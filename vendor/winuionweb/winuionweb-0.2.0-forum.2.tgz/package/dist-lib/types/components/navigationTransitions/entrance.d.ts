import { type NavigationStoryboardPair, type NavigationStoryboardTarget, type NavigationTransitionStoryboard } from './shared';
/** EntranceNavigationTransitionInfo::CreateStoryboards, ThemeTransitions.cpp:3141. */
export declare const createEntranceStoryboards: (backward: boolean) => NavigationStoryboardPair;
export declare const resolveEntranceStoryboards: (storyboard: NavigationTransitionStoryboard, root: HTMLElement, incoming: boolean) => NavigationStoryboardTarget[];
