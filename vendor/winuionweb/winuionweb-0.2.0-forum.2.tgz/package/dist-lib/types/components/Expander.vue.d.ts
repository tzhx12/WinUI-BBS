declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    Header: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Content: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Description: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    HeaderIcon: {
        type: StringConstructor;
        default: string;
    };
    IsExpanded: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    ExpandDirection: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Padding: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Background: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    BorderBrush: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    BorderThickness: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    CornerRadius: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    HorizontalContentAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalContentAlignment: {
        type: StringConstructor;
        default: string;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
}>, {
    IsExpanded: boolean;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    Expanding: (...args: any[]) => void;
    Collapsed: (...args: any[]) => void;
    "update:IsExpanded": (...args: any[]) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    Header: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Content: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Description: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    HeaderIcon: {
        type: StringConstructor;
        default: string;
    };
    IsExpanded: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    ExpandDirection: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Padding: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Background: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    BorderBrush: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    BorderThickness: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    CornerRadius: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    HorizontalContentAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalContentAlignment: {
        type: StringConstructor;
        default: string;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
}>> & Readonly<{
    onExpanding?: ((...args: any[]) => any) | undefined;
    onCollapsed?: ((...args: any[]) => any) | undefined;
    "onUpdate:IsExpanded"?: ((...args: any[]) => any) | undefined;
}>, {
    Width: string | number;
    Height: string | number;
    MinWidth: string | number;
    MaxWidth: string | number;
    Padding: string | number;
    HorizontalAlignment: string;
    VerticalAlignment: string;
    Description: string | number;
    IsEnabled: string | boolean;
    Header: string | number;
    Background: string | Record<string, any>;
    BorderBrush: string | Record<string, any>;
    BorderThickness: string | number;
    CornerRadius: string | number;
    HorizontalContentAlignment: string;
    VerticalContentAlignment: string;
    Content: string | number;
    IsExpanded: string | boolean;
    HeaderIcon: string;
    ExpandDirection: string | number;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
