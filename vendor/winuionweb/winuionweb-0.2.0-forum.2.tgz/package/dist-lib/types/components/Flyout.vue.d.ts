import { type PropType } from 'vue';
declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    Content: {
        type: PropType<unknown>;
        default: unknown;
    };
    Placement: {
        type: StringConstructor;
        default: string;
    };
    ShowMode: {
        type: StringConstructor;
        default: string;
    };
    LightDismissOverlayMode: {
        type: StringConstructor;
        default: string;
    };
    AreOpenCloseAnimationsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    ShouldConstrainToRootBounds: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    AllowFocusOnInteraction: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    AllowFocusWhenDisabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    FlyoutPresenterStyle: {
        type: PropType<unknown>;
        default: unknown;
    };
}>, {
    Content: import("vue").WritableComputedRef<unknown, unknown>;
    ShowAt: (placementTarget?: unknown, options?: {
        Placement?: string;
        ShowMode?: string;
        Position?: {
            X?: number;
            Y?: number;
            x?: number;
            y?: number;
        };
    }) => Promise<void>;
    Hide: (restoreFocus?: boolean) => void;
    IsOpen: import("vue").ComputedRef<boolean>;
    Target: import("vue").ComputedRef<HTMLElement | null>;
    IsConstrainedToRootBounds: import("vue").ComputedRef<boolean>;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    Opening: (...args: any[]) => void;
    Opened: (...args: any[]) => void;
    Closing: (...args: any[]) => void;
    Closed: (...args: any[]) => void;
    "update:Content": (...args: any[]) => void;
    "update:AllowFocusOnInteraction": (...args: any[]) => void;
    "update:AllowFocusWhenDisabled": (...args: any[]) => void;
    "update:Placement": (...args: any[]) => void;
    "update:ShowMode": (...args: any[]) => void;
    "update:AreOpenCloseAnimationsEnabled": (...args: any[]) => void;
    "update:ShouldConstrainToRootBounds": (...args: any[]) => void;
    "update:LightDismissOverlayMode": (...args: any[]) => void;
    "update:FlyoutPresenterStyle": (...args: any[]) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    Content: {
        type: PropType<unknown>;
        default: unknown;
    };
    Placement: {
        type: StringConstructor;
        default: string;
    };
    ShowMode: {
        type: StringConstructor;
        default: string;
    };
    LightDismissOverlayMode: {
        type: StringConstructor;
        default: string;
    };
    AreOpenCloseAnimationsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    ShouldConstrainToRootBounds: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    AllowFocusOnInteraction: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    AllowFocusWhenDisabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    FlyoutPresenterStyle: {
        type: PropType<unknown>;
        default: unknown;
    };
}>> & Readonly<{
    onOpening?: ((...args: any[]) => any) | undefined;
    onOpened?: ((...args: any[]) => any) | undefined;
    onClosing?: ((...args: any[]) => any) | undefined;
    onClosed?: ((...args: any[]) => any) | undefined;
    "onUpdate:Content"?: ((...args: any[]) => any) | undefined;
    "onUpdate:AllowFocusOnInteraction"?: ((...args: any[]) => any) | undefined;
    "onUpdate:AllowFocusWhenDisabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:Placement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:ShowMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:AreOpenCloseAnimationsEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:ShouldConstrainToRootBounds"?: ((...args: any[]) => any) | undefined;
    "onUpdate:LightDismissOverlayMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:FlyoutPresenterStyle"?: ((...args: any[]) => any) | undefined;
}>, {
    FlyoutPresenterStyle: unknown;
    Content: unknown;
    Placement: string;
    AllowFocusOnInteraction: string | boolean;
    AllowFocusWhenDisabled: string | boolean;
    ShowMode: string;
    AreOpenCloseAnimationsEnabled: string | boolean;
    ShouldConstrainToRootBounds: string | boolean;
    LightDismissOverlayMode: string;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
