import { type ComponentInternalInstance, type VNode } from 'vue';
export declare const brushProperty: (owner: string, property: string) => import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const isBrushProperty: (node: VNode) => boolean;
export declare const useBrushProperty: (property: string, value: () => unknown, nodes: () => VNode[], instance: ComponentInternalInstance | null) => {
    value: import("vue").ComputedRef<unknown>;
    style: import("vue").ComputedRef<import("vue").CSSProperties>;
};
