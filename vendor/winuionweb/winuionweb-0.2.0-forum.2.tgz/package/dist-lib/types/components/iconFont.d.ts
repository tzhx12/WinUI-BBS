export type WinUIIconFontSource = string | URL | Blob | ArrayBuffer;
/**
 * Load an icon font supplied by the host application. The npm package does not
 * contain a font file; callers must have the right to use and distribute it.
 * Returns a function that removes the registered faces from the document.
 */
export declare function loadWinUIIconFont(source: WinUIIconFontSource, targetDocument?: Document): Promise<() => void>;
