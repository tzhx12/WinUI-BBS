declare const __VLS_export: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    HorizontalOrientationPadding: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    VerticalOrientationPadding: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    HorizontalOrientationPadding: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    VerticalOrientationPadding: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
}>> & Readonly<{}>, {
    Margin: string | number;
    HorizontalOrientationPadding: string | number;
    VerticalOrientationPadding: string | number;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
declare const _default: typeof __VLS_export;
export default _default;
