import { type ComponentInternalInstance } from 'vue';
type GeometryResult = {
    path: string;
    fillRule: 'evenodd' | 'nonzero';
};
/** Consume the same Geometry object elements declared in Shapes.ts. */
export declare const resolveIconGeometry: (input: unknown, instance: ComponentInternalInstance | null) => GeometryResult;
export {};
