declare const __VLS_export: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    Kind: {
        type: StringConstructor;
        default: string;
    };
    Columns: {
        type: (StringConstructor | ArrayConstructor)[];
        default: () => never[];
    };
    RequestedTheme: {
        type: StringConstructor;
        default: string;
    };
    LightDismissOverlayMode: {
        type: StringConstructor;
        default: string;
    };
}>, {
    ShowAt: (target: HTMLElement) => Promise<void>;
    Hide: () => Promise<void>;
    Flush: () => void;
    IsOpen: import("vue").Ref<boolean, boolean>;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    SelectionChanged: (...args: any[]) => void;
    Closed: (...args: any[]) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    Kind: {
        type: StringConstructor;
        default: string;
    };
    Columns: {
        type: (StringConstructor | ArrayConstructor)[];
        default: () => never[];
    };
    RequestedTheme: {
        type: StringConstructor;
        default: string;
    };
    LightDismissOverlayMode: {
        type: StringConstructor;
        default: string;
    };
}>> & Readonly<{
    onSelectionChanged?: ((...args: any[]) => any) | undefined;
    onClosed?: ((...args: any[]) => any) | undefined;
}>, {
    Kind: string;
    RequestedTheme: string;
    LightDismissOverlayMode: string;
    Columns: string | unknown[];
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
declare const _default: typeof __VLS_export;
export default _default;
