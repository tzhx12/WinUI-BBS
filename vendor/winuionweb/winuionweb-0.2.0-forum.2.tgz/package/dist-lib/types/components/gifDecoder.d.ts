/** Browser equivalent of the composited GIF frames used by WinUI's imaging service. */
export type GifFrame = {
    image: CanvasImageSource;
    duration: number;
};
export type GifImage = {
    width: number;
    height: number;
    frames: GifFrame[];
    repetitions: number;
    dispose: () => void;
};
/**
 * Safari and Firefox do not expose ImageDecoder. Read the same palette, LZW,
 * transparency, interlace and disposal data there so Stop freezes an actual
 * frame and Play resumes from that frame rather than restarting an <img> URL.
 */
export declare function decodeGifData(data: ArrayBuffer): GifImage;
export declare function decodeGif(data: ArrayBuffer): Promise<GifImage>;
