import { type Directive, type StyleValue } from 'vue';
export interface AcrylicMaterialLayer {
    update(input: StyleValue): void;
    dispose(): void;
}
export interface AcrylicNoiseLayer {
    update(): void;
    dispose(): void;
}
/** Apply the in-app Acrylic layers over a native backdrop without another blur pass. */
export declare const createAcrylicMaterialLayer: (host: HTMLElement, input: StyleValue) => AcrylicMaterialLayer;
export declare const mountAcrylicMaterialLayer: (host: HTMLElement, input: StyleValue) => (() => void);
/** Add only the package-owned noise texture over a native Desktop Acrylic surface. */
export declare const createAcrylicNoiseLayer: (host: HTMLElement, opacity?: number) => AcrylicNoiseLayer;
export declare const mountAcrylicNoiseLayer: (host: HTMLElement, opacity?: number) => (() => void);
export declare const vAcrylicBrush: Directive<HTMLElement, StyleValue>;
export declare const vAcrylicBackdrop: Directive<HTMLElement, StyleValue>;
