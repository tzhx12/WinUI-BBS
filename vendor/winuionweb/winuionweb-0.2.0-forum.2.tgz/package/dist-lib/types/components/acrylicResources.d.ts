export declare const acrylicResourceAliases: Readonly<Record<string, string>>;
export type AccentPalette = {
    SystemAccentColorDark1: string;
    SystemAccentColorDark2: string;
    SystemAccentColorLight3: string;
};
export declare const acrylicThemeResources: (theme: "light" | "dark", accent?: string | AccentPalette, highContrast?: boolean) => Record<string, unknown>;
export declare const acrylicResource: (name: string, theme?: "light" | "dark", accent?: string | AccentPalette, highContrast?: boolean) => unknown;
export declare const isAcrylicResource: (name: string) => boolean;
