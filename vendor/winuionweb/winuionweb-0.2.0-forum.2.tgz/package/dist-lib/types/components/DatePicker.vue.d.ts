declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    CalendarIdentifier: {
        type: StringConstructor;
        default: string;
    };
    Date: {
        type: (StringConstructor | DateConstructor)[];
        default: undefined;
    };
    SelectedDate: {
        type: (StringConstructor | DateConstructor)[];
        default: undefined;
    };
    DayFormat: {
        type: StringConstructor;
        default: string;
    };
    DayVisible: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    MonthFormat: {
        type: StringConstructor;
        default: string;
    };
    MonthVisible: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    YearFormat: {
        type: StringConstructor;
        default: string;
    };
    YearVisible: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    MinYear: {
        type: (StringConstructor | DateConstructor)[];
        default: () => Date;
    };
    MaxYear: {
        type: (StringConstructor | DateConstructor)[];
        default: () => Date;
    };
    Header: {
        type: null;
        default: null;
    };
    HeaderTemplate: {
        type: null;
        default: null;
    };
    Orientation: {
        type: StringConstructor;
        default: string;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    Language: {
        type: StringConstructor;
        default: string;
    };
    LightDismissOverlayMode: {
        type: StringConstructor;
        default: string;
    };
    RequestedTheme: {
        type: StringConstructor;
        default: string;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Padding: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
    FontSize: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    FontFamily: {
        type: StringConstructor;
        default: string;
    };
    FontWeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Background: {
        type: StringConstructor;
        default: string;
    };
    Foreground: {
        type: StringConstructor;
        default: string;
    };
    BorderBrush: {
        type: StringConstructor;
        default: string;
    };
    BorderThickness: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    CornerRadius: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
}>, {
    Date: import("vue").WritableComputedRef<Date, Date>;
    SelectedDate: import("vue").WritableComputedRef<Date | null, Date | null>;
    Focus: () => void | undefined;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    DateChanged: (...args: any[]) => void;
    SelectedDateChanged: (...args: any[]) => void;
    "update:Date": (...args: any[]) => void;
    "update:SelectedDate": (...args: any[]) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    CalendarIdentifier: {
        type: StringConstructor;
        default: string;
    };
    Date: {
        type: (StringConstructor | DateConstructor)[];
        default: undefined;
    };
    SelectedDate: {
        type: (StringConstructor | DateConstructor)[];
        default: undefined;
    };
    DayFormat: {
        type: StringConstructor;
        default: string;
    };
    DayVisible: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    MonthFormat: {
        type: StringConstructor;
        default: string;
    };
    MonthVisible: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    YearFormat: {
        type: StringConstructor;
        default: string;
    };
    YearVisible: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    MinYear: {
        type: (StringConstructor | DateConstructor)[];
        default: () => Date;
    };
    MaxYear: {
        type: (StringConstructor | DateConstructor)[];
        default: () => Date;
    };
    Header: {
        type: null;
        default: null;
    };
    HeaderTemplate: {
        type: null;
        default: null;
    };
    Orientation: {
        type: StringConstructor;
        default: string;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    Language: {
        type: StringConstructor;
        default: string;
    };
    LightDismissOverlayMode: {
        type: StringConstructor;
        default: string;
    };
    RequestedTheme: {
        type: StringConstructor;
        default: string;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Padding: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
    FontSize: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    FontFamily: {
        type: StringConstructor;
        default: string;
    };
    FontWeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Background: {
        type: StringConstructor;
        default: string;
    };
    Foreground: {
        type: StringConstructor;
        default: string;
    };
    BorderBrush: {
        type: StringConstructor;
        default: string;
    };
    BorderThickness: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    CornerRadius: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
}>> & Readonly<{
    onDateChanged?: ((...args: any[]) => any) | undefined;
    onSelectedDateChanged?: ((...args: any[]) => any) | undefined;
    "onUpdate:Date"?: ((...args: any[]) => any) | undefined;
    "onUpdate:SelectedDate"?: ((...args: any[]) => any) | undefined;
}>, {
    Width: string | number;
    Height: string | number;
    MinWidth: string | number;
    MaxWidth: string | number;
    MinHeight: string | number;
    MaxHeight: string | number;
    Margin: string | number;
    Padding: string | number;
    HorizontalAlignment: string;
    VerticalAlignment: string;
    Foreground: string;
    IsEnabled: string | boolean;
    Header: any;
    Background: string;
    BorderBrush: string;
    BorderThickness: string | number;
    CornerRadius: string | number;
    FontSize: string | number;
    FontFamily: string;
    FontWeight: string | number;
    RequestedTheme: string;
    HeaderTemplate: any;
    Visibility: string;
    Language: string;
    Orientation: string;
    LightDismissOverlayMode: string;
    CalendarIdentifier: string;
    Date: string | Date;
    SelectedDate: string | Date;
    DayFormat: string;
    DayVisible: string | boolean;
    MonthFormat: string;
    MonthVisible: string | boolean;
    YearFormat: string;
    YearVisible: string | boolean;
    MinYear: string | Date;
    MaxYear: string | Date;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
