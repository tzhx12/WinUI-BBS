/** Typed values from InfoBadge/InfoBar_themeresources.xaml. Brushes remain
 * CSS variables so ThemeResource follows the nearest local theme scope. */
export declare const informationControlResources: Readonly<Record<string, string | number>>;
