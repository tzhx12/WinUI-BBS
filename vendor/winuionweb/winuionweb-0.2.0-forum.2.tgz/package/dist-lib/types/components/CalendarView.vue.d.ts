type Mode = 'Month' | 'Year' | 'Decade';
declare const __VLS_export: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    CalendarIdentifier: {
        type: StringConstructor;
        default: string;
    };
    DayOfWeekFormat: {
        type: StringConstructor;
        default: string;
    };
    DisplayMode: {
        type: StringConstructor;
        default: string;
    };
    FirstDayOfWeek: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    IsGroupLabelVisible: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsOutOfScopeEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsTodayHighlighted: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    MaxDate: {
        type: (NumberConstructor | StringConstructor | DateConstructor)[];
        default: undefined;
    };
    MinDate: {
        type: (NumberConstructor | StringConstructor | DateConstructor)[];
        default: undefined;
    };
    NumberOfWeeksInView: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    SelectedDates: {
        type: (StringConstructor | ArrayConstructor)[];
        default: undefined;
    };
    SelectionMode: {
        type: StringConstructor;
        default: string;
    };
    Language: {
        type: StringConstructor;
        default: string;
    };
    RequestedTheme: {
        type: StringConstructor;
        default: string;
    };
    SelectedDatesChanged: {
        type: (StringConstructor | FunctionConstructor)[];
        default: undefined;
    };
    CalendarViewDayItemChanging: {
        type: (StringConstructor | FunctionConstructor)[];
        default: undefined;
    };
    Style: (StringConstructor | ObjectConstructor)[];
    Width: (NumberConstructor | StringConstructor)[];
    Height: (NumberConstructor | StringConstructor)[];
    MinWidth: (NumberConstructor | StringConstructor)[];
    MinHeight: (NumberConstructor | StringConstructor)[];
    MaxWidth: (NumberConstructor | StringConstructor)[];
    MaxHeight: (NumberConstructor | StringConstructor)[];
    Margin: (NumberConstructor | StringConstructor)[];
    Padding: (NumberConstructor | StringConstructor)[];
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    CornerRadius: (NumberConstructor | StringConstructor)[];
    BorderThickness: (NumberConstructor | StringConstructor)[];
    CalendarItemBorderThickness: (NumberConstructor | StringConstructor)[];
    CalendarItemCornerRadius: (NumberConstructor | StringConstructor)[];
    DayItemFontFamily: StringConstructor;
    DayItemFontSize: (NumberConstructor | StringConstructor)[];
    DayItemFontWeight: (NumberConstructor | StringConstructor)[];
    DayItemMargin: (NumberConstructor | StringConstructor)[];
    FirstOfMonthLabelFontFamily: StringConstructor;
    FirstOfMonthLabelFontSize: (NumberConstructor | StringConstructor)[];
    FirstOfMonthLabelFontWeight: (NumberConstructor | StringConstructor)[];
    FirstOfMonthLabelMargin: (NumberConstructor | StringConstructor)[];
    MonthYearItemFontFamily: StringConstructor;
    MonthYearItemFontSize: (NumberConstructor | StringConstructor)[];
    MonthYearItemFontWeight: (NumberConstructor | StringConstructor)[];
    MonthYearItemMargin: (NumberConstructor | StringConstructor)[];
    FirstOfYearDecadeLabelFontFamily: StringConstructor;
    FirstOfYearDecadeLabelFontSize: (NumberConstructor | StringConstructor)[];
    FirstOfYearDecadeLabelFontWeight: (NumberConstructor | StringConstructor)[];
    FirstOfYearDecadeLabelMargin: (NumberConstructor | StringConstructor)[];
    TodayFontWeight: (NumberConstructor | StringConstructor)[];
    Foreground: StringConstructor;
    Background: StringConstructor;
    BorderBrush: StringConstructor;
    BlackoutStrikethroughBrush: StringConstructor;
    SelectedHoverBorderBrush: StringConstructor;
    SelectedPressedBorderBrush: StringConstructor;
    SelectedDisabledBorderBrush: StringConstructor;
    SelectedBorderBrush: StringConstructor;
    HoverBorderBrush: StringConstructor;
    PressedBorderBrush: StringConstructor;
    CalendarItemBorderBrush: StringConstructor;
    TodaySelectedInnerBorderBrush: StringConstructor;
    TodayForeground: StringConstructor;
    DisabledForeground: StringConstructor;
    BlackoutForeground: StringConstructor;
    SelectedForeground: StringConstructor;
    SelectedHoverForeground: StringConstructor;
    SelectedPressedForeground: StringConstructor;
    SelectedDisabledForeground: StringConstructor;
    PressedForeground: StringConstructor;
    OutOfScopeForeground: StringConstructor;
    OutOfScopeHoverForeground: StringConstructor;
    OutOfScopePressedForeground: StringConstructor;
    CalendarItemForeground: StringConstructor;
    TodayBackground: StringConstructor;
    TodayBlackoutBackground: StringConstructor;
    TodayBlackoutForeground: StringConstructor;
    TodayHoverBackground: StringConstructor;
    TodayPressedBackground: StringConstructor;
    TodayDisabledBackground: StringConstructor;
    BlackoutBackground: StringConstructor;
    OutOfScopeBackground: StringConstructor;
    CalendarItemBackground: StringConstructor;
    CalendarItemHoverBackground: StringConstructor;
    CalendarItemPressedBackground: StringConstructor;
    CalendarItemDisabledBackground: StringConstructor;
}>, {
    SelectedDates: Date[];
    SelectionMode: string;
    Language: string;
    CalendarIdentifier: string;
    DisplayMode: Mode;
    SetDisplayDate(date: Date | string): void;
    SetYearDecadeDisplayDimensions(columnCount: number, rowCount: number): void;
    Focus: () => Promise<boolean>;
    FocusFirst: () => Promise<boolean>;
    FocusDate: (date: Date | number) => Promise<boolean>;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    SelectedDatesChanged: (...args: any[]) => void;
    CalendarViewDayItemChanging: (...args: any[]) => void;
    "update:DisplayMode": (...args: any[]) => void;
    "update:SelectedDates": (...args: any[]) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    CalendarIdentifier: {
        type: StringConstructor;
        default: string;
    };
    DayOfWeekFormat: {
        type: StringConstructor;
        default: string;
    };
    DisplayMode: {
        type: StringConstructor;
        default: string;
    };
    FirstDayOfWeek: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    IsGroupLabelVisible: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsOutOfScopeEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsTodayHighlighted: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    MaxDate: {
        type: (NumberConstructor | StringConstructor | DateConstructor)[];
        default: undefined;
    };
    MinDate: {
        type: (NumberConstructor | StringConstructor | DateConstructor)[];
        default: undefined;
    };
    NumberOfWeeksInView: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    SelectedDates: {
        type: (StringConstructor | ArrayConstructor)[];
        default: undefined;
    };
    SelectionMode: {
        type: StringConstructor;
        default: string;
    };
    Language: {
        type: StringConstructor;
        default: string;
    };
    RequestedTheme: {
        type: StringConstructor;
        default: string;
    };
    SelectedDatesChanged: {
        type: (StringConstructor | FunctionConstructor)[];
        default: undefined;
    };
    CalendarViewDayItemChanging: {
        type: (StringConstructor | FunctionConstructor)[];
        default: undefined;
    };
    Style: (StringConstructor | ObjectConstructor)[];
    Width: (NumberConstructor | StringConstructor)[];
    Height: (NumberConstructor | StringConstructor)[];
    MinWidth: (NumberConstructor | StringConstructor)[];
    MinHeight: (NumberConstructor | StringConstructor)[];
    MaxWidth: (NumberConstructor | StringConstructor)[];
    MaxHeight: (NumberConstructor | StringConstructor)[];
    Margin: (NumberConstructor | StringConstructor)[];
    Padding: (NumberConstructor | StringConstructor)[];
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    CornerRadius: (NumberConstructor | StringConstructor)[];
    BorderThickness: (NumberConstructor | StringConstructor)[];
    CalendarItemBorderThickness: (NumberConstructor | StringConstructor)[];
    CalendarItemCornerRadius: (NumberConstructor | StringConstructor)[];
    DayItemFontFamily: StringConstructor;
    DayItemFontSize: (NumberConstructor | StringConstructor)[];
    DayItemFontWeight: (NumberConstructor | StringConstructor)[];
    DayItemMargin: (NumberConstructor | StringConstructor)[];
    FirstOfMonthLabelFontFamily: StringConstructor;
    FirstOfMonthLabelFontSize: (NumberConstructor | StringConstructor)[];
    FirstOfMonthLabelFontWeight: (NumberConstructor | StringConstructor)[];
    FirstOfMonthLabelMargin: (NumberConstructor | StringConstructor)[];
    MonthYearItemFontFamily: StringConstructor;
    MonthYearItemFontSize: (NumberConstructor | StringConstructor)[];
    MonthYearItemFontWeight: (NumberConstructor | StringConstructor)[];
    MonthYearItemMargin: (NumberConstructor | StringConstructor)[];
    FirstOfYearDecadeLabelFontFamily: StringConstructor;
    FirstOfYearDecadeLabelFontSize: (NumberConstructor | StringConstructor)[];
    FirstOfYearDecadeLabelFontWeight: (NumberConstructor | StringConstructor)[];
    FirstOfYearDecadeLabelMargin: (NumberConstructor | StringConstructor)[];
    TodayFontWeight: (NumberConstructor | StringConstructor)[];
    Foreground: StringConstructor;
    Background: StringConstructor;
    BorderBrush: StringConstructor;
    BlackoutStrikethroughBrush: StringConstructor;
    SelectedHoverBorderBrush: StringConstructor;
    SelectedPressedBorderBrush: StringConstructor;
    SelectedDisabledBorderBrush: StringConstructor;
    SelectedBorderBrush: StringConstructor;
    HoverBorderBrush: StringConstructor;
    PressedBorderBrush: StringConstructor;
    CalendarItemBorderBrush: StringConstructor;
    TodaySelectedInnerBorderBrush: StringConstructor;
    TodayForeground: StringConstructor;
    DisabledForeground: StringConstructor;
    BlackoutForeground: StringConstructor;
    SelectedForeground: StringConstructor;
    SelectedHoverForeground: StringConstructor;
    SelectedPressedForeground: StringConstructor;
    SelectedDisabledForeground: StringConstructor;
    PressedForeground: StringConstructor;
    OutOfScopeForeground: StringConstructor;
    OutOfScopeHoverForeground: StringConstructor;
    OutOfScopePressedForeground: StringConstructor;
    CalendarItemForeground: StringConstructor;
    TodayBackground: StringConstructor;
    TodayBlackoutBackground: StringConstructor;
    TodayBlackoutForeground: StringConstructor;
    TodayHoverBackground: StringConstructor;
    TodayPressedBackground: StringConstructor;
    TodayDisabledBackground: StringConstructor;
    BlackoutBackground: StringConstructor;
    OutOfScopeBackground: StringConstructor;
    CalendarItemBackground: StringConstructor;
    CalendarItemHoverBackground: StringConstructor;
    CalendarItemPressedBackground: StringConstructor;
    CalendarItemDisabledBackground: StringConstructor;
}>> & Readonly<{
    onSelectedDatesChanged?: ((...args: any[]) => any) | undefined;
    onCalendarViewDayItemChanging?: ((...args: any[]) => any) | undefined;
    "onUpdate:DisplayMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:SelectedDates"?: ((...args: any[]) => any) | undefined;
}>, {
    HorizontalAlignment: string;
    VerticalAlignment: string;
    IsEnabled: string | boolean;
    RequestedTheme: string;
    SelectedDatesChanged: string | Function;
    CalendarViewDayItemChanging: string | Function;
    Language: string;
    SelectionMode: string;
    DisplayMode: string;
    CalendarIdentifier: string;
    DayOfWeekFormat: string;
    FirstDayOfWeek: string | number;
    IsGroupLabelVisible: string | boolean;
    IsOutOfScopeEnabled: string | boolean;
    IsTodayHighlighted: string | boolean;
    MaxDate: string | number | Date;
    MinDate: string | number | Date;
    NumberOfWeeksInView: string | number;
    SelectedDates: string | unknown[];
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
declare const _default: typeof __VLS_export;
export default _default;
