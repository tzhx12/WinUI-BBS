declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    ItemsSource: {
        type: (StringConstructor | ArrayConstructor | ObjectConstructor)[];
        default: null;
    };
    SelectedIndex: {
        type: (NumberConstructor | StringConstructor)[];
        default: undefined;
    };
    SelectedItem: {
        type: (NumberConstructor | StringConstructor | ObjectConstructor | BooleanConstructor)[];
        default: undefined;
    };
    Orientation: {
        type: StringConstructor;
        default: undefined;
    };
    FlowDirection: {
        type: StringConstructor;
        default: undefined;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    HorizontalContentAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalContentAlignment: {
        type: StringConstructor;
        default: string;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsTabStop: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    ItemTemplate: {
        type: (StringConstructor | ObjectConstructor)[];
        default: undefined;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Padding: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Background: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    BorderBrush: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    BorderThickness: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    CornerRadius: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
}>, {
    SelectedIndex: import("vue").WritableComputedRef<number, number>;
    SelectedItem: import("vue").ComputedRef<any>;
    MovePrevious: () => void;
    MoveNext: () => void;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    SelectionChanged: (...args: any[]) => void;
    "update:SelectedItem": (...args: any[]) => void;
    "update:SelectedIndex": (...args: any[]) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    ItemsSource: {
        type: (StringConstructor | ArrayConstructor | ObjectConstructor)[];
        default: null;
    };
    SelectedIndex: {
        type: (NumberConstructor | StringConstructor)[];
        default: undefined;
    };
    SelectedItem: {
        type: (NumberConstructor | StringConstructor | ObjectConstructor | BooleanConstructor)[];
        default: undefined;
    };
    Orientation: {
        type: StringConstructor;
        default: undefined;
    };
    FlowDirection: {
        type: StringConstructor;
        default: undefined;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    HorizontalContentAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalContentAlignment: {
        type: StringConstructor;
        default: string;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsTabStop: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    ItemTemplate: {
        type: (StringConstructor | ObjectConstructor)[];
        default: undefined;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Padding: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Background: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    BorderBrush: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    BorderThickness: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    CornerRadius: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
}>> & Readonly<{
    onSelectionChanged?: ((...args: any[]) => any) | undefined;
    "onUpdate:SelectedItem"?: ((...args: any[]) => any) | undefined;
    "onUpdate:SelectedIndex"?: ((...args: any[]) => any) | undefined;
}>, {
    Width: string | number;
    Height: string | number;
    MinWidth: string | number;
    MaxWidth: string | number;
    MinHeight: string | number;
    MaxHeight: string | number;
    Margin: string | number;
    Padding: string | number;
    HorizontalAlignment: string;
    VerticalAlignment: string;
    IsEnabled: string | boolean;
    Background: string | Record<string, any>;
    BorderBrush: string | Record<string, any>;
    BorderThickness: string | number;
    CornerRadius: string | number;
    HorizontalContentAlignment: string;
    VerticalContentAlignment: string;
    IsTabStop: string | boolean;
    SelectedItem: string | number | boolean | Record<string, any>;
    ItemTemplate: string | Record<string, any>;
    FlowDirection: string;
    Orientation: string;
    ItemsSource: string | unknown[] | Record<string, any>;
    SelectedIndex: string | number;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
