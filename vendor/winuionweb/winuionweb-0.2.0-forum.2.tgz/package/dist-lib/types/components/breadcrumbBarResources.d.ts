export declare const breadcrumbBarResources: Record<string, string | number>;
