import { type ImageEventArgs } from './imageSource';
declare const __VLS_export: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    UriSource: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    AutoPlay: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    DecodePixelWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    DecodePixelHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    DecodePixelType: {
        type: StringConstructor;
        default: string;
    };
}>, import("./imageSource").ImageSourceModel, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    ImageOpened: (sender: unknown, args: ImageEventArgs) => any;
    ImageFailed: (sender: unknown, args: ImageEventArgs) => any;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    UriSource: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    AutoPlay: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    DecodePixelWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    DecodePixelHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    DecodePixelType: {
        type: StringConstructor;
        default: string;
    };
}>> & Readonly<{
    onImageOpened?: ((sender: unknown, args: ImageEventArgs) => any) | undefined;
    onImageFailed?: ((sender: unknown, args: ImageEventArgs) => any) | undefined;
}>, {
    UriSource: string | Record<string, any>;
    AutoPlay: string | boolean;
    DecodePixelWidth: string | number;
    DecodePixelHeight: string | number;
    DecodePixelType: string;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
declare const _default: typeof __VLS_export;
export default _default;
