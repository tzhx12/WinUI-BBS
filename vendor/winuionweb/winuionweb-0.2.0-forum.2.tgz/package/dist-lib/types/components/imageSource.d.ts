import { type ComponentInternalInstance, type InjectionKey, type VNode } from 'vue';
export type ImageSourceKind = 'BitmapImage' | 'SvgImageSource';
export type ImageSourceModel = {
    UriSource: string;
    AutoPlay: boolean;
    DecodePixelWidth: number;
    DecodePixelHeight: number;
    DecodePixelType: string;
    RasterizePixelWidth: number;
    RasterizePixelHeight: number;
    readonly PixelWidth: number;
    readonly PixelHeight: number;
    readonly IsAnimatedBitmap: boolean;
    readonly IsPlaying: boolean;
    Play: () => void;
    Stop: () => void;
    __kind: ImageSourceKind;
    __state: {
        pixelWidth: number;
        pixelHeight: number;
        animated: boolean;
        playing: boolean;
    };
    __play?: () => void;
    __stop?: () => void;
};
export type ImageEventArgs = {
    OriginalSource: unknown;
    PixelWidth?: number;
    PixelHeight?: number;
    ErrorMessage?: string;
    BrowserEvent?: Event;
};
export type ImageSourceRegistration = {
    model: ImageSourceModel;
    opened: (args: ImageEventArgs) => void;
    failed: (args: ImageEventArgs) => void;
};
export declare const imageSourceContextKey: InjectionKey<(registration: ImageSourceRegistration | null) => void>;
export declare const ImageSourceProperty: import("vue").DefineComponent<{}, () => VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const imageNumber: (value: unknown) => number;
export declare const imageBoolean: (value: unknown) => value is true | "True";
export declare const imageUri: (input: unknown, instance: ComponentInternalInstance | null, resources?: Record<string, VNode> | null) => string;
/** ImageSource's public dependency properties retain their official casing. */
export declare const createImageSourceModel: (kind?: ImageSourceKind) => ImageSourceModel;
/** A single decode dimension preserves aspect ratio, as WinUI does. */
export declare const imageDecodeSize: (width: number, height: number, requestedWidth: number, requestedHeight: number) => {
    width: number;
    height: number;
};
export declare const imageStretchSize: (width: number, height: number, availableWidth: number, availableHeight: number, stretch: string) => {
    width: number;
    height: number;
};
