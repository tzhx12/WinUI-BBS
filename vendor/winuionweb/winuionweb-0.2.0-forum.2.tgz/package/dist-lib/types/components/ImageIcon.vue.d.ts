declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: __VLS_WithSlots<import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    Source: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    Foreground: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    Visibility: {
        type: (StringConstructor | BooleanConstructor)[];
        default: string;
    };
    Opacity: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    IsHitTestVisible: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    FlowDirection: {
        type: StringConstructor;
        default: string;
    };
    RequestedTheme: {
        type: StringConstructor;
        default: string;
    };
}>, Record<string, unknown>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    Source: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    Foreground: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    Visibility: {
        type: (StringConstructor | BooleanConstructor)[];
        default: string;
    };
    Opacity: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    IsHitTestVisible: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    FlowDirection: {
        type: StringConstructor;
        default: string;
    };
    RequestedTheme: {
        type: StringConstructor;
        default: string;
    };
}>> & Readonly<{}>, {
    Width: string | number;
    Height: string | number;
    MinWidth: string | number;
    MaxWidth: string | number;
    MinHeight: string | number;
    MaxHeight: string | number;
    Margin: string | number;
    HorizontalAlignment: string;
    VerticalAlignment: string;
    Foreground: string | Record<string, any>;
    Opacity: string | number;
    Source: string | Record<string, any>;
    RequestedTheme: string;
    Visibility: string | boolean;
    IsHitTestVisible: string | boolean;
    FlowDirection: string;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>, {
    default?: (props: {}) => any;
}>;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
