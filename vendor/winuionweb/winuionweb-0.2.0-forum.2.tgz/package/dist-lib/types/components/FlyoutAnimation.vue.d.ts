import { type PropType } from 'vue';
import { type FlyoutAnimationDirection, type FlyoutAnimationOrigin, type FlyoutAnimationOriginElement, type FlyoutAnimationRect, type Resolvable } from './useFlyoutAnimation';
declare var __VLS_1: {};
type __VLS_Slots = {} & {
    default?: (props: typeof __VLS_1) => any;
};
declare const __VLS_base: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    Open: {
        type: BooleanConstructor;
        default: undefined;
    };
    Autoplay: {
        type: BooleanConstructor;
        default: boolean;
    };
    Origin: {
        type: PropType<FlyoutAnimationOrigin>;
        default: string;
    };
    Direction: {
        type: PropType<FlyoutAnimationDirection>;
        default: string;
    };
    OriginElement: {
        type: PropType<Resolvable<FlyoutAnimationOriginElement>>;
        default: null;
    };
    StartRect: {
        type: PropType<Resolvable<FlyoutAnimationRect | null> | ((targetRect: DOMRect) => FlyoutAnimationRect | null)>;
        default: null;
    };
    Duration: {
        type: NumberConstructor;
        default: number;
    };
    Easing: {
        type: StringConstructor;
        default: string;
    };
    Margin: {
        type: NumberConstructor;
        default: number;
    };
    StripSize: {
        type: NumberConstructor;
        default: number;
    };
    RespectReducedMotion: {
        type: BooleanConstructor;
        default: boolean;
    };
}>, {
    play: () => void;
    cancel: () => void;
    isPlaying: import("vue").Ref<boolean, boolean>;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    Open: {
        type: BooleanConstructor;
        default: undefined;
    };
    Autoplay: {
        type: BooleanConstructor;
        default: boolean;
    };
    Origin: {
        type: PropType<FlyoutAnimationOrigin>;
        default: string;
    };
    Direction: {
        type: PropType<FlyoutAnimationDirection>;
        default: string;
    };
    OriginElement: {
        type: PropType<Resolvable<FlyoutAnimationOriginElement>>;
        default: null;
    };
    StartRect: {
        type: PropType<Resolvable<FlyoutAnimationRect | null> | ((targetRect: DOMRect) => FlyoutAnimationRect | null)>;
        default: null;
    };
    Duration: {
        type: NumberConstructor;
        default: number;
    };
    Easing: {
        type: StringConstructor;
        default: string;
    };
    Margin: {
        type: NumberConstructor;
        default: number;
    };
    StripSize: {
        type: NumberConstructor;
        default: number;
    };
    RespectReducedMotion: {
        type: BooleanConstructor;
        default: boolean;
    };
}>> & Readonly<{}>, {
    Margin: number;
    Open: boolean;
    OriginElement: Resolvable<FlyoutAnimationOriginElement>;
    StartRect: Resolvable<FlyoutAnimationRect | null> | ((targetRect: DOMRect) => FlyoutAnimationRect | null);
    Origin: FlyoutAnimationOrigin;
    StripSize: number;
    Autoplay: boolean;
    Direction: FlyoutAnimationDirection;
    Duration: number;
    Easing: string;
    RespectReducedMotion: boolean;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
declare const __VLS_export: __VLS_WithSlots<typeof __VLS_base, __VLS_Slots>;
declare const _default: typeof __VLS_export;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
