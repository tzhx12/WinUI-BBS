import { type VNode } from 'vue';
export declare const breadcrumbBarItemContextKey: unique symbol;
export declare const ContentTemplate: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
/**
 * WinUI text font properties inherit from ContentPresenter. The web TextBlock
 * supplies default CSS fonts, so let template TextBlocks opt into inheritance
 * only where the author has supplied neither a font property nor a Style.
 * An explicit Style retains its own font setters and explicit properties win.
 */
export declare const inheritBreadcrumbTextFonts: (nodes: VNode[]) => VNode[];
