import { type Component } from 'vue';
export declare const animatedIconVisualSourceNames: readonly ["AnimatedAcceptVisualSource", "AnimatedBackVisualSource", "AnimatedChevronDownSmallVisualSource", "AnimatedChevronRightDownSmallVisualSource", "AnimatedChevronUpDownSmallVisualSource", "AnimatedFindVisualSource", "AnimatedGlobalNavigationButtonVisualSource", "AnimatedSettingsVisualSource"];
export type AnimatedIconVisualSourceName = typeof animatedIconVisualSourceNames[number];
export interface AnimatedIconVisualSource {
    name: AnimatedIconVisualSourceName;
    duration: number;
    size: {
        width: number;
        height: number;
    };
    markers: Readonly<Record<string, number>>;
    Foreground?: string;
    render(progress: number, foreground?: string): string;
    FrameCount(): number;
    Framerate(): number;
    FrameToProgress(frame: number): number;
    SetColorProperty(propertyName: string, value: string): void;
}
export declare function createAnimatedIconSource(name: string): AnimatedIconVisualSource | undefined;
export declare const getAnimatedIconVisualSource: typeof createAnimatedIconSource;
export declare const animatedIconVisualSourceComponents: Record<string, Component>;
