type __VLS_Props = {
    Margin?: string | number;
    CornerRadius?: string | number;
    TargetBorderThickness?: string | number;
    PrimaryThickness?: string | number;
    SecondaryThickness?: string | number;
};
declare const __VLS_export: import("vue").DefineComponent<__VLS_Props, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<__VLS_Props> & Readonly<{}>, {
    Margin: string | number;
    CornerRadius: string | number;
    TargetBorderThickness: string | number;
    PrimaryThickness: string | number;
    SecondaryThickness: string | number;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, false, {}, any>;
declare const _default: typeof __VLS_export;
export default _default;
