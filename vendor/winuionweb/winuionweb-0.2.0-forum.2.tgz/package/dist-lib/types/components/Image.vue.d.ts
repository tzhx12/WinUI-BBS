import { type PropType } from 'vue';
import { type ImageEventArgs, type ImageSourceModel } from './imageSource';
import { ImageSourceProperty } from './imageSource';
export { ImageSourceProperty };
declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    Source: {
        type: PropType<unknown>;
        default: unknown;
    };
    Stretch: {
        type: StringConstructor;
        default: string;
    };
    NineGrid: {
        type: (NumberConstructor | StringConstructor | ObjectConstructor)[];
        default: string;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    Opacity: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
    IsHitTestVisible: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
}>, {
    Element: HTMLElement | null;
    Source: ImageSourceModel;
    Stretch: string;
    NineGrid: unknown;
    ActualWidth: number;
    ActualHeight: number;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    ImageOpened: (sender: unknown, args: ImageEventArgs) => any;
    ImageFailed: (sender: unknown, args: ImageEventArgs) => any;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    Source: {
        type: PropType<unknown>;
        default: unknown;
    };
    Stretch: {
        type: StringConstructor;
        default: string;
    };
    NineGrid: {
        type: (NumberConstructor | StringConstructor | ObjectConstructor)[];
        default: string;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    Opacity: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
    IsHitTestVisible: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
}>> & Readonly<{
    onImageOpened?: ((sender: unknown, args: ImageEventArgs) => any) | undefined;
    onImageFailed?: ((sender: unknown, args: ImageEventArgs) => any) | undefined;
}>, {
    Stretch: string;
    Width: string | number;
    Height: string | number;
    MinWidth: string | number;
    MaxWidth: string | number;
    MinHeight: string | number;
    MaxHeight: string | number;
    Margin: string | number;
    HorizontalAlignment: string;
    VerticalAlignment: string;
    Opacity: string | number;
    Source: unknown;
    Visibility: string;
    IsHitTestVisible: string | boolean;
    NineGrid: string | number | Record<string, any>;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
