import { type Component } from 'vue';
declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    Content: {
        type: (NumberConstructor | StringConstructor | ObjectConstructor)[];
        default: null;
    };
    ContentTransitions: {
        type: (StringConstructor | ArrayConstructor | ObjectConstructor)[];
        default: null;
    };
    IsNavigationStackEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    Background: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
    Opacity: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
}>, {
    Content: unknown;
    readonly CanGoBack: boolean;
    readonly CanGoForward: boolean;
    readonly BackStack: {
        SourcePageType: Component;
        Parameter: unknown;
        NavigationTransitionInfo: unknown;
    }[];
    readonly ForwardStack: {
        SourcePageType: Component;
        Parameter: unknown;
        NavigationTransitionInfo: unknown;
    }[];
    readonly BackStackDepth: number;
    readonly CurrentSourcePageType: Component | null;
    IsNavigationStackEnabled: boolean;
    Navigate: (sourcePageType: Component, parameter?: unknown, transitionInfo?: unknown) => boolean;
    NavigateToType: (sourcePageType: Component, parameter?: unknown, options?: {
        TransitionInfoOverride?: unknown;
        IsNavigationStackEnabled?: boolean;
    }) => boolean;
    GoBack: (transitionInfo?: unknown) => boolean;
    GoForward: () => boolean;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    Navigating: (...args: any[]) => void;
    Navigated: (...args: any[]) => void;
    NavigationFailed: (...args: any[]) => void;
    NavigationStopped: (...args: any[]) => void;
    "update:Content": (...args: any[]) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    Content: {
        type: (NumberConstructor | StringConstructor | ObjectConstructor)[];
        default: null;
    };
    ContentTransitions: {
        type: (StringConstructor | ArrayConstructor | ObjectConstructor)[];
        default: null;
    };
    IsNavigationStackEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    Background: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
    Opacity: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
}>> & Readonly<{
    onNavigating?: ((...args: any[]) => any) | undefined;
    onNavigated?: ((...args: any[]) => any) | undefined;
    onNavigationFailed?: ((...args: any[]) => any) | undefined;
    onNavigationStopped?: ((...args: any[]) => any) | undefined;
    "onUpdate:Content"?: ((...args: any[]) => any) | undefined;
}>, {
    Width: string | number;
    Height: string | number;
    MinWidth: string | number;
    MaxWidth: string | number;
    MinHeight: string | number;
    MaxHeight: string | number;
    Margin: string | number;
    HorizontalAlignment: string;
    VerticalAlignment: string;
    Opacity: string | number;
    Background: string | Record<string, any>;
    Visibility: string;
    Content: string | number | Record<string, any>;
    ContentTransitions: string | unknown[] | Record<string, any>;
    IsNavigationStackEnabled: string | boolean;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
