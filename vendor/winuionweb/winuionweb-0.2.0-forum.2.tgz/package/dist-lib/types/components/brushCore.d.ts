export interface AcrylicBrushValue {
    readonly __xamlBrush: 'AcrylicBrush';
    TintColor: string;
    TintOpacity: number;
    TintLuminosityOpacity: number | null;
    TintTransitionDuration: number;
    AlwaysUseFallback: boolean;
    FallbackColor: string;
    Opacity: number;
}
export interface SolidColorBrushValue {
    readonly __xamlBrush: 'SolidColorBrush';
    Color: string;
    Opacity: number;
}
export type XamlBrushValue = AcrylicBrushValue | SolidColorBrushValue;
export declare const xamlBrushResourceKey: unique symbol;
export declare const xamlThemeKey: unique symbol;
export declare const colorString: (value: unknown) => string;
export declare const colorChannels: (value: unknown) => {
    r: number;
    g: number;
    b: number;
    a: number;
};
export declare const cssColor: (value: unknown) => string;
export declare const clampOpacity: (value: unknown, fallback?: number) => number;
export declare const createSolidColorBrush: (color?: unknown, opacity?: unknown) => SolidColorBrushValue;
export declare const createAcrylicBrush: (values?: Partial<Omit<AcrylicBrushValue, "__xamlBrush">>) => AcrylicBrushValue;
export declare const isAcrylicBrush: (value: unknown) => value is AcrylicBrushValue;
export declare const isSolidColorBrush: (value: unknown) => value is SolidColorBrushValue;
export declare const acrylicColors: (brush: AcrylicBrushValue) => {
    tint: string;
    luminosity: string;
    opaque: boolean;
};
