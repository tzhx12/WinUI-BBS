declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    ItemsSource: {
        type: (StringConstructor | ArrayConstructor | ObjectConstructor)[];
        default: null;
    };
    ItemTemplate: {
        type: null;
        default: undefined;
    };
    ItemTemplateSelector: {
        type: null;
        default: undefined;
    };
    ItemsPanel: {
        type: null;
        default: undefined;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsTabStop: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Padding: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Background: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    BorderBrush: {
        type: StringConstructor;
        default: string;
    };
    BorderThickness: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
}>, {
    Element: HTMLElement | null;
    Name: {};
    Items: unknown[];
    ItemsSource: unknown;
    ItemTemplate: unknown;
    ItemTemplateSelector: unknown;
    ItemsPanel: unknown;
    IsEnabled: unknown;
    IsTabStop: unknown;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    ItemsSource: {
        type: (StringConstructor | ArrayConstructor | ObjectConstructor)[];
        default: null;
    };
    ItemTemplate: {
        type: null;
        default: undefined;
    };
    ItemTemplateSelector: {
        type: null;
        default: undefined;
    };
    ItemsPanel: {
        type: null;
        default: undefined;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsTabStop: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Padding: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Background: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    BorderBrush: {
        type: StringConstructor;
        default: string;
    };
    BorderThickness: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
}>> & Readonly<{}>, {
    Width: string | number;
    Height: string | number;
    MinWidth: string | number;
    MaxWidth: string | number;
    MinHeight: string | number;
    MaxHeight: string | number;
    Margin: string | number;
    Padding: string | number;
    HorizontalAlignment: string;
    VerticalAlignment: string;
    IsEnabled: string | boolean;
    Background: string | Record<string, any>;
    BorderBrush: string;
    BorderThickness: string | number;
    IsTabStop: string | boolean;
    ItemTemplate: any;
    Visibility: string;
    ItemsSource: string | unknown[] | Record<string, any>;
    ItemTemplateSelector: any;
    ItemsPanel: any;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
