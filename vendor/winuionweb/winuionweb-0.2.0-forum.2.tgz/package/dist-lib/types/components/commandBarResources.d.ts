export declare const commandBarResources: Readonly<Record<string, string | number>>;
