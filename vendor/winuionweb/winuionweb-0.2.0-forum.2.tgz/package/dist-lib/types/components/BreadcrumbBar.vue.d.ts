declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    ItemsSource: {
        type: (StringConstructor | ArrayConstructor | ObjectConstructor)[];
        default: null;
    };
    ItemTemplate: {
        type: (StringConstructor | ObjectConstructor | FunctionConstructor)[];
        default: undefined;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    FlowDirection: {
        type: StringConstructor;
        default: string;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
}>, {
    Element: import("vue").Ref<HTMLElement | null, HTMLElement | null>;
    ItemsSource: import("vue").WritableComputedRef<unknown, unknown>;
    ItemTemplate: import("vue").WritableComputedRef<unknown, unknown>;
    IsEnabled: import("vue").WritableComputedRef<unknown, unknown>;
    FlowDirection: import("vue").WritableComputedRef<unknown, unknown>;
    Focus: () => boolean;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    ItemClicked: (...args: any[]) => void;
    "update:ItemsSource": (...args: any[]) => void;
    "update:IsEnabled": (...args: any[]) => void;
    "update:FlowDirection": (...args: any[]) => void;
    "update:ItemTemplate": (...args: any[]) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    ItemsSource: {
        type: (StringConstructor | ArrayConstructor | ObjectConstructor)[];
        default: null;
    };
    ItemTemplate: {
        type: (StringConstructor | ObjectConstructor | FunctionConstructor)[];
        default: undefined;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    FlowDirection: {
        type: StringConstructor;
        default: string;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
}>> & Readonly<{
    onItemClicked?: ((...args: any[]) => any) | undefined;
    "onUpdate:ItemsSource"?: ((...args: any[]) => any) | undefined;
    "onUpdate:IsEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:FlowDirection"?: ((...args: any[]) => any) | undefined;
    "onUpdate:ItemTemplate"?: ((...args: any[]) => any) | undefined;
}>, {
    Width: string | number;
    Height: string | number;
    MinWidth: string | number;
    MaxWidth: string | number;
    MinHeight: string | number;
    MaxHeight: string | number;
    Margin: string | number;
    HorizontalAlignment: string;
    VerticalAlignment: string;
    IsEnabled: string | boolean;
    ItemTemplate: string | Function | Record<string, any>;
    Visibility: string;
    FlowDirection: string;
    ItemsSource: string | unknown[] | Record<string, any>;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
