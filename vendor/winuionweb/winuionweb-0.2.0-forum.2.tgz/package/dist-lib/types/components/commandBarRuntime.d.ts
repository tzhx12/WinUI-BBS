import { type PropType, type VNode } from 'vue';
import { type CommandBarContext } from './appBarRuntime';
export declare const commandBarProperty: (owner: string, property: string) => import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const commandChildren: (node: VNode) => VNode[];
export declare const flattenCommandNodes: (nodes: VNode[]) => VNode[];
export declare const commandKind: (node: VNode) => string;
export declare const isCommandSeparator: (node: VNode) => boolean;
export declare const commandHasIcon: (node: VNode) => boolean;
export declare const isCommandToggle: (node: VNode) => boolean;
export declare const isAppBarCommand: (node: VNode) => boolean;
export declare const commandCollection: (collection: VNode[]) => VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>[];
export declare const CommandPortal: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    node: {
        type: PropType<VNode>;
        required: true;
    };
    host: {
        type: PropType<HTMLElement>;
        required: true;
    };
    overflow: {
        type: BooleanConstructor;
        required: true;
    };
    context: {
        type: PropType<CommandBarContext>;
        required: true;
    };
}>, () => VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    node: {
        type: PropType<VNode>;
        required: true;
    };
    host: {
        type: PropType<HTMLElement>;
        required: true;
    };
    overflow: {
        type: BooleanConstructor;
        required: true;
    };
    context: {
        type: PropType<CommandBarContext>;
        required: true;
    };
}>> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const CommandOutlet: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    nodes: {
        type: PropType<VNode[]>;
        required: true;
    };
    context: {
        type: PropType<CommandBarContext>;
        required: true;
    };
}>, () => VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    nodes: {
        type: PropType<VNode[]>;
        required: true;
    };
    context: {
        type: PropType<CommandBarContext>;
        required: true;
    };
}>> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
