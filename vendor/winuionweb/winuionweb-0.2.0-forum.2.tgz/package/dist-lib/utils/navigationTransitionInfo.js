//#region src/utils/navigationTransitionInfo.js
var e = new Set([
	"FromRight",
	"FromLeft",
	"FromBottom"
]), t = () => ({ Type: "EntranceNavigationTransitionInfo" }), n = (t = "FromBottom") => ({
	Type: "SlideNavigationTransitionInfo",
	Effect: e.has(t) ? t : "FromBottom"
});
//#endregion
export { t as createEntranceNavigationTransitionInfo, n as createSlideNavigationTransitionInfo };

//# sourceMappingURL=navigationTransitionInfo.js.map