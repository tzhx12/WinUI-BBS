import { resolveXamlValue as e } from "./xamlRuntime.js";
import t from "../_virtual/_plugin-vue_export-helper.js";
/* empty css                                         */
import { Transition as n, computed as r, createBlock as i, createCommentVNode as a, createElementBlock as o, createTextVNode as s, getCurrentInstance as c, inject as l, onBeforeUnmount as u, openBlock as d, renderSlot as f, toDisplayString as p, withCtx as m } from "vue";
//#region src/components/Case.vue
var h = {
	__name: "Case",
	props: {
		Content: {
			type: [
				String,
				Number,
				Object,
				Array
			],
			default: null
		},
		Value: {
			type: [
				String,
				Number,
				Boolean,
				Object
			],
			default: null
		},
		IsDefault: {
			type: Boolean,
			default: !1
		}
	},
	setup(t, { expose: n }) {
		let i = t, a = l("win-switch-presenter", null), o = c(), s = r(() => e(i.Content, o)), d = a?.registerCase(() => ({
			Value: i.Value,
			IsDefault: i.IsDefault,
			Content: i.Content
		})), f = r(() => a ? a.isCaseActive(i.Value, i.IsDefault) : i.IsDefault), p = {
			enter: 400,
			leave: 200
		};
		n({
			Content: r(() => i.Content),
			IsDefault: r(() => i.IsDefault),
			Value: r(() => i.Value)
		}), u(() => d?.());
		let m = {
			props: i,
			presenter: a,
			instance: o,
			resolvedContent: s,
			unregister: d,
			isActive: f,
			transitionDuration: p,
			computed: r,
			getCurrentInstance: c,
			inject: l,
			onBeforeUnmount: u,
			get resolveXamlValue() {
				return e;
			}
		};
		return Object.defineProperty(m, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), m;
	}
}, g = {
	key: 0,
	class: "win-case-content"
};
function _(e, t, r, c, l, u) {
	return d(), i(n, {
		name: "win-switch-presenter-case",
		duration: c.transitionDuration
	}, {
		default: m(() => [c.isActive ? (d(), o("div", g, [f(e.$slots, "default", {}, () => [s(p(c.resolvedContent), 1)])])) : a("", !0)]),
		_: 3
	});
}
var v = /*#__PURE__*/ t(h, [["render", _], ["__file", "Case.vue"]]);
//#endregion
export { v as default };

//# sourceMappingURL=Case.vue.js.map