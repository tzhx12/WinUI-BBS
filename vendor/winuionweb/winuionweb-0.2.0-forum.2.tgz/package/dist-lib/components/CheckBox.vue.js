import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./CheckBox.vue_vue_type_script_setup_true_lang.js";
/* empty css                                             */
import { createElementBlock as n, createElementVNode as r, createTextVNode as i, createVNode as a, mergeProps as o, openBlock as s, renderSlot as c, resolveComponent as l, toDisplayString as u, withCtx as d } from "vue";
//#region src/components/CheckBox.vue
var f = [
	"tabindex",
	"aria-checked",
	"aria-disabled"
], p = {
	class: "checkbox-box",
	"aria-hidden": "true"
}, m = { class: "checkbox-content" };
function h(e, t, h, g, _, v) {
	let y = l("animatedvisuals:AnimatedAcceptVisualSource"), b = l("FontIconSource");
	return s(), n("div", o({
		ref: "checkboxElement",
		class: ["win-checkbox", g.stateClasses],
		style: g.checkboxStyle,
		tabindex: g.isTabStop ? g.isDisabled ? -1 : 0 : -1,
		role: "checkbox",
		"aria-checked": g.ariaChecked,
		"aria-disabled": g.isDisabled
	}, g.forwardedAttrs, {
		onClick: g.toggle,
		onPointerenter: t[0] ||= (...e) => g.iconInput.PointerEntered && g.iconInput.PointerEntered(...e),
		onPointerleave: t[1] ||= (...e) => g.iconInput.PointerExited && g.iconInput.PointerExited(...e),
		onPointerdown: t[2] ||= (...e) => g.iconInput.PointerPressed && g.iconInput.PointerPressed(...e),
		onPointerup: t[3] ||= (...e) => g.iconInput.PointerReleased && g.iconInput.PointerReleased(...e),
		onPointercancel: t[4] ||= (...e) => g.iconInput.PointerExited && g.iconInput.PointerExited(...e),
		onLostpointercapture: t[5] ||= (...e) => g.iconInput.PointerExited && g.iconInput.PointerExited(...e),
		onKeydown: g.onKeyDown,
		onKeyup: g.onKeyUp,
		onFocusout: g.onLostFocus
	}), [r("span", p, [a(g.AnimatedIcon, {
		class: "checkbox-glyph",
		Width: "18",
		Height: "18",
		HorizontalAlignment: "Center",
		VerticalAlignment: "Center",
		Margin: "{x:Bind CheckGlyphMargin, Mode=OneWay}"
	}, {
		default: d(() => [a(g.AnimatedIcon.Source, null, {
			default: d(() => [a(y)]),
			_: 1
		}), a(g.AnimatedIcon.FallbackIconSource, null, {
			default: d(() => [a(b, {
				Glyph: "",
				FontSize: "12"
			})]),
			_: 1
		})]),
		_: 1
	})]), r("span", m, [c(e.$slots, "default", {}, () => [i(u(g.resolvedContent), 1)])])], 16, f);
}
var g = /*#__PURE__*/ e(t, [["render", h], ["__file", "CheckBox.vue"]]);
//#endregion
export { g as default };

//# sourceMappingURL=CheckBox.vue.js.map