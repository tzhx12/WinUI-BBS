import { acrylicColors as e, clampOpacity as t, colorChannels as n, colorString as r, createAcrylicBrush as i, cssColor as a, isAcrylicBrush as o, isSolidColorBrush as s, xamlBrushResourceKey as c, xamlThemeKey as l } from "./brushCore.js";
import { acrylicResource as u, acrylicResourceAliases as d, isAcrylicResource as f } from "./acrylicResources.js";
import { uiSettings as p } from "./uiSettings.js";
import { acrylicNoise as m } from "./acrylicNoise.js";
import { resolveXamlValue as h } from "./xamlRuntime.js";
import { computed as g, defineComponent as _, getCurrentInstance as v, inject as y, isRef as b, onBeforeUnmount as x, onMounted as S, ref as C, watch as w } from "vue";
//#region src/components/AcrylicBrush.ts
var T = [
	"TintColor",
	"TintOpacity",
	"TintLuminosityOpacity",
	"TintTransitionDuration",
	"AlwaysUseFallback",
	"FallbackColor",
	"Opacity"
], E = (e) => {
	if (typeof e == "number") return Math.max(0, e);
	let t = String(e ?? "").split(":").map(Number), n = Number(e);
	return t.length === 3 ? Math.max(0, ((t[0] * 60 + t[1]) * 60 + t[2]) * 1e3) : Math.max(0, Number.isFinite(n) ? n : 500);
}, D = (e, n) => {
	let a = i(), o = T.map((n) => w(() => e(n), (e) => {
		e === void 0 || e === "" || (n === "TintColor" || n === "FallbackColor" ? a[n] = r(e) : n === "TintLuminosityOpacity" ? a[n] = e === null ? null : t(e) : n === "TintTransitionDuration" ? a[n] = E(e) : n === "AlwaysUseFallback" ? a[n] = e === !0 || e === "True" : a[n] = t(e));
	}, { immediate: !0 }));
	return n?.Dispose(() => o.forEach((e) => e())), a;
}, O = _({
	name: "AcrylicBrush",
	__xamlBrush: !0,
	__createXamlResource: D,
	inheritAttrs: !1,
	props: {
		TintColor: {
			type: String,
			default: "#CCFFFFFF"
		},
		TintOpacity: {
			type: [String, Number],
			default: 1
		},
		TintLuminosityOpacity: {
			type: [String, Number],
			default: null
		},
		TintTransitionDuration: {
			type: [String, Number],
			default: 500
		},
		AlwaysUseFallback: {
			type: [String, Boolean],
			default: !1
		},
		FallbackColor: {
			type: String,
			default: "#00FFFFFF"
		},
		Opacity: {
			type: [String, Number],
			default: 1
		}
	},
	setup(e, { expose: t }) {
		let n = v();
		return t(D((t) => h(e[t], n))), () => null;
	}
}), k = C("light"), A = C(!1), j = C(!1), M = C(!1), N = 0, P, F = () => {
	if (++N !== 1 || typeof window > "u") return;
	let e = [
		"(prefers-color-scheme: dark)",
		"(prefers-reduced-transparency: reduce)",
		"(forced-colors: active)",
		"(prefers-reduced-motion: reduce)"
	].map((e) => window.matchMedia(e)), t = () => {
		let t = document.documentElement, n = t.dataset.theme;
		k.value = n === "dark" || n === "light" ? n : t.classList.contains("theme-dark") || t.classList.contains("dark") ? "dark" : t.classList.contains("theme-light") || t.classList.contains("light") ? "light" : e[0].matches ? "dark" : "light", A.value = e[1].matches, j.value = e[2].matches, M.value = e[3].matches;
	}, n = new MutationObserver(t);
	n.observe(document.documentElement, {
		attributes: !0,
		attributeFilter: ["class", "data-theme"]
	}), e.forEach((e) => e.addEventListener("change", t)), t(), P = () => {
		n.disconnect(), e.forEach((e) => e.removeEventListener("change", t));
	};
}, I = () => {
	--N === 0 && (P?.(), P = void 0);
}, L = (e) => {
	let t = e?.props.RequestedTheme;
	if (t === "Dark" || t === "dark") return "dark";
	if (t === "Light" || t === "light") return "light";
	let n = e?.provides?.[l], r = b(n) ? n.value : n;
	return r === "dark" || r === "Dark" ? "dark" : r === "light" || r === "Light" ? "light" : k.value;
}, R = (e, t) => {
	let n = t?.provides?.[c], r = b(n) ? n.value : n, i = r?.[e] ?? r?.[d[e] ?? e];
	if (i && typeof i == "object" && "__xamlThemeResource" in i) {
		let e = i;
		return e[j.value || p.IsHighContrast ? "HighContrast" : L(t) === "light" ? "Light" : "Dark"] ?? e.Default;
	}
	let a;
	if (e.startsWith("AccentAcrylic") && typeof document < "u") {
		let e = getComputedStyle(document.documentElement);
		a = {
			SystemAccentColorDark1: e.getPropertyValue("--SystemAccentColorDark1").trim() || "#005A9E",
			SystemAccentColorDark2: e.getPropertyValue("--SystemAccentColorDark2").trim() || "#004578",
			SystemAccentColorLight3: e.getPropertyValue("--SystemAccentColorLight3").trim() || "#A6D8FF"
		};
	}
	return i ?? u(e, L(t), a, j.value || p.IsHighContrast);
}, z = (r) => {
	if (s(r)) return { background: r.Opacity === 1 ? a(r.Color) : `color-mix(in srgb, ${a(r.Color)} ${t(r.Opacity) * 100}%, transparent)` };
	if (r && typeof r == "object" && "__radialGradient" in r) return { background: "transparent" };
	if (!o(r)) return { background: r == null ? void 0 : String(r) };
	let i = r.AlwaysUseFallback || !p.AdvancedEffectsEnabled || !p.AreEffectsFast || p.EnergySaverStatus || A.value || j.value || p.IsHighContrast || typeof CSS < "u" && !CSS.supports("backdrop-filter", "blur(1px)") && !CSS.supports("-webkit-backdrop-filter", "blur(1px)"), c = e(r), l = n(r.FallbackColor);
	return {
		background: "transparent",
		"--acrylic-tint": c.tint,
		"--acrylic-luminosity": c.luminosity,
		"--acrylic-opaque-fallback": `rgb(${l.r}, ${l.g}, ${l.b})`,
		"--acrylic-brush-opacity": String(t(r.Opacity)),
		"--acrylic-opaque": c.opaque ? "1" : "0",
		"--acrylic-fallback": a(r.FallbackColor),
		"--acrylic-noise": `url("${m}")`,
		"--acrylic-noise-opacity": i ? "0" : ".02",
		"--acrylic-fallback-opacity": i ? "1" : "0",
		"--acrylic-tint-duration": `${M.value ? 1 : E(r.TintTransitionDuration)}ms`,
		"--acrylic-fallback-duration": `${M.value ? 1 : 167}ms`
	};
}, B = (e, t = null) => {
	let n = typeof e == "string" ? e.trim().match(/^\{(?:ThemeResource|StaticResource)\s+([^}]+)\}$|^var\(--([\w]+)\)$/)?.slice(1).find(Boolean) : void 0;
	return z(n && f(n) ? R(n, t) : h(e, t));
}, V = (e = {}) => {
	let t = u("AcrylicBackgroundFillColorDefaultBrush", e.theme === "Dark" ? "dark" : e.theme === "Light" ? "light" : L(null), void 0, j.value || p.IsHighContrast);
	return z(o(t) ? i({
		TintColor: t.TintColor,
		TintOpacity: t.TintOpacity,
		TintLuminosityOpacity: t.TintLuminosityOpacity,
		TintTransitionDuration: t.TintTransitionDuration,
		AlwaysUseFallback: t.AlwaysUseFallback,
		FallbackColor: e.fallbackColor === void 0 ? t.FallbackColor : r(e.fallbackColor),
		Opacity: t.Opacity
	}) : t);
}, H = (e, t = v(), n = B) => {
	S(F), x(I);
	let r = y(l, null) ?? y("winuiTheme", null);
	return r && t && !t.provides[l] && (t.provides[l] = r), g(() => n(typeof e == "function" ? e() : e, t));
};
//#endregion
export { V as createAcrylicMaterialStyle, D as createAcrylicResource, O as default, R as resolveAcrylicResource, B as resolveBrushStyle, z as styleFromResolvedBrush, H as useAcrylicBrushStyle };

//# sourceMappingURL=AcrylicBrush.js.map