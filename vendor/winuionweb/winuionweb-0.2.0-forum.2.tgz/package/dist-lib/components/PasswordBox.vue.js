import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./PasswordBox.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                */
import { Fragment as n, createBlock as r, createCommentVNode as i, createElementBlock as a, createVNode as o, mergeProps as s, openBlock as c, withCtx as l } from "vue";
//#region src/components/PasswordBox.vue
function u(e, t, u, d, f, p) {
	return c(), a(n, null, [
		o(d.TextBox, s({
			class: "win-password-box",
			Header: "{x:Bind PasswordTemplate.Header, Mode=OneWay}",
			HeaderTemplate: "{x:Bind PasswordTemplate.HeaderTemplate, Mode=OneWay}",
			Description: "{x:Bind PasswordTemplate.Description, Mode=OneWay}",
			IsEnabled: "{x:Bind PasswordTemplate.IsEnabled, Mode=OneWay}",
			Width: "{x:Bind PasswordTemplate.Width, Mode=OneWay}",
			Height: "{x:Bind PasswordTemplate.Height, Mode=OneWay}",
			MinWidth: "{x:Bind PasswordTemplate.MinWidth, Mode=OneWay}",
			MaxWidth: "{x:Bind PasswordTemplate.MaxWidth, Mode=OneWay}",
			Margin: "{x:Bind PasswordTemplate.Margin, Mode=OneWay}",
			HorizontalAlignment: "{x:Bind PasswordTemplate.HorizontalAlignment, Mode=OneWay}",
			VerticalAlignment: "{x:Bind PasswordTemplate.VerticalAlignment, Mode=OneWay}",
			Padding: "{x:Bind PasswordTemplate.Padding, Mode=OneWay}",
			CornerRadius: "{x:Bind PasswordTemplate.CornerRadius, Mode=OneWay}",
			BorderBrush: "{x:Bind PasswordTemplate.BorderBrush, Mode=OneWay}",
			BorderThickness: "{x:Bind PasswordTemplate.BorderThickness, Mode=OneWay}",
			Background: "{x:Bind PasswordTemplate.Background, Mode=OneWay}",
			FontFamily: "{x:Bind PasswordTemplate.FontFamily, Mode=OneWay}",
			FontSize: "{x:Bind PasswordTemplate.FontSize, Mode=OneWay}",
			FontWeight: "{x:Bind PasswordTemplate.FontWeight, Mode=OneWay}",
			SelectionHighlightColor: "{x:Bind PasswordTemplate.SelectionHighlightColor, Mode=OneWay}"
		}, d.surfaceAttrs), {
			default: l(() => [
				d.headerNodes.length ? (c(), r(d.TextBox.Header, { key: 0 }, {
					default: l(() => [o(d.HeaderOutlet)]),
					_: 1
				})) : i("", !0),
				d.headerTemplateNodes.length ? (c(), r(d.TextBox.HeaderTemplate, { key: 1 }, {
					default: l(() => [o(d.HeaderTemplateOutlet)]),
					_: 1
				})) : i("", !0),
				d.descriptionNodes.length ? (c(), r(d.TextBox.Description, { key: 2 }, {
					default: l(() => [o(d.DescriptionOutlet)]),
					_: 1
				})) : i("", !0)
			]),
			_: 1
		}, 16),
		o(d.ContextMenu),
		o(d.CustomFlyouts)
	], 64);
}
var d = /*#__PURE__*/ e(t, [["render", u], ["__file", "PasswordBox.vue"]]);
//#endregion
export { d as default };

//# sourceMappingURL=PasswordBox.vue.js.map