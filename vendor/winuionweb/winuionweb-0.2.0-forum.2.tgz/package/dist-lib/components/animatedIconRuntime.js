//#region src/components/animatedIconRuntime.ts
var e = "winui-animated-icon-state-changed", t = /* @__PURE__ */ new WeakMap(), n = /* @__PURE__ */ new WeakMap(), r = (e) => {
	if (!e || typeof e != "object") return null;
	if (typeof Element < "u" && e instanceof Element) return e;
	let t = e;
	for (let n of [
		"$el",
		"Element",
		"element",
		"RootElement",
		"rootElement",
		"value"
	]) {
		let r;
		try {
			r = t[n];
		} catch {
			continue;
		}
		if (!(!r || r === e)) {
			if (typeof Element < "u" && r instanceof Element) return r;
			if (typeof r == "object" && "value" in r) {
				let e = r.value;
				if (typeof Element < "u" && e instanceof Element) return e;
			}
		}
	}
	return null;
}, i = (e) => {
	if (!e || typeof e != "object") return "";
	let n = r(e), i = t.get(n ?? e);
	return i === void 0 ? n ? n.getAttribute("AnimatedIcon.State") ?? "" : t.get(e) ?? "" : i;
}, a = (a, o) => {
	if (!a || typeof a != "object") return;
	let s = r(a), c = s ?? a, l = String(o ?? "");
	if (i(c) === l) return;
	t.set(c, l);
	let u = {
		Target: c,
		State: l
	};
	if (n.get(c)?.forEach((e) => e(u)), s) {
		let t = s.ownerDocument.defaultView?.CustomEvent;
		t && s.dispatchEvent(new t(e, {
			bubbles: !0,
			detail: u
		}));
	}
}, o = (e) => {
	let t = r(e)?.parentElement ?? null;
	for (; t;) {
		if (i(t)) return t;
		t = t.parentElement;
	}
	return null;
}, s = (t, i) => {
	if (!t || typeof t != "object") return () => void 0;
	let a = r(t);
	if (a) {
		let t = (e) => {
			let t = e.detail;
			(t?.Target === a || r(t?.Target)?.contains(a)) && i(t);
		};
		return a.ownerDocument.addEventListener(e, t, !0), () => a.ownerDocument.removeEventListener(e, t, !0);
	}
	let o = n.get(t);
	return o || (o = /* @__PURE__ */ new Set(), n.set(t, o)), o.add(i), () => o?.delete(i);
}, c = Object.freeze({
	SetState: a,
	GetState: i
});
//#endregion
export { c as AnimatedIcon, i as GetState, a as SetState, o as findAnimatedIconStateAncestor, s as subscribeAnimatedIconState };

//# sourceMappingURL=animatedIconRuntime.js.map