import { cssLength as e } from "./layout.js";
import { resolveXamlValue as t, updateXamlBinding as n, xamlNameScopeKey as r, xamlScopeKey as ee } from "./xamlRuntime.js";
import { frameworkLayoutStyle as te } from "./frameworkLayout.js";
import ne from "./Grid.vue.js";
import re from "./SymbolIcon.vue.js";
import ie from "./Viewbox.vue.js";
import { useI18n as ae } from "./i18n/index.js";
import oe from "./TextBlock.vue.js";
import se from "./FontIcon.vue.js";
import ce from "./ContentPresenter.vue.js";
import le from "./Image.vue.js";
import { iconSourceKind as i } from "./IconSource.js";
import { Fragment as ue, computed as a, defineComponent as o, getCurrentInstance as de, h as s, isVNode as fe, nextTick as pe, onBeforeUnmount as me, onMounted as he, provide as c, ref as l, shallowReactive as ge, shallowRef as u, useAttrs as _e, useSlots as ve, watch as d } from "vue";
//#region src/components/InfoBadge.vue?vue&type=script&setup=true&lang.ts
var f = o({
	name: "InfoBadge.IconSource",
	__infoBadgeIconSourceProperty: !0,
	setup() {
		return () => null;
	}
}), p = /*@__PURE__*/ o({
	IconSource: f,
	inheritAttrs: !1,
	__name: "InfoBadge",
	props: {
		Value: {
			type: [Number, String],
			default: -1
		},
		IconSource: {
			type: [Object, String],
			default: null
		},
		Style: {
			type: [Object, String],
			default: ""
		},
		Background: {
			type: String,
			default: ""
		},
		Foreground: {
			type: String,
			default: ""
		},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		IsTabStop: {
			type: [Boolean, String],
			default: !1
		},
		Visibility: {
			type: String,
			default: "Visible"
		},
		Opacity: {
			type: [Number, String],
			default: 1
		},
		RequestedTheme: {
			type: String,
			default: "Default"
		},
		Padding: {
			type: [String, Number],
			default: ""
		},
		CornerRadius: {
			type: [String, Number],
			default: ""
		},
		HorizontalAlignment: {
			type: String,
			default: "Stretch"
		},
		VerticalAlignment: {
			type: String,
			default: "Stretch"
		},
		Width: {
			type: [String, Number],
			default: ""
		},
		Height: {
			type: [String, Number],
			default: ""
		},
		MinWidth: {
			type: [String, Number],
			default: ""
		},
		MinHeight: {
			type: [String, Number],
			default: ""
		},
		MaxWidth: {
			type: [String, Number],
			default: ""
		},
		MaxHeight: {
			type: [String, Number],
			default: ""
		},
		Margin: {
			type: [String, Number],
			default: ""
		}
	},
	emits: [
		"update:Value",
		"update:IconSource",
		"update:Style",
		"update:RequestedTheme"
	],
	setup(p, { expose: ye, emit: be }) {
		let m = p, h = be, g = _e(), xe = ve(), _ = de();
		c(r, ge({}));
		let { t: v } = ae(), y = l(null), b = l(0), x = l(), S = u(), C = u(), w = l(), T = (e) => t(e, _), E = a(() => T(m.Value)), D = a(() => T(m.Style)), O = a(() => T(m.IconSource)), k = a(() => String(T(m.RequestedTheme) ?? "Default"));
		d(E, () => {
			x.value = void 0;
		}), d(D, () => {
			S.value = void 0;
		}), d(O, () => {
			C.value = void 0;
		}), d(k, () => {
			w.value = void 0;
		});
		let A = a({
			get: () => w.value ?? k.value,
			set: (e) => {
				let t = ["Light", "Dark"].includes(e) ? e : "Default";
				w.value = t, n(m.RequestedTheme, t, _), h("update:RequestedTheme", t);
			}
		}), Se = a(() => ["Light", "Dark"].includes(A.value) ? `theme-${A.value.toLowerCase()}` : ""), j = (e) => {
			let t = Number(e), n = Number.isFinite(t) ? Math.trunc(t) : -1;
			if (n < -1 || n > 2147483647) throw RangeError("InfoBadge.Value must be an Int32 equal to or greater than -1.");
			return n;
		}, M = a(() => x.value ?? j(E.value)), N = a(() => {
			let e = S.value === void 0 ? D.value : S.value;
			return typeof e == "string" ? e.match(/^\{(?:StaticResource|ThemeResource)\s+([^}]+)\}$/)?.[1] ?? e.match(/^var\(--([^,)]+)\)$/)?.[1] ?? e : "";
		}), P = a(() => N.value.match(/^(Attention|Informational|Success|Caution|Critical)(Dot|Value|Icon)InfoBadgeStyle$/)), F = a(() => P.value?.[1] ?? ""), I = a(() => P.value?.[2] === "Icon" ? {
			Attention: {
				Kind: "FontIcon",
				Glyph: ""
			},
			Informational: {
				Kind: "FontIcon",
				Glyph: ""
			},
			Success: {
				Kind: "SymbolIcon",
				Symbol: "Accept"
			},
			Caution: {
				Kind: "SymbolIcon",
				Symbol: "Important"
			},
			Critical: {
				Kind: "SymbolIcon",
				Symbol: "Cancel"
			}
		}[F.value] ?? null : null), L = (e) => Array.isArray(e.children) ? e.children : e.children?.default?.() ?? [], R = a(() => {
			let e = (t) => {
				for (let n of t) {
					if (n.type === ue) {
						let t = e(L(n));
						if (t) return t;
					}
					if (n.type?.__infoBadgeIconSourceProperty) return L(n).find((e) => i(e));
				}
			}, t = e(xe.default?.() ?? []);
			return t ? {
				Kind: i(t),
				...t.props
			} : null;
		}), z = a(() => {
			let e = Object.keys(_?.vnode.props ?? {}).some((e) => e.replace(/-/g, "").toLowerCase() === "iconsource"), t = C.value === void 0 ? e ? O.value : R.value ?? I.value : C.value;
			return !t || typeof t != "object" ? null : fe(t) ? {
				Kind: i(t),
				...t.props
			} : Object.fromEntries(Object.entries(t).map(([e, t]) => [e, T(t)]));
		}), B = a(() => String(z.value?.Kind ?? (z.value?.Glyph === void 0 ? z.value?.Symbol === void 0 ? z.value?.Data === void 0 ? z.value?.UriSource === void 0 ? "ImageIcon" : "BitmapIcon" : "PathIcon" : "SymbolIcon" : "FontIcon"))), V = a(() => M.value >= 0 ? "Value" : z.value ? B.value === "FontIcon" ? "FontIcon" : "Icon" : "Dot"), Ce = a(() => `win-infobadge-${V.value.toLowerCase()}`), H = a(() => V.value === "Value" ? "Visible" : "Collapsed"), we = a(() => ["Icon", "FontIcon"].includes(V.value) ? "Visible" : "Collapsed"), Te = a(() => H.value === "Visible" ? "4,0,4,2" : "0"), Ee = a(() => V.value === "FontIcon" ? "4,0,4,2" : V.value === "Icon" ? "4" : "0"), U = a(() => T(m.Padding) === "" ? P.value?.[2] === "Icon" && ["Attention", "Informational"].includes(F.value) ? "0,4,0,2" : "0" : T(m.Padding)), De = a(() => T(m.Background) || {
			Attention: "var(--SystemFillColorAttentionBrush)",
			Informational: "var(--SystemFillColorSolidNeutralBrush)",
			Success: "var(--SystemFillColorSuccessBrush)",
			Caution: "var(--SystemFillColorCautionBrush)",
			Critical: "var(--SystemFillColorCriticalBrush)"
		}[F.value] || "var(--InfoBadgeBackground, var(--AccentFillColorDefaultBrush))"), W = a(() => T(m.Foreground) || "var(--InfoBadgeForeground, var(--TextOnAccentFillColorPrimaryBrush))"), G = (e) => {
			let t = String(e ?? "0").split(",").map(Number);
			return t.length === 1 ? [
				t[0],
				t[0],
				t[0],
				t[0]
			] : t.length === 2 ? [
				t[0],
				t[1],
				t[0],
				t[1]
			] : t;
		}, K = (e, t) => {
			let n = T(e);
			if (n === "" || n === void 0 || n === "Auto") return t;
			let r = Number(n);
			return Number.isFinite(r) ? r : t;
		}, q = a(() => {
			let e = G(U.value), t = V.value === "Dot" ? 0 : V.value === "Value" ? 16 : K(z.value?.FontSize, 20) + (V.value === "FontIcon" ? 2 : 8);
			return K(m.Height, Math.max(K(m.MinHeight, 4), Math.min(K(m.MaxHeight, 16), t + (e[1] || 0) + (e[3] || 0))));
		}), J = a(() => {
			let e = G(U.value);
			return Math.max(0, q.value - (e[1] || 0) - (e[3] || 0) - (V.value === "FontIcon" ? 2 : 8));
		}), Y = a(() => J.value), X = a(() => ({
			InfoBadgeCornerRadius: T(m.CornerRadius) === "" ? (b.value || q.value) / 2 : T(m.CornerRadius),
			IconElement: z.value
		})), Oe = (e) => {
			let t = String(e ?? ""), n = t.match(/^(?:\\u|&#x|0x)([\da-f]+);?$/i);
			return n ? String.fromCodePoint(parseInt(n[1], 16)) : t;
		}, ke = o({
			name: "InfoBadgeIconElementPresenter",
			setup() {
				return () => {
					let e = z.value;
					if (!e) return null;
					let t = e.Foreground || W.value;
					return B.value === "FontIcon" ? s(se, {
						Glyph: Oe(e.Glyph),
						FontFamily: e.FontFamily || "var(--SymbolThemeFontFamily)",
						FontSize: e.FontSize ?? 20,
						Foreground: t
					}) : B.value === "SymbolIcon" ? s(re, {
						Symbol: e.Symbol,
						Foreground: t,
						FontSize: e.FontSize ?? 20
					}) : B.value === "PathIcon" ? s("svg", {
						viewBox: "0 0 20 20",
						width: 20,
						height: 20,
						"aria-hidden": "true",
						style: { fill: t }
					}, [s("path", { d: e.Data })]) : s(le, {
						Source: e.ImageSource ?? e.UriSource,
						Stretch: "Uniform",
						Width: e.Width ?? 20,
						Height: e.Height ?? 20
					});
				};
			}
		}), Ae = a(() => {
			let { class: e, style: t, ...n } = g;
			return {
				...n,
				tabindex: T(m.IsTabStop) === !0 ? 0 : void 0
			};
		}), je = a(() => {
			let t = te(m, _);
			return t.minWidth = e(Math.max(K(m.MinWidth, 4), q.value)), t.height = e(q.value), t.color = String(W.value), t.background = "", t.padding = "", t.borderRadius = "", [g.style, t];
		}), Me = a(() => String(T(g["AutomationProperties.Name"]) || (V.value === "Value" ? v("control.infobadge.value", { value: M.value }) : v(`control.infobadge.${V.value === "Dot" ? "dot" : "icon"}`)))), Ne = a({
			get: () => M.value,
			set: (e) => {
				let t = j(e);
				x.value = t, n(m.Value, t, _), h("update:Value", t);
			}
		}), Pe = a({
			get: () => S.value === void 0 ? D.value : S.value,
			set: (e) => {
				S.value = e, n(m.Style, e, _), h("update:Style", e);
			}
		}), Fe = a({
			get: () => z.value,
			set: (e) => {
				C.value = e, n(m.IconSource, e, _), h("update:IconSource", e);
			}
		});
		ye({
			Value: Ne,
			Style: Pe,
			IconSource: Fe,
			RequestedTheme: A,
			TemplateSettings: X,
			Element: y
		}), c(ee, {
			RequestedTheme: A,
			BadgeValue: M,
			BadgeBackground: De,
			BadgeForeground: W,
			BadgePadding: U,
			TemplateSettings: X,
			ValueVisibility: H,
			IconVisibility: we,
			ValueMargin: Te,
			IconMargin: Ee,
			IconViewportWidth: Y,
			IconViewportHeight: J
		});
		let Z, Q = () => {
			y.value && (b.value = y.value.offsetHeight);
		};
		he(() => {
			Q(), typeof ResizeObserver < "u" && y.value && (Z = new ResizeObserver(Q), Z.observe(y.value));
		}), d(q, () => pe(Q)), me(() => Z?.disconnect());
		let $ = {
			InfoBadgeIconSourceProperty: f,
			props: m,
			emit: h,
			attrs: g,
			slots: xe,
			instance: _,
			t: v,
			rootRef: y,
			actualHeight: b,
			localValue: x,
			localStyle: S,
			localIconSource: C,
			localRequestedTheme: w,
			value: T,
			sourceValue: E,
			sourceStyle: D,
			sourceIconSource: O,
			sourceRequestedTheme: k,
			RequestedTheme: A,
			themeClass: Se,
			validateValue: j,
			BadgeValue: M,
			styleName: N,
			styleMatch: P,
			styleSeverity: F,
			styleIcon: I,
			childrenOf: L,
			structuralIconSource: R,
			IconElement: z,
			iconKind: B,
			displayKind: V,
			displayKindClass: Ce,
			ValueVisibility: H,
			IconVisibility: we,
			ValueMargin: Te,
			IconMargin: Ee,
			BadgePadding: U,
			BadgeBackground: De,
			BadgeForeground: W,
			thickness: G,
			numeric: K,
			desiredHeight: q,
			IconViewportHeight: J,
			IconViewportWidth: Y,
			TemplateSettings: X,
			decodeGlyph: Oe,
			IconElementPresenter: ke,
			badgeAttrs: Ae,
			badgeStyle: je,
			automationName: Me,
			Value: Ne,
			Style: Pe,
			IconSource: Fe,
			get resizeObserver() {
				return Z;
			},
			set resizeObserver(e) {
				Z = e;
			},
			measure: Q,
			ContentPresenter: ce,
			Grid: ne,
			TextBlock: oe,
			Viewbox: ie
		};
		return Object.defineProperty($, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), $;
	}
});
//#endregion
export { f as InfoBadgeIconSourceProperty, p as default };

//# sourceMappingURL=InfoBadge.vue_vue_type_script_setup_true_lang.js.map