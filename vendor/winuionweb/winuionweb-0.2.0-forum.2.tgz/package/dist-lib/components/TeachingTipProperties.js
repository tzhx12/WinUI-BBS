import { Fragment as e, defineComponent as t, h as n } from "vue";
//#region src/components/TeachingTipProperties.ts
var r = (r) => t({
	name: `TeachingTip.${r[0].toUpperCase()}${r.slice(1)}`,
	__teachingTipProperty: r,
	setup(t, { slots: r }) {
		return () => n(e, r.default?.());
	}
}), i = r("heroContent"), a = r("content"), o = r("iconSource"), s = r("actionButtonContent"), c = r("closeButtonContent"), l = (e) => e.type?.__teachingTipProperty;
//#endregion
export { s as TeachingTipActionButtonContent, c as TeachingTipCloseButtonContent, a as TeachingTipContent, i as TeachingTipHeroContent, o as TeachingTipIconSource, l as getTeachingTipProperty };

//# sourceMappingURL=TeachingTipProperties.js.map