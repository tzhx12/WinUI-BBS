import { createThemeShadow as e } from "./themeShadowRuntime.js";
import { defineComponent as t, onBeforeUnmount as n } from "vue";
//#region src/components/ThemeShadow.vue?vue&type=script&lang.ts
var r = Object.assign(t({
	name: "ThemeShadow",
	inheritAttrs: !1,
	setup(t, { expose: r }) {
		let i = e();
		return r(i), n(i.Dispose), () => null;
	}
}), {
	__xamlDependencyObject: !0,
	__createXamlResource(t, n) {
		let r = e();
		return n.Dispose(r.Dispose), r;
	}
});
//#endregion
export { r as default };

//# sourceMappingURL=ThemeShadow.vue_vue_type_script_lang.js.map