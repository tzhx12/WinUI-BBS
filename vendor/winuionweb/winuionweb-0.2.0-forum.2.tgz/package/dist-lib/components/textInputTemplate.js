//#region src/components/textInputTemplate.ts
var e = Symbol("WinUIonWeb.TextInputTemplate");
//#endregion
export { e as textInputTemplateKey };

//# sourceMappingURL=textInputTemplate.js.map