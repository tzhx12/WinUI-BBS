import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./MenuFlyout.vue_vue_type_script_setup_true_lang.js";
/* empty css                                               */
import { Fragment as n, createElementBlock as r, createElementVNode as i, createVNode as a, openBlock as o, withCtx as s } from "vue";
//#region src/components/MenuFlyout.vue
var c = {
	ref: "anchor",
	class: "win-menu-flyout-anchor",
	"aria-hidden": "true"
};
function l(e, t, l, u, d, f) {
	return o(), r(n, null, [i("span", c, null, 512), a(u.MenuFlyoutPresenter, {
		ref: "presenter",
		Owner: u.owner
	}, {
		default: s(() => [a(u.ItemsOutlet)]),
		_: 1
	}, 512)], 64);
}
var u = /*#__PURE__*/ e(t, [["render", l], ["__file", "MenuFlyout.vue"]]);
//#endregion
export { u as default };

//# sourceMappingURL=MenuFlyout.vue.js.map