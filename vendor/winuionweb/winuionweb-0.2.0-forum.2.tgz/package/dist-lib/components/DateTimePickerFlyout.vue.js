import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./DateTimePickerFlyout.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                                         */
import { Teleport as n, createBlock as r, createCommentVNode as i, createElementBlock as a, createElementVNode as o, createVNode as s, normalizeClass as c, normalizeStyle as l, openBlock as u, withCtx as d, withDirectives as f } from "vue";
//#region src/components/DateTimePickerFlyout.vue
var p = ["aria-label"];
function m(e, t, m, h, g, _) {
	return u(), r(n, { to: "body" }, [h.visible ? (u(), a("div", {
		key: 0,
		class: c(["date-time-picker-overlay", h.themeClasses]),
		style: l(h.overlayStyle),
		onPointerdown: h.OnLightDismiss
	}, null, 38)) : i("", !0), h.visible ? f((u(), a("div", {
		key: 1,
		ref: "presenterRef",
		class: c(["date-time-picker-presenter", h.themeClasses]),
		style: l(h.presenterStyle),
		role: "dialog",
		"aria-modal": "true",
		"aria-label": h.dialogLabel,
		onKeydown: h.OnKeyDown
	}, [s(h.Grid, { class: "picker-content-panel" }, {
		default: d(() => [
			s(h.Grid.RowDefinitions, null, {
				default: d(() => [s(h.RowDefinition, { Height: "*" }), s(h.RowDefinition, { Height: "Auto" })]),
				_: 1
			}),
			s(h.Grid, {
				class: "picker-host-grid",
				style: l(h.columnStyle)
			}, {
				default: d(() => [
					s(h.Grid.ColumnDefinitions, null, {
						default: d(() => [
							s(h.ColumnDefinition, { Width: "*" }),
							s(h.ColumnDefinition, { Width: "Auto" }),
							s(h.ColumnDefinition, { Width: "*" }),
							s(h.ColumnDefinition, { Width: "Auto" }),
							s(h.ColumnDefinition, { Width: "*" })
						]),
						_: 1
					}),
					t[0] ||= o("div", {
						class: "picker-highlight",
						"aria-hidden": "true"
					}, null, -1),
					h.columns.length ? (u(), r(h.PickerColumn, {
						ref: "firstRef",
						key: h.columns[0]?.key,
						"Grid.Column": "0",
						Items: "{x:Bind FirstItems}",
						SelectedIndex: "{x:Bind FirstIndex}",
						ShouldLoop: "{x:Bind FirstLoop}",
						AutomationName: "{x:Bind FirstLabel}",
						style: l(h.firstStyle),
						SelectionChanged: "OnFirstSelectionChanged"
					}, null, 8, ["style"])) : i("", !0),
					h.columns.length > 1 ? (u(), r(h.Rectangle, {
						key: 1,
						class: "picker-flyout-divider",
						"Grid.Column": "1",
						Width: "1",
						Fill: "{x:Bind SpacerFill}"
					})) : i("", !0),
					h.columns.length > 1 ? (u(), r(h.PickerColumn, {
						ref: "secondRef",
						key: h.columns[1]?.key,
						"Grid.Column": "2",
						Items: "{x:Bind SecondItems}",
						SelectedIndex: "{x:Bind SecondIndex}",
						ShouldLoop: "{x:Bind SecondLoop}",
						AutomationName: "{x:Bind SecondLabel}",
						style: l(h.secondStyle),
						SelectionChanged: "OnSecondSelectionChanged"
					}, null, 8, ["style"])) : i("", !0),
					h.columns.length > 2 ? (u(), r(h.Rectangle, {
						key: 3,
						class: "picker-flyout-divider",
						"Grid.Column": "3",
						Width: "1",
						Fill: "{x:Bind SpacerFill}"
					})) : i("", !0),
					h.columns.length > 2 ? (u(), r(h.PickerColumn, {
						ref: "thirdRef",
						key: h.columns[2]?.key,
						"Grid.Column": "4",
						Items: "{x:Bind ThirdItems}",
						SelectedIndex: "{x:Bind ThirdIndex}",
						ShouldLoop: "{x:Bind ThirdLoop}",
						AutomationName: "{x:Bind ThirdLabel}",
						style: l(h.thirdStyle),
						SelectionChanged: "OnThirdSelectionChanged"
					}, null, 8, ["style"])) : i("", !0)
				]),
				_: 1
			}, 8, ["style"]),
			s(h.Grid, {
				class: "picker-accept-dismiss-grid",
				"Grid.Row": "1",
				Height: "41"
			}, {
				default: d(() => [
					s(h.Grid.ColumnDefinitions, null, {
						default: d(() => [s(h.ColumnDefinition, { Width: "*" }), s(h.ColumnDefinition, { Width: "*" })]),
						_: 1
					}),
					s(h.Rectangle, {
						"Grid.ColumnSpan": "2",
						Height: "1",
						VerticalAlignment: "Top",
						Fill: "{x:Bind SpacerFill}"
					}),
					s(h.Button, {
						class: "picker-accept",
						"Grid.Column": "0",
						Margin: "4,4,2,4",
						Padding: "4",
						BorderThickness: "{ThemeResource DateTimeFlyoutButtonBorderThickness}",
						MinWidth: "0",
						MinHeight: "0",
						HorizontalAlignment: "Stretch",
						VerticalAlignment: "Stretch",
						Style: "{StaticResource SubtleButtonStyle}",
						"AutomationProperties.Name": "{x:Bind AcceptLabel}",
						"ToolTipService.ToolTip": "{x:Bind AcceptLabel}",
						Click: "OnAccept"
					}, {
						default: d(() => [s(h.FontIcon, {
							Glyph: "",
							FontSize: "16"
						})]),
						_: 1
					}),
					s(h.Button, {
						class: "picker-dismiss",
						"Grid.Column": "1",
						Margin: "2,4,4,4",
						Padding: "4",
						BorderThickness: "{ThemeResource DateTimeFlyoutButtonBorderThickness}",
						MinWidth: "0",
						MinHeight: "0",
						HorizontalAlignment: "Stretch",
						VerticalAlignment: "Stretch",
						Style: "{StaticResource SubtleButtonStyle}",
						"AutomationProperties.Name": "{x:Bind DismissLabel}",
						"ToolTipService.ToolTip": "{x:Bind DismissLabel}",
						Click: "OnDismiss"
					}, {
						default: d(() => [s(h.FontIcon, {
							Glyph: "",
							FontSize: "16"
						})]),
						_: 1
					})
				]),
				_: 1
			})
		]),
		_: 1
	})], 46, p)), [[
		h.vAcrylicBrush,
		h.presenterBackgroundStyle,
		void 0,
		{ "host-backdrop": !0 }
	], [h.vThemeShadow, { Translation: 32 }]]) : i("", !0)]);
}
var h = /*#__PURE__*/ e(t, [
	["render", m],
	["__scopeId", "data-v-9b200b7f"],
	["__file", "DateTimePickerFlyout.vue"]
]);
//#endregion
export { h as default };

//# sourceMappingURL=DateTimePickerFlyout.vue.js.map