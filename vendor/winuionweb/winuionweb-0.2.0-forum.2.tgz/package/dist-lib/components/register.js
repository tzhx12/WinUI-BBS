import { HorizontalAlignment as e, ResourceDictionary as t, SolidColorBrush as n, StaticResource as r, Thickness as ee, VerticalAlignment as te, XamlBoolean as ne, XamlDouble as re, XamlInt32 as ie } from "./xamlPrimitives.js";
import ae from "./AcrylicBrush.js";
import { Bold as oe, Hyperlink as se, InlineUIContainer as ce, InlineUIContainerChild as le, Italic as ue, LineBreak as de, Paragraph as fe, ParagraphInlines as pe, RichTextBlockBlocks as me, RichTextBlockTextHighlighters as he, Run as ge, Span as _e, SpanInlines as i, TextBlockInlines as ve, TextBlockTextHighlighters as ye, TextHighlighter as be, TextHighlighterRanges as xe, TextRange as Se, Underline as Ce } from "./TextInline.js";
import { ImageSourceProperty as we } from "./imageSource.js";
import Te from "./GridDefinitions.vue.js";
import Ee from "./GridColumnDefinitions.vue.js";
import De from "./GridRowDefinitions.vue.js";
import { GridContextFlyout as Oe } from "./Grid.vue_vue_type_script_setup_true_lang.js";
import a from "./Grid.vue.js";
import ke from "./BitmapIcon.vue.js";
import o from "./SymbolIcon.vue.js";
import s from "./PathIcon.vue.js";
import Ae from "./Viewbox.vue.js";
import { AppBarButtonContent as je, AppBarButtonFlyout as Me, AppBarButtonIcon as Ne, AppBarButtonKeyboardAccelerators as Pe } from "./AppBarButton.vue_vue_type_script_setup_true_lang.js";
import Fe from "./AppBarButton.vue.js";
import c from "./CommandBarFlyout.vue.js";
import { ToolTipContent as Ie, ToolTipContentTemplate as Le, ToolTipContentTransitions as Re, ToolTipServiceToolTip as ze } from "./ToolTipServiceProperties.js";
import l from "./Page.vue.js";
import { ActivityFeedLayout as Be, CollectionGroupHeaderTemplate as Ve, CollectionGroupStyle as u, CollectionGroupStyleHeaderTemplate as He, CollectionItemContainerStyle as d, CollectionItemContainerStyleSelector as Ue, CollectionItemContainerTransitions as We, CollectionItemTemplate as f, CollectionItemTemplateSelector as Ge, CollectionItems as Ke, CollectionItemsPanel as p, CollectionLayout as m, CollectionResources as qe, ControlTemplate as Je, DataTemplate as Ye, DataTemplateSelector as Xe, ItemsPanelTemplate as Ze, ItemsStackPanel as Qe, ItemsWrapGrid as $e, LinedFlowLayout as et, ScrollContentPresenter as tt, StackLayout as nt, UniformGridLayout as rt, VariedImageSizeLayout as it, XamlSetter as at, XamlStyle as ot } from "./CollectionProperties.js";
import st from "./TextBlock.vue.js";
import ct from "./FontIcon.vue.js";
import { animatedIconVisualSourceComponents as lt } from "./animatedIconVisuals.js";
import h from "./AnimatedIcon.vue.js";
import ut from "./AnimatedVisualPlayer.vue.js";
import { installPointerInput as dt } from "./pointerInput.js";
import ft from "./AnnotatedScrollBar.vue.js";
import pt from "./AppBarSeparator.vue.js";
import { AppBarToggleButtonContent as mt, AppBarToggleButtonIcon as ht, AppBarToggleButtonKeyboardAccelerators as gt } from "./AppBarToggleButton.vue_vue_type_script_setup_true_lang.js";
import _t from "./AppBarToggleButton.vue.js";
import vt from "./ScrollBar.vue.js";
import { ScrollViewerTemplate as yt } from "./ScrollViewer.vue_vue_type_script_setup_true_lang.js";
import bt from "./ScrollViewer.vue.js";
import { BorderChild as xt, BorderResources as St } from "./Border.vue_vue_type_script_setup_true_lang.js";
import g from "./Border.vue.js";
import Ct from "./ContentPresenter.vue.js";
import _ from "./TextBox.vue.js";
import v from "./AutoSuggestBox.vue.js";
import wt from "./BitmapImage.vue.js";
import Tt from "./FocusVisual.vue.js";
import { ButtonContent as Et, ButtonFlyout as Dt, ButtonKeyboardAccelerators as Ot } from "./Button.vue_vue_type_script_setup_true_lang.js";
import y from "./Button.vue.js";
import b from "./BreadcrumbBarItem.vue.js";
import x from "./Flyout.vue.js";
import S from "./BreadcrumbBar.vue.js";
import kt from "./CalendarView.vue.js";
import At from "./ColumnDefinition.vue.js";
import jt from "./RowDefinition.vue.js";
import Mt from "./CalendarDatePicker.vue.js";
import { CanvasResources as Nt } from "./Canvas.vue_vue_type_script_setup_true_lang.js";
import C from "./Canvas.vue.js";
import Pt from "./CaptureElement.vue.js";
import Ft from "./Case.vue.js";
import It from "./CheckBox.vue.js";
import { ComboBoxItem as Lt, SliderHeaderProperty as Rt, XamlString as zt } from "./inlineControlProperties.js";
import w from "./ComboBox.vue.js";
import { RepeatButtonContent as Bt } from "./RepeatButton.vue_vue_type_script_setup_true_lang.js";
import T from "./RepeatButton.vue.js";
import Vt from "./NumberBox.vue.js";
import Ht from "./ToolTip.vue.js";
import Ut from "./ColorPicker.vue.js";
import E from "./CommandBar.vue.js";
import D from "./ContentDialog.vue.js";
import Wt from "./PickerColumn.vue.js";
import O from "./Rectangle.vue.js";
import Gt from "./DateTimePickerFlyout.vue.js";
import Kt from "./DatePicker.vue.js";
import qt from "./Image.vue.js";
import Jt from "./ImageIcon.vue.js";
import { BitmapIconSource as Yt, FontIconSource as Xt, IconSourceProperty as Zt, ImageIconSource as Qt, ImageIconSourceProperty as $t, PathIconSource as en, SymbolIconSource as tn } from "./IconSource.js";
import k from "./DropDownButton.vue.js";
import nn from "./Ellipse.vue.js";
import rn from "./ExpanderBase.vue.js";
import { ExpanderContent as an, ExpanderDescription as on, ExpanderHeader as sn, ExpanderHeaderControls as cn, ExpanderHeaderIcon as ln } from "./ExpanderProperties.js";
import un from "./Expander.vue.js";
import dn from "./FlipView.vue.js";
import fn from "./FlyoutAnimation.vue.js";
import { CommonNavigationTransitionInfo as pn, ContinuumNavigationTransitionInfo as mn, DrillInNavigationTransitionInfo as hn, EntranceNavigationTransitionInfo as gn, FrameContentTransitions as _n, NavigationThemeTransition as vn, SlideNavigationTransitionInfo as yn, SuppressNavigationTransitionInfo as bn, TransitionCollection as xn } from "./NavigationTransitionProperties.js";
import Sn from "./Frame.vue.js";
import Cn from "./GridView.vue.js";
import { HyperlinkButtonContent as wn } from "./HyperlinkButton.vue_vue_type_script_setup_true_lang.js";
import A from "./HyperlinkButton.vue.js";
import j from "./IconSourceElement.vue.js";
import { InfoBadgeIconSourceProperty as Tn } from "./InfoBadge.vue_vue_type_script_setup_true_lang.js";
import M from "./InfoBadge.vue.js";
import N from "./InfoBarPanel.vue.js";
import { InfoBarActionButton as En, InfoBarContent as Dn, InfoBarContentTemplate as On, InfoBarIconSource as kn } from "./InfoBarProperties.js";
import An from "./InfoBar.vue.js";
import jn from "./ItemContainer.vue.js";
import P from "./StackPanel.vue.js";
import F from "./ItemsControl.vue.js";
import Mn from "./ItemsRepeater.vue.js";
import Nn from "./ItemsRepeaterScrollHost.vue.js";
import Pn from "./ScrollView.vue.js";
import Fn from "./ItemsView.vue.js";
import In from "./ListBox.vue.js";
import Ln from "./ListView.vue.js";
import Rn from "./RadioButton.vue.js";
import zn from "./ProgressBar.vue.js";
import Bn from "./Slider.vue.js";
import Vn from "./MediaTransportControls.vue.js";
import { MediaPlayerTransportControlsProperty as Hn } from "./MediaPlayerElement.vue_vue_type_script_setup_true_lang.js";
import Un from "./MediaPlayerElement.vue.js";
import I from "./MenuBar.vue.js";
import { MenuFlyoutItemIcon as Wn, MenuFlyoutItemKeyboardAccelerators as Gn, MenuFlyoutItems_exports as Kn, MenuFlyoutSubItemItems as qn } from "./MenuFlyoutItems.js";
import L from "./MenuFlyout.vue.js";
import R from "./MenuBarItem.vue.js";
import { NavigationViewProperties_exports as Jn } from "./NavigationViewProperties.js";
import Yn from "./NavigationView.vue.js";
import Xn from "./ParallaxView.vue.js";
import z from "./PasswordBox.vue.js";
import B from "./PersonPicture.vue.js";
import Zn from "./PipsPager.vue.js";
import { pivotItemProperties as Qn, pivotProperties as $n } from "./PivotProperties.js";
import er from "./PivotItem.vue.js";
import tr from "./Pivot.vue.js";
import V from "./Popup.vue.js";
import nr from "./ProgressRing.vue.js";
import H from "./RadialGradientBrush.vue.js";
import rr from "./RadioButtons.vue.js";
import ir from "./Rating.vue.js";
import { RefreshContainerContent as ar, RefreshContainerVisualizer as or, RefreshVisualizerContent as sr } from "./RefreshProperties.js";
import cr from "./RefreshVisualizer.vue.js";
import lr from "./RefreshContainer.vue.js";
import U from "./RelativePanel.vue.js";
import W from "./RichEditBox.vue.js";
import ur from "./RichTextBlock.vue.js";
import dr from "./RichTextBlockOverflow.vue.js";
import fr from "./SelectorBarItem.vue.js";
import pr from "./SelectorBar.vue.js";
import G from "./SemanticZoom.vue.js";
import mr from "./SettingsCard.vue.js";
import { SplitButtonContent as hr, SplitButtonFlyout as gr } from "./SplitButton.vue_vue_type_script_setup_true_lang.js";
import K from "./SplitButton.vue.js";
import { SplitViewContent as _r, SplitViewPane as vr } from "./SplitView.vue_vue_type_script_setup_true_lang.js";
import yr from "./SplitView.vue.js";
import br from "./SvgImageSource.vue.js";
import { GradientStop as xr, LinearGradientBrush as Sr, SwipeItem as Cr, SwipeItemBackground as wr, SwipeItemForeground as Tr, SwipeItemIconSource as Er, SwipeItems as Dr, swipeControlProperties as Or } from "./SwipeControlProperties.js";
import kr from "./SwipeControl.vue.js";
import Ar from "./SwitchPresenter.vue.js";
import { DesktopAcrylicBackdrop as jr, MicaBackdrop as Mr, SystemBackdropElementSystemBackdrop as Nr } from "./systemBackdropXaml.js";
import Pr from "./SystemBackdropElement.vue.js";
import { tabViewItemProperties as Fr, tabViewProperties as Ir } from "./TabViewProperties.js";
import Lr from "./TabViewItem.vue.js";
import Rr from "./TabView.vue.js";
import { TeachingTipContent as zr, TeachingTipHeroContent as Br, TeachingTipIconSource as Vr } from "./TeachingTipProperties.js";
import q from "./TeachingTip.vue.js";
import J from "./ThemeShadow.vue.js";
import Hr from "./TimePicker.vue.js";
import Y from "./TitleBar.vue.js";
import { ToggleButtonContent as Ur } from "./ToggleButton.vue_vue_type_script_setup_true_lang.js";
import X from "./ToggleButton.vue.js";
import { ToggleSplitButtonContent as Wr, ToggleSplitButtonFlyout as Gr } from "./ToggleSplitButton.vue_vue_type_script_setup_true_lang.js";
import Z from "./ToggleSplitButton.vue.js";
import Kr from "./ToggleSwitch.vue.js";
import qr from "./ToolTipService.vue.js";
import { TreeViewNodeChildren as Jr, TreeViewRootNodes as Yr, XamlTreeViewItem as Xr, XamlTreeViewNode as Zr } from "./TreeView.vue_vue_type_script_setup_true_lang.js";
import Qr from "./TreeView.vue.js";
import { VariableSizedWrapGridResources as $r } from "./VariableSizedWrapGrid.vue_vue_type_script_setup_true_lang.js";
import ei from "./VariableSizedWrapGrid.vue.js";
import ti from "./CollectionViewSource.js";
import { EllipseGeometry as ni, GeometryGroup as ri, Line as ii, LineGeometry as ai, Path as Q, Polyline as oi, RectangleGeometry as si } from "./Shapes.js";
//#region src/components/register.ts
function $($) {
	dt(), $.component("AcrylicBrush", ae), $.component("media:AcrylicBrush", ae), $.component("SolidColorBrush", n), $.component("StaticResource", r), $.component("ResourceDictionary", t), $.component("ResourceDictionary.ThemeDictionaries", t.ThemeDictionaries), $.component("ResourceDictionary.MergedDictionaries", t.MergedDictionaries), $.component("Thickness", ee), $.component("Grid", a), $.component("AnimatedIcon", h), $.component("AutoSuggestBox.QueryIcon", v.QueryIcon);
	for (let e of [
		"Header",
		"Description",
		"HeaderTemplate",
		"ItemTemplate",
		"ItemTemplateSelector",
		"Resources"
	]) $.component(`AutoSuggestBox.${e}`, v[e]);
	$.component("AnimatedIcon.Source", h.Source), $.component("AnimatedIcon.FallbackIconSource", h.FallbackIconSource);
	for (let [e, t] of Object.entries(lt)) $.component(e, t), $.component(`animatedvisuals:${e}`, t);
	$.component("Grid.ContextFlyout", Oe), $.component("Button.Flyout", Dt), $.component("Button.Content", Et), $.component("Button.KeyboardAccelerators", Ot), $.component("HyperlinkButton.Content", wn), $.component("RepeatButton.Content", Bt), $.component("ToggleButton.Content", Ur), $.component("Button.ContentTemplate", y.ContentTemplate), $.component("Button.ContentTransitions", y.ContentTransitions), $.component("Button.Resources", y.Resources), $.component("HyperlinkButton.ContentTemplate", A.ContentTemplate), $.component("HyperlinkButton.ContentTransitions", A.ContentTransitions), $.component("HyperlinkButton.Resources", A.Resources), $.component("RepeatButton.ContentTemplate", T.ContentTemplate), $.component("RepeatButton.ContentTransitions", T.ContentTransitions), $.component("RepeatButton.Resources", T.Resources), $.component("ToggleButton.ContentTemplate", X.ContentTemplate), $.component("ToggleButton.ContentTransitions", X.ContentTransitions), $.component("ToggleButton.Resources", X.Resources), $.component("SplitButton.ContentTemplate", K.ContentTemplate), $.component("SplitButton.ContentTransitions", K.ContentTransitions), $.component("SplitButton.Resources", K.Resources), $.component("ToggleSplitButton.ContentTemplate", Z.ContentTemplate), $.component("ToggleSplitButton.ContentTransitions", Z.ContentTransitions), $.component("ToggleSplitButton.Resources", Z.Resources), $.component("AppBarButton", Fe), $.component("AppBarButton.Icon", Ne), $.component("AppBarButton.Flyout", Me), $.component("AppBarButton.Content", je), $.component("AppBarButton.KeyboardAccelerators", Pe), $.component("AppBarToggleButton", _t), $.component("AppBarToggleButton.Icon", ht), $.component("AppBarToggleButton.Content", mt), $.component("AppBarToggleButton.KeyboardAccelerators", gt), $.component("AppBarSeparator", pt), $.component("CommandBar", E), $.component("CommandBar.PrimaryCommands", E.PrimaryCommands), $.component("CommandBar.SecondaryCommands", E.SecondaryCommands), $.component("CommandBar.Content", E.Content), $.component("CommandBarFlyout", c), $.component("CommandBarFlyout.PrimaryCommands", c.PrimaryCommands), $.component("CommandBarFlyout.SecondaryCommands", c.SecondaryCommands), $.component("RichEditBox.ContextFlyout", W.ContextFlyout), $.component("RichEditBox.Background", W.Background), $.component("RichEditBox.Header", W.Header), $.component("RichEditBox.HeaderTemplate", W.HeaderTemplate), $.component("RichEditBox.Description", W.Description), $.component("RichEditBox.SelectionFlyout", W.SelectionFlyout), $.component("BitmapIcon", ke), $.component("PathIcon", s), $.component("PathIcon.Data", s.Data), $.component("ImageIcon", Jt), $.component("ImageIcon.Source", we), $.component("IconSourceElement", j), $.component("IconSourceElement.IconSource", Zt), $.component("MediaTransportControls", Vn), $.component("MediaPlayerElement.TransportControls", Hn), $.component("StackPanel", P), $.component("Canvas", C), $.component("Canvas.Resources", Nt), $.component("RelativePanel", U), $.component("RelativePanel.Resources", U.Resources), $.component("VariableSizedWrapGrid", ei), $.component("Border", g), $.component("Border.Child", xt), $.component("Rectangle", O), $.component("Ellipse", nn), $.component("ItemsRepeaterScrollHost", Nn), $.component("Image", qt), $.component("Image.Source", we), $.component("BitmapImage", wt), $.component("PersonPicture", B), $.component("ProgressBar", zn), $.component("ProgressRing", nr), $.component("PersonPicture.ProfilePicture", B.ProfilePicture), $.component("PersonPicture.BadgeImageSource", B.BadgeImageSource), $.component("SvgImageSource", br), $.component("ItemContainer", jn), $.component("FontIcon", ct), $.component("SymbolIcon", o), $.component("Run", ge), $.component("TextBox.Header", _.Header), $.component("TextBox.HeaderTemplate", _.HeaderTemplate), $.component("TextBox.Description", _.Description), $.component("TextBox.ContextFlyout", _.ContextFlyout), $.component("TextBox.SelectionFlyout", _.SelectionFlyout), $.component("NumberBox.HeaderTemplate", Vt.HeaderTemplate), $.component("PasswordBox.Header", z.Header), $.component("PasswordBox.Description", z.Description), $.component("PasswordBox.HeaderTemplate", z.HeaderTemplate), $.component("PasswordBox.ContextFlyout", z.ContextFlyout), $.component("PasswordBox.SelectionFlyout", z.SelectionFlyout), $.component("InlineUIContainer", ce), $.component("TextHighlighter", be), $.component("TextRange", Se), $.component("TextBlock.Inlines", ve), $.component("TextBlock.TextHighlighters", ye), $.component("RichTextBlock.Blocks", me), $.component("RichTextBlock.TextHighlighters", he), $.component("Span.Inlines", i), $.component("Bold.Inlines", i), $.component("Italic.Inlines", i), $.component("Underline.Inlines", i), $.component("Hyperlink.Inlines", i), $.component("Paragraph.Inlines", pe), $.component("InlineUIContainer.Child", le), $.component("TextHighlighter.Ranges", xe), $.component("Span", _e), $.component("Bold", oe), $.component("Italic", ue), $.component("Underline", Ce), $.component("Paragraph", fe), $.component("RichTextBlockOverflow", dr), $.component("LineBreak", de), $.component("Hyperlink", se), $.component("FontIconSource", Xt), $.component("SymbolIconSource", tn), $.component("BitmapIconSource", Yt), $.component("PathIconSource", en), $.component("ImageIconSource", Qt), $.component("ImageIconSource.ImageSource", $t), $.component("InfoBadge", M), $.component("InfoBadge.IconSource", Tn), $.component("InfoBar", An), $.component("InfoBarPanel", N), $.component("InfoBar.ActionButton", En), $.component("InfoBar.Content", Dn), $.component("InfoBar.ContentTemplate", On), $.component("InfoBar.IconSource", kn), $.component("Frame", Sn), $.component("Frame.ContentTransitions", _n), $.component("TransitionCollection", xn), $.component("NavigationThemeTransition", vn), $.component("NavigationThemeTransition.DefaultNavigationTransitionInfo", vn.DefaultNavigationTransitionInfo), $.component("EntranceNavigationTransitionInfo", gn), $.component("DrillInNavigationTransitionInfo", hn), $.component("SuppressNavigationTransitionInfo", bn), $.component("SlideNavigationTransitionInfo", yn), $.component("CommonNavigationTransitionInfo", pn), $.component("ContinuumNavigationTransitionInfo", mn), $.component("NavigationView", Yn);
	for (let e of Object.values(Jn)) e && typeof e == "object" && "name" in e && typeof e.name == "string" && /^(NavigationView|MenuItemTemplateSelector)/.test(e.name) && $.component(e.name, e);
	$.component("Flyout", x), $.component("ContentDialog", D), $.component("ContentDialog.Title", D.Title), $.component("ContentDialog.Content", D.Content), $.component("ContentDialog.TitleTemplate", D.TitleTemplate), $.component("ContentDialog.ContentTemplate", D.ContentTemplate), $.component("Popup", V), $.component("TeachingTip", q), $.component("TeachingTip.HeroContent", Br), $.component("TeachingTip.Content", zr), $.component("TeachingTip.IconSource", Vr), $.component("TeachingTip.ActionButtonContent", q.ActionButtonContent), $.component("TeachingTip.CloseButtonContent", q.CloseButtonContent), $.component("ToolTip", Ht), $.component("ToolTipService.ToolTip", ze), $.component("ToolTip.Content", Ie), $.component("ToolTip.ContentTemplate", Le), $.component("ToolTip.ContentTransitions", Re), $.component("BreadcrumbBar", S), $.component("BreadcrumbBar.ItemTemplate", S.ItemTemplate), $.component("BreadcrumbBarItem", b), $.component("BreadcrumbBarItem.ContentTemplate", b.ContentTemplate), $.component("ComboBoxItem", Lt), $.component("ComboBox", w);
	for (let e of [
		"ItemTemplate",
		"Items",
		"Resources",
		"ItemContainerStyle",
		"Header",
		"HeaderTemplate",
		"Description"
	]) $.component(`ComboBox.${e}`, w[e]);
	$.component("ItemsControl", F);
	for (let e of [
		"Items",
		"Resources",
		"ItemTemplate",
		"ItemTemplateSelector",
		"ItemsPanel"
	]) $.component(`ItemsControl.${e}`, F[e]);
	$.component("x:String", zt), $.component("x:Double", re), $.component("x:Int32", ie), $.component("x:Boolean", ne), $.component("HorizontalAlignment", e), $.component("VerticalAlignment", te), $.component("SplitView", yr), $.component("SplitView.Pane", vr), $.component("SplitView.Content", _r), $.component("Flyout.Content", x.Content), $.component("Flyout.FlyoutPresenterStyle", x.FlyoutPresenterStyle), $.component("Popup.Child", V.Child), $.component("Popup.Shadow", V.Shadow), $.component("Expander", un), $.component("Expander.Header", sn), $.component("Expander.Content", an), $.component("Expander.Description", on), $.component("Expander.HeaderIcon", ln), $.component("Expander.HeaderControls", cn), $.component("DropDownButton", k);
	for (let e of [
		"Content",
		"Flyout",
		"ContentTemplate",
		"ContentTransitions",
		"Resources",
		"KeyboardAccelerators",
		"Background"
	]) $.component(`DropDownButton.${e}`, k[e]);
	$.component("MenuFlyout", L), $.component("MenuBar", I), $.component("MenuBar.Items", I.Items), $.component("MenuBarItem", R), $.component("MenuBarItem.Items", R.Items);
	for (let e of [
		"MenuFlyoutItem",
		"ToggleMenuFlyoutItem",
		"RadioMenuFlyoutItem",
		"MenuFlyoutSubItem",
		"SplitMenuFlyoutItem",
		"MenuFlyoutSeparator",
		"KeyboardAccelerator"
	]) $.component(e, Kn[e]);
	$.component("MenuFlyout.Items", L.Items), $.component("MenuFlyout.MenuFlyoutPresenterStyle", L.MenuFlyoutPresenterStyle);
	for (let e of [
		"MenuFlyoutItem",
		"ToggleMenuFlyoutItem",
		"RadioMenuFlyoutItem",
		"MenuFlyoutSubItem",
		"SplitMenuFlyoutItem"
	]) $.component(`${e}.Icon`, Wn), $.component(`${e}.KeyboardAccelerators`, Gn);
	$.component("MenuFlyoutSubItem.Items", qn), $.component("SplitMenuFlyoutItem.Items", qn), $.component("SplitButton.Flyout", gr), $.component("SplitButton.Content", hr), $.component("ToggleSplitButton.Flyout", Gr), $.component("ToggleSplitButton.Content", Wr), $.component("ColumnDefinition", At), $.component("RowDefinition", jt), $.component("Grid.ColumnDefinitions", Ee), $.component("Grid.RowDefinitions", De), $.component("Slider.Header", Rt), $.component("Page", l), $.component("Page.Resources", l.Resources), $.component("CollectionViewSource", ti), $.component("SemanticZoom.ZoomedInView", G.ZoomedInView), $.component("SemanticZoom.ZoomedOutView", G.ZoomedOutView), $.component("ScrollViewer.Template", yt), $.component("FlipView.ItemTemplate", f), $.component("FlipView.ItemsPanel", p), $.component("GridView.ItemTemplate", f), $.component("GridView.GroupStyle", u), $.component("GridView.ItemsPanel", p), $.component("ItemsRepeater.ItemTemplate", f), $.component("ItemsRepeater.Layout", m), $.component("ItemsView.ItemTemplate", f), $.component("ItemsView.Layout", m), $.component("ListView.ItemTemplate", f), $.component("ListBox.ItemTemplate", f), $.component("ListView.GroupHeaderTemplate", Ve), $.component("ListView.GroupStyle", u), $.component("GroupStyle", u), $.component("GroupStyle.HeaderTemplate", He), $.component("ListView.ItemsPanel", p), $.component("GridView.ItemContainerStyle", d), $.component("ListView.ItemContainerStyle", d), $.component("Style", ot), $.component("Setter", at), $.component("TreeView.ItemTemplate", f), $.component("TreeView.ItemTemplateSelector", Ge), $.component("TreeView.ItemContainerStyle", d), $.component("TreeView.ItemContainerStyleSelector", Ue), $.component("TreeView.ItemContainerTransitions", We), $.component("TreeView.RootNodes", Yr), $.component("TreeViewItem", Xr), $.component("TreeViewNode", Zr), $.component("TreeViewNode.Children", Jr), $.component("DataTemplate", Ye), $.component("Pivot", tr), $.component("PivotItem", er);
	for (let [e, t] of Object.entries($n)) $.component(`Pivot.${e}`, t);
	for (let [e, t] of Object.entries(Qn)) $.component(`PivotItem.${e}`, t);
	$.component("TabView", Rr), $.component("TabViewItem", Lr);
	for (let [e, t] of Object.entries(Ir)) $.component(`TabView.${e}`, t);
	for (let [e, t] of Object.entries(Fr)) $.component(`TabViewItem.${e}`, t);
	$.component("DataTemplateSelector", Xe), $.component("ItemsPanelTemplate", Ze), $.component("ItemsStackPanel", Qe), $.component("ControlTemplate", Je), $.component("ScrollContentPresenter", tt), $.component("CollectionLayout", m), $.component("StackLayout", nt), $.component("UniformGridLayout", rt), $.component("LinedFlowLayout", et), $.component("ActivityFeedLayout", Be), $.component("VariedImageSizeLayout", it), $.component("ItemsWrapGrid", $e), $.component("VariableSizedWrapGrid.Resources", $r), $.component("StackPanel.Resources", P.Resources), $.component("GridView.Resources", qe), $.component("GridView.Items", Ke), $.component("VirtualizingStackPanel", P), $.component("SwipeControl", kr), $.component("SwipeItems", Dr), $.component("SwipeItem", Cr), $.component("SwipeItem.IconSource", Er), $.component("SwipeItem.Background", wr), $.component("SwipeItem.Foreground", Tr), $.component("LinearGradientBrush", Sr), $.component("GradientStop", xr), $.component("RadialGradientBrush", H), $.component("media:RadialGradientBrush", H), $.component("RadialGradientBrush.GradientStops", H.GradientStops), $.component("media:RadialGradientBrush.GradientStops", H.GradientStops);
	for (let [e, t, n] of [
		[
			"Grid",
			a,
			["Background"]
		],
		[
			"StackPanel",
			P,
			["Background"]
		],
		[
			"Canvas",
			C,
			["Background"]
		],
		[
			"Border",
			g,
			["Background"]
		],
		[
			"Button",
			y,
			["Background"]
		],
		[
			"TextBlock",
			st,
			["Foreground"]
		],
		[
			"Rectangle",
			O,
			["Fill", "Stroke"]
		],
		[
			"Line",
			ii,
			["Fill", "Stroke"]
		],
		[
			"Polyline",
			oi,
			["Fill", "Stroke"]
		],
		[
			"Path",
			Q,
			["Fill", "Stroke"]
		]
	]) for (let r of n) $.component(`${e}.${r}`, t[r]);
	$.component("ThemeShadow", J), $.component("SystemBackdropElement", Pr), $.component("TitleBar", Y);
	for (let e of [
		"Resources",
		"IconSource",
		"LeftHeader",
		"Content",
		"RightHeader"
	]) $.component(`TitleBar.${e}`, Y[e]);
	$.component("SystemBackdropElement.SystemBackdrop", Nr), $.component("MicaBackdrop", Mr), $.component("DesktopAcrylicBackdrop", jr), $.component("Line", ii), $.component("Polyline", oi), $.component("Path", Q), $.component("Path.Data", Q.Data), $.component("GeometryGroup", ri), $.component("GeometryGroup.Children", ri.Children), $.component("LineGeometry", ai), $.component("EllipseGeometry", ni), $.component("RectangleGeometry", si), $.component("Border.Shadow", g.Shadow), $.component("Grid.Shadow", a.Shadow), $.component("Border.Resources", St);
	for (let [e, t] of Object.entries(Or)) $.component(`SwipeControl.${e}`, t);
	$.component("RefreshContainer", lr), $.component("RefreshContainer.Visualizer", or), $.component("RefreshContainer.Content", ar), $.component("RefreshVisualizer", cr), $.component("RefreshVisualizer.Content", sr);
	let ci = /* #__PURE__ */ Object.assign({
		"./AnimatedIcon.vue": h,
		"./AnimatedVisualPlayer.vue": ut,
		"./AnnotatedScrollBar.vue": ft,
		"./AppBarButton.vue": Fe,
		"./AppBarSeparator.vue": pt,
		"./AppBarToggleButton.vue": _t,
		"./AutoSuggestBox.vue": v,
		"./BitmapIcon.vue": ke,
		"./BitmapImage.vue": wt,
		"./Border.vue": g,
		"./BreadcrumbBar.vue": S,
		"./BreadcrumbBarItem.vue": b,
		"./Button.vue": y,
		"./CalendarDatePicker.vue": Mt,
		"./CalendarView.vue": kt,
		"./Canvas.vue": C,
		"./CaptureElement.vue": Pt,
		"./Case.vue": Ft,
		"./CheckBox.vue": It,
		"./ColorPicker.vue": Ut,
		"./ColumnDefinition.vue": At,
		"./ComboBox.vue": w,
		"./CommandBar.vue": E,
		"./CommandBarFlyout.vue": c,
		"./ContentDialog.vue": D,
		"./ContentPresenter.vue": Ct,
		"./DatePicker.vue": Kt,
		"./DateTimePickerFlyout.vue": Gt,
		"./DropDownButton.vue": k,
		"./Ellipse.vue": nn,
		"./Expander.vue": un,
		"./ExpanderBase.vue": rn,
		"./FlipView.vue": dn,
		"./Flyout.vue": x,
		"./FlyoutAnimation.vue": fn,
		"./FocusVisual.vue": Tt,
		"./FontIcon.vue": ct,
		"./Frame.vue": Sn,
		"./Grid.vue": a,
		"./GridColumnDefinitions.vue": Ee,
		"./GridDefinitions.vue": Te,
		"./GridRowDefinitions.vue": De,
		"./GridView.vue": Cn,
		"./HyperlinkButton.vue": A,
		"./IconSourceElement.vue": j,
		"./Image.vue": qt,
		"./ImageIcon.vue": Jt,
		"./InfoBadge.vue": M,
		"./InfoBar.vue": An,
		"./InfoBarPanel.vue": N,
		"./ItemContainer.vue": jn,
		"./ItemsControl.vue": F,
		"./ItemsRepeater.vue": Mn,
		"./ItemsRepeaterScrollHost.vue": Nn,
		"./ItemsView.vue": Fn,
		"./ListBox.vue": In,
		"./ListView.vue": Ln,
		"./MediaPlayerElement.vue": Un,
		"./MediaTransportControls.vue": Vn,
		"./MenuBar.vue": I,
		"./MenuBarItem.vue": R,
		"./MenuFlyout.vue": L,
		"./NavigationView.vue": Yn,
		"./NumberBox.vue": Vt,
		"./Page.vue": l,
		"./ParallaxView.vue": Xn,
		"./PasswordBox.vue": z,
		"./PathIcon.vue": s,
		"./PersonPicture.vue": B,
		"./PickerColumn.vue": Wt,
		"./PipsPager.vue": Zn,
		"./Pivot.vue": tr,
		"./PivotItem.vue": er,
		"./Popup.vue": V,
		"./ProgressBar.vue": zn,
		"./ProgressRing.vue": nr,
		"./RadialGradientBrush.vue": H,
		"./RadioButton.vue": Rn,
		"./RadioButtons.vue": rr,
		"./Rating.vue": ir,
		"./Rectangle.vue": O,
		"./RefreshContainer.vue": lr,
		"./RefreshVisualizer.vue": cr,
		"./RelativePanel.vue": U,
		"./RepeatButton.vue": T,
		"./RichEditBox.vue": W,
		"./RichTextBlock.vue": ur,
		"./RichTextBlockOverflow.vue": dr,
		"./RowDefinition.vue": jt,
		"./ScrollBar.vue": vt,
		"./ScrollView.vue": Pn,
		"./ScrollViewer.vue": bt,
		"./SelectorBar.vue": pr,
		"./SelectorBarItem.vue": fr,
		"./SemanticZoom.vue": G,
		"./SettingsCard.vue": mr,
		"./Slider.vue": Bn,
		"./SplitButton.vue": K,
		"./SplitView.vue": yr,
		"./StackPanel.vue": P,
		"./SvgImageSource.vue": br,
		"./SwipeControl.vue": kr,
		"./SwitchPresenter.vue": Ar,
		"./SymbolIcon.vue": o,
		"./SystemBackdropElement.vue": Pr,
		"./TabView.vue": Rr,
		"./TabViewItem.vue": Lr,
		"./TeachingTip.vue": q,
		"./TextBlock.vue": st,
		"./TextBox.vue": _,
		"./ThemeShadow.vue": J,
		"./TimePicker.vue": Hr,
		"./TitleBar.vue": Y,
		"./ToggleButton.vue": X,
		"./ToggleSplitButton.vue": Z,
		"./ToggleSwitch.vue": Kr,
		"./ToolTip.vue": Ht,
		"./ToolTipService.vue": qr,
		"./TreeView.vue": Qr,
		"./VariableSizedWrapGrid.vue": ei,
		"./Viewbox.vue": Ae
	});
	for (let [e, t] of Object.entries(ci)) {
		let n = e.slice(2, -4);
		$.component(n) || $.component(n, t);
	}
}
//#endregion
export { $ as registerWinUIComponents };

//# sourceMappingURL=register.js.map