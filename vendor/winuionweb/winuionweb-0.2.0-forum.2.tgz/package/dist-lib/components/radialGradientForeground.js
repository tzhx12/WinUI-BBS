import { isRadialGradientBrush as e, radialGradientPaint as t } from "./RadialGradientVisual.js";
import { h as n, render as r, shallowRef as i, watchEffect as a } from "vue";
//#region src/components/radialGradientForeground.ts
var o = /* @__PURE__ */ new WeakMap(), s = 0, c = (c, l) => {
	let u = o.get(c);
	if (u) {
		e(l) ? u.brush.value = l : (u.dispose(), o.delete(c));
		return;
	}
	if (!e(l)) return;
	let d = i(l), f = i({
		width: c.clientWidth,
		height: c.clientHeight
	}), p = document.createElement("div"), m = `radial-foreground-${++s}`, h = [
		"background-image",
		"background-size",
		"background-repeat",
		"background-origin",
		"background-clip",
		"-webkit-background-clip",
		"-webkit-text-fill-color"
	].map((e) => [e, c.style.getPropertyValue(e)]), g = new ResizeObserver(() => {
		let e = c.clientWidth, t = c.clientHeight;
		(e !== f.value.width || t !== f.value.height) && (f.value = {
			width: e,
			height: t
		});
	});
	g.observe(c);
	let _ = a(() => {
		if (!e(d.value)) return;
		let { definition: i, paint: a, opacity: o } = t(d.value, m), s = Math.max(1, f.value.width), l = Math.max(1, f.value.height);
		r(n("svg", {
			xmlns: "http://www.w3.org/2000/svg",
			width: s,
			height: l
		}, [n("defs", [i]), n("rect", {
			width: s,
			height: l,
			fill: a,
			opacity: o
		})]), p);
		let u = new XMLSerializer().serializeToString(p.firstElementChild);
		c.style.backgroundImage = `url("data:image/svg+xml,${encodeURIComponent(u)}")`, c.style.backgroundSize = "100% 100%", c.style.backgroundRepeat = "no-repeat", c.style.backgroundOrigin = "padding-box", c.style.backgroundClip = "text", c.style.setProperty("-webkit-background-clip", "text"), c.style.setProperty("-webkit-text-fill-color", "transparent");
	});
	o.set(c, {
		brush: d,
		dispose: () => {
			_(), g.disconnect(), r(null, p);
			for (let [e, t] of h) t ? c.style.setProperty(e, t) : c.style.removeProperty(e);
		}
	});
}, l = {
	mounted: (e, t) => c(e, t.value),
	updated: (e, t) => c(e, t.value),
	beforeUnmount: (e) => {
		o.get(e)?.dispose(), o.delete(e);
	}
};
//#endregion
export { l as vRadialGradientForeground };

//# sourceMappingURL=radialGradientForeground.js.map