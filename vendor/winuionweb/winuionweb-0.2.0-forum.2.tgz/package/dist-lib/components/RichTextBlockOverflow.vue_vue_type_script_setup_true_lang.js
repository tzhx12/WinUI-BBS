import { alignment as e, cssLength as t, xamlThickness as n } from "./layout.js";
import { resolveXamlValue as r } from "./xamlRuntime.js";
import { computed as i, defineComponent as a, getCurrentInstance as o, ref as s, useAttrs as c } from "vue";
//#region src/components/RichTextBlockOverflow.vue?vue&type=script&setup=true&lang.ts
var l = /*@__PURE__*/ a({
	inheritAttrs: !1,
	__name: "RichTextBlockOverflow",
	props: {
		OverflowContentTarget: {
			type: [String, Object],
			default: null
		},
		Margin: {
			type: [String, Number],
			default: ""
		},
		Padding: {
			type: [String, Number],
			default: ""
		},
		Width: {
			type: [String, Number],
			default: ""
		},
		Height: {
			type: [String, Number],
			default: ""
		},
		MinWidth: {
			type: [String, Number],
			default: 0
		},
		MinHeight: {
			type: [String, Number],
			default: 0
		},
		MaxWidth: {
			type: [String, Number],
			default: ""
		},
		MaxHeight: {
			type: [String, Number],
			default: ""
		},
		HorizontalAlignment: {
			type: String,
			default: "Stretch"
		},
		VerticalAlignment: {
			type: String,
			default: "Stretch"
		},
		Visibility: {
			type: String,
			default: "Visible"
		},
		Opacity: {
			type: [String, Number],
			default: 1
		}
	},
	setup(a, { expose: l }) {
		let u = a, d = o(), f = c(), p = s(null), m = (e) => r(u[e], d), h = i(() => ({
			...Object.fromEntries(Object.entries(f).filter(([e]) => e !== "style" && e !== "AutomationProperties.Name")),
			"aria-label": r(f["AutomationProperties.Name"], d)
		})), g = i(() => ({
			margin: n(m("Margin")),
			padding: n(m("Padding")),
			width: t(m("Width")),
			height: t(m("Height")),
			minWidth: t(m("MinWidth")),
			minHeight: t(m("MinHeight")),
			maxWidth: t(m("MaxWidth")),
			maxHeight: t(m("MaxHeight")),
			justifySelf: e(m("HorizontalAlignment"), "horizontal"),
			alignSelf: e(m("VerticalAlignment"), "vertical"),
			opacity: m("Opacity"),
			...m("Visibility") === "Collapsed" ? { display: "none" } : {}
		}));
		l({
			Element: p,
			get OverflowContentTarget() {
				return r(u.OverflowContentTarget, d);
			}
		});
		let _ = {
			props: u,
			instance: d,
			attrs: f,
			element: p,
			resolve: m,
			forwardedAttrs: h,
			style: g
		};
		return Object.defineProperty(_, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), _;
	}
});
//#endregion
export { l as default };

//# sourceMappingURL=RichTextBlockOverflow.vue_vue_type_script_setup_true_lang.js.map