import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./CaptureElement.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                                   */
import { createElementBlock as n, createElementVNode as r, normalizeStyle as i, openBlock as a } from "vue";
//#region src/components/CaptureElement.vue
function o(e, t, o, s, c, l) {
	return a(), n("div", {
		class: "win-capture-element",
		style: i(s.elementStyle)
	}, [r("video", {
		ref: "video",
		class: "win-capture-video",
		autoplay: "",
		muted: "",
		playsinline: "",
		style: i(s.videoStyle)
	}, null, 4)], 4);
}
var s = /*#__PURE__*/ e(t, [
	["render", o],
	["__scopeId", "data-v-85dbe703"],
	["__file", "CaptureElement.vue"]
]);
//#endregion
export { s as default };

//# sourceMappingURL=CaptureElement.vue.js.map