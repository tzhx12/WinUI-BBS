//#region src/components/mediaDecode.worker.ts?worker&inline
var e = "(function(){let e=self,t=null,n=async()=>{for(let e of[`https://cdn.jsdelivr.net/npm`,`https://unpkg.com`]){let t=`${e}/@ffmpeg/core@0.12.10/dist/esm`,n=``;try{let[e,r]=await Promise.all([fetch(`${t}/ffmpeg-core.js`,{signal:AbortSignal.timeout(45e3)}),fetch(`${t}/ffmpeg-core.wasm`,{signal:AbortSignal.timeout(45e3)})]);if(!e.ok||!r.ok)throw Error(`Media decoder download failed.`);let[i,a]=await Promise.all([e.blob(),r.arrayBuffer()]);n=URL.createObjectURL(new Blob([i],{type:`text/javascript`}));let{default:o}=await import(n);return await o({wasmBinary:new Uint8Array(a),mainScriptUrlOrBlob:`${t}/ffmpeg-core.js#${btoa(JSON.stringify({wasmURL:`${t}/ffmpeg-core.wasm`}))}`})}catch{}finally{n&&URL.revokeObjectURL(n)}}throw Error(`Media decoder is unavailable.`)};e.onmessage=async({data:r})=>{let i=`source.wmv`,a=`playback.mp4`,o=null;try{if(t||=n(),o=await t,o.FS.writeFile(i,new Uint8Array(r.bytes)),o.setTimeout(6e4),o.exec(`-i`,i,`-map`,`0:v:0`,`-map`,`0:a:0?`,`-c:v`,`libx264`,`-preset`,`ultrafast`,`-crf`,`20`,`-pix_fmt`,`yuv420p`,`-c:a`,`aac`,`-b:a`,`128k`,`-fps_mode`,`vfr`,`-movflags`,`+faststart`,`-threads`,`1`,a),o.ret!==0)throw Error(`Media conversion failed.`);let s=o.FS.readFile(a).slice().buffer;e.postMessage({id:r.id,bytes:s},[s])}catch{e.postMessage({id:r.id,error:!0}),o||(t=null)}finally{if(o){for(let e of[i,a])try{o.FS.unlink(e)}catch{}o.reset()}}}})();\n//# sourceMappingURL=mediaDecode.worker-Befy33Ck.js.map", t = typeof self < "u" && self.Blob && new Blob(["(self.URL || self.webkitURL).revokeObjectURL(self.location.href);", e], { type: "text/javascript;charset=utf-8" });
function n(n) {
	let r;
	try {
		if (r = t && (self.URL || self.webkitURL).createObjectURL(t), !r) throw "";
		let e = new Worker(r, { name: n?.name });
		return e.addEventListener("error", () => {
			(self.URL || self.webkitURL).revokeObjectURL(r);
		}), e;
	} catch {
		return new Worker("data:text/javascript;charset=utf-8," + encodeURIComponent(e), { name: n?.name });
	}
}
//#endregion
export { n as default };

//# sourceMappingURL=mediaDecode.worker.ts_worker_inline.js.map