import { xamlThemeKey as e } from "./brushCore.js";
import { useAcrylicBrushStyle as t } from "./AcrylicBrush.js";
import { resolveXamlHandler as n, resolveXamlValue as r, updateXamlBinding as i, xamlControlIdentityKey as a } from "./xamlRuntime.js";
import { vAcrylicBackdrop as o, vAcrylicBrush as s } from "./acrylicBrushVisual.js";
import { getThemeShadowRecipe as c } from "./themeShadowRuntime.js";
import { vThemeShadow as ee } from "./themeShadowVisual.js";
import { CommandPortal as te, commandBarProperty as ne, commandChildren as re, commandCollection as ie, commandHasIcon as ae, flattenCommandNodes as oe, isAppBarCommand as se, isCommandSeparator as ce, isCommandToggle as le } from "./commandBarRuntime.js";
import { fitPopupPosition as ue, popupBoundsFor as de, popupPlacementPosition as fe, resolvePopupElement as pe } from "./popupRuntime.js";
import { flyoutContainsNode as me, hasOpenDescendantFlyout as he, hideDescendantFlyouts as ge, isDescendantFlyoutOpening as _e, nestedFlyoutLayers as ve, registerFlyoutInputRegion as ye } from "./flyoutInput.js";
import { useI18n as be } from "./i18n/index.js";
/* empty css                        */
import { computed as l, defineComponent as xe, getCurrentInstance as Se, inject as Ce, isVNode as we, nextTick as u, onBeforeUnmount as Te, onMounted as Ee, onUpdated as De, provide as Oe, ref as d, shallowReactive as ke, shallowRef as Ae, unref as je, useAttrs as Me, useSlots as Ne, watch as Pe } from "vue";
var Fe = /*@__PURE__*/ xe({
	PrimaryCommands: ne("CommandBarFlyout", "PrimaryCommands"),
	SecondaryCommands: ne("CommandBarFlyout", "SecondaryCommands"),
	name: "CommandBarFlyout",
	inheritAttrs: !1,
	__name: "CommandBarFlyout",
	props: {
		PrimaryCommands: { default: void 0 },
		SecondaryCommands: { default: void 0 },
		AlwaysExpanded: {
			type: [Boolean, String],
			default: !1
		},
		Placement: {
			type: String,
			default: "Top"
		},
		ShowMode: {
			type: String,
			default: "Standard"
		},
		AreOpenCloseAnimationsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		ShouldConstrainToRootBounds: {
			type: [Boolean, String],
			default: !0
		},
		LightDismissOverlayMode: {
			type: String,
			default: "Auto"
		}
	},
	emits: [
		"Opening",
		"Opened",
		"Closing",
		"Closed",
		"update:PrimaryCommands",
		"update:SecondaryCommands",
		"update:AlwaysExpanded",
		"update:Placement",
		"update:ShowMode",
		"update:AreOpenCloseAnimationsEnabled",
		"update:ShouldConstrainToRootBounds",
		"update:LightDismissOverlayMode"
	],
	setup(ne, { expose: Fe, emit: Ie }) {
		let f = ne, Le = Ie, p = Se(), Re = Me(), ze = Ne(), { t: Be } = be(), m = (e) => r(e, p), h = (e) => e !== !1 && e !== "False" && e !== "false", Ve = ke({}), g = (e) => e in Ve ? Ve[e] : m(f[e]), _ = ie(ke([])), He = ie(ke([])), Ue = /* @__PURE__ */ new Set(), We = /* @__PURE__ */ new Map(), Ge = d(null), v = d(null), y = d(null), b = d(null), Ke = d(null), qe = d(null), x = /* @__PURE__ */ new Map(), Je = /* @__PURE__ */ new WeakMap(), Ye = 0, S = Ae(/* @__PURE__ */ new Set()), C = document.createElement("div");
		C.className = "commandbar-overflow-divider", C.setAttribute("role", "separator");
		let w = l(() => [..._.map((e) => Xe(e, !1)), ...He.map((e) => Xe(e, !0))]);
		function Xe(e, t) {
			let n = Je.get(e);
			n === void 0 && (n = ++Ye, Je.set(e, n));
			let r = x.get(n);
			if (!r) {
				let i = document.createElement("div");
				i.className = "commandbar-command-host", r = {
					id: n,
					node: e,
					host: i,
					secondary: t,
					width: ce(e) ? 5 : Number(m(e.props?.Width)) || 40
				}, x.set(n, r);
			}
			return r.secondary = t, r;
		}
		let T = l(() => w.value.filter((e) => e.secondary || S.value.has(e.id)).map((e) => e.node)), E = d(null), D = d(!1), O = d(!1), Ze = d(!1), k = d(!1), A = d(!1), Qe = d(!1), j = d({
			left: 0,
			top: 0
		}), $e = d(!1), et = d(!1), tt = l(() => Be(k.value ? "text.see-less" : "text.see-more")), nt = l(() => ({ "ToolTipService.ToolTip": tt.value })), M = d({
			width: 0,
			height: 0
		}), N = d(null), rt = d("Top"), it = Ce(e, null) ?? Ce("winuiTheme", null), at = d(0), ot = Ce("buttonFlyoutAnchor", null), st = Ce("buttonFlyoutController", null), ct = l(() => h(g("AlwaysExpanded")) ? "Standard" : String(N.value?.ShowMode || g("ShowMode"))), lt = l(() => _.length > 0 && T.value.length > 0 && !h(g("AlwaysExpanded"))), P = l(() => {
			at.value;
			let e = E.value?.closest("[data-theme], .win-theme-scope, .example-theme-wrapper, .theme-light, .theme-dark"), t = e?.getAttribute("data-theme")?.toLowerCase();
			return t === "light" || t === "dark" ? t : e?.classList.contains("theme-dark") ? "dark" : e?.classList.contains("theme-light") ? "light" : String(je(it) || "").toLowerCase();
		}), ut = l(() => P.value === "light" || P.value === "dark" ? `win-theme-scope theme-${P.value}` : "");
		Oe(e, P), Oe("winuiTheme", P);
		let dt = d(void 0), ft = t("{ThemeResource CommandBarFlyoutBackground}", p), pt = t("{StaticResource CommandBarFlyoutSystemBackdrop}", p), mt = l(() => {
			let e = c(32, P.value).Insets;
			return {
				zIndex: dt.value,
				left: `${j.value.left}px`,
				top: `${j.value.top}px`,
				"--cbf-available-width": `${M.value.width}px`,
				"--cbf-available-height": `${M.value.height}px`,
				"--cbf-shadow-top-inset": `${e.Top}px`,
				"--cbf-shadow-bottom-inset": `${e.Bottom}px`
			};
		}), ht = {
			isOpen: D,
			defaultLabelPosition: l(() => $e.value ? "Bottom" : "Collapsed"),
			compact: l(() => !0),
			isInOverflow: l(() => !1),
			isInFlyout: l(() => !0),
			hasIcons: l(() => T.value.some(ae)),
			hasToggleButtons: l(() => T.value.some(le)),
			closeOverflow: () => Q(),
			invokeCommand: () => Q()
		}, gt = xe({
			name: "CommandBarFlyoutDeclarationOutlet",
			setup() {
				return () => {
					let e = oe(ze.default?.() ?? []);
					for (let t of ["PrimaryCommands", "SecondaryCommands"]) {
						let n = m(f[t]), r = e.find((e) => e.type.__commandBarProperty === t), i = Array.isArray(n) ? n.filter(we) : oe(r ? re(r) : t === "PrimaryCommands" ? e.filter(se) : []), a = We.get(t), o = (e) => JSON.stringify(Object.entries(e.props || {}).filter(([, e]) => e === null || [
							"string",
							"number",
							"boolean"
						].includes(typeof e)));
						if (!Ue.has(t) || !a || a.length !== i.length || i.some((e, t) => e.type !== a[t].type || e.key !== a[t].key || o(e) !== o(a[t]))) {
							let e = t === "PrimaryCommands" ? _ : He;
							e.splice(0, e.length, ...i), Ue.add(t), We.set(t, i);
						}
					}
					return null;
				};
			}
		}), F = {
			ShowAt: At,
			Hide: Q
		}, I = {
			Owner: F,
			get IsOpen() {
				return D.value;
			},
			get Target() {
				return E.value;
			},
			get Presenter() {
				return v.value;
			},
			DismissLayer: null,
			Hide: Q
		}, _t = ye(I), vt = (e, t = {}) => {
			let r = p?.vnode.props?.[`on${e}`];
			if (r) for (let e of Array.isArray(r) ? r : [r]) e(F, t);
			else Le(e, F, t), n(Re[e], p)?.(F, t);
		}, L = 0, R = 0, z = 0, B = [], V = [], H = null, U = null, W = null, G = null, yt = null, bt = null, K = !1, xt = 0, q = () => {
			B.forEach((e) => e.cancel()), B = [];
		}, St = () => ({
			primary: y.value,
			secondary: b.value,
			more: y.value?.querySelector(".win-cbf-more-button") ?? null
		}), J = (e = !0) => {
			if (V.forEach((e) => e.cancel()), V = [], !e) return;
			let t = St();
			t.primary?.style.removeProperty("clip-path"), t.secondary?.style.removeProperty("clip-path"), t.more?.style.removeProperty("transform");
		}, Ct = () => {
			let e = St(), t = V.length ? {
				primaryClip: e.primary ? getComputedStyle(e.primary).clipPath : "none",
				secondaryClip: e.secondary ? getComputedStyle(e.secondary).clipPath : "none",
				moreTransform: e.more ? getComputedStyle(e.more).transform : "none"
			} : null;
			return J(!t), t && (e.primary?.style.setProperty("clip-path", t.primaryClip), e.secondary?.style.setProperty("clip-path", t.secondaryClip), e.more?.style.setProperty("transform", t.moreTransform)), t;
		}, wt = () => {
			if (!y.value || !Ke.value) return 0;
			let e = getComputedStyle(Ke.value), t = getComputedStyle(y.value), n = w.value.filter((e) => !e.secondary && !S.value.has(e.id)).reduce((e, t) => {
				let n = t.host.firstElementChild;
				if (!(n instanceof HTMLElement)) return e + t.width;
				let r = getComputedStyle(n);
				return e + n.offsetWidth + (parseFloat(r.marginLeft) || 0) + (parseFloat(r.marginRight) || 0);
			}, 0), r = St().more?.offsetWidth ?? 3, i = [
				e.marginLeft,
				e.marginRight,
				t.borderLeftWidth,
				t.borderRightWidth
			].reduce((e, t) => e + (parseFloat(t) || 0), 0);
			return Math.min(n + r + i, M.value.width, 440);
		}, Tt = () => h(g("AreOpenCloseAnimationsEnabled")) && !window.matchMedia("(prefers-reduced-motion: reduce)").matches, Et = (e, t) => Tt() ? (B = [y.value, b.value].filter((e) => !!e?.animate).map((n) => n.animate(e ? [{ opacity: 0 }, { opacity: 1 }] : [{ opacity: t || getComputedStyle(n).opacity }, { opacity: 0 }], {
			duration: 83,
			easing: "linear",
			fill: "both"
		})), Promise.all(B.map((e) => e.finished.catch(() => void 0))).then(() => void 0)) : Promise.resolve(), Dt = () => {
			let e = w.value.some((e) => {
				if (e.secondary) return !1;
				let t = e.host.querySelector(".win-appbar-button");
				return t?.dataset.labelPosition === "Default" && !!t.querySelector(".appbar-button-label")?.textContent?.trim();
			});
			e !== $e.value && ($e.value = e, $());
		}, Ot = () => {
			W?.disconnect(), v.value && W?.observe(v.value, {
				subtree: !0,
				childList: !0,
				characterData: !0,
				attributes: !0,
				attributeFilter: ["data-label-position"]
			});
		}, Y = () => {
			if (!Ke.value || !qe.value || K) return;
			let e = document.activeElement instanceof HTMLElement ? document.activeElement : null, t = e && w.value.some((t) => t.host.contains(e)), n = [], r = [], i = !1, a = w.value.some((e) => !e.secondary && S.value.has(e.id));
			for (let e of w.value) e.secondary && a && !i && (r.push(C), i = !0), (e.secondary || S.value.has(e.id) ? r : n).push(e.host);
			i || C.remove();
			for (let [e, t] of [[Ke.value, n], [qe.value, r]]) {
				let n = e.firstElementChild;
				for (let r of t) r !== n && e.insertBefore(r, n), n = r.nextElementSibling;
			}
			let o = new Set(w.value.map((e) => e.id));
			for (let [e, t] of x) o.has(e) || (t.host.remove(), x.delete(e));
			Dt(), t && e?.isConnected && document.activeElement !== e && (e.getClientRects().length ? e.focus({ preventScroll: !0 }) : y.value?.querySelector(".win-cbf-more-button")?.focus({ preventScroll: !0 }));
		}, kt = () => {
			let e = w.value.filter((e) => !e.secondary);
			for (let t of e) S.value.has(t.id) || (t.width = t.host.firstElementChild?.getBoundingClientRect().width || t.width);
			let t = /* @__PURE__ */ new Set(), n = Math.min(440, M.value.width), r = e.reduce((e, t) => e + t.width, 0), i = He.length > 0 || r + 6 > n, a = Math.max(0, n - (i && !h(g("AlwaysExpanded")) ? 44 : 0) - 6), o = r, s = [...e].sort((t, n) => (Number(m(t.node.props?.DynamicOverflowOrder)) || Infinity) - (Number(m(n.node.props?.DynamicOverflowOrder)) || Infinity) || e.indexOf(n) - e.indexOf(t));
			for (let n of s) {
				if (o <= a) break;
				let r = Number(m(n.node.props?.DynamicOverflowOrder) || 0), i = r ? e.filter((e) => Number(m(e.node.props?.DynamicOverflowOrder)) === r) : [n];
				for (let e of i) t.has(e.id) || (t.add(e.id), o -= e.width);
			}
			return t.size !== S.value.size || [...t].some((e) => !S.value.has(e)) ? (S.value = t, !0) : !1;
		}, X = async () => {
			if (!O.value || !v.value || !E.value) return;
			let e = ++z, t = E.value, n = v.value, r = de(t, h(g("ShouldConstrainToRootBounds")));
			if (M.value = {
				width: Math.max(0, r.width - 8),
				height: Math.max(0, r.height - 8)
			}, await u(), K || e !== z || !O.value || v.value !== n || E.value !== t) return;
			if (Y(), kt()) {
				if (await u(), K || e !== z || !O.value || v.value !== n || E.value !== t) return;
				Y();
			}
			let i = N.value?.Placement || String(g("Placement")), a = t.getBoundingClientRect(), o = {
				width: n.offsetWidth,
				height: n.offsetHeight
			}, s = fe(a, o, i, r, 4, getComputedStyle(t).direction === "rtl");
			rt.value = s.placement;
			let c = N.value?.Position;
			j.value = c ? ue({
				left: a.left + Number(c.X ?? c.x ?? 0),
				top: a.top + Number(c.Y ?? c.y ?? 0)
			}, o, r) : {
				left: s.left,
				top: s.top
			};
			let ee = y.value?.offsetHeight || 0, te = b.value?.offsetHeight || 0;
			Qe.value = rt.value.startsWith("Top") || r.bottom - j.value.top - ee < te && j.value.top >= te, Ze.value = !0;
		}, Z = (e) => Array.from(e?.querySelectorAll("button:not(:disabled), [tabindex]:not([tabindex=\"-1\"])") ?? []).filter((e) => e.getClientRects().length > 0);
		async function At(e, t) {
			let n = pe(e) || ot?.value || Ge.value?.parentElement || null;
			if (!n || K) return;
			let r = ++L;
			R += 1, q(), J(), et.value = !1, D.value || (yt = document.activeElement instanceof HTMLElement ? document.activeElement : null), E.value = n, N.value = t ?? null, dt.value = ve(I)?.presenter;
			let i = h(g("AlwaysExpanded")) || !_.length || ct.value === "Standard";
			k.value = i, A.value = i && T.value.length > 0, U?.disconnect();
			let a = n.closest("[data-theme], .win-theme-scope, .example-theme-wrapper, .theme-light, .theme-dark");
			if (a && U?.observe(a, {
				attributes: !0,
				attributeFilter: ["class", "data-theme"]
			}), U?.observe(document.documentElement, {
				attributes: !0,
				attributeFilter: ["class", "data-theme"]
			}), at.value += 1, D.value) {
				await X();
				return;
			}
			if (window.dispatchEvent(new CustomEvent("winui-flyout-opening", { detail: F })), vt("Opening"), D.value = !0, O.value = !0, Ze.value = !1, await u(), Ot(), await X(), r !== L || K || !D.value) return;
			H?.disconnect(), v.value && H?.observe(v.value), H?.observe(n), ct.value === "Standard" && (Z(y.value)[0] || Z(b.value)[0] || v.value)?.focus({ preventScroll: !0 });
			let o = Et(!0);
			vt("Opened"), await o, r === L && q();
		}
		function Q(e = !0) {
			if (!D.value) return;
			let t = { Cancel: !1 };
			if (vt("Closing", t), t.Cancel) return;
			let n = me(I, document.activeElement);
			ge(I);
			let r = ++L;
			R += 1;
			let i = y.value ?? b.value, a = i ? getComputedStyle(i).opacity : void 0;
			q(), Ct(), et.value = !0, D.value = !1, H?.disconnect(), e && n && (yt?.isConnected ? yt : E.value)?.focus({ preventScroll: !0 }), Et(!1, a).then(() => {
				r !== L || K || D.value || (q(), J(), O.value = !1, Ze.value = !1, k.value = !1, A.value = !1, vt("Closed"));
			});
		}
		async function jt(e) {
			if (!D.value || e === k.value || h(g("AlwaysExpanded")) || !T.value.length) return;
			let t = ++R, n = Ct();
			et.value = !0, e && (N.value = {
				...N.value,
				ShowMode: "Standard"
			}, A.value = !0), k.value = e, await u(), await X();
			let r = v.value;
			if (!r || t !== R) return;
			let i = St(), a = Math.max(0, r.offsetWidth - wt()) / 2, o = (i.secondary?.offsetHeight || 0) / 2, s = `inset(0px ${a}px 0px 0px)`, c = Qe.value ? `inset(${o}px ${a}px 0px 0px)` : `inset(0px ${a}px ${o}px 0px)`, ee = "inset(0px 0px 0px 0px)", te = `translateX(${-a}px)`;
			if (typeof r.animate == "function" && Tt()) {
				let t = {
					duration: e ? 250 : 167,
					easing: "cubic-bezier(0, 0, 0, 1)",
					fill: "both"
				}, r = (n, r, i) => n ? n.animate([{ clipPath: i || (e ? r : ee) }, { clipPath: e ? ee : r }], t) : null, a = [r(i.primary, s, n?.primaryClip), r(i.secondary, c, n?.secondaryClip)], o = i.more?.animate([{ transform: n?.moreTransform || (e ? te : "translateX(0px)") }, { transform: e ? "translateX(0px)" : te }], t);
				V = [...a, o].filter((e) => !!e), await Promise.all(V.map((e) => e.finished.catch(() => void 0)));
			}
			t !== R || !D.value || (J(), e || (A.value = !1), await u(), await X(), t === R && D.value && (et.value = !1));
		}
		let Mt = (e) => {
			if (e.defaultPrevented || he(I)) return;
			if (e.key === "Escape") {
				e.preventDefault(), e.stopPropagation(), Q();
				return;
			}
			let t = b.value?.contains(e.target), n = Z(t ? b.value : y.value), r = n.indexOf(document.activeElement);
			if (!t && e.key === "ArrowDown" && T.value.length) {
				e.preventDefault(), jt(!0).then(() => Z(b.value)[0]?.focus({ preventScroll: !0 }));
				return;
			}
			let i = t ? ["ArrowUp", "ArrowDown"] : ["ArrowLeft", "ArrowRight"];
			if ([
				...i,
				"Home",
				"End"
			].includes(e.key) && n.length) {
				e.preventDefault(), n[e.key === "Home" ? 0 : e.key === "End" ? n.length - 1 : (r + (e.key === i[0] ? -1 : 1) + n.length) % n.length].focus({ preventScroll: !0 });
				return;
			}
			if (e.key === "Tab" && ct.value === "Standard") {
				let t = Z(v.value), n = t.indexOf(document.activeElement);
				t.length && (e.shiftKey && n <= 0 || !e.shiftKey && n === t.length - 1) && (e.preventDefault(), t[e.shiftKey ? t.length - 1 : 0].focus({ preventScroll: !0 }));
			}
		}, Nt = (e) => {
			if (D.value) {
				if (me(I, e.target)) {
					xt = performance.now();
					return;
				}
				E.value?.contains(e.target) || Q(!1);
			}
		}, Pt = (e) => {
			!D.value || e.key !== "Escape" || e.defaultPrevented || he(I) || me(I, e.target) || (e.preventDefault(), Q());
		}, $ = () => {
			!D.value || G !== null || (G = requestAnimationFrame(() => {
				G = null, X();
			}));
		}, Ft = () => Q(!1), It = (e) => {
			let t = e.detail;
			t !== F && !_e(t, I) && !me(I, document.activeElement) && performance.now() - xt > 1e3 && Q();
		}, Lt = () => {
			At(ot?.value);
		};
		for (let e of Object.keys(f)) e === "PrimaryCommands" || e === "SecondaryCommands" || (Object.defineProperty(F, e, {
			enumerable: !0,
			get: () => g(e),
			set: (t) => {
				Ve[e] = t, i(f[e], t, p), Le(`update:${e}`, t), $();
			}
		}), Pe(() => m(f[e]), () => {
			delete Ve[e], $();
		}));
		for (let e of ["PrimaryCommands", "SecondaryCommands"]) {
			let t = e === "PrimaryCommands" ? _ : He;
			Object.defineProperty(F, e, {
				enumerable: !0,
				get: () => t,
				set: (n) => {
					if (!Array.isArray(n) || n.some((e) => !we(e))) throw TypeError(`${e} requires AppBar command elements`);
					t.splice(0, t.length, ...n), Le(`update:${e}`, t), $();
				}
			}), Pe(() => {
				let t = m(f[e]);
				return Array.isArray(t) ? [...t] : void 0;
			}, (e) => {
				e && t.splice(0, t.length, ...e.filter(we));
			});
		}
		Object.defineProperty(F, "IsOpen", {
			enumerable: !0,
			get: () => D.value
		}), Object.defineProperty(F, "Target", {
			enumerable: !0,
			get: () => E.value
		}), Ee(() => {
			Y(), H = new ResizeObserver($), U = new MutationObserver(() => {
				at.value += 1;
			}), W = new MutationObserver(Dt), st && (st.value = F), bt = ot?.value?.tagName === "BUTTON" ? ot.value : null, bt?.addEventListener("click", Lt), document.addEventListener("pointerdown", Nt, !0), document.addEventListener("keydown", Pt, !0), window.addEventListener("resize", $), window.addEventListener("scroll", $, !0), window.addEventListener("blur", Ft), window.addEventListener("winui-flyout-opening", It);
		}), Pe(() => w.value.map((e) => e.id), async () => {
			await u(), !K && (Y(), $());
		}), Pe(() => T.value.length, async (e) => {
			!D.value || K || (A.value = k.value && e > 0, await u(), !K && D.value && await X());
		}), De(Y), Te(() => {
			ge(I), _t(), K = !0, L += 1, R += 1, z += 1, q(), J(), H?.disconnect(), U?.disconnect(), W?.disconnect(), G !== null && cancelAnimationFrame(G), x.forEach((e) => e.host.remove()), C.remove(), st?.value === F && (st.value = null), bt?.removeEventListener("click", Lt), document.removeEventListener("pointerdown", Nt, !0), document.removeEventListener("keydown", Pt, !0), window.removeEventListener("resize", $), window.removeEventListener("scroll", $, !0), window.removeEventListener("blur", Ft), window.removeEventListener("winui-flyout-opening", It);
		}), Object.defineProperty(F, a, { value: !0 }), Fe(F);
		let Rt = {
			props: f,
			emit: Le,
			instance: p,
			attrs: Re,
			slots: ze,
			t: Be,
			resolve: m,
			enabled: h,
			overrides: Ve,
			value: g,
			primaryCommands: _,
			secondaryCommands: He,
			initialized: Ue,
			lastDeclarations: We,
			anchor: Ge,
			flyout: v,
			primaryRoot: y,
			overflowRoot: b,
			primaryMount: Ke,
			secondaryMount: qe,
			retainedEntries: x,
			nodeIds: Je,
			get nextId() {
				return Ye;
			},
			set nextId(e) {
				Ye = e;
			},
			overflowIds: S,
			overflowDivider: C,
			entries: w,
			entryFor: Xe,
			overflowNodes: T,
			target: E,
			isOpen: D,
			isPresent: O,
			positioned: Ze,
			expanded: k,
			expandedPresent: A,
			expandsUp: Qe,
			position: j,
			hasPrimaryLabels: $e,
			suppressShadow: et,
			moreButtonLabel: tt,
			moreButtonAttributes: nt,
			available: M,
			options: N,
			actualPlacement: rt,
			inheritedTheme: it,
			themeRevision: at,
			buttonAnchor: ot,
			buttonController: st,
			showMode: ct,
			showMore: lt,
			theme: P,
			themeClass: ut,
			flyoutLayer: dt,
			flyoutBackgroundStyle: ft,
			flyoutBackdropStyle: pt,
			flyoutStyle: mt,
			commonContext: ht,
			DeclarationOutlet: gt,
			api: F,
			inputRegion: I,
			unregisterInputRegion: _t,
			raise: vt,
			get generation() {
				return L;
			},
			set generation(e) {
				L = e;
			},
			get expandGeneration() {
				return R;
			},
			set expandGeneration(e) {
				R = e;
			},
			get positionGeneration() {
				return z;
			},
			set positionGeneration(e) {
				z = e;
			},
			get animations() {
				return B;
			},
			set animations(e) {
				B = e;
			},
			get expansionAnimations() {
				return V;
			},
			set expansionAnimations(e) {
				V = e;
			},
			get resizeObserver() {
				return H;
			},
			set resizeObserver(e) {
				H = e;
			},
			get themeObserver() {
				return U;
			},
			set themeObserver(e) {
				U = e;
			},
			get commandObserver() {
				return W;
			},
			set commandObserver(e) {
				W = e;
			},
			get viewportFrame() {
				return G;
			},
			set viewportFrame(e) {
				G = e;
			},
			get previousFocus() {
				return yt;
			},
			set previousFocus(e) {
				yt = e;
			},
			get boundButton() {
				return bt;
			},
			set boundButton(e) {
				bt = e;
			},
			get unmounted() {
				return K;
			},
			set unmounted(e) {
				K = e;
			},
			get lastInsidePointer() {
				return xt;
			},
			set lastInsidePointer(e) {
				xt = e;
			},
			stopAnimations: q,
			expansionElements: St,
			stopExpansion: J,
			freezeExpansion: Ct,
			collapsedPrimaryWidth: wt,
			animationsEnabled: Tt,
			animateOpacity: Et,
			syncPrimaryLabels: Dt,
			observeCommandFlyout: Ot,
			mountCommands: Y,
			calculateOverflow: kt,
			updatePosition: X,
			focusable: Z,
			ShowAt: At,
			Hide: Q,
			setExpanded: jt,
			onKeyDown: Mt,
			onPointerDown: Nt,
			onGlobalKeyDown: Pt,
			onViewport: $,
			onWindowBlur: Ft,
			onOtherOpening: It,
			onButtonClick: Lt,
			get CommandPortal() {
				return te;
			},
			get vAcrylicBackdrop() {
				return o;
			},
			get vAcrylicBrush() {
				return s;
			},
			get vThemeShadow() {
				return ee;
			}
		};
		return Object.defineProperty(Rt, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), Rt;
	}
});
//#endregion
export { Fe as default };

//# sourceMappingURL=CommandBarFlyout.vue_vue_type_script_setup_true_lang.js.map