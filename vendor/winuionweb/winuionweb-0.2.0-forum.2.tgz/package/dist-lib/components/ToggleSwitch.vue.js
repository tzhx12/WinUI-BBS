import { resolveXamlHandler as e, resolveXamlValue as t, updateXamlBinding as n, xamlScopeKey as r } from "./xamlRuntime.js";
import i from "../_virtual/_plugin-vue_export-helper.js";
import { useI18n as a } from "./i18n/index.js";
import ee from "./TextBlock.vue.js";
/* empty css                                                 */
import { computed as o, createBlock as s, createCommentVNode as c, createElementBlock as l, createElementVNode as u, createVNode as d, getCurrentInstance as f, normalizeClass as p, normalizeStyle as m, onBeforeUnmount as h, openBlock as g, provide as _, ref as v, renderSlot as y, useAttrs as b, watch as x, withCtx as S, withModifiers as C } from "vue";
//#region src/components/ToggleSwitch.vue
var w = 0, T = 20, E = 3, D = {
	__name: "ToggleSwitch",
	props: {
		IsOn: {
			type: [Boolean, String],
			default: void 0
		},
		Header: {
			type: [String, Number],
			default: ""
		},
		OnContent: {
			type: [String, Number],
			default: ""
		},
		OffContent: {
			type: [String, Number],
			default: ""
		},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		FlowDirection: {
			type: String,
			default: ""
		},
		Width: {
			type: [String, Number],
			default: ""
		},
		MinWidth: {
			type: [String, Number],
			default: ""
		},
		Margin: {
			type: [String, Number],
			default: ""
		},
		modelValue: {
			type: Boolean,
			default: void 0
		},
		onContent: {
			type: String,
			default: ""
		},
		offContent: {
			type: String,
			default: ""
		},
		disabled: Boolean
	},
	emits: [
		"update:IsOn",
		"Toggled",
		"update:modelValue"
	],
	setup(i, { expose: s, emit: c }) {
		let { t: l } = a(), u = f(), d = b(), p = i, m = c, g = v(!1), y = v(!1), S = v(0), C = v(null), D = o(() => t(p.IsOn, u)), O = o(() => t(p.modelValue, u)), k = v(D.value ?? O.value ?? !1), A = o(() => k.value), j = o(() => t(p.IsEnabled, u) !== !1 && !p.disabled), M = v(void 0), N = o(() => M.value ?? j.value);
		x([D, O], ([e, t]) => {
			k.value = e ?? t ?? k.value;
		}), x(j, () => {
			M.value = void 0;
		});
		let P = o(() => t(p.Header, u)), F = o(() => t(p.OnContent || p.onContent || l("text.on"), u)), I = o(() => t(p.OffContent || p.offContent || l("text.off"), u)), L = o(() => P.value), R = o(() => A.value ? F.value : I.value), te = `toggle-switch-header-${u?.uid ?? "control"}`, z = (e) => e === "" || e == null ? "" : typeof e == "string" && e.trim() !== "" && !Number.isNaN(Number(e.trim())) ? `${Number(e.trim())}px` : typeof e == "number" ? `${e}px` : e, ne = o(() => {
			let e = String(t(p.Margin, u) ?? "").split(",").map((e) => z(e.trim()));
			return {
				width: p.Width === "" ? void 0 : z(t(p.Width, u)),
				minWidth: p.MinWidth === "" ? void 0 : z(t(p.MinWidth, u)),
				margin: p.Margin === "" ? void 0 : e.length === 4 ? `${e[1]} ${e[2]} ${e[3]} ${e[0]}` : e.length === 2 ? `${e[1]} ${e[0]}` : e[0]
			};
		}), B = 0, V = !1, H = !1, U = !1, W = null, G = null, K = null;
		x(A, (e) => {
			g.value || (S.value = e ? T : w);
		}, { immediate: !0 });
		let re = o(() => g.value || y.value ? { "--tx": S.value + "px" } : {}), ie = () => {
			U = !1, N.value && C.value?.focus({ preventScroll: !0 });
		}, ae = () => {
			if (N.value) {
				if (U) {
					U = !1;
					return;
				}
				q(!A.value);
			}
		}, q = (t, r = !1) => {
			if (t = !!t, !r && !N.value || t === !!A.value) return;
			k.value = t, m("update:IsOn", t), n(p.IsOn, t, u), m("update:modelValue", t);
			let i = { IsOn: t }, a = u?.vnode.props?.onToggled;
			typeof a == "function" ? a(i) : Array.isArray(a) ? a.forEach((e) => e(i)) : e(d.Toggled, u)?.(i);
		}, J = o({
			get: () => !!A.value,
			set: (e) => q(e, !0)
		}), Y = o({
			get: () => !!N.value,
			set: (e) => {
				M.value = !!e, n(p.IsEnabled, !!e, u);
			}
		});
		s({
			IsOn: J,
			IsEnabled: Y,
			Element: C
		}), _(r, {
			ToggleSwitchHeader: L,
			ToggleSwitchContent: R
		});
		let oe = (e) => {
			if (!(!N.value || W !== null || e.isPrimary === !1 || e.pointerType === "mouse" && e.button !== 0)) {
				K = null, C.value?.focus({ preventScroll: !0 }), y.value = !0, g.value = !0, H = !1, U = !1, W = e.pointerId, G = e.currentTarget, B = e.clientX, V = !!A.value, S.value = V ? T : w;
				try {
					G.setPointerCapture?.(e.pointerId);
				} catch {}
			}
		}, se = (e) => {
			if (!g.value || e.pointerId !== W) return;
			let t = e.clientX - B;
			Math.abs(t) > E && (H = !0);
			let n = V ? T + t : w + t;
			S.value = Math.max(w, Math.min(T, n));
		}, ce = (e) => {
			if (!g.value || e.pointerId !== W) return;
			let t = H, n = V, r = S.value;
			if (X(), U = !0, t) {
				let e = (T - w) / 2;
				q((n ? r <= e : r >= e) ? !n : n);
			} else q(!n);
		}, X = () => {
			let e = G, t = W;
			if (W = null, G = null, g.value = !1, y.value = !1, S.value = A.value ? T : w, H = !1, e && t !== null && e.hasPointerCapture?.(t)) try {
				e.releasePointerCapture(t);
			} catch {}
		}, le = (e) => {
			!g.value || e.pointerId !== W || (X(), U = !0);
		}, ue = (e) => {
			!g.value || e.pointerId !== W || (X(), U = !0);
		}, Z = (e) => e.key === "Spacebar" ? " " : e.key, Q = new Set([
			" ",
			"ArrowLeft",
			"ArrowRight",
			"ArrowUp",
			"ArrowDown",
			"Home",
			"End"
		]), de = (e) => {
			let t = Z(e);
			!N.value || !Q.has(t) || (e.preventDefault(), !(e.repeat || K !== null || g.value) && (K = t, U = !1));
		}, fe = (e) => {
			let n = Z(e);
			if (!Q.has(n)) return;
			e.preventDefault();
			let r = n === K;
			if (K = null, !(!r || !N.value || g.value)) if (n === " ") q(!A.value);
			else {
				let e = String(t(p.FlowDirection, u)), r = e === "RightToLeft" || !e && C.value && getComputedStyle(C.value).direction === "rtl";
				q(n === "ArrowUp" || n === "End" || (r ? n === "ArrowLeft" : n === "ArrowRight"));
			}
		}, pe = () => {
			K = null, g.value || (y.value = !1);
		};
		x(N, (e) => {
			e || (K = null, X(), U = !0);
		}), h(() => {
			X(), K = null;
		});
		let $ = {
			t: l,
			instance: u,
			attrs: d,
			props: p,
			emit: m,
			isDragging: g,
			isPressed: y,
			currentTx: S,
			wrapRef: C,
			resolvedIsOn: D,
			resolvedModelValue: O,
			internalIsOn: k,
			isOnValue: A,
			sourceIsEnabled: j,
			localIsEnabled: M,
			IsEnabledResolved: N,
			resolvedHeader: P,
			resolvedOnContent: F,
			resolvedOffContent: I,
			ToggleSwitchHeader: L,
			ToggleSwitchContent: R,
			headerId: te,
			cssLength: z,
			rootStyle: ne,
			get startX() {
				return B;
			},
			set startX(e) {
				B = e;
			},
			get initialChecked() {
				return V;
			},
			set initialChecked(e) {
				V = e;
			},
			get moved() {
				return H;
			},
			set moved(e) {
				H = e;
			},
			get didToggle() {
				return U;
			},
			set didToggle(e) {
				U = e;
			},
			get activePointerId() {
				return W;
			},
			set activePointerId(e) {
				W = e;
			},
			get pointerTarget() {
				return G;
			},
			set pointerTarget(e) {
				G = e;
			},
			get handledKey() {
				return K;
			},
			set handledKey(e) {
				K = e;
			},
			minKnobTranslation: w,
			maxKnobTranslation: T,
			movementThreshold: E,
			knobStyle: re,
			onWrapPointerDown: ie,
			onWrapClick: ae,
			setIsOn: q,
			exposedIsOn: J,
			exposedIsEnabled: Y,
			onDown: oe,
			onMove: se,
			onUp: ce,
			clearPointerState: X,
			onCancel: le,
			onLostPointerCapture: ue,
			keyName: Z,
			handledKeys: Q,
			onKeyDown: de,
			onKeyUp: fe,
			onBlur: pe,
			ref: v,
			computed: o,
			getCurrentInstance: f,
			provide: _,
			useAttrs: b,
			watch: x,
			onBeforeUnmount: h,
			get useI18n() {
				return a;
			},
			TextBlock: ee,
			get resolveXamlHandler() {
				return e;
			},
			get resolveXamlValue() {
				return t;
			},
			get updateXamlBinding() {
				return n;
			},
			get xamlScopeKey() {
				return r;
			}
		};
		return Object.defineProperty($, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), $;
	}
}, O = [
	"tabindex",
	"aria-checked",
	"aria-disabled",
	"aria-labelledby",
	"aria-label"
];
function k(e, t, n, r, i, a) {
	return g(), l("div", {
		class: "win-switch-root",
		style: m(r.rootStyle)
	}, [r.resolvedHeader ? (g(), l("div", {
		key: 0,
		id: r.headerId,
		class: "win-switch-header"
	}, [d(r.TextBlock, { Text: "{x:Bind ToggleSwitchHeader}" })])) : c("", !0), u("div", {
		ref: "wrapRef",
		class: p(["win-switch-wrap", { "is-disabled": !r.IsEnabledResolved }]),
		role: "switch",
		tabindex: r.IsEnabledResolved ? 0 : -1,
		"aria-checked": r.isOnValue ? "true" : "false",
		"aria-disabled": r.IsEnabledResolved ? void 0 : "true",
		"aria-labelledby": r.resolvedHeader ? r.headerId : void 0,
		"aria-label": r.resolvedHeader ? void 0 : String(r.ToggleSwitchContent),
		onPointerdown: r.onWrapPointerDown,
		onClick: r.onWrapClick,
		onKeydown: r.onKeyDown,
		onKeyup: r.onKeyUp,
		onBlur: r.onBlur
	}, [u("div", {
		class: p(["win-switch", {
			"is-on": r.isOnValue,
			dragging: r.isDragging,
			"is-pressed": r.isPressed,
			"is-disabled": !r.IsEnabledResolved
		}]),
		onPointerdown: C(r.onDown, ["stop"]),
		onPointermove: r.onMove,
		onPointerup: r.onUp,
		onPointercancel: r.onCancel,
		onLostpointercapture: r.onLostPointerCapture
	}, [t[1] ||= u("div", { class: "track" }, null, -1), u("div", {
		class: "knob",
		style: m(r.knobStyle)
	}, [...t[0] ||= [u("div", { class: "thumb" }, null, -1)]], 4)], 34), e.$slots.default ? (g(), s(r.TextBlock, {
		key: 0,
		class: "win-switch-label"
	}, {
		default: S(() => [y(e.$slots, "default")]),
		_: 3
	})) : (g(), s(r.TextBlock, {
		key: 1,
		class: "win-switch-label",
		Text: "{x:Bind ToggleSwitchContent}"
	}))], 42, O)], 4);
}
var A = /*#__PURE__*/ i(D, [["render", k], ["__file", "ToggleSwitch.vue"]]);
//#endregion
export { A as default };

//# sourceMappingURL=ToggleSwitch.vue.js.map