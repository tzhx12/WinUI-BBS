import { xamlThickness as e } from "./layout.js";
import { xamlThemeKey as t } from "./brushCore.js";
import { primitiveResourceScope as n, primitiveResourceStyles as r, xamlPrimitiveResourceKey as i } from "./xamlPrimitives.js";
import { resolveAcrylicResource as a, resolveBrushStyle as o } from "./AcrylicBrush.js";
import { normalizeXamlNodes as s, resolveXamlHandler as c, resolveXamlValue as ee, updateXamlBinding as te, xamlControlIdentityKey as ne, xamlNameScopeKey as re, xamlTemplateComponent as ie } from "./xamlRuntime.js";
import { frameworkLayoutStyle as ae } from "./frameworkLayout.js";
import { collectXamlResources as oe, useXamlBrushResources as se } from "./xamlBrushResources.js";
import { useI18n as ce } from "./i18n/index.js";
import { xamlResourceDictionaryKey as le } from "./Page.vue_vue_type_script_lang.js";
import ue from "./FontIcon.vue.js";
import { isHoverPointer as de } from "./pointerInput.js";
import { pivotChildren as fe, pivotNodes as pe, pivotRootAttributes as me, pivotTemplate as he, pivotText as ge, pivotTypeName as _e, renderPivotPresenter as ve } from "./PivotProperties.js";
import { TabViewTemplateToolTip as ye } from "./tabViewToolTip.js";
import { getTabViewProperty as be, tabViewItemLiveControlKey as xe, tabViewItemOwnerKey as Se, tabViewItemRecordKey as Ce, tabViewItemTransferKey as we, tabViewProperties as Te, tabViewPropertyChildren as Ee } from "./TabViewProperties.js";
/* empty css                  */
import De from "./TabViewItem.vue.js";
import { activeTabViewDrag as l, cancelTabViewDrag as u, createTabViewDataPackage as Oe, endTabViewDrag as d, moveTabViewDrag as f, registerTabViewDragEndpoint as ke, startTabViewDrag as Ae } from "./tabViewRuntime.js";
import { tabViewNativeDragBridgeKey as je, tabViewNativeDropHandledKey as Me } from "./tabViewNativeDragBridge.js";
import { Fragment as Ne, cloneVNode as Pe, computed as p, defineComponent as Fe, getCurrentInstance as Ie, h as Le, inject as Re, isVNode as ze, nextTick as Be, onBeforeUnmount as Ve, onMounted as He, onUpdated as Ue, provide as m, ref as h, shallowReactive as We, shallowRef as Ge, triggerRef as Ke, useAttrs as qe, useSlots as Je, watch as Ye } from "vue";
var Xe = /*@__PURE__*/ Fe({
	...Te,
	name: "TabView",
	inheritAttrs: !1,
	__name: "TabView",
	props: {
		TabWidthMode: {
			type: null,
			default: "Equal"
		},
		CloseButtonOverlayMode: {
			type: null,
			default: "Auto"
		},
		TabStripHeader: {
			type: null,
			default: null
		},
		TabStripHeaderTemplate: {
			type: null,
			default: null
		},
		TabStripFooter: {
			type: null,
			default: null
		},
		TabStripFooterTemplate: {
			type: null,
			default: null
		},
		IsAddTabButtonVisible: {
			type: null,
			default: !0
		},
		AddTabButtonCommand: {
			type: null,
			default: null
		},
		AddTabButtonCommandParameter: {
			type: null,
			default: null
		},
		TabItemsSource: {
			type: null,
			default: null
		},
		TabItemTemplate: {
			type: null,
			default: null
		},
		TabItemTemplateSelector: {
			type: null,
			default: null
		},
		CanDragTabs: {
			type: null,
			default: !1
		},
		CanReorderTabs: {
			type: null,
			default: !0
		},
		AllowDropTabs: {
			type: null,
			default: !0
		},
		CanTearOutTabs: {
			type: null,
			default: !1
		},
		SelectedIndex: {
			type: null,
			default: 0
		},
		SelectedItem: {
			type: null,
			default: void 0
		},
		IsEnabled: {
			type: null,
			default: !0
		},
		IsTabStop: {
			type: null,
			default: !1
		},
		Visibility: {
			type: null,
			default: "Visible"
		},
		Background: {
			type: null,
			default: "{ThemeResource TabViewBackground}"
		},
		Foreground: {
			type: null,
			default: ""
		},
		BorderBrush: {
			type: null,
			default: ""
		},
		BorderThickness: {
			type: null,
			default: 0
		},
		CornerRadius: {
			type: null,
			default: 0
		},
		Margin: {
			type: null,
			default: 0
		},
		Padding: {
			type: null,
			default: "{ThemeResource TabViewHeaderPadding}"
		},
		Width: {
			type: null,
			default: ""
		},
		Height: {
			type: null,
			default: ""
		},
		MinWidth: {
			type: null,
			default: ""
		},
		MinHeight: {
			type: null,
			default: ""
		},
		MaxWidth: {
			type: null,
			default: ""
		},
		MaxHeight: {
			type: null,
			default: ""
		},
		HorizontalAlignment: {
			type: null,
			default: "Stretch"
		},
		VerticalAlignment: {
			type: null,
			default: "Top"
		},
		RequestedTheme: {
			type: null,
			default: "Default"
		},
		FlowDirection: {
			type: null,
			default: ""
		},
		Opacity: {
			type: null,
			default: 1
		},
		IsHitTestVisible: {
			type: null,
			default: !0
		}
	},
	emits: [
		"Loaded",
		"SelectionChanged",
		"TabCloseRequested",
		"TabDroppedOutside",
		"AddTabButtonClick",
		"TabItemsChanged",
		"TabDragStarting",
		"TabDragCompleted",
		"TabStripDragOver",
		"TabStripDrop",
		"TabTearOutWindowRequested",
		"TabTearOutRequested",
		"ExternalTornOutTabsDropping",
		"ExternalTornOutTabsDropped",
		"update:SelectedIndex",
		"update:SelectedItem"
	],
	setup(Te, { expose: Xe, emit: Ze }) {
		let g = Te, Qe = Ze, _ = Ie(), $e = qe(), et = Je(), { t: tt } = ce(), nt = Re(je, null), v = h(null), y = h(null), b = h(null), rt = h(null), it = h(null), at = h(null), ot = h(null), st = h(null), ct = h(null), lt = h(null), ut = h(null), dt = h(null), ft = h(null), pt = We({}), mt = Ge(null), x = We(/* @__PURE__ */ new Map()), S = Ge(null), ht = Ge(null), gt = /* @__PURE__ */ new Map(), C = /* @__PURE__ */ new Map(), _t = h(0), vt = h(0), yt = h(!1), bt = h(0), xt = h(0), w = h(-1), St = h(!1), T = h(null), Ct = h("ltr"), E = !1, wt, D = 0, Tt = !1, O = null, Et = !1, k = 0, A = 0, j = 0, Dt = !1, M = null, N = null, P = /* @__PURE__ */ new Map(), Ot = 0, kt, F = /* @__PURE__ */ new Map(), At = /* @__PURE__ */ new Set(), I = (e) => ee(e, _), L = (e) => {
			let t = e in pt ? pt[e] : g[e];
			return /Template$/.test(e) && typeof t == "string" && /^\{(?:StaticResource|ThemeResource)\s/.test(t) ? t : I(t);
		}, R = p(() => L("IsEnabled") !== !1), jt = p(() => String(L("TabWidthMode"))), z = p(() => L("FlowDirection") === "RightToLeft" ? "rtl" : L("FlowDirection") === "LeftToRight" ? "ltr" : Ct.value), Mt = p(() => ["Light", "Dark"].includes(String(L("RequestedTheme"))) ? String(L("RequestedTheme")).toLowerCase() : void 0), Nt = p(() => pe(et.default?.() ?? [])), B = (e) => Ee(Nt.value, "TabView", e), Pt = Re(i, null), Ft = n(() => Nt.value, Pt);
		m(i, Ft);
		let It = Re(le, {}), Lt = Object.create(It);
		m(le, Lt);
		let Rt = Re(re, {}), zt = se(_, Rt), Bt = Ge([]), Vt = Re(t, null);
		m(t, p(() => Mt.value ?? (Vt && typeof Vt == "object" && "value" in Vt ? Vt.value : Vt)));
		let Ht = p(() => Object.fromEntries(Bt.value.map((e) => {
			let t = a(e, _);
			return [`--${e}`, o(t, _).background];
		}).filter(([, e]) => e !== void 0))), Ut = (e, t) => {
			let n = Number(Ft.value[e] ?? I(`{ThemeResource ${e}}`));
			return Number.isFinite(n) ? n : t;
		}, Wt = /* @__PURE__ */ new WeakMap(), Gt = /* @__PURE__ */ new Map(), Kt = 0, qt = (e) => {
			let t = e && typeof e == "object" ? Wt : Gt;
			return t.has(e) || t.set(e, `tab-${++Kt}`), t.get(e);
		}, V = p(() => {
			let e = L("TabItemsSource"), t = e && typeof e[Symbol.iterator] == "function" ? Array.from(e) : mt.value ?? (B("TabItems").length ? B("TabItems") : Nt.value.filter((e) => !be(e, "TabView"))), n = /* @__PURE__ */ new Map();
			return t.map((e, t) => {
				let r = ze(e) ? e.props?.__tabViewRecordKey ?? e.key ?? `tab-view-${_?.uid}:markup:${t}` : qt(e), i = n.get(r) ?? 0;
				return n.set(r, i + 1), {
					Key: `${String(r)}${i ? `:duplicate:${i}` : ""}`,
					Item: e,
					Index: t,
					Node: ze(e) ? e : null
				};
			});
		}), Jt = p(() => V.value.findIndex((e) => e.Key === S.value)), Yt = p(() => V.value[Jt.value] ?? null), H = (e) => (_t.value, e ? gt.get(e.Key) ?? null : null), U = (e) => e ? e.Node ? e.Node.props?.__tabViewPublicItem ?? H(e) ?? e.Item : e.Item : null, W = (e) => V.value.find((t) => t.Item === e || U(t) === e || H(t) === e), G = (e) => H(e)?.IsEnabled !== !1 && I(e.Node?.props?.IsEnabled ?? e.Item?.IsEnabled ?? !0) !== !1, Xt = (e) => `tab-view-${_?.uid}-${String(e).replace(/[^a-z\d_-]/gi, "-")}-panel`, Zt = p(() => T.value ?? Math.max(Ut("TabViewItemMinWidth", 100), Math.min(Ut("TabViewItemMaxWidth", 240), (vt.value - 8) / Math.max(1, V.value.length + +(w.value >= 0 && l.value?.Source !== Z))))), Qt = p(() => me($e, _)), $t = p(() => ({
			...ae({
				...Object.fromEntries(Object.keys(g).map((e) => [e, L(e)])),
				Padding: "",
				BorderThickness: "",
				BorderBrush: "",
				CornerRadius: ""
			}, _),
			...r(Ft.value),
			...Ht.value,
			minWidth: L("MinWidth") === "" ? void 0 : `min(${Number(L("MinWidth"))}px, 100%)`,
			color: L("Foreground") ? String(L("Foreground")) : void 0
		})), en = p(() => ({ padding: e(L("Padding")) })), tn = p(() => ({
			borderWidth: e(L("BorderThickness")),
			borderColor: L("BorderBrush") ? String(L("BorderBrush")) : void 0,
			borderRadius: `${Number(L("CornerRadius")) || 0}px`
		})), K = (e, t) => {
			let n = _?.vnode.props?.[`on${e}`];
			if (e === "Loaded" && n) {
				for (let e of Array.isArray(n) ? n : [n]) typeof e == "function" && e(Q, t);
				return;
			}
			Qe(e, Q, t), n || c($e[e], _)?.(Q, t);
		}, q = async (e, t) => {
			let n = _?.vnode.props?.[`on${e}`], r = Array.isArray(n) ? n : n ? [n] : [];
			for (let e of r) typeof e == "function" && await e(Q, t);
			await c($e[e], _)?.(Q, t);
		}, nn = (e = S.value) => {
			let t = C.get(e), n = b.value;
			if (!t || !n) return;
			let r = t.getBoundingClientRect(), i = n.getBoundingClientRect();
			r.left < i.left ? n.scrollBy({ left: r.left - i.left }) : r.right > i.right && n.scrollBy({ left: r.right - i.right }), qn();
		}, J = async (e, t = !0, n) => {
			let r = V.value[e] ?? null;
			if (r && !G(r) || r?.Key === S.value || !r && S.value === null) return;
			let i = n === void 0 ? U(Yt.value) : n, a = ft.value?.contains(document.activeElement) ?? !1;
			if (S.value = r?.Key ?? null, r) {
				let e = H(r);
				e && x.set(r.Key, {
					Content: e.Content,
					Template: e.ContentTemplate
				});
			}
			let o = U(r);
			Qe("update:SelectedIndex", r?.Index ?? -1), Qe("update:SelectedItem", o), te(g.SelectedIndex, r?.Index ?? -1, _), te(g.SelectedItem, o, _), t && K("SelectionChanged", {
				RemovedItems: i === null ? [] : [i],
				AddedItems: o === null ? [] : [o]
			}), await Be(), nn(), a && (ft.value?.querySelector("button:not(:disabled),a[href],input:not(:disabled),select:not(:disabled),textarea:not(:disabled),[tabindex=\"0\"]") ?? C.get(r?.Key))?.focus();
		}, rn = () => V.value.map((e) => e.Node ? Pe(e.Node, { __tabViewRecordKey: e.Key }) : e.Item), an = (e) => {
			e = e.map((e) => e && typeof e == "object" && !ze(e) && e[we] ? e[we] : e);
			let t = L("TabItemsSource");
			if (Array.isArray(t)) t.splice(0, t.length, ...e);
			else if (t && typeof t == "object" && "ReplaceAll" in t && typeof t.ReplaceAll == "function") t.ReplaceAll(e);
			else if (t && typeof t == "object" && "Clear" in t && "Append" in t && typeof t.Clear == "function" && typeof t.Append == "function") {
				t.Clear();
				let n = t.Append;
				e.forEach((e) => n.call(t, e));
			} else if (t) throw TypeError("TabItemsSource must expose a mutable collection to move tabs.");
			else mt.value = e;
		}, on = (e, t, n) => {
			let r = rn();
			n(r), an(r), K("TabItemsChanged", {
				CollectionChange: e,
				Index: t
			});
		}, Y = {
			GetAt: (e) => U(V.value[e]),
			Add: (e) => on("ItemInserted", V.value.length, (t) => {
				t.push(e);
			}),
			Append: (e) => Y.Add(e),
			Insert: (e, t) => Y.InsertAt(e, t),
			InsertAt: (e, t) => on("ItemInserted", e, (n) => {
				n.splice(e, 0, t);
			}),
			SetAt: (e, t) => on("ItemChanged", e, (n) => {
				n.splice(e, 1, t);
			}),
			RemoveAt: (e) => {
				e < 0 || e >= V.value.length || on("ItemRemoved", e, (t) => {
					t.splice(e, 1);
				});
			},
			Remove: (e) => {
				let t = W(e);
				return t && Y.RemoveAt(t.Index), !!t;
			},
			RemoveAtEnd: () => Y.RemoveAt(V.value.length - 1),
			Clear: () => on("Reset", 0, (e) => {
				e.length = 0;
			}),
			IndexOf: (e) => W(e)?.Index ?? -1,
			Contains: (e) => !!W(e),
			ReplaceAll: (e) => {
				an([...e]), K("TabItemsChanged", {
					CollectionChange: "Reset",
					Index: 0
				});
			}
		}, sn = new Proxy(Y, { get(e, t) {
			if (t === "Count" || t === "Size" || t === "length") return V.value.length;
			if (t === Symbol.iterator) return function* () {
				for (let e of V.value) yield U(e);
			};
			if (t in e) return e[t];
			if (typeof t == "string" && /^\d+$/.test(t)) return U(V.value[Number(t)]);
			let n = V.value.map(U), r = n[t];
			return typeof r == "function" ? r.bind(n) : r;
		} }), cn = async (e) => {
			let t = V.value.find((t) => t.Key === e), n = H(t);
			if (!R.value || !t || !G(t) || n?.IsClosable === !1) return;
			let r = C.get(e)?.contains(document.activeElement);
			jt.value === "Equal" && St.value && (T.value = Zt.value);
			let i = {
				Item: U(t),
				Tab: n
			};
			K("TabCloseRequested", i), n?.RaiseCloseRequested?.(i), await Be(), r && !V.value.some((t) => t.Key === e) && (C.get(V.value[Math.min(t.Index, V.value.length - 1)]?.Key) ?? ct.value)?.focus();
		}, ln = () => {
			if (!R.value) return;
			let e = L("AddTabButtonCommand"), t = L("AddTabButtonCommandParameter");
			e && e.CanExecute?.(t) === !1 || (e?.Execute?.(t), K("AddTabButtonClick", {}));
		}, un = p(() => {
			let e = L("AddTabButtonCommand");
			return R.value && e?.CanExecute?.(L("AddTabButtonCommandParameter")) !== !1;
		}), dn = (e, t) => {
			let n = V.value.findIndex((t) => t.Key === e), r = V.value.filter(G), i = r[r.findIndex((e) => e.Index === n) + t];
			i ? (ht.value = i.Key, C.get(i.Key)?.focus(), nn(i.Key)) : t > 0 && ct.value?.focus();
		}, fn = (e, t) => {
			if (![
				"ArrowLeft",
				"ArrowRight",
				"Home",
				"End"
			].includes(e.key)) return;
			e.preventDefault(), e.stopPropagation();
			let n = V.value.find((e) => e.Key === t), r = (e.key === "ArrowRight" ? 1 : -1) * (z.value === "rtl" ? -1 : 1);
			if (e.altKey && e.shiftKey && L("CanReorderTabs") !== !1 && n) {
				let e = Math.max(0, Math.min(V.value.length - 1, n.Index + r)), i = rn(), [a] = i.splice(n.Index, 1);
				i.splice(e, 0, a), an(i), K("TabItemsChanged", {
					CollectionChange: "Reset",
					Index: e
				}), Be(() => C.get(t)?.focus());
				return;
			}
			if (e.key === "Home" || e.key === "End") {
				let t = V.value.filter(G), n = e.key === "Home" ? t[0] : t.at(-1);
				n && C.get(n.Key)?.focus();
				return;
			}
			dn(t, r);
		}, pn = (e) => {
			if (R.value) {
				if (e.key === "Escape") {
					O = null, u(), xn();
					for (let e of F.values()) e.abort();
					return;
				}
				for (let t of B("KeyboardAccelerators")) {
					let n = t.props ?? {};
					if (I(n.IsEnabled ?? !0) === !1) continue;
					let r = String(I(n.Modifiers) ?? ""), i = String(I(n.Key) ?? "");
					if (!(e.key.toLowerCase() === i.replace(/^Number/, "").toLowerCase() && e.ctrlKey === /Control/.test(r) && e.shiftKey === /Shift/.test(r) && e.altKey === /Menu|Alt/.test(r))) continue;
					let a = {
						Handled: !1,
						Element: Q,
						OriginalEvent: e
					}, o = {
						Key: i,
						Modifiers: r,
						IsEnabled: !0
					};
					if (c(n.onInvoked ?? n.Invoked, _)?.(o, a), a.Handled) {
						e.preventDefault();
						return;
					}
				}
				if (e.ctrlKey && e.key === "F4") {
					e.preventDefault(), Yt.value && cn(Yt.value.Key);
					return;
				}
				if (e.ctrlKey && e.key === "Tab") {
					e.preventDefault();
					let t = V.value.filter(G);
					if (!t.length) return;
					let n = t[(t.findIndex((e) => e.Key === S.value) + (e.shiftKey ? -1 : 1) + t.length) % t.length];
					J(n.Index);
					return;
				}
			}
		}, mn = async (e) => {
			let t = W(e);
			if (!t || !R.value || L("CanTearOutTabs") !== !0 || F.has(t.Key)) return !1;
			let n = new AbortController();
			F.set(t.Key, n);
			let r = {
				Items: [U(t)],
				Tabs: [H(t)],
				SourceTabView: Q,
				Signal: n.signal,
				NewWindowId: null,
				Cancel: !1
			};
			try {
				if (await q("TabTearOutWindowRequested", r), E || !R.value || L("CanTearOutTabs") !== !0 || n.signal.aborted || r.Cancel || r.NewWindowId === null || r.NewWindowId === void 0) return n.abort(), !1;
				let e = {
					Items: r.Items,
					Tabs: r.Tabs,
					SourceTabView: Q,
					Signal: n.signal,
					NewWindowId: r.NewWindowId,
					Cancel: !1
				};
				return await q("TabTearOutRequested", e), e.Cancel && n.abort(), !n.signal.aborted && !e.Cancel;
			} catch {
				return n.abort(), !1;
			} finally {
				F.delete(t.Key);
			}
		}, hn = (e) => {
			let t = C.get(e);
			if (!t) return;
			let n = t.cloneNode(!0);
			n.classList.remove("is-dragging", "is-pressed", "is-pointer-over"), n.classList.add("win-tab-view-drag-ghost", "is-drag-visual"), n.inert = !0, n.draggable = !1, n.setAttribute("aria-hidden", "true");
			for (let e of n.querySelectorAll("[role=\"tooltip\"],.win-tooltip,.win-tool-tip")) e.remove();
			for (let e of [n, ...n.querySelectorAll("*")]) {
				for (let t of [...e.attributes]) ([
					"id",
					"role",
					"tabindex",
					"aria-controls",
					"aria-selected",
					"aria-describedby",
					"title"
				].includes(t.name) || /^tooltipservice\./i.test(t.name)) && e.removeAttribute(t.name);
				e.hasAttribute("draggable") && (e.draggable = !1);
			}
			let r = getComputedStyle(t);
			for (let e = 0; e < r.length; e++) {
				let t = r[e];
				t?.startsWith("--") && n.style.setProperty(t, r.getPropertyValue(t));
			}
			let i = t.getBoundingClientRect();
			n.style.width = `${i.width}px`, n.style.height = `${i.height}px`, n.style.fontFamily = r.fontFamily, n.style.direction = r.direction, n.style.opacity = "1";
			let a = t.querySelector(".win-tab-view-tab-drag-visual");
			return a && n.style.setProperty("--TabViewItemHeaderDragBackground", getComputedStyle(a).backgroundColor), document.body.append(n), n;
		}, gn = (e, t, n) => {
			let r = V.value.find((t) => t.Key === e);
			if (!r || !R.value || !G(r)) return null;
			let i = {
				Cancel: !1,
				Data: Oe(),
				Item: U(r),
				Tab: H(r)
			};
			if (K("TabDragStarting", i), i.Cancel) return null;
			let a = {
				Source: Z,
				Key: e,
				Item: i.Item,
				Tab: i.Tab,
				Data: i.Data,
				Controller: new AbortController(),
				Native: t,
				CanLeaveSource: L("CanDragTabs") === !0 || L("CanTearOutTabs") === !0,
				X: n.clientX,
				Y: n.clientY,
				Target: null,
				DropIndex: -1
			};
			return t || (a.Ghost = hn(e)), Ae(a), k && window.clearTimeout(k), Et = !0, a;
		}, _n = (e, t) => {
			e.button !== 0 || L("CanReorderTabs") === !1 && L("CanDragTabs") !== !0 && L("CanTearOutTabs") !== !0 || (O = {
				Key: t,
				Id: e.pointerId,
				X: e.clientX,
				Y: e.clientY
			});
		}, vn = (e) => {
			let t = O;
			if (t && t.Id === e.pointerId && !l.value && (Math.abs(e.clientX - t.X) > 8 || Math.abs(e.clientY - t.Y) > 8)) {
				let n = gn(t.Key, !1, e);
				if (!n) {
					O = null;
					return;
				}
				n.PointerId = e.pointerId;
				try {
					y.value?.setPointerCapture(e.pointerId);
				} catch {}
			}
			let n = l.value;
			!n || n.Source !== Z || n.Native || n.PointerId !== e.pointerId || (e.preventDefault(), f(e.clientX, e.clientY, e));
		}, yn = (e) => {
			O = null;
			let t = l.value;
			t?.Source !== Z || t.Native || t.PointerId !== e.pointerId || (f(e.clientX, e.clientY, e), !t.Target && Pn(e) ? u() : d(e), y.value?.hasPointerCapture(e.pointerId) && y.value.releasePointerCapture(e.pointerId));
		}, bn = () => {
			O = null, l.value?.Source === Z && !l.value.Native && u();
		}, xn = () => {
			w.value = -1;
			for (let e of At) e.abort();
		}, Sn = () => {
			M && N && M.removeEventListener("dragend", N), M = null, N = null;
		}, Cn = () => {
			O = null, Xn(), w.value = -1, l.value?.Source === Z && !l.value.Native && u();
		}, wn = (e) => {
			if (e.key === "Escape") {
				O = null, l.value?.Source === Z && u(), xn();
				for (let e of F.values()) e.abort();
			}
		}, Tn = (e, t) => {
			if (O = null, L("CanDragTabs") !== !0) {
				e.preventDefault();
				return;
			}
			let n = l.value?.Source === Z && l.value.Key === t && !l.value.Native ? l.value : null;
			if (!n && l.value && u(), n && !n.Native) {
				let e = n.PointerId;
				n.Ghost?.remove(), n.Ghost = void 0, n.Native = !0, n.PointerId = void 0, e !== void 0 && y.value?.hasPointerCapture(e) && y.value.releasePointerCapture(e), Ke(l);
			}
			if (n ||= gn(t, !0, e), !n) {
				e.preventDefault();
				return;
			}
			Sn(), M = C.get(t) ?? null;
			let r = n;
			if (N = (e) => Nn(e, r), M?.addEventListener("dragend", N), e.dataTransfer) {
				n.NativeDragToken = `application/x-winui-tab-token-${crypto.randomUUID()}`, e.dataTransfer.setData(n.NativeDragToken, Z.Id), e.dataTransfer.effectAllowed = "move", e.dataTransfer.setData("application/x-winui-tab", Z.Id);
				let r = ge(H(V.value.find((e) => e.Key === t))?.Header);
				e.dataTransfer.setData("text/plain", r);
				let i = hn(t);
				if (i) {
					i.style.transform = "translate3d(-10000px,0,0)";
					let n = C.get(t)?.getBoundingClientRect();
					e.dataTransfer.setDragImage(i, n ? e.clientX - n.left : 0, n ? e.clientY - n.top : 0), requestAnimationFrame(() => i.remove());
				}
			}
			nt?.Start(Q, e, [n.Item], [n.Tab], n.Controller.signal, (t) => {
				l.value === n && (n.NativeDropObserved = !0, t === "Move" ? d(e, "Move") : u());
			});
		}, En = (e, t, n, r) => {
			let i = Oe();
			i.Properties.Items = t.Items, i.Properties.SourceWindowId = t.SourceWindowId, i.Properties.SourceId = t.SourceId, i.SetData("Tab", t.Items[0]);
			let a = t.Data ?? i.GetView();
			return {
				Data: a,
				DataView: a,
				Signal: r,
				AcceptedOperation: "Move",
				Handled: !1,
				OriginalSource: y.value,
				DropIndex: n,
				GetPosition: (t) => {
					let n = (t instanceof HTMLElement ? t : t?.Element)?.getBoundingClientRect();
					return {
						X: e.clientX - (n?.left ?? 0),
						Y: e.clientY - (n?.top ?? 0)
					};
				},
				OriginalEvent: e
			};
		}, Dn = (e, t, n) => ({
			Items: e.Items,
			Tabs: e.Tabs,
			SourceWindowId: e.SourceWindowId,
			SourceId: e.SourceId,
			Signal: n,
			DropIndex: t,
			AllowDrop: !0
		}), On = (e) => {
			if (!R.value || L("AllowDropTabs") === !1) return null;
			let t = b.value?.getBoundingClientRect();
			return !t || e.clientX < t.left || e.clientX > t.right || e.clientY < t.top || e.clientY > t.bottom ? null : nt?.Preview(Q, e) ?? null;
		}, X = (e) => {
			let t = l.value;
			return t?.Native && t.NativeDragToken && Array.from(e.dataTransfer?.types ?? []).includes(t.NativeDragToken) ? t : null;
		}, kn = () => {
			let e = l.value;
			e && !e.NativeDropObserved && u();
		}, An = (e) => {
			let t = On(e);
			if (!t) {
				if (!X(e)) {
					w.value = -1;
					return;
				}
				f(e.clientX, e.clientY, e), l.value?.Target === Z && (e.preventDefault(), e.dataTransfer && (e.dataTransfer.dropEffect = "move"));
				return;
			}
			kn();
			let n = Ln(e.clientX), r = En(e, t, n);
			K("TabStripDragOver", r);
			let i = Dn(t, n);
			if (K("ExternalTornOutTabsDropping", i), r.AcceptedOperation === "None" || !i.AllowDrop) {
				w.value = -1, e.dataTransfer && (e.dataTransfer.dropEffect = "none");
				return;
			}
			w.value = n;
			let a = b.value, o = a?.getBoundingClientRect();
			a && o && yt.value && (e.clientX - o.left < 24 ? a.scrollLeft -= 12 : o.right - e.clientX < 24 && (a.scrollLeft += 12)), e.preventDefault(), e.dataTransfer && (e.dataTransfer.dropEffect = "move");
		}, jn = (e) => {
			e.relatedTarget instanceof Node && y.value?.contains(e.relatedTarget) || (w.value = -1);
		}, Mn = (e) => {
			let t = On(e);
			if (t && nt) {
				kn(), e.preventDefault(), e.stopPropagation();
				let n = Ln(e.clientX), r = new AbortController();
				At.add(r), nt.Drop(Q, e, n, async (r) => {
					let i = En(e, t, n, r);
					if (await q("TabStripDrop", i), E || !R.value || L("AllowDropTabs") === !1 || r.aborted || i.AcceptedOperation === "None") return !1;
					let a = Dn(t, n, r);
					return K("ExternalTornOutTabsDropping", a), {
						Accepted: a.AllowDrop && !r.aborted && !E,
						Handled: i.Handled
					};
				}, r.signal).then(async (e) => {
					if (e !== "Move") return;
					let i = {
						Items: t.Items,
						Tabs: t.Tabs,
						SourceWindowId: t.SourceWindowId,
						SourceId: t.SourceId,
						Signal: r.signal,
						DropIndex: n
					};
					Object.defineProperty(i, Me, { value: !0 });
					try {
						await q("ExternalTornOutTabsDropped", i);
					} catch {}
				}).catch(() => {}).finally(() => {
					At.delete(r), w.value = -1;
				});
				return;
			}
			let n = X(e);
			if (!n) {
				w.value = -1;
				return;
			}
			if (e.preventDefault(), e.stopPropagation(), f(e.clientX, e.clientY, e), n.Target !== Z) {
				u();
				return;
			}
			n.NativeDropObserved = !0, d(e);
		}, Nn = (e, t) => {
			let n = l.value;
			if (n?.Source !== Z || t && n !== t || X(e) !== n) return;
			Sn();
			let r = nt?.End(Q, e);
			if (r) {
				n.NativeDropObserved = !0, r.then((t) => {
					l.value === n && (t === "Move" ? d(e, "Move") : u());
				}, () => {
					l.value === n && u();
				});
				return;
			}
			n.NativeDropObserved || (e.dataTransfer?.dropEffect === "move" ? d(e, "Move") : u());
		}, Pn = (e) => e.composedPath().some((e) => e instanceof Element && e.matches(".win-tab-view-tab-container-grid")) ? !0 : [...document.querySelectorAll(".win-tab-view-tab-container-grid")].some((t) => {
			let n = t.getBoundingClientRect();
			return e.clientX >= n.left && e.clientX <= n.right && e.clientY >= n.top && e.clientY <= n.bottom;
		}), Fn = (e) => {
			let t = X(e);
			t?.Source !== Z || !t.Native || !t.CanLeaveSource || e.defaultPrevented || (f(e.clientX, e.clientY, e), !t.Target && !Pn(e) && (e.preventDefault(), e.dataTransfer && (e.dataTransfer.dropEffect = "move")));
		}, In = (e) => {
			let t = X(e);
			t?.Source !== Z || !t.Native || !t.CanLeaveSource || e.defaultPrevented || (f(e.clientX, e.clientY, e), t.Target ? (t.NativeDropObserved = !0, e.preventDefault(), d(e)) : Pn(e) || (t.NativeDropObserved = !0, e.preventDefault(), d(e, "None")));
		}, Ln = (e) => {
			let t = z.value === "rtl" ? [...V.value].reverse() : V.value, n = b.value?.getBoundingClientRect();
			for (let r of t) {
				let t = C.get(r.Key);
				if (!(!t || !n || !b.value) && e < n.left + t.offsetLeft - b.value.scrollLeft + t.offsetWidth / 2) return z.value === "rtl" ? r.Index + 1 : r.Index;
			}
			return z.value === "rtl" ? 0 : V.value.length;
		}, Rn = (e, t) => ({
			Data: e.Data.GetView(),
			DataView: e.Data.GetView(),
			Signal: e.Controller.signal,
			AcceptedOperation: "Move",
			Handled: !1,
			OriginalSource: y.value,
			DropIndex: e.DropIndex,
			GetPosition: (t) => {
				let n = (t instanceof HTMLElement ? t : t?.Element)?.getBoundingClientRect();
				return {
					X: e.X - (n?.left ?? 0),
					Y: e.Y - (n?.top ?? 0)
				};
			},
			OriginalEvent: t
		}), Z = {
			Id: `tab-view-${_?.uid}`,
			Element: () => b.value,
			CanAccept: (e) => R.value && L("AllowDropTabs") !== !1 && (e.Source === Z ? L("CanReorderTabs") !== !1 : e.CanLeaveSource),
			Over(e, t) {
				e.DropIndex = Ln(e.X);
				let n = Rn(e, t);
				if (K("TabStripDragOver", n), n.AcceptedOperation === "None") return !1;
				w.value = e.DropIndex;
				let r = b.value, i = r?.getBoundingClientRect();
				return r && i && yt.value && (e.X - i.left < 24 ? r.scrollLeft -= 12 : i.right - e.X < 24 && (r.scrollLeft += 12)), !0;
			},
			Leave() {
				w.value = -1;
			},
			async Drop(e, t) {
				let n = V.value.map((e) => e.Item), r = Rn(e, t);
				if (await q("TabStripDrop", r), E || l.value !== e || e.Controller.signal.aborted || r.AcceptedOperation === "None") return "None";
				if (r.Handled || V.value.length !== n.length || V.value.some((e, t) => e.Item !== n[t])) return "Move";
				if (e.Source === Z) {
					let t = W(e.Item) ?? V.value.find((t) => t.Key === e.Key);
					if (!t) return "None";
					let n = rn(), [r] = n.splice(t.Index, 1), i = Math.max(0, Math.min(n.length, e.DropIndex - +(t.Index < e.DropIndex)));
					return n.splice(i, 0, r), an(n), K("TabItemsChanged", {
						CollectionChange: "Reset",
						Index: i
					}), await J(i), "Move";
				}
				let i = e.Tab?.ParentTabView, a = i?.TabItems;
				if (!a) return "None";
				let o = a.GetAt(a.IndexOf(e.Item));
				if (o == null) return "None";
				let s = {
					Items: [e.Item],
					Tabs: [e.Tab],
					SourceTabView: i,
					Signal: e.Controller.signal,
					DropIndex: e.DropIndex,
					AllowDrop: !0
				};
				if (K("ExternalTornOutTabsDropping", s), !s.AllowDrop) return "None";
				if (_?.vnode.props?.onExternalTornOutTabsDropped || $e.ExternalTornOutTabsDropped) {
					let t = {
						Items: s.Items,
						Tabs: s.Tabs,
						SourceTabView: i,
						Signal: e.Controller.signal,
						DropIndex: e.DropIndex,
						Cancel: !1
					};
					return await q("ExternalTornOutTabsDropped", t), t.Cancel && e.Controller.abort(), !t.Cancel && !e.Controller.signal.aborted && l.value === e && !E ? "Move" : "None";
				}
				let c = a.IndexOf(o);
				a.RemoveAt(c);
				try {
					Y.InsertAt(e.DropIndex, o);
				} catch (e) {
					throw a.InsertAt(c, o), e;
				}
				return await J(e.DropIndex), K("ExternalTornOutTabsDropped", {
					Items: s.Items,
					Tabs: s.Tabs,
					SourceTabView: i,
					Signal: e.Controller.signal,
					DropIndex: e.DropIndex
				}), "Move";
			},
			Complete(e, t, n) {
				Sn(), O = null, w.value = -1, k = window.setTimeout(() => {
					k = 0, l.value?.Source !== Z && (Et = !1);
				}, 0), K("TabDragCompleted", {
					Item: e.Item,
					Tab: e.Tab,
					DropResult: t
				}), t === "None" && !n && e.CanLeaveSource && (K("TabDroppedOutside", {
					Item: e.Item,
					Tab: e.Tab
				}), L("CanTearOutTabs") === !0 && mn(e.Item));
			}
		}, zn = {
			Api: () => Q,
			Selected: (e) => S.value === e,
			Enabled: () => R.value,
			Compact: (e) => jt.value === "Compact" && S.value !== e,
			Width: () => jt.value === "Equal" ? Zt.value : void 0,
			ReorderHint: (e) => {
				let t = V.value.findIndex((t) => t.Key === e);
				return w.value >= 0 && t === Math.min(w.value, V.value.length - 1) && l.value?.Key !== e ? Ut("ListViewItemReorderHintThemeOffset", 10) * (z.value === "rtl" ? -1 : 1) : 0;
			},
			IsNativeDrag: () => l.value?.Native ?? !1,
			OverlayMode: () => String(L("CloseButtonOverlayMode")),
			Dragging: (e) => l.value?.Source === Z && l.value.Key === e,
			Separator: (e) => {
				let t = V.value.findIndex((t) => t.Key === e);
				return S.value !== e && V.value[t + 1]?.Key !== S.value;
			},
			CanDrag: () => L("CanDragTabs") === !0,
			TabIndex: (e) => (ht.value ?? S.value ?? V.value[0]?.Key) === e ? 0 : -1,
			PanelId: Xt,
			SetFocused: (e) => {
				ht.value = e;
			},
			Select: (e) => {
				Et || J(V.value.findIndex((t) => t.Key === e));
			},
			Close: (e) => {
				cn(e);
			},
			KeyDown: fn,
			PointerDown: _n,
			DragStart: Tn,
			DragEnd: Nn,
			SetElement: (e, t) => {
				t ? C.set(e, t) : C.delete(e), $();
			},
			Container: (e) => gt.get(e) ?? null,
			SetContainer: (e, t) => {
				if (t) {
					let n = V.value.find((t) => t.Key === e), r = n?.Node?.props?.__tabViewPublicItem;
					r && r !== t && (r[xe] = t);
					let i = r ?? t;
					n && Object.defineProperty(t, we, {
						configurable: !0,
						get: () => n.Node ? Pe(n.Node, {
							__tabViewRecordKey: n.Key,
							__tabViewPublicItem: i
						}) : n.Item
					}), gt.set(e, i);
				} else gt.delete(e);
				_t.value++;
			}
		};
		m(Se, zn);
		let Bn = Fe({
			props: { Entry: {
				type: Object,
				required: !0
			} },
			setup(e) {
				return m(Ce, e.Entry.Key), () => {
					let t = e.Entry;
					if (t.Node) {
						let e = Pe(t.Node, { key: t.Key });
						return e.props && (e.props = { ...e.props }, delete e.props.__tabViewRecordKey, delete e.props.__tabViewPublicItem), Le(Ne, s([e], _));
					}
					let n = B("TabItemTemplate"), r = he(L("TabItemTemplateSelector")?.SelectTemplate?.(t.Item, Q) ?? L("TabItemTemplate"), _), i = n.length ? n : ze(r) ? [r] : Array.isArray(r) ? r.filter(ze) : [];
					return i.length ? ie(i.flatMap((e) => _e(e) === "DataTemplate" ? fe(e) : [e]), t.Item, _) : Le(De, {
						key: t.Key,
						...t.Item && typeof t.Item == "object" ? t.Item : { Header: t.Item },
						DataContext: t.Item
					});
				};
			}
		}), Vn = (e) => Fe({ setup: () => () => ve(L(e), B(e), L(`${e}Template`), B(`${e}Template`), _) }), Hn = Vn("TabStripHeader"), Un = Vn("TabStripFooter"), Wn = Fe({
			props: { Entry: {
				type: Object,
				required: !0
			} },
			setup(e) {
				return m(re, We({})), () => {
					let t = e.Entry, n = H(t), r = x.get(t.Key);
					return Le("div", {
						class: "win-tab-view-content-panel",
						hidden: t.Key !== S.value,
						inert: t.Key === S.value ? void 0 : !0,
						"aria-hidden": t.Key !== S.value
					}, [ve(n ? n.Content : r?.Content, [], n ? n.ContentTemplate : r?.Template, [], _)]);
				};
			}
		}), Gn = Fe({ setup: () => () => {
			let e = Yt.value, t = H(e);
			return e && t && (x.get(e.Key) || x.set(e.Key, {
				Content: t.Content,
				Template: t.ContentTemplate
			})), Le(Ne, V.value.filter((e) => x.has(e.Key)).map((e) => Le(Wn, {
				key: e.Key,
				Entry: e
			})));
		} }), Kn = Fe({ setup: () => () => {
			let e = {};
			oe(B("Resources"), e);
			for (let t of Object.keys(Lt)) Object.hasOwn(e, t) || delete Lt[t];
			Object.assign(Lt, e), zt.sync(e);
			let t = [...new Set(Object.entries(e).filter(([, e]) => e.type.__xamlBrush).map(([e]) => e.replace(/^(Light|Dark|Default|HighContrast):/, "")))];
			return t.join("|") !== Bt.value.join("|") && (Bt.value = t), Le(Ne, s(B("KeyboardAccelerators"), _));
		} }), Q = {
			get Element() {
				return v.value;
			},
			get TabItems() {
				return sn;
			},
			get SelectedIndex() {
				return Jt.value;
			},
			set SelectedIndex(e) {
				J(Number(e));
			},
			get SelectedItem() {
				return U(Yt.value);
			},
			set SelectedItem(e) {
				let t = W(e);
				t ? J(t.Index) : e === null && J(-1);
			},
			ContainerFromIndex: (e) => H(V.value[e]),
			ContainerFromItem: (e) => H(W(e)),
			IndexFromContainer: (e) => W(e)?.Index ?? -1,
			Focus() {
				return (C.get(S.value) ?? ct.value)?.focus(), !!(C.size || ct.value);
			},
			RequestTearOut: mn,
			get ActualWidth() {
				return v.value?.clientWidth ?? 0;
			},
			get ActualHeight() {
				return v.value?.clientHeight ?? 0;
			}
		};
		Object.defineProperty(Q, ne, { value: Q });
		for (let e of Object.keys(g)) e === "SelectedIndex" || e === "SelectedItem" || (Object.defineProperty(Q, e, {
			enumerable: !0,
			configurable: !0,
			get: () => L(e),
			set: (t) => {
				pt[e] = t, te(g[e], t, _);
			}
		}), Ye(() => I(g[e]), () => {
			delete pt[e];
		}));
		function qn() {
			let e = b.value;
			e && (bt.value = Math.abs(e.scrollLeft), xt.value = Math.max(0, e.scrollWidth - e.clientWidth), yt.value = e.scrollWidth > (Tt ? vt.value : e.clientWidth) + 1);
		}
		function $() {
			E || D || (D = requestAnimationFrame(() => {
				D = 0;
				let e = y.value;
				if (e) {
					let t = rt.value ? getComputedStyle(rt.value) : null, n = (parseFloat(t?.paddingLeft ?? "") || 0) + (parseFloat(t?.paddingRight ?? "") || 0), r = st.value, i = 0;
					if (r) {
						let e = r.style.width, t = r.style.maxWidth;
						r.style.width = "max-content", r.style.maxWidth = "none", i = r.scrollWidth, r.style.width = e, r.style.maxWidth = t;
					}
					let a = Math.max(0, e.clientWidth - (at.value?.offsetWidth ?? 2) - i - (lt.value?.offsetWidth ?? 0) - n);
					Tt && Math.abs(a - vt.value) > .5 && (T.value = null), Tt = !0, vt.value = a;
				}
				qn();
			}));
		}
		let Jn = (e) => b.value?.scrollBy({
			left: e * 50 * (z.value === "rtl" ? -1 : 1),
			behavior: "smooth"
		}), Yn = (e) => {
			e.cancelable && e.preventDefault(), e.stopPropagation();
			let t = b.value;
			if (!t || !R.value) return;
			let n = parseFloat(getComputedStyle(C.values().next().value ?? t).lineHeight) || 16, r = e.deltaMode === 1 ? n : e.deltaMode === 2 ? t.clientWidth : 1, i = Math.abs(e.deltaX) > Math.abs(e.deltaY) ? e.deltaX : e.deltaY * (z.value === "rtl" ? -1 : 1);
			t.scrollLeft += i * r, qn();
		}, Xn = () => {
			A && clearTimeout(A), j && clearInterval(j), A = 0, j = 0;
		}, Zn = (e, t) => {
			if (!R.value || e.button !== 0) return;
			Xn(), Dt = !0, Jn(t);
			let n = e.currentTarget;
			try {
				n.setPointerCapture(e.pointerId);
			} catch {}
			A = window.setTimeout(() => {
				Jn(t), j = window.setInterval(() => Jn(t), 100);
			}, 50);
		}, Qn = (e) => {
			Dt || Jn(e), Dt = !1;
		}, $n = () => {
			St.value = !1, T.value = null, $();
		};
		Ye(() => I(g.SelectedIndex), (e) => {
			Number.isInteger(Number(e)) && J(Number(e));
		}), Ye(() => I(g.SelectedItem), (e) => {
			if (e === void 0) return;
			let t = W(e);
			t && J(t.Index);
		}), Ye(V, (e, t = []) => {
			let n = new Map([...C].map(([e, t]) => [e, t.getBoundingClientRect()])), r = performance.now(), i = t.length > 0 && r - Ot > 100;
			Ot = r, i && Be(() => {
				if (!(E || window.matchMedia("(prefers-reduced-motion: reduce)").matches)) for (let t of e) {
					let e = C.get(t.Key), r = n.get(t.Key);
					if (!e?.animate || !r) continue;
					let i = e.getBoundingClientRect(), a = r.left - i.left, o = r.top - i.top;
					if (Math.abs(a) < 1 && Math.abs(o) < 1) continue;
					P.get(t.Key)?.cancel();
					let s = e.animate([{ transform: `translate3d(${a}px,${o}px,0)` }, { transform: "translate3d(0,0,0)" }], {
						duration: 200,
						easing: "cubic-bezier(0.1,0.9,0.2,1)"
					});
					P.set(t.Key, s), s.finished.catch(() => {}).finally(() => {
						P.get(t.Key) === s && (P.delete(t.Key), s.cancel());
					});
				}
			});
			let a = t.findIndex((e) => e.Key === S.value);
			for (let t of x.keys()) e.some((e) => e.Key === t) || x.delete(t);
			let o = e.findIndex((e) => e.Key === S.value);
			if (o >= 0) {
				a !== o && (Qe("update:SelectedIndex", o), te(g.SelectedIndex, o, _)), $();
				return;
			}
			let s = I(g.SelectedItem), c = (s === void 0 ? null : e.find((e) => e.Item === s))?.Index ?? Math.max(0, Math.min(e.length - 1, a < 0 ? Number(I(g.SelectedIndex)) || 0 : a));
			J((e.slice(c).find(G) ?? [...e.slice(0, c)].reverse().find(G))?.Index ?? -1, t.length > 0, U(t[a])), $();
		}, { immediate: !0 }), Ye([
			R,
			jt,
			() => L("CanDragTabs"),
			() => L("CanReorderTabs"),
			() => L("CanTearOutTabs"),
			() => L("AllowDropTabs")
		], () => {
			if (bn(), l.value?.Source === Z && u(), xn(), Xn(), !R.value || L("CanTearOutTabs") !== !0) for (let e of F.values()) e.abort();
			T.value = null, $();
		}), He(async () => {
			if (kt = ke(Z), v.value && (Ct.value = getComputedStyle(v.value).direction), typeof ResizeObserver < "u") {
				wt = new ResizeObserver($);
				for (let e of [
					v.value,
					at.value,
					st.value,
					b.value,
					it.value
				]) e && wt.observe(e);
			}
			window.addEventListener("pointermove", vn, { passive: !1 }), window.addEventListener("pointerup", yn), window.addEventListener("pointercancel", bn), window.addEventListener("blur", Cn), window.addEventListener("keydown", wn, !0), window.addEventListener("dragover", Fn), window.addEventListener("drop", In), await Be(), $(), K("Loaded", { OriginalSource: Q });
		}), Ue($), Ve(() => {
			E = !0, Sn(), xn(), Xn();
			for (let e of P.values()) e.cancel();
			P.clear();
			for (let e of F.values()) e.abort();
			kt?.(), wt?.disconnect(), D && cancelAnimationFrame(D), k && clearTimeout(k), window.removeEventListener("pointermove", vn), window.removeEventListener("pointerup", yn), window.removeEventListener("pointercancel", bn), window.removeEventListener("blur", Cn), window.removeEventListener("keydown", wn, !0), window.removeEventListener("dragover", Fn), window.removeEventListener("drop", In);
		}), Xe(Q);
		let er = {
			props: g,
			emit: Qe,
			instance: _,
			attrs: $e,
			slots: et,
			t: tt,
			nativeDragBridge: nt,
			rootRef: v,
			stripRef: y,
			scrollerRef: b,
			listRef: rt,
			itemsPresenterRef: it,
			headerRef: at,
			footerRef: ot,
			footerContentRef: st,
			addButtonRef: ct,
			addContainerRef: lt,
			scrollDecreaseButtonRef: ut,
			scrollIncreaseButtonRef: dt,
			contentRef: ft,
			overrides: pt,
			localItems: mt,
			realizedContent: x,
			selectedKey: S,
			focusedKey: ht,
			containers: gt,
			elements: C,
			containerVersion: _t,
			availableWidth: vt,
			overflow: yt,
			scrollOffset: bt,
			scrollMaximum: xt,
			dropIndex: w,
			stripHovered: St,
			frozenWidth: T,
			inheritedDirection: Ct,
			get disposed() {
				return E;
			},
			set disposed(e) {
				E = e;
			},
			get observer() {
				return wt;
			},
			set observer(e) {
				wt = e;
			},
			get layoutFrame() {
				return D;
			},
			set layoutFrame(e) {
				D = e;
			},
			get layoutMeasured() {
				return Tt;
			},
			set layoutMeasured(e) {
				Tt = e;
			},
			get pendingPointer() {
				return O;
			},
			set pendingPointer(e) {
				O = e;
			},
			get suppressClick() {
				return Et;
			},
			set suppressClick(e) {
				Et = e;
			},
			get clickResetTimer() {
				return k;
			},
			set clickResetTimer(e) {
				k = e;
			},
			get scrollRepeatTimer() {
				return A;
			},
			set scrollRepeatTimer(e) {
				A = e;
			},
			get scrollRepeatInterval() {
				return j;
			},
			set scrollRepeatInterval(e) {
				j = e;
			},
			get scrollHasRepeated() {
				return Dt;
			},
			set scrollHasRepeated(e) {
				Dt = e;
			},
			get nativeDragElement() {
				return M;
			},
			set nativeDragElement(e) {
				M = e;
			},
			get nativeDragEndListener() {
				return N;
			},
			set nativeDragEndListener(e) {
				N = e;
			},
			layoutAnimations: P,
			get lastCollectionChange() {
				return Ot;
			},
			set lastCollectionChange(e) {
				Ot = e;
			},
			get unregister() {
				return kt;
			},
			set unregister(e) {
				kt = e;
			},
			tearOutRequests: F,
			externalDropControllers: At,
			value: I,
			property: L,
			enabled: R,
			widthMode: jt,
			direction: z,
			requestedTheme: Mt,
			nodes: Nt,
			children: B,
			inheritedPrimitives: Pt,
			primitives: Ft,
			inheritedResources: It,
			resources: Lt,
			names: Rt,
			brushResources: zt,
			resourceNames: Bt,
			inheritedTheme: Vt,
			resourceBrushStyles: Ht,
			metric: Ut,
			keys: Wt,
			primitiveKeys: Gt,
			get identity() {
				return Kt;
			},
			set identity(e) {
				Kt = e;
			},
			keyOf: qt,
			entries: V,
			selectedIndex: Jt,
			selectedRecord: Yt,
			containerOf: H,
			sourceOf: U,
			entryFor: W,
			itemEnabled: G,
			panelId: Xt,
			equalWidth: Zt,
			rootAttrs: Qt,
			rootStyle: $t,
			listStyle: en,
			contentStyle: tn,
			raise: K,
			raiseAsync: q,
			ensureVisible: nn,
			select: J,
			editableItems: rn,
			replaceItems: an,
			changed: on,
			collectionMethods: Y,
			collection: sn,
			close: cn,
			add: ln,
			commandEnabled: un,
			moveFocus: dn,
			headerKeyDown: fn,
			keyDown: pn,
			RequestTearOut: mn,
			createDragVisual: hn,
			beginDrag: gn,
			pointerDown: _n,
			pointerMove: vn,
			pointerUp: yn,
			pointerCancel: bn,
			cancelExternalDrag: xn,
			clearNativeDragEndListener: Sn,
			windowBlur: Cn,
			windowKeyDown: wn,
			nativeDragStart: Tn,
			externalDragArgs: En,
			externalDroppingArgs: Dn,
			nativeExternalPreview: On,
			nativeEventSession: X,
			prepareExternalDrag: kn,
			nativeDragOver: An,
			nativeDragLeave: jn,
			nativeDrop: Mn,
			nativeDragEnd: Nn,
			inAnyStrip: Pn,
			windowDragOver: Fn,
			windowDrop: In,
			insertionIndex: Ln,
			dragArgs: Rn,
			endpoint: Z,
			owner: zn,
			ItemHost: Bn,
			presenter: Vn,
			HeaderOutlet: Hn,
			FooterOutlet: Un,
			ContentPanel: Wn,
			ContentOutlet: Gn,
			ResourcesOutlet: Kn,
			publicApi: Q,
			updateScroll: qn,
			updateLayout: $,
			scroll: Jn,
			stripWheel: Yn,
			endScrollRepeat: Xn,
			beginScrollRepeat: Zn,
			scrollClick: Qn,
			leaveStrip: $n,
			FontIcon: ue,
			get TabViewTemplateToolTip() {
				return ye;
			},
			get activeTabViewDrag() {
				return l;
			},
			get isHoverPointer() {
				return de;
			}
		};
		return Object.defineProperty(er, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), er;
	}
});
//#endregion
export { Xe as default };

//# sourceMappingURL=TabView.vue_vue_type_script_setup_true_lang.js.map