import { alignment as e, xamlThickness as t } from "./layout.js";
import { selectorBarStyleSetter as n } from "./selectorBarResources.js";
import { normalizeXamlNodes as r, resolveXamlValue as i, updateXamlBinding as a, xamlItemContextKey as ee, xamlScopeKey as te } from "./xamlRuntime.js";
import { frameworkLayoutStyle as ne } from "./frameworkLayout.js";
import re from "../_virtual/_plugin-vue_export-helper.js";
import ie from "./SymbolIcon.vue.js";
import ae from "./TextBlock.vue.js";
import { isHoverPointer as o } from "./pointerInput.js";
import { itemContainerControllerKey as oe, itemsViewElementKey as s, itemsViewItemContextKey as se } from "./ItemsViewState.js";
import { SelectorBarItemChild as ce, SelectorBarItemIcon as le, selectorBarElementFactory as ue, selectorBarItemDefaults as c, selectorBarItemKey as de, selectorBarPointerFocusKey as l } from "./selectorBarRuntime.js";
/* empty css                                                                    */
import { Comment as fe, Fragment as u, Text as pe, computed as d, createBlock as me, createCommentVNode as f, createElementBlock as p, createElementVNode as m, createVNode as h, defineComponent as g, getCurrentInstance as he, h as _, inject as v, isVNode as ge, mergeProps as y, normalizeStyle as b, onBeforeUnmount as _e, onMounted as ve, openBlock as x, provide as ye, reactive as S, ref as C, useAttrs as be, useSlots as xe, watch as w } from "vue";
//#region src/components/SelectorBarItem.vue
var T = /*@__PURE__*/ Object.assign({
	Icon: le,
	Child: ce
}, {
	name: "SelectorBarItem",
	inheritAttrs: !1
}, {
	__name: "SelectorBarItem",
	props: {
		Style: {
			type: [String, Object],
			default: null
		},
		Text: {
			type: [String, Number],
			default: ""
		},
		Tag: {
			type: [String, Number],
			default: ""
		},
		Icon: {
			type: [String, Object],
			default: null
		},
		Child: {
			type: null,
			default: null
		},
		IsSelected: {
			type: [Boolean, String],
			default: !1
		},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		IsTabStop: {
			type: [Boolean, String],
			default: !0
		},
		IsHitTestVisible: {
			type: [Boolean, String],
			default: !0
		},
		Visibility: {
			type: String,
			default: "Visible"
		},
		Padding: {
			type: [String, Number],
			default: "12,10,12,7"
		},
		Width: {
			type: [String, Number],
			default: ""
		},
		Height: {
			type: [String, Number],
			default: ""
		},
		MinWidth: {
			type: [String, Number],
			default: 0
		},
		MinHeight: {
			type: [String, Number],
			default: 0
		},
		MaxWidth: {
			type: [String, Number],
			default: ""
		},
		MaxHeight: {
			type: [String, Number],
			default: ""
		},
		Margin: {
			type: [String, Number],
			default: 0
		},
		Opacity: {
			type: [String, Number],
			default: 1
		},
		BackgroundSizing: {
			type: String,
			default: "OuterBorderEdge"
		},
		Background: {
			type: String,
			default: "Transparent"
		},
		Foreground: {
			type: String,
			default: "{ThemeResource SelectorBarItemForeground}"
		},
		BorderBrush: {
			type: String,
			default: "{ThemeResource SelectorBarItemBorderBrush}"
		},
		BorderThickness: {
			type: [String, Number],
			default: 1
		},
		CornerRadius: {
			type: [String, Number],
			default: "{ThemeResource ControlCornerRadius}"
		},
		HorizontalAlignment: {
			type: String,
			default: "Left"
		},
		VerticalAlignment: {
			type: String,
			default: "Center"
		},
		HorizontalContentAlignment: {
			type: String,
			default: "Left"
		},
		VerticalContentAlignment: {
			type: String,
			default: "Top"
		},
		FontFamily: {
			type: String,
			default: "{ThemeResource ContentControlThemeFontFamily}"
		},
		FontSize: {
			type: [String, Number],
			default: 14
		},
		FontWeight: {
			type: String,
			default: "Normal"
		},
		FocusVisualMargin: {
			type: [String, Number],
			default: -2
		},
		UseSystemFocusVisuals: {
			type: [Boolean, String],
			default: !0
		}
	},
	setup(re, { expose: me }) {
		let f = re, p = be(), m = xe(), h = he(), y = C(null), b = v(oe, null), x = v(se, null), T = v(ee, null), E = T?.[de] ? T : null, D = S({}), O = C(!1), k = C(!1), A = S({}), j = ue(h), M = (e) => {
			if (E) return E[e];
			let t = e === "Style" ? void 0 : n(M("Style"), e, "SelectorBarItem"), r = e in D ? i(D[e], h) : e in A ? A[e] : i(h?.vnode.props?.[e] === void 0 ? t ?? f[e] : f[e], h);
			return e === "Icon" || e === "Child" ? j(e, r) : r;
		}, N = d(() => M("IsEnabled") !== !1 && (b?.isEnabled?.() ?? !0)), P = d(() => M("Style")?.Key === "TokenViewSelectorBarItemStyle"), F = d(() => b && T ? b.isSelected(T) : M("IsSelected") === !0), Se = d(() => !N.value || M("IsTabStop") === !1 ? -1 : x?.tabIndex?.() ?? 0), Ce = d(() => [`${F.value ? "Selected" : "Unselected"}${N.value && k.value ? "Pressed" : N.value && O.value ? "PointerOver" : "Normal"}`, {
			"is-selected": F.value,
			"is-disabled": !N.value,
			"is-token-style": P.value
		}]), we = d(() => {
			let { class: e, style: t, ...n } = p;
			return n;
		}), I = d(() => P.value ? N.value && k.value ? i(`{ThemeResource TokenItemForegroundPressed${F.value ? "Selected" : ""}}`, h) : N.value && O.value ? i(`{ThemeResource TokenItemForegroundPointerOver${F.value ? "Selected" : ""}}`, h) : F.value ? i("{ThemeResource TokenItemForegroundSelected}", h) : M("Foreground") : N.value ? k.value ? F.value ? "var(--SelectorBarItemForegroundPointerOver)" : "var(--SelectorBarItemForegroundPressed)" : O.value ? "var(--SelectorBarItemForegroundPointerOver)" : F.value ? "var(--SelectorBarItemForegroundSelected)" : M("Foreground") : "var(--SelectorBarItemForegroundDisabled)"), Te = d(() => ({
			...ne(Object.fromEntries(Object.keys(c).filter((e) => ![
				"Icon",
				"Child",
				"Padding",
				"Background",
				"BorderBrush",
				"BorderThickness"
			].includes(e)).map((e) => [e, M(e)])), h),
			color: I.value
		})), Ee = d(() => {
			if (P.value) {
				let e = `${N.value && k.value ? "Pressed" : N.value && O.value ? "PointerOver" : ""}${F.value ? "Selected" : ""}`;
				return {
					borderRadius: "inherit",
					borderStyle: "solid",
					borderWidth: t(M("BorderThickness")),
					borderColor: e ? i(`{ThemeResource TokenItemBorderBrush${e}}`, h) : M("BorderBrush"),
					background: e ? i(`{ThemeResource TokenItemBackground${e}}`, h) : M("Background"),
					backgroundClip: M("BackgroundSizing") === "InnerBorderEdge" ? "padding-box" : "border-box",
					transition: "background-color 83ms linear"
				};
			}
			return {
				borderRadius: "inherit",
				background: N.value ? F.value && !O.value && !k.value ? "var(--SelectorBarItemBackgroundSelected)" : !F.value && k.value ? "var(--SelectorBarItemBackgroundPressed)" : !F.value && O.value ? "var(--SelectorBarItemBackgroundPointerOver)" : M("Background") : "var(--SelectorBarItemBackgroundDisabled)"
			};
		}), De = d(() => ({
			margin: t(M("Padding")),
			justifySelf: e(M("HorizontalContentAlignment"), "horizontal"),
			alignSelf: e(M("VerticalContentAlignment"), "vertical"),
			fontFamily: M("FontFamily"),
			fontSize: typeof M("FontSize") == "number" ? `${M("FontSize")}px` : M("FontSize"),
			fontWeight: String(M("FontWeight")).toLowerCase()
		})), L = d(() => String(M("Text") ?? "")), Oe = d(() => L.value.length > 0), R = (e) => {
			if (!e) return [];
			if (Array.isArray(e.children)) return e.children;
			let t = e.children?.default?.();
			return Array.isArray(t) ? t : t ? [t] : [];
		}, z = (e) => (Array.isArray(e) ? e : e ? [e] : []).flatMap((e) => !e || e.type === fe || e.type === pe && !String(e.children ?? "").trim() ? [] : e.type === u ? z(R(e)) : [e]), ke = () => {
			let e = z(m.default?.() ?? []), t = (t) => e.find((e) => e.type?.__selectorBarProperty === t), n = z(R(t("Icon") ?? {}))[0] ?? null, r = t("Child"), i = r ? z(R(r))[0] ?? null : e.find((e) => !e.type?.__selectorBarProperty) ?? null;
			for (let [e, t] of [["Icon", n], ["Child", i]]) if (E?.SetPropertyElement) E.SetPropertyElement(e, t);
			else if (!(e in D)) {
				let n = A[e];
				t ? n?.Type === (t.type?.name || t.type?.__name || t.type) ? n.UpdateElementNode(t) : A[e] = j(e, t) : delete A[e];
			}
			return null;
		}, Ae = d(() => M("Icon") != null), B = (e, t) => {
			if (t == null) return null;
			let n = typeof t?.[s] == "function" ? t[s]() : t;
			return Array.isArray(n) ? _(u, r(n, h)) : ge(n) ? _(u, r([n], h)) : e === "Icon" && typeof t == "object" && t.Symbol !== void 0 ? _(ie, t) : typeof n == "string" || typeof n == "number" ? n : null;
		}, je = g({ setup() {
			return () => B("Icon", M("Icon"));
		} }), Me = g({ setup() {
			return () => B("Child", M("Child"));
		} });
		ye(te, {
			...v(te, {}),
			get TemplateText() {
				return L.value;
			},
			get TemplateForeground() {
				return I.value;
			},
			get TemplateFontFamily() {
				return M("FontFamily");
			},
			get TemplateFontSize() {
				return M("FontSize");
			},
			get TemplateFontWeight() {
				return M("FontWeight");
			}
		});
		let V = null, H = null, U = null, W = !1, G = null, K = () => {
			W = !1, G != null && clearTimeout(G), G = null;
		}, q = (e, t) => {
			!N.value || M("IsHitTestVisible") === !1 || (b && T ? b.itemInvoked(T, e, t) : e !== "Tap" && (D.IsSelected = !0, a(f.IsSelected, !0, h)));
		}, J = (e) => {
			if (e && V != null && e.pointerId !== V) return;
			k.value = !1, (H === "touch" || H === "pen") && (O.value = !1);
			let t = V;
			V = null, H = null, U = null, t != null && y.value?.hasPointerCapture?.(t) && y.value.releasePointerCapture(t);
		}, Ne = (e) => {
			O.value = o(e);
		}, Pe = (e) => {
			if (!(!N.value || M("IsHitTestVisible") === !1 || e.pointerType === "mouse" && e.button !== 0) && !(V != null && V !== e.pointerId)) {
				V = e.pointerId, H = e.pointerType, k.value = !0, o(e) || (O.value = !1), U = {
					x: e.clientX,
					y: e.clientY
				}, e.pointerType === "mouse" && e.preventDefault();
				try {
					y.value?.setPointerCapture?.(V);
				} catch {}
			}
		}, Fe = (e) => {
			if (O.value = !1, V === e.pointerId && (H === "touch" || H === "pen")) {
				let t = y.value?.getBoundingClientRect();
				if (t && e.clientX >= t.left && e.clientX <= t.right && e.clientY >= t.top && e.clientY <= t.bottom) return;
			}
			k.value = !1;
		}, Y = (e) => {
			if (V !== e.pointerId) return;
			let t = y.value.getBoundingClientRect(), n = e.clientX >= t.left && e.clientX <= t.right && e.clientY >= t.top && e.clientY <= t.bottom, r = k.value && n;
			if (J(), r) {
				K(), W = !0, G = setTimeout(K, 0), q("PointerReleased", e);
				let t = y.value;
				t && (t[l] = !0);
				try {
					t?.focus?.({ preventScroll: !0 }), b?.setCurrent?.(T, { preserveSelection: !0 });
				} finally {
					t && delete t[l];
				}
			}
		}, Ie = (e) => Y(e), X = (e) => {
			V === e.pointerId && J(e);
		}, Z = (e) => {
			V === e.pointerId && !y.value?.contains(e.target) && Y(e);
		}, Le = (e) => {
			e.pointerId !== V || !U || H !== "touch" && H !== "pen" || Math.hypot(e.clientX - U.x, e.clientY - U.y) > 3 && J(e);
		}, Re = (e) => {
			if (W) {
				K();
				return;
			}
			e.detail === 0 && q("PointerReleased", e);
		}, ze = (e) => {
			N.value && (e.key === "Enter" || e.key === " ") && (e.preventDefault(), e.repeat || q(e.key === "Enter" ? "EnterKey" : "SpaceKey", e));
		}, Be = (e) => b?.setCurrent?.(T, { preserveSelection: !!y.value?.[l] || e.relatedTarget?.closest?.(".win-selector-bar") !== y.value?.closest?.(".win-selector-bar") }), Q = () => {
			O.value = !1, J(), K();
		};
		w(() => i(f.IsSelected, h), (e) => {
			E && E.IsSelected !== e && (E.IsSelected = e);
		});
		for (let e of ["Icon", "Child"]) w(() => i(f[e], h), () => {
			E?.SynchronizeBoundProperty ? E.SynchronizeBoundProperty(e) : delete D[e];
		});
		w(N, (e) => {
			e || Q();
		}), ve(() => {
			window.addEventListener("blur", Q), window.addEventListener("pointercancel", X, !0), window.addEventListener("pointerup", Z, !0), window.addEventListener("pointermove", Le, !0);
		}), _e(() => {
			window.removeEventListener("blur", Q), window.removeEventListener("pointercancel", X, !0), window.removeEventListener("pointerup", Z, !0), window.removeEventListener("pointermove", Le, !0), J(), K();
		});
		let $ = E ?? Object.fromEntries([]);
		if (!E) for (let e of Object.keys(c)) Object.defineProperty($, e, {
			enumerable: !0,
			get: () => e === "IsSelected" ? F.value : M(e),
			set: (t) => {
				D[e] = t, a(f[e], t, h);
			}
		});
		me($);
		let Ve = {
			props: f,
			attrs: p,
			slots: m,
			instance: h,
			rootRef: y,
			controller: b,
			itemContext: x,
			dataItem: T,
			model: E,
			local: D,
			pointerOver: O,
			pressed: k,
			directPropertyValues: A,
			makeElement: j,
			read: M,
			isEnabled: N,
			isTokenStyle: P,
			isSelected: F,
			tabIndex: Se,
			stateClasses: Ce,
			rootAttrs: we,
			foreground: I,
			rootStyle: Te,
			chromeStyle: Ee,
			contentStyle: De,
			text: L,
			hasText: Oe,
			elementChildren: R,
			flattenContent: z,
			preparePropertyElements: ke,
			hasIcon: Ae,
			renderPropertyElement: B,
			IconOutlet: je,
			ChildOutlet: Me,
			get pointerId() {
				return V;
			},
			set pointerId(e) {
				V = e;
			},
			get pointerType() {
				return H;
			},
			set pointerType(e) {
				H = e;
			},
			get pointerOrigin() {
				return U;
			},
			set pointerOrigin(e) {
				U = e;
			},
			get pendingPointerClick() {
				return W;
			},
			set pendingPointerClick(e) {
				W = e;
			},
			get pointerClickTimer() {
				return G;
			},
			set pointerClickTimer(e) {
				G = e;
			},
			clearPointerClick: K,
			invoke: q,
			cancelPointer: J,
			onPointerEnter: Ne,
			onPointerDown: Pe,
			onPointerLeave: Fe,
			completePointerRelease: Y,
			onPointerUp: Ie,
			onWindowPointerCancel: X,
			onWindowPointerUp: Z,
			onWindowPointerMove: Le,
			onClick: Re,
			onKeyDown: ze,
			onFocus: Be,
			onWindowBlur: Q,
			publicApi: $,
			get SelectorBarItemIcon() {
				return le;
			},
			get SelectorBarItemChild() {
				return ce;
			},
			Comment: fe,
			Fragment: u,
			Text: pe,
			computed: d,
			defineComponent: g,
			getCurrentInstance: he,
			h: _,
			inject: v,
			isVNode: ge,
			onBeforeUnmount: _e,
			onMounted: ve,
			provide: ye,
			reactive: S,
			ref: C,
			useAttrs: be,
			useSlots: xe,
			watch: w,
			SymbolIcon: ie,
			TextBlock: ae,
			get frameworkLayoutStyle() {
				return ne;
			},
			get alignment() {
				return e;
			},
			get xamlThickness() {
				return t;
			},
			get itemContainerControllerKey() {
				return oe;
			},
			get itemsViewItemContextKey() {
				return se;
			},
			get itemsViewElementKey() {
				return s;
			},
			get selectorBarItemDefaults() {
				return c;
			},
			get selectorBarItemKey() {
				return de;
			},
			get selectorBarPointerFocusKey() {
				return l;
			},
			get selectorBarElementFactory() {
				return ue;
			},
			get selectorBarStyleSetter() {
				return n;
			},
			get isHoverPointer() {
				return o;
			},
			get normalizeXamlNodes() {
				return r;
			},
			get resolveXamlValue() {
				return i;
			},
			get updateXamlBinding() {
				return a;
			},
			get xamlItemContextKey() {
				return ee;
			},
			get xamlScopeKey() {
				return te;
			}
		};
		return Object.defineProperty(Ve, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), Ve;
	}
}), E = [
	"tabindex",
	"aria-selected",
	"aria-disabled"
], D = {
	key: 1,
	class: "win-selector-bar-item-selection-visual",
	"data-template-part": "PART_SelectionVisual",
	"aria-hidden": "true"
}, O = {
	key: 2,
	class: "win-selector-bar-item-common-visual",
	"data-template-part": "PART_CommonVisual",
	"aria-hidden": "true"
};
function k(e, t, n, r, i, a) {
	return x(), p("div", y({ ref: "rootRef" }, r.rootAttrs, {
		class: ["win-selector-bar-item", [r.preparePropertyElements(), r.stateClasses]],
		style: [r.attrs.style, r.rootStyle],
		role: "option",
		tabindex: r.tabIndex,
		"aria-selected": r.isSelected,
		"aria-disabled": !r.isEnabled || void 0,
		onPointerenter: r.onPointerEnter,
		onPointerleave: r.onPointerLeave,
		onPointerdown: r.onPointerDown,
		onPointerup: r.onPointerUp,
		onPointercancel: r.cancelPointer,
		onLostpointercapture: r.cancelPointer,
		onClick: r.onClick,
		onKeydown: r.onKeyDown,
		onFocus: r.onFocus
	}), [m("div", {
		class: "win-selector-bar-item-container-root",
		"data-template-part": "PART_ContainerRoot",
		style: b(r.chromeStyle)
	}, [
		h(r.ChildOutlet),
		r.hasIcon || r.hasText ? (x(), p("div", {
			key: 0,
			class: "win-selector-bar-item-content",
			style: b(r.contentStyle)
		}, [r.hasIcon ? (x(), p("span", {
			key: 0,
			class: "win-selector-bar-item-icon",
			"data-template-part": "PART_IconVisual",
			style: b({ color: r.foreground })
		}, [h(r.IconOutlet)], 4)) : f("", !0), r.hasText ? (x(), me(r.TextBlock, {
			key: 1,
			class: "win-selector-bar-item-text",
			"data-template-part": "PART_TextVisual",
			Text: "{x:Bind TemplateText}",
			Foreground: "{x:Bind TemplateForeground}",
			TextWrapping: "Wrap",
			FontFamily: "{x:Bind TemplateFontFamily}",
			FontSize: "{x:Bind TemplateFontSize}",
			FontWeight: "{x:Bind TemplateFontWeight}"
		})) : f("", !0)], 4)) : f("", !0),
		r.isTokenStyle ? f("", !0) : (x(), p("span", D)),
		r.isTokenStyle ? f("", !0) : (x(), p("span", O))
	], 4)], 16, E);
}
var A = /*#__PURE__*/ re(T, [
	["render", k],
	["__scopeId", "data-v-b2db0486"],
	["__file", "SelectorBarItem.vue"]
]);
//#endregion
export { A as default };

//# sourceMappingURL=SelectorBarItem.vue.js.map