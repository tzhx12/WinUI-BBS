import { resolveXamlValue as e } from "./xamlRuntime.js";
import { frameworkLayoutStyle as t } from "./frameworkLayout.js";
import n from "../_virtual/_plugin-vue_export-helper.js";
/* empty css                                                    */
import { computed as r, createElementBlock as i, getCurrentInstance as a, mergeProps as o, onBeforeUnmount as s, openBlock as c, provide as l, ref as u, renderSlot as d, useAttrs as f } from "vue";
//#region src/components/SwitchPresenter.vue
var p = /*@__PURE__*/ Object.assign({ inheritAttrs: !1 }, {
	__name: "SwitchPresenter",
	props: {
		Value: {
			type: [
				String,
				Number,
				Boolean,
				Object
			],
			default: null
		},
		SwitchCases: {
			type: Array,
			default: () => []
		},
		TargetType: {
			type: [
				String,
				Object,
				Function
			],
			default: null
		}
	},
	setup(n, { expose: i }) {
		let o = n, c = u([]), d = a(), p = f(), m = r(() => e(o.Value, d)), h = r(() => t(p, d)), g = 0, _ = (e, t) => o.TargetType === String ? String(e) === String(t) : o.TargetType === Number ? Number(e) === Number(t) : Object.is(e, t) || String(e) === String(t), v = r(() => [...c.value.map((e) => e.get()), ...o.SwitchCases.map((e) => ({
			Value: e?.Value,
			IsDefault: e?.IsDefault === !0,
			Content: e?.Content
		}))]), y = r(() => {
			let e = v.value;
			return e.find((e) => _(e.Value, m.value)) || e.find((e) => e.IsDefault) || null;
		}), b = (e, t = !1) => _(e, m.value) ? !0 : t && !y.value, x = (e) => {
			let t = g++;
			return c.value = [...c.value, {
				id: t,
				get: e
			}], () => {
				c.value = c.value.filter((e) => e.id !== t);
			};
		};
		l("win-switch-presenter", {
			isCaseActive: b,
			registerCase: x,
			CurrentCase: y
		}), i({
			Value: r(() => o.Value),
			SwitchCases: r(() => o.SwitchCases),
			CurrentCase: y,
			TargetType: r(() => o.TargetType)
		}), s(() => {
			c.value = [];
		});
		let S = {
			props: o,
			registeredCases: c,
			instance: d,
			attrs: p,
			value: m,
			layoutStyle: h,
			get nextCaseId() {
				return g;
			},
			set nextCaseId(e) {
				g = e;
			},
			valuesEqual: _,
			caseEntries: v,
			currentCase: y,
			isCaseActive: b,
			registerCase: x,
			computed: r,
			getCurrentInstance: a,
			onBeforeUnmount: s,
			provide: l,
			ref: u,
			useAttrs: f,
			get resolveXamlValue() {
				return e;
			},
			get frameworkLayoutStyle() {
				return t;
			}
		};
		return Object.defineProperty(S, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), S;
	}
});
function m(e, t, n, r, a, s) {
	return c(), i("div", o({ class: "win-switch-presenter" }, e.$attrs, { style: r.layoutStyle }), [d(e.$slots, "default")], 16);
}
var h = /*#__PURE__*/ n(p, [["render", m], ["__file", "SwitchPresenter.vue"]]);
//#endregion
export { h as default };

//# sourceMappingURL=SwitchPresenter.vue.js.map