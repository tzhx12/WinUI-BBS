//#region src/components/teachingTipPlacement.ts
var e = [
	"Top",
	"Bottom",
	"Left",
	"Right",
	"TopLeft",
	"TopRight",
	"BottomLeft",
	"BottomRight",
	"LeftTop",
	"LeftBottom",
	"RightTop",
	"RightBottom",
	"Center"
], t = (e, t, n) => Math.max(t, Math.min(n, e));
function n(e) {
	if (e && typeof e == "object") {
		let t = e;
		return {
			left: Number(t.Left ?? t.left) || 0,
			top: Number(t.Top ?? t.top) || 0,
			right: Number(t.Right ?? t.right) || 0,
			bottom: Number(t.Bottom ?? t.bottom) || 0
		};
	}
	let t = String(e ?? 0).split(",").map(Number);
	return t.length === 1 ? {
		left: t[0],
		top: t[0],
		right: t[0],
		bottom: t[0]
	} : t.length === 2 ? {
		left: t[0],
		top: t[1],
		right: t[0],
		bottom: t[1]
	} : {
		left: t[0] || 0,
		top: t[1] || 0,
		right: t[2] || 0,
		bottom: t[3] || 0
	};
}
function r(e) {
	return [
		"Bottom",
		"BottomLeft",
		"BottomRight"
	].includes(e) ? "top" : [
		"Left",
		"LeftTop",
		"LeftBottom"
	].includes(e) ? "right" : [
		"Right",
		"RightTop",
		"RightBottom"
	].includes(e) ? "left" : "bottom";
}
function i(n, r, i, a, o, s, c, l = !1) {
	let u = l ? a.replace(/Left|Right/g, (e) => e === "Left" ? "Right" : "Left") : a, d = e.includes(u) ? u : n ? "Top" : "Bottom";
	if (!n) {
		let e = i.left + 24 + o.left, t = i.right - r.width - 24 - o.right, n = i.top + 24 + o.top, a = i.bottom - r.height - 24 - o.bottom, s = i.left + (i.width - r.width) / 2 + o.left - o.right, c = i.top + (i.height - r.height) / 2 + o.top - o.bottom;
		return {
			left: [
				"Left",
				"TopLeft",
				"BottomLeft",
				"LeftTop",
				"LeftBottom"
			].includes(d) ? e : [
				"Right",
				"TopRight",
				"BottomRight",
				"RightTop",
				"RightBottom"
			].includes(d) ? t : s,
			top: [
				"Top",
				"TopLeft",
				"TopRight",
				"LeftTop",
				"RightTop"
			].includes(d) ? n : [
				"Bottom",
				"BottomLeft",
				"BottomRight",
				"LeftBottom",
				"RightBottom"
			].includes(d) ? a : c,
			placement: d
		};
	}
	let f = n.left + n.width / 2, p = n.top + n.height / 2, m = (e) => {
		let t = f - r.width / 2, i = n.top - r.height - o.top;
		return [
			"Bottom",
			"BottomLeft",
			"BottomRight"
		].includes(e) && (i = n.bottom + o.bottom), ["TopLeft", "BottomLeft"].includes(e) && (t = f - r.width + 28), ["TopRight", "BottomRight"].includes(e) && (t = f - 28), [
			"Left",
			"LeftTop",
			"LeftBottom"
		].includes(e) && (t = n.left - r.width - o.left), [
			"Right",
			"RightTop",
			"RightBottom"
		].includes(e) && (t = n.right + o.right), (e === "Left" || e === "Right") && (i = p - r.height / 2), (e === "LeftTop" || e === "RightTop") && (i = p - r.height + 28), (e === "LeftBottom" || e === "RightBottom") && (i = p - 28), e === "Center" && (i = p - r.height - o.top), {
			left: t,
			top: i,
			placement: e
		};
	}, h = [...e], g = (e, t) => {
		[h[e], h[t]] = [h[t], h[e]];
	};
	d.startsWith("Bottom") ? (g(0, 1), g(4, 6), g(5, 7)) : (d.startsWith("Left") || d.startsWith("Right")) && (g(0, 2), g(1, 3), g(4, 8), g(5, 9), g(6, 10), g(7, 11), d.startsWith("Right") && (g(0, 1), g(4, 6), g(5, 7))), h.splice(h.indexOf(d), 1), h.unshift(d);
	let _ = h.find((e) => {
		if (c && s === "Top" && [
			"Bottom",
			"BottomLeft",
			"BottomRight",
			"LeftBottom",
			"RightBottom"
		].includes(e) || c && s === "Bottom" && [
			"Top",
			"TopLeft",
			"TopRight",
			"LeftTop",
			"RightTop",
			"Center"
		].includes(e)) return !1;
		let t = m(e);
		return t.left >= i.left && t.top >= i.top && t.left + r.width <= i.right && t.top + r.height <= i.bottom;
	});
	if (_) return m(_);
	let v = m(d);
	return {
		...v,
		left: t(v.left, i.left, i.right - r.width),
		top: t(v.top, i.top, i.bottom - r.height)
	};
}
//#endregion
export { i as teachingTipPlacement, r as teachingTipTailSide, n as teachingTipThickness };

//# sourceMappingURL=teachingTipPlacement.js.map