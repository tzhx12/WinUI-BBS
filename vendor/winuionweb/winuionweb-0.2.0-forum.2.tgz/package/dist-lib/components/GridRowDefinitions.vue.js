import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./GridRowDefinitions.vue_vue_type_script_setup_true_lang.js";
import { createBlock as n, openBlock as r, renderSlot as i, withCtx as a } from "vue";
//#region src/components/GridRowDefinitions.vue
function o(e, t, o, s, c, l) {
	return r(), n(s.GridDefinitions, { axis: "rows" }, {
		default: a(() => [i(e.$slots, "default")]),
		_: 3
	});
}
var s = /*#__PURE__*/ e(t, [["render", o], ["__file", "GridRowDefinitions.vue"]]);
//#endregion
export { s as default };

//# sourceMappingURL=GridRowDefinitions.vue.js.map