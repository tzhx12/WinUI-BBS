import e from "../_virtual/_plugin-vue_export-helper.js";
import "./personPictureProperties.js";
import t from "./PersonPicture.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                  */
import { createBlock as n, createCommentVNode as r, createElementBlock as i, createVNode as a, mergeProps as o, openBlock as s, withCtx as c } from "vue";
//#region src/components/PersonPicture.vue
var l = [
	"data-person-picture-state",
	"data-person-picture-badge-state",
	"aria-label",
	"aria-disabled",
	"tabindex"
];
function u(e, t, u, d, f, p) {
	return s(), i("div", o({ ref: "root" }, d.rootAttrs, {
		class: ["win-person-picture", d.attrs.class],
		style: [d.attrs.style, d.rootStyle],
		"data-person-picture-state": d.commonState,
		"data-person-picture-badge-state": d.badgeState,
		role: "img",
		"aria-label": d.automationLabel,
		"aria-disabled": !d.isEnabled || void 0,
		tabindex: d.isTabStop ? 0 : void 0
	}), [a(d.Grid, {
		"x:Name": "RootGrid",
		class: "win-person-picture-root",
		Width: "{x:Bind Template.Size, Mode=OneWay}",
		Height: "{x:Bind Template.Size, Mode=OneWay}"
	}, {
		default: c(() => [
			a(d.Ellipse, {
				class: "win-person-picture-ellipse",
				Fill: "{x:Bind Template.Background, Mode=OneWay}",
				Stroke: "{x:Bind Template.BorderBrush, Mode=OneWay}",
				StrokeThickness: "{x:Bind Template.BorderThickness, Mode=OneWay}",
				Width: "{x:Bind Template.Size, Mode=OneWay}",
				Height: "{x:Bind Template.Size, Mode=OneWay}"
			}),
			a(d.TextBlock, {
				"x:Name": "InitialsTextBlock",
				class: "win-person-picture-initials",
				"AutomationProperties.AccessibilityView": "Raw",
				Text: "{x:Bind Template.DisplayedText, Mode=OneWay}",
				FontSize: "{x:Bind Template.InitialsFontSize, Mode=OneWay}",
				FontFamily: "{x:Bind Template.FontFamily, Mode=OneWay}",
				FontWeight: "{x:Bind Template.FontWeight, Mode=OneWay}",
				Foreground: "{x:Bind Template.Foreground, Mode=OneWay}",
				TextLineBounds: "Tight",
				IsTextScaleFactorEnabled: "False",
				VerticalAlignment: "Center",
				HorizontalAlignment: "Center"
			}),
			d.commonState === "Photo" ? (s(), n(d.Ellipse, {
				key: 0,
				"x:Name": "PersonPictureEllipse",
				class: "win-person-picture-photo-ellipse",
				Fill: "{x:Bind Template.PhotoFill, Mode=OneWay}",
				Width: "{x:Bind Template.Size, Mode=OneWay}",
				Height: "{x:Bind Template.Size, Mode=OneWay}",
				FlowDirection: "LeftToRight"
			})) : r("", !0),
			a(d.Grid, {
				"x:Name": "BadgeGrid",
				class: "win-person-picture-badge-grid",
				Visibility: "{x:Bind Template.BadgeVisibility, Mode=OneWay}",
				Width: "{x:Bind Template.BadgeSize, Mode=OneWay}",
				Height: "{x:Bind Template.BadgeSize, Mode=OneWay}",
				VerticalAlignment: "Top",
				HorizontalAlignment: "Right",
				Margin: "{ThemeResource PersonPictureBadgeGridMargin}"
			}, {
				default: c(() => [
					a(d.Ellipse, {
						"x:Name": "BadgingBackgroundEllipse",
						Opacity: "{ThemeResource PersonPictureEllipseBadgeStrokeOpacity}",
						Fill: "{ThemeResource PersonPictureEllipseBadgeFillThemeBrush}",
						Stroke: "{ThemeResource PersonPictureEllipseBadgeStrokeThemeBrush}",
						StrokeThickness: "{ThemeResource PersonPictureEllipseBadgeStrokeThickness}",
						Width: "{x:Bind Template.BadgeSize, Mode=OneWay}",
						Height: "{x:Bind Template.BadgeSize, Mode=OneWay}"
					}),
					a(d.Ellipse, {
						"x:Name": "BadgingEllipse",
						class: "win-person-picture-badge-image-ellipse",
						Fill: "{x:Bind Template.BadgeImageBrush, Mode=OneWay}",
						Opacity: "{x:Bind Template.BadgeImageOpacity, Mode=OneWay}",
						Width: "{x:Bind Template.BadgeSize, Mode=OneWay}",
						Height: "{x:Bind Template.BadgeSize, Mode=OneWay}",
						FlowDirection: "LeftToRight"
					}),
					a(d.TextBlock, {
						"x:Name": "BadgeNumberTextBlock",
						class: "win-person-picture-badge-number",
						"AutomationProperties.AccessibilityView": "Raw",
						Visibility: "{x:Bind Template.BadgeNumberVisibility, Mode=OneWay}",
						Text: "{x:Bind Template.BadgeNumberText, Mode=OneWay}",
						FontSize: "{x:Bind Template.BadgeFontSize, Mode=OneWay}",
						FontFamily: "{x:Bind Template.ContentFontFamily, Mode=OneWay}",
						FontWeight: "{x:Bind Template.FontWeight, Mode=OneWay}",
						Foreground: "{ThemeResource PersonPictureEllipseBadgeForegroundThemeBrush}",
						TextLineBounds: "Tight",
						IsTextScaleFactorEnabled: "False",
						VerticalAlignment: "Center",
						HorizontalAlignment: "Center"
					}),
					a(d.FontIcon, {
						"x:Name": "BadgeGlyphIcon",
						class: "win-person-picture-badge-glyph",
						"AutomationProperties.AccessibilityView": "Raw",
						Glyph: "{x:Bind Template.BadgeGlyph, Mode=OneWay}",
						FontSize: "{x:Bind Template.BadgeFontSize, Mode=OneWay}",
						Foreground: "{ThemeResource PersonPictureEllipseBadgeForegroundThemeBrush}",
						FontFamily: "{ThemeResource SymbolThemeFontFamily}",
						FontWeight: "{x:Bind Template.FontWeight, Mode=OneWay}",
						VerticalAlignment: "Center",
						HorizontalAlignment: "Center"
					})
				]),
				_: 1
			})
		]),
		_: 1
	}), a(d.SourceOutlet)], 16, l);
}
var d = /*#__PURE__*/ e(t, [["render", u], ["__file", "PersonPicture.vue"]]);
//#endregion
export { d as default };

//# sourceMappingURL=PersonPicture.vue.js.map