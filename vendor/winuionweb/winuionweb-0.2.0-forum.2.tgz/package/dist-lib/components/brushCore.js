import { reactive as e } from "vue";
//#region src/components/brushCore.ts
var t = Symbol.for("WinUIonWeb.Xaml.BrushResources"), n = Symbol.for("WinUIonWeb.Xaml.Theme"), r = {
	aliceblue: "#FFF0F8FF",
	antiquewhite: "#FFFAEBD7",
	aqua: "#FF00FFFF",
	aquamarine: "#FF7FFFD4",
	azure: "#FFF0FFFF",
	beige: "#FFF5F5DC",
	bisque: "#FFFFE4C4",
	black: "#FF000000",
	blanchedalmond: "#FFFFEBCD",
	blue: "#FF0000FF",
	blueviolet: "#FF8A2BE2",
	brown: "#FFA52A2A",
	burlywood: "#FFDEB887",
	cadetblue: "#FF5F9EA0",
	chartreuse: "#FF7FFF00",
	chocolate: "#FFD2691E",
	coral: "#FFFF7F50",
	cornflowerblue: "#FF6495ED",
	cornsilk: "#FFFFF8DC",
	crimson: "#FFDC143C",
	cyan: "#FF00FFFF",
	darkblue: "#FF00008B",
	darkcyan: "#FF008B8B",
	darkgoldenrod: "#FFB8860B",
	darkgray: "#FFA9A9A9",
	darkgreen: "#FF006400",
	darkkhaki: "#FFBDB76B",
	darkmagenta: "#FF8B008B",
	darkolivegreen: "#FF556B2F",
	darkorange: "#FFFF8C00",
	darkorchid: "#FF9932CC",
	darkred: "#FF8B0000",
	darksalmon: "#FFE9967A",
	darkseagreen: "#FF8FBC8F",
	darkslateblue: "#FF483D8B",
	darkslategray: "#FF2F4F4F",
	darkturquoise: "#FF00CED1",
	darkviolet: "#FF9400D3",
	deeppink: "#FFFF1493",
	deepskyblue: "#FF00BFFF",
	dimgray: "#FF696969",
	dodgerblue: "#FF1E90FF",
	firebrick: "#FFB22222",
	floralwhite: "#FFFFFAF0",
	forestgreen: "#FF228B22",
	fuchsia: "#FFFF00FF",
	gainsboro: "#FFDCDCDC",
	ghostwhite: "#FFF8F8FF",
	gold: "#FFFFD700",
	goldenrod: "#FFDAA520",
	gray: "#FF808080",
	green: "#FF008000",
	greenyellow: "#FFADFF2F",
	honeydew: "#FFF0FFF0",
	hotpink: "#FFFF69B4",
	indianred: "#FFCD5C5C",
	indigo: "#FF4B0082",
	ivory: "#FFFFFFF0",
	khaki: "#FFF0E68C",
	lavender: "#FFE6E6FA",
	lavenderblush: "#FFFFF0F5",
	lawngreen: "#FF7CFC00",
	lemonchiffon: "#FFFFFACD",
	lightblue: "#FFADD8E6",
	lightcoral: "#FFF08080",
	lightcyan: "#FFE0FFFF",
	lightgoldenrodyellow: "#FFFAFAD2",
	lightgreen: "#FF90EE90",
	lightgray: "#FFD3D3D3",
	lightpink: "#FFFFB6C1",
	lightsalmon: "#FFFFA07A",
	lightseagreen: "#FF20B2AA",
	lightskyblue: "#FF87CEFA",
	lightslategray: "#FF778899",
	lightsteelblue: "#FFB0C4DE",
	lightyellow: "#FFFFFFE0",
	lime: "#FF00FF00",
	limegreen: "#FF32CD32",
	linen: "#FFFAF0E6",
	magenta: "#FFFF00FF",
	maroon: "#FF800000",
	mediumaquamarine: "#FF66CDAA",
	mediumblue: "#FF0000CD",
	mediumorchid: "#FFBA55D3",
	mediumpurple: "#FF9370DB",
	mediumseagreen: "#FF3CB371",
	mediumslateblue: "#FF7B68EE",
	mediumspringgreen: "#FF00FA9A",
	mediumturquoise: "#FF48D1CC",
	mediumvioletred: "#FFC71585",
	midnightblue: "#FF191970",
	mintcream: "#FFF5FFFA",
	mistyrose: "#FFFFE4E1",
	moccasin: "#FFFFE4B5",
	navajowhite: "#FFFFDEAD",
	navy: "#FF000080",
	oldlace: "#FFFDF5E6",
	olive: "#FF808000",
	olivedrab: "#FF6B8E23",
	orange: "#FFFFA500",
	orangered: "#FFFF4500",
	orchid: "#FFDA70D6",
	palegoldenrod: "#FFEEE8AA",
	palegreen: "#FF98FB98",
	paleturquoise: "#FFAFEEEE",
	palevioletred: "#FFDB7093",
	papayawhip: "#FFFFEFD5",
	peachpuff: "#FFFFDAB9",
	peru: "#FFCD853F",
	pink: "#FFFFC0CB",
	plum: "#FFDDA0DD",
	powderblue: "#FFB0E0E6",
	purple: "#FF800080",
	red: "#FFFF0000",
	rosybrown: "#FFBC8F8F",
	royalblue: "#FF4169E1",
	saddlebrown: "#FF8B4513",
	salmon: "#FFFA8072",
	sandybrown: "#FFF4A460",
	seagreen: "#FF2E8B57",
	seashell: "#FFFFF5EE",
	sienna: "#FFA0522D",
	silver: "#FFC0C0C0",
	skyblue: "#FF87CEEB",
	slateblue: "#FF6A5ACD",
	slategray: "#FF708090",
	snow: "#FFFFFAFA",
	springgreen: "#FF00FF7F",
	steelblue: "#FF4682B4",
	tan: "#FFD2B48C",
	teal: "#FF008080",
	thistle: "#FFD8BFD8",
	tomato: "#FFFF6347",
	transparent: "#00FFFFFF",
	turquoise: "#FF40E0D0",
	violet: "#FFEE82EE",
	wheat: "#FFF5DEB3",
	white: "#FFFFFFFF",
	whitesmoke: "#FFF5F5F5",
	yellow: "#FFFFFF00",
	yellowgreen: "#FF9ACD32"
}, i = (e) => {
	let t = String(e ?? "Transparent").trim();
	if (r[t.toLowerCase()]) return r[t.toLowerCase()];
	if (/^#[\da-f]{6}$/i.test(t)) return `#FF${t.slice(1).toUpperCase()}`;
	if (/^#[\da-f]{8}$/i.test(t)) return t.toUpperCase();
	if (/^#[\da-f]{3}$/i.test(t)) return "#FF" + t.slice(1).split("").map((e) => e + e).join("").toUpperCase();
	let n = t.match(/^rgba?\(\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)(?:\s*,\s*([\d.]+))?\s*\)$/i);
	return n ? "#" + [Math.round(Number(n[4] ?? 1) * 255), ...n.slice(1, 4).map(Number)].map((e) => Math.max(0, Math.min(255, e)).toString(16).padStart(2, "0")).join("").toUpperCase() : t;
}, a = (e) => {
	let t = i(e);
	return /^#[\da-f]{8}$/i.test(t) ? {
		a: parseInt(t.slice(1, 3), 16) / 255,
		r: parseInt(t.slice(3, 5), 16),
		g: parseInt(t.slice(5, 7), 16),
		b: parseInt(t.slice(7, 9), 16)
	} : {
		r: 255,
		g: 255,
		b: 255,
		a: 1
	};
}, o = (e) => {
	let t = i(e);
	if (!/^#[\da-f]{8}$/i.test(t)) return t;
	let { r: n, g: r, b: o, a: s } = a(t);
	return `rgba(${n}, ${r}, ${o}, ${s})`;
}, s = (e, t = 1) => {
	let n = Number(e);
	return Number.isFinite(n) ? Math.max(0, Math.min(1, n)) : t;
}, c = (t = "Transparent", n = 1) => e({
	__xamlBrush: "SolidColorBrush",
	Color: i(t),
	Opacity: s(n)
}), l = (t = {}) => {
	let n = e(new Proxy({
		__xamlBrush: "AcrylicBrush",
		TintColor: "#CCFFFFFF",
		TintOpacity: 1,
		TintLuminosityOpacity: null,
		TintTransitionDuration: 500,
		AlwaysUseFallback: !1,
		FallbackColor: "#00FFFFFF",
		Opacity: 1
	}, { set(e, t, n, r) {
		let a = n;
		return t === "TintColor" || t === "FallbackColor" ? a = i(n) : t === "Opacity" || t === "TintOpacity" ? a = s(n) : t === "TintLuminosityOpacity" ? a = n === null ? null : s(n) : t === "AlwaysUseFallback" ? a = n === !0 || n === "True" : t === "TintTransitionDuration" && (a = Math.max(0, Number(n) || 0)), Reflect.set(e, t, a, r);
	} }));
	return Object.assign(n, t), n;
}, u = (e) => !!(e && typeof e == "object" && e.__xamlBrush === "AcrylicBrush"), d = (e) => !!(e && typeof e == "object" && e.__xamlBrush === "SolidColorBrush"), f = (e) => {
	let { r: t, g: n, b: r, a: i } = a(e.TintColor), o = Math.max(t, n, r) / 255, c = Math.min(t, n, r) / 255, l = o === 0 ? 0 : (o - c) / o, u = i * s(e.TintOpacity), d = e.TintLuminosityOpacity !== null && e.TintLuminosityOpacity !== void 0, f = o > .5 ? .45 * (o - .5) / .5 : .05 * (.5 - o) / .5, p = Math.round(255 * u * (d ? 1 : .9 - f * Math.max(1 - 2 * l, 0))) / 255, m = Math.max(.125, Math.min(.965, o)), h = o === 0 ? 0 : m / o, g = d ? [
		t,
		n,
		r
	] : o === 0 ? [
		m * 255,
		m * 255,
		m * 255
	] : [
		t * h,
		n * h,
		r * h
	], _ = d ? Math.round(255 * s(e.TintLuminosityOpacity)) / 255 : Math.round(255 * Math.min(Math.round(u * 255) / 255 * .88 + .15, 1)) / 255;
	return {
		tint: `rgba(${t}, ${n}, ${r}, ${p})`,
		luminosity: `rgba(${g.map(Math.round).join(", ")}, ${_})`,
		opaque: p >= 1
	};
};
//#endregion
export { f as acrylicColors, s as clampOpacity, a as colorChannels, i as colorString, l as createAcrylicBrush, c as createSolidColorBrush, o as cssColor, u as isAcrylicBrush, d as isSolidColorBrush, t as xamlBrushResourceKey, n as xamlThemeKey };

//# sourceMappingURL=brushCore.js.map