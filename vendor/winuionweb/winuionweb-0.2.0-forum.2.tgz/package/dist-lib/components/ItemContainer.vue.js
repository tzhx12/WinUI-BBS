import { useAcrylicBrushStyle as e } from "./AcrylicBrush.js";
import { resolveXamlValue as t, xamlItemContextKey as n } from "./xamlRuntime.js";
import { vAcrylicBrush as r } from "./acrylicBrushVisual.js";
import i from "../_virtual/_plugin-vue_export-helper.js";
import { isHoverPointer as a } from "./pointerInput.js";
import o from "./CheckBox.vue.js";
import { itemContainerControllerKey as s, itemsViewItemContextKey as c } from "./ItemsViewState.js";
/* empty css                                                                  */
import { computed as l, createBlock as u, createCommentVNode as d, createElementBlock as f, createElementVNode as p, getCurrentInstance as m, inject as h, normalizeClass as g, normalizeStyle as _, openBlock as v, ref as y, renderSlot as b, withDirectives as x, withModifiers as S } from "vue";
//#region src/components/ItemContainer.vue
var C = {
	__name: "ItemContainer",
	props: {
		IsSelected: {
			type: [Boolean, String],
			default: !1
		},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		Width: {
			type: [String, Number],
			default: void 0
		},
		Height: {
			type: [String, Number],
			default: void 0
		},
		MinWidth: {
			type: [String, Number],
			default: void 0
		},
		MinHeight: {
			type: [String, Number],
			default: void 0
		},
		MaxWidth: {
			type: [String, Number],
			default: void 0
		},
		MaxHeight: {
			type: [String, Number],
			default: void 0
		},
		Margin: {
			type: [String, Number],
			default: ""
		},
		Background: {
			type: [String, Object],
			default: ""
		},
		CornerRadius: {
			type: [String, Number],
			default: ""
		}
	},
	setup(i, { expose: u }) {
		let d = i, f = m(), p = y(null), g = h(s, null), _ = h(c, null), v = h(n, void 0), b = l(() => g?.isEnabled?.() ?? t(d.IsEnabled, f) !== !1), x = l(() => g && v !== void 0 ? g.isSelected(v) : t(d.IsSelected, f) === !0), S = l(() => g?.multiSelectMode?.() ?? "Single"), C = l(() => (g?.selectionMode?.() ?? "Single") !== "None"), w = l(() => _?.tabIndex?.() ?? -1), T = l(() => S.value === "Multiple" || S.value === "Extended"), E = y(!1), D = y(!1), O = l(() => b.value ? D.value ? x.value ? "SelectedPressed" : "UnselectedPressed" : E.value ? x.value ? "SelectedPointerOver" : "UnselectedPointerOver" : x.value ? "SelectedNormal" : "UnselectedNormal" : x.value ? "SelectedNormal" : "UnselectedNormal"), k = l(() => [O.value, {
			"multi-select": T.value,
			disabled: !b.value
		}]), A = (e) => {
			if (!(e == null || e === "")) return typeof e == "number" || /^-?\d+(?:\.\d+)?$/.test(String(e)) ? `${e}px` : String(e);
		}, j = (e) => {
			let t = String(e ?? "").split(",").map((e) => A(e.trim())).filter(Boolean);
			if (t.length === 1) return t[0];
			if (t.length === 2) return `${t[1]} ${t[0]}`;
			if (t.length === 4) return `${t[1]} ${t[2]} ${t[3]} ${t[0]}`;
		}, M = l(() => A(t(d.CornerRadius, f)) || "var(--ControlCornerRadius, 4px)"), N = l(() => {
			let e = _?.geometry?.();
			return {
				width: e?.width ?? A(t(d.Width, f)),
				height: e?.height ?? A(t(d.Height, f)),
				minWidth: A(t(d.MinWidth, f)),
				minHeight: A(t(d.MinHeight, f)),
				maxWidth: A(t(d.MaxWidth, f)),
				maxHeight: A(t(d.MaxHeight, f)),
				margin: j(t(d.Margin, f)),
				borderRadius: M.value,
				flex: e?.flex
			};
		}), P = e(() => d.Background || void 0, f), F = l(() => ({
			borderRadius: M.value,
			...P.value
		})), I = (e) => {
			E.value = a(e);
		}, L = () => !!(g?.canUserInvoke?.() || g?.canUserSelect?.()), R = (e, t) => !b.value || !L() ? !1 : (g?.itemInvoked?.(v, e, t), !0), z = (e) => {
			b.value && (e.pointerType === "mouse" && e.button !== 0 || (D.value = !0, a(e) || (E.value = !1)));
		}, B = (e) => {
			D.value && (D.value = !1, a(e) || (E.value = !1), R("PointerReleased", e));
		}, V = () => {
			D.value = !1, E.value = !1;
		}, H = (e) => {
			R("Tap", e);
		}, U = (e) => {
			R("DoubleTap", e);
		}, W = (e) => {
			b.value && (e.key === "Enter" ? R("EnterKey", e) : e.key === " " && (e.preventDefault(), R("SpaceKey", e)));
		}, G = () => {
			g?.setCurrent?.(v);
		};
		u({ IsSelected: x });
		let K = {
			props: d,
			instance: f,
			rootRef: p,
			controller: g,
			itemContext: _,
			dataItem: v,
			isEnabled: b,
			isSelected: x,
			multiSelectMode: S,
			selectionEnabled: C,
			tabIndex: w,
			showsSelectionCheckbox: T,
			isPointerOver: E,
			isPressed: D,
			combinedState: O,
			stateClasses: k,
			cssLength: A,
			xamlThickness: j,
			resolvedCornerRadius: M,
			rootStyle: N,
			backgroundStyle: P,
			rootChromeStyle: F,
			onPointerEnter: I,
			canRaiseItemInvoked: L,
			raiseItemInvoked: R,
			onPointerDown: z,
			onPointerUp: B,
			onPointerCancel: V,
			onClick: H,
			onDoubleClick: U,
			onKeyDown: W,
			onFocus: G,
			computed: l,
			getCurrentInstance: m,
			inject: h,
			ref: y,
			CheckBox: o,
			get itemContainerControllerKey() {
				return s;
			},
			get itemsViewItemContextKey() {
				return c;
			},
			get resolveXamlValue() {
				return t;
			},
			get xamlItemContextKey() {
				return n;
			},
			get useAcrylicBrushStyle() {
				return e;
			},
			get vAcrylicBrush() {
				return r;
			},
			get isHoverPointer() {
				return a;
			}
		};
		return Object.defineProperty(K, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), K;
	}
}, w = [
	"tabindex",
	"aria-selected",
	"aria-disabled"
], T = { class: "win-item-container-child" };
function E(e, t, n, r, i, a) {
	return v(), f("div", {
		ref: "rootRef",
		class: g(["win-item-container", r.stateClasses]),
		style: _(r.rootStyle),
		tabindex: r.tabIndex,
		"aria-selected": r.selectionEnabled ? r.isSelected : void 0,
		"aria-disabled": !r.isEnabled || void 0,
		role: "option",
		onPointerenter: r.onPointerEnter,
		onPointerleave: t[3] ||= (e) => r.isPointerOver = !1,
		onPointerdown: r.onPointerDown,
		onPointerup: r.onPointerUp,
		onPointercancel: r.onPointerCancel,
		onLostpointercapture: r.onPointerCancel,
		onClick: r.onClick,
		onDblclick: r.onDoubleClick,
		onKeydown: r.onKeyDown,
		onFocus: r.onFocus
	}, [x((v(), f("div", {
		class: "win-item-container-root",
		style: _(r.rootChromeStyle)
	}, [
		p("div", T, [b(e.$slots, "default", {}, void 0, !0)]),
		t[4] ||= p("div", {
			class: "win-item-container-selection-visual",
			"aria-hidden": "true"
		}, null, -1),
		t[5] ||= p("div", {
			class: "win-item-container-common-visual",
			"aria-hidden": "true"
		}, null, -1),
		r.showsSelectionCheckbox ? (v(), u(r.CheckBox, {
			key: 0,
			class: "win-item-container-checkbox",
			IsChecked: "{x:Bind isSelected, Mode=OneWay}",
			IsTabStop: "False",
			IsHitTestVisible: "False",
			onClick: t[0] ||= S(() => {}, ["stop"]),
			onPointerdown: t[1] ||= S(() => {}, ["stop"]),
			onKeydown: t[2] ||= S(() => {}, ["stop"])
		})) : d("", !0)
	], 4)), [[r.vAcrylicBrush, r.backgroundStyle]])], 46, w);
}
var D = /*#__PURE__*/ i(C, [
	["render", E],
	["__scopeId", "data-v-a3d231c4"],
	["__file", "ItemContainer.vue"]
]);
//#endregion
export { D as default };

//# sourceMappingURL=ItemContainer.vue.js.map