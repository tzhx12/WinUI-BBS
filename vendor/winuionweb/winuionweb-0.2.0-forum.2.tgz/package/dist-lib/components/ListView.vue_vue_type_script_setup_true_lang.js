import { useAcrylicBrushStyle as e } from "./AcrylicBrush.js";
import { materializeXamlVNode as t, normalizeXamlNodes as n, resolveXamlHandler as r, resolveXamlValue as i, updateXamlBinding as a, xamlItemContextKey as o, xamlNameScopeKey as s, xamlScopeKey as c } from "./xamlRuntime.js";
import { vAcrylicBrush as l } from "./acrylicBrushVisual.js";
import { xamlResourceDictionaryKey as ee } from "./Page.vue_vue_type_script_lang.js";
import { CollectionGroupHeaderTemplate as te, CollectionGroupStyle as ne, CollectionItemContainerStyle as re, CollectionItemTemplate as ie, CollectionItemsPanel as u, getCollectionProperty as ae, getVNodeChildren as d } from "./CollectionProperties.js";
import oe from "./ScrollViewer.vue.js";
import { scrollViewerTemplateBindings as se } from "./scrollViewerTemplateBindings.js";
import ce from "./CheckBox.vue.js";
import { createSemanticZoomView as le } from "./semanticZoomView.js";
import { attachSecondaryTouchScrollDuringDrag as ue } from "./pointerDragTouchScroll.js";
import { Fragment as de, cloneVNode as fe, computed as f, defineComponent as pe, getCurrentInstance as me, h as he, inject as ge, isVNode as _e, nextTick as ve, onBeforeUnmount as ye, onMounted as be, provide as xe, ref as p, shallowReactive as Se, shallowRef as Ce, toRaw as m, useAttrs as we, useSlots as Te, watch as Ee } from "vue";
//#region src/components/ListView.vue?vue&type=script&setup=true&lang.ts
var De = pe({
	name: "ListView.Header",
	__listViewHeader: !0,
	setup(e, { slots: t }) {
		return () => he(de, t.default?.());
	}
}), Oe = pe({
	name: "ListView.Resources",
	__xamlResourceProperty: "resources",
	setup() {
		return () => null;
	}
}), h = /*@__PURE__*/ pe({
	Resources: Oe,
	Header: De,
	GroupHeaderTemplate: te,
	GroupStyle: ne,
	ItemTemplate: ie,
	ItemsPanel: u,
	ItemContainerStyle: re,
	__name: "ListView",
	props: {
		ItemsSource: { default: () => [] },
		IsGrouped: { type: [Boolean, String] },
		IsItemClickEnabled: {
			type: [Boolean, String],
			default: !1
		},
		CanDrag: {
			type: [Boolean, String],
			default: !1
		},
		CanDragItems: {
			type: [Boolean, String],
			default: !1
		},
		CanReorderItems: {
			type: [Boolean, String],
			default: !1
		},
		AllowDrop: {
			type: [Boolean, String],
			default: !1
		},
		AreStickyGroupHeadersEnabled: {
			type: [Boolean, String],
			default: !1
		},
		SelectionMode: { default: "Single" },
		SelectedItems: { default: void 0 },
		SelectedItem: { default: void 0 },
		SelectedIndex: { default: void 0 },
		ItemContainerStyle: { default: () => ({}) },
		ItemTemplate: {},
		HorizontalAlignment: {},
		VerticalAlignment: {},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		Width: { default: "" },
		Height: { default: "" },
		MinWidth: { default: "" },
		MinHeight: { default: "" },
		MaxWidth: { default: "" },
		MaxHeight: { default: "" },
		Margin: { default: "" },
		Padding: { default: "" },
		Background: { default: "" },
		BorderBrush: { default: "" },
		BorderThickness: { default: "" },
		CornerRadius: { default: "" }
	},
	emits: [
		"Loaded",
		"ContainerContentChanging",
		"ItemClick",
		"SelectionChanged",
		"DragItemsStarting",
		"DragItemsCompleted",
		"DragOver",
		"Drop",
		"update:SelectedItems",
		"update:SelectedItem",
		"update:SelectedIndex",
		"update:ItemsSource"
	],
	setup(te, { expose: ne, emit: re }) {
		let ie = Te(), u = we(), h = me(), ke = ge(c, {}), Ae = se((e) => u[e], h);
		xe(c, {
			...ke,
			ScrollSettings: Ae,
			get ScrollTemplateIsEnabled() {
				return S.value;
			}
		});
		let je = pe({
			name: "ListViewSelectionCheck",
			props: { Item: {
				type: null,
				default: void 0
			} },
			setup(e) {
				return xe(c, {
					...ke,
					Selected: f(() => Y(e.Item))
				}), () => he(ce, {
					IsChecked: "{x:Bind Selected, Mode=OneWay}",
					IsEnabled: "False"
				});
			}
		}), Me = ge(ee, {}), Ne = f(() => {
			let e = {}, t = (n) => {
				for (let r of n) r.type === de ? t(d(r)) : typeof r.props?.["x:Key"] == "string" && (e[r.props["x:Key"]] = r);
			};
			for (let e of ie.default?.() ?? []) e.type?.__xamlResourceProperty && t(d(e));
			return e;
		}), Pe = new Proxy(Me, { get: (e, t) => Ne.value[t] ?? e[t] });
		xe(ee, Pe);
		let Fe = Ce(null), Ie = Ce(ie.default?.() ?? []), Le = f(() => {
			let e = {
				itemTemplate: [],
				headerTemplate: [],
				groupHeaderTemplate: [],
				itemContainerStyle: [],
				itemsPanel: []
			}, t = (n) => {
				for (let r of n) {
					if (!r) continue;
					let n = ae(r), i = typeof r.type == "string" ? r.type : String(r.type?.name ?? r.type?.__name ?? "");
					(n === "itemTemplate" || n === "groupHeaderTemplate" || n === "itemContainerStyle") && (e[n] = d(r)), (r.type?.__listViewHeader || i === "ListView.Header") && (e.headerTemplate = d(r)), n === "itemsPanel" && (e.itemsPanel = d(r)), (n === "groupStyle" || /(?:^|\.)GroupStyle$/i.test(i)) && t(d(r)), n === "groupStyleHeaderTemplate" && (e.groupHeaderTemplate = d(r));
				}
			};
			return t(Ie.value), e;
		}), Re = pe({
			name: "ListViewHeaderOutlet",
			setup() {
				return () => he(de, n(Le.value.headerTemplate, h));
			}
		}), ze = (e) => {
			let t = (n) => {
				for (let r of n) {
					if (r?.props?.[e] !== void 0) return r.props[e];
					let n = t(d(r));
					if (n !== void 0) return n;
				}
			};
			return t(Le.value.itemsPanel);
		}, Be = f(() => {
			let e = Fe.value ?? _.ItemTemplate, t = typeof e == "string" && /^\{\s*(?:x:Bind|Binding)\b/.test(e) ? i(e, h) : e, n = typeof t == "string" ? t.trim().match(/^\{\s*StaticResource\s+([^\s}]+)\s*\}$/)?.[1] : void 0;
			return n && Pe?.[n] ? d(Pe[n]) : t && typeof t == "object" && t.type ? d(t) : Le.value.itemTemplate;
		}), Ve = f(() => String(i(ze("VerticalAlignment"), h) ?? "").toLowerCase() === "bottom"), He = f(() => String(i(ze("ItemsUpdatingScrollMode"), h) ?? "").toLowerCase() === "keeplastiteminview"), Ue = /* @__PURE__ */ new Map(), We = (e, r, i = void 0) => {
			let a = e && typeof e == "object" ? e : `primitive:${i?.Key ?? ""}:${r}:${String(e ?? "")}`, c = Ue.get(a);
			if (c) return c;
			let l = pe({
				name: "ListViewItemTemplate",
				setup() {
					let r = me();
					return xe(o, e), xe(s, Se({})), () => Be.value.length ? he(de, n(t(Be.value, e, r), r)) : he("span", String(e ?? ""));
				}
			});
			return Ue.set(a, l), l;
		}, Ge = ge(Symbol.for("WinUIonWeb.StackPanel.ImplicitStyles"), null), g = f(() => {
			let e = typeof _.ItemContainerStyle == "string" ? _.ItemContainerStyle.match(/^\{StaticResource\s+([^}]+)\}$/)?.[1] : void 0, t = Le.value.itemContainerStyle[0] ?? (e ? Pe[e] : void 0), n = {}, r = Ge?.value.ListViewItem ?? {}, a = [...Object.entries(r).map(([e, t]) => ({ props: {
				Property: e,
				Value: t
			} })), ...t ? d(t) : []];
			for (let e of a) {
				let t = e?.props?.Property;
				if (!t) continue;
				let r = i(e?.props?.Value, h);
				r != null && (t === "Margin" ? n.margin = E(r) : t === "Padding" ? n.padding = E(r) : t === "Height" ? n.height = T(r) : t === "MinHeight" ? n.minHeight = T(r) : t === "Width" ? n.width = T(r) : t === "MinWidth" ? n.minWidth = T(r) : t === "Background" ? n.background = String(r) : t === "BorderBrush" ? n.borderColor = String(r) : t === "BorderThickness" ? (n.borderWidth = E(r), n.borderStyle = "solid") : t === "CornerRadius" ? n.borderRadius = T(r) : t === "HorizontalContentAlignment" ? n.justifyContent = ft(String(r)) : t === "VerticalContentAlignment" && (n.alignItems = ft(String(r))));
			}
			return n;
		}), Ke = /* @__PURE__ */ new Map(), qe = (e) => {
			let r = e ?? "__root__", i = Ke.get(r);
			if (i) return i;
			let a = pe({
				name: "ListViewGroupHeaderTemplate",
				setup() {
					let r = me();
					return xe(o, e), xe(s, Se({})), () => Le.value.groupHeaderTemplate.length ? he(de, n(t(Le.value.groupHeaderTemplate, e, r), r)) : he("span", it(e));
				}
			});
			return Ke.set(r, a), a;
		}, _ = te, v = re, Je = Ce(void 0);
		Ee(() => i(_.ItemsSource, h), () => {
			Je.value = void 0;
		});
		let Ye = f(() => Je.value ?? i(_.ItemsSource, h)), Xe = f(() => {
			let e = Ye.value;
			return Array.isArray(e?.CollectionGroups) ? e.CollectionGroups : [];
		}), y = f(() => {
			if (Xe.value.length) return Xe.value.map((e) => e.Group);
			let e = Ye.value;
			return Array.isArray(e) ? e : [];
		}), b = f(() => {
			let e = i(_.IsGrouped, h), t = y.value.length > 0 && y.value.every((e) => Array.isArray(e?.Items));
			return e === !0 ? !0 : e === !1 && typeof _.IsGrouped == "string" ? !1 : Xe.value.length > 0 || t;
		}), Ze = f(() => i(_.IsItemClickEnabled, h) === !0), Qe = f(() => (i(_.CanDragItems, h) === !0 || i(_.CanDrag, h) === !0) && S.value), $e = f(() => i(_.CanReorderItems, h) === !0), et = f(() => i(_.AllowDrop, h) === !0), tt = f(() => {
			let e = ze("AreStickyGroupHeadersEnabled");
			return i(e === void 0 ? _.AreStickyGroupHeadersEnabled : e, h) === !0;
		}), x = f(() => i(_.SelectionMode, h) ?? "Single"), S = f(() => i(_.IsEnabled, h) !== !1), nt = (e) => Xe.value.find((t) => t.Group === e)?.GroupItems ?? e?.Items ?? [], rt = (e, t) => e?.Key ?? t, it = (e) => e?.Key ?? "", at = /* @__PURE__ */ new WeakMap(), ot = /* @__PURE__ */ new Map(), st = /* @__PURE__ */ new Map(), ct = (e) => {
			let t = /* @__PURE__ */ new Map();
			return e.map((e) => {
				let n = m(e), r = typeof n == "object" && n ? n : null, i = r?.Key ?? r?.Id, a;
				i === void 0 ? r ? (a = at.get(r) ?? [], at.set(r, a)) : (a = ot.get(n) ?? [], ot.set(n, a)) : (a = st.get(i) ?? [], st.set(i, a));
				let o = t.get(a) ?? 0;
				return t.set(a, o + 1), a[o] ?? (a[o] = Symbol("ListViewItem"));
			});
		}, lt = p([]), C = f(() => b.value ? y.value.flatMap((e) => nt(e)) : N.value), ut = f(() => {
			let e = i(_.SelectedItems, h), t = i(_.SelectedItem, h);
			if (Array.isArray(e)) return e;
			if (t !== void 0) return t === null ? [] : [t];
			let n = i(_.SelectedIndex, h);
			return n != null && n !== "" ? Number(n) >= 0 && C.value[Number(n)] !== void 0 ? [C.value[Number(n)]] : [] : lt.value;
		}), w = f(() => x.value === "None" ? [] : ut.value), T = (e) => e === "" || e == null ? "" : typeof e == "number" || !Number.isNaN(Number(String(e).trim())) ? `${Number(e)}px` : String(e), E = (e) => {
			if (e === "" || e == null) return "";
			let t = String(e).split(",").map((e) => T(e.trim()));
			return t.length === 1 ? t[0] : t.length === 2 ? `${t[1]} ${t[0]}` : t.length === 4 ? `${t[1]} ${t[2]} ${t[3]} ${t[0]}` : String(e);
		}, dt = {
			Left: "flex-start",
			Center: "center",
			Right: "flex-end",
			Stretch: "stretch",
			Top: "flex-start",
			Bottom: "flex-end"
		}, ft = (e) => dt[e || ""] || void 0, pt = e(() => _.Background || void 0, h), mt = f(() => ({
			justifySelf: {
				Left: "start",
				Center: "center",
				Right: "end",
				Stretch: "stretch"
			}[String(i(_.HorizontalAlignment, h) ?? "")],
			alignSelf: {
				Top: "start",
				Center: "center",
				Bottom: "end",
				Stretch: "stretch"
			}[String(i(_.VerticalAlignment, h) ?? "")],
			width: T(i(_.Width, h)) || void 0,
			height: T(i(_.Height, h)) || void 0,
			minWidth: T(i(_.MinWidth, h)) || void 0,
			minHeight: T(i(_.MinHeight, h)) || void 0,
			maxWidth: T(i(_.MaxWidth, h)) || void 0,
			maxHeight: T(i(_.MaxHeight, h)) || void 0,
			margin: E(i(_.Margin, h)) || void 0,
			...pt.value,
			borderColor: i(_.BorderBrush, h) ? String(i(_.BorderBrush, h)) : void 0,
			borderWidth: E(_.BorderThickness) || void 0,
			borderStyle: i(_.BorderThickness, h) !== "" && i(_.BorderThickness, h) !== 0 ? "solid" : void 0,
			borderRadius: T(i(_.CornerRadius, h)) || void 0
		})), ht = f(() => ({ padding: E(i(_.Padding, h)) || void 0 })), D = f(() => typeof _.ItemContainerStyle == "object" ? _.ItemContainerStyle : {}), O = f(() => ({
			height: T(D.value.Height) || void 0,
			minHeight: T(D.value.MinHeight) || void 0,
			margin: E(D.value.Margin) || void 0,
			width: T(D.value.Width) || void 0,
			minWidth: T(D.value.MinWidth) || void 0,
			borderColor: D.value.BorderBrush || void 0,
			borderWidth: E(D.value.BorderThickness) || void 0,
			borderStyle: D.value.BorderThickness !== void 0 && D.value.BorderThickness !== 0 ? "solid" : void 0,
			borderRadius: T(D.value.CornerRadius) || void 0
		})), gt = f(() => ({
			...O.value,
			margin: O.value.margin ?? g.value.margin,
			width: O.value.width ?? g.value.width,
			minWidth: O.value.minWidth ?? g.value.minWidth,
			height: O.value.height ?? g.value.height,
			minHeight: O.value.minHeight ?? g.value.minHeight,
			background: g.value.background,
			borderColor: O.value.borderColor ?? g.value.borderColor,
			borderWidth: O.value.borderWidth ?? g.value.borderWidth,
			borderStyle: O.value.borderStyle ?? g.value.borderStyle,
			borderRadius: O.value.borderRadius ?? g.value.borderRadius
		})), _t = (e, t) => {
			let n = String(e ?? "").trim();
			return n === "Left" || n === "Center" || n === "Right" || n === "Stretch" ? n : t;
		}, vt = f(() => _t(g.value.justifyContent ? g.value.justifyContent === "flex-start" ? "Left" : g.value.justifyContent === "flex-end" ? "Right" : g.value.justifyContent === "center" ? "Center" : "Stretch" : D.value.HorizontalContentAlignment, "Stretch")), yt = f(() => _t(g.value.alignItems ? g.value.alignItems === "flex-start" ? "Top" : g.value.alignItems === "flex-end" ? "Bottom" : g.value.alignItems === "center" ? "Center" : "Stretch" : D.value.VerticalContentAlignment, "Center")), bt = f(() => ({
			margin: "2px 4px",
			padding: E(g.value.padding ?? D.value.Padding) || void 0,
			height: yt.value === "Stretch" && gt.value.height ? `calc(${gt.value.height} - 4px)` : void 0,
			justifyContent: vt.value === "Right" ? "flex-end" : vt.value === "Center" ? "center" : "flex-start",
			alignItems: yt.value === "Top" ? "flex-start" : yt.value === "Bottom" ? "flex-end" : yt.value === "Stretch" ? "stretch" : "center"
		})), xt = f(() => x.value === "None" && Ve.value && vt.value === "Stretch"), k = p(), A = le(k, () => b.value ? y.value.flatMap((e) => nt(e)) : N.value, () => y.value, !1), St = (e) => {
			if (!S.value || !A.SemanticZoomOwner.value || !A.IsActiveView.value || ![
				"ArrowUp",
				"ArrowDown",
				"Home",
				"End",
				"PageUp",
				"PageDown"
			].includes(e.key)) return;
			let t = Array.from(k.value?.querySelectorAll(".win-list-item") ?? []), n = Math.max(0, t.findIndex((e) => e.contains(document.activeElement))), r = Math.max(1, Math.floor((k.value?.clientHeight ?? 0) / (t[n]?.offsetHeight || 40))), i = e.key === "Home" ? 0 : e.key === "End" ? t.length - 1 : n + (e.key === "ArrowUp" ? -1 : e.key === "ArrowDown" ? 1 : e.key === "PageUp" ? -r : r);
			t[Math.max(0, Math.min(t.length - 1, i))]?.focus({ preventScroll: !0 }), A.MakeVisible({
				Item: N.value[Math.max(0, Math.min(t.length - 1, i))],
				Bounds: {
					X: 0,
					Y: 0,
					Width: 0,
					Height: 0
				}
			}), e.preventDefault(), e.stopPropagation();
		}, j = {
			...A,
			get Element() {
				return k.value;
			},
			get ItemsSource() {
				return y.value;
			},
			set ItemsSource(e) {
				Je.value = e, a(_.ItemsSource, e, h), v("update:ItemsSource", e);
			},
			get SelectedIndex() {
				return w.value.length ? C.value.findIndex((e) => m(e) === m(w.value[0])) : -1;
			},
			set SelectedIndex(e) {
				yn(e >= 0 && C.value[e] !== void 0 ? [C.value[e]] : []);
			},
			ItemTemplate: f({
				get: () => Fe.value ?? _.ItemTemplate,
				set: (e) => {
					Fe.value = e;
				}
			})
		};
		ne(j);
		let M = p(), N = p([...y.value]), Ct = f(() => ct(N.value)), wt = /* @__PURE__ */ new WeakMap(), Tt = f(() => new Map(y.value.map((e) => {
			let t = m(e), n = wt.get(t) ?? /* @__PURE__ */ new Map();
			return wt.set(t, n), [e, ct(nt(e)).map((e) => {
				let t = n.get(e);
				return t || (t = Symbol("ListViewGroupItem"), n.set(e, t)), t;
			})];
		}))), Et = Se(/* @__PURE__ */ new Map()), Dt = /* @__PURE__ */ new Map(), Ot = /* @__PURE__ */ new Map(), kt = (e, t) => t ? Tt.value.get(t)?.[e] : Ct.value[e], At = (e, t) => {
			let n = h?.vnode.props?.[`on${e}`];
			for (let e of Array.isArray(n) ? n : [n]) typeof e == "function" && e(j, t);
			r(u[e], h)?.(j, t);
		}, jt = (e) => {
			let t = Et.get(e)?.ContextFlyout;
			(Dt.get(e) ?? (_e(t) ? void 0 : t))?.Hide?.(), Dt.delete(e);
		}, Mt = (e, t) => {
			if (x.value === "None") return;
			let n = w.value, r = n.filter((t) => m(t) !== m(e));
			if (!t) {
				r.length !== n.length && yn(r);
				return;
			}
			n.some((t) => m(t) === m(e)) || yn(x.value === "Single" ? [e] : [...n, e]);
		}, Nt = (e, t, n, r) => {
			if (!(t instanceof HTMLElement)) {
				jt(e), Et.delete(e), Ot.delete(e);
				return;
			}
			let i = Et.get(e);
			if (i?.Element === t && i.Content === n && i.ItemIndex === r) return;
			jt(e);
			let a = Se({
				Element: t,
				Content: n,
				DataContext: n,
				ItemIndex: r,
				ContextFlyout: void 0,
				get IsSelected() {
					return Y(n);
				},
				set IsSelected(e) {
					Mt(n, e);
				}
			});
			Et.set(e, a), At("ContainerContentChanging", {
				Item: n,
				ItemIndex: r,
				ItemContainer: a,
				InRecycleQueue: !1,
				Phase: 0,
				Handled: !1
			});
		}, Pt = (e, t, n, r) => {
			if (!e) return;
			let i = Ot.get(e);
			if (!i) {
				let a = {
					Item: t,
					Index: n,
					Group: r,
					Callback: (t) => Nt(e, t, a.Item, a.Index)
				};
				i = a, Ot.set(e, i);
			}
			return i.Item = t, i.Index = n, i.Group = r, i.Callback;
		}, Ft = pe({
			name: "ListViewContextFlyoutOutlet",
			setup: () => () => he(de, [...Et.entries()].flatMap(([e, t]) => _e(t.ContextFlyout) ? [fe(t.ContextFlyout, {
				key: e,
				ref: (t) => {
					t ? Dt.set(e, t) : Dt.delete(e);
				}
			})] : []))
		}), It = async (e, t, n, r) => {
			if (!S.value) return;
			let i = kt(n, r);
			if (!i) return;
			let a = Et.get(i);
			if (!a?.ContextFlyout || !a.Element) return;
			e.preventDefault(), e.stopPropagation(), await ve();
			let o = _e(a.ContextFlyout) ? Dt.get(i) : a.ContextFlyout, s = a.Element.getBoundingClientRect();
			await o?.ShowAt?.(a.Element, { Position: {
				X: e.clientX - s.left,
				Y: e.clientY - s.top
			} });
		};
		ye(() => Et.forEach((e, t) => jt(t)));
		let P = Ce(/* @__PURE__ */ new Set()), Lt = /* @__PURE__ */ new Set(), Rt = /* @__PURE__ */ new Set(), zt = () => Array.from(M.value?.querySelectorAll(".win-list-item") ?? []), Bt = (e) => b.value ? e.flatMap((e) => nt(e)) : e, Vt = () => {
			for (let e of Lt) e.cancel();
			Lt.clear();
		}, Ht = async (e, t, n) => {
			if (await ve(), !M.value) return;
			let r = k.value?.querySelector(".win-scroll-viewer-viewport");
			if (n && r && (r.scrollTop = Math.max(0, r.scrollHeight - r.clientHeight)), window.matchMedia?.("(prefers-reduced-motion: reduce)").matches) return;
			let i = zt();
			Bt(e).forEach((e, n) => {
				let r = m(e);
				if (!r || typeof r != "object") return;
				let a = t.get(r), o = i[n];
				if (a === void 0 || !o) return;
				let s = a - o.getBoundingClientRect().top;
				if (Math.abs(s) < .5) return;
				let c = o.animate([{ transform: `translateY(${s}px)` }, { transform: "translateY(0)" }], {
					duration: 300,
					easing: "cubic-bezier(0.1, 0.9, 0.2, 1)"
				}), l = () => Lt.delete(c);
				c.addEventListener("finish", l, { once: !0 }), c.addEventListener("cancel", l, { once: !0 }), Lt.add(c);
			});
		};
		Ee(y, (e) => {
			let t = N.value, n = Bt(t), r = Bt(e), i = new Set(n.map((e) => m(e))), a = e.flatMap((e) => b.value ? nt(e) : [e]).map((e) => m(e)).filter((e) => !i.has(e)), o = n.map((e) => m(e)), s = r.map((e) => m(e)), c = o.length !== s.length || o.some((e, t) => e !== s[t]);
			if (c && On(), c && M.value) {
				let t = k.value?.querySelector(".win-scroll-viewer-viewport"), r = He.value && (!t || t.scrollHeight - t.clientHeight - t.scrollTop < 24), i = zt(), o = /* @__PURE__ */ new Map();
				if (n.forEach((e, t) => {
					let n = m(e);
					n != null && i[t] && o.set(n, i[t].getBoundingClientRect().top);
				}), Vt(), window.matchMedia?.("(prefers-reduced-motion: reduce)").matches) {
					let e = new Set(P.value);
					a.forEach((t) => e.delete(t)), P.value = e;
				} else if (a.length) {
					let e = new Set(P.value);
					a.forEach((t) => e.add(t)), P.value = e;
					let t = window.setTimeout(() => {
						let e = new Set(P.value);
						a.forEach((t) => e.delete(t)), P.value = e, Rt.delete(t);
					}, 517);
					Rt.add(t);
				}
				Ht(e, o, r);
			}
			N.value = [...e];
			let l = b.value ? e.flatMap((e) => nt(e)) : e;
			lt.value = lt.value.filter((e) => l.some((t) => m(t) === m(e)));
		}, { deep: !0 }), ye(() => {
			for (let e of Rt) window.clearTimeout(e);
			Rt.clear(), Vt();
		});
		let F = p(!1), Ut = p(!1), I = p([]), L = p(-1), R = p(-1), z = null, Wt = 0, B = [], V = p(0), Gt = 0, H = /* @__PURE__ */ new Map(), U = -1, W, Kt = null, G = null, qt = [], Jt = 0, Yt = Symbol("winuionweb-listview-drag-owner"), Xt = "winuionweb-listview-pointer-drag-over", Zt = "winuionweb-listview-pointer-drag-leave", Qt = "winuionweb-listview-pointer-drop", $t = null, en = 1500, tn, nn, rn = 0, an = 0, K = null, q = null, J = null, on = !1, Y = (e) => {
			let t = m(e);
			return w.value.some((e) => m(e) === t);
		}, sn = (e) => {
			if (!xt.value || !e || typeof e != "object") return !1;
			let t = e;
			return "MsgAlignment" in t && "MsgText" in t;
		}, X = Ce(null), Z = p(!1), cn = 0, ln = /* @__PURE__ */ new Set(), Q = null, un = null, dn = 0, fn = (e) => {
			if (!sn(e)) return "";
			let t = String(e.MsgAlignment ?? "").toLowerCase();
			return t === "right" || t === "left" ? t : "";
		}, pn = () => {
			if (V.value, !F.value || !B.length) return -1;
			let e = B.filter(({ index: e }) => !I.value.includes(e));
			return R.value >= 0 && e.some(({ index: e }) => e === R.value) ? R.value : -1;
		}, mn = (e) => {
			if (e !== pn() || L.value < 0) return 0;
			let t = [...I.value].sort((e, t) => e - t);
			return t.length ? L.value > t[t.length - 1] ? 10 : -10 : 0;
		}, hn = (e) => (V.value, !F.value || I.value.includes(e) ? 0 : H.get(e) ?? 0), gn = (e, t) => {
			if (!B.length) return -1;
			let n = B.filter(({ index: e }) => !t.includes(e));
			if (!n.length) return -1;
			let r = n.find((t) => {
				let n = H.get(t.index) ?? 0, r = t.top + n, i = Math.max(1, t.bottom - t.top), a = (e - r) / i;
				return a > .2 && a < .8;
			});
			return r ? r.index : -1;
		}, _n = (e, t = -1) => ({
			selected: Y(e),
			interactive: S.value && x.value !== "None",
			"selection-none": x.value === "None",
			"message-item": sn(e),
			"message-left": fn(e) === "left",
			"message-right": fn(e) === "right",
			"message-enter": sn(e) && P.value.has(m(e)),
			"collection-enter": m(e) !== null && m(e) !== void 0 && P.value.has(m(e)),
			"multi-select": x.value === "Multiple",
			"can-drag": Qe.value && !b.value,
			"content-stretch": vt.value === "Stretch",
			"drag-shrink": t >= 0 && F.value && !I.value.includes(t) && t !== pn(),
			"reorder-target": t >= 0 && t === pn(),
			"dragging-source": t >= 0 && F.value && I.value.includes(t)
		}), vn = () => ({
			height: "max(min(16px, 100%), calc(100% - 40px))",
			minHeight: "0px"
		}), yn = (e, t = w.value) => {
			let n = e.filter((e) => !t.some((t) => m(t) === m(e))), i = t.filter((t) => !e.some((e) => m(e) === m(t)));
			for (let e of i) Sn(e);
			let o = e[0] ?? null, s = o === null ? -1 : C.value.findIndex((e) => m(e) === m(o));
			lt.value = [...e], v("update:SelectedItems", e), v("update:SelectedItem", o), v("update:SelectedIndex", s), a(_.SelectedItems, e, h), a(_.SelectedItem, o, h), a(_.SelectedIndex, s, h);
			let c = {
				AddedItems: n,
				RemovedItems: i,
				SelectedItems: e
			};
			v("SelectionChanged", j, c), r(u.SelectionChanged, h)?.(j, c);
		}, bn = /* @__PURE__ */ new Set(), $ = /* @__PURE__ */ new Map(), xn = (e) => {
			if (!M.value) return;
			let t = C.value.findIndex((t) => m(t) === m(e));
			return M.value.querySelectorAll(".win-list-item")[t];
		}, Sn = (e) => {
			let t = xn(e)?.querySelector(".win-list-view-selection-indicator");
			if (t) {
				for (let e of t.getAnimations()) e.cancel(), bn.delete(e);
				for (let [e, n] of $) n.indicator === t && (n.animation?.cancel(), $.delete(e));
				t.classList.remove("indicator-pressed"), t.style.removeProperty("--selection-indicator-pressed-height");
			}
		}, Cn = (e) => {
			let t = () => bn.delete(e);
			e.addEventListener("finish", t, { once: !0 }), e.addEventListener("cancel", t, { once: !0 }), bn.add(e);
		}, wn = async (e) => {
			if (x.value === "None" || x.value === "Multiple" || (await ve(), !Y(e) || !M.value || window.matchMedia?.("(prefers-reduced-motion: reduce)").matches)) return;
			let t = xn(e)?.querySelector(".win-list-view-selection-indicator.active");
			if (!t) return;
			for (let e of t.getAnimations()) e.cancel();
			let n = t.animate([{ transform: "translateY(-50%) scaleY(0)" }, { transform: "translateY(-50%) scaleY(1)" }], {
				duration: 167,
				easing: "cubic-bezier(0.167, 0.167, 0, 1)"
			}), r = t.animate([{ opacity: 0 }, { opacity: 1 }], {
				duration: 83,
				easing: "linear"
			});
			Cn(n), Cn(r);
		}, Tn = (e) => {
			let t = window.getComputedStyle(e).transform;
			if (!t || t === "none") return 1;
			let n = t.match(/^matrix3d\(([^)]+)\)$/);
			if (n) {
				let e = n[1].split(",").map(Number);
				return Number.isFinite(e[5]) ? e[5] : 1;
			}
			let r = t.match(/^matrix\(([^)]+)\)$/);
			if (r) {
				let e = r[1].split(",").map(Number);
				return Number.isFinite(e[3]) ? e[3] : 1;
			}
			return 1;
		}, En = (e) => {
			let t = $.get(e);
			if (!t || t.releaseStarted) return;
			t.releaseStarted = !0;
			let n = Tn(t.indicator);
			t.animation?.cancel(), t.indicator.classList.remove("indicator-pressed");
			let r = t.indicator.getBoundingClientRect().height || t.normalHeight, i = r > 0 ? Math.max(0, Math.min(2, n * t.pressedHeight / r)) : 1, a = t.indicator.animate([{ transform: `translateY(-50%) scaleY(${i})` }, { transform: "translateY(-50%) scaleY(1)" }], {
				duration: 167,
				easing: "cubic-bezier(0, 0, 0, 1)",
				fill: "both"
			});
			t.animation = a, Cn(a), a.addEventListener("finish", () => {
				$.get(e) === t && ($.delete(e), a.cancel(), t.indicator.style.removeProperty("--selection-indicator-pressed-height"));
			}, { once: !0 });
		}, Dn = (e) => {
			let t = $.get(e);
			!t || !t.isPressed || (t.isPressed = !1, En(e));
		}, On = () => {
			for (let e of $.values()) e.animation?.cancel(), e.indicator.classList.remove("indicator-pressed"), e.indicator.style.removeProperty("--selection-indicator-pressed-height");
			$.clear();
			for (let e of M.value?.querySelectorAll(".win-list-view-selection-indicator") ?? []) for (let t of e.getAnimations()) t.cancel();
			for (let e of bn) e.cancel();
			bn.clear();
		}, kn = (e, t, n = !1) => {
			if (x.value === "None" || x.value === "Multiple" || !Y(t)) return;
			let r = xn(t)?.querySelector(".win-list-view-selection-indicator");
			if (!r || window.matchMedia?.("(prefers-reduced-motion: reduce)").matches) return;
			let i = $.get(e.pointerId);
			i?.animation?.cancel(), i?.indicator.classList.remove("indicator-pressed"), i?.indicator.style.removeProperty("--selection-indicator-pressed-height"), $.delete(e.pointerId);
			let a = r.getBoundingClientRect().height;
			if (a <= 0) return;
			let o = Math.max(1, a - 6);
			r.style.setProperty("--selection-indicator-pressed-height", `${o}px`), r.classList.add("indicator-pressed");
			let s = r.getBoundingClientRect().height, c = n ? 0 : s > 0 ? a / s : 1, l = {
				indicator: r,
				isPressed: !0,
				pressFinished: !1,
				releaseStarted: !1,
				normalHeight: a,
				pressedHeight: s,
				animation: void 0
			}, ee = r.animate([{ transform: `translateY(-50%) scaleY(${c})` }, { transform: "translateY(-50%) scaleY(1)" }], {
				duration: 167,
				easing: "cubic-bezier(0, 0, 0, 1)",
				fill: "both"
			});
			n && Cn(r.animate([{ opacity: 0 }, { opacity: 1 }], {
				duration: 83,
				easing: "linear"
			})), l.animation = ee, $.set(e.pointerId, l), Cn(ee), ee.addEventListener("finish", () => {
				$.get(e.pointerId) === l && (l.pressFinished = !0, l.isPressed || En(e.pointerId));
			}, { once: !0 });
		};
		Ee(x, (e) => {
			z = null, Q = null, un = null, dn = 0, (e === "None" || e === "Multiple") && On(), e === "None" && ut.value.length ? yn([], ut.value) : e === "Single" && w.value.length > 1 && yn([w.value[0]]);
		}, { immediate: !0 });
		let An = (e, t) => {
			if (x.value === "None") return !1;
			let n = m(t), r = Y(t), i = [...w.value], a = C.value.findIndex((e) => m(e) === n);
			if (x.value === "Single") i = [n], z = a;
			else if (x.value === "Multiple") if (e.shiftKey && z !== null) {
				let e = Math.min(z, a), t = Math.max(z, a), n = C.value.slice(e, t + 1).map((e) => m(e)), r = C.value[z];
				if (r !== void 0 && Y(r)) for (let e of n) i.some((t) => m(t) === e) || i.push(e);
				else i = i.filter((e) => !n.some((t) => m(e) === t));
			} else {
				let e = i.findIndex((e) => m(e) === n);
				e > -1 ? i.splice(e, 1) : i.push(n), z = a;
			}
			else if (x.value === "Extended") if (e.shiftKey && z !== null) {
				let t = Math.min(z, a), n = Math.max(z, a), r = C.value.slice(t, n + 1).map((e) => m(e));
				if (e.ctrlKey) for (let e of r) i.some((t) => m(t) === e) || i.push(e);
				else i = r;
			} else if (e.ctrlKey) {
				let e = i.findIndex((e) => m(e) === n);
				e > -1 ? i.splice(e, 1) : i.push(n), z = a;
			} else i = [n], z = a;
			return (i.length !== w.value.length || i.some((e, t) => m(w.value[t]) !== m(e))) && yn(i), !r && i.some((e) => m(e) === n);
		}, jn = (e, t) => {
			let n = t.getBoundingClientRect();
			return e.clientX >= n.left && e.clientX <= n.right && e.clientY >= n.top && e.clientY <= n.bottom;
		}, Mn = (e) => {
			let t = Q;
			if (!t || t.pointerId !== e.pointerId) return !0;
			if (Q = null, !jn(e, t.source) || F.value || !S.value) return !1;
			let n = An(e, t.item);
			return un = t.item, dn = Date.now() + 1e3, n && wn(t.item), !0;
		}, Nn = (e, t) => {
			if (!(!S.value || F.value || Date.now() < cn)) {
				if (A.SemanticZoomOwner.value && A.IsActiveView.value && !A.IsZoomedInView.value) {
					A.SemanticZoomOwner.value.ToggleActiveView({
						Item: t,
						OriginalSource: e.currentTarget
					});
					return;
				}
				if (Ze.value) {
					let n = {
						ClickedItem: t,
						OriginalSource: e.target
					};
					v("ItemClick", j, n), r(u.ItemClick, h)?.(j, n);
				}
				if (e instanceof MouseEvent && e.detail > 0 && un !== null && Date.now() <= dn && m(un) === m(t)) {
					un = null, dn = 0;
					return;
				}
				An(e, t) && wn(t);
			}
		}, Pn = (e, t) => {
			if (!S.value || !e.isPrimary || e.button !== 0) return;
			ln.delete(e.pointerId), un = null, dn = 0, Q && Q.pointerId !== e.pointerId && (Q = null);
			let n = e.currentTarget;
			if (Q = x.value !== "None" && n ? {
				pointerId: e.pointerId,
				item: t,
				source: n
			} : null, kn(e, t, !1), Qe.value && !b.value) {
				let n = e.currentTarget;
				if (n) {
					let r = n.getBoundingClientRect(), i = C.value.findIndex((e) => m(e) === m(t));
					X.value = {
						pointerId: e.pointerId,
						index: i,
						startX: e.clientX,
						startY: e.clientY,
						grabX: e.clientX - r.left,
						grabY: e.clientY - r.top,
						source: n
					};
					try {
						n.setPointerCapture?.(e.pointerId);
					} catch {}
				}
			}
		}, Fn = (e, t) => {
			let n = X.value;
			if (!n || Z.value || Math.hypot(e.clientX - n.startX, e.clientY - n.startY) < 8) return;
			Z.value = !0, On();
			let i = n.index >= 0 ? n.index : t;
			Y(N.value[i]) && w.value.length > 1 ? I.value = N.value.map((e, t) => w.value.some((t) => m(t) === m(e)) ? t : -1).filter((e) => e >= 0) : I.value = [i], qt = [...I.value].sort((e, t) => e - t).map((e) => N.value[e]), F.value = !0, R.value = -1, L.value = -1, U = -1, Wn();
			let a = I.value.reduce((e, t) => {
				let n = B.find((e) => e.index === t);
				return e + (n?.slotSize ?? n?.height ?? 0);
			}, 0), o = n.source.cloneNode(!0);
			o.querySelectorAll("[id]").forEach((e) => e.removeAttribute("id")), o.removeAttribute("id"), o.classList.remove("dragging-source", "reorder-target"), o.classList.add("win-list-drag-preview");
			let s = n.source.getBoundingClientRect();
			Object.assign(o.style, {
				width: `${s.width}px`,
				height: `${s.height}px`,
				margin: "0",
				left: "0",
				top: "0"
			}), document.body.appendChild(o), Kt = o, K = k.value?.querySelector(".win-scroll-viewer-viewport") ?? K, $t = {
				owner: Yt,
				indices: [...I.value],
				items: [...qt],
				dragHeight: Math.max(1, a || s.height),
				dragWidth: s.width,
				clientX: e.clientX,
				clientY: e.clientY,
				accepted: !1,
				dropResult: "None"
			};
			let c = {
				Items: [...qt],
				OriginalSource: e.target
			};
			v("DragItemsStarting", j, c), r(u.DragItemsStarting, h)?.(j, c);
		}, In = (e, t = X.value?.index ?? -1) => {
			let n = X.value;
			!n || n.pointerId !== e.pointerId || !Qe.value || (Z.value || Fn(e, t), Z.value && (J = {
				x: e.clientX,
				y: e.clientY
			}, Kt && (Kt.style.transform = `translate3d(${e.clientX - n.grabX}px, ${e.clientY - n.grabY}px, 0)`), rr(e.clientY), lr(e.clientX, e.clientY), e.preventDefault()));
		}, Ln = (e, t) => {
			In(e, t);
		}, Rn = () => {
			let e = X.value;
			if (e) try {
				e.source.hasPointerCapture?.(e.pointerId) && (ln.add(e.pointerId), e.source.releasePointerCapture?.(e.pointerId));
			} catch {
				ln.delete(e.pointerId);
			}
		}, zn = (e) => {
			if (e && (Dn(e.pointerId), !Z.value && !Mn(e) && (cn = Date.now() + 250)), Z.value && e) {
				Q = null, cn = Date.now() + 250, lr(e.clientX, e.clientY);
				let t = $t;
				Rn(), G && t && G.dispatchEvent(new CustomEvent(Qt, { detail: t }));
				let n = {
					Items: [...qt],
					DropResult: t?.dropResult ?? "None",
					OriginalSource: e.target
				};
				v("DragItemsCompleted", j, n), r(u.DragItemsCompleted, h)?.(j, n), xr();
				return;
			}
			e && Q?.pointerId === e.pointerId && (Q = null), X.value = null, Z.value = !1;
		}, Bn = (e) => {
			if (e && Dn(e.pointerId), e && Q?.pointerId === e.pointerId && (Q = null), !(!X.value && !Z.value)) {
				if (Z.value && qt.length) {
					let t = {
						Items: [...qt],
						DropResult: "None",
						OriginalSource: e?.target
					};
					v("DragItemsCompleted", j, t), r(u.DragItemsCompleted, h)?.(j, t);
				}
				Rn(), xr();
			}
		}, Vn = (e, t) => {
			Dn(e.pointerId), Y(t) || Sn(t);
		}, Hn = (e) => {
			ln.delete(e.pointerId) || X.value?.pointerId === e.pointerId && (Z.value || xr());
		}, Un = (e) => {
			let t = hn(e), n = e === pn();
			if (!F.value && !n) return;
			let r = n ? mn(e) : 0;
			return {
				transform: t || r ? `translateY(${t + r}px)` : void 0,
				transformOrigin: "center center",
				transition: "transform 240ms cubic-bezier(0.1, 0.9, 0.2, 1)",
				zIndex: n ? 2 : void 0
			};
		}, Wn = () => {
			let e = M.value;
			if (!e) return;
			let t = Array.from(e.querySelectorAll(".win-list-item")), n = [];
			t.forEach((e, t) => {
				let r = e.getBoundingClientRect();
				n.push({
					index: t,
					top: r.top,
					bottom: r.bottom,
					midY: r.top + r.height / 2,
					height: r.height,
					slotSize: r.height
				});
			});
			for (let e = 0; e < n.length - 1; e++) {
				let t = n[e + 1].top - n[e].top;
				t > 0 && (n[e].slotSize = t);
			}
			B = n, K = k.value?.querySelector(".win-scroll-viewer-viewport") ?? null, Gt = K?.scrollTop ?? 0, V.value++;
		}, Gn = () => {
			let e = K;
			if (!e || !B.length) return;
			let t = e.scrollTop, n = t - Gt;
			if (!(Math.abs(n) < .01)) {
				for (let e of B) e.top -= n, e.bottom -= n, e.midY -= n;
				Gt = t, V.value++;
			}
		}, Kn = (e, t) => (B.length || Wn(), B.filter(({ index: e }) => !t.includes(e)).find(({ index: t, midY: n }) => e < n + (H.get(t) ?? 0))?.index ?? N.value.length), qn = (e) => {
			let t = [...I.value].sort((e, t) => e - t);
			if (!t.length) return e;
			let n = t[0], r = t[t.length - 1];
			return r - n + 1 === t.length && e >= n && e <= r + 1 ? -1 : e;
		}, Jn = () => {
			H.clear();
			let e = [...I.value].sort((e, t) => e - t);
			if (!F.value) {
				V.value++;
				return;
			}
			if (L.value < 0 && e.length) {
				V.value++;
				return;
			}
			if (Ut.value && !e.length) {
				let e = Math.max(1, Jt);
				for (let t of B) t.index >= L.value && H.set(t.index, e);
				V.value++;
				return;
			}
			let t = new Set(e), n = e.reduce((e, t) => {
				let n = B.find((e) => e.index === t);
				return e + (n?.slotSize ?? n?.height ?? 0);
			}, 0);
			if (n <= 0) {
				V.value++;
				return;
			}
			let r = e[0], i = e[e.length - 1];
			if (L.value > i) for (let e of B) !t.has(e.index) && e.index > i && e.index < L.value && H.set(e.index, -n);
			else if (L.value < r) for (let e of B) !t.has(e.index) && e.index >= L.value && e.index < r && H.set(e.index, n);
			V.value++;
		}, Yn = (e) => {
			F.value && (W !== void 0 && (window.clearTimeout(W), W = void 0), L.value = qn(e), Jn());
		}, Xn = (e, t = !1) => {
			let n = qn(e);
			if (!(!t && n === U && W !== void 0) && (U = n, !(n === L.value && W === void 0))) {
				if (W !== void 0 && window.clearTimeout(W), t) {
					W = void 0, Yn(n);
					return;
				}
				W = window.setTimeout(() => {
					W = void 0, Yn(U);
				}, 200);
			}
		}, Zn = () => {
			let e = W !== void 0 || U !== -1;
			W !== void 0 && (window.clearTimeout(W), W = void 0), F.value && e && Yn(U);
		}, Qn = () => {
			tn !== void 0 && (window.clearTimeout(tn), tn = void 0), nn !== void 0 && (window.cancelAnimationFrame(nn), nn = void 0), rn = 0, an = 0, q = null;
		}, $n = () => J ? (document.elementFromPoint(J.x, J.y)?.closest(".win-list-view"))?.querySelector(".win-scroll-viewer-viewport") ?? null : null, er = (e) => {
			let t = $n() ?? K ?? k.value?.querySelector(".win-scroll-viewer-viewport");
			if (!t) return 0;
			q = t;
			let n = t.getBoundingClientRect(), r = Math.max(0, t.scrollHeight - t.clientHeight);
			if (r <= 0 || e < n.top - 100 || e > n.bottom + 100) return 0;
			let i = e - n.top, a = n.bottom - e;
			if (i >= 100 && a >= 100) return 0;
			let o = Math.max(0, Math.min(i, a)), s = i < 100 ? -1 : 1;
			if (s < 0 && t.scrollTop <= 0 || s > 0 && t.scrollTop >= r) return 0;
			let c = Math.max(0, Math.min(1, o / 100));
			return s * (en - (en - 150) * c);
		}, tr = () => {
			if (!F.value || !J) return;
			let e = I.value;
			R.value = gn(J.y, e), Xn(Kn(J.y, e));
		}, nr = (e) => {
			if (!F.value || !rn || !q) {
				nn = void 0;
				return;
			}
			let t = an > 0 ? Math.min(50, e - an) : 16;
			an = e;
			let n = q.scrollTop, r = Math.max(0, q.scrollHeight - q.clientHeight);
			if (q.scrollTop = Math.max(0, Math.min(r, n + rn * t / 1e3)), Math.abs(q.scrollTop - n) > .01) q === K && Gn(), tr();
			else {
				Qn();
				return;
			}
			nn = window.requestAnimationFrame(nr);
		}, rr = (e) => {
			let t = er(e);
			if (!t) {
				Qn();
				return;
			}
			rn = t, nn === void 0 && tn === void 0 && (tn = window.setTimeout(() => {
				tn = void 0, !(!rn || !F.value) && (an = 0, nn = window.requestAnimationFrame(nr));
			}, 50));
		}, ir = () => {
			F.value && (Gn(), tr());
		}, ar = (e) => {
			W !== void 0 && (window.clearTimeout(W), W = void 0), U = -1, L.value = -1, R.value = -1, H.clear(), Jt = 0, B = [], V.value++, e.owner !== Yt && (Ut.value = !1, F.value = !1);
		}, or = (e) => {
			let t = e.detail;
			if (!t || b.value || !S.value) return;
			let n = t.owner === Yt;
			if (!n && !et.value || n && !$e.value) return;
			t.accepted = !0, F.value = !0, Ut.value = !n;
			let i = n ? t.indices : [];
			Jt = n ? 0 : Math.max(1, t.dragHeight || 0);
			let a = Kn(t.clientY, i);
			R.value = gn(t.clientY, i), n && i.length ? Xn(a) : (L.value = a, U = a, Jn());
			let o = {
				DataTransfer: null,
				AcceptedOperation: "Move",
				OriginalSource: document.elementFromPoint(t.clientX, t.clientY)
			};
			v("DragOver", j, o), r(u.DragOver, h)?.(j, o);
		}, sr = (e) => {
			let t = e.detail;
			t && ar(t);
		}, cr = (e) => {
			let t = e.detail;
			if (!t || b.value || !S.value) return;
			let n = t.owner === Yt;
			if (!n && !et.value) return;
			if (n && Zn(), n && (!$e.value || L.value < 0)) {
				ar(t);
				return;
			}
			let i = L.value < 0 ? N.value.length : L.value;
			if (n) {
				let e = new Set(t.indices), n = N.value.filter((t, n) => !e.has(n));
				i = L.value >= N.value.length ? n.length : t.indices.reduce((e, t) => t < L.value ? e - 1 : e, L.value);
				let r = [...n];
				r.splice(Math.max(0, i), 0, ...t.items), N.value = r, a(_.ItemsSource, r, h), v("update:ItemsSource", r);
			}
			let o = {
				DataTransfer: null,
				AcceptedOperation: "Move",
				InsertIndex: Math.max(0, i),
				Items: [...t.items],
				OriginalSource: document.elementFromPoint(t.clientX, t.clientY)
			};
			v("Drop", j, o), r(u.Drop, h)?.(j, o), t.dropResult = "Move", ar(t);
		}, lr = (e, t) => {
			let n = $t;
			if (!n) return;
			n.clientX = e, n.clientY = t;
			let r = document.elementFromPoint(e, t)?.closest(".win-list-view") ?? null;
			G && G !== r && (G.dispatchEvent(new CustomEvent(Zt, { detail: n })), G = null), r && (n.accepted = !1, r.dispatchEvent(new CustomEvent(Xt, { detail: n })), G = n.accepted ? r : null);
		}, ur = (e) => {
			!X.value || X.value.pointerId !== e.pointerId || In(e);
		}, dr = (e) => {
			if (X.value?.pointerId === e.pointerId) {
				zn(e);
				return;
			}
			Q?.pointerId === e.pointerId && zn(e);
		}, fr = (e) => {
			(X.value?.pointerId === e.pointerId || Q?.pointerId === e.pointerId) && Bn(e);
		}, pr = () => {
			Bn(), Q = null, On(), xr();
		}, mr = (e) => {
			e.key !== "Escape" || !X.value && !Z.value || (e.preventDefault(), pr());
		}, hr = () => {
			document.hidden && pr();
		}, gr = (e) => {
			e.relatedTarget === null && Z.value && pr();
		}, _r;
		be(() => {
			At("Loaded", {
				OriginalSource: j,
				Handled: !1
			});
			let e = k.value;
			e?.addEventListener(Xt, or), e?.addEventListener(Zt, sr), e?.addEventListener(Qt, cr), K = e?.querySelector(".win-scroll-viewer-viewport") ?? null, K?.addEventListener("scroll", ir, { passive: !0 }), document.addEventListener("pointermove", ur), document.addEventListener("pointerup", dr), document.addEventListener("pointercancel", fr), document.addEventListener("keydown", mr, !0), document.addEventListener("visibilitychange", hr), document.addEventListener("pointerout", gr), window.addEventListener("blur", pr), _r = ue(() => Z.value, () => X.value?.pointerId), on = !0;
		});
		let vr = (e) => {
			if (!et.value || b.value) return;
			e.preventDefault();
			let t = I.value.length > 0;
			if (t && !$e.value) return;
			t || (Ut.value = !0), e.dataTransfer && (e.dataTransfer.dropEffect = "move");
			let n = {
				DataTransfer: e.dataTransfer,
				AcceptedOperation: "Move",
				OriginalSource: e.target
			};
			v("DragOver", j, n), r(u.DragOver, h)?.(j, n);
			let i = Date.now();
			if (i - Wt < 80) return;
			Wt = i;
			let a = e.clientY;
			if (B.length === 0 && Wn(), B.length === 0) return;
			let o = B.filter((e) => !I.value.includes(e.index));
			if (o.length === 0) return;
			R.value = gn(a, I.value);
			let s = y.value.length;
			for (let e = 0; e < o.length; e++) if (a < o[e].midY) {
				s = o[e].index;
				break;
			}
			let c = [...I.value].sort((e, t) => e - t), l = c[0], ee = c[c.length - 1];
			if (ee - l + 1 === c.length && s >= l && s <= ee + 1) {
				L.value !== -1 && (L.value = -1);
				return;
			}
			s !== L.value && (L.value = s);
		}, yr = (e) => {
			let t = M.value;
			if (!t) return;
			let n = e.relatedTarget;
			n instanceof Node && t.contains(n) || (L.value = -1, R.value = -1, Ut.value = !1);
		}, br = (e) => {
			e.preventDefault(), e.stopPropagation();
			let t = I.value.length > 0;
			if (Ut.value && !t) {
				let t = L.value < 0 ? N.value.length : L.value, n = {
					DataTransfer: e.dataTransfer,
					AcceptedOperation: "Move",
					InsertIndex: t,
					OriginalSource: e.target
				};
				v("Drop", j, n), r(u.Drop, h)?.(j, n), xr();
				return;
			}
			if (!$e.value || !t || L.value === -1) {
				xr();
				return;
			}
			let n = I.value.sort((e, t) => e - t).map((e) => N.value[e]), i = N.value.filter((e, t) => !I.value.includes(t)), o;
			if (L.value >= N.value.length) o = i.length;
			else {
				o = 0;
				for (let e = 0; e < L.value; e++) I.value.includes(e) || o++;
			}
			let s = [...i];
			s.splice(o, 0, ...n), N.value = s, a(_.ItemsSource, s, h), v("update:ItemsSource", s);
			let c = {
				DataTransfer: e.dataTransfer,
				AcceptedOperation: "Move",
				InsertIndex: o,
				OriginalSource: e.target
			};
			v("Drop", j, c), r(u.Drop, h)?.(j, c);
			let l = {
				Items: n,
				DropResult: "Move",
				OriginalSource: e.target
			};
			v("DragItemsCompleted", j, l), r(u.DragItemsCompleted, h)?.(j, l), xr();
		}, xr = () => {
			Qn(), W !== void 0 && (window.clearTimeout(W), W = void 0), U = -1, G && $t && G.dispatchEvent(new CustomEvent(Zt, { detail: $t })), G = null, Rn(), Kt?.remove(), Kt = null, F.value = !1, Ut.value = !1, I.value = [], L.value = -1, R.value = -1, H.clear(), Jt = 0, B = [], V.value++, K = null, J = null, qt = [], $t = null, X.value = null, Z.value = !1;
		};
		ye(() => {
			_r?.(), _r = void 0, On();
			for (let e of bn) e.cancel();
			bn.clear(), Qn(), W !== void 0 && window.clearTimeout(W), W = void 0, K?.removeEventListener("scroll", ir), on &&= (document.removeEventListener("pointermove", ur), document.removeEventListener("pointerup", dr), document.removeEventListener("pointercancel", fr), document.removeEventListener("keydown", mr, !0), document.removeEventListener("visibilitychange", hr), document.removeEventListener("pointerout", gr), window.removeEventListener("blur", pr), !1);
			let e = k.value;
			e?.removeEventListener(Xt, or), e?.removeEventListener(Zt, sr), e?.removeEventListener(Qt, cr), Kt?.remove();
		});
		let Sr = {
			ListViewHeader: De,
			ListViewResources: Oe,
			slots: ie,
			attrs: u,
			instance: h,
			inheritedScrollTemplateScope: ke,
			ScrollSettings: Ae,
			SelectionCheck: je,
			inheritedResources: Me,
			localResources: Ne,
			resources: Pe,
			itemTemplateOverride: Fe,
			slotNodes: Ie,
			propertyTemplateNodes: Le,
			HeaderOutlet: Re,
			itemsPanelProperty: ze,
			itemTemplateNodes: Be,
			itemsPanelBottom: Ve,
			keepsLastItemInView: He,
			itemComponentCache: Ue,
			itemComponent: We,
			implicitItemContainerStyles: Ge,
			xamlItemContainerStyle: g,
			groupHeaderCache: Ke,
			groupHeaderComponent: qe,
			props: _,
			emit: v,
			itemsSourceOverride: Je,
			resolvedItemsSource: Ye,
			collectionViewGroups: Xe,
			items: y,
			isGrouped: b,
			isItemClickEnabled: Ze,
			canDragItems: Qe,
			canReorderItems: $e,
			allowDrop: et,
			stickyHeader: tt,
			selectionMode: x,
			resolvedIsEnabled: S,
			getGroupItems: nt,
			getGroupKey: rt,
			getGroupTitle: it,
			objectItemKeys: at,
			valueItemKeys: ot,
			explicitItemKeys: st,
			keysForItems: ct,
			internalSelectedItems: lt,
			flatItems: C,
			configuredSelectedItems: ut,
			selectedItems: w,
			cssLength: T,
			xamlThickness: E,
			contentAlignments: dt,
			alignment: ft,
			backgroundStyle: pt,
			rootStyle: mt,
			contentPaddingStyle: ht,
			configuredItemContainerStyle: D,
			propItemContainerStyle: O,
			itemContainerStyle: gt,
			styleAlignment: _t,
			contentAlignment: vt,
			verticalContentAlignment: yt,
			itemContentStyle: bt,
			messageLayout: xt,
			containerRef: k,
			semanticView: A,
			onSemanticKeyDown: St,
			listViewApi: j,
			listRef: M,
			internalItems: N,
			itemKeys: Ct,
			groupContainerKeys: wt,
			groupItemKeys: Tt,
			itemContainers: Et,
			contextFlyoutControllers: Dt,
			itemContainerRefs: Ot,
			itemContainerKey: kt,
			raiseContainerEvent: At,
			disposeContainerFlyout: jt,
			selectContainerItem: Mt,
			prepareItemContainer: Nt,
			itemContainerRef: Pt,
			ContextFlyoutOutlet: Ft,
			onItemContextRequested: It,
			COLLECTION_REPOSITION_DURATION: 300,
			COLLECTION_FADE_DURATION: 167,
			messageEnterItems: P,
			messageRepositionAnimations: Lt,
			messageEnterTimers: Rt,
			collectionRows: zt,
			renderedItems: Bt,
			stopMessageRepositionAnimations: Vt,
			animateCollectionMutation: Ht,
			isDragging: F,
			isExternalDragOver: Ut,
			dragIndices: I,
			insertBeforeIndex: L,
			dragOverIndex: R,
			get anchorIndex() {
				return z;
			},
			set anchorIndex(e) {
				z = e;
			},
			get lastCalcTime() {
				return Wt;
			},
			set lastCalcTime(e) {
				Wt = e;
			},
			get cachedMidpoints() {
				return B;
			},
			set cachedMidpoints(e) {
				B = e;
			},
			dragLayoutVersion: V,
			get dragLayoutScrollTop() {
				return Gt;
			},
			set dragLayoutScrollTop(e) {
				Gt = e;
			},
			dragOffsets: H,
			get pendingInsertIndex() {
				return U;
			},
			set pendingInsertIndex(e) {
				U = e;
			},
			get liveReorderTimer() {
				return W;
			},
			set liveReorderTimer(e) {
				W = e;
			},
			get dragPreviewElement() {
				return Kt;
			},
			set dragPreviewElement(e) {
				Kt = e;
			},
			get pointerDropTarget() {
				return G;
			},
			set pointerDropTarget(e) {
				G = e;
			},
			get pointerDraggedItems() {
				return qt;
			},
			set pointerDraggedItems(e) {
				qt = e;
			},
			get externalDragHeight() {
				return Jt;
			},
			set externalDragHeight(e) {
				Jt = e;
			},
			pointerDragOwner: Yt,
			pointerDragOverEvent: Xt,
			pointerDragLeaveEvent: Zt,
			pointerDropEvent: Qt,
			get pointerDragDetail() {
				return $t;
			},
			set pointerDragDetail(e) {
				$t = e;
			},
			LIVE_REORDER_DELAY: 200,
			REORDER_ANIMATION_DURATION: 240,
			DRAG_THRESHOLD: 8,
			EDGE_SCROLL_SIZE: 100,
			EDGE_SCROLL_DELAY: 50,
			EDGE_SCROLL_MIN_SPEED: 150,
			EDGE_SCROLL_MAX_SPEED: en,
			get edgeScrollStartTimer() {
				return tn;
			},
			set edgeScrollStartTimer(e) {
				tn = e;
			},
			get edgeScrollFrame() {
				return nn;
			},
			set edgeScrollFrame(e) {
				nn = e;
			},
			get edgeScrollVelocity() {
				return rn;
			},
			set edgeScrollVelocity(e) {
				rn = e;
			},
			get edgeScrollLastTime() {
				return an;
			},
			set edgeScrollLastTime(e) {
				an = e;
			},
			get dragScrollViewport() {
				return K;
			},
			set dragScrollViewport(e) {
				K = e;
			},
			get edgeScrollViewport() {
				return q;
			},
			set edgeScrollViewport(e) {
				q = e;
			},
			get latestPointerPosition() {
				return J;
			},
			set latestPointerPosition(e) {
				J = e;
			},
			get globalPointerListenersAttached() {
				return on;
			},
			set globalPointerListenersAttached(e) {
				on = e;
			},
			isSelected: Y,
			isMessageItem: sn,
			pointerDrag: X,
			pointerDragActive: Z,
			get suppressClickUntil() {
				return cn;
			},
			set suppressClickUntil(e) {
				cn = e;
			},
			intentionallyReleasedPointerCaptures: ln,
			get pendingPointerSelection() {
				return Q;
			},
			set pendingPointerSelection(e) {
				Q = e;
			},
			get pointerSelectedItem() {
				return un;
			},
			set pointerSelectedItem(e) {
				un = e;
			},
			get pointerSelectedUntil() {
				return dn;
			},
			set pointerSelectedUntil(e) {
				dn = e;
			},
			messageAlignment: fn,
			reorderTargetIndex: pn,
			reorderHintOffset: mn,
			reorderOffset: hn,
			pointerDragOverIndex: gn,
			itemClasses: _n,
			selectionIndicatorStyle: vn,
			emitSelection: yn,
			selectionIndicatorAnimations: bn,
			selectionIndicatorPresses: $,
			itemElement: xn,
			cancelSelectionIndicatorForItem: Sn,
			trackSelectionIndicatorAnimation: Cn,
			playSelectionIndicatorReveal: wn,
			readSelectionIndicatorScale: Tn,
			releaseSelectionIndicator: En,
			finishSelectionIndicatorPress: Dn,
			cancelSelectionIndicatorPresses: On,
			beginSelectionIndicatorPress: kn,
			selectItem: An,
			isPointerInsideElement: jn,
			commitPointerSelection: Mn,
			onItemClick: Nn,
			onItemPointerDown: Pn,
			startPointerDrag: Fn,
			updatePointerDragPosition: In,
			onItemPointerMove: Ln,
			releasePointerDragCapture: Rn,
			onItemPointerUp: zn,
			onItemPointerCancel: Bn,
			onItemPointerLeave: Vn,
			onItemLostPointerCapture: Hn,
			getItemStyle: Un,
			cacheMidpoints: Wn,
			shiftCachedLayoutForScroll: Gn,
			pointerInsertIndex: Kn,
			normalizeOwnInsertIndex: qn,
			updateDragOffsets: Jn,
			applyLiveReorder: Yn,
			scheduleLiveReorder: Xn,
			flushLiveReorder: Zn,
			stopEdgeAutoScroll: Qn,
			findPointerViewport: $n,
			computeEdgeScrollVelocity: er,
			recalculateDragTarget: tr,
			runEdgeAutoScroll: nr,
			updateEdgeAutoScroll: rr,
			onDragViewportScroll: ir,
			clearPointerDropVisual: ar,
			onPointerListDragOver: or,
			onPointerListDragLeave: sr,
			onPointerListDrop: cr,
			updatePointerDropTarget: lr,
			onGlobalPointerMove: ur,
			onGlobalPointerUp: dr,
			onGlobalPointerCancel: fr,
			cancelActiveInteractions: pr,
			onGlobalKeyDown: mr,
			onVisibilityChange: hr,
			onWindowPointerLeave: gr,
			get detachSecondaryTouchScroll() {
				return _r;
			},
			set detachSecondaryTouchScroll(e) {
				_r = e;
			},
			onViewportDragOver: vr,
			onViewportDragLeave: yr,
			onViewportDrop: br,
			resetDrag: xr,
			ScrollViewer: oe,
			get vAcrylicBrush() {
				return l;
			}
		};
		return Object.defineProperty(Sr, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), Sr;
	}
});
//#endregion
export { h as default };

//# sourceMappingURL=ListView.vue_vue_type_script_setup_true_lang.js.map