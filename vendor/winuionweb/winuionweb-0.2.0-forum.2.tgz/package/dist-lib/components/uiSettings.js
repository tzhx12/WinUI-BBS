import { reactive as e } from "vue";
//#region src/components/uiSettings.ts
var t = e({
	AutoHideScrollBars: !0,
	AdvancedEffectsEnabled: !0,
	AreEffectsFast: !0,
	EnergySaverStatus: !1,
	IsHighContrast: !1
});
//#endregion
export { t as uiSettings };

//# sourceMappingURL=uiSettings.js.map