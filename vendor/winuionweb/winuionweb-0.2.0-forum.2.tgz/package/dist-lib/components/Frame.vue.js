import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./Frame.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                          */
import { createElementBlock as n, createVNode as r, mergeProps as i, openBlock as a } from "vue";
//#region src/components/Frame.vue
function o(e, t, o, s, c, l) {
	return a(), n("div", i(s.attrs, {
		ref: "frameElement",
		class: "win-frame",
		style: [s.attrs.style, s.frameStyle]
	}), [r(s.ContentOutlet)], 16);
}
var s = /*#__PURE__*/ e(t, [
	["render", o],
	["__scopeId", "data-v-8627df05"],
	["__file", "Frame.vue"]
]);
//#endregion
export { s as default };

//# sourceMappingURL=Frame.vue.js.map