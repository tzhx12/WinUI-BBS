import { alignment as e, boolValue as t, xamlThickness as n } from "./layout.js";
import { colorString as r, createSolidColorBrush as i, xamlThemeKey as a } from "./brushCore.js";
import { primitiveResourceScope as o } from "./xamlPrimitives.js";
import { useAcrylicBrushStyle as s } from "./AcrylicBrush.js";
import { normalizeXamlNodes as c, resolveXamlHandler as l, resolveXamlValue as u, updateXamlBinding as d, xamlItemContextKey as f, xamlScopeKey as p, xamlTemplateComponent as m } from "./xamlRuntime.js";
import { collectXamlResources as h, useXamlBrushResources as g } from "./xamlBrushResources.js";
import { isBrushProperty as _, useBrushProperty as v } from "./brushProperties.js";
import { vAcrylicBrush as ee } from "./acrylicBrushVisual.js";
import { vThemeShadow as te } from "./themeShadowVisual.js";
import ne from "../_virtual/_plugin-vue_export-helper.js";
import { useI18n as re } from "./i18n/index.js";
import { xamlResourceDictionaryKey as ie } from "./Page.vue_vue_type_script_lang.js";
import { CollectionItemContainerStyle as ae, CollectionItemTemplate as oe, CollectionItems as se, CollectionResources as ce, getCollectionProperty as le, getVNodeChildren as ue } from "./CollectionProperties.js";
import de from "./TextBlock.vue.js";
import fe from "./AnimatedIcon.vue.js";
import pe from "./ScrollViewer.vue.js";
import { scrollViewerTemplateBindings as me } from "./scrollViewerTemplateBindings.js";
import he from "./ContentPresenter.vue.js";
import ge from "./TextBox.vue.js";
import { useAnimatedIconInput as _e } from "./animatedIconInput.js";
import { useFlyoutAnimation as ve } from "./useFlyoutAnimation.js";
import { ComboBoxDescription as ye, ComboBoxHeader as be, ComboBoxHeaderTemplate as xe, getComboBoxProperty as Se, isComboBoxProperty as Ce } from "./ComboBoxProperties.js";
/* empty css                      */
import "./inlineControlProperties.js";
/* empty css                                             */
import { Fragment as we, Teleport as Te, computed as y, createBlock as Ee, createCommentVNode as b, createElementBlock as x, createElementVNode as S, createVNode as C, defineComponent as De, getCurrentInstance as Oe, h as ke, inject as Ae, isVNode as je, mergeProps as Me, nextTick as w, normalizeClass as Ne, normalizeStyle as T, onBeforeUnmount as Pe, onMounted as Fe, openBlock as E, provide as Ie, ref as D, renderList as Le, resolveComponent as Re, shallowReactive as ze, shallowRef as Be, toDisplayString as Ve, unref as He, useAttrs as Ue, useSlots as We, watch as O, withCtx as k, withDirectives as Ge, withModifiers as Ke } from "vue";
//#region src/components/ComboBox.vue
var qe = /*@__PURE__*/ Object.assign({
	ItemTemplate: oe,
	Items: se,
	Resources: ce,
	ItemContainerStyle: ae,
	Header: be,
	HeaderTemplate: xe,
	Description: ye
}, {
	name: "ComboBox",
	inheritAttrs: !1
}, {
	__name: "ComboBox",
	props: {
		ItemsSource: {
			type: [Array, String],
			default: void 0
		},
		ItemTemplate: {
			type: [
				String,
				Object,
				Function
			],
			default: void 0
		},
		Header: {
			type: null,
			default: ""
		},
		HeaderTemplate: {
			type: null,
			default: void 0
		},
		Description: {
			type: null,
			default: ""
		},
		ItemContainerStyle: {
			type: null,
			default: void 0
		},
		PlaceholderText: {
			type: [String, Number],
			default: ""
		},
		IsEditable: {
			type: [Boolean, String],
			default: !1
		},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		IsDropDownOpen: {
			type: [Boolean, String],
			default: void 0
		},
		SelectedIndex: {
			type: [Number, String],
			default: void 0
		},
		SelectedItem: {
			type: null,
			default: void 0
		},
		SelectedValue: {
			type: null,
			default: void 0
		},
		SelectedValuePath: {
			type: [String, Number],
			default: ""
		},
		DisplayMemberPath: {
			type: [String, Number],
			default: ""
		},
		Text: {
			type: [String, Number],
			default: void 0
		},
		IsTextSearchEnabled: {
			type: [Boolean, String],
			default: !0
		},
		SelectionChangedTrigger: {
			type: String,
			default: "Committed"
		},
		LightDismissOverlayMode: {
			type: String,
			default: "Auto"
		},
		IsTabStop: {
			type: [Boolean, String],
			default: !0
		},
		RequestedTheme: {
			type: String,
			default: "Default"
		},
		Visibility: {
			type: String,
			default: "Visible"
		},
		Background: {
			type: [String, Object],
			default: ""
		},
		Foreground: {
			type: String,
			default: ""
		},
		BorderBrush: {
			type: [String, Object],
			default: ""
		},
		BorderThickness: {
			type: [String, Number],
			default: 1
		},
		CornerRadius: {
			type: [String, Number],
			default: 4
		},
		Padding: {
			type: [String, Number],
			default: ""
		},
		PlaceholderForeground: {
			type: String,
			default: ""
		},
		FontFamily: {
			type: String,
			default: ""
		},
		FontSize: {
			type: [String, Number],
			default: ""
		},
		FontWeight: {
			type: [String, Number],
			default: ""
		},
		HorizontalContentAlignment: {
			type: String,
			default: "Stretch"
		},
		VerticalContentAlignment: {
			type: String,
			default: "Top"
		},
		Width: {
			type: [String, Number],
			default: ""
		},
		Height: {
			type: [String, Number],
			default: ""
		},
		MinWidth: {
			type: [String, Number],
			default: ""
		},
		MinHeight: {
			type: [String, Number],
			default: ""
		},
		MaxWidth: {
			type: [String, Number],
			default: ""
		},
		MaxHeight: {
			type: [String, Number],
			default: ""
		},
		Margin: {
			type: [String, Number],
			default: ""
		},
		HorizontalAlignment: {
			type: String,
			default: "Left"
		},
		VerticalAlignment: {
			type: String,
			default: "Top"
		},
		MaxDropDownHeight: {
			type: [Number, String],
			default: 504
		}
	},
	emits: [
		"DropDownOpened",
		"DropDownClosed",
		"SelectionChanged",
		"TextSubmitted",
		"Loaded"
	],
	setup(ne, { expose: Te, emit: Ee }) {
		let b = {
			Top: 4,
			Bottom: 4
		}, { t: x } = re(), S = ne, C = Oe(), Me = s("{ThemeResource ComboBoxDropDownBackground}", C), Ne = _e(!1, (e) => e === "Disabled" ? "Normal" : e), T = Ue(), E = y(() => Object.fromEntries(Object.entries(T).filter(([e]) => ![
			"class",
			"style",
			"SelectionChanged",
			"TextSubmitted",
			"DropDownOpened",
			"DropDownClosed",
			"Loaded"
		].includes(e) && !e.startsWith("on")))), Le = me((e) => T[e], C, {
			VerticalScrollMode: "Auto",
			IsDeferredScrollingEnabled: !1
		}), Re = We(), Ve = o(() => Re.default?.() ?? []), k = y(() => t(Ve.value.IsDefaultShadowEnabled ?? !0)), Ge = v("Background", () => S.Background, () => Re.default?.() ?? [], C), Ke = Ae(ie, {}), qe = y(() => {
			let e = {
				Header: [],
				HeaderTemplate: [],
				Description: [],
				resources: [],
				items: [],
				itemTemplate: [],
				itemContainerStyle: []
			}, t = (n) => {
				for (let r of n) {
					if (r.type === we && Array.isArray(r.children)) {
						t(r.children);
						continue;
					}
					let n = Se(r) || le(r);
					n && n in e && e[n].push(...ue(r));
				}
			};
			return t(Re.default?.() ?? []), e;
		}), Je = y(() => {
			let e = {}, t = (n) => {
				for (let r of n) {
					let n = typeof r.type == "string" ? r.type : r.type?.name;
					r.type === we || n === "ResourceDictionary" ? t(ue(r)) : h([r], e);
				}
			};
			return t(qe.value.resources), e;
		}), Ye = new Proxy(Ke, { get: (e, t) => Je.value[t] ?? e[t] });
		Ie(ie, Ye);
		let Xe = g(C), A = (e) => {
			let t = typeof e == "string" ? e.match(/^\{(?:StaticResource|ThemeResource)\s+([^\s}]+)\}/)?.[1] : void 0;
			return t && Ye[t] ? Ye[t] : u(e, C);
		}, Ze = y(() => {
			let e = A(S.ItemTemplate);
			return e && typeof e == "object" && e.type ? ue(e) : qe.value.itemTemplate;
		}), Qe = y(() => Ze.value.length > 0 || typeof A(S.ItemTemplate) == "function"), $e = De({
			name: "ComboBoxItemTemplate",
			props: {
				item: {
					type: null,
					default: void 0
				},
				index: {
					type: Number,
					default: 0
				}
			},
			setup(e) {
				return Ie(f, y(() => e.item)), () => typeof A(S.ItemTemplate) == "function" ? A(S.ItemTemplate)(e.item) : m(Ze.value, e.item, C);
			}
		}), et = De({
			props: { item: {
				type: null,
				default: void 0
			} },
			setup(e) {
				return () => e.item?.__contentNodes?.length ? ke(we, c(e.item.__contentNodes, C)) : je(e.item?.Content) ? ke(we, c([e.item.Content], C)) : K(e.item);
			}
		}), tt = De({ setup() {
			return () => U.value === void 0 ? ke(de, {
				Text: ut.value,
				class: "win-combo-placeholder",
				Foreground: "var(--ComboBoxPlaceholderCurrent)"
			}) : Qe.value ? ke($e, {
				item: U.value,
				index: H.value
			}) : ke(et, { item: U.value });
		} }), nt = /* @__PURE__ */ new Map(), rt = /* @__PURE__ */ new Map(), it = /* @__PURE__ */ new Map(), at = y(() => {
			let e = [], n = /* @__PURE__ */ new Set(), a = /* @__PURE__ */ new Map(), o = (e) => {
				if (e == null) return "";
				if (Array.isArray(e)) return e.map(o).join("");
				if (typeof e == "string" || typeof e == "number") return String(e);
				if (typeof e != "object") return "";
				let t = e.children;
				if (typeof t == "string" || typeof t == "number") return String(t);
				if (t && typeof t == "object" && typeof t.default == "function") try {
					return o(t.default());
				} catch {
					return "";
				}
				return o(t);
			}, s = (c) => {
				if (c) {
					if (Array.isArray(c)) {
						c.forEach(s);
						return;
					}
					if (typeof c == "object") {
						let l = c.type, d = typeof l == "string" ? l : l?.name || l?.__name || "";
						if (le(c) === "items") s(ue(c));
						else if (Ce(c) || _(c)) return;
						else if (d === "x:String") {
							let t = c.props?.["x:Uid"], n = t ? x(t) : o(c.children).trim();
							n && (a.set(c.key ?? t ?? e.length, e.length), e.push(n));
						} else if (d === "SolidColorBrush") {
							let t = c.key ?? e.length;
							n.add(t);
							let a = nt.get(t);
							(!a || a.__xamlBrush !== "SolidColorBrush") && (a = i(), nt.set(t, a)), a.Color = r(u(c.props?.Color, C)), a.Opacity = Number(u(c.props?.Opacity ?? 1, C)), e.push(a);
						} else if (l?.__xamlComboBoxItem || d === "ComboBoxItem") {
							let r = c.props?.Content === void 0 ? void 0 : u(c.props.Content, C), i = c.props?.Content === void 0 ? ue(c) : [], a = c.props?.Tag, s = c.key ?? e.length;
							n.add(s);
							let l = nt.get(s);
							l || (l = ze({
								Content: void 0,
								Tag: void 0,
								IsEnabled: !0,
								__contentNodes: []
							}), nt.set(s, l)), l.Content = r ?? o(c).trim(), l.__contentNodes = i, l.IsEnabled = t(u(c.props?.IsEnabled ?? !0, C)), l.Tag = typeof a == "string" && a.startsWith("{}") ? a.slice(2) : u(a, C), e.push(l);
						} else typeof l == "symbol" && s(c.children);
					}
				}
			};
			s(Re.default?.());
			for (let e of nt.keys()) n.has(e) || nt.delete(e);
			return it = rt, rt = a, e;
		}), ot = !0, j = y(() => {
			let e = u(S.ItemsSource, C);
			return Array.isArray(e) ? (ot = !1, e) : (ot = !0, at.value);
		}), st = y(() => qe.value.Header[0] ?? u(S.Header, C)), ct = y(() => qe.value.HeaderTemplate[0] ?? A(S.HeaderTemplate)), lt = y(() => qe.value.Description[0] ?? u(S.Description, C)), ut = y(() => u(S.PlaceholderText, C)), M = y(() => t(u(S.IsEditable, C))), dt = D(void 0), ft = y(() => t(u(S.IsEnabled, C)));
		O(ft, () => {
			dt.value = void 0;
		});
		let N = y(() => dt.value ?? ft.value), pt = y(() => t(u(S.IsTabStop, C))), mt = y(() => {
			let e = u(S.IsDropDownOpen, C);
			return e === void 0 ? void 0 : t(e);
		}), ht = y(() => {
			let e = u(S.SelectedIndex, C);
			return e === void 0 || e === "" ? void 0 : Number(e);
		}), gt = y(() => u(S.SelectedItem, C)), _t = y(() => u(S.SelectedValue, C)), vt = y(() => u(S.Text, C)), yt = y(() => u(S.Width, C)), bt = y(() => u(S.MinWidth, C)), xt = y(() => u(S.MaxWidth, C)), St = y(() => Number(u(S.MaxDropDownHeight, C)) || 504), Ct = Ee, wt = D(null), P = D(null), Tt = D(null), Et = De({
			name: "ComboBoxEditableText",
			inheritAttrs: !1,
			setup(e, { attrs: n, expose: r }) {
				let i = Oe(), a = D(null), o = {
					Focus: () => a.value?.Focus(),
					SelectAll: () => a.value?.SelectAll()
				};
				return Object.defineProperty(o, "Text", { get: () => a.value?.Text }), r(o), () => {
					let e = c([ke(ge, {
						...n,
						ref: a
					})], i)[0];
					for (let n of ["IsEnabled", "ShowDeleteButton"]) e.props?.[n] !== void 0 && (e.props[n] = t(u(e.props[n], i)));
					return e;
				};
			}
		}), F = D(null), Dt = D(null), Ot = D(null), I = D([]), L = D(-1), R = D(-1), kt = y(() => z.value && R.value >= 0 ? R.value : H.value), z = D(!!mt.value), At = y(() => z.value ? .5 : 1), B = D(!1), jt = y(() => z.value || B.value), V = D(!1), Mt = D(!1), Nt = D(!1), Pt = D({ visibility: "hidden" }), Ft = D("Mouse"), It = y(() => u(S.LightDismissOverlayMode, C) === "On"), H = D(-1), U = Be(void 0), W = D(vt.value === void 0 ? "" : String(vt.value)), Lt = D(""), Rt = Ae(a, null) ?? Ae("winuiTheme", null), zt = `win-combo-box-${Math.random().toString(36).slice(2)}`, G = ve(F, {
			Duration: () => B.value ? 167 : 250,
			Easing: "cubic-bezier(0,0,0,1)",
			Origin: "rect",
			StartRect: (e) => {
				let t = P.value?.getBoundingClientRect(), n = t ? t.top + t.height / 2 - e.top : e.height / 2, r = Math.abs(n - e.height / 2), i = B.value ? .15 : .5, a = e.height * (1 - i) / 2, o = e.height * i + Math.max(0, r - a) * 2;
				return {
					left: 0,
					right: e.width,
					top: n - o / 2,
					bottom: n + o / 2
				};
			},
			Direction: () => Nt.value ? "bottom" : "top",
			StripSize: 36
		}), Bt = y(() => G.isPlaying.value), Vt = [], Ht = () => {
			Vt.forEach((e) => e.cancel()), Vt = [];
		}, Ut = (e) => {
			if (Ht(), !G.isPlaying.value) return;
			e && F.value?.animate && Vt.push(F.value.animate([
				{ opacity: 1 },
				{
					opacity: 1,
					offset: 84 / 167
				},
				{ opacity: 0 }
			], {
				duration: 167,
				easing: "linear",
				fill: "none"
			}));
			let t = !M.value && P.value?.querySelector(".win-combo-content");
			t?.animate && Vt.push(t.animate(e ? [
				{ opacity: 0 },
				{
					opacity: 0,
					offset: 84 / 167
				},
				{ opacity: 1 }
			] : [{ opacity: 1 }, { opacity: .5 }], {
				duration: e ? 167 : 83,
				easing: "linear",
				fill: "none"
			}));
		};
		O(Bt, (e) => {
			!e && B.value && (Ht(), B.value = !1, Mt.value = !1);
		});
		let Wt = null, Gt = null, Kt = 0, qt = "Mouse", Jt = !1, Yt, Xt = "", Zt = !1, Qt = (e) => e === "" || e == null ? "" : typeof e == "string" && e.trim() !== "" && !Number.isNaN(Number(e.trim())) ? `${Number(e.trim())}px` : typeof e == "number" ? `${e}px` : e, $t = y(() => {
			let t = {};
			Xe.sync(Je.value), yt.value !== "" && (t.width = Qt(yt.value)), bt.value !== "" && (t.minWidth = Qt(bt.value)), xt.value !== "" && (t.maxWidth = Qt(xt.value));
			let r = String(u(S.Margin, C) ?? "").split(",").map((e) => Qt(e.trim()));
			S.Margin !== "" && (t.margin = r.length === 4 ? `${r[1]} ${r[2]} ${r[3]} ${r[0]}` : r.length === 2 ? `${r[1]} ${r[0]}` : r[0]);
			for (let e of [
				"Height",
				"MinHeight",
				"MaxHeight"
			]) S[e] !== "" && (t[e[0].toLowerCase() + e.slice(1)] = Qt(u(S[e], C)));
			t.alignSelf = e(u(S.VerticalAlignment, C), "vertical"), t.justifySelf = e(u(S.HorizontalAlignment, C), "horizontal"), u(S.HorizontalAlignment, C) === "Stretch" && yt.value === "" && (t.width = "100%");
			for (let e of [
				"Background",
				"Foreground",
				"BorderBrush"
			]) S[e] && (t[`--ComboBox${e}`] = u(S[e], C));
			let i = u(S.BorderBrush, C);
			i != null && typeof i != "object" && !/gradient\(/i.test(String(i)) && (t["--ComboBoxBorderSide"] = String(i), t["--ComboBoxBorderTop"] = String(i), t["--ComboBoxBorderBottom"] = String(i)), Ge.value.value && typeof Ge.value.value != "object" && (t["--ComboBoxBackground"] = Ge.value.value), S.PlaceholderForeground && (t["--ComboBoxPlaceHolderForeground"] = u(S.PlaceholderForeground, C)), t["--ComboBoxBorderThemeThickness"] = n(u(S.BorderThickness, C)), S.Padding !== "" && (t["--ComboBoxPadding"] = n(u(S.Padding, C))), t["--ComboBoxCornerRadius"] = n(u(S.CornerRadius, C));
			for (let e of [
				"FontFamily",
				"FontSize",
				"FontWeight"
			]) S[e] !== "" && (t[e[0].toLowerCase() + e.slice(1)] = e === "FontSize" ? Qt(u(S[e], C)) : u(S[e], C));
			return u(S.Visibility, C) === "Collapsed" && (t.display = "none"), [T.style, t];
		}), en = y(() => S.Padding === "" ? "var(--combo-selection-padding)" : u(S.Padding, C)), tn = y(() => ({
			margin: n(en.value),
			justifySelf: e(u(S.HorizontalContentAlignment, C), "horizontal"),
			alignSelf: e(u(S.VerticalContentAlignment, C), "vertical")
		})), nn = y(() => {
			let e = String(u(S.RequestedTheme, C)).toLowerCase(), t = e === "default" ? He(Rt) || Lt.value : e;
			return t === "light" || t === "dark" ? `theme-${t}` : "";
		}), rn = (e, t) => t ? t.split(".").reduce((e, t) => e?.[t], e) : e, K = (e) => {
			let t = u(S.DisplayMemberPath, C), n = t ? rn(e, t) : e;
			return n == null ? "" : typeof n == "object" ? n.Content === void 0 ? typeof n.toString == "function" && n.toString !== Object.prototype.toString ? String(n) : "" : typeof n.Content == "string" || typeof n.Content == "number" ? String(n.Content) : "" : String(n);
		}, an = (e) => e?.IsEnabled !== !1, on = (e) => {
			let t = qe.value.itemContainerStyle[0] ?? A(S.ItemContainerStyle), r = {};
			for (let e of je(t) ? ue(t) : []) {
				let t = e.props?.Property, i = u(e.props?.Value, C);
				[
					"Width",
					"Height",
					"MinWidth",
					"MinHeight",
					"MaxWidth",
					"MaxHeight",
					"FontSize"
				].includes(t) && (r[t[0].toLowerCase() + t.slice(1)] = Qt(i)), t === "Foreground" && (r.color = i), t === "Padding" && (r["--ComboBoxItemPadding"] = n(i));
			}
			return r;
		}, sn = (e, t = {}) => {
			t.OriginalSource ??= Yn;
			let n = C?.vnode.props?.[`on${e}`];
			if (e === "Loaded" && n) {
				for (let e of Array.isArray(n) ? n : [n]) e(Yn, t);
				return;
			}
			Ct(e, Yn, t), n || l(T[e], C)?.(Yn, t);
		}, cn = (e) => {
			let t = u(S.SelectedValuePath, C);
			return t ? rn(e, t) : e;
		}, ln = (e, t) => e && typeof e == "object" ? e.Key ?? e.Id ?? e.id ?? t : `${String(e)}-${t}`, un = (e) => j.value.findIndex((t) => Object.is(t, e)), dn = (e) => j.value.findIndex((t) => Object.is(cn(t), e)), fn = y(() => U.value === void 0 ? ut.value || "" : K(U.value)), pn = y(() => W.value || fn.value), mn = (e, t, n = !0) => {
			H.value = e, U.value = t, Jt = M.value && t !== void 0 && e < 0, n && (W.value = t === void 0 ? "" : K(t));
		}, hn = () => [
			ht.value,
			gt.value,
			_t.value
		], gn, q = !1, _n = (e) => !gn || e.some((e, t) => !Object.is(e, gn[t])), vn = () => {
			let e, t, n = hn(), r = gn ? n.findIndex((e, t) => !Object.is(e, gn[t])) : -1, i = r >= 0 ? r : n.findIndex((e) => e !== void 0);
			if (gn = n, q = !1, i === 0) e = ht.value >= 0 && ht.value < j.value.length ? ht.value : -1, t = e >= 0 ? j.value[e] : void 0, q = ht.value >= 0 && e < 0;
			else if (i === 1) e = un(gt.value), t = gt.value === null ? void 0 : gt.value, q = t !== void 0 && e < 0 && !M.value;
			else if (i === 2) e = dn(_t.value), t = e >= 0 ? j.value[e] : void 0, q = e < 0;
			else return;
			let a = U.value, o = e !== H.value || !Object.is(a, t);
			mn(e, t, vt.value === void 0), o && !q && yn(a, t, e);
		}, yn = (e, t, n) => {
			q = !1, d(S.SelectedIndex, n, C), d(S.SelectedItem, t, C), d(S.SelectedValue, t === void 0 ? void 0 : cn(t), C), d(S.Text, W.value, C), gn = hn(), sn("SelectionChanged", {
				AddedItems: t === void 0 ? [] : [t],
				RemovedItems: e === void 0 ? [] : [e],
				Handled: !1
			});
		}, J = (e) => {
			let t = e >= 0 && e < j.value.length ? e : -1, n = t >= 0 ? j.value[t] : void 0, r = U.value;
			q = !1, !(t === H.value && Object.is(n, r)) && (mn(t, n), yn(r, n, t));
		}, bn = (e) => {
			let t = e === null ? void 0 : e, n = un(t);
			if (t !== void 0 && n < 0 && !M.value) return;
			let r = U.value;
			q = !1, !(n === H.value && Object.is(t, r)) && (mn(n, t), yn(r, t, n));
		}, xn = (e) => {
			W.value = e == null ? "" : String(e), d(S.Text, W.value, C);
		}, Sn = (e) => J(dn(e)), Cn = () => {
			let e = wt.value?.parentElement?.closest(".theme-light, .theme-dark, [data-theme=\"light\"], [data-theme=\"dark\"]");
			return e?.classList.contains("theme-dark") ? "dark" : e?.classList.contains("theme-light") ? "light" : e?.getAttribute("data-theme") || "";
		}, wn = () => {
			Gt?.disconnect();
			let e = wt.value?.parentElement?.closest(".theme-light, .theme-dark, [data-theme=\"light\"], [data-theme=\"dark\"]");
			Lt.value = Cn(), e && (Gt = new MutationObserver(() => {
				let e = Cn();
				e !== Lt.value && (Lt.value = e, An());
			}), Gt.observe(e, {
				attributes: !0,
				attributeFilter: ["class", "data-theme"]
			}));
		}, Y = (e) => {
			let t = I.value[e];
			if (!t) return 36;
			let n = window.getComputedStyle(t);
			return t.getBoundingClientRect().height + Number.parseFloat(n.marginTop || "0") + Number.parseFloat(n.marginBottom || "0");
		}, Tn = (e, t, n, r, i, a, o) => {
			let s = o, c = 0;
			if ((t < e || e < 0) && (e = Math.floor(t / 2)), t === 0) return {
				popupY: n,
				popupMaxHeight: r,
				offset: c
			};
			let l = Y(e);
			n + r >= a.Height && (n = a.Height - r);
			let u = n + r / 2 - l / 2 - i.Top, d = Math.max(u, 0), f = Math.max(n + r / 2 - s / 2, 0), p = d + l + i.Top + i.Bottom, m = Math.min(p, a.Height), h = Math.min(f + s, a.Height), g = e - 1, _ = e + 1, v = 1, ee = Math.min(7, t), te = Math.min(15, t);
			if (p > a.Height && (d = Math.max(d - p + a.Height, 0)), g >= 0) for (l = Y(g); g >= 0 && d - l >= f && v < ee;) d -= l, v++, g--, g >= 0 && (l = Y(g));
			if (_ < t) for (l = Y(_); _ < t && m + l < h && m - d < s && v < te;) m += l, v++, _++, _ < t && (l = Y(_));
			if (g >= 0 || _ < t) {
				let e = g >= 0, n = e ? g : _;
				for (l = Y(n); m - d + l <= s && (m + l < a.Height || d - l >= 0) && v < te;) e ? g-- : _++, d - l <= 0 ? m += l : d -= l, v++, (g >= 0 || _ < t) && (e = g >= 0, n = e ? g : _, l = Y(n));
			}
			c = g + 1;
			let ne = d;
			return s = m - d, {
				popupY: ne,
				popupMaxHeight: s,
				offset: c
			};
		}, En = (e, t, n, r, i) => {
			if (e === 0) return {
				popupY: t,
				popupMaxHeight: n,
				offset: 0,
				openedUp: !1
			};
			let a = t + n, o = Math.max(a, 0), s = o + r.Top + r.Bottom, c = 0, l = 0, u = Math.min(15, e);
			for (; c < e && l < u;) s += Y(c), l++, c++;
			let d = o, f = s - o, p = !1;
			return d + f > i.Height && t - f >= 0 && (d = Math.max(t - f, 0), p = !0), {
				popupY: d,
				popupMaxHeight: f,
				offset: 0,
				openedUp: p
			};
		}, Dn = (e, t, n, r, i, a, o) => {
			let s = o;
			(t < e || e < 0) && (e = Math.floor(t / 2));
			let c = Y(e), l = Math.min((s - r) / 2, n), u = Math.min(s - l - r, Math.max(0, a.Height - n - c)), d = Math.floor(Math.min(7, (t - 1) / 2)), f = Math.floor(Math.min(7, (t - 1) / 2)), p = 0, m = 0, h = e - 1 >= 0 ? e - 1 : t - 1;
			h >= 0 && (m = Y(h));
			let g = Math.max(Math.min(n, a.Height - c), 0);
			for (; c + m <= s && p < d && l - m > 0;) p++, c += m, l -= m, g -= m, h = h - 1 >= 0 ? h - 1 : t - 1, h >= 0 && (m = Y(h));
			let _ = e - p, v = 0;
			for (m = 0, h = e + 1 < t ? e + 1 : 0, h < t && (m = Y(h)); c + m <= s && v < f && u - m > 0;) v++, c += m, u -= m, h = h + 1 < t ? h + 1 : 0, h < t && (m = Y(h));
			for (l >= m / 2 && (c += m / 2, g -= m / 2, _ -= .5), s = Math.min(s, c); _ < 0;) _ += t + 1;
			for (; _ >= t + 1;) _ -= t + 1;
			return {
				popupY: g,
				popupMaxHeight: s,
				offset: _,
				childHeight: i
			};
		}, On = (e, t, n, r = b) => e <= 0 ? !1 : e > 15 ? !0 : (t = Math.min(t, n.Height), j.value.reduce((e, t, n) => e + Y(n), r.Top + r.Bottom) > t), kn = async () => {
			if (!z.value || !P.value || !F.value) return;
			G.cancel(), await w();
			let e = P.value.getBoundingClientRect(), t = {
				Width: window.innerWidth,
				Height: window.innerHeight
			};
			if (t.Width === 0 || t.Height === 0 || e.width === 0 || e.height === 0) return;
			let n = Math.min(St.value, t.Height), r = Ft.value === "Touch", i = b, a = Math.max(r ? 240 : 80, e.width);
			Mt.value = !1, Pt.value = {
				top: "0px",
				left: "0px",
				minWidth: `${a}px`,
				maxWidth: `${t.Width}px`,
				maxHeight: `${n}px`,
				visibility: "hidden"
			}, await w();
			let o = Math.max(e.width, Math.min(F.value.getBoundingClientRect().width, t.Width)), s = window.getComputedStyle(P.value).direction === "rtl" ? e.right - o : e.left, c = Math.round(Math.max(0, Math.min(s, t.Width - o))), l = On(j.value.length, n, t, i), u = M.value ? En(j.value.length, e.top, e.height, i, t) : r && l ? Dn(H.value, j.value.length, e.top, e.height, F.value.getBoundingClientRect().height, t, n) : Tn(H.value, j.value.length, e.top, e.height, i, t, n), d = u.popupY, f = Math.max(e.height, Math.min(u.popupMaxHeight, n));
			d + f > t.Height && (d = Math.max(d - (d + f - t.Height), 0));
			let p = Math.round(d);
			if (Nt.value = u.openedUp ?? p < e.top, Pt.value = {
				top: `${p}px`,
				left: `${c}px`,
				width: `${Math.ceil(o)}px`,
				minWidth: `${a}px`,
				maxWidth: `${t.Width}px`,
				height: `${Math.ceil(f + 2)}px`,
				maxHeight: `${Math.ceil(f + 2)}px`,
				visibility: "visible"
			}, await w(), Ot.value) {
				let e = Math.floor(u.offset), t = u.offset - e, n = Array.from({ length: e }, (e, t) => Y(t)).reduce((e, t) => e + t, 0) + (t > 0 ? Y(e) * t : 0);
				Dt.value?.ChangeView(null, n, null);
			}
			Mt.value = !0, j.value.length > 0 && (G.play(), Ut(!1));
		}, An = () => {
			!z.value || Kt || (Kt = window.requestAnimationFrame(() => {
				Kt = 0, kn();
			}));
		}, jn = (e) => {
			F.value?.contains(e.target) || An();
		}, Mn = async (e) => {
			e === z.value || e && !N.value || (z.value = e, d(S.IsDropDownOpen, e, C), e ? (G.cancel(), Ht(), B.value = !1, Ft.value = qt, Lt.value = Cn(), Mt.value = !1, R.value = H.value, rr = U.value, sn("DropDownOpened"), await w(), await kn()) : (G.cancel(), Mt.value && F.value ? (B.value = !0, G.playReverse(), Ut(!0), G.isPlaying.value || (B.value = !1, Mt.value = !1)) : Mt.value = !1, R.value = -1, L.value = -1, sn("DropDownClosed")));
		}, Nn = () => Mn(!0), X = () => Mn(!1), Pn = () => Mn(!z.value), Z = () => {
			if (!M.value) {
				P.value?.focus();
				return;
			}
			V.value ? Tt.value?.Focus() : P.value?.querySelector(".win-combo-edit-display")?.focus();
		}, Fn = (e = !1) => {
			Tt.value?.Focus(), e && Tt.value?.SelectAll();
		}, In = () => {
			N.value && (V.value || (Yt = U.value, Xt = W.value), V.value = !0, w(() => Fn(!0)));
		}, Ln = (e = !1) => {
			V.value && (V.value = !1, e && w(Z));
		}, Rn = () => {
			if (z.value) {
				Xn();
				return;
			}
			In(), Nn();
		}, zn = (e) => {
			!N.value || !an(j.value[e]) || (L.value = -1, J(e), V.value = !1, X(), w(Z));
		}, Bn = (e) => {
			let t = e.clientX, n = e.clientY;
			for (let e = 0; e < I.value.length; e += 1) {
				let r = I.value[e];
				if (!r) continue;
				let i = r.getBoundingClientRect();
				if (t >= i.left && t <= i.right && n >= i.top && n <= i.bottom) return e;
			}
			return -1;
		}, Vn = (e) => {
			if (e.pointerType === "touch") {
				L.value = -1;
				return;
			}
			L.value = Bn(e);
		}, Hn = () => {
			L.value = -1;
		}, Un = (e) => {
			e.pointerType === "touch" && (L.value = -1);
		}, Wn = (e) => {
			if (!z.value || e.pointerType === "touch") {
				e.pointerType === "touch" && (L.value = -1);
				return;
			}
			let t = e.target;
			L.value = F.value?.contains(t) || t instanceof Element && t.closest(".win-combo-flyout-hit-overlay") ? Bn(e) : -1;
		}, Gn = (e) => {
			if (e.target instanceof Element && e.target.closest(".win-combo-item")) return;
			let t = Bn(e);
			t >= 0 && zn(t);
		}, Kn = () => {
			if (xn(Tt.value?.Text ?? W.value), z.value && t(u(S.IsTextSearchEnabled, C))) {
				let e = W.value.toLocaleLowerCase(), t = j.value.findIndex((t) => an(t) && K(t).toLocaleLowerCase().startsWith(e));
				R.value = e ? t : -1, t >= 0 && u(S.SelectionChangedTrigger, C) === "Always" && J(t);
			}
		}, qn = () => {
			let e = W.value, t = j.value.findIndex((t) => K(t) === e);
			if (t >= 0) return t !== H.value && J(t), Jt = !1, !0;
			if (!e.trim()) return U.value !== void 0 && bn(void 0), !0;
			if (Jt && K(U.value) === e) return !0;
			let n = {
				Text: e,
				Handled: !1
			};
			Zt = !0;
			try {
				sn("TextSubmitted", n);
			} finally {
				Zt = !1;
			}
			return n.Handled || bn(e), !0;
		}, Jn = () => {
			w(() => {
				if (!V.value || Zt) return;
				let e = document.activeElement;
				P.value?.contains(e) || F.value?.contains(e) || (qn(), Ln());
			});
		}, Yn = {};
		Object.defineProperties(Yn, {
			Element: { get: () => wt.value },
			Name: { get: () => T["data-xaml-ref"] ?? T["x:Name"] ?? T.Name ?? "" },
			IsEnabled: {
				get: () => N.value,
				set: (e) => {
					dt.value = t(e), d(S.IsEnabled, t(e), C);
				}
			},
			Text: {
				get: () => W.value,
				set: xn
			},
			SelectedIndex: {
				get: () => H.value,
				set: (e) => J(Number(e))
			},
			SelectedItem: {
				get: () => U.value,
				set: bn
			},
			SelectedValue: {
				get: () => U.value === void 0 ? void 0 : cn(U.value),
				set: Sn
			},
			IsDropDownOpen: {
				get: () => z.value,
				set: (e) => Mn(t(e))
			},
			Items: { get: () => j.value },
			ItemsSource: { get: () => j.value },
			SelectionBoxItem: { get: () => U.value },
			SelectionBoxItemTemplate: { get: () => A(S.ItemTemplate) },
			Focus: { value: () => (Z(), N.value) }
		});
		let Xn = () => {
			qn(), X(), Ln(!0);
		}, Zn = (e = !0) => {
			V.value && (bn(Yt), xn(Xt)), X(), Ln(e);
		}, Qn = (e) => {
			if (j.value.length === 0) return;
			let t = Math.min(j.value.length - 1, Math.max(0, H.value < 0 ? e > 0 ? 0 : j.value.length - 1 : H.value + e));
			for (; t >= 0 && t < j.value.length && !an(j.value[t]);) t += e;
			t >= 0 && t < j.value.length && J(t);
		}, Q = (e, t = 1) => {
			if (j.value.length === 0) return;
			let n = Math.min(j.value.length - 1, Math.max(0, e));
			for (; n >= 0 && n < j.value.length && !an(j.value[n]);) n += t;
			n < 0 || n >= j.value.length || (R.value = n, u(S.SelectionChangedTrigger, C) === "Always" && J(n), I.value[n]?.focus(), I.value[n]?.scrollIntoView({ block: "nearest" }));
		}, $n = (e) => {
			!N.value || e.defaultPrevented || ar(e) || (e.key === "ArrowDown" && !e.altKey && !z.value ? (e.preventDefault(), Qn(1)) : e.key === "ArrowUp" && !z.value ? (e.preventDefault(), Qn(-1)) : e.key === "Home" || e.key === "End" ? (e.preventDefault(), J(e.key === "Home" ? 0 : j.value.length - 1)) : (e.key === "ArrowDown" || e.key === "F4" || e.key === "Enter" || e.key === " ") && (e.preventDefault(), Nn(), w(() => Q(H.value < 0 ? 0 : H.value))));
		}, er = (e) => {
			!N.value || e.defaultPrevented || (e.key === "Enter" || e.key === "F2" || e.key === " " ? (e.preventDefault(), In()) : e.key === "F4" || e.altKey && e.key === "ArrowDown" ? (e.preventDefault(), Nn(), w(() => Q(H.value < 0 ? 0 : H.value))) : e.key === "ArrowDown" || e.key === "ArrowUp" ? (e.preventDefault(), In(), Nn()) : e.key.length === 1 && !e.ctrlKey && !e.altKey && !e.metaKey && (e.preventDefault(), In(), xn(e.key)));
		}, tr = (e) => {
			if (!(e.defaultPrevented || e.isComposing || !N.value)) if (e.key === "Enter") e.preventDefault(), Xn();
			else if (e.key === "Escape") e.preventDefault(), Zn();
			else if (e.key === "F4" || e.altKey && (e.key === "ArrowDown" || e.key === "ArrowUp")) e.preventDefault(), z.value ? Xn() : Nn();
			else if ((e.key === "ArrowDown" || e.key === "ArrowUp") && !z.value) e.preventDefault(), Nn();
			else if ((e.key === "ArrowDown" || e.key === "ArrowUp") && z.value) {
				e.preventDefault();
				let t = Math.max(0, Math.min(j.value.length - 1, (R.value >= 0 ? R.value : H.value) + (e.key === "ArrowDown" ? 1 : -1)));
				R.value = t, t >= 0 && an(j.value[t]) && (xn(K(j.value[t])), u(S.SelectionChangedTrigger, C) === "Always" && J(t), I.value[t]?.scrollIntoView({ block: "nearest" }));
			} else e.key === "Tab" && (qn(), X(), Ln());
		}, nr = (e) => {
			let t = I.value.indexOf(document.activeElement);
			if (!ar(e)) if (e.altKey && (e.key === "ArrowDown" || e.key === "ArrowUp")) e.preventDefault(), X(), w(Z);
			else if (e.key === "Escape") e.preventDefault(), M.value ? Zn() : (u(S.SelectionChangedTrigger, C) === "Always" && bn(rr), X()), w(Z);
			else if (e.key === "ArrowDown") e.preventDefault(), Q(t < 0 ? 0 : t + 1);
			else if (e.key === "ArrowUp") e.preventDefault(), Q(t < 0 ? j.value.length - 1 : t - 1, -1);
			else if (e.key === "Home") e.preventDefault(), Q(0);
			else if (e.key === "End") e.preventDefault(), Q(j.value.length - 1, -1);
			else if (e.key === "PageDown" || e.key === "PageUp") {
				e.preventDefault();
				let n = e.key === "PageDown" ? 1 : -1, r = Math.max(1, Math.floor((F.value?.clientHeight ?? 252) / 36));
				Q(Math.max(0, t) + n * r, n);
			} else e.key === "Enter" || e.key === " " ? (e.preventDefault(), t >= 0 && zn(t)) : e.key === "F4" || e.altKey && (e.key === "ArrowDown" || e.key === "ArrowUp") ? (e.preventDefault(), X(), w(Z)) : e.key === "Tab" ? (R.value >= 0 && J(R.value), Z(), X()) : (e.key === "ArrowLeft" || e.key === "ArrowRight") && e.preventDefault();
		}, rr, $ = "", ir = 0, ar = (e) => {
			if (!t(u(S.IsTextSearchEnabled, C)) || e.isComposing || e.ctrlKey || e.altKey || e.metaKey || e.key.length !== 1 || e.key === " " && !$) return !1;
			let n = Date.now();
			$ = n - ir > 1e3 ? e.key : $ + e.key, ir = n;
			let r = j.value.findIndex((e) => an(e) && K(e).toLocaleLowerCase().startsWith($.toLocaleLowerCase()));
			if (r < 0 && [...$].every((t) => t.toLocaleLowerCase() === e.key.toLocaleLowerCase())) {
				$ = e.key;
				let t = z.value ? R.value : H.value;
				for (let e = 1; e <= j.value.length; e += 1) {
					let n = (Math.max(-1, t) + e) % j.value.length;
					if (an(j.value[n]) && K(j.value[n]).toLocaleLowerCase().startsWith($.toLocaleLowerCase())) {
						r = n;
						break;
					}
				}
			}
			return r >= 0 && (z.value ? Q(r) : J(r)), e.preventDefault(), !0;
		}, or = (e) => {
			!N.value || z.value || document.activeElement !== P.value || e.deltaY === 0 || (e.preventDefault(), Qn(e.deltaY > 0 ? 1 : -1));
		}, sr = (e, t) => {
			I.value[t] = e;
		}, cr = (e) => {
			qt = e.pointerType === "touch" ? "Touch" : "Mouse";
		}, lr = (e) => {
			qt = "Keyboard", V.value && e.target instanceof Element && e.target.closest(".win-textbox") ? tr(e) : e.key === "Escape" && (z.value || V.value) && (e.preventDefault(), M.value ? Zn() : (u(S.SelectionChangedTrigger, C) === "Always" && bn(rr), X(), w(Z)));
		}, ur = (e) => {
			let t = wt.value?.contains(e.target), n = F.value?.contains(e.target) || z.value && e.target instanceof Element && e.target.closest(".win-combo-flyout-hit-overlay");
			V.value && !t && !n && !Zt && (qn(), Ln()), !(!z.value || t || n) && X();
		};
		O(hn, (e) => {
			_n(e) && vn();
		}, { immediate: !0 }), O(() => j.value.slice(), (e, t) => {
			if ((_n(hn()) || q) && vn(), q) {
				z.value && w(An);
				return;
			}
			let n = U.value;
			if (n !== void 0) {
				let r = e.findIndex((e) => Object.is(e, n));
				if (r < 0) {
					let r = t?.findIndex((e) => Object.is(e, n)), i = ot ? [...it].find(([, e]) => e === r)?.[0] : void 0, a = i === void 0 ? void 0 : rt.get(i);
					a !== void 0 && e[a] !== void 0 ? (mn(a, e[a], vt.value === void 0), yn(n, e[a], a)) : Jt || (mn(-1, void 0, vt.value === void 0), yn(n, void 0, -1));
				} else {
					let e = r !== H.value;
					mn(r, n, vt.value === void 0), e && d(S.SelectedIndex, r, C);
				}
			}
			z.value && w(An);
		}), O(vt, (e) => {
			e !== void 0 && (W.value = String(e));
		}), O(mt, (e) => {
			e !== void 0 && Mn(e);
		}), O(N, (e) => {
			e || (Ln(), X());
		}), O(M, (e) => {
			e || Ln();
		}), Fe(() => {
			Ne.Attach(wt.value), Wt = new ResizeObserver(An), P.value && Wt.observe(P.value), wn(), window.addEventListener("resize", An), window.addEventListener("scroll", jn, !0), document.addEventListener("pointerdown", ur), document.addEventListener("pointermove", Wn, !0), w(() => {
				sn("Loaded");
			});
		}), O(N, Ne.Refresh, { flush: "post" }), Pe(() => {
			Wt?.disconnect(), Gt?.disconnect(), G.cancel(), Ht(), window.removeEventListener("resize", An), window.removeEventListener("scroll", jn, !0), document.removeEventListener("pointerdown", ur), document.removeEventListener("pointermove", Wn, !0), Kt && window.cancelAnimationFrame(Kt);
		}), Ie(p, {
			...Ae(p, {}),
			props: S,
			ComboBoxScrollSettings: Le,
			SelectionBoxPadding: en,
			SelectionBoxOpacity: At,
			currentText: W,
			resolvedIsEnabled: N,
			resolvedPlaceholderText: ut,
			resolvedHeader: st,
			resolvedHeaderTemplate: ct,
			resolvedDescription: lt,
			onEditableTextChanged: Kn,
			onEditableLostFocus: Jn
		}), Te(Yn);
		let dr = {
			ComboBoxPopupMaxNumberOfItems: 15,
			ComboBoxPopupMaxNumberOfItemsThatCanBeShownOnOneSide: 7,
			ComboBoxDropdownContentMargin: b,
			DefaultComboBoxItemHeight: 36,
			t: x,
			props: S,
			instance: C,
			dropDownBackgroundStyle: Me,
			AnimatedGlyphInput: Ne,
			attrs: T,
			rootAttrs: E,
			ComboBoxScrollSettings: Le,
			slots: Re,
			localPrimitiveResources: Ve,
			defaultShadowEnabled: k,
			backgroundBrush: Ge,
			inheritedResources: Ke,
			propertyNodes: qe,
			resourceNodes: Je,
			resources: Ye,
			brushResources: Xe,
			templateValue: A,
			itemTemplateNodes: Ze,
			hasItemTemplate: Qe,
			ItemRenderer: $e,
			InlineItemRenderer: et,
			SelectionBoxRenderer: tt,
			inlineItemContainers: nt,
			get inlineStringKeys() {
				return rt;
			},
			set inlineStringKeys(e) {
				rt = e;
			},
			get previousInlineStringKeys() {
				return it;
			},
			set previousInlineStringKeys(e) {
				it = e;
			},
			inlineItems: at,
			get isUsingInlineItems() {
				return ot;
			},
			set isUsingInlineItems(e) {
				ot = e;
			},
			resolvedItemsSource: j,
			resolvedHeader: st,
			resolvedHeaderTemplate: ct,
			resolvedDescription: lt,
			resolvedPlaceholderText: ut,
			resolvedIsEditable: M,
			localIsEnabled: dt,
			sourceIsEnabled: ft,
			resolvedIsEnabled: N,
			resolvedIsTabStop: pt,
			resolvedIsDropDownOpen: mt,
			resolvedSelectedIndex: ht,
			resolvedSelectedItem: gt,
			resolvedSelectedValue: _t,
			resolvedText: vt,
			resolvedWidth: yt,
			resolvedMinWidth: bt,
			resolvedMaxWidth: xt,
			resolvedMaxDropDownHeight: St,
			emit: Ct,
			comboRef: wt,
			backgroundRef: P,
			inputRef: Tt,
			TextBox: Et,
			flyoutRef: F,
			scrollViewerRef: Dt,
			itemsPresenterRef: Ot,
			itemRefs: I,
			hoveredIndex: L,
			focusedIndex: R,
			visualSelectedIndex: kt,
			isOpen: z,
			SelectionBoxOpacity: At,
			isClosing: B,
			popupVisible: jt,
			isEditing: V,
			flyoutReady: Mt,
			openedUp: Nt,
			flyoutStyle: Pt,
			inputDeviceTypeUsedToOpen: Ft,
			isOverlayVisible: It,
			currentSelectedIndex: H,
			currentSelectedItem: U,
			currentText: W,
			anchorTheme: Lt,
			inheritedTheme: Rt,
			listBoxId: zt,
			flyoutAnimation: G,
			isFlyoutAnimating: Bt,
			get opacityAnimations() {
				return Vt;
			},
			set opacityAnimations(e) {
				Vt = e;
			},
			cancelOpacityAnimations: Ht,
			playOpacityAnimations: Ut,
			get resizeObserver() {
				return Wt;
			},
			set resizeObserver(e) {
				Wt = e;
			},
			get themeObserver() {
				return Gt;
			},
			set themeObserver(e) {
				Gt = e;
			},
			get positionFrame() {
				return Kt;
			},
			set positionFrame(e) {
				Kt = e;
			},
			get lastInputDeviceType() {
				return qt;
			},
			set lastInputDeviceType(e) {
				qt = e;
			},
			get isCustomSelection() {
				return Jt;
			},
			set isCustomSelection(e) {
				Jt = e;
			},
			get editingRestoreItem() {
				return Yt;
			},
			set editingRestoreItem(e) {
				Yt = e;
			},
			get editingRestoreText() {
				return Xt;
			},
			set editingRestoreText(e) {
				Xt = e;
			},
			get submittingText() {
				return Zt;
			},
			set submittingText(e) {
				Zt = e;
			},
			cssLength: Qt,
			rootStyle: $t,
			SelectionBoxPadding: en,
			selectionBoxStyle: tn,
			themeClass: nn,
			GetPathValue: rn,
			GetItemLabel: K,
			IsItemEnabled: an,
			itemContainerStyle: on,
			raiseEvent: sn,
			GetItemValue: cn,
			getItemKey: ln,
			FindItemIndex: un,
			FindValueIndex: dn,
			selectedLabel: fn,
			editableDisplayLabel: pn,
			SetCurrentSelection: mn,
			GetSelectionProperties: hn,
			get lastSelectionProperties() {
				return gn;
			},
			set lastSelectionProperties(e) {
				gn = e;
			},
			get pendingSelectionFromProperties() {
				return q;
			},
			set pendingSelectionFromProperties(e) {
				q = e;
			},
			HaveSelectionPropertiesChanged: _n,
			SyncSelectionFromProperties: vn,
			RaiseSelectionChanged: yn,
			SetSelectedIndex: J,
			SetSelectedItem: bn,
			SetText: xn,
			SetSelectedValue: Sn,
			ResolveAnchorTheme: Cn,
			ObserveAnchorTheme: wn,
			GetItemLayoutHeight: Y,
			GetNonPannablePopupLayout: Tn,
			GetEditableComboBoxPopupLayout: En,
			GetPannablePopupLayout: Dn,
			UpdateIsPopupPannable: On,
			positionFlyout: kn,
			schedulePositionFlyout: An,
			onWindowScroll: jn,
			setOpen: Mn,
			open: Nn,
			close: X,
			toggle: Pn,
			focusCombo: Z,
			focusEditableText: Fn,
			beginEditing: In,
			endEditing: Ln,
			toggleEditableDropDown: Rn,
			select: zn,
			itemIndexAtPoint: Bn,
			onFlyoutPointerMove: Vn,
			onFlyoutPointerLeave: Hn,
			onFlyoutPointerDown: Un,
			onDocumentPointerMove: Wn,
			onFlyoutClick: Gn,
			onEditableTextChanged: Kn,
			commitEditableText: qn,
			onEditableLostFocus: Jn,
			controlSender: Yn,
			SubmitText: Xn,
			CancelEditableText: Zn,
			MoveSelection: Qn,
			FocusItem: Q,
			onButtonKeyDown: $n,
			onEditableDisplayKeyDown: er,
			onEditableKeyDown: tr,
			onFlyoutKeyDown: nr,
			get openingSelectedItem() {
				return rr;
			},
			set openingSelectedItem(e) {
				rr = e;
			},
			get searchText() {
				return $;
			},
			set searchText(e) {
				$ = e;
			},
			get searchTimestamp() {
				return ir;
			},
			set searchTimestamp(e) {
				ir = e;
			},
			ProcessTextSearch: ar,
			onPointerWheelChanged: or,
			setItemRef: sr,
			onPointerDown: cr,
			onInputKeyDown: lr,
			onDocumentPointerDown: ur,
			get CollectionItemTemplate() {
				return oe;
			},
			get CollectionItems() {
				return se;
			},
			get CollectionResources() {
				return ce;
			},
			get CollectionItemContainerStyle() {
				return ae;
			},
			get ComboBoxHeader() {
				return be;
			},
			get ComboBoxHeaderTemplate() {
				return xe;
			},
			get ComboBoxDescription() {
				return ye;
			},
			computed: y,
			defineComponent: De,
			Fragment: we,
			getCurrentInstance: Oe,
			h: ke,
			inject: Ae,
			isVNode: je,
			nextTick: w,
			onBeforeUnmount: Pe,
			onMounted: Fe,
			provide: Ie,
			ref: D,
			shallowReactive: ze,
			shallowRef: Be,
			unref: He,
			useAttrs: Ue,
			useSlots: We,
			watch: O,
			get useI18n() {
				return re;
			},
			ScrollViewer: pe,
			get getCollectionProperty() {
				return le;
			},
			get getVNodeChildren() {
				return ue;
			},
			xamlResourceDictionaryKey: ie,
			get normalizeXamlNodes() {
				return c;
			},
			get resolveXamlHandler() {
				return l;
			},
			get resolveXamlValue() {
				return u;
			},
			get updateXamlBinding() {
				return d;
			},
			get xamlItemContextKey() {
				return f;
			},
			get xamlScopeKey() {
				return p;
			},
			get xamlTemplateComponent() {
				return m;
			},
			get scrollViewerTemplateBindings() {
				return me;
			},
			TextBlock: de,
			TextBoxControl: ge,
			ContentPresenter: he,
			get boolValue() {
				return t;
			},
			get xamlThickness() {
				return n;
			},
			get alignment() {
				return e;
			},
			get getComboBoxProperty() {
				return Se;
			},
			get isComboBoxProperty() {
				return Ce;
			},
			get collectXamlResources() {
				return h;
			},
			get useXamlBrushResources() {
				return g;
			},
			get useBrushProperty() {
				return v;
			},
			get isBrushProperty() {
				return _;
			},
			get useFlyoutAnimation() {
				return ve;
			},
			AnimatedIcon: fe,
			get useAnimatedIconInput() {
				return _e;
			},
			get colorString() {
				return r;
			},
			get createSolidColorBrush() {
				return i;
			},
			get xamlThemeKey() {
				return a;
			},
			get useAcrylicBrushStyle() {
				return s;
			},
			get vAcrylicBrush() {
				return ee;
			},
			get vThemeShadow() {
				return te;
			},
			get primitiveResourceScope() {
				return o;
			}
		};
		return Object.defineProperty(dr, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), dr;
	}
}), Je = ["aria-disabled"], Ye = {
	key: 0,
	class: "win-combo-background",
	"aria-hidden": "true"
}, Xe = [
	"aria-expanded",
	"aria-label",
	"disabled",
	"tabindex"
], A = ["aria-label", "disabled"], Ze = [
	"aria-expanded",
	"aria-label",
	"disabled",
	"tabindex"
], Qe = {
	ref: "itemsPresenterRef",
	class: "win-combo-items-presenter"
}, $e = [
	"aria-selected",
	"disabled",
	"tabindex",
	"onClick"
], et = { class: "win-combo-item-layout" }, tt = {
	key: 0,
	class: "win-combo-item-pill",
	width: "3",
	height: "16",
	viewBox: "0 0 3 16",
	"aria-hidden": "true",
	focusable: "false"
};
function nt(e, t, n, r, i, a) {
	let o = Re("animatedvisuals:AnimatedChevronDownSmallVisualSource"), s = Re("FontIconSource");
	return E(), x("div", Me({ ref: "comboRef" }, r.rootAttrs, {
		class: ["win-combo-box win-theme-scope", [
			r.attrs.class,
			r.themeClass,
			{
				"is-disabled": !r.resolvedIsEnabled,
				"is-drop-down-open": r.isOpen,
				"is-editable": r.resolvedIsEditable
			}
		]],
		style: r.rootStyle,
		"aria-disabled": !r.resolvedIsEnabled,
		onKeydownCapture: r.onInputKeyDown,
		onPointerdownCapture: r.onPointerDown,
		onPointerenter: t[2] ||= (...e) => r.AnimatedGlyphInput.PointerEntered && r.AnimatedGlyphInput.PointerEntered(...e),
		onPointerleave: t[3] ||= (...e) => r.AnimatedGlyphInput.PointerExited && r.AnimatedGlyphInput.PointerExited(...e),
		onPointerdown: t[4] ||= (...e) => r.AnimatedGlyphInput.PointerPressed && r.AnimatedGlyphInput.PointerPressed(...e),
		onPointerup: t[5] ||= (...e) => r.AnimatedGlyphInput.PointerReleased && r.AnimatedGlyphInput.PointerReleased(...e),
		onPointercancel: t[6] ||= (...e) => r.AnimatedGlyphInput.PointerExited && r.AnimatedGlyphInput.PointerExited(...e),
		onLostpointercapture: t[7] ||= (...e) => r.AnimatedGlyphInput.PointerReleased && r.AnimatedGlyphInput.PointerReleased(...e),
		onKeydown: t[8] ||= (...e) => r.AnimatedGlyphInput.KeyDown && r.AnimatedGlyphInput.KeyDown(...e),
		onKeyup: t[9] ||= (...e) => r.AnimatedGlyphInput.KeyUp && r.AnimatedGlyphInput.KeyUp(...e),
		onFocusout: t[10] ||= (...e) => r.AnimatedGlyphInput.LostFocus && r.AnimatedGlyphInput.LostFocus(...e)
	}), [
		r.resolvedHeader ? (E(), Ee(r.ContentPresenter, {
			key: 0,
			"x:Name": "HeaderContentPresenter",
			class: "win-combo-header",
			Content: "{x:Bind resolvedHeader, Mode=OneWay}",
			ContentTemplate: "{x:Bind resolvedHeaderTemplate, Mode=OneWay}",
			Margin: "{ThemeResource ComboBoxTopHeaderMargin}",
			Foreground: "{ThemeResource ComboBoxHeaderForeground}",
			VerticalAlignment: "Top"
		})) : b("", !0),
		r.resolvedIsEditable ? (E(), x("div", {
			key: 1,
			ref: "backgroundRef",
			class: Ne(["win-combo-editable", { "is-editing": r.isEditing }])
		}, [
			r.isEditing ? (E(), x("span", Ye)) : b("", !0),
			r.isEditing ? (E(), Ee(r.TextBox, {
				key: 2,
				ref: "inputRef",
				class: "win-combo-textbox",
				role: "combobox",
				"aria-controls": r.listBoxId,
				"aria-expanded": r.isOpen,
				"aria-label": r.resolvedHeader || r.resolvedPlaceholderText,
				"x:Name": "EditableText",
				IsEnabled: "{x:Bind resolvedIsEnabled, Mode=OneWay}",
				Padding: "{ThemeResource ComboBoxEditableTextPadding}",
				PlaceholderText: "{x:Bind resolvedPlaceholderText, Mode=OneWay}",
				ShowDeleteButton: "False",
				Text: "{x:Bind currentText, Mode=TwoWay}",
				LostFocus: "onEditableLostFocus",
				TextChanged: "onEditableTextChanged"
			}, null, 8, ["aria-expanded", "aria-label"])) : (E(), x("button", {
				key: 1,
				class: "win-combo-btn win-combo-edit-display",
				type: "button",
				role: "combobox",
				"aria-controls": r.listBoxId,
				"aria-expanded": r.isOpen,
				"aria-label": r.resolvedHeader || r.resolvedPlaceholderText,
				disabled: !r.resolvedIsEnabled,
				tabindex: r.resolvedIsTabStop ? void 0 : -1,
				onClick: r.beginEditing,
				onKeydown: r.onEditableDisplayKeyDown
			}, [t[11] ||= S("span", {
				class: "win-combo-background",
				"aria-hidden": "true"
			}, null, -1), S("span", {
				class: Ne(["win-combo-content", { "is-placeholder": !r.currentText && r.currentSelectedItem === void 0 }]),
				style: T(r.selectionBoxStyle)
			}, Ve(r.editableDisplayLabel), 7)], 40, Xe)),
			S("button", {
				class: "win-combo-drop-down-button",
				type: "button",
				tabindex: "-1",
				"aria-label": r.t("text.select"),
				disabled: !r.resolvedIsEnabled,
				onClick: r.toggleEditableDropDown,
				onPointerdown: t[0] ||= Ke(() => {}, ["prevent"])
			}, null, 40, A),
			C(r.AnimatedIcon, {
				class: "win-combo-chevron",
				"x:Name": "DropDownGlyph",
				Width: "12",
				Height: "12",
				Margin: "0,0,14,0",
				HorizontalAlignment: "Right",
				VerticalAlignment: "Center",
				Foreground: "{ThemeResource ComboBoxDropDownGlyphForeground}",
				IsHitTestVisible: "False",
				"AutomationProperties.AccessibilityView": "Raw"
			}, {
				default: k(() => [C(r.AnimatedIcon.Source, null, {
					default: k(() => [C(o)]),
					_: 1
				}), C(r.AnimatedIcon.FallbackIconSource, null, {
					default: k(() => [C(s, {
						Foreground: "{ThemeResource ComboBoxDropDownGlyphForeground}",
						FontFamily: "{ThemeResource SymbolThemeFontFamily}",
						FontSize: "12",
						Glyph: ""
					})]),
					_: 1
				})]),
				_: 1
			})
		], 2)) : (E(), x("button", {
			key: 2,
			ref: "backgroundRef",
			class: "win-combo-btn",
			type: "button",
			role: "combobox",
			"aria-controls": r.listBoxId,
			"aria-expanded": r.isOpen,
			"aria-label": r.resolvedHeader || r.resolvedPlaceholderText,
			disabled: !r.resolvedIsEnabled,
			tabindex: r.resolvedIsTabStop ? void 0 : -1,
			onClick: r.toggle,
			onKeydown: r.onButtonKeyDown,
			onWheel: r.onPointerWheelChanged
		}, [
			t[12] ||= S("span", {
				class: "win-combo-background",
				"aria-hidden": "true"
			}, null, -1),
			C(r.ContentPresenter, {
				"x:Name": "ContentPresenter",
				class: Ne(["win-combo-content", { "is-placeholder": r.currentSelectedIndex < 0 && r.currentSelectedItem === void 0 }]),
				Margin: "{x:Bind SelectionBoxPadding, Mode=OneWay}",
				Opacity: "{x:Bind SelectionBoxOpacity, Mode=OneWay}",
				HorizontalAlignment: "{x:Bind props.HorizontalContentAlignment, Mode=OneWay}",
				VerticalAlignment: "{x:Bind props.VerticalContentAlignment, Mode=OneWay}"
			}, {
				default: k(() => [C(r.SelectionBoxRenderer)]),
				_: 1
			}, 8, ["class"]),
			t[13] ||= S("span", {
				class: "win-combo-focus-pill",
				"aria-hidden": "true"
			}, null, -1),
			C(r.AnimatedIcon, {
				class: "win-combo-chevron",
				"x:Name": "DropDownGlyph",
				Width: "12",
				Height: "12",
				Margin: "0,0,14,0",
				HorizontalAlignment: "Right",
				VerticalAlignment: "Center",
				Foreground: "{ThemeResource ComboBoxDropDownGlyphForeground}",
				IsHitTestVisible: "False",
				"AutomationProperties.AccessibilityView": "Raw"
			}, {
				default: k(() => [C(r.AnimatedIcon.Source, null, {
					default: k(() => [C(o)]),
					_: 1
				}), C(r.AnimatedIcon.FallbackIconSource, null, {
					default: k(() => [C(s, {
						Foreground: "{ThemeResource ComboBoxDropDownGlyphForeground}",
						FontFamily: "{ThemeResource SymbolThemeFontFamily}",
						FontSize: "12",
						Glyph: ""
					})]),
					_: 1
				})]),
				_: 1
			})
		], 40, Ze)),
		r.resolvedDescription ? (E(), Ee(r.ContentPresenter, {
			key: 3,
			"x:Name": "DescriptionPresenter",
			class: "win-combo-description",
			Content: "{x:Bind resolvedDescription, Mode=OneWay}"
		})) : b("", !0),
		(E(), Ee(Te, { to: "body" }, [
			r.isOpen ? (E(), x("div", {
				key: 0,
				class: Ne(["win-combo-overlay", [r.themeClass, { "is-visible": r.isOverlayVisible }]]),
				onContextmenu: Ke(r.close, ["prevent"]),
				onPointerdown: r.close
			}, null, 34)) : b("", !0),
			r.popupVisible ? Ge((E(), x("div", {
				key: 1,
				id: r.listBoxId,
				ref: "flyoutRef",
				class: Ne(["win-combo-flyout win-theme-scope", [r.themeClass, {
					"is-positioned": r.flyoutReady,
					"is-closing": r.isClosing,
					"opens-up": r.openedUp,
					"touch-input": r.inputDeviceTypeUsedToOpen === "Touch",
					"edge-square-top": r.resolvedIsEditable && !r.openedUp,
					"edge-square-bottom": r.resolvedIsEditable && r.openedUp
				}]]),
				style: T([r.flyoutStyle, r.dropDownBackgroundStyle]),
				role: "listbox",
				onKeydown: r.onFlyoutKeyDown,
				onPointerdown: Ke(r.onFlyoutPointerDown, ["stop"]),
				onPointerleave: r.onFlyoutPointerLeave
			}, [S("div", {
				class: "win-combo-flyout-hit-root",
				onPointermove: r.onFlyoutPointerMove,
				onClick: r.onFlyoutClick
			}, [C(r.ScrollViewer, {
				ref: "scrollViewerRef",
				class: "win-combo-scroll-viewer",
				HorizontalScrollMode: "{x:Bind ComboBoxScrollSettings.HorizontalScrollMode, Mode=OneWay}",
				HorizontalScrollBarVisibility: "{x:Bind ComboBoxScrollSettings.HorizontalScrollBarVisibility, Mode=OneWay}",
				VerticalScrollMode: "{x:Bind ComboBoxScrollSettings.VerticalScrollMode, Mode=OneWay}",
				VerticalScrollBarVisibility: "{x:Bind ComboBoxScrollSettings.VerticalScrollBarVisibility, Mode=OneWay}",
				IsHorizontalRailEnabled: "{x:Bind ComboBoxScrollSettings.IsHorizontalRailEnabled, Mode=OneWay}",
				IsVerticalRailEnabled: "{x:Bind ComboBoxScrollSettings.IsVerticalRailEnabled, Mode=OneWay}",
				IsDeferredScrollingEnabled: "{x:Bind ComboBoxScrollSettings.IsDeferredScrollingEnabled, Mode=OneWay}",
				ZoomMode: "Disabled",
				IsVerticalScrollChainingEnabled: "False",
				IsTabStop: "False"
			}, {
				default: k(() => [S("div", Qe, [(E(!0), x(we, null, Le(r.resolvedItemsSource, (e, n) => (E(), x("button", {
					key: r.getItemKey(e, n),
					ref_for: !0,
					ref: (e) => r.setItemRef(e, n),
					class: Ne(["win-combo-item", {
						selected: r.visualSelectedIndex === n,
						hovered: r.isFlyoutAnimating && r.hoveredIndex === n,
						"is-disabled": !r.IsItemEnabled(e)
					}]),
					type: "button",
					role: "option",
					"aria-selected": r.currentSelectedIndex === n,
					disabled: !r.IsItemEnabled(e),
					style: T(r.itemContainerStyle(e)),
					tabindex: r.currentSelectedIndex === n ? 0 : -1,
					onClick: (e) => r.select(n)
				}, [S("span", et, [r.visualSelectedIndex === n ? (E(), x("svg", tt, [...t[14] ||= [S("rect", {
					width: "3",
					height: "16",
					rx: "1.5",
					fill: "currentColor"
				}, null, -1)]])) : b("", !0), C(r.ContentPresenter, {
					class: "win-combo-item-content",
					Margin: "{ThemeResource ComboBoxItemThemePadding}",
					HorizontalAlignment: "Stretch",
					VerticalAlignment: "Top"
				}, {
					default: k(() => [r.hasItemTemplate ? (E(), Ee(r.ItemRenderer, {
						key: 0,
						item: e,
						index: n
					}, null, 8, ["item", "index"])) : (E(), Ee(r.InlineItemRenderer, {
						key: 1,
						item: e
					}, null, 8, ["item"]))]),
					_: 2
				}, 1024)])], 14, $e))), 128))], 512)]),
				_: 1
			}, 512)], 32)], 38)), [[
				r.vAcrylicBrush,
				r.dropDownBackgroundStyle,
				void 0,
				{ "host-backdrop": !0 }
			], [r.vThemeShadow, {
				Translation: 32,
				Enabled: r.defaultShadowEnabled
			}]]) : b("", !0),
			r.isOpen && r.isFlyoutAnimating ? (E(), x("div", {
				key: 2,
				class: "win-combo-flyout-hit-overlay",
				style: T(r.flyoutStyle),
				onPointerdown: t[1] ||= Ke(() => {}, ["stop"]),
				onPointermove: r.onFlyoutPointerMove,
				onPointerleave: r.onFlyoutPointerLeave,
				onClick: r.onFlyoutClick
			}, null, 36)) : b("", !0)
		]))
	], 16, Je);
}
var rt = /*#__PURE__*/ ne(qe, [["render", nt], ["__file", "ComboBox.vue"]]);
//#endregion
export { rt as default };

//# sourceMappingURL=ComboBox.vue.js.map