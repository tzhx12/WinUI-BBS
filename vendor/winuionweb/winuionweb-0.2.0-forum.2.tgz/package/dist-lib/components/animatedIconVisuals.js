import e from "./animatedIconVisualData.json.js";
import { defineComponent as t } from "vue";
//#region src/components/animatedIconVisuals.ts
var n = [
	"AnimatedAcceptVisualSource",
	"AnimatedBackVisualSource",
	"AnimatedChevronDownSmallVisualSource",
	"AnimatedChevronRightDownSmallVisualSource",
	"AnimatedChevronUpDownSmallVisualSource",
	"AnimatedFindVisualSource",
	"AnimatedGlobalNavigationButtonVisualSource",
	"AnimatedSettingsVisualSource"
], r = /* @__PURE__ */ new Map(), i = {
	Offset: [0, 0],
	CenterPoint: [0, 0],
	Scale: [1, 1],
	Opacity: 1,
	RotationAngle: 0,
	RotationAngleInDegrees: 0,
	IsVisible: !0,
	StrokeThickness: 1,
	StrokeMiterLimit: 10,
	TrimStart: 0,
	TrimEnd: 1,
	TrimOffset: 0
}, a = (e) => Math.max(0, Math.min(1, e)), o = (e, t = 0) => typeof e == "number" ? e : t, s = (e, t) => Array.isArray(e) ? e.map((e) => o(e)) : t, c = (e) => Number(e.toFixed(7)), l = (e) => e.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
function u(e, t, n) {
	return Array.isArray(e) ? e.map((e, r) => u(e, Array.isArray(t) ? t[r] : t, n)) : Array.isArray(t) ? t.map((t) => u(e, t, n)) : n(e, t);
}
function d(e) {
	let t = r.get(e);
	if (t !== void 0) return t;
	let n = e.match(/(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?|[A-Za-z_]\w*(?:\.\w+)*|[()+*\/,\-]/g) ?? [];
	if (n.join("") !== e.replace(/\s/g, "")) throw Error(`Unsupported official animation expression: ${e}`);
	let i = 0, a = () => {
		let t = n[i++];
		if (t === void 0) throw Error(`Incomplete official animation expression: ${e}`);
		if (t === "-") return {
			operator: "-",
			left: 0,
			right: a()
		};
		if (t === "(") {
			let t = s();
			if (n[i++] !== ")") throw Error(`Invalid official animation expression: ${e}`);
			return t;
		}
		if (/^(?:\d|\.)/.test(t)) return Number(t);
		if (n[i] !== "(") return { variable: t };
		i++;
		let r = [];
		if (n[i] !== ")") do {
			if (r.push(s()), n[i] !== ",") break;
			i++;
		} while (i < n.length);
		if (n[i++] !== ")") throw Error(`Invalid official animation function: ${e}`);
		return {
			call: t,
			args: r
		};
	}, o = () => {
		let e = a();
		for (; n[i] === "*" || n[i] === "/";) e = {
			operator: n[i++],
			left: e,
			right: a()
		};
		return e;
	}, s = () => {
		let e = o();
		for (; n[i] === "+" || n[i] === "-";) e = {
			operator: n[i++],
			left: e,
			right: o()
		};
		return e;
	}, c = s();
	if (i !== n.length) throw Error(`Unsupported official animation expression: ${e}`);
	return r.set(e, c), c;
}
function f(e, t) {
	if (typeof e == "number") return e;
	if ("variable" in e) return t(e.variable);
	if ("operator" in e) {
		let n = f(e.left, t), r = f(e.right, t);
		switch (e.operator) {
			case "+": return u(n, r, (e, t) => e + t);
			case "-": return u(n, r, (e, t) => e - t);
			case "*": return u(n, r, (e, t) => e * t);
			case "/": return u(n, r, (e, t) => e / t);
		}
	}
	if ("call" in e) {
		let n = e.args.map((e) => f(e, t));
		if (/^Vector[234]$/.test(e.call)) return n;
		if (e.call === "Pow") return u(n[0], n[1], Math.pow);
		if (e.call === "Square") return u(n[0], n[0], (e, t) => e * t);
		if (e.call === "Min") return u(n[0], n[1], Math.min);
		if (e.call === "Max") return u(n[0], n[1], Math.max);
		if (e.call === "Lerp") return u(n[0], u(u(n[1], n[0], (e, t) => e - t), n[2], (e, t) => e * t), (e, t) => e + t);
		throw Error(`Unsupported official animation function: ${e.call}`);
	}
	throw Error("Invalid official animation expression");
}
function p(e, t) {
	let [n, r, i, a] = t, o = (e, t, n) => 3 * (1 - e) ** 2 * e * t + 3 * (1 - e) * e ** 2 * n + e ** 3, s = 0, c = 1;
	for (let t = 0; t < 30; t++) {
		let t = (s + c) / 2;
		o(t, n, i) < e ? s = t : c = t;
	}
	return o((s + c) / 2, r, a);
}
function m(e, t) {
	let n = /* @__PURE__ */ new Map(), r = /* @__PURE__ */ new Set(), s = e.records, c = (a, o) => {
		let c = `${a.ref}:${o}`, l = n.get(c);
		if (l !== void 0) return l;
		if (r.has(c)) throw Error(`Circular official animation property: ${c}`);
		r.add(c);
		let u = s[a.ref], d = o === "Progress" && a.ref === e.root.ref ? t : u.props?.[o] ?? i[o] ?? 0, f = u.animations?.[o];
		f && (d = h(f, d));
		let p = {
			X: 0,
			Y: 1,
			Z: 2,
			W: 3
		};
		if (Array.isArray(d)) {
			d = [...d];
			for (let [e, t] of Object.entries(p)) {
				let n = u.animations?.[`${o}.${e}`];
				n && (d[t] = h(n, d[t] ?? 0));
			}
		}
		return r.delete(c), n.set(c, d), d;
	}, l = (t, n) => f(d(t), (t) => {
		let [r, i, a] = t.split("."), s = c(n.references?.[r] ?? e.root, i);
		return a ? o(Array.isArray(s) ? s[{
			X: 0,
			Y: 1,
			Z: 2,
			W: 3
		}[a] ?? 0] : s) : s;
	}), m = (e, t) => e.expression === void 0 ? e.value : l(e.expression, t), h = (e, n) => {
		let r = s[e.ref], i = r.frames ?? [];
		if (r.type === "BooleanKeyFrameAnimation") {
			let e = n;
			for (let n of i) t >= n.at && (e = m(n, r));
			return e;
		}
		let o = {
			at: 0,
			value: n
		};
		for (let e of i) {
			if (t >= e.at) {
				o = e;
				continue;
			}
			let n = m(o, r), i = m(e, r), c = a((t - o.at) / (e.at - o.at));
			if (e.easing) {
				let t = s[e.easing.ref];
				if (t.type === "CubicBezierEasingFunction") c = p(c, t.points);
				else if (t.type === "StepEasingFunction") c = t.props?.IsInitialStepSingleFrame ? +(c > 0) : +(c >= 1);
				else throw Error(`Unsupported official easing: ${t.type}`);
			}
			return u(n, i, (e, t) => e + (t - e) * c);
		}
		return m(o, r);
	};
	return {
		property: c,
		records: s
	};
}
function h(e, t) {
	return [
		e[0] * t[0] + e[2] * t[1],
		e[1] * t[0] + e[3] * t[1],
		e[0] * t[2] + e[2] * t[3],
		e[1] * t[2] + e[3] * t[3],
		e[0] * t[4] + e[2] * t[5] + e[4],
		e[1] * t[4] + e[3] * t[5] + e[5]
	];
}
function g(e, t, n) {
	let { property: r, records: i } = m(e, a(t)), u = l(n), d = (e) => {
		let t = s(r(e, "CenterPoint"), [0, 0]), n = s(r(e, "Offset"), [0, 0]), a = s(r(e, "Scale"), [1, 1]), l = i[e.ref], u = l.props?.RotationAngleInDegrees !== void 0 || l.animations?.RotationAngleInDegrees !== void 0 ? o(r(e, "RotationAngleInDegrees")) * Math.PI / 180 : o(r(e, "RotationAngle")), d = Math.cos(u), f = Math.sin(u), p = t[0], m = t[1], g = [
			d * a[0],
			f * a[0],
			-f * a[1],
			d * a[1],
			0,
			0
		];
		g[4] = n[0] + p - g[0] * p - g[2] * m, g[5] = n[1] + m - g[1] * p - g[3] * m;
		let _ = l.props?.TransformMatrix;
		if (Array.isArray(_)) {
			let e = s(_, []), t = e.length === 16 ? [
				e[0],
				e[1],
				e[4],
				e[5],
				e[12],
				e[13]
			] : e;
			g = h(g, t);
		}
		return `matrix(${g.map(c).join(" ")})`;
	}, f = (e, t) => {
		let n = i[e.ref];
		if (n.type === "PathGeometry") return f(n.geometry, t);
		if (n.type === "Geometry") return `<path d="${n.commands.map((e) => e.map((e) => typeof e == "number" ? c(e) : e).join(" ")).join(" ")}" fill-rule="${n.fillRule}" ${t}/>`;
		if (n.type === "EllipseGeometry") {
			let n = s(r(e, "Radius"), [0, 0]), i = s(r(e, "Center"), [0, 0]);
			return `<ellipse cx="${c(i[0])}" cy="${c(i[1])}" rx="${c(n[0])}" ry="${c(n[1])}" ${t}/>`;
		}
		if (n.type === "RectangleGeometry" || n.type === "RoundedRectangleGeometry") {
			let n = s(r(e, "Offset"), [0, 0]), i = s(r(e, "Size"), [0, 0]), a = s(r(e, "CornerRadius"), [0, 0]);
			return `<rect x="${c(n[0])}" y="${c(n[1])}" width="${c(i[0])}" height="${c(i[1])}" rx="${c(a[0])}" ry="${c(a[1])}" ${t}/>`;
		}
		throw Error(`Unsupported official animation geometry: ${n.type}`);
	}, p = (t) => {
		let n = i[t.ref];
		if (r(t, "IsVisible") === !1) return "";
		let l = o(r(t, "Opacity"), 1);
		if (l <= 0) return "";
		let m = `transform="${d(t)}"${l === 1 ? "" : ` opacity="${c(l)}"`}`;
		if (n.type === "SpriteShape") {
			let e = n.geometry, i = n.props?.FillBrush ? u : "none", s = n.props?.StrokeBrush ? u : "none", l = o(r(t, "StrokeThickness"), 1), d = {
				Round: "round",
				Square: "square",
				Flat: "butt"
			}[String(n.props?.StrokeStartCap)] ?? "butt", p = {
				Round: "round",
				Bevel: "bevel",
				Miter: "miter"
			}[String(n.props?.StrokeLineJoin)] ?? "miter", h = o(r(t, "StrokeMiterLimit"), 1), g = o(r(e, "TrimStart")), _ = o(r(e, "TrimEnd"), 1), v = o(r(e, "TrimOffset")), y = g !== 0 || _ !== 1 || v !== 0, b = a(_ - g);
			if (y && b === 0 && i === "none") return "";
			let x = y ? ` pathLength="1" stroke-dasharray="${c(b)} ${c(2 - b)}" stroke-dashoffset="${c(-g - v)}"` : "";
			return f(e, `${m} fill="${i}" stroke="${s}" stroke-width="${c(l)}" stroke-linecap="${d}" stroke-linejoin="${p}" stroke-miterlimit="${c(h)}"${x}`);
		}
		let h = (n.children ?? []).map(p).join("");
		if (n.props?.Clip && n.props?.Size) {
			let n = s(r(t, "Size"), e.size);
			return `<g ${m}><svg width="${c(n[0])}" height="${c(n[1])}" viewBox="0 0 ${c(n[0])} ${c(n[1])}" overflow="hidden">${h}</svg></g>`;
		}
		return `<g ${m}>${h}</g>`;
	};
	return p(e.root);
}
var _ = e;
function v(e) {
	if (!Object.prototype.hasOwnProperty.call(_, e)) return;
	let t = e, n = _[t], r = {
		name: t,
		duration: n.duration,
		size: {
			width: n.size[0],
			height: n.size[1]
		},
		markers: Object.freeze({ ...n.markers }),
		render: (e, t) => g(n, e, t ?? r.Foreground ?? "currentColor"),
		FrameCount: () => n.frameCount,
		Framerate: () => n.framerate,
		FrameToProgress: (e) => e / n.frameCount,
		SetColorProperty: (e, t) => {
			e === "Foreground" && (r.Foreground = t);
		}
	};
	return r;
}
var y = v, b = Object.fromEntries(n.map((e) => [e, Object.assign(t({
	name: e,
	setup: () => () => null
}), { __animatedVisualSourceName: e })]));
//#endregion
export { b as animatedIconVisualSourceComponents, v as createAnimatedIconSource, y as getAnimatedIconVisualSource };

//# sourceMappingURL=animatedIconVisuals.js.map