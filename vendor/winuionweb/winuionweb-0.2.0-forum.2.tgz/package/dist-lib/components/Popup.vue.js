import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./Popup.vue_vue_type_script_setup_true_lang.js";
/* empty css                                          */
import { Fragment as n, Teleport as r, createBlock as i, createCommentVNode as a, createElementBlock as o, createElementVNode as s, createVNode as c, mergeProps as l, normalizeClass as u, normalizeStyle as d, openBlock as f, vShow as p, withDirectives as m, withModifiers as h } from "vue";
//#region src/components/Popup.vue
var g = [
	"inert",
	"aria-hidden",
	"dir"
], _ = {
	ref: "shadowHostRef",
	class: "win-popup-shadow-host",
	"aria-hidden": "true"
};
function v(e, t, v, y, b, x) {
	return f(), o(n, null, [s("span", l({
		ref: "originRef",
		class: "win-popup-origin"
	}, y.originAttributes, { "aria-hidden": "true" }), null, 16), (f(), i(r, { to: "body" }, [y.isOpen && y.lightDismiss ? (f(), o("div", {
		key: 0,
		class: u(["win-popup-overlay", [y.themeClass, { "is-visible": y.overlayMode === "On" }]]),
		style: d(y.overlayStyle),
		"aria-hidden": "true",
		onPointerdown: h(y.DismissPopup, ["prevent", "stop"])
	}, null, 38)) : a("", !0), m(s("div", {
		ref: "popupRef",
		class: u([y.isOpen ? "win-popup-root" : "win-popup-child-storage", y.themeClass]),
		style: d(y.popupStyle),
		inert: y.isOpen ? void 0 : !0,
		"aria-hidden": y.isOpen ? void 0 : "true",
		dir: y.flowDirection === "RightToLeft" ? "rtl" : void 0,
		tabindex: "-1"
	}, [s("div", _, null, 512), c(y.ChildOutlet)], 14, g), [[p, y.isOpen]])]))], 64);
}
var y = /*#__PURE__*/ e(t, [["render", v], ["__file", "Popup.vue"]]);
//#endregion
export { y as default };

//# sourceMappingURL=Popup.vue.js.map