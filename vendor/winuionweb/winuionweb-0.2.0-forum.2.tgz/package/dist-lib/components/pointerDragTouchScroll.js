//#region src/components/pointerDragTouchScroll.ts
var e = (e) => {
	let t = null;
	e instanceof HTMLElement ? t = e : (e instanceof Element || e instanceof Node) && (t = e.parentElement);
	let n = [];
	for (let e = t; e; e = e.parentElement) {
		let t = getComputedStyle(e).overflowY;
		/^(auto|scroll|overlay)$/.test(t) && e.scrollHeight > e.clientHeight && n.push(e);
	}
	let r = document.scrollingElement;
	return r instanceof HTMLElement && !n.includes(r) && r.scrollHeight > r.clientHeight && n.push(r), n;
}, t = (e, t) => {
	let n = t;
	for (let t of e) {
		if (Math.abs(n) < .5) break;
		let e = t.scrollTop, r = Math.max(0, t.scrollHeight - t.clientHeight);
		t.scrollTop = Math.max(0, Math.min(r, e + n)), n -= t.scrollTop - e;
	}
}, n = (n, r) => {
	let i = null, a = (e) => {
		(!e || i?.pointerId === e.pointerId) && (i = null);
	}, o = (t) => {
		let a = r();
		!n() || a == null || t.pointerType !== "touch" || t.pointerId === a || i || (i = {
			pointerId: t.pointerId,
			dragPointerId: a,
			clientY: t.clientY,
			scrollChain: e(t.target),
			scrollTops: []
		}, i.scrollTops = i.scrollChain.map((e) => e.scrollTop));
	}, s = (e) => o(e), c = (e) => {
		if (!n()) {
			i = null;
			return;
		}
		let a = r();
		if (a == null || e.pointerType !== "touch" || e.pointerId === a) return;
		if (!i || i.pointerId !== e.pointerId || i.dragPointerId !== a) {
			i = null, o(e);
			return;
		}
		let s = i.clientY - e.clientY;
		if (i.clientY = e.clientY, Math.abs(s) < .5) return;
		let c = 0;
		i.scrollChain.forEach((e, t) => {
			c += e.scrollTop - i.scrollTops[t];
		});
		let l = s - c;
		Math.abs(l) >= .5 && (t(i.scrollChain, l), e.cancelable && e.preventDefault()), i.scrollTops = i.scrollChain.map((e) => e.scrollTop);
	}, l = (e) => a(e);
	return document.addEventListener("pointerdown", s, !0), document.addEventListener("pointermove", c, {
		capture: !0,
		passive: !1
	}), document.addEventListener("pointerup", l, !0), document.addEventListener("pointercancel", l, !0), () => {
		document.removeEventListener("pointerdown", s, !0), document.removeEventListener("pointermove", c, !0), document.removeEventListener("pointerup", l, !0), document.removeEventListener("pointercancel", l, !0), i = null;
	};
};
//#endregion
export { n as attachSecondaryTouchScrollDuringDrag, t as scrollByTouchDelta, e as scrollableAncestors };

//# sourceMappingURL=pointerDragTouchScroll.js.map