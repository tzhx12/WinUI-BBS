import { alignment as e, cssLength as t, xamlThickness as n } from "./layout.js";
import { resolveXamlHandler as r, resolveXamlValue as i } from "./xamlRuntime.js";
import a from "./SymbolIcon.vue.js";
import { RefreshVisualizerContent as o, getRefreshVisualizerProperty as s, refreshChildren as c, refreshNodes as l } from "./RefreshProperties.js";
import { createRefreshContext as u, isFarPull as d, isVerticalPull as ee, raiseRefreshRequested as te, refreshContextKey as ne } from "./refreshRuntime.js";
import { cloneVNode as re, computed as f, defineComponent as p, getCurrentInstance as ie, h as ae, inject as oe, isVNode as m, markRaw as h, nextTick as se, onBeforeUnmount as ce, onMounted as le, ref as g, useAttrs as _, useSlots as v, watch as ue } from "vue";
var y = /*@__PURE__*/ p({
	Content: o,
	inheritAttrs: !1,
	__name: "RefreshVisualizer",
	props: {
		Orientation: {
			type: String,
			default: "Auto"
		},
		Content: {
			type: [String, Object],
			default: ""
		},
		Width: {
			type: [String, Number],
			default: ""
		},
		Height: {
			type: [String, Number],
			default: ""
		},
		MinWidth: {
			type: [String, Number],
			default: ""
		},
		MinHeight: {
			type: [String, Number],
			default: ""
		},
		MaxWidth: {
			type: [String, Number],
			default: ""
		},
		MaxHeight: {
			type: [String, Number],
			default: ""
		},
		Margin: {
			type: [String, Number],
			default: ""
		},
		HorizontalAlignment: {
			type: String,
			default: "Stretch"
		},
		VerticalAlignment: {
			type: String,
			default: "Stretch"
		},
		Background: {
			type: String,
			default: "{ThemeResource RefreshVisualizerBackground}"
		},
		Foreground: {
			type: String,
			default: "{ThemeResource RefreshVisualizerForeground}"
		},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		Visibility: {
			type: String,
			default: "Visible"
		}
	},
	emits: ["RefreshRequested", "RefreshStateChanged"],
	setup(o, { expose: y, emit: de }) {
		let b = o, x = de, S = ie(), C = v(), w = _(), fe = f(() => {
			let { RefreshRequested: e, RefreshStateChanged: t, ...n } = w;
			return n;
		}), T = g(null), E = g(null), D = oe(ne, null), O = D ?? u(), k = g("Idle"), A = g(0), j = g(!1), M = null, N = null, P = !1, F = (e) => i(e, S), I = f(() => {
			switch (F(b.Orientation)) {
				case "Normal": return 0;
				case "Rotate270DegreesCounterclockwise": return -Math.PI / 2;
				case "Rotate90DegreesCounterclockwise": return Math.PI / 2;
				default: return O.pullDirection === "LeftToRight" ? -Math.PI / 2 : O.pullDirection === "RightToLeft" ? Math.PI / 2 : 0;
			}
		}), L = f(() => ee(O.pullDirection)), R = (e) => L.value ? `0px ${e}px` : `${e}px 0px`, z = (e) => (d(O.pullDirection) ? -1 : 1) * (1 - O.executionRatio) * O.visualizerRootSize * .5 * e, B = f(() => {
			let e = Math.min(A.value / O.executionRatio, 1), t = k.value === "Interacting" || k.value === "Pending", n = k.value === "Interacting" ? I.value + Math.PI * e * 2 : I.value;
			return {
				justifySelf: "center",
				alignSelf: "center",
				transformOrigin: "50% 50%",
				opacity: k.value === "Idle" || k.value === "Interacting" ? "0.4" : "1",
				rotate: `${n}rad`,
				translate: k.value === "Refreshing" ? R(D ? z(1) : (d(O.pullDirection) ? -1 : 1) * O.visualizerRootSize) : t ? R(z(e)) : "0px 0px"
			};
		}), pe = f(() => {
			let r = {
				background: F(b.Background),
				color: F(b.Foreground),
				margin: n(F(b.Margin)),
				justifySelf: e(F(b.HorizontalAlignment), "horizontal"),
				alignSelf: e(F(b.VerticalAlignment), "vertical"),
				minHeight: t(F(b.MinHeight)) || "80px"
			};
			for (let e of [
				"Width",
				"Height",
				"MinWidth",
				"MaxWidth",
				"MaxHeight"
			]) {
				let n = t(F(b[e]));
				n && (r[e[0].toLowerCase() + e.slice(1)] = n);
			}
			return D && !L.value ? r.width ??= "100px" : r.height ??= "100px", F(b.Visibility) === "Collapsed" && (r.display = "none"), F(b.Visibility) === "Hidden" && (r.visibility = "hidden"), r;
		}), V = () => {
			M?.cancel(), M = null;
		}, H = () => {
			V(), N?.cancel(), N = null;
		}, U = () => {
			V(), E.value?.animate && (M = E.value.animate([{ rotate: `${I.value}rad` }, { rotate: `${I.value + Math.PI * 2}rad` }], {
				duration: 500,
				iterations: Infinity,
				easing: "linear"
			}));
		}, W = () => {
			N?.cancel(), E.value?.animate && (N = E.value.animate([
				{
					scale: "1",
					offset: 0
				},
				{
					scale: "1.5",
					offset: .5
				},
				{
					scale: "1",
					offset: 1
				}
			], {
				duration: 300,
				easing: "cubic-bezier(0.5, 0, 0, 1)"
			}));
		}, G = (e) => {
			let t = Q;
			x("RefreshStateChanged", t, e), r(w.RefreshStateChanged, S)?.(t, e);
		}, K = (e) => {
			if (k.value === e || P) return;
			let t = k.value;
			k.value = e, O.state = e, e === "Pending" ? (V(), W()) : e === "Refreshing" ? U() : e === "Idle" ? H() : V(), G({
				OldState: t,
				NewState: e
			}), O.containerStateChanged?.(t, e);
		}, q = () => {
			P || k.value === "Refreshing" || (K("Refreshing"), te((e) => {
				let t = Q;
				x("RefreshRequested", t, e), r(w.RefreshRequested, S)?.(t, e), O.containerRefreshRequested?.(e);
			}, () => {
				P || (A.value = 0, j.value = !1, K("Idle"));
			}));
		}, J = (e) => {
			let t = A.value === 0;
			if (A.value = Math.max(0, Math.min(1, e)), !j.value) {
				k.value !== "Refreshing" && K(e > 0 ? "Peeking" : "Idle");
				return;
			}
			switch (k.value) {
				case "Idle":
					t ? e > O.executionRatio ? K("Pending") : e > 0 && K("Interacting") : e > 0 && K("Peeking");
					break;
				case "Interacting":
					e <= 0 ? K("Idle") : e > O.executionRatio && K("Pending");
					break;
				case "Pending":
					e <= O.executionRatio && K("Interacting");
					break;
			}
		}, Y = h({
			setInteractionRatio: J,
			setIsInteractingForRefresh(e) {
				j.value = e, !e && (k.value === "Pending" ? q() : k.value !== "Refreshing" && K("Idle"));
			},
			setInternalPullDirection(e) {
				O.pullDirection = e, k.value !== "Refreshing" && K("Idle"), se(Z);
			},
			RequestRefresh: q,
			get publicInstance() {
				return Q;
			}
		}), me = p({ setup() {
			return () => {
				let e = l(C.default?.() ?? []), t = e.find((e) => s(e) === "content"), n = F(b.Content), r = (t ? c(t) : e)[0] ?? (m(n) ? n : ae(a, {
					Symbol: "Refresh",
					FontSize: "20",
					style: {
						width: "30px",
						height: "30px"
					}
				})), i = (e) => {
					let t = e.el instanceof HTMLElement ? e.el : null;
					E.value !== t && (H(), E.value = t, k.value === "Refreshing" ? U() : k.value === "Pending" && W());
				};
				return re(r, {
					style: B.value,
					onVnodeMounted: i,
					onVnodeUpdated: i
				});
			};
		} }), X, Z = () => {
			let e = T.value;
			if (!e) return;
			let t = L.value ? e.offsetHeight : e.offsetWidth;
			t > 0 && (O.visualizerSize = t, O.visualizerRootSize = t);
		};
		ue(I, () => {
			k.value === "Refreshing" && U();
		}), le(() => {
			O.visualizerHandle = Y, Z(), typeof ResizeObserver == "function" && (X = new ResizeObserver(Z), T.value && X.observe(T.value));
		}), ce(() => {
			P = !0, X?.disconnect(), H(), O.visualizerHandle === Y && (O.visualizerHandle = null);
		});
		let Q = h({
			RequestRefresh: q,
			get State() {
				return k.value;
			},
			get Content() {
				return E.value;
			}
		});
		y(Q);
		let $ = {
			props: b,
			emit: x,
			instance: S,
			slots: C,
			attrs: w,
			rootAttrs: fe,
			rootRef: T,
			contentRef: E,
			provider: D,
			context: O,
			state: k,
			interactionRatio: A,
			isInteracting: j,
			get rotationAnimation() {
				return M;
			},
			set rotationAnimation(e) {
				M = e;
			},
			get scaleAnimation() {
				return N;
			},
			set scaleAnimation(e) {
				N = e;
			},
			get disposed() {
				return P;
			},
			set disposed(e) {
				P = e;
			},
			value: F,
			startingAngle: I,
			vertical: L,
			translate: R,
			parallax: z,
			indicatorStyle: B,
			rootStyle: pe,
			stopRotation: V,
			stopAnimations: H,
			startRotation: U,
			startScale: W,
			invokeStateChanged: G,
			setState: K,
			RequestRefresh: q,
			setInteractionRatio: J,
			handle: Y,
			ContentOutlet: me,
			get resizeObserver() {
				return X;
			},
			set resizeObserver(e) {
				X = e;
			},
			measure: Z,
			publicApi: Q
		};
		return Object.defineProperty($, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), $;
	}
});
//#endregion
export { y as default };

//# sourceMappingURL=RefreshVisualizer.vue_vue_type_script_setup_true_lang.js.map