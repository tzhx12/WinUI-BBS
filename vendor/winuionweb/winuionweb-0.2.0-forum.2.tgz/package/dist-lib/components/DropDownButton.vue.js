import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./DropDownButton.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                   */
import { Fragment as n, createBlock as r, createCommentVNode as i, createElementBlock as a, createVNode as o, mergeProps as s, openBlock as c, resolveComponent as l, withCtx as u } from "vue";
//#region src/components/DropDownButton.vue
function d(e, t, d, f, p, m) {
	let h = l("ColumnDefinition");
	return c(), a(n, null, [o(f.Button, s({ ref: "buttonControl" }, f.hostAttrs, {
		class: ["win-dropdown-button", [f.attrs.class]],
		style: f.attrs.style,
		IsEnabled: f.IsEnabled,
		IsTabStop: f.IsTabStop,
		ClickMode: f.ClickMode,
		RequestedTheme: f.RequestedTheme,
		Visibility: f.resolveString(f.props.Visibility),
		Background: f.resolvedBackground,
		Foreground: f.resolveString(f.props.Foreground),
		BorderBrush: f.resolveString(f.props.BorderBrush),
		BorderThickness: f.BorderThickness,
		CornerRadius: f.CornerRadius,
		Padding: f.resolveString(f.props.Padding),
		BackgroundSizing: f.BackgroundSizing,
		Margin: f.resolveString(f.props.Margin),
		Width: f.resolveLength(f.props.Width),
		Height: f.resolveLength(f.props.Height),
		MinWidth: f.resolveLength(f.props.MinWidth),
		MinHeight: f.resolveLength(f.props.MinHeight),
		MaxWidth: f.resolveLength(f.props.MaxWidth),
		MaxHeight: f.resolveLength(f.props.MaxHeight),
		HorizontalAlignment: f.resolveString(f.props.HorizontalAlignment),
		VerticalAlignment: f.resolveString(f.props.VerticalAlignment),
		HorizontalContentAlignment: f.HorizontalContentAlignment,
		VerticalContentAlignment: f.VerticalContentAlignment,
		FontFamily: f.resolveString(f.props.FontFamily),
		FontSize: f.resolveLength(f.props.FontSize),
		FontWeight: f.resolveString(f.props.FontWeight),
		UseSystemFocusVisuals: f.UseSystemFocusVisuals,
		FocusVisualMargin: f.resolveLength(f.props.FocusVisualMargin),
		"aria-haspopup": f.Flyout ? "menu" : void 0,
		"aria-expanded": f.Flyout ? f.isFlyoutOpen : void 0,
		Command: f.Command,
		CommandParameter: f.CommandParameter,
		Flyout: f.FlyoutForButton,
		onClick: f.onButtonClick,
		onGotFocus: t[0] ||= (e) => f.forwardButtonEvent("GotFocus"),
		onLostFocus: t[1] ||= (e) => f.forwardButtonEvent("LostFocus"),
		onKeyDown: t[2] ||= (e) => f.forwardButtonEvent("KeyDown"),
		onKeyUp: t[3] ||= (e) => f.forwardButtonEvent("KeyUp"),
		onPointerEntered: t[4] ||= (e) => f.forwardButtonEvent("PointerEntered"),
		onPointerExited: t[5] ||= (e) => f.forwardButtonEvent("PointerExited"),
		onPointerMoved: t[6] ||= (e) => f.forwardButtonEvent("PointerMoved"),
		onPointerPressed: t[7] ||= (e) => f.forwardButtonEvent("PointerPressed"),
		onPointerReleased: t[8] ||= (e) => f.forwardButtonEvent("PointerReleased"),
		onPointerCanceled: t[9] ||= (e) => f.forwardButtonEvent("PointerCanceled"),
		onPointerCaptureLost: t[10] ||= (e) => f.forwardButtonEvent("PointerCaptureLost"),
		onContextRequested: f.contextRequestedListener
	}), {
		default: u(() => [o(f.Grid, { class: "win-dropdown-root-grid" }, {
			default: u(() => [
				o(f.Grid.ColumnDefinitions, null, {
					default: u(() => [o(h, { Width: "*" }), o(h, { Width: "Auto" })]),
					_: 1
				}),
				o(f.ContentPresenter, {
					class: "win-dropdown-content-presenter",
					Content: f.Content,
					ContentTemplate: f.ContentTemplate,
					ContentTransitions: f.ContentTransitions,
					HorizontalContentAlignment: f.HorizontalContentAlignment,
					VerticalContentAlignment: f.VerticalContentAlignment,
					"AutomationProperties.AccessibilityView": "Raw"
				}, {
					default: u(() => [o(f.ContentOutlet)]),
					_: 1
				}, 8, [
					"Content",
					"ContentTemplate",
					"ContentTransitions",
					"HorizontalContentAlignment",
					"VerticalContentAlignment"
				]),
				o(f.AnimatedIcon, {
					class: "win-dropdown-chevron",
					"Grid.Column": "1",
					Margin: "8,0,0,0",
					Width: "12",
					Height: "12",
					"AutomationProperties.AccessibilityView": "Raw"
				}, {
					default: u(() => [o(f.AnimatedChevronDownSmallVisualSource), o(f.AnimatedIcon.FallbackIconSource, null, {
						default: u(() => [o(f.FontIconSource, {
							FontSize: "8",
							FontFamily: "{ThemeResource SymbolThemeFontFamily}",
							Glyph: "",
							IsTextScaleFactorEnabled: "False"
						})]),
						_: 1
					})]),
					_: 1
				})
			]),
			_: 1
		})]),
		_: 1
	}, 16, /* @__PURE__ */ "class.style.IsEnabled.IsTabStop.ClickMode.RequestedTheme.Visibility.Background.Foreground.BorderBrush.BorderThickness.CornerRadius.Padding.BackgroundSizing.Margin.Width.Height.MinWidth.MinHeight.MaxWidth.MaxHeight.HorizontalAlignment.VerticalAlignment.HorizontalContentAlignment.VerticalContentAlignment.FontFamily.FontSize.FontWeight.UseSystemFocusVisuals.FocusVisualMargin.aria-haspopup.aria-expanded.Command.CommandParameter.Flyout.onContextRequested".split(".")), f.propertyNodes.attached.length ? (c(), r(f.AttachedOutlet, { key: 0 })) : i("", !0)], 64);
}
var f = /*#__PURE__*/ e(t, [["render", d], ["__file", "DropDownButton.vue"]]);
//#endregion
export { f as default };

//# sourceMappingURL=DropDownButton.vue.js.map