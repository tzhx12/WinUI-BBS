import { cssLength as e, xamlThickness as t } from "./layout.js";
import { resolveXamlValue as n, updateXamlBinding as r } from "./xamlRuntime.js";
import { frameworkLayoutStyle as i } from "./frameworkLayout.js";
import { appBarBoolean as a, commandBarContextKey as o } from "./appBarRuntime.js";
/* empty css                 */
import { computed as s, defineComponent as c, getCurrentInstance as l, inject as u, ref as d, shallowReactive as f, useAttrs as p, watch as m } from "vue";
//#region src/components/AppBarSeparator.vue?vue&type=script&setup=true&lang.ts
var h = /*@__PURE__*/ c({
	name: "AppBarSeparator",
	inheritAttrs: !1,
	__name: "AppBarSeparator",
	props: {
		IsCompact: {
			type: [Boolean, String],
			default: void 0
		},
		DynamicOverflowOrder: {
			type: [Number, String],
			default: 0
		},
		IsTabStop: {
			type: [Boolean, String],
			default: !1
		},
		Visibility: {
			type: String,
			default: "Visible"
		},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		Foreground: { default: void 0 },
		Padding: {
			type: [String, Number],
			default: void 0
		},
		Margin: {
			type: [String, Number],
			default: void 0
		},
		Width: {
			type: [String, Number],
			default: void 0
		},
		Height: {
			type: [String, Number],
			default: void 0
		},
		MinWidth: {
			type: [String, Number],
			default: 0
		},
		MinHeight: {
			type: [String, Number],
			default: 0
		},
		MaxWidth: {
			type: [String, Number],
			default: void 0
		},
		MaxHeight: {
			type: [String, Number],
			default: void 0
		},
		HorizontalAlignment: {
			type: String,
			default: "Stretch"
		},
		VerticalAlignment: {
			type: String,
			default: "Stretch"
		}
	},
	emits: [
		"update:IsCompact",
		"update:DynamicOverflowOrder",
		"update:IsTabStop",
		"update:Visibility",
		"update:IsEnabled",
		"update:Foreground",
		"update:Padding",
		"update:Margin",
		"update:Width",
		"update:Height",
		"update:MinWidth",
		"update:MinHeight",
		"update:MaxWidth",
		"update:MaxHeight",
		"update:HorizontalAlignment",
		"update:VerticalAlignment"
	],
	setup(c, { expose: h, emit: g }) {
		let _ = c, v = g, y = p(), b = l(), x = u(o, null), S = d(null), C = f({}), w = (e) => n(e, b), T = (e) => e in C ? C[e] : w(_[e]), E = s(() => x?.isInOverflow.value ?? !1), D = s(() => T("IsCompact") === void 0 ? x?.compact.value ?? !1 : a(T("IsCompact"))), O = s(() => T("Visibility") !== "Collapsed"), k = s(() => a(T("IsTabStop")));
		for (let e of Object.keys(_)) m(() => w(_[e]), () => {
			delete C[e];
		});
		let A = s(() => ({
			...i(_, b),
			margin: t(T("Margin")) || void 0,
			width: e(T("Width")) || void 0,
			height: e(T("Height")) || void 0,
			minWidth: e(T("MinWidth")) || void 0,
			minHeight: e(T("MinHeight")) || void 0,
			maxWidth: e(T("MaxWidth")) || void 0,
			maxHeight: e(T("MaxHeight")) || void 0,
			"--AppBarSeparatorForeground": T("Foreground") || void 0,
			"--AppBarSeparatorPadding": t(T("Padding")) || void 0
		})), j = Object.fromEntries(Object.keys(_).map((e) => [e, s({
			get: () => T(e),
			set: (t) => {
				C[e] = t, r(_[e], t, b), v(`update:${e}`, t);
			}
		})]));
		h({
			...j,
			Name: s(() => String(w(y["data-xaml-ref"] ?? y["x:Name"] ?? y.Name ?? ""))),
			IsInOverflow: E,
			$el: S
		});
		let M = {
			props: _,
			emit: v,
			attrs: y,
			instance: b,
			barContext: x,
			rootRef: S,
			overrides: C,
			resolve: w,
			value: T,
			inOverflow: E,
			compact: D,
			visible: O,
			isTabStop: k,
			separatorStyle: A,
			dependencies: j
		};
		return Object.defineProperty(M, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), M;
	}
});
//#endregion
export { h as default };

//# sourceMappingURL=AppBarSeparator.vue_vue_type_script_setup_true_lang.js.map