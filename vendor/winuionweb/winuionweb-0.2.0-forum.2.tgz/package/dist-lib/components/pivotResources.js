//#region src/components/pivotResources.ts
var e = Object.freeze({
	PivotHeaderItemFontFamily: "var(--ContentControlThemeFontFamily, \"Segoe UI Variable\", \"Segoe UI\", sans-serif)",
	PivotTitleFontFamily: "var(--ContentControlThemeFontFamily, \"Segoe UI Variable\", \"Segoe UI\", sans-serif)",
	PivotHeaderItemFontSize: 24,
	PivotHeaderItemLockedTranslation: 40,
	PivotTitleFontSize: 14,
	PivotHeaderItemCharacterSpacing: -25,
	PivotHeaderItemMargin: "12,0,12,0",
	PivotItemMargin: "12,0,12,0",
	PivotLandscapeThemePadding: "12,14,0,13",
	PivotPortraitThemePadding: "12,14,0,13",
	PivotNavButtonBorderThemeThickness: 0,
	PivotNavButtonMargin: "0,6,0,0",
	PivotHeaderItemThemeFontWeight: 350,
	PivotTitleThemeFontWeight: 700,
	PivotHeaderItemSelectedPipeCornerRadius: 1.5,
	PivotBackground: "var(--SystemControlTransparentBrush, transparent)",
	PivotHeaderBackground: "var(--SystemControlTransparentBrush, transparent)",
	PivotItemBackground: "var(--SystemControlTransparentBrush, transparent)",
	PivotHeaderItemBackgroundUnselected: "transparent",
	PivotHeaderItemBackgroundUnselectedPointerOver: "transparent",
	PivotHeaderItemBackgroundUnselectedPressed: "transparent",
	PivotHeaderItemBackgroundSelected: "transparent",
	PivotHeaderItemBackgroundSelectedPointerOver: "transparent",
	PivotHeaderItemBackgroundSelectedPressed: "transparent",
	PivotHeaderItemBackgroundDisabled: "transparent",
	PivotHeaderItemForegroundUnselected: "var(--SystemControlForegroundBaseMediumBrush, var(--text-secondary))",
	PivotHeaderItemForegroundUnselectedPointerOver: "var(--SystemControlHighlightAltBaseMediumHighBrush, var(--text-primary))",
	PivotHeaderItemForegroundUnselectedPressed: "var(--SystemControlHighlightAltBaseMediumHighBrush, var(--text-primary))",
	PivotHeaderItemForegroundSelected: "var(--SystemControlHighlightAltBaseHighBrush, var(--text-primary))",
	PivotHeaderItemForegroundSelectedPointerOver: "var(--SystemControlHighlightAltBaseMediumHighBrush, var(--text-primary))",
	PivotHeaderItemForegroundSelectedPressed: "var(--SystemControlHighlightAltBaseMediumHighBrush, var(--text-primary))",
	PivotHeaderItemForegroundDisabled: "var(--SystemControlDisabledBaseMediumLowBrush, var(--text-disabled))",
	PivotHeaderItemFocusPipeFill: "var(--SystemControlHighlightAltAccentBrush, var(--accent-default))",
	PivotHeaderItemSelectedPipeFill: "var(--AccentFillColorDefaultBrush, var(--accent-default))",
	...Object.fromEntries(["Next", "Previous"].flatMap((e) => [
		[`Pivot${e}ButtonBackground`, "var(--SystemControlBackgroundBaseMediumLowBrush, var(--control-fill-secondary))"],
		[`Pivot${e}ButtonBackgroundPointerOver`, "var(--SystemControlHighlightBaseMediumBrush, var(--control-fill-tertiary))"],
		[`Pivot${e}ButtonBackgroundPressed`, "var(--SystemControlHighlightBaseMediumHighBrush, var(--control-fill-disabled))"],
		[`Pivot${e}ButtonBorderBrush`, "transparent"],
		[`Pivot${e}ButtonBorderBrushPointerOver`, "transparent"],
		[`Pivot${e}ButtonBorderBrushPressed`, "transparent"],
		[`Pivot${e}ButtonForeground`, "var(--SystemControlForegroundAltMediumHighBrush, var(--text-primary))"],
		[`Pivot${e}ButtonForegroundPointerOver`, "var(--SystemControlHighlightAltAltMediumHighBrush, var(--text-primary))"],
		[`Pivot${e}ButtonForegroundPressed`, "var(--SystemControlHighlightAltAltMediumHighBrush, var(--text-primary))"]
	]))
}), t = Object.freeze(Object.fromEntries(Object.entries(e).map(([e, t]) => [e, typeof t == "string" && /var\(|transparent/.test(t) ? `var(--${e}, ${t})` : t])));
//#endregion
export { t as pivotResources };

//# sourceMappingURL=pivotResources.js.map