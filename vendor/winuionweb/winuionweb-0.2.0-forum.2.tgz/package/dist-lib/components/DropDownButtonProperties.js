import { defineComponent as e } from "vue";
//#region src/components/DropDownButtonProperties.ts
var t = (t, n) => e({
	name: `DropDownButton.${t}`,
	__dropDownButtonProperty: n,
	setup() {
		return () => null;
	}
}), n = t("Flyout", "flyout"), r = t("Content", "content"), i = t("KeyboardAccelerators", "keyboardAccelerators"), a = (e) => {
	let t = e.type;
	return typeof t != "string" && t?.__dropDownButtonProperty ? t.__dropDownButtonProperty : {
		"DropDownButton.Flyout": "flyout",
		"DropDownButton.Content": "content",
		"DropDownButton.KeyboardAccelerators": "keyboardAccelerators"
	}[(typeof t == "string" ? t : t?.name ?? t?.__name) ?? ""];
};
//#endregion
export { r as DropDownButtonContent, n as DropDownButtonFlyout, i as DropDownButtonKeyboardAccelerators, a as getDropDownButtonProperty };

//# sourceMappingURL=DropDownButtonProperties.js.map