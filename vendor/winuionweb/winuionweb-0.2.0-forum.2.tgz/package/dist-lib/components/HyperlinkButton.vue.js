import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./HyperlinkButton.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                    */
import { createBlock as n, createVNode as r, mergeProps as i, openBlock as a, withCtx as o } from "vue";
//#region src/components/HyperlinkButton.vue
function s(e, t, s, c, l, u) {
	return a(), n(c.NativeHyperlinkHost, i(c.buttonAttrs, {
		class: ["win-hyperlink-button", [c.attrs.class, {
			disabled: !c.IsEnabled,
			"is-pressed": c.pressed,
			"system-focus": c.UseSystemFocusVisuals,
			"win-theme-scope": c.RequestedTheme === "Light" || c.RequestedTheme === "Dark",
			"theme-light": c.RequestedTheme === "Light",
			"theme-dark": c.RequestedTheme === "Dark"
		}]],
		HorizontalAlignment: c.resolve(c.props.HorizontalAlignment),
		VerticalAlignment: c.resolve(c.props.VerticalAlignment),
		style: c.hostStyle,
		href: c.NavigateUri || void 0,
		type: c.NavigateUri ? void 0 : "button",
		target: c.NavigateUri ? c.TargetName || "_blank" : void 0,
		rel: !c.TargetName || c.TargetName === "_blank" ? "noopener noreferrer" : void 0,
		disabled: c.NavigateUri ? void 0 : !c.IsEnabled,
		"aria-disabled": !c.IsEnabled || void 0,
		tabindex: !c.IsEnabled || !c.IsTabStop ? -1 : void 0,
		onClick: c.onClick,
		onPointerdown: c.onPointerDown,
		onPointerenter: c.onPointerEntered,
		onPointermove: c.onPointerMoved,
		onPointerup: c.onPointerReleased,
		onPointercancel: c.onPointerCanceled,
		onLostpointercapture: c.clearPressed,
		onPointerleave: c.onPointerExited,
		onKeydown: c.onKeyDown,
		onKeyup: c.onKeyUp,
		onBlur: c.clearPressed
	}), {
		default: o(() => [r(c.ContentPresenter, {
			class: "win-hyperlink-content-presenter",
			ContentTemplate: "{x:Bind ContentTemplate}",
			ContentTransitions: "{x:Bind ContentTransitions}",
			Background: "{x:Bind PresenterBackground}",
			BackgroundSizing: "{x:Bind PresenterBackgroundSizing}",
			BorderBrush: "{x:Bind PresenterBorderBrush}",
			BorderThickness: "{x:Bind PresenterBorderThickness}",
			Padding: "{x:Bind PresenterPadding}",
			CornerRadius: "{x:Bind PresenterCornerRadius}",
			HorizontalContentAlignment: "{x:Bind PresenterHorizontalAlignment}",
			VerticalContentAlignment: "{x:Bind PresenterVerticalAlignment}"
		}, {
			default: o(() => [r(c.ContentOutlet)]),
			_: 1
		})]),
		_: 1
	}, 16, [
		"HorizontalAlignment",
		"VerticalAlignment",
		"class",
		"style",
		"href",
		"type",
		"target",
		"rel",
		"disabled",
		"aria-disabled",
		"tabindex"
	]);
}
var c = /*#__PURE__*/ e(t, [["render", s], ["__file", "HyperlinkButton.vue"]]);
//#endregion
export { c as default };

//# sourceMappingURL=HyperlinkButton.vue.js.map