import { cssLength as e, xamlThickness as t } from "./layout.js";
import { xamlThemeKey as n } from "./brushCore.js";
import { useAcrylicBrushStyle as r } from "./AcrylicBrush.js";
import { normalizeXamlNodes as i, resolveXamlHandler as a, resolveXamlValue as ee, updateXamlBinding as te, xamlControlIdentityKey as ne } from "./xamlRuntime.js";
import { vAcrylicBackdrop as re, vAcrylicBrush as ie } from "./acrylicBrushVisual.js";
import { vThemeShadow as ae } from "./themeShadowVisual.js";
import { CommandPortal as oe, commandBarProperty as se, commandChildren as ce, commandCollection as le, commandHasIcon as ue, flattenCommandNodes as de, isAppBarCommand as fe, isCommandSeparator as pe, isCommandToggle as me } from "./commandBarRuntime.js";
import { flyoutContainsNode as he, hasOpenDescendantFlyout as ge, hideDescendantFlyouts as _e, registerFlyoutInputRegion as ve } from "./flyoutInput.js";
import { useI18n as ye } from "./i18n/index.js";
/* empty css                        */
import { Fragment as be, computed as o, defineComponent as xe, getCurrentInstance as Se, h as Ce, inject as we, isVNode as Te, nextTick as s, onBeforeUnmount as Ee, onMounted as De, onUpdated as Oe, provide as ke, ref as c, shallowReactive as Ae, shallowRef as je, unref as Me, useAttrs as Ne, useSlots as Pe, watch as Fe } from "vue";
var Ie = /*@__PURE__*/ xe({
	Content: se("CommandBar", "Content"),
	PrimaryCommands: se("CommandBar", "PrimaryCommands"),
	SecondaryCommands: se("CommandBar", "SecondaryCommands"),
	name: "CommandBar",
	inheritAttrs: !1,
	__name: "CommandBar",
	props: {
		Content: { default: void 0 },
		PrimaryCommands: { default: void 0 },
		SecondaryCommands: { default: void 0 },
		IsOpen: {
			type: [Boolean, String],
			default: !1
		},
		IsSticky: {
			type: [Boolean, String],
			default: !1
		},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		IsDynamicOverflowEnabled: {
			type: [Boolean, String],
			default: !0
		},
		DefaultLabelPosition: {
			type: String,
			default: "Bottom"
		},
		ClosedDisplayMode: {
			type: String,
			default: "Compact"
		},
		OverflowButtonVisibility: {
			type: String,
			default: "Auto"
		},
		Background: { default: void 0 },
		Foreground: { default: void 0 },
		Padding: { default: "4,0,0,0" },
		CornerRadius: { default: void 0 },
		HorizontalAlignment: {
			type: String,
			default: "Stretch"
		}
	},
	emits: [
		"Opening",
		"Opened",
		"Closing",
		"Closed",
		"DynamicOverflowItemsChanging",
		"update:IsOpen",
		"update:IsSticky",
		"update:IsEnabled",
		"update:IsDynamicOverflowEnabled",
		"update:DefaultLabelPosition",
		"update:ClosedDisplayMode",
		"update:OverflowButtonVisibility",
		"update:PrimaryCommands",
		"update:SecondaryCommands",
		"update:Content",
		"update:Background",
		"update:Foreground",
		"update:Padding",
		"update:CornerRadius",
		"update:HorizontalAlignment"
	],
	setup(se, { expose: Ie, emit: Le }) {
		let l = se, u = Le, d = Se(), Re = Ne(), ze = Pe(), { t: Be } = ye(), f = (e) => ee(e, d), p = (e) => e !== !1 && e !== "False" && e !== "false", m = Ae({}), h = (e) => e in m ? m[e] : f(l[e]), g = c(null), Ve = c(null), He = c(null), _ = c(null), v = c(null), y = c(null), b = c(null), Ue = c(null), x = c(null), S = c(null), C = c(p(f(l.IsOpen))), w = c(!1), We = c(0), Ge = we(n, null) ?? we("winuiTheme", null), T = o(() => {
			We.value;
			let e = g.value?.closest("[data-theme], .win-theme-scope, .example-theme-wrapper, .theme-light, .theme-dark"), t = e?.getAttribute("data-theme")?.toLowerCase();
			return t === "dark" || t === "light" ? t : e?.classList.contains("theme-dark") ? "dark" : e?.classList.contains("theme-light") ? "light" : String(Me(Ge) || "").toLowerCase();
		});
		ke(n, T);
		let Ke = o(() => T.value === "light" || T.value === "dark" ? `win-theme-scope theme-${T.value}` : ""), qe = r(() => w.value ? "{ThemeResource CommandBarBackgroundOpen}" : h("Background") ?? "{ThemeResource CommandBarBackground}", d), Je = r("{ThemeResource CommandBarOverflowPresenterBackground}", d), E = c(!1), D = c(!1), O = c(!1), Ye = c({
			left: 0,
			top: 0
		}), k = c({
			left: 0,
			top: 0,
			width: 0,
			direction: "ltr"
		}), Xe = c(0), Ze = c(0), A = c(64), Qe = o(() => String(h("ClosedDisplayMode")) === "Hidden" ? 0 : String(h("ClosedDisplayMode")) === "Minimal" ? 24 : 48), j = o(() => Qe.value - A.value), M = le(Ae([])), N = le(Ae([])), $e = je([]), et = /* @__PURE__ */ new Set(), tt = /* @__PURE__ */ new WeakMap(), nt = 0, P = /* @__PURE__ */ new Map(), F = document.createElement("div");
		F.className = "commandbar-overflow-divider", F.setAttribute("role", "separator");
		let I = je(/* @__PURE__ */ new Set()), L = o(() => [...M.map((e) => rt(e, !1)), ...N.map((e) => rt(e, !0))]);
		function rt(e, t) {
			let n = tt.get(e);
			n === void 0 && (n = ++nt, tt.set(e, n));
			let r = P.get(n);
			if (!r) {
				let i = document.createElement("div");
				i.className = "commandbar-command-host", r = {
					id: n,
					node: e,
					host: i,
					secondary: t,
					width: pe(e) ? 17 : 68
				}, P.set(n, r);
			}
			return r.secondary = t, r;
		}
		let it = o(() => p(h("IsEnabled"))), at = o(() => p(h("IsSticky"))), ot = o(() => Be(C.value ? "text.see-less" : "text.see-more")), R = o(() => String(h("DefaultLabelPosition"))), st = o(() => !w.value && String(h("ClosedDisplayMode")) !== "Hidden"), z = o(() => L.value.filter((e) => e.secondary || I.value.has(e.id)).map((e) => e.node)), ct = {
			isOpen: C,
			isEnabled: it,
			defaultLabelPosition: R,
			compact: st,
			isInOverflow: o(() => !1),
			hasIcons: o(() => z.value.some(ue)),
			hasToggleButtons: o(() => z.value.some(me)),
			closeOverflow: () => {
				p(h("IsSticky")) || Q(!1);
			},
			invokeCommand: () => {
				p(h("IsSticky")) || Q(!1);
			}
		}, lt = o(() => String(h("OverflowButtonVisibility")) === "Visible" || String(h("OverflowButtonVisibility")) !== "Collapsed" && (M.length > 0 || N.length > 0)), ut = o(() => String(f(Re["AutomationProperties.Name"]) || Be("text.command-bar"))), dt = o(() => ({
			"is-open": w.value,
			"opens-up": O.value,
			"is-disabled": !it.value,
			"labels-bottom": R.value === "Bottom",
			"labels-right": R.value === "Right",
			"labels-collapsed": R.value === "Collapsed",
			"closed-minimal": String(h("ClosedDisplayMode")) === "Minimal",
			"closed-hidden": String(h("ClosedDisplayMode")) === "Hidden",
			"dynamic-overflow-enabled": p(h("IsDynamicOverflowEnabled"))
		})), ft = o(() => ({
			"--CommandBarBackground": h("Background"),
			"--CommandBarForeground": h("Foreground"),
			"--CommandBarCornerRadius": h("CornerRadius") === void 0 ? void 0 : e(h("CornerRadius")),
			"--CommandBarContentPadding": t(h("Padding")),
			"--CommandBarDesiredWidth": `${Ze.value}px`,
			width: w.value && Xe.value ? `${Xe.value}px` : String(h("HorizontalAlignment")) === "Stretch" ? "auto" : "max-content",
			maxWidth: "100%",
			alignSelf: {
				Left: "flex-start",
				Center: "center",
				Right: "flex-end",
				Stretch: "stretch"
			}[String(h("HorizontalAlignment"))],
			justifySelf: {
				Left: "start",
				Center: "center",
				Right: "end",
				Stretch: "stretch"
			}[String(h("HorizontalAlignment"))]
		})), pt = o(() => ({
			left: `${k.value.left}px`,
			top: `${k.value.top}px`,
			width: `${k.value.width}px`,
			height: `${A.value}px`,
			direction: k.value.direction,
			"--CommandBarVerticalDelta": `${j.value}px`
		})), mt = o(() => ({ clipPath: w.value ? O.value ? `inset(${j.value}px 0 ${-j.value}px 0)` : "inset(0px 0px 0px 0px)" : `inset(0px 0px ${Math.max(0, A.value - Qe.value)}px 0px)` })), ht = o(() => ({
			left: `${Ye.value.left}px`,
			top: `${Ye.value.top}px`,
			clipPath: O.value ? "inset(-24px -16px 0px -16px)" : "inset(0px -16px -24px -16px)",
			"--CommandBarOverflowAvailableWidth": `${Math.max(0, window.innerWidth - 16)}px`,
			"--CommandBarOverflowAvailableHeight": `${Math.max(0, window.innerHeight * .5)}px`
		})), gt = (e, t) => {
			let n = f(l[e]);
			if (Array.isArray(n)) return n.filter(Te);
			let r = t.find((t) => t.type.__commandBarProperty === e);
			return de(r ? ce(r) : e === "PrimaryCommands" ? t.filter(fe) : []);
		}, _t = xe({
			name: "CommandBarDeclarationOutlet",
			setup() {
				return () => {
					let e = de(ze.default?.() ?? []);
					$e.value = e;
					for (let t of ["PrimaryCommands", "SecondaryCommands"]) et.has(t) || ((t === "PrimaryCommands" ? M : N).push(...gt(t, e)), et.add(t));
					return null;
				};
			}
		}), vt = xe({
			name: "CommandBarContentOutlet",
			setup() {
				return () => {
					let e = $e.value.find((e) => e.type.__commandBarProperty === "Content"), t = h("Content"), n = Te(t) ? [t] : e ? ce(e) : [];
					return Ce(be, n.length ? i(n, d) : typeof t == "string" || typeof t == "number" ? [String(t)] : []);
				};
			}
		}), B = {}, yt = (e) => ({
			Owner: B,
			get IsOpen() {
				return w.value;
			},
			get Target() {
				return g.value;
			},
			get Presenter() {
				return e.value;
			},
			get DismissLayer() {
				return at.value ? null : Ve.value;
			},
			Hide() {
				Q(!1);
			}
		}), V = yt(He), H = yt(S), bt = ve(V), xt = ve(H), U = (e, t = {}) => {
			u(e, B, t), a(Re[e], d)?.(B, t);
		}, W = 0, G = [], K = null, q = null, J = null, Y = !1, St = () => {
			G.forEach((e) => e.cancel()), G = [];
		}, Ct = (e, t) => {
			if (!_.value?.animate || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return Promise.resolve();
			let n = {
				duration: e ? 250 : 167,
				easing: "cubic-bezier(0, 0, 0, 1)",
				fill: "both"
			}, r = (e, t, r, i) => {
				e && G.push(e.animate([{ [t]: r }, { [t]: i }], n));
			}, i = j.value;
			if (O.value ? r(v.value, "transform", t?.contentTransform || `translateY(${e ? 0 : i}px)`, `translateY(${e ? i : 0}px)`) : r(_.value, "clipPath", t?.clipPath || `inset(0px 0px ${e ? -i : 0}px 0px)`, `inset(0px 0px ${e ? 0 : -i}px 0px)`), String(h("ClosedDisplayMode")) !== "Compact") for (let t of [b.value, y.value]) t && G.push(t.animate([{ opacity: +!e }, { opacity: +!!e }], n));
			if (E.value) {
				let n = S.value?.querySelector(".commandbar-secondary-shadow-wrapper"), a = O.value ? "100%" : "-100%";
				r(n, "transform", t?.overflowTransform || (e ? `translateY(${a})` : "translateY(0)"), e ? "translateY(0)" : `translateY(${a})`), O.value ? r(S.value, "clipPath", t?.overflowClip || `inset(${(e ? -i : 0) - 24}px -16px 0px -16px)`, `inset(${(e ? 0 : -i) - 24}px -16px 0px -16px)`) : r(S.value, "transform", t?.popupTransform || `translateY(${e ? i : 0}px)`, `translateY(${e ? 0 : i}px)`);
			}
			return Promise.all(G.map((e) => e.finished.catch(() => void 0))).then(() => void 0);
		}, X = () => {
			if (!b.value || !Ue.value) return;
			let e = document.activeElement instanceof HTMLElement ? document.activeElement : null, t = e && L.value.some((t) => t.host.contains(e)), n = L.value.some((e) => !e.secondary && I.value.has(e.id)), r = [], i = [], a = !1;
			for (let e of L.value) e.secondary && n && !a && (i.push(F), a = !0), (e.secondary || I.value.has(e.id) ? i : r).push(e.host);
			a || F.remove();
			for (let [e, t] of [[b.value, r], [Ue.value, i]]) {
				let n = e.firstElementChild;
				for (let r of t) r !== n && e.insertBefore(r, n), n = r.nextElementSibling;
			}
			let ee = new Set(L.value.map((e) => e.id));
			for (let [e, t] of P) ee.has(e) || (t.host.remove(), P.delete(e));
			t && e?.isConnected && document.activeElement !== e && (e.getClientRects().length ? e.focus({ preventScroll: !0 }) : x.value?.focus({ preventScroll: !0 }));
		}, wt = () => {
			if (!g.value || !b.value) return;
			let e = L.value.filter((e) => !e.secondary);
			for (let t of e) I.value.has(t.id) || (t.width = t.host.firstElementChild?.getBoundingClientRect().width || t.width);
			Ze.value = e.reduce((e, t) => e + t.width, 0) + (y.value?.scrollWidth || 0) + (lt.value ? 48 : 6) + 4;
			let t = /* @__PURE__ */ new Set();
			if (p(h("IsDynamicOverflowEnabled"))) {
				let n = Math.max(0, g.value.clientWidth - (y.value?.scrollWidth || 0) - (lt.value ? 48 : 6) - 4), r = e.reduce((e, t) => e + t.width, 0), i = [...e].sort((t, n) => (Number(f(t.node.props?.DynamicOverflowOrder)) || Infinity) - (Number(f(n.node.props?.DynamicOverflowOrder)) || Infinity) || e.indexOf(n) - e.indexOf(t));
				for (let a of i) {
					if (r <= n) break;
					let i = Number(f(a.node.props?.DynamicOverflowOrder) || 0), ee = i ? e.filter((e) => Number(f(e.node.props?.DynamicOverflowOrder)) === i) : [a];
					for (let e of ee) t.has(e.id) || (t.add(e.id), r -= e.width);
				}
			}
			(t.size !== I.value.size || [...t].some((e) => !I.value.has(e))) && (U("DynamicOverflowItemsChanging", { Action: t.size > I.value.size ? "AddingToOverflow" : "RemovingFromOverflow" }), I.value = t, s(() => {
				X(), Z();
			}));
		}, Z = async () => {
			if (!g.value || !v.value) return;
			let e = g.value.getBoundingClientRect();
			if (k.value = {
				left: e.left,
				top: e.top,
				width: e.width,
				direction: getComputedStyle(g.value).direction
			}, A.value = Math.max(48, v.value.offsetHeight), !w.value) return;
			let t = E.value && S.value?.offsetHeight || 0, n = S.value?.offsetWidth || 0, r = e.top + A.value;
			O.value = window.innerHeight - r < t + 4 && e.bottom >= A.value + t + 4, Ye.value = {
				left: Math.max(8, Math.min(window.innerWidth - n - 8, e.right - n)),
				top: Math.max(8, Math.min(window.innerHeight - t - 8, O.value ? e.top + j.value - t : r))
			}, D.value = !0;
		};
		async function Q(e) {
			if (e === C.value || e && !it.value || Y) return;
			let t = ++W;
			U(e ? "Opening" : "Closing");
			let n = S.value?.querySelector(".commandbar-secondary-shadow-wrapper"), r = G.length ? {
				clipPath: _.value ? getComputedStyle(_.value).clipPath : void 0,
				contentTransform: v.value ? getComputedStyle(v.value).transform : void 0,
				overflowTransform: n ? getComputedStyle(n).transform : void 0,
				popupTransform: S.value ? getComputedStyle(S.value).transform : void 0,
				overflowClip: S.value ? getComputedStyle(S.value).clipPath : void 0
			} : void 0;
			if (e || ((he(H, document.activeElement) || ge(V)) && x.value?.focus({ preventScroll: !0 }), _e(V), _e(H)), St(), C.value = e, m.IsOpen = e, te(l.IsOpen, e, d), u("update:IsOpen", e), e) {
				if (await Z(), t !== W || Y) return;
				w.value || (Xe.value = k.value.width);
				let e = document.activeElement instanceof HTMLElement && g.value?.contains(document.activeElement) ? document.activeElement : null;
				if (w.value = !0, E.value = z.value.length > 0, D.value = !1, await s(), X(), await Z(), await s(), t !== W || Y) return;
				e?.focus({ preventScroll: !0 });
				let n = Ct(!0, r);
				U("Opened"), await n;
			} else {
				if (S.value?.contains(document.activeElement) && x.value?.focus({ preventScroll: !0 }), await Ct(!1, r), t !== W || Y) return;
				let e = document.activeElement instanceof HTMLElement && He.value?.contains(document.activeElement) ? document.activeElement : null;
				E.value = !1, w.value = !1, D.value = !1, await s(), await Z(), e?.focus({ preventScroll: !0 }), U("Closed");
			}
			t === W && St();
		}
		let Tt = (e) => Array.from(e?.querySelectorAll("button:not(:disabled)") ?? []).filter((e) => e.getClientRects().length), Et = (e, t, n) => {
			let r = n ? ["ArrowUp", "ArrowDown"] : ["ArrowLeft", "ArrowRight"], i = Tt(t);
			if (!i.length || ![
				...r,
				"Home",
				"End"
			].includes(e.key)) return;
			let a = i.indexOf(document.activeElement), ee = !n && getComputedStyle(g.value).direction === "rtl", te = e.key === r[0] ? -1 : 1, ne = e.key === "Home" ? 0 : e.key === "End" ? i.length - 1 : (a + (ee ? -te : te) + i.length) % i.length;
			e.preventDefault(), i[ne].focus({ preventScroll: !0 });
		}, Dt = (e) => {
			if (!(e.defaultPrevented || ge(V))) {
				if (e.key === "Escape" && C.value) {
					e.preventDefault(), Q(!1);
					return;
				}
				if (e.target === x.value && (e.key === "ArrowDown" || e.key === "ArrowUp")) {
					e.preventDefault(), Q(!0).then(() => (e.key === "ArrowUp" ? Tt(S.value).at(-1) : Tt(S.value)[0])?.focus({ preventScroll: !0 }));
					return;
				}
				Et(e, v.value, !1);
			}
		}, Ot = (e) => {
			if (!(e.defaultPrevented || ge(H))) {
				if (e.key === "Escape") {
					e.preventDefault(), e.stopPropagation(), Q(!1);
					return;
				}
				if (e.key === "Tab") {
					Q(!1);
					return;
				}
				Et(e, S.value, !0);
			}
		}, kt = (e) => {
			!C.value || p(h("IsSticky")) || !e.composedPath().includes(g.value) && !he(V, e.target) && !he(H, e.target) && Q(!1);
		}, At = () => {
			p(h("IsSticky")) || Q(!1);
		}, $ = () => {
			J === null && (J = requestAnimationFrame(() => {
				J = null, wt(), Z();
			}));
		};
		for (let e of Object.keys(l)) {
			if (e === "PrimaryCommands" || e === "SecondaryCommands") continue;
			let t = o({
				get: () => e === "IsOpen" ? C.value : h(e),
				set: (t) => {
					if (e === "IsOpen") {
						Q(p(t));
						return;
					}
					m[e] = t, te(l[e], t, d), u(`update:${e}`, t), $();
				}
			});
			Object.defineProperty(B, e, {
				enumerable: !0,
				get: () => t.value,
				set: (e) => {
					t.value = e;
				}
			}), Fe(() => f(l[e]), (t) => {
				delete m[e], e === "IsOpen" ? Q(p(t)) : $();
			});
		}
		for (let e of ["PrimaryCommands", "SecondaryCommands"]) {
			let t = e === "PrimaryCommands" ? M : N;
			Object.defineProperty(B, e, {
				enumerable: !0,
				get: () => t,
				set: (n) => {
					if (!Array.isArray(n) || n.some((e) => !Te(e))) throw TypeError(`${e} requires AppBar command elements`);
					t.splice(0, t.length, ...n), u(`update:${e}`, t);
				}
			}), Fe(() => {
				let t = f(l[e]);
				return Array.isArray(t) ? [...t] : void 0;
			}, (e) => {
				e && t.splice(0, t.length, ...e.filter(Te));
			});
		}
		Fe(() => L.value.map((e) => e.id), async () => {
			await s(), !Y && (X(), $());
		}), Fe(() => z.value.length, async (e) => {
			if (!C.value || Y) return;
			let t = S.value?.contains(document.activeElement);
			if (E.value = e > 0, !e) {
				D.value = !1, t && x.value?.focus({ preventScroll: !0 });
				return;
			}
			await s(), !Y && C.value && (X(), await Z());
		}), Oe(X), De(async () => {
			X(), await s(), wt(), K = new ResizeObserver($), g.value && K.observe(g.value), v.value && K.observe(v.value), y.value && K.observe(y.value), q = new MutationObserver(() => {
				We.value += 1;
			});
			let e = g.value?.closest("[data-theme], .win-theme-scope, .example-theme-wrapper, .theme-light, .theme-dark");
			e && q.observe(e, {
				attributes: !0,
				attributeFilter: ["class", "data-theme"]
			}), e !== document.documentElement && q.observe(document.documentElement, {
				attributes: !0,
				attributeFilter: ["class", "data-theme"]
			}), document.addEventListener("pointerdown", kt, !0), window.addEventListener("resize", $), window.addEventListener("scroll", $, !0), window.addEventListener("blur", At), await Z(), C.value && (C.value = !1, await Q(!0));
		}), Ee(() => {
			_e(V), _e(H), bt(), xt(), Y = !0, W += 1, St(), K?.disconnect(), q?.disconnect(), J !== null && cancelAnimationFrame(J), document.removeEventListener("pointerdown", kt, !0), window.removeEventListener("resize", $), window.removeEventListener("scroll", $, !0), window.removeEventListener("blur", At), P.forEach((e) => e.host.remove());
		}), Object.defineProperty(B, ne, { value: !0 }), Ie(B);
		let jt = {
			props: l,
			emit: u,
			instance: d,
			attrs: Re,
			slots: ze,
			t: Be,
			resolve: f,
			enabled: p,
			overrides: m,
			value: h,
			root: g,
			dismissLayer: Ve,
			overlayRoot: He,
			layoutRoot: _,
			surface: v,
			contentRoot: y,
			primaryRoot: b,
			secondaryRoot: Ue,
			moreButton: x,
			overflowRoot: S,
			isOpen: C,
			surfacePresent: w,
			themeRevision: We,
			inheritedTheme: Ge,
			effectiveTheme: T,
			themeClass: Ke,
			surfaceBackgroundStyle: qe,
			overflowBackgroundStyle: Je,
			overflowPresent: E,
			positioned: D,
			opensUp: O,
			position: Ye,
			anchor: k,
			measuredWidth: Xe,
			desiredWidth: Ze,
			contentHeight: A,
			closedHeight: Qe,
			verticalDelta: j,
			primaryCommands: M,
			secondaryCommands: N,
			declarations: $e,
			initialized: et,
			nodeIds: tt,
			get nextId() {
				return nt;
			},
			set nextId(e) {
				nt = e;
			},
			retainedEntries: P,
			overflowDivider: F,
			overflowIds: I,
			entries: L,
			entryFor: rt,
			isEnabled: it,
			isSticky: at,
			moreLabel: ot,
			defaultLabelPosition: R,
			compact: st,
			overflowNodes: z,
			commandContext: ct,
			showMore: lt,
			automationName: ut,
			barClasses: dt,
			barStyle: ft,
			overlayStyle: pt,
			layoutStyle: mt,
			overflowStyle: ht,
			collectionNodes: gt,
			DeclarationOutlet: _t,
			ContentOutlet: vt,
			api: B,
			inputRegion: yt,
			primaryInputRegion: V,
			secondaryInputRegion: H,
			unregisterPrimaryRegion: bt,
			unregisterSecondaryRegion: xt,
			raise: U,
			get generation() {
				return W;
			},
			set generation(e) {
				W = e;
			},
			get animations() {
				return G;
			},
			set animations(e) {
				G = e;
			},
			get resizeObserver() {
				return K;
			},
			set resizeObserver(e) {
				K = e;
			},
			get themeObserver() {
				return q;
			},
			set themeObserver(e) {
				q = e;
			},
			get frame() {
				return J;
			},
			set frame(e) {
				J = e;
			},
			get unmounted() {
				return Y;
			},
			set unmounted(e) {
				Y = e;
			},
			stopAnimations: St,
			animateDisplayMode: Ct,
			mountCommands: X,
			calculateOverflow: wt,
			positionOverflow: Z,
			setOpen: Q,
			focusable: Tt,
			moveFocus: Et,
			onKeyDown: Dt,
			onOverflowKeyDown: Ot,
			onOutsidePointer: kt,
			onWindowBlur: At,
			scheduleLayout: $,
			get CommandPortal() {
				return oe;
			},
			get vAcrylicBackdrop() {
				return re;
			},
			get vAcrylicBrush() {
				return ie;
			},
			get vThemeShadow() {
				return ae;
			}
		};
		return Object.defineProperty(jt, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), jt;
	}
});
//#endregion
export { Ie as default };

//# sourceMappingURL=CommandBar.vue_vue_type_script_setup_true_lang.js.map