import { resolveXamlHandler as e, resolveXamlValue as t, updateXamlBinding as n, xamlScopeKey as r } from "./xamlRuntime.js";
import i from "../_virtual/_plugin-vue_export-helper.js";
import a from "./TextBlock.vue.js";
/* empty css                                                */
import { Fragment as o, computed as s, createBlock as c, createCommentVNode as l, createElementBlock as u, createElementVNode as d, createTextVNode as f, createVNode as p, getCurrentInstance as m, inject as h, normalizeClass as g, normalizeStyle as _, onBeforeUnmount as v, onMounted as y, openBlock as b, provide as x, ref as S, renderList as C, renderSlot as w, toDisplayString as T, useAttrs as E, watch as D, withCtx as O } from "vue";
//#region src/components/RadioButton.vue
var k = /* @__PURE__ */ new WeakMap(), A = {
	__name: "RadioButton",
	props: {
		Content: {
			type: [String, Number],
			default: ""
		},
		IsChecked: {
			type: [Boolean, String],
			default: void 0
		},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		GroupName: {
			type: String,
			default: ""
		},
		Tag: {
			type: [
				String,
				Number,
				Boolean,
				Object
			],
			default: void 0
		},
		name: {
			type: String,
			default: ""
		},
		Header: {
			type: String,
			default: ""
		},
		ItemsSource: {
			type: [Array, String],
			default: () => []
		},
		SelectedIndex: {
			type: [Number, String],
			default: void 0
		},
		SelectedItem: {
			type: null,
			default: void 0
		},
		MaxColumns: {
			type: [Number, String],
			default: 1
		},
		Margin: {
			type: String,
			default: ""
		},
		value: {
			type: [
				String,
				Number,
				Boolean,
				Object
			],
			default: void 0
		},
		modelValue: {
			type: [
				String,
				Number,
				Boolean,
				Object
			],
			default: void 0
		}
	},
	emits: [
		"update:IsChecked",
		"Checked",
		"Unchecked",
		"update:modelValue",
		"update:SelectedIndex",
		"update:SelectedItem",
		"SelectionChanged"
	],
	setup(i, { expose: o, emit: c }) {
		let l = Symbol.for("WinUIonWeb.RadioButtons"), u = i, d = c, f = `win-radio-buttons-${Math.random().toString(36).slice(2)}`, p = m(), g = E(), _ = S(null), b = h(l, null), C = s(() => {
			let e = t(u.ItemsSource, p);
			return Array.isArray(e) ? e : [];
		}), w = s(() => t(u.Header, p)), T = s(() => t(u.IsEnabled, p) !== !1 && b?.isEnabled?.value !== !1), O = s(() => t(u.IsChecked, p)), A = S(O.value === !0 || u.value !== void 0 && u.modelValue === u.value), j = s(() => {
			let e = t(u.SelectedIndex, p);
			return e === void 0 || e === "" ? void 0 : Number(e);
		}), M = S(j.value ?? -1), N = b?.register?.({
			getItem: () => X,
			isEnabled: () => T.value,
			getBounds: () => _.value?.parentElement?.getBoundingClientRect(),
			focus: () => _.value?.focus()
		}), P = 0, F = (e) => e === "" || e == null ? "" : typeof e == "string" && e.trim() !== "" && !Number.isNaN(Number(e.trim())) ? `${Number(e.trim())}px` : typeof e == "number" ? `${e}px` : e, I = (e) => {
			if (!e) return "";
			let t = String(e).split(",").map((e) => F(Number.isNaN(Number(e.trim())) ? e.trim() : Number(e.trim())));
			return t.length === 1 ? t[0] : t.length === 2 ? `${t[1]} ${t[0]}` : t.length === 4 ? `${t[1]} ${t[2]} ${t[3]} ${t[0]}` : e;
		}, ee = s(() => w.value !== "" || C.value.length > 0 || j.value !== void 0 || u.SelectedItem !== void 0), L = s(() => C.value.map((e) => typeof e == "string" || typeof e == "number" ? {
			Text: String(e),
			Value: e
		} : {
			...e,
			Text: e.Text ?? e.Content ?? e.label ?? String(e),
			Value: e.Value ?? e
		})), R = s(() => j.value ?? M.value), z = `win-radio-parent-${p?.parent?.uid ?? p?.uid}`, B = s(() => b?.name || u.GroupName || u.name || (b ? "" : z)), V = s(() => b && N !== void 0 ? b.selectedIndex.value === N : A.value), H = s(() => {
			let e = t(u.Content, p);
			return e == null ? "" : String(e);
		}), U = s(() => w.value), W = s(() => H.value), G = (e) => {
			let n = t(e, p) === !0;
			if (b && N !== void 0) n ? b.select(N, !1) : V.value && b.select(-1, !1);
			else {
				if (n && K) for (let e of q.get(K) ?? []) e !== J && e.setChecked(!1);
				A.value = n;
			}
		}, K = "", q = k.get(p.appContext);
		q || (q = /* @__PURE__ */ new Map(), k.set(p.appContext, q));
		let J = { setChecked: G }, Y = () => {
			let e = q.get(K);
			e?.delete(J), e?.size === 0 && q.delete(K), K = "";
		};
		D(B, (e) => {
			if (Y(), b || !e) return;
			K = e;
			let t = q.get(e);
			t || (t = /* @__PURE__ */ new Set(), q.set(e, t)), t.add(J), A.value && G(!0);
		}, { immediate: !0 });
		let X = {
			get Name() {
				return String(g["data-xaml-ref"] ?? g["x:Name"] ?? "");
			},
			get Tag() {
				return t(u.Tag, p);
			},
			get Content() {
				return H.value;
			},
			get IsChecked() {
				return V.value;
			},
			set IsChecked(e) {
				G(e);
			},
			get IsEnabled() {
				return T.value;
			},
			get GroupName() {
				return B.value;
			}
		}, Z = s(() => u.Margin ? { margin: I(t(u.Margin, p)) } : {}), te = s(() => {
			let e = Math.max(1, Number(u.MaxColumns) || 1);
			return e > 1 ? { gridTemplateColumns: `repeat(${e}, max-content)` } : { gridTemplateColumns: "max-content" };
		}), ne = () => {
			!T.value || V.value || (b && N !== void 0 ? b.select(N) : G(!0));
		};
		D(O, (e) => {
			e !== void 0 && G(e);
		}), D(() => u.modelValue, (e) => {
			u.value !== void 0 && G(e === u.value);
		}), D(V, (t, r) => {
			if (t === r) return;
			d("update:IsChecked", t), n(u.IsChecked, t, p);
			let i = t ? "Checked" : "Unchecked", a = {
				OriginalSource: X,
				RoutedEvent: i
			};
			d(i, X, a), e(g[i], p)?.(X, a), t && u.value !== void 0 && d("update:modelValue", u.value);
		}, { flush: "sync" }), y(() => {
			b && N !== void 0 && O.value === !0 && b.selectedIndex.value < 0 && (b.initialize ? b.initialize(N) : b.select(N));
		}), v(() => {
			b?.unregister?.(N), Y();
		});
		let Q = (t) => {
			if (!T.value) return;
			let n = L.value[R.value], r = L.value[t];
			M.value = t, d("update:SelectedIndex", t), d("update:SelectedItem", r?.Value ?? r);
			let i = {
				SelectedIndex: t,
				SelectedItem: r?.Value ?? r,
				AddedItems: r ? [r.Value ?? r] : [],
				RemovedItems: n ? [n.Value ?? n] : []
			};
			d("SelectionChanged", i), e(g.SelectionChanged, p)?.(i);
		};
		x(r, {
			RadioButtonsHeader: U,
			RadioContent: W
		}), x(l, {
			selectedIndex: R,
			register: () => P++,
			select: Q
		}), o({
			Name: s(() => X.Name),
			IsChecked: s({
				get: () => V.value,
				set: G
			}),
			Content: H,
			Tag: s(() => t(u.Tag, p)),
			IsEnabled: T,
			GroupName: B
		});
		let $ = {
			namedRadioGroups: k,
			radioButtonsGroupKey: l,
			props: u,
			emit: d,
			groupName: f,
			instance: p,
			attrs: g,
			radioInput: _,
			group: b,
			resolvedItemsSource: C,
			resolvedHeader: w,
			resolvedIsEnabled: T,
			resolvedIsChecked: O,
			localChecked: A,
			resolvedSelectedIndex: j,
			internalSelectedIndex: M,
			groupIndex: N,
			get nextSlotIndex() {
				return P;
			},
			set nextSlotIndex(e) {
				P = e;
			},
			cssLength: F,
			xamlThickness: I,
			isGroup: ee,
			normalizedItems: L,
			selectedIndexValue: R,
			defaultGroupName: z,
			radioGroupName: B,
			resolvedChecked: V,
			contentText: H,
			RadioButtonsHeader: U,
			RadioContent: W,
			setChecked: G,
			get registeredNamedGroup() {
				return K;
			},
			set registeredNamedGroup(e) {
				K = e;
			},
			get appRadioGroups() {
				return q;
			},
			set appRadioGroups(e) {
				q = e;
			},
			namedMember: J,
			unregisterNamedGroup: Y,
			eventSender: X,
			rootStyle: Z,
			itemsStyle: te,
			check: ne,
			select: Q,
			computed: s,
			getCurrentInstance: m,
			inject: h,
			onBeforeUnmount: v,
			onMounted: y,
			provide: x,
			ref: S,
			useAttrs: E,
			watch: D,
			TextBlock: a,
			get resolveXamlHandler() {
				return e;
			},
			get resolveXamlValue() {
				return t;
			},
			get updateXamlBinding() {
				return n;
			},
			get xamlScopeKey() {
				return r;
			}
		};
		return Object.defineProperty($, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), $;
	}
}, j = [
	"checked",
	"disabled",
	"onChange"
], M = [
	"name",
	"checked",
	"disabled",
	"tabindex"
];
function N(e, t, n, r, i, a) {
	return r.isGroup ? (b(), u("div", {
		key: 0,
		class: g(["win-radio-buttons", { "is-disabled": !r.resolvedIsEnabled }]),
		style: _(r.rootStyle)
	}, [r.resolvedHeader ? (b(), c(r.TextBlock, {
		key: 0,
		class: "win-radio-buttons-header",
		Text: "{x:Bind RadioButtonsHeader}"
	})) : l("", !0), d("div", {
		class: "win-radio-buttons-items",
		style: _(r.itemsStyle)
	}, [(b(!0), u(o, null, C(r.normalizedItems, (e, n) => (b(), u("label", {
		key: n,
		class: g(["win-radio-button", {
			"is-checked": r.selectedIndexValue === n,
			"is-disabled": !r.resolvedIsEnabled
		}])
	}, [
		d("input", {
			class: "win-radio-input",
			type: "radio",
			name: r.groupName,
			checked: r.selectedIndexValue === n,
			disabled: !r.resolvedIsEnabled,
			onChange: (e) => r.select(n)
		}, null, 40, j),
		t[1] ||= d("span", {
			class: "win-radio-glyph",
			"aria-hidden": "true"
		}, [d("span", { class: "win-radio-check" })], -1),
		p(r.TextBlock, { class: "win-radio-content" }, {
			default: O(() => [f(T(e.Text), 1)]),
			_: 2
		}, 1024)
	], 2))), 128)), r.normalizedItems.length === 0 ? w(e.$slots, "default", { key: 0 }) : l("", !0)], 4)], 6)) : (b(), u("label", {
		key: 1,
		class: g(["win-radio-button", {
			"is-checked": r.resolvedChecked,
			"is-disabled": !r.resolvedIsEnabled
		}]),
		style: _(r.rootStyle)
	}, [
		d("input", {
			ref: "radioInput",
			class: "win-radio-input",
			type: "radio",
			name: r.radioGroupName || void 0,
			checked: r.resolvedChecked,
			disabled: !r.resolvedIsEnabled,
			tabindex: r.group?.tabIndex ? r.group.tabIndex(r.groupIndex) : void 0,
			onChange: r.check,
			onKeydown: t[0] ||= (e) => r.group?.navigate?.(r.groupIndex, e)
		}, null, 40, M),
		t[2] ||= d("span", {
			class: "win-radio-glyph",
			"aria-hidden": "true"
		}, [d("span", { class: "win-radio-check" })], -1),
		e.$slots.default ? (b(), c(r.TextBlock, {
			key: 0,
			class: "win-radio-content"
		}, {
			default: O(() => [w(e.$slots, "default")]),
			_: 3
		})) : (b(), c(r.TextBlock, {
			key: 1,
			class: "win-radio-content",
			Text: "{x:Bind RadioContent}"
		}))
	], 6));
}
var P = /*#__PURE__*/ i(A, [["render", N], ["__file", "RadioButton.vue"]]);
//#endregion
export { P as default };

//# sourceMappingURL=RadioButton.vue.js.map