import { reactive as e } from "vue";
//#region src/components/refreshRuntime.ts
var t = Symbol("WinUIonWeb.refreshContext"), n = .8, r = (e) => e === "TopToBottom" || e === "BottomToTop", i = (e) => e === "BottomToTop" || e === "RightToLeft", a = (e, t) => {
	let n = 1, r = !1, i = () => {
		--n, !(n > 0 || r) && (r = !0, t());
	}, a = { GetDeferral: () => {
		n += 1;
		let e = !1;
		return { Complete: () => {
			e || (e = !0, i());
		} };
	} };
	try {
		e(a);
	} finally {
		i();
	}
}, o = (t = {}) => {
	let n = e({
		pullDirection: t.pullDirection ?? "TopToBottom",
		state: "Idle",
		executionRatio: t.executionRatio ?? 1,
		visualizerSize: 100,
		visualizerRootSize: 100,
		visualizerHandle: null
	});
	return n.publishInteractionRatio = (e) => {
		n.visualizerHandle?.setInteractionRatio(e);
	}, n.publishIsInteractingForRefresh = (e) => {
		n.visualizerHandle?.setIsInteractingForRefresh(e);
	}, n.containerRefreshRequested = null, n.containerStateChanged = null, n;
};
//#endregion
export { n as DEFAULT_EXECUTION_RATIO, o as createRefreshContext, i as isFarPull, r as isVerticalPull, a as raiseRefreshRequested, t as refreshContextKey };

//# sourceMappingURL=refreshRuntime.js.map