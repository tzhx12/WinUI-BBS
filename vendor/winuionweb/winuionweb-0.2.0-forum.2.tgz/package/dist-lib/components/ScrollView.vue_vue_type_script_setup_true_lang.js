import { boolValue as e, xamlThickness as t } from "./layout.js";
import { uiSettings as n } from "./uiSettings.js";
import { useAcrylicBrushStyle as r } from "./AcrylicBrush.js";
import { resolveXamlHandler as i, resolveXamlValue as a, updateXamlBinding as o, xamlNameScopeKey as s, xamlScopeKey as c } from "./xamlRuntime.js";
import { vAcrylicBrush as l } from "./acrylicBrushVisual.js";
import u from "./Grid.vue.js";
import { scrollBarOwnerKey as d } from "./scrollBarOwner.js";
import ee from "./ScrollBar.vue.js";
import te from "./ColumnDefinition.vue.js";
import ne from "./RowDefinition.vue.js";
import { Fragment as re, cloneVNode as ie, computed as f, defineComponent as ae, getCurrentInstance as oe, h as se, inject as ce, nextTick as le, onBeforeUnmount as ue, onMounted as de, provide as fe, reactive as pe, ref as p, shallowReactive as me, unref as he, useAttrs as ge, useSlots as _e, watch as m, withDirectives as ve } from "vue";
//#region src/components/ScrollView.vue?vue&type=script&setup=true&lang.ts
var ye = /*@__PURE__*/ ae({
	inheritAttrs: !1,
	__name: "ScrollView",
	props: {
		Content: {},
		ContentOrientation: { default: "Vertical" },
		HorizontalScrollBarVisibility: { default: "Auto" },
		VerticalScrollBarVisibility: { default: "Auto" },
		HorizontalScrollChainMode: { default: "Auto" },
		VerticalScrollChainMode: { default: "Auto" },
		ZoomChainMode: { default: "Auto" },
		HorizontalScrollRailMode: { default: "Enabled" },
		VerticalScrollRailMode: { default: "Enabled" },
		HorizontalScrollMode: { default: "Auto" },
		VerticalScrollMode: { default: "Auto" },
		ZoomMode: { default: "Disabled" },
		IgnoredInputKinds: { default: "None" },
		MinZoomFactor: { default: .1 },
		MaxZoomFactor: { default: 10 },
		HorizontalAnchorRatio: { default: 0 },
		VerticalAnchorRatio: { default: 0 },
		IsTabStop: {
			type: [Boolean, String],
			default: !1
		},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		Width: { default: "" },
		Height: { default: "" },
		MinWidth: { default: 0 },
		MinHeight: { default: 0 },
		MaxWidth: { default: "" },
		MaxHeight: { default: "" },
		HorizontalAlignment: { default: "Stretch" },
		VerticalAlignment: { default: "Stretch" },
		Background: { default: "Transparent" },
		BorderBrush: { default: "" },
		BorderThickness: { default: 0 },
		CornerRadius: { default: "{ThemeResource ControlCornerRadius}" },
		Padding: { default: 0 },
		Margin: { default: 0 }
	},
	emits: [
		"ExtentChanged",
		"StateChanged",
		"ViewChanged",
		"ScrollAnimationStarting",
		"ZoomAnimationStarting",
		"ScrollCompleted",
		"ZoomCompleted",
		"ScrollStarting",
		"ZoomStarting",
		"AnchorRequested",
		"BringingIntoView",
		"Loaded"
	],
	setup(ye, { expose: be, emit: xe }) {
		let Se = ye, Ce = xe, h = oe(), we = ge(), Te = f(() => Object.fromEntries(Object.entries(we).filter(([e]) => !/^(?:x:Name|ExtentChanged|StateChanged|ViewChanged|ScrollAnimationStarting|ZoomAnimationStarting|ScrollCompleted|ZoomCompleted|ScrollStarting|ZoomStarting|AnchorRequested|BringingIntoView|Loaded)$/i.test(e)))), Ee = _e(), De = ce(c, {}), Oe = pe({}), ke = f(() => Object.fromEntries(Object.entries(Se).map(([e, t]) => [e, e in Oe ? Oe[e] : a(t, h)]))), g = (e) => ke.value[e], _ = f(() => e(g("IsEnabled"))), v = p(null), y = p(null), b = p(null), x = pe({
			ViewportWidth: 0,
			ViewportHeight: 0,
			ExtentWidth: 0,
			ExtentHeight: 0,
			HorizontalOffset: 0,
			VerticalOffset: 0
		}), S = p(1), C = p("Idle"), Ae = p(null), je = /* @__PURE__ */ new Set(), w = f(() => Math.max(0, x.ExtentWidth * S.value - x.ViewportWidth)), T = f(() => Math.max(0, x.ExtentHeight * S.value - x.ViewportHeight)), E = (e) => {
			let t = String(g(`${e}ScrollMode`));
			return t === "Auto" ? g("ZoomMode") === "Enabled" || (e === "Horizontal" ? w.value : T.value) > 0 ? "Enabled" : "Disabled" : t;
		}, Me = (e) => g(`${e}ScrollBarVisibility`) === "Hidden" ? "Collapsed" : g(`${e}ScrollBarVisibility`) === "Visible" || (e === "Horizontal" ? w.value : T.value) > 0 ? "Visible" : "Collapsed", Ne = f(() => Me("Horizontal")), Pe = f(() => Me("Vertical")), D = p("NoIndicator"), Fe = f(() => {
			x.HorizontalOffset, x.VerticalOffset, x.ViewportWidth, x.ViewportHeight, x.ExtentWidth, x.ExtentHeight, S.value;
			let e = v.value;
			return {
				Vertical: {
					Maximum: Math.max(0, (e?.scrollHeight ?? 0) - (e?.clientHeight ?? 0)),
					ViewportSize: e?.clientHeight ?? 0,
					Value: x.VerticalOffset
				},
				Horizontal: {
					Maximum: Math.max(0, (e?.scrollWidth ?? 0) - (e?.clientWidth ?? 0)),
					ViewportSize: e?.clientWidth ?? 0,
					Value: x.HorizontalOffset
				},
				IndicatorMode: D.value === "TouchIndicator" ? "TouchIndicator" : n.AutoHideScrollBars ? D.value === "NoIndicator" ? "None" : D.value : "MouseIndicator"
			};
		}), Ie = (e, t) => {
			W(x.HorizontalOffset, t.NewValue), t.ScrollEventType === "EndScroll" && z("Idle");
		}, Le = (e, t) => {
			W(t.NewValue, x.VerticalOffset), t.ScrollEventType === "EndScroll" && z("Idle");
		};
		fe(d, {
			autoHide: () => n.AutoHideScrollBars,
			onHover: (e, t) => {
				O.value = t ? e : "", t || B();
			},
			onPointerActivity: (e) => {
				A = e, B();
			},
			onInteraction: (e, t) => {
				k.value = t ? e : "", t ? (H(!0), z("Interaction")) : (z("Idle"), B());
			}
		});
		let O = p(""), k = p(""), A = "mouse", j, M, N, P, F = 0, I = 0, Re = 0, L = null, ze = new Proxy({}, {
			get: (e, t) => he(Q[t]),
			set: (e, t, n) => {
				let r = Q[t];
				return r && typeof r == "object" && "value" in r ? r.value = n : Q[t] = n, !0;
			}
		}), R = (e, t = {}) => {
			Ce(e, ze, t), we[`on${e}`] || i(we[e], h)?.(ze, t);
		}, z = (e) => {
			C.value !== e && (C.value = e, R("StateChanged"));
		}, B = (e = A === "touch" ? "TouchIndicator" : "MouseIndicator") => {
			if (j && clearTimeout(j), j = void 0, !_.value) {
				D.value = "NoIndicator";
				return;
			}
			if (!n.AutoHideScrollBars) {
				D.value = "MouseIndicator";
				return;
			}
			D.value = e === "MouseIndicator" || D.value === "MouseIndicator" ? "MouseIndicator" : e;
			let t = () => {
				j = setTimeout(() => {
					if (j = void 0, O.value || k.value || C.value === "Interaction") {
						t();
						return;
					}
					D.value = "NoIndicator";
				}, D.value === "TouchIndicator" ? 500 : 2e3);
			};
			!O.value && !k.value && t();
		}, Be = (e) => {
			e.pointerType !== "touch" && (A = e.pointerType || "mouse", B("MouseIndicator"));
		}, Ve = (e) => {
			e.pointerType !== "touch" && _.value && (A = e.pointerType || "mouse", B("MouseIndicator"));
		}, He = (e) => {
			e.pointerType !== "touch" && (O.value = "", B("MouseIndicator"));
		}, V = (e) => {
			if (!_.value) return !0;
			let t = g("IgnoredInputKinds");
			return typeof t == "number" ? (t & {
				Touch: 1,
				Pen: 2,
				MouseWheel: 4,
				Keyboard: 8
			}[e]) !== 0 : String(t).split(/[ ,|]+/).some((t) => t === e || t === "All");
		}, H = (e = !1) => {
			F && cancelAnimationFrame(F), F = 0;
			let t = L;
			L = null, z("Idle"), t && R(t.Kind === "Scroll" ? "ScrollCompleted" : "ZoomCompleted", { CorrelationId: t.Id });
		}, U = (e, t) => (H(!0), L = {
			Id: ++Re,
			Kind: e
		}, z(t), L.Id), Ue = () => {
			let e = v.value;
			if (!e) return !1;
			let t = e.scrollLeft, n = e.scrollTop, r = Math.abs(x.HorizontalOffset - t) > .001 || Math.abs(x.VerticalOffset - n) > .001;
			return x.HorizontalOffset = t, x.VerticalOffset = n, r;
		}, W = (e, t) => {
			let n = v.value;
			if (!n) return;
			let r = Math.max(0, n.scrollWidth - n.clientWidth), i = Math.max(0, n.scrollHeight - n.clientHeight), a = (e, t) => Math.abs(t - e) < .5 ? t : Math.max(0, Math.min(t, e));
			n.scrollLeft = a(Number.isFinite(e) ? e : x.HorizontalOffset, r), n.scrollTop = a(Number.isFinite(t) ? t : x.VerticalOffset, i), Ue() && (R("ViewChanged"), B());
		}, We = () => {
			let e = v.value?.getBoundingClientRect();
			if (!e) return;
			let t = {
				x: e.left + e.width * Number(g("HorizontalAnchorRatio")),
				y: e.top + e.height * Number(g("VerticalAnchorRatio"))
			}, n = Array.from(je).filter((e) => e.isConnected && y.value?.contains(e)), r = Infinity, i = null;
			for (let e of n) {
				let n = e.getBoundingClientRect(), a = (n.left - t.x) ** 2 + (n.top - t.y) ** 2;
				a < r && (i = e, r = a);
			}
			let a = {
				AnchorCandidates: n,
				AnchorElement: i
			};
			R("AnchorRequested", a), Ae.value = a.AnchorElement instanceof Element ? a.AnchorElement : i;
		}, Ge = () => {
			if (!v.value || !y.value) return;
			let e = x.ExtentWidth, t = x.ExtentHeight;
			x.ViewportWidth = v.value.clientWidth, x.ViewportHeight = v.value.clientHeight, x.ExtentWidth = y.value.offsetWidth, x.ExtentHeight = y.value.offsetHeight, (e !== x.ExtentWidth || t !== x.ExtentHeight) && (R("ExtentChanged"), We()), W(x.HorizontalOffset, x.VerticalOffset);
		}, Ke = () => {
			I ||= requestAnimationFrame(() => {
				I = 0, Ge();
			});
		}, G = (e) => Math.max(Math.max(.01, Number(g("MinZoomFactor"))), Math.min(Math.max(Number(g("MinZoomFactor")), Number(g("MaxZoomFactor"))), e)), K = (e, t, n = S.value, r = {
			x: x.HorizontalOffset,
			y: x.VerticalOffset
		}) => {
			let i = G(e);
			i !== S.value && (S.value = i, b.value && (b.value.style.width = `${Math.max(x.ViewportWidth, x.ExtentWidth * i)}px`, b.value.style.height = `${Math.max(x.ViewportHeight, x.ExtentHeight * i)}px`), y.value && (y.value.style.transform = `scale(${i})`), W((r.x + t.x) * i / n - t.x, (r.y + t.y) * i / n - t.y), R("ViewChanged"));
		}, qe = (e, t, n) => {
			let r = (e, t, n) => 3 * e * (1 - n) ** 2 * n + 3 * t * (1 - n) * n ** 2 + n ** 3, i = 0, a = 1, o = n;
			for (let s = 0; s < 16; s++) {
				let s = r(e.x, t.x, o);
				if (Math.abs(s - n) < 1e-5) break;
				s < n ? i = o : a = o, o = (i + a) / 2;
			}
			return r(e.y, t.y, o);
		}, Je = (e, t) => t?.Type === "Step" ? Math.floor(e * t.StepCount) / t.StepCount : qe(t?.ControlPoint1 ?? {
			x: .1,
			y: .9
		}, t?.ControlPoint2 ?? {
			x: .2,
			y: 1
		}, e), Ye = {
			CreateVector3KeyFrameAnimation: () => Xe(),
			CreateScalarKeyFrameAnimation: () => Xe(),
			CreateCubicBezierEasingFunction: (e, t) => ({
				Type: "CubicBezier",
				ControlPoint1: e,
				ControlPoint2: t
			}),
			CreateStepEasingFunction: (e = 1) => ({
				Type: "Step",
				StepCount: e
			})
		}, Xe = () => ({
			Duration: 250,
			KeyFrames: [],
			Compositor: Ye,
			InsertKeyFrame(e, t, n) {
				this.KeyFrames.push({
					Progress: e,
					Value: t,
					EasingFunction: n
				}), this.KeyFrames.sort((e, t) => e.Progress - t.Progress);
			}
		}), Ze = (e, t, n) => {
			let r = [{
				Progress: 0,
				Value: n
			}, ...e.KeyFrames], i = r.findIndex((e) => e.Progress >= t), a = r[i < 0 ? r.length - 1 : Math.max(1, i)], o = r[i < 0 ? r.length - 1 : Math.max(0, i - 1)], s = Je(Math.min(1, Math.max(0, (t - o.Progress) / Math.max(1e-6, a.Progress - o.Progress))), a.EasingFunction);
			if (typeof a.Value == "number" && typeof o.Value == "number") return o.Value + (a.Value - o.Value) * s;
			let c = o.Value, l = a.Value;
			return {
				x: c.x + (l.x - c.x) * s,
				y: c.y + (l.y - c.y) * s
			};
		}, Qe = (e) => e?.AnimationMode !== "Disabled" && (e?.AnimationMode === "Enabled" || !window.matchMedia("(prefers-reduced-motion: reduce)").matches), $e = (e, t, n) => {
			if (!v.value || !Number.isFinite(e) || !Number.isFinite(t)) return -1;
			let r = {
				x: x.HorizontalOffset,
				y: x.VerticalOffset
			}, i = {
				x: Math.max(0, Math.min(w.value, e)),
				y: Math.max(0, Math.min(T.value, t))
			}, a = U("Scroll", Qe(n) ? "Animation" : "Idle");
			if (R("ScrollStarting", {
				CorrelationId: a,
				HorizontalOffset: i.x,
				VerticalOffset: i.y
			}), !Qe(n) || r.x === i.x && r.y === i.y) return W(i.x, i.y), queueMicrotask(() => {
				L?.Id === a && H();
			}), a;
			let o = Xe();
			o.Duration = Math.min(1e3, Math.max(50, Math.hypot(i.x - r.x, i.y - r.y) * 5)), o.InsertKeyFrame(1, i);
			let s = {
				CorrelationId: a,
				StartPosition: r,
				EndPosition: i,
				Animation: o
			};
			R("ScrollAnimationStarting", s);
			let c = performance.now(), l = (e) => {
				if (L?.Id !== a) return;
				let t = Math.min(1, (e - c) / Math.max(1, Number(s.Animation.Duration))), n = Ze(s.Animation, t, r);
				W(n.x, n.y), t < 1 ? F = requestAnimationFrame(l) : (W(i.x, i.y), H());
			};
			return F = requestAnimationFrame(l), a;
		}, et = (e, t, n) => $e(x.HorizontalOffset + e, x.VerticalOffset + t, n), tt = (e, t, n) => {
			if (!v.value || !Number.isFinite(e)) return -1;
			let r = t ?? {
				x: x.ViewportWidth / 2,
				y: x.ViewportHeight / 2
			}, i = S.value, a = G(e), o = {
				x: x.HorizontalOffset,
				y: x.VerticalOffset
			}, s = U("Zoom", Qe(n) ? "Animation" : "Idle");
			if (R("ZoomStarting", {
				CorrelationId: s,
				ZoomFactor: a,
				CenterPoint: r
			}), !Qe(n) || a === i) return K(a, r, i, o), queueMicrotask(() => {
				L?.Id === s && H();
			}), s;
			let c = Xe();
			c.Duration = Math.min(1e3, Math.max(50, Math.abs(a - i) * 250)), c.InsertKeyFrame(1, a);
			let l = {
				CorrelationId: s,
				CenterPoint: r,
				StartZoomFactor: i,
				EndZoomFactor: a,
				Animation: c
			};
			R("ZoomAnimationStarting", l);
			let u = performance.now(), d = (e) => {
				if (L?.Id !== s) return;
				let t = Math.min(1, (e - u) / Math.max(1, Number(l.Animation.Duration)));
				K(Ze(l.Animation, t, i), r, i, o), t < 1 ? F = requestAnimationFrame(d) : H();
			};
			return F = requestAnimationFrame(d), s;
		}, nt = (e, t, n) => tt(S.value + e, t, n), rt = (e) => Array.isArray(e) ? {
			x: e[0],
			y: e[1]
		} : e, it = (e, t) => {
			if (!v.value) return -1;
			let n = rt(e), r = t ? rt(t) : {
				x: .9995,
				y: .9995
			}, i = Math.sign(n.x) * Math.max(0, Math.abs(n.x) - 30), a = Math.sign(n.y) * Math.max(0, Math.abs(n.y) - 30), o = U("Scroll", "Inertia"), s = performance.now(), c = (e) => {
				if (L?.Id !== o) return;
				let t = Math.min(50, e - s);
				s = e;
				let n = x.HorizontalOffset, l = x.VerticalOffset;
				W(n + i * t / 1e3, l + a * t / 1e3), i *= r.x === 0 ? 1 : r.x ** +t, a *= r.y === 0 ? 1 : r.y ** +t, Math.abs(i) < .1 && Math.abs(a) < .1 || x.HorizontalOffset === n && x.VerticalOffset === l ? H() : F = requestAnimationFrame(c);
			};
			return F = requestAnimationFrame(c), o;
		}, at = (e, t, n = .995) => {
			let r = t ?? {
				x: x.ViewportWidth / 2,
				y: x.ViewportHeight / 2
			}, i = U("Zoom", "Inertia"), a = e, o = performance.now(), s = (e) => {
				if (L?.Id !== i) return;
				let t = Math.min(50, e - o);
				o = e;
				let c = S.value;
				K(c + a * t / 1e3, r), a *= n ** +t, Math.abs(a) < .001 || S.value === c ? H() : F = requestAnimationFrame(s);
			};
			return F = requestAnimationFrame(s), i;
		}, ot = () => {
			M && clearTimeout(M), M = setTimeout(() => {
				!L && !q.size && !k.value && z("Idle");
			}, 120);
		}, st = () => {
			Ue() && (L || z("Interaction"), R("ViewChanged"), B(), ot());
		}, ct = (e) => {
			if (V("MouseWheel")) {
				e.preventDefault();
				return;
			}
			A = "mouse";
			let t = v.value?.getBoundingClientRect();
			if (e.ctrlKey && g("ZoomMode") === "Enabled" && t) {
				H(!0), z("Interaction"), K(S.value * Math.exp(-e.deltaY / 300), {
					x: e.clientX - t.left,
					y: e.clientY - t.top
				}), B(), e.preventDefault(), ot();
				return;
			}
			H(!0);
			let n = e.deltaMode === 1 ? 16 : e.deltaMode === 2 ? x.ViewportHeight : 1, r = E("Horizontal") === "Enabled" ? (e.shiftKey ? e.deltaY : e.deltaX) * n : 0, i = E("Vertical") === "Enabled" ? (e.shiftKey ? 0 : e.deltaY) * n : 0, a = {
				x: x.HorizontalOffset,
				y: x.VerticalOffset
			};
			z("Interaction"), W(a.x + r, a.y + i), ot(), (a.x !== x.HorizontalOffset || a.y !== x.VerticalOffset || r !== 0 && g("HorizontalScrollChainMode") === "Never" || i !== 0 && g("VerticalScrollChainMode") === "Never") && e.preventDefault();
		}, q = /* @__PURE__ */ new Map(), lt = (e, t) => {
			try {
				e?.setPointerCapture(t);
			} catch {}
		}, J = null, Y = null, X = null, ut = (e) => {
			if (A = e.pointerType || "mouse", e.pointerType === "touch" && (O.value = ""), B(), !(e.pointerType !== "touch" && e.pointerType !== "pen" || V(e.pointerType === "pen" ? "Pen" : "Touch"))) {
				if (H(!0), q.set(e.pointerId, {
					x: e.clientX,
					y: e.clientY
				}), J = {
					x: e.clientX,
					y: e.clientY
				}, Y = null, z("Interaction"), B(), lt(v.value, e.pointerId), q.size === 2 && g("ZoomMode") === "Enabled") {
					let [e, t] = Array.from(q.values()), n = v.value.getBoundingClientRect();
					X = {
						distance: Math.hypot(t.x - e.x, t.y - e.y),
						zoom: S.value,
						offsets: {
							x: x.HorizontalOffset,
							y: x.VerticalOffset
						},
						center: {
							x: (e.x + t.x) / 2 - n.left,
							y: (e.y + t.y) / 2 - n.top
						}
					};
				}
				e.preventDefault();
			}
		}, dt = (e) => {
			if (q.has(e.pointerId)) {
				if (q.set(e.pointerId, {
					x: e.clientX,
					y: e.clientY
				}), X && q.size === 2) {
					let [e, t] = Array.from(q.values());
					K(X.zoom * Math.hypot(t.x - e.x, t.y - e.y) / Math.max(1, X.distance), X.center, X.zoom, X.offsets);
				} else if (J) {
					let t = J.x - e.clientX, n = J.y - e.clientY;
					!Y && Math.hypot(t, n) > 3 && (Y = Math.abs(t) > Math.abs(n) ? "Horizontal" : "Vertical"), W(x.HorizontalOffset + (E("Horizontal") === "Enabled" && !(Y === "Vertical" && g("HorizontalScrollRailMode") === "Enabled") ? t : 0), x.VerticalOffset + (E("Vertical") === "Enabled" && !(Y === "Horizontal" && g("VerticalScrollRailMode") === "Enabled") ? n : 0)), J = {
						x: e.clientX,
						y: e.clientY
					};
				}
				e.preventDefault();
			}
		}, Z = (e) => {
			if (e) {
				if (!q.has(e.pointerId)) return;
				q.delete(e.pointerId), v.value?.hasPointerCapture(e.pointerId) && v.value.releasePointerCapture(e.pointerId);
			} else q.clear();
			X = null, J = q.size ? Array.from(q.values())[0] : null, q.size || (z("Idle"), B());
		}, ft = (e) => {
			if (V("Keyboard") || e.target !== v.value) return;
			let t = x.HorizontalOffset, n = x.VerticalOffset, r = t, i = n;
			if (e.ctrlKey && g("ZoomMode") === "Enabled" && [
				"+",
				"=",
				"-",
				"0"
			].includes(e.key)) {
				tt(e.key === "0" ? 1 : S.value * (e.key === "-" ? .9 : 1.1)), e.preventDefault();
				return;
			}
			if (e.key === "ArrowDown") i += 16;
			else if (e.key === "ArrowUp") i -= 16;
			else if (e.key === "ArrowRight") r += 16;
			else if (e.key === "ArrowLeft") r -= 16;
			else if (e.key === "PageDown") i += x.ViewportHeight;
			else if (e.key === "PageUp") i -= x.ViewportHeight;
			else if (e.key === "Home") i = 0, e.ctrlKey && (r = 0);
			else if (e.key === "End") i = T.value, e.ctrlKey && (r = w.value);
			else return;
			$e(E("Horizontal") === "Enabled" ? r : t, E("Vertical") === "Enabled" ? i : n), e.preventDefault();
		}, pt = (e) => {
			if (!(e.target instanceof HTMLElement) || e.target === v.value || !v.value) return;
			let t = e.target.getBoundingClientRect(), n = v.value.getBoundingClientRect(), r = {
				TargetElement: e.target,
				Cancel: !1,
				HorizontalOffset: x.HorizontalOffset + (t.left < n.left ? t.left - n.left : t.right > n.right ? t.right - n.right : 0),
				VerticalOffset: x.VerticalOffset + (t.top < n.top ? t.top - n.top : t.bottom > n.bottom ? t.bottom - n.bottom : 0)
			};
			R("BringingIntoView", r), r.Cancel || W(r.HorizontalOffset, r.VerticalOffset);
		}, mt = (e) => e.map((e) => {
			if (!e || typeof e != "object") return e;
			let t = ["Vertical", "Both"].includes(String(g("ContentOrientation"))), n = e.type, r = t && x.ViewportWidth > 0 && (n?.__name === "Image" || n?.name === "Image") && !e.props?.Width ? ie(e, { MaxWidth: Math.min(x.ViewportWidth, Number(e.props?.MaxWidth) || Infinity) }) : ie(e);
			if (e.type === re && Array.isArray(e.children)) r.children = mt(e.children);
			else if (e.children && typeof e.children == "object" && !Array.isArray(e.children)) {
				let t = e.children;
				r.children = {
					...t,
					...typeof t.default == "function" ? { default: (...e) => mt(t.default(...e)) } : {}
				};
			}
			return r;
		}), ht = ae({
			name: "ScrollPresenter",
			inheritAttrs: !1,
			setup(n, { attrs: i }) {
				let a = r(() => g("Background"), h);
				return () => ve(se("div", {
					ref: v,
					class: ["win-scroll-presenter", `content-orientation-${String(g("ContentOrientation")).toLowerCase()}`],
					"data-template-part": "PART_ScrollPresenter",
					"Grid.ColumnSpan": 2,
					"Grid.RowSpan": 2,
					"data-xaml-ref": i["data-xaml-ref"],
					tabindex: _.value && e(g("IsTabStop")) ? 0 : -1,
					style: {
						...a.value,
						margin: t(g("Padding")),
						touchAction: V("Touch") ? "auto" : "none"
					},
					onScroll: st,
					onWheel: ct,
					onPointerdown: ut,
					onPointermove: dt,
					onPointerup: Z,
					onPointercancel: Z,
					onLostpointercapture: Z,
					onKeydown: ft,
					onFocusin: pt
				}, [se("div", {
					ref: b,
					class: "scroll-surface",
					style: {
						width: `${Math.max(x.ViewportWidth, x.ExtentWidth * S.value)}px`,
						height: `${Math.max(x.ViewportHeight, x.ExtentHeight * S.value)}px`
					}
				}, [se("div", {
					ref: y,
					class: "scroll-content",
					style: {
						transform: `scale(${S.value})`,
						width: ["Vertical", "Both"].includes(String(g("ContentOrientation"))) ? `${x.ViewportWidth}px` : "max-content",
						minWidth: `${x.ViewportWidth}px`,
						minHeight: `${x.ViewportHeight}px`
					}
				}, mt(Ee.default?.() ?? []))])]), [[l, a.value]]);
			}
		}), gt = () => {
			let e = /* @__PURE__ */ new Map();
			return {
				animate: (t, n, r, i, a = 0, o = "linear") => {
					if (!t) return;
					let s = Object.keys(r), c = getComputedStyle(t), l = Object.fromEntries(s.map((e) => [e, c[e]])), u = e.get(t) ?? /* @__PURE__ */ new Map();
					u.get(n)?.cancel(), Object.assign(t.style, l);
					let d = t.animate([l, r], {
						duration: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? 0 : i,
						delay: a,
						easing: o,
						fill: "both"
					});
					u.set(n, d), e.set(t, u), d.onfinish = () => {
						u.get(n) === d && (Object.assign(t.style, r), u.delete(n), d.cancel());
					};
				},
				clear: () => {
					for (let t of e.values()) for (let e of t.values()) e.cancel();
					e.clear();
				}
			};
		}, _t = ae({
			name: "ScrollBarsSeparator",
			inheritAttrs: !1,
			setup(e, { attrs: t }) {
				let r = p(null), i = gt(), a = f(() => Ne.value === "Visible" && Pe.value === "Visible"), o = f(() => a.value && (!n.AutoHideScrollBars || _.value && D.value === "MouseIndicator" && !!(O.value || k.value)));
				return m([o, _], ([e]) => i.animate(r.value, "separator", { opacity: e ? "1" : "0" }, 100, !n.AutoHideScrollBars || !_.value ? 0 : e ? 400 : 2e3), {
					flush: "post",
					immediate: !0
				}), ue(i.clear), () => se("div", {
					...t,
					ref: r,
					class: ["scrollbar-separator", { expanded: o.value }],
					"Grid.Row": 1,
					"Grid.Column": 1,
					"data-template-part": "PART_ScrollBarsSeparator",
					style: {
						display: a.value ? void 0 : "none",
						opacity: n.AutoHideScrollBars ? void 0 : 1
					}
				});
			}
		});
		fe(c, {
			...De,
			properties: ke,
			enabled: _,
			ScrollBars: Fe,
			VerticalScrollBar_Scroll: Ie,
			HorizontalScrollBar_Scroll: Le,
			horizontalVisibility: Ne,
			verticalVisibility: Pe,
			ScrollView_PointerEntered: Be,
			ScrollView_PointerMoved: Ve,
			ScrollView_PointerExited: He
		}), fe(s, me({}));
		let Q = {
			ScrollTo: $e,
			ScrollBy: et,
			ZoomTo: tt,
			ZoomBy: nt,
			AddScrollVelocity: it,
			AddZoomVelocity: at,
			RegisterAnchorCandidate: (e) => {
				je.add(e), We();
			},
			UnregisterAnchorCandidate: (e) => {
				je.delete(e), We();
			},
			CurrentAnchor: f(() => Ae.value),
			State: f(() => C.value),
			ZoomFactor: f(() => S.value),
			HorizontalOffset: f(() => x.HorizontalOffset),
			VerticalOffset: f(() => x.VerticalOffset),
			ExtentWidth: f(() => x.ExtentWidth),
			ExtentHeight: f(() => x.ExtentHeight),
			ViewportWidth: f(() => x.ViewportWidth),
			ViewportHeight: f(() => x.ViewportHeight),
			ScrollableWidth: w,
			ScrollableHeight: T,
			ComputedHorizontalScrollMode: f(() => E("Horizontal")),
			ComputedVerticalScrollMode: f(() => E("Vertical")),
			ComputedHorizontalScrollBarVisibility: Ne,
			ComputedVerticalScrollBarVisibility: Pe,
			ScrollPresenter: f(() => v.value),
			ExpressionAnimationSources: f(() => ({
				Extent: {
					x: x.ExtentWidth,
					y: x.ExtentHeight
				},
				Viewport: {
					x: x.ViewportWidth,
					y: x.ViewportHeight
				},
				Offset: {
					x: x.HorizontalOffset,
					y: x.VerticalOffset
				},
				ZoomFactor: S.value
			}))
		};
		for (let e of Object.keys(Se)) Q[e] = f({
			get: () => g(e),
			set: (t) => {
				Oe[e] = t, o(Se[e], t, h);
			}
		});
		be(Q), m(() => [
			g("ContentOrientation"),
			g("Width"),
			g("Height")
		], () => void le(Ke)), m(_, (e) => {
			e || (O.value = "", Z(), H(!0), j && clearTimeout(j), D.value = "NoIndicator");
		}), m(() => n.AutoHideScrollBars, () => {
			j && clearTimeout(j), j = void 0, !n.AutoHideScrollBars || O.value || k.value ? B() : D.value = "NoIndicator";
		}), m(() => [g("MinZoomFactor"), g("MaxZoomFactor")], () => {
			S.value !== G(S.value) && K(G(S.value), {
				x: 0,
				y: 0
			});
		});
		let vt = () => {
			O.value = "", Z(), H(!0), B();
		}, $ = null;
		de(() => {
			le(() => {
				Ge(), N = new ResizeObserver(Ke), v.value && N.observe(v.value), y.value && N.observe(y.value), P = new MutationObserver(Ke), y.value && P.observe(y.value, {
					childList: !0,
					subtree: !0
				}), $ = v.value?.closest(".win-scroll-view"), $?.addEventListener("pointerenter", Be), $?.addEventListener("pointermove", Ve), $?.addEventListener("pointerleave", He), R("Loaded");
			}), window.addEventListener("blur", vt);
		}), ue(() => {
			H(!0), N?.disconnect(), P?.disconnect(), I && cancelAnimationFrame(I), j && clearTimeout(j), M && clearTimeout(M), window.removeEventListener("blur", vt), $?.removeEventListener("pointerenter", Be), $?.removeEventListener("pointermove", Ve), $?.removeEventListener("pointerleave", He);
		});
		let yt = {
			props: Se,
			emit: Ce,
			instance: h,
			attrs: we,
			rootAttrs: Te,
			slots: Ee,
			inheritedScope: De,
			overrides: Oe,
			properties: ke,
			property: g,
			enabled: _,
			viewport: v,
			content: y,
			surface: b,
			metrics: x,
			zoom: S,
			state: C,
			currentAnchor: Ae,
			anchorCandidates: je,
			scrollableWidth: w,
			scrollableHeight: T,
			computedMode: E,
			visibility: Me,
			horizontalVisibility: Ne,
			verticalVisibility: Pe,
			indicator: D,
			ScrollBars: Fe,
			VerticalScrollBar_Scroll: Ie,
			HorizontalScrollBar_Scroll: Le,
			hoveredBar: O,
			pressedBar: k,
			get lastPointerKind() {
				return A;
			},
			set lastPointerKind(e) {
				A = e;
			},
			get indicatorTimer() {
				return j;
			},
			set indicatorTimer(e) {
				j = e;
			},
			get settleTimer() {
				return M;
			},
			set settleTimer(e) {
				M = e;
			},
			get observer() {
				return N;
			},
			set observer(e) {
				N = e;
			},
			get mutationObserver() {
				return P;
			},
			set mutationObserver(e) {
				P = e;
			},
			get frame() {
				return F;
			},
			set frame(e) {
				F = e;
			},
			get measureFrame() {
				return I;
			},
			set measureFrame(e) {
				I = e;
			},
			get correlation() {
				return Re;
			},
			set correlation(e) {
				Re = e;
			},
			get operation() {
				return L;
			},
			set operation(e) {
				L = e;
			},
			publicSender: ze,
			event: R,
			changeState: z,
			showIndicator: B,
			ScrollView_PointerEntered: Be,
			ScrollView_PointerMoved: Ve,
			ScrollView_PointerExited: He,
			ignored: V,
			complete: H,
			begin: U,
			syncOffsets: Ue,
			setOffsets: W,
			chooseAnchor: We,
			measure: Ge,
			queueMeasure: Ke,
			clampZoom: G,
			setZoom: K,
			cubicBezier: qe,
			compositionEase: Je,
			compositor: Ye,
			createAnimation: Xe,
			evaluateAnimation: Ze,
			animated: Qe,
			ScrollTo: $e,
			ScrollBy: et,
			ZoomTo: tt,
			ZoomBy: nt,
			vector: rt,
			AddScrollVelocity: it,
			AddZoomVelocity: at,
			settle: ot,
			onScroll: st,
			onWheel: ct,
			pointers: q,
			setPointerCaptureSafe: lt,
			get lastPointer() {
				return J;
			},
			set lastPointer(e) {
				J = e;
			},
			get rail() {
				return Y;
			},
			set rail(e) {
				Y = e;
			},
			get pinch() {
				return X;
			},
			set pinch(e) {
				X = e;
			},
			onPointerDown: ut,
			onPointerMove: dt,
			onPointerEnd: Z,
			onKeyDown: ft,
			onFocusIn: pt,
			measureContentNodes: mt,
			ScrollPresenter: ht,
			storyboard: gt,
			ScrollBarsSeparator: _t,
			exposed: Q,
			onWindowBlur: vt,
			get rootElement() {
				return $;
			},
			set rootElement(e) {
				$ = e;
			},
			Grid: u,
			RowDefinition: ne,
			ColumnDefinition: te,
			ScrollBar: ee
		};
		return Object.defineProperty(yt, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), yt;
	}
});
//#endregion
export { ye as default };

//# sourceMappingURL=ScrollView.vue_vue_type_script_setup_true_lang.js.map