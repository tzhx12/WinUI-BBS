import { defineComponent as e } from "vue";
//#region src/components/MediaTransportControls.vue?vue&type=script&lang.ts
var t = {
	IsZoomButtonVisible: !0,
	IsZoomEnabled: !0,
	IsFullWindowButtonVisible: !0,
	IsFullWindowEnabled: !0,
	IsFastForwardButtonVisible: !1,
	IsFastForwardEnabled: !1,
	IsFastRewindButtonVisible: !1,
	IsFastRewindEnabled: !1,
	IsStopButtonVisible: !1,
	IsStopEnabled: !1,
	IsVolumeButtonVisible: !0,
	IsVolumeEnabled: !0,
	IsPlaybackRateButtonVisible: !1,
	IsPlaybackRateEnabled: !1,
	IsSeekBarVisible: !0,
	IsSeekEnabled: !0,
	IsCompact: !1,
	IsSkipForwardButtonVisible: !1,
	IsSkipForwardEnabled: !1,
	IsSkipBackwardButtonVisible: !1,
	IsSkipBackwardEnabled: !1,
	IsNextTrackButtonVisible: !1,
	IsPreviousTrackButtonVisible: !1,
	FastPlayFallbackBehaviour: "Skip",
	ShowAndHideAutomatically: !0,
	IsRepeatEnabled: !1,
	IsRepeatButtonVisible: !1
}, n = e({
	name: "MediaTransportControls",
	__mediaTransportControls: !0,
	inheritAttrs: !1,
	props: Object.fromEntries(Object.entries(t).map(([e, t]) => [e, {
		type: typeof t == "boolean" ? [Boolean, String] : String,
		default: t
	}])),
	setup() {
		return () => null;
	}
});
//#endregion
export { n as default, t as mediaTransportControlDefaults };

//# sourceMappingURL=MediaTransportControls.vue_vue_type_script_lang.js.map