import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./StackPanel.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                               */
import { createElementBlock as n, createVNode as r, normalizeStyle as i, openBlock as a, withDirectives as o } from "vue";
//#region src/components/StackPanel.vue
var s = ["HorizontalAlignment", "VerticalAlignment"];
function c(e, t, c, l, u, d) {
	return o((a(), n("div", {
		ref: "root",
		class: "win-stack-panel",
		style: i(l.rootStyle),
		HorizontalAlignment: l.resolve(c.HorizontalAlignment) || "Stretch",
		VerticalAlignment: l.resolve(c.VerticalAlignment) || "Stretch"
	}, [r(l.ContentOutlet)], 12, s)), [[l.vAcrylicBrush, l.rootStyle], [l.vRadialGradientBrush, l.backgroundBrush.value.value]]);
}
var l = /*#__PURE__*/ e(t, [
	["render", c],
	["__scopeId", "data-v-73c53dfe"],
	["__file", "StackPanel.vue"]
]);
//#endregion
export { l as default };

//# sourceMappingURL=StackPanel.vue.js.map