import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./RelativePanel.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                                  */
import { createElementBlock as n, createVNode as r, normalizeStyle as i, openBlock as a } from "vue";
//#region src/components/RelativePanel.vue
function o(e, t, o, s, c, l) {
	return a(), n("div", {
		ref: "root",
		class: "win-relative-panel",
		style: i(s.rootStyle)
	}, [r(s.ChildrenOutlet)], 4);
}
var s = /*#__PURE__*/ e(t, [
	["render", o],
	["__scopeId", "data-v-b3cbbde4"],
	["__file", "RelativePanel.vue"]
]);
//#endregion
export { s as default };

//# sourceMappingURL=RelativePanel.vue.js.map