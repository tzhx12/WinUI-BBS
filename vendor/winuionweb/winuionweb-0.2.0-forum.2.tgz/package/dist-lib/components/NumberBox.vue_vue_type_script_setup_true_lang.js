import { useAcrylicBrushStyle as e } from "./AcrylicBrush.js";
import { resolveXamlHandler as t, resolveXamlValue as n, updateXamlBinding as r, xamlScopeKey as i } from "./xamlRuntime.js";
import { vAcrylicBrush as a } from "./acrylicBrushVisual.js";
import { vThemeShadow as o } from "./themeShadowVisual.js";
import { useI18n as s } from "./i18n/index.js";
import { xamlResourceDictionaryKey as ee } from "./Page.vue_vue_type_script_lang.js";
import { getVNodeChildren as te } from "./CollectionProperties.js";
import { textInputTemplateKey as ne } from "./textInputTemplate.js";
import re from "./TextBox.vue.js";
import ie from "./RepeatButton.vue.js";
import { Fragment as ae, computed as c, defineComponent as oe, getCurrentInstance as se, h as l, inject as ce, nextTick as le, onBeforeUnmount as ue, onMounted as de, provide as fe, proxyRefs as pe, ref as u, useAttrs as me, useSlots as he, watch as d, watchPostEffect as ge } from "vue";
//#region src/components/NumberBox.vue?vue&type=script&setup=true&lang.ts
var _e = oe({
	name: "NumberBox.HeaderTemplate",
	__numberBoxProperty: "HeaderTemplate",
	setup: () => () => null
}), ve = /*@__PURE__*/ oe({
	HeaderTemplate: _e,
	inheritAttrs: !1,
	__name: "NumberBox",
	props: {
		Value: { default: NaN },
		Text: { default: "" },
		Minimum: { default: -Infinity },
		Maximum: { default: Infinity },
		SmallChange: { default: 1 },
		LargeChange: { default: 10 },
		Header: { default: () => "" },
		HeaderTemplate: { default: void 0 },
		Description: { default: "" },
		PlaceholderText: { default: "" },
		InputScope: { default: "Decimal" },
		SelectionFlyout: { default: void 0 },
		SelectionHighlightColor: { default: "" },
		TextReadingOrder: { default: "Default" },
		PreventKeyboardDisplayOnProgrammaticFocus: {
			type: [Boolean, String],
			default: !1
		},
		NumberFormatter: { default: null },
		SpinButtonPlacementMode: { default: "Hidden" },
		ValidationMode: { default: "InvalidInputOverwritten" },
		IsWrapEnabled: {
			type: [Boolean, String],
			default: !1
		},
		AcceptsExpression: {
			type: [Boolean, String],
			default: !1
		},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		TextAlignment: { default: "Left" },
		MinWidth: { default: 64 },
		MinHeight: { default: "" },
		MaxWidth: { default: "" },
		MaxHeight: { default: "" },
		VerticalAlignment: { default: "Stretch" },
		HorizontalAlignment: { default: "Stretch" },
		Width: { default: "" },
		Margin: { default: "" }
	},
	emits: [
		"update:Value",
		"update:Text",
		"ValueChanged"
	],
	setup(oe, { expose: ve, emit: ye }) {
		let { t: be } = s(), f = oe, p = ye, m = u(null), h = u(!1), g = u(!1), xe = u({}), Se = ce("winuiTheme", null), _ = u(""), v = me(), y = se(), Ce = he(), we = ce(ee, {}), Te = u(64), b = c(() => {
			let e = (t) => t.flatMap((t) => {
				if (t.type === ae) return e(te(t));
				let n = t.type;
				return typeof n == "string" ? n === "NumberBox.HeaderTemplate" ? te(t) : [] : n?.__numberBoxProperty === "HeaderTemplate" ? te(t) : [];
			});
			return e(Ce.default?.() ?? []);
		}), Ee = c(() => {
			if (b.value.length) return l(ae, b.value);
			let e = typeof f.HeaderTemplate == "string" ? f.HeaderTemplate.match(/^\{(?:StaticResource|ThemeResource)\s+([^}]+)\}$/)?.[1] : void 0;
			return e && we[e] ? we[e] : n(f.HeaderTemplate, y);
		}), x = u(), De = e("{ThemeResource NumberBoxPopupBackground}", y), Oe = c(() => {
			let e = Number(n("{ThemeResource NumberBoxPopupShadowDepth}", y));
			return Number.isFinite(e) ? e : 16;
		});
		ge(() => {
			let e = m.value?.querySelector("input, textarea");
			if (!e) return;
			let t = (e) => v[e] ?? v[e.toLowerCase()] ?? v[e.replaceAll(".", "").toLowerCase()], r = n(t("AutomationProperties.Name"), y);
			r ? e.setAttribute("aria-label", String(r)) : e.removeAttribute("aria-label");
			let i = n(t("AutomationProperties.LabeledBy"), y), a = i instanceof HTMLElement ? i : i?.Element ?? i?.$el;
			a instanceof HTMLElement ? (a.id ||= `numberbox-label-${y?.uid ?? 0}`, e.setAttribute("aria-labelledby", a.id)) : e.removeAttribute("aria-labelledby");
		});
		let S = (e, t) => {
			let r = n(e, y);
			if (r == null || typeof r == "string" && r.trim() === "") return t;
			let i = typeof r == "number" ? r : Number(r);
			return Number.isNaN(i) ? t : i;
		}, C = (e, t) => {
			let r = n(e, y);
			if (typeof r == "boolean") return r;
			if (typeof r == "string") {
				if (r.trim().toLowerCase() === "true") return !0;
				if (r.trim().toLowerCase() === "false") return !1;
			}
			return t;
		}, w = (e, t) => {
			let n = c(e), i = u();
			return d(n, () => {
				i.value = void 0;
			}), c({
				get: () => i.value ?? n.value,
				set: (e) => {
					i.value = e, r(t(), e, y);
				}
			});
		}, ke = c(() => S(f.Value, NaN)), T = u(ke.value), E = c(() => T.value);
		d(ke, (e) => {
			T.value = e;
		});
		let D = w(() => S(f.Minimum, -Infinity), () => f.Minimum), O = w(() => S(f.Maximum, Infinity), () => f.Maximum), k = w(() => S(f.SmallChange, 1), () => f.SmallChange), A = w(() => S(f.LargeChange, 10), () => f.LargeChange), Ae = c(() => {
			let e = n(f.Text, y);
			return e == null ? "" : String(e);
		}), j = w(() => n(f.Header, y), () => f.Header), je = c(() => n(f.Description, y)), Me = c(() => n(f.PlaceholderText, y)), Ne = c(() => n(f.InputScope, y)), M = w(() => String(n(f.ValidationMode, y) ?? "InvalidInputOverwritten"), () => f.ValidationMode), N = w(() => C(f.IsWrapEnabled, !1), () => f.IsWrapEnabled), P = w(() => C(f.AcceptsExpression, !1), () => f.AcceptsExpression), F = c(() => C(f.IsEnabled, !0)), I = u(void 0), L = c(() => I.value ?? F.value);
		d(F, () => {
			I.value = void 0;
		});
		let Pe = c(() => n(f.TextAlignment, y)), R = c(() => {
			let e = String(n(f.SpinButtonPlacementMode, y) ?? "Hidden");
			return e === "Inline" || e === "Compact" ? e : "Hidden";
		}), z = u(), B = c(() => z.value ?? R.value);
		d(R, () => {
			z.value = void 0;
		});
		let Fe = c(() => n(f.SelectionHighlightColor, y)), Ie = c(() => C(f.PreventKeyboardDisplayOnProgrammaticFocus, !1)), Le = c(() => n(f.NumberFormatter, y)), V = u(), H = c(() => V.value ?? Le.value);
		d(Le, () => {
			V.value = void 0;
		});
		let U = c(() => n(f.Width, y)), W = c(() => n(f.MinWidth, y)), Re = c(() => n(f.MinHeight, y)), ze = c(() => n(f.MaxWidth, y)), Be = c(() => n(f.MaxHeight, y)), Ve = c(() => n(f.VerticalAlignment, y)), He = c(() => n(f.HorizontalAlignment, y)), Ue = c(() => n(f.Margin, y)), G = (e) => {
			if (Number.isNaN(e)) return "";
			let t = H.value;
			if (t && typeof t == "object" && "FormatDouble" in t && typeof t.FormatDouble == "function") return t.FormatDouble(e);
			if (t && typeof t == "object" && "format" in t && typeof t.format == "function") try {
				return t.format(e);
			} catch {}
			return String(e);
		}, K = u(Ae.value || G(E.value)), We = c(() => K.value), Ge = c(() => B.value === "Compact" && L.value && h.value), Ke = c(() => {
			let e = Se?.value || _.value;
			return e === "light" || e === "dark" ? `theme-${e}` : "";
		}), qe = (e, t) => {
			let n = String(e || "").toLowerCase();
			return t === "vertical" ? {
				center: "center",
				top: "flex-start",
				bottom: "flex-end",
				stretch: "stretch"
			}[n] || "stretch" : {
				left: "flex-start",
				center: "center",
				right: "flex-end",
				stretch: "stretch"
			}[n] || "stretch";
		}, q = (e) => {
			if (e === "" || e == null) return;
			if (typeof e == "number") return Number.isFinite(e) ? `${e}px` : void 0;
			let t = String(e).trim();
			if (t) return /^-?\d+(?:\.\d+)?$/.test(t) ? `${t}px` : t;
		}, Je = (e) => {
			if (e === "" || e == null) return;
			let t = String(e).split(",").map((e) => q(e.trim()) ?? "0px");
			return t.length === 1 ? t[0] : t.length === 2 ? `${t[1]} ${t[0]}` : t.length === 4 ? `${t[1]} ${t[2]} ${t[3]} ${t[0]}` : String(e);
		}, Ye = c(() => ({
			width: q(U.value),
			minWidth: U.value === "" || U.value === void 0 ? `min(${Math.max(Te.value, B.value === "Inline" ? 120 : 64, Number(W.value) || 0)}px, 100%)` : q(B.value === "Inline" ? Math.max(120, Number(W.value) || 0) : W.value),
			minHeight: q(Re.value),
			maxWidth: q(ze.value),
			maxHeight: q(Be.value),
			margin: Je(Ue.value),
			alignSelf: Ve.value === "Stretch" ? void 0 : qe(String(Ve.value ?? ""), "vertical"),
			justifySelf: He.value === "Stretch" ? void 0 : qe(String(He.value ?? ""), "horizontal")
		})), Xe = c(() => L.value && !Number.isNaN(E.value) && (N.value || M.value === "Disabled" || E.value < O.value)), Ze = c(() => L.value && !Number.isNaN(E.value) && (N.value || M.value === "Disabled" || E.value > D.value)), Qe = (e) => Math.min(O.value, Math.max(D.value, e)), $e = (e) => {
			let t = H.value;
			if (t && typeof t == "object" && "ParseDouble" in t && typeof t.ParseDouble == "function") {
				let n = t.ParseDouble(e);
				return typeof n == "number" && Number.isFinite(n) ? n : NaN;
			}
			let n = e.replace(/,/g, "").trim();
			return /^-?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$/.test(n) ? Number(n) : NaN;
		}, et = (e) => {
			let t = [], n = [], r = (e) => e === "^" ? 2 : +(e === "*" || e === "/"), i = !0;
			for (let a = 0; a < e.length;) {
				let o = e[a];
				if (o === " ") {
					a++;
					continue;
				}
				if (i) {
					if (o === "(") {
						n.push(o), a++;
						continue;
					}
					let r = e.slice(a).match(/^-?[^-+/*()^\s]+/)?.[0];
					if (!r) return NaN;
					let s = $e(r);
					if (Number.isNaN(s)) return s;
					t.push(s), a += r.length, i = !1;
				} else if ("+-*/^".includes(o)) {
					for (; n.length && n.at(-1) !== "(" && r(n.at(-1)) >= r(o);) t.push(n.pop());
					n.push(o), a++, i = !0;
				} else if (o === ")") {
					for (; n.length && n.at(-1) !== "(";) t.push(n.pop());
					if (n.pop() !== "(") return NaN;
					a++;
				} else return NaN;
			}
			if (i || n.includes("(")) return NaN;
			for (; n.length;) t.push(n.pop());
			let a = [];
			for (let e of t) {
				if (typeof e == "number") {
					a.push(e);
					continue;
				}
				if (a.length < 2) return NaN;
				let t = a.pop(), n = a.pop(), r = e === "+" ? n + t : e === "-" ? n - t : e === "*" ? n * t : e === "/" ? n / t : n ** t;
				if (!Number.isFinite(r)) return NaN;
				a.push(r);
			}
			return a.length === 1 ? a[0] : NaN;
		}, tt = (e) => P.value ? et(e.trim()) : $e(e), J = (e, n = E.value) => {
			let i = Number.isNaN(e) ? NaN : M.value === "Disabled" ? e : Qe(e), a = S(n, NaN);
			if (T.value = i, K.value = G(i), p("update:Value", i), r(f.Value, i, y), p("update:Text", K.value), r(f.Text, K.value, y), !Object.is(a, i)) {
				let e = {
					OldValue: a,
					NewValue: i
				};
				p("ValueChanged", Y, e), t(v.ValueChanged, y)?.(Y, e);
			}
			return i;
		}, nt = c({
			get: () => E.value,
			set: (e) => J(Number(e))
		}), rt = c({
			get: () => L.value,
			set: (e) => {
				I.value = !!e, r(f.IsEnabled, !!e, y);
			}
		}), Y = pe({
			Value: nt,
			Text: c({
				get: () => K.value,
				set: (e) => {
					K.value = String(e), X();
				}
			}),
			NumberFormatter: c({
				get: () => H.value,
				set: (e) => {
					V.value = e;
				}
			}),
			Header: j,
			HeaderTemplate: c({
				get: () => x.value ?? Ee.value,
				set: (e) => {
					x.value = e, r(f.HeaderTemplate, e, y);
				}
			}),
			SpinButtonPlacementMode: c({
				get: () => B.value,
				set: (e) => {
					z.value = e, r(f.SpinButtonPlacementMode, e, y);
				}
			}),
			Minimum: D,
			Maximum: O,
			SmallChange: k,
			LargeChange: A,
			ValidationMode: M,
			IsWrapEnabled: N,
			AcceptsExpression: P,
			IsEnabled: rt,
			Element: m,
			Focus: () => (m.value?.querySelector("input")?.focus(), !0)
		});
		ve(Y);
		let it = (e) => {
			let t = e.Text;
			t !== K.value && (K.value = t, p("update:Text", t), r(f.Text, t, y));
		}, at = () => {
			let e = m.value?.closest(".theme-light, .theme-dark");
			return e?.classList.contains("theme-dark") ? "dark" : e?.classList.contains("theme-light") ? "light" : "";
		}, ot = async () => {
			if (!m.value) return;
			_.value = at();
			let e = m.value.querySelector(".win-textbox-border")?.getBoundingClientRect() ?? m.value.getBoundingClientRect();
			xe.value = {
				left: `${Math.min(window.innerWidth - 50, Math.max(0, e.right - 49))}px`,
				top: `${Math.max(0, Math.min(window.innerHeight - 90, e.top - 27))}px`
			}, await le();
		}, st = () => {
			h.value = !0, ot();
		}, ct = () => {
			h.value = !1, g.value || X();
		}, X = () => {
			if (K.value.trim() === "") return J(NaN);
			let e = tt(K.value);
			return Number.isNaN(e) ? (M.value === "InvalidInputOverwritten" && (K.value = G(E.value)), E.value) : J(e);
		}, Z = (e) => {
			if (g.value) return;
			let t = X();
			if (Number.isNaN(t) || !L.value) return;
			let n = t + e;
			N.value && (n > O.value ? n = D.value : n < D.value && (n = O.value)), J(n, t), le(() => {
				let e = m.value?.querySelector("input");
				e?.setSelectionRange(e.value.length, e.value.length);
			});
		}, lt = (e) => {
			!L.value || g.value || e.isComposing || e.keyCode === 229 || e.ctrlKey || e.metaKey || e.altKey || (e.key === "ArrowUp" && (e.preventDefault(), Z(k.value)), e.key === "ArrowDown" && (e.preventDefault(), Z(-k.value)), e.key === "PageUp" && (e.preventDefault(), Z(A.value)), e.key === "PageDown" && (e.preventDefault(), Z(-A.value)));
		}, ut = (e) => {
			!L.value || g.value || e.isComposing || e.keyCode === 229 || (e.key === "Enter" ? (e.preventDefault(), X()) : e.key === "Escape" && (e.preventDefault(), K.value = G(E.value)));
		}, dt = (e) => {
			!h.value || g.value || !L.value || !e.deltaY || (e.preventDefault(), Z(e.deltaY < 0 ? k.value : -k.value));
		}, Q = () => {
			Ge.value && ot();
		};
		d(E, (e) => {
			K.value = G(e);
		}), d(H, () => {
			K.value = G(E.value);
		}), d([D, O], () => {
			!Number.isNaN(E.value) && M.value === "InvalidInputOverwritten" && J(E.value);
		}), d(Ae, (e) => {
			e !== void 0 && e !== K.value && (K.value = e);
		}), de(() => {
			window.addEventListener("resize", Q), window.addEventListener("scroll", Q, !0);
		}), ue(() => {
			window.removeEventListener("resize", Q), window.removeEventListener("scroll", Q, !0);
		});
		let $ = {
			get Text() {
				return We.value;
			},
			get Header() {
				return j.value;
			},
			get HeaderTemplate() {
				return x.value ?? Ee.value;
			},
			get Description() {
				return je.value;
			},
			get PlaceholderText() {
				return Me.value;
			},
			get IsEnabled() {
				return L.value;
			},
			get InputScope() {
				return Ne.value || "Decimal";
			},
			get MinHeight() {
				return Re.value;
			},
			get TextAlignment() {
				return Pe.value;
			},
			get SelectionHighlightColor() {
				return Fe.value;
			},
			get PreventKeyboardDisplayOnProgrammaticFocus() {
				return Ie.value;
			},
			get CanIncrease() {
				return Xe.value;
			},
			get CanDecrease() {
				return Ze.value;
			},
			get IncreaseLabel() {
				return be("TextControls.NumberBox.Increase");
			},
			get DecreaseLabel() {
				return be("TextControls.NumberBox.Decrease");
			}
		};
		fe(i, {
			NumberBoxTemplate: $,
			OnNumberBoxTextChanged: it,
			OnNumberBoxGotFocus: st,
			OnNumberBoxLostFocus: ct,
			OnNumberBoxTextCompositionStarted: () => {
				g.value = !0;
			},
			OnNumberBoxTextCompositionEnded: () => {
				g.value = !1;
			},
			OnNumberBoxSpinUp: () => Z(k.value),
			OnNumberBoxSpinDown: () => Z(-k.value)
		}), fe(ne, {
			KeyDown: lt,
			ActionsWidth: () => B.value === "Inline" ? 76 : B.value === "Compact" ? 40 : 0,
			ReserveDeleteButtonWidth: 40,
			DesiredWidthChanged: (e) => {
				Te.value = e;
			},
			Actions: () => B.value === "Inline" ? l("div", {
				class: "win-number-spin inline",
				onPointerdown: (e) => e.preventDefault()
			}, [l(ie, {
				class: "win-number-spin-button",
				Content: "",
				Padding: "0",
				VerticalAlignment: "Stretch",
				IsEnabled: Xe.value,
				IsTabStop: "False",
				"AutomationProperties.Name": $.IncreaseLabel,
				Click: () => Z(k.value)
			}), l(ie, {
				class: "win-number-spin-button",
				Content: "",
				Padding: "0",
				VerticalAlignment: "Stretch",
				IsEnabled: Ze.value,
				IsTabStop: "False",
				"AutomationProperties.Name": $.DecreaseLabel,
				Click: () => Z(-k.value)
			})]) : B.value === "Compact" ? l("span", {
				class: "win-number-compact-indicator",
				"aria-hidden": !0
			}, "") : null
		});
		let ft = {
			NumberBoxHeaderTemplate: _e,
			t: be,
			props: f,
			emit: p,
			rootRef: m,
			isFocused: h,
			isComposing: g,
			compactPopupStyle: xe,
			inheritedTheme: Se,
			anchorTheme: _,
			attrs: v,
			instance: y,
			slots: Ce,
			resources: we,
			desiredInputWidth: Te,
			headerTemplateNodes: b,
			resolvedHeaderTemplate: Ee,
			localHeaderTemplate: x,
			compactPopupBackgroundStyle: De,
			compactPopupShadowDepth: Oe,
			resolveNumber: S,
			resolveBoolean: C,
			dependency: w,
			sourceValue: ke,
			localValue: T,
			resolvedValue: E,
			resolvedMinimum: D,
			resolvedMaximum: O,
			resolvedSmallChange: k,
			resolvedLargeChange: A,
			resolvedText: Ae,
			resolvedHeader: j,
			resolvedDescription: je,
			resolvedPlaceholderText: Me,
			resolvedInputScope: Ne,
			resolvedValidationMode: M,
			resolvedIsWrapEnabled: N,
			resolvedAcceptsExpression: P,
			sourceIsEnabled: F,
			localIsEnabled: I,
			resolvedIsEnabled: L,
			resolvedTextAlignment: Pe,
			sourceSpinButtonPlacementMode: R,
			localSpinButtonPlacementMode: z,
			resolvedSpinButtonPlacementMode: B,
			resolvedSelectionHighlightColor: Fe,
			resolvedPreventKeyboardDisplayOnProgrammaticFocus: Ie,
			sourceNumberFormatter: Le,
			localNumberFormatter: V,
			resolvedNumberFormatter: H,
			resolvedWidth: U,
			resolvedMinWidth: W,
			resolvedMinHeight: Re,
			resolvedMaxWidth: ze,
			resolvedMaxHeight: Be,
			resolvedVerticalAlignment: Ve,
			resolvedHorizontalAlignment: He,
			resolvedMargin: Ue,
			formatValue: G,
			text: K,
			displayText: We,
			compactPopupOpen: Ge,
			compactPopupThemeClass: Ke,
			alignmentStyle: qe,
			cssLength: q,
			xamlThickness: Je,
			rootStyle: Ye,
			canIncrease: Xe,
			canDecrease: Ze,
			clamp: Qe,
			parseNumber: $e,
			evaluateExpression: et,
			parseText: tt,
			setValue: J,
			exposedValue: nt,
			exposedIsEnabled: rt,
			api: Y,
			onTextInput: it,
			resolveAnchorTheme: at,
			updateCompactPopupPosition: ot,
			onFocus: st,
			onLostFocus: ct,
			commitText: X,
			changeBy: Z,
			onKeydown: lt,
			onKeyup: ut,
			onWheel: dt,
			onWindowMove: Q,
			NumberBoxTemplate: $,
			TextBox: re,
			RepeatButton: ie,
			get vAcrylicBrush() {
				return a;
			},
			get vThemeShadow() {
				return o;
			}
		};
		return Object.defineProperty(ft, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), ft;
	}
});
//#endregion
export { _e as NumberBoxHeaderTemplate, ve as default };

//# sourceMappingURL=NumberBox.vue_vue_type_script_setup_true_lang.js.map