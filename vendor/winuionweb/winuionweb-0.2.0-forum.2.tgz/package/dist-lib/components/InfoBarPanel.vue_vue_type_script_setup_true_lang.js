import { attachedValue as e, xamlThickness as t } from "./layout.js";
import { normalizeXamlNodes as n, resolveXamlValue as r } from "./xamlRuntime.js";
import { Fragment as i, cloneVNode as a, computed as o, defineComponent as s, getCurrentInstance as c, h as l, nextTick as u, onBeforeUnmount as d, onMounted as f, onUpdated as p, ref as m, useSlots as h } from "vue";
//#region src/components/InfoBarPanel.vue?vue&type=script&setup=true&lang.ts
var g = /*@__PURE__*/ s({
	name: "InfoBarPanel",
	__name: "InfoBarPanel",
	props: {
		HorizontalOrientationPadding: {
			type: [String, Number],
			default: 0
		},
		VerticalOrientationPadding: {
			type: [String, Number],
			default: 0
		},
		Margin: {
			type: [String, Number],
			default: 0
		}
	},
	setup(g, { expose: _ }) {
		_();
		let v = g, y = c(), b = h(), x = m(null), S = m(!0), C = (e) => r(e, y), w = o(() => ({
			padding: t(C(S.value ? v.VerticalOrientationPadding : v.HorizontalOrientationPadding)),
			margin: t(C(v.Margin))
		})), T = (e) => {
			let t = String(C(e) ?? 0).split(",").map((e) => Number(e.trim()) || 0);
			return t.length === 4 ? t : t.length === 2 ? [
				t[0],
				t[1],
				t[0],
				t[1]
			] : [
				,
				,
				,
				,
			].fill(t[0]);
		}, E = s({
			name: "InfoBarPanelChildren",
			setup() {
				return () => l(i, n(b.default?.() ?? [], y).map((e) => {
					let t = { ...e.props ?? {} };
					delete t.ref;
					for (let e of ["InfoBarPanel.HorizontalOrientationMargin", "InfoBarPanel.VerticalOrientationMargin"]) e in t && (t[e] = C(t[e]));
					let n = a(e, t);
					return n.ref = e.ref, n;
				}));
			}
		}), D, O, k = 0, A = !1, j = () => [...x.value?.children ?? []].filter((e) => e instanceof HTMLElement && !e.hidden && getComputedStyle(e).display !== "none"), M = () => {
			k = 0;
			let t = x.value;
			if (!t || !t.getClientRects().length || A) return;
			let n = t.clientWidth;
			if (!n) return;
			let r = document.createElement("div");
			Object.assign(r.style, {
				position: "absolute",
				inset: "0 auto auto 0",
				width: `${n}px`,
				visibility: "hidden",
				pointerEvents: "none",
				contain: "layout style",
				zIndex: "-1"
			});
			let i = j(), a = i.map((t) => {
				let i = t.cloneNode(!0);
				return i.removeAttribute("id"), i.querySelectorAll("[id]").forEach((e) => e.removeAttribute("id")), Object.assign(i.style, {
					position: "relative",
					width: "max-content",
					minWidth: "0",
					maxWidth: `${n}px`,
					flex: "none",
					margin: "0",
					alignSelf: "start"
				}), r.appendChild(i), {
					child: t,
					clone: i,
					horizontal: T(e(t, "InfoBarPanel.HorizontalOrientationMargin")),
					vertical: T(e(t, "InfoBarPanel.VerticalOrientationMargin"))
				};
			});
			r.dataset.infoBarMeasureHost = "true", t.appendChild(r);
			let o = a.map((e) => ({
				...e,
				width: e.clone.getBoundingClientRect().width,
				height: e.clone.getBoundingClientRect().height
			})).filter((e) => e.width > 0 && e.height > 0);
			r.remove();
			let s = o.reduce((e, t, n) => e + t.width + (n ? t.horizontal[0] : 0) + (n < o.length - 1 ? t.horizontal[2] : 0), 0), c = Number.parseFloat(getComputedStyle(t.parentElement).minHeight) || 0, l = o.length === 1 || s > n + .01 || c > 0 && o.some((e) => e.height + e.horizontal[1] + e.horizontal[3] > c);
			S.value = l;
			for (let e of i) e.style.margin = "0", e.style.flex = "0 0 auto", e.style.maxWidth = "100%", e.style.minWidth = "0";
			o.forEach((e, t) => {
				let [r, i, a, s] = l ? e.vertical : e.horizontal;
				e.child.style.margin = l ? `${t ? i : 0}px ${a}px ${s}px ${r}px` : `${i}px ${t < o.length - 1 ? a : 0}px ${s}px ${t ? r : 0}px`, e.child.style.width = l ? `${Math.min(n - r - a, e.width)}px` : `${e.width}px`, !l && t === o.length - 1 && (e.child.style.flex = "1 1 auto");
			}), i.forEach((e) => D?.observe(e));
		}, N = () => {
			!k && !A && (k = requestAnimationFrame(M));
		};
		f(() => {
			D = new ResizeObserver(N), x.value && D.observe(x.value), O = new MutationObserver((e) => {
				e.some((e) => e.type !== "childList" || [...e.addedNodes, ...e.removedNodes].some((e) => !(e instanceof HTMLElement && e.dataset.infoBarMeasureHost === "true"))) && N();
			}), x.value && O.observe(x.value, {
				subtree: !0,
				childList: !0,
				characterData: !0,
				attributes: !0,
				attributeFilter: ["hidden", "class"]
			}), document.fonts?.ready.then(N), u(N);
		}), p(() => {
			u(N);
		}), d(() => {
			A = !0, D?.disconnect(), O?.disconnect(), k && cancelAnimationFrame(k);
		});
		let P = {
			props: v,
			instance: y,
			slots: b,
			root: x,
			isVertical: S,
			resolve: C,
			panelStyle: w,
			thickness: T,
			ChildrenOutlet: E,
			get observer() {
				return D;
			},
			set observer(e) {
				D = e;
			},
			get mutations() {
				return O;
			},
			set mutations(e) {
				O = e;
			},
			get frame() {
				return k;
			},
			set frame(e) {
				k = e;
			},
			get disposed() {
				return A;
			},
			set disposed(e) {
				A = e;
			},
			children: j,
			measure: M,
			schedule: N
		};
		return Object.defineProperty(P, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), P;
	}
});
//#endregion
export { g as default };

//# sourceMappingURL=InfoBarPanel.vue_vue_type_script_setup_true_lang.js.map