import { defineComponent as e } from "vue";
//#region src/components/TitleBarProperties.ts
var t = (t) => e({
	name: `TitleBar.${t}`,
	__titleBarProperty: t,
	setup: () => () => null
}), n = t("IconSource"), r = t("LeftHeader"), i = t("Content"), a = t("RightHeader"), o = t("Resources");
//#endregion
export { i as TitleBarContent, n as TitleBarIconSource, r as TitleBarLeftHeader, o as TitleBarResources, a as TitleBarRightHeader };

//# sourceMappingURL=TitleBarProperties.js.map