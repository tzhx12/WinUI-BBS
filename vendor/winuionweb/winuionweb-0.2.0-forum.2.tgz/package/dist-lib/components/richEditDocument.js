import { convertAsciiMathToLatex as e, convertLatexToMathMl as t } from "mathlive/ssr";
//#region src/components/richEditDocument.ts
var n = "http://www.w3.org/1998/Math/MathML", r = (r) => {
	let i = t(r.includes("\\") ? r : e(r)), a = new DOMParser().parseFromString(`<math xmlns="${n}">${i}</math>`, "application/xml");
	if (a.querySelector("parsererror")) throw TypeError("Invalid math expression");
	let o = document.importNode(a.documentElement, !0);
	return o.setAttribute("data-linear-math", r), o;
}, i = (e) => {
	let t = new DOMParser().parseFromString(e, "application/xml"), r = t.documentElement;
	if (t.querySelector("parsererror") || r.localName !== "math" || r.namespaceURI !== n) throw TypeError("Invalid MathML");
	let i = document.createElementNS(n, "math"), a = (e, t) => {
		for (let n of Array.from(e.attributes)) [
			"display",
			"mathvariant",
			"mathsize",
			"stretchy",
			"fence",
			"separator",
			"accent",
			"accentunder",
			"open",
			"close",
			"separators",
			"columnalign",
			"rowalign"
		].includes(n.localName) && t.setAttribute(n.localName, n.value);
		for (let r of Array.from(e.childNodes)) if (r.nodeType === Node.TEXT_NODE) t.append(r.textContent ?? "");
		else if (r instanceof Element && r.namespaceURI === n && ![
			"annotation-xml",
			"annotation",
			"maction"
		].includes(r.localName)) {
			let e = document.createElementNS(n, r.localName === "mfenced" ? "mrow" : r.localName);
			if (r.localName === "mfenced") {
				let t = document.createElementNS(n, "mo");
				t.textContent = r.getAttribute("open") ?? "(", e.append(t);
			}
			if (a(r, e), r.localName === "mfenced") {
				let t = document.createElementNS(n, "mo");
				t.textContent = r.getAttribute("close") ?? ")", e.append(t);
			}
			t.append(e);
		}
	};
	return a(r, i), i;
}, a = async (e) => {
	let { RTFJS: t } = await import("rtf.js");
	t.loggingEnabled(!1);
	let n = typeof e == "string" ? Uint8Array.from(e, (e) => e.charCodeAt(0)).buffer : e;
	return new t.Document(n, {}).render();
}, o = (e) => Array.from(e).map((e) => e === "\\" || e === "{" || e === "}" ? `\\${e}` : e === "\n" ? "\\line " : e === "	" ? "\\tab " : Array.from({ length: e.length }, (t, n) => {
	let r = e.charCodeAt(n);
	return r > 127 ? `\\u${r > 32767 ? r - 65536 : r}?` : e[n];
}).join("")).join(""), s = (e) => {
	let t = [], n = (e) => (t.includes(e) || t.push(e), t.indexOf(e) + 1), r = (t) => {
		if (t.nodeType === Node.TEXT_NODE || !(t instanceof HTMLElement)) return o(t.textContent ?? "");
		if (t.tagName === "BR") return "\\line ";
		let i = "", a = t.style;
		(["B", "STRONG"].includes(t.tagName) || a.fontWeight === "bold" || Number(a.fontWeight) >= 600) && (i += "\\b "), (["I", "EM"].includes(t.tagName) || a.fontStyle === "italic") && (i += "\\i "), (t.tagName === "U" || a.textDecoration.includes("underline")) && (i += "\\ul "), (["S", "STRIKE"].includes(t.tagName) || a.textDecoration.includes("line-through")) && (i += "\\strike ");
		let s = a.color || t.getAttribute("color");
		s && (i += `\\cf${n(s)} `), a.fontSize && (i += `\\fs${Math.round(parseFloat(a.fontSize) * (a.fontSize.endsWith("pt") ? 2 : 1.5))} `);
		let c = Array.from(t.childNodes).map(r).join(""), l = [
			"DIV",
			"P",
			"LI"
		].includes(t.tagName) && t !== e ? "\\par\n" : "";
		return `{${i}${c}}${l}`;
	}, i = Array.from(e.childNodes).map(r).join("");
	return `{\\rtf1\\ansi\\deff0\\uc1{\\fonttbl{\\f0 Segoe UI;}}{\\colortbl;${t.map((t) => {
		let n = document.createElement("span");
		n.style.color = t, e.append(n);
		let r = getComputedStyle(n).color;
		n.remove();
		let i = r.match(/\d+/g)?.map(Number) ?? [
			0,
			0,
			0
		];
		return `\\red${i[0]}\\green${i[1]}\\blue${i[2]};`;
	}).join("")}}\\f0\\fs21 ${i}}`;
};
//#endregion
export { r as linearMathToElement, a as loadRtf, i as parseMathML, s as saveRtf };

//# sourceMappingURL=richEditDocument.js.map