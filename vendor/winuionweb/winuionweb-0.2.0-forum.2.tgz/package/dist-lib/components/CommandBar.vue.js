import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./CommandBar.vue_vue_type_script_setup_true_lang.js";
import { Fragment as n, Teleport as r, createBlock as i, createCommentVNode as a, createElementBlock as o, createElementVNode as s, createVNode as c, mergeProps as l, normalizeClass as u, normalizeStyle as d, openBlock as f, renderList as p, vShow as m, withDirectives as h, withModifiers as g } from "vue";
//#region src/components/CommandBar.vue
var _ = ["aria-label"], v = { class: "commandbar-content-and-primary" }, y = {
	ref: "contentRoot",
	class: "commandbar-content-control"
}, b = {
	ref: "primaryRoot",
	class: "commandbar-primary-items-control"
}, x = [
	"disabled",
	"aria-label",
	"aria-expanded"
], S = {
	key: 1,
	class: "commandbar-more-column",
	"aria-hidden": "true"
}, C = { class: "commandbar-secondary-shadow-wrapper" }, w = { class: "commandbar-overflow-scroll-viewer" }, T = {
	ref: "secondaryRoot",
	class: "commandbar-secondary-items-presenter"
};
function E(e, t, E, D, O, k) {
	return f(), o("div", {
		ref: "root",
		class: u(["win-commandbar", D.barClasses]),
		style: d(D.barStyle)
	}, [
		c(D.DeclarationOutlet),
		(f(), i(r, {
			to: D.overlayRoot || "body",
			disabled: !D.surfacePresent || !D.overlayRoot
		}, [h((f(), o("div", {
			ref: "layoutRoot",
			class: "commandbar-layout-root",
			style: d(D.layoutStyle),
			role: "toolbar",
			"aria-label": D.automationName,
			onKeydown: D.onKeyDown
		}, [h((f(), o("div", {
			ref: "surface",
			class: "commandbar-content-root",
			style: d(D.surfaceBackgroundStyle)
		}, [
			s("div", v, [s("div", y, [c(D.ContentOutlet)], 512), s("div", b, null, 512)]),
			D.showMore ? (f(), o("button", l({
				key: 0,
				ref: "moreButton",
				class: "commandbar-more-button commandbar-overflow-button",
				type: "button",
				disabled: !D.isEnabled,
				"aria-label": D.moreLabel
			}, { "ToolTipService.ToolTip": D.moreLabel }, {
				"aria-expanded": D.isOpen,
				"aria-haspopup": "menu",
				onClick: t[0] ||= (e) => D.setOpen(!D.isOpen)
			}), [...t[2] ||= [s("span", { class: "commandbar-ellipsis-content" }, [s("span", {
				class: "commandbar-ellipsis-icon",
				"aria-hidden": "true"
			}, "")], -1)]], 16, x)) : a("", !0),
			D.showMore ? a("", !0) : (f(), o("div", S)),
			t[3] ||= s("div", {
				class: "commandbar-open-border",
				"aria-hidden": "true"
			}, null, -1)
		], 4)), [[
			D.vAcrylicBrush,
			D.surfaceBackgroundStyle,
			void 0,
			{ "no-backdrop": !0 }
		]])], 44, _)), [[D.vAcrylicBackdrop, D.surfaceBackgroundStyle]])], 8, ["to", "disabled"])),
		(f(!0), o(n, null, p(D.entries, (e) => (f(), i(D.CommandPortal, {
			key: e.id,
			node: e.node,
			host: e.host,
			overflow: e.secondary || D.overflowIds.has(e.id),
			context: D.commandContext
		}, null, 8, [
			"node",
			"host",
			"overflow"
		]))), 128)),
		(f(), i(r, { to: "body" }, [
			h(s("div", {
				ref: "dismissLayer",
				class: "commandbar-light-dismiss-layer",
				"aria-hidden": "true",
				onPointerdown: t[1] ||= g((e) => D.setOpen(!1), ["prevent"])
			}, null, 544), [[m, D.surfacePresent && !D.isSticky]]),
			h(s("div", {
				ref: "overlayRoot",
				class: u(["commandbar-overlay-root", [D.barClasses, D.themeClass]]),
				style: d([D.barStyle, D.overlayStyle])
			}, null, 6), [[m, D.surfacePresent]]),
			h((f(), o("div", {
				ref: "overflowRoot",
				class: u(["commandbar-overflow-content-root", [D.themeClass, {
					"is-positioning": !D.positioned,
					"opens-up": D.opensUp
				}]]),
				style: d(D.overflowStyle),
				role: "menu",
				onKeydown: D.onOverflowKeyDown
			}, [h((f(), o("div", C, [h((f(), o("div", {
				class: "commandbar-overflow-presenter",
				style: d(D.overflowBackgroundStyle)
			}, [s("div", w, [s("div", T, null, 512)])], 4)), [[
				D.vAcrylicBrush,
				D.overflowBackgroundStyle,
				void 0,
				{ "no-backdrop": !0 }
			]])])), [[D.vThemeShadow, {
				Translation: 32,
				Theme: D.effectiveTheme,
				Enabled: D.overflowPresent
			}]])], 38)), [[m, D.overflowPresent], [D.vAcrylicBackdrop, D.overflowBackgroundStyle]])
		]))
	], 6);
}
var D = /*#__PURE__*/ e(t, [["render", E], ["__file", "CommandBar.vue"]]);
//#endregion
export { D as default };

//# sourceMappingURL=CommandBar.vue.js.map