import e from "./GridDefinitions.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                                    */
import t from "../_virtual/_plugin-vue_export-helper.js";
import { createElementBlock as n, openBlock as r, renderSlot as i } from "vue";
//#region src/components/GridDefinitions.vue
var a = {
	class: "win-grid-definitions",
	"aria-hidden": "true"
};
function o(e, t, o, s, c, l) {
	return r(), n("span", a, [i(e.$slots, "default", {}, void 0, !0)]);
}
var s = /*#__PURE__*/ t(e, [
	["render", o],
	["__scopeId", "data-v-5ebb9a6a"],
	["__file", "GridDefinitions.vue"]
]);
//#endregion
export { s as default };

//# sourceMappingURL=GridDefinitions.vue.js.map