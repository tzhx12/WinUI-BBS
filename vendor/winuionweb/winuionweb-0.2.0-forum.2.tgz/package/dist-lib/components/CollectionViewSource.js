import { computed as e, defineComponent as t } from "vue";
//#region src/components/CollectionViewSource.ts
var n = t({
	name: "CollectionViewSource",
	__createXamlResource(t) {
		let n = e(() => {
			let e = t("Source"), n = Array.isArray(e) ? e : [], r = t("IsSourceGrouped") === !0, i = String(t("ItemsPath") ?? "Items"), a = (e) => {
				let t = e;
				for (let e of i.split(".")) t = t?.[e];
				return Array.isArray(t) ? t : [];
			}, o = r ? n.map((e) => ({
				Group: e,
				GroupItems: a(e)
			})) : [];
			return Object.assign(r ? o.flatMap((e) => e.GroupItems) : [...n], {
				CollectionGroups: o,
				Groups: r ? n : []
			});
		});
		return {
			get View() {
				return n.value;
			},
			get Source() {
				return t("Source");
			},
			get IsSourceGrouped() {
				return t("IsSourceGrouped") === !0;
			},
			get ItemsPath() {
				return t("ItemsPath");
			}
		};
	},
	setup() {
		return () => null;
	}
});
//#endregion
export { n as default };

//# sourceMappingURL=CollectionViewSource.js.map