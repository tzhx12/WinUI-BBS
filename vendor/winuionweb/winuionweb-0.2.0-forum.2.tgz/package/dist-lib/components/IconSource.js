import { resolveXamlValue as e, updateXamlBinding as t } from "./xamlRuntime.js";
import { createImageSourceModel as n, imageBoolean as r, imageNumber as i, imageUri as a } from "./imageSource.js";
import o from "./BitmapIcon.vue.js";
import s from "./SymbolIcon.vue.js";
import c from "./PathIcon.vue.js";
import l from "./FontIcon.vue.js";
import u from "./ImageIcon.vue.js";
import { Fragment as d, defineComponent as f, effectScope as p, getCurrentInstance as m, h, inject as g, isVNode as _, onBeforeUnmount as v, reactive as y, useSlots as b, watch as x, watchEffect as S } from "vue";
//#region src/components/IconSource.ts
var C = {
	FontIcon: {
		Glyph: "",
		FontFamily: "Segoe Fluent Icons,Segoe MDL2 Assets",
		FontSize: 20,
		FontWeight: "Normal",
		FontStyle: "Normal",
		IsTextScaleFactorEnabled: !0,
		MirroredWhenRightToLeft: !1
	},
	SymbolIcon: { Symbol: "Emoji" },
	BitmapIcon: {
		UriSource: null,
		ShowAsMonochrome: !0
	},
	PathIcon: { Data: null },
	ImageIcon: { ImageSource: null }
}, w = Symbol.for("WinUI.IconSource"), T = (e, t) => f({
	name: `${e}.${t}`,
	__iconSourceProperty: t,
	setup: (e, { slots: t }) => () => h(d, t.default?.())
}), E = T("IconSourceElement", "IconSource"), D = T("ImageIconSource", "ImageSource"), O = (e) => Array.isArray(e.children) ? e.children.filter(_) : e.children?.default?.() ?? [], k = (e) => e.flatMap((e) => e.type === d ? k(O(e)) : [e]), A = (e) => typeof e.type == "string" ? e.type : e.type.name ?? e.type.__name ?? "", j = (e) => e.type?.__iconSourceKind, M = (e) => {
	let t = e.__iconSourceKind;
	if (typeof t == "string" && Object.hasOwn(C, t)) return t;
	if ("Glyph" in e) return "FontIcon";
	if ("Symbol" in e) return "SymbolIcon";
	if ("UriSource" in e) return "BitmapIcon";
	if ("Data" in e) return "PathIcon";
	if ("ImageSource" in e) return "ImageIcon";
}, N = (e) => {
	let t = M(e);
	if (!t) return null;
	let n = {};
	for (let r of Object.keys(C[t])) {
		let i = e[r];
		i !== void 0 && (n[t === "ImageIcon" && r === "ImageSource" ? "Source" : r] = i);
	}
	return e.Foreground !== void 0 && e.Foreground !== null && e.Foreground !== "" && (n.Foreground = e.Foreground), h({
		FontIcon: l,
		SymbolIcon: s,
		BitmapIcon: o,
		PathIcon: c,
		ImageIcon: u
	}[t], n);
}, P = (e) => {
	let t = y({
		...C[e],
		Foreground: void 0
	});
	Object.defineProperty(t, "__iconSourceKind", { value: e });
	let n = f({
		name: `${e}FromIconSource`,
		setup: () => () => N(t)
	});
	return Object.defineProperty(t, "CreateIconElement", { value: () => h(n) }), t;
}, F = (e, t, n) => {
	for (let [r, i] of Object.entries({
		...C[e.__iconSourceKind],
		Foreground: void 0
	})) e[r] = n(r) ? t(r) : i;
}, I = (e) => {
	let t = k(e), n = t.find((e) => e.type.__iconSourceProperty === "ImageSource" || A(e) === "ImageIconSource.ImageSource");
	return k(n ? O(n) : t).find((e) => ["BitmapImage", "SvgImageSource"].includes(A(e)));
}, L = (t, n, o) => {
	let s = (t) => e(n.props?.[t], o);
	t.__kind = A(n) === "SvgImageSource" ? "SvgImageSource" : "BitmapImage", t.UriSource = a(n.props?.UriSource, o), t.AutoPlay = n.props?.AutoPlay === void 0 ? !0 : r(s("AutoPlay")), t.DecodePixelWidth = i(s("DecodePixelWidth")), t.DecodePixelHeight = i(s("DecodePixelHeight")), t.DecodePixelType = s("DecodePixelType") === "Logical" ? "Logical" : "Physical", t.RasterizePixelWidth = i(s("RasterizePixelWidth")), t.RasterizePixelHeight = i(s("RasterizePixelHeight"));
}, R = (r) => {
	let i = `${r}Source`, a = {
		...C[r],
		Foreground: void 0
	}, o = f({
		name: i,
		__iconSourceKind: r,
		inheritAttrs: !1,
		props: Object.fromEntries(Object.keys(a).map((e) => [e, {
			type: null,
			default: void 0
		}])),
		setup(i, { expose: o }) {
			let s = m(), c = b(), l = g(w, null), u = P(r), d = n(), f = y({}), p = (t) => t in f ? f[t] : e(i[t], s);
			for (let t of Object.keys(a)) x(() => e(i[t], s), () => {
				delete f[t];
			});
			S(() => F(u, p, (e) => e in f || i[e] !== void 0));
			let h = { CreateIconElement: u.CreateIconElement };
			Object.defineProperty(h, "__iconSourceKind", { value: r });
			for (let e of Object.keys(a)) Object.defineProperty(h, e, {
				enumerable: !0,
				get: () => u[e],
				set: (n) => {
					f[e] = n, u[e] = n, t(i[e], n, s);
				}
			});
			return o(h), l?.(h), v(() => l?.(null)), () => {
				if (r === "ImageIcon") {
					let e = I(c.default?.() ?? []);
					e && !("ImageSource" in f) && i.ImageSource === void 0 && (L(d, e, s), u.ImageSource = d);
				}
				return null;
			};
		},
		__createXamlResource: (e, t) => {
			let i = P(r), a = n(), o = p(!0);
			return t.Dispose(() => o.stop()), o.run(() => S(() => {
				let n = t.Node();
				if (F(i, e, (e) => n.props?.[e] !== void 0), r === "ImageIcon") {
					let e = I(O(n));
					e && (L(a, e, t.instance), i.ImageSource = a);
				}
			})), i;
		}
	});
	return r === "ImageIcon" ? Object.assign(o, { ImageSource: D }) : o;
}, z = R("FontIcon"), B = R("SymbolIcon"), V = R("BitmapIcon"), H = R("PathIcon"), U = R("ImageIcon");
//#endregion
export { V as BitmapIconSource, z as FontIconSource, E as IconSourceProperty, U as ImageIconSource, D as ImageIconSourceProperty, H as PathIconSource, B as SymbolIconSource, N as createIconSourceElementVNode, w as iconSourceContextKey, j as iconSourceKind };

//# sourceMappingURL=IconSource.js.map