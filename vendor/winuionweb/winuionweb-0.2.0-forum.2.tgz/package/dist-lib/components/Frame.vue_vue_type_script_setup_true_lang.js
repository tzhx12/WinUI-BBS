import { normalizeXamlNodes as e, resolveXamlHandler as t, resolveXamlValue as n, xamlNameScopeKey as r } from "./xamlRuntime.js";
import { frameworkLayoutStyle as i } from "./frameworkLayout.js";
import { beginNavigationCommit as a } from "./frameNavigationRuntime.js";
import { getNavigationTransitionStoryboard as o, resolveNavigationPageStoryboards as s } from "./navigationTransitionRuntime.js";
import { FrameContentTransitions as c, getFrameProperty as l, readFrameNavigationTransition as ee } from "./NavigationTransitionProperties.js";
import { Fragment as u, Suspense as d, computed as f, defineComponent as p, getCurrentInstance as m, h, isVNode as te, markRaw as g, nextTick as ne, onBeforeUnmount as re, onErrorCaptured as ie, provide as ae, ref as _, shallowReactive as v, shallowRef as y, useAttrs as oe, useSlots as se, watch as ce } from "vue";
var b = /*@__PURE__*/ p({
	ContentTransitions: c,
	inheritAttrs: !1,
	__name: "Frame",
	props: {
		Content: {
			type: [
				String,
				Number,
				Object
			],
			default: null
		},
		ContentTransitions: {
			type: [
				String,
				Object,
				Array
			],
			default: null
		},
		IsNavigationStackEnabled: {
			type: [Boolean, String],
			default: !0
		},
		Background: {
			type: [String, Object],
			default: ""
		},
		Width: {
			type: [String, Number],
			default: ""
		},
		Height: {
			type: [String, Number],
			default: ""
		},
		MinWidth: {
			type: [String, Number],
			default: 0
		},
		MinHeight: {
			type: [String, Number],
			default: 0
		},
		MaxWidth: {
			type: [String, Number],
			default: ""
		},
		MaxHeight: {
			type: [String, Number],
			default: ""
		},
		Margin: {
			type: [String, Number],
			default: 0
		},
		HorizontalAlignment: {
			type: String,
			default: "Stretch"
		},
		VerticalAlignment: {
			type: String,
			default: "Stretch"
		},
		Visibility: {
			type: String,
			default: "Visible"
		},
		Opacity: {
			type: [String, Number],
			default: 1
		}
	},
	emits: [
		"update:Content",
		"Navigating",
		"Navigated",
		"NavigationFailed",
		"NavigationStopped"
	],
	setup(c, { expose: b, emit: le }) {
		let x = c, ue = oe(), S = se(), C = m();
		ae(r, v({}));
		let w = le, T = y(null), E = _(null), D = y(null), O = y(null), k = y(null), A = _(!1), j = _(!1), M = _(!1), N = /* @__PURE__ */ new Map(), P = v(/* @__PURE__ */ new Map()), F = [], I = [], L = 0, R = null, z = null, B = !1, V = 0, H = y([]), U = y([]), W = _(0), G = y(n(x.Content, C)), K = _(void 0), q = f({
			get: () => K.value ?? n(x.IsNavigationStackEnabled, C) !== !1,
			set: (e) => {
				K.value = e;
			}
		});
		ce(() => n(x.Content, C), (e) => {
			G.value = e;
		});
		let J = f({
			get: () => D.value ? P.get(D.value.Version) ?? null : G.value,
			set: (e) => {
				X(), T.value = null, D.value = null, G.value = e, w("update:Content", e);
			}
		}), de = f(() => H.value.length > 0), fe = f(() => U.value.length > 0), pe = f(() => i(x, C)), Y = (e, n) => {
			w(e, $, n), C?.vnode.props?.[`on${e}`] || t(ue[e], C)?.($, n);
		}, X = () => {
			V && cancelAnimationFrame(V), V = 0, R?.Commit.complete(!1), R = null, L += 1;
			for (let e of F) e.cancel();
			F = [];
			for (let e of I) e();
			I = [], O.value = null, k.value = null, A.value = !1, j.value = !1, M.value = !1;
		}, me = (e, t) => {
			if (e !== L || !D.value) return;
			let n = N.get(D.value.Version), r = O.value ? N.get(O.value.Version) : null;
			if (!n || typeof n.animate != "function") {
				X();
				return;
			}
			M.value = !0, n.style.removeProperty("transform"), n.style.removeProperty("opacity");
			let i = (e, n) => {
				let r = [];
				for (let i of s(t, e, n)) {
					if (i.Storyboard.TransformOrigin) {
						let e = i.Element.style.transformOrigin;
						i.Element.style.transformOrigin = i.Storyboard.TransformOrigin, I.push(() => {
							i.Element.style.transformOrigin = e;
						});
					}
					for (let e of i.Storyboard.Tracks) {
						let t = i.Element.animate(e.Keyframes, {
							duration: e.Duration,
							delay: e.Delay ?? 0,
							easing: e.Easing ?? "linear",
							fill: e.Fill ?? "both"
						});
						r.push(t), F.push(t);
					}
				}
				return r;
			}, a = i(n, !0), o = r ? i(r, !1) : [];
			r && Promise.all(o.map((e) => e.finished)).then(() => {
				e === L && (O.value = null);
			}, () => {}), Promise.all([...a, ...o].map((e) => e.finished)).then(() => {
				e === L && X();
			}, () => {
				e === L && X();
			});
		}, Z = (e, t, n = q.value, r = e.NavigationTransitionInfo) => {
			let i = {
				SourcePageType: e.SourcePageType,
				Parameter: e.Parameter,
				NavigationTransitionInfo: e.NavigationTransitionInfo,
				NavigationMode: t,
				Cancel: !1
			}, s = a(E.value), c = z?.Commit ?? null;
			z && (z.Commit = s);
			try {
				if (Y("Navigating", i), i.Cancel) return z?.Commit === s && (z.Commit = c), Y("NavigationStopped", i), s.complete(!1), !1;
				let a = T.value, l = D.value, u = {
					Entry: a,
					Layer: l,
					Content: G.value,
					BackStack: H.value,
					ForwardStack: U.value
				};
				X(), t === "New" ? (a && n && (H.value = [...H.value, a]), U.value = []) : t === "Back" ? (H.value = H.value.slice(0, -1), a && (U.value = [...U.value, a])) : (U.value = U.value.slice(0, -1), a && (H.value = [...H.value, a])), T.value = e, G.value = e.SourcePageType, W.value += 1, D.value = {
					Entry: e,
					Version: W.value
				};
				let d = ee(S.default?.() ?? [], C, x.ContentTransitions);
				R = {
					Commit: s,
					Version: W.value,
					Args: i,
					Ready: !1,
					Previous: u,
					DefaultNavigationTransitionInfoToStore: r == null ? d.DefaultNavigationTransitionInfo : null
				}, j.value = !0, O.value = l;
				let f = d.Enabled || H.value.length > 0 || t === "Back", p = o(r ?? d.DefaultNavigationTransitionInfo, t, f), m = typeof window < "u" && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
				return p && !m && (k.value = p, A.value = !0), w("update:Content", e.SourcePageType), !0;
			} catch (t) {
				z?.Commit === s && (z.Commit = c), s.complete(!1);
				let n = R;
				return n?.Commit === s && (X(), T.value = n.Previous.Entry, D.value = n.Previous.Layer, G.value = n.Previous.Content, H.value = n.Previous.BackStack, U.value = n.Previous.ForwardStack, w("update:Content", G.value)), Y("NavigationFailed", {
					SourcePageType: e.SourcePageType,
					Exception: t,
					Handled: !1
				}), !1;
			}
		}, he = (e) => {
			let t = R;
			!t || t.Version !== e || t.Ready || (t.Ready = !0, ne(() => {
				R === t && (j.value = !1, k.value || (O.value = null), V = requestAnimationFrame(() => {
					if (V = 0, R !== t || D.value?.Version !== e) return;
					R = null, t.DefaultNavigationTransitionInfoToStore != null && T.value && (T.value.NavigationTransitionInfo = t.DefaultNavigationTransitionInfoToStore);
					try {
						k.value && me(L, k.value);
					} catch {
						X();
					}
					let n = { Commit: null }, r = z;
					z = n;
					try {
						Y("Navigated", {
							...t.Args,
							Content: J.value
						});
					} finally {
						z = r, n.Commit ? n.Commit.completion.then((e) => {
							let n = T.value?.SourcePageType === t.Args.SourcePageType && Object.is(T.value?.Parameter, t.Args.Parameter);
							t.Commit.complete(!B && (e || n));
						}) : t.Commit.complete(!B);
					}
				}));
			}));
		}, ge = (e, t = null, n = null) => !e || !["object", "function"].includes(typeof e) ? !1 : Z({
			SourcePageType: g(e),
			Parameter: t,
			NavigationTransitionInfo: n
		}, "New"), Q = (e) => {
			let t = H.value.at(-1);
			return t && e != null && T.value && (T.value = {
				...T.value,
				NavigationTransitionInfo: e
			}), t ? Z(t, "Back", q.value, e ?? T.value?.NavigationTransitionInfo ?? null) : !1;
		}, _e = () => {
			let e = U.value.at(-1);
			return e ? Z(e, "Forward") : !1;
		}, ve = (e, t = null, n = {}) => !e || !["object", "function"].includes(typeof e) ? !1 : Z({
			SourcePageType: g(e),
			Parameter: t,
			NavigationTransitionInfo: n.TransitionInfoOverride ?? null
		}, "New", n.IsNavigationStackEnabled ?? q.value), $ = {
			get Content() {
				return J.value;
			},
			set Content(e) {
				J.value = e;
			},
			get CanGoBack() {
				return de.value;
			},
			get CanGoForward() {
				return fe.value;
			},
			get BackStack() {
				return H.value;
			},
			get ForwardStack() {
				return U.value;
			},
			get BackStackDepth() {
				return H.value.length;
			},
			get CurrentSourcePageType() {
				return T.value?.SourcePageType ?? null;
			},
			get IsNavigationStackEnabled() {
				return q.value;
			},
			set IsNavigationStackEnabled(e) {
				q.value = e;
			},
			Navigate: ge,
			NavigateToType: ve,
			GoBack: Q,
			GoForward: _e
		}, ye = p({
			name: "FrameNavigationPage",
			__scopeId: C?.type?.__scopeId,
			props: {
				Layer: {
					type: Object,
					required: !0
				},
				IsLeaving: {
					type: Boolean,
					default: !1
				},
				IsAnimating: {
					type: Boolean,
					default: !1
				},
				IsPreparing: {
					type: Boolean,
					default: !1
				},
				Timeline: {
					type: Object,
					default: null
				},
				IsStarted: {
					type: Boolean,
					default: !1
				}
			},
			setup(e) {
				ae(r, v({}));
				let t = (t) => {
					t ? P.set(e.Layer.Version, t) : P.delete(e.Layer.Version);
				};
				return () => {
					let n = e.Layer, r = e.IsAnimating && !e.IsLeaving && !e.IsStarted && e.Timeline, i = e.IsLeaving || e.IsAnimating && e.Timeline?.DisableHitTesting;
					return h("div", {
						ref: (e) => {
							e instanceof HTMLElement ? N.set(n.Version, e) : N.delete(n.Version);
						},
						class: ["win-frame-navigation-page", { "is-leaving": e.IsLeaving }],
						"aria-hidden": e.IsLeaving || void 0,
						inert: i || void 0,
						style: {
							pointerEvents: i ? "none" : void 0,
							...r ? e.Timeline.Entrance.InitialStyle : {},
							...e.IsPreparing ? { opacity: 0 } : {}
						}
					}, [h(d, { onResolve: () => he(n.Version) }, { default: () => h(n.Entry.SourcePageType, {
						ref: t,
						Parameter: n.Entry.Parameter,
						NavigationTransitionInfo: n.Entry.NavigationTransitionInfo,
						NavigationVersion: n.Version
					}) })]);
				};
			}
		}), be = p({ setup() {
			return () => {
				if (D.value) return h(u, (O.value ? [O.value, D.value] : [D.value]).map((e) => h(ye, {
					key: e.Version,
					Layer: e,
					IsLeaving: e === O.value,
					IsAnimating: A.value,
					Timeline: k.value,
					IsPreparing: j.value && e === D.value,
					IsStarted: M.value
				})));
				let t = S.default?.().filter((e) => !l(e));
				return t?.length ? h(u, e(t, C)) : J.value === null || J.value === void 0 ? null : te(J.value) ? e([J.value], C) : typeof J.value == "object" ? h(J.value) : String(J.value);
			};
		} });
		re(() => {
			B = !0, X(), P.clear();
		}), ie((e) => {
			let t = R;
			if (!t) return;
			X(), T.value = t.Previous.Entry, D.value = t.Previous.Layer, G.value = t.Previous.Content, H.value = t.Previous.BackStack, U.value = t.Previous.ForwardStack, w("update:Content", G.value);
			let n = {
				SourcePageType: t.Args.SourcePageType,
				Exception: e,
				Handled: !1
			};
			return Y("NavigationFailed", n), n.Handled ? !1 : void 0;
		}), b($);
		let xe = {
			props: x,
			attrs: ue,
			slots: S,
			instance: C,
			emit: w,
			currentEntry: T,
			frameElement: E,
			currentLayer: D,
			outgoingLayer: O,
			activeTimeline: k,
			navigationAnimating: A,
			navigationPreparing: j,
			navigationAnimationStarted: M,
			layerElements: N,
			layerPages: P,
			get navigationAnimations() {
				return F;
			},
			set navigationAnimations(e) {
				F = e;
			},
			get navigationStyleRestorers() {
				return I;
			},
			set navigationStyleRestorers(e) {
				I = e;
			},
			get transitionGeneration() {
				return L;
			},
			set transitionGeneration(e) {
				L = e;
			},
			get pendingNavigationCommit() {
				return R;
			},
			set pendingNavigationCommit(e) {
				R = e;
			},
			get navigatedRedirectCapture() {
				return z;
			},
			set navigatedRedirectCapture(e) {
				z = e;
			},
			get frameUnmounted() {
				return B;
			},
			set frameUnmounted(e) {
				B = e;
			},
			get navigationCommitFrame() {
				return V;
			},
			set navigationCommitFrame(e) {
				V = e;
			},
			backStack: H,
			forwardStack: U,
			navigationVersion: W,
			localContent: G,
			localNavigationStackEnabled: K,
			navigationStackEnabled: q,
			content: J,
			canGoBack: de,
			canGoForward: fe,
			frameStyle: pe,
			navigationEvent: Y,
			clearNavigationTransition: X,
			beginNavigationTransition: me,
			commitNavigation: Z,
			navigationPageReady: he,
			navigate: ge,
			goBack: Q,
			goForward: _e,
			navigateToType: ve,
			publicApi: $,
			NavigationPage: ye,
			ContentOutlet: be
		};
		return Object.defineProperty(xe, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), xe;
	}
});
//#endregion
export { b as default };

//# sourceMappingURL=Frame.vue_vue_type_script_setup_true_lang.js.map