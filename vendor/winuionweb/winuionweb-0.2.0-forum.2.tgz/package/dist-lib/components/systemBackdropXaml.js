import { resolveXamlValue as e } from "./xamlRuntime.js";
import { DesktopAcrylicBackdrop as t, MicaBackdrop as n } from "./systemBackdrop.js";
import { defineComponent as r, getCurrentInstance as i, markRaw as a, watch as o } from "vue";
//#region src/components/systemBackdropXaml.ts
var s = (e, t) => {
	let r = a(new n()), i = o(() => e("Kind"), (e) => {
		r.Kind = e === "BaseAlt" ? "BaseAlt" : "Base";
	}, { immediate: !0 });
	return t?.Dispose(i), r;
}, c = () => a(new t()), l = r({
	name: "MicaBackdrop",
	__xamlDependencyObject: !0,
	__systemBackdropDeclaration: !0,
	__createXamlResource: s,
	inheritAttrs: !1,
	props: { Kind: {
		type: String,
		default: "Base"
	} },
	setup(t, { expose: n }) {
		let r = i();
		return n(s((n) => e(t[n], r))), () => null;
	}
}), u = r({
	name: "DesktopAcrylicBackdrop",
	__xamlDependencyObject: !0,
	__systemBackdropDeclaration: !0,
	__createXamlResource: c,
	inheritAttrs: !1,
	setup(e, { expose: t }) {
		return t(c()), () => null;
	}
}), d = r({
	name: "SystemBackdropElement.SystemBackdrop",
	__systemBackdropProperty: !0,
	setup() {
		return () => null;
	}
});
//#endregion
export { u as DesktopAcrylicBackdrop, l as MicaBackdrop, d as SystemBackdropElementSystemBackdrop };

//# sourceMappingURL=systemBackdropXaml.js.map