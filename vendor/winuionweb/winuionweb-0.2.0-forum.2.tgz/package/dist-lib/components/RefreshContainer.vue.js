import e from "../_virtual/_plugin-vue_export-helper.js";
import "./RefreshProperties.js";
import t from "./RefreshContainer.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                                     */
import { createElementBlock as n, createElementVNode as r, createVNode as i, mergeProps as a, normalizeStyle as o, openBlock as s } from "vue";
//#region src/components/RefreshContainer.vue
var c = ["aria-disabled", "inert"];
function l(e, t, l, u, d, f) {
	return s(), n("div", a({
		ref: "rootRef",
		class: "win-refresh-container"
	}, u.rootAttrs, {
		style: u.rootStyle,
		"aria-disabled": u.enabled ? void 0 : !0,
		inert: u.enabled ? void 0 : !0,
		onPointerdown: u.onPointerDown,
		onPointermove: u.onPointerMove,
		onPointerup: u.onPointerUp,
		onPointercancel: u.cancelGesture,
		onLostpointercapture: u.onLostPointerCapture,
		onScrollCapture: u.updateScrollBoundary
	}), [r("div", {
		class: "refresh-container-content-presenter",
		style: o(u.contentPresenterStyle)
	}, [i(u.ContentOutlet)], 4), r("div", {
		class: "refresh-visualizer-presenter",
		style: o(u.visualizerPresenterStyle),
		"aria-hidden": "true"
	}, [i(u.VisualizerOutlet)], 4)], 16, c);
}
var u = /*#__PURE__*/ e(t, [
	["render", l],
	["__scopeId", "data-v-22b6fa90"],
	["__file", "RefreshContainer.vue"]
]);
//#endregion
export { u as default };

//# sourceMappingURL=RefreshContainer.vue.js.map