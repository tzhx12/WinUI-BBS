import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./TabViewItem.vue_vue_type_script_setup_true_lang.js";
import { createBlock as n, createCommentVNode as r, createElementBlock as i, createElementVNode as a, createVNode as o, mergeProps as s, normalizeClass as c, openBlock as l, toDisplayString as u, withModifiers as d } from "vue";
//#region src/components/TabViewItem.vue
var f = [
	"tabindex",
	"aria-selected",
	"aria-disabled",
	"aria-controls",
	"accesskey",
	"draggable",
	"data-visual-state",
	"data-drag-state"
], p = {
	key: 0,
	class: "win-tab-view-selected-background",
	"data-part": "SelectedBackgroundPath",
	"aria-hidden": "true"
}, m = {
	key: 1,
	class: "win-tab-view-tab-separator",
	"data-part": "TabSeparator"
}, h = {
	class: "win-tab-view-tab-container",
	"data-part": "TabContainer"
}, g = {
	key: 0,
	class: "win-tab-view-icon-box",
	"data-part": "IconBox"
}, _ = {
	class: "win-tab-view-header-content",
	"data-part": "ContentPresenter"
}, v = { class: "win-tab-view-header-value" }, y = {
	class: "win-tab-view-header-measure",
	"aria-hidden": "true"
}, b = ["disabled", "aria-label"];
function x(e, t, x, S, C, w) {
	return l(), i("div", s({ ref: "rootRef" }, S.rootAttrs, {
		class: ["win-tab-view-item", [S.attrs.class, {
			"is-selected": S.selected,
			"is-disabled": !S.enabled,
			"is-pointer-over": S.hovered,
			"is-pressed": S.pressed,
			"is-compact": S.compact,
			"has-icon": S.hasIcon,
			"has-close": S.showClose,
			"is-closable": S.closable,
			"is-dragging": S.owner?.Dragging(S.key())
		}]],
		style: [S.attrs.style, S.rootStyle],
		role: "tab",
		tabindex: S.enabled && S.property("IsTabStop") !== !1 ? S.owner?.TabIndex(S.key()) ?? 0 : -1,
		"aria-selected": S.selected,
		"aria-disabled": !S.enabled,
		"aria-controls": S.owner?.PanelId(S.key()),
		accesskey: S.tabViewText(S.property("AccessKey")) || void 0,
		draggable: S.enabled && S.owner?.CanDrag(),
		"data-part": "LayoutRoot",
		"data-visual-state": S.visualState,
		"data-drag-state": S.owner?.Dragging(S.key()) ? S.owner?.IsNativeDrag() ? "Dragging" : "Reordering" : "NotDragging",
		onClick: S.select,
		onKeydown: S.keyDown,
		onFocus: t[2] ||= (e) => S.owner?.SetFocused(S.key()),
		onContextmenu: S.contextMenu,
		onPointerenter: t[3] ||= (e) => S.hovered = S.isHoverPointer(e),
		onPointerleave: t[4] ||= (e) => {
			S.hovered = !1, S.pressed = !1;
		},
		onPointerdown: S.pointerDown,
		onPointerup: S.pointerUp,
		onPointercancel: t[5] ||= (e) => S.pressed = !1,
		onLostpointercapture: t[6] ||= (e) => S.pressed = !1,
		onAuxclick: t[7] ||= d(() => {}, ["prevent"]),
		onDragstart: t[8] ||= (e) => S.owner?.DragStart(e, S.key()),
		onDragend: t[9] ||= (e) => S.owner?.DragEnd(e)
	}), [
		t[11] ||= a("div", {
			class: "win-tab-view-bottom-border-line",
			"data-part": "BottomBorderLine"
		}, null, -1),
		S.selected ? (l(), i("div", p)) : r("", !0),
		S.owner?.Separator(S.key()) ?? !S.selected ? (l(), i("div", m)) : r("", !0),
		t[12] ||= a("div", {
			class: "win-tab-view-tab-drag-visual",
			"data-part": "TabDragVisualContainer"
		}, null, -1),
		a("div", h, [
			S.hasIcon ? (l(), i("div", g, [o(S.IconOutlet)])) : r("", !0),
			a("div", _, [a("span", v, [o(S.HeaderOutlet)]), a("span", y, u(S.tabViewText(S.property("Header"))), 1)]),
			S.closable ? (l(), i("button", {
				key: 1,
				ref: "closeButtonRef",
				class: c(["win-tab-view-close-button", { "is-visible": S.showClose }]),
				type: "button",
				"data-part": "CloseButton",
				tabindex: "-1",
				disabled: !S.enabled,
				"aria-label": S.closeName,
				onPointerdown: t[0] ||= d(() => {}, ["stop"]),
				onClick: t[1] ||= d((e) => S.owner?.Close(S.key()), ["stop"])
			}, [...t[10] ||= [a("span", { class: "win-tab-view-glyph" }, "", -1)]], 42, b)) : r("", !0)
		]),
		o(S.ContextFlyoutOutlet),
		S.hasAuthorToolTip ? (l(), n(S.ToolTipDeclarationOutlet, { key: 2 })) : (l(), n(S.TabViewTemplateToolTip, {
			key: 3,
			Owner: S.rootRef,
			Content: S.headerToolTip,
			Placement: "Mouse",
			IsEnabled: S.enabled
		}, null, 8, [
			"Owner",
			"Content",
			"IsEnabled"
		])),
		o(S.TabViewTemplateToolTip, {
			Owner: S.closeButtonRef,
			Content: S.closeTooltip,
			IsEnabled: S.enabled && S.closable && S.showClose
		}, null, 8, [
			"Owner",
			"Content",
			"IsEnabled"
		])
	], 16, f);
}
var S = /*#__PURE__*/ e(t, [["render", x], ["__file", "TabViewItem.vue"]]);
//#endregion
export { S as default };

//# sourceMappingURL=TabViewItem.vue.js.map