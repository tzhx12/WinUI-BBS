import { computed as e, onScopeDispose as t, ref as n, watch as r } from "vue";
//#region src/components/uiCommandRuntime.ts
var i = (i) => {
	let a = n(0), o = () => {};
	return r(i, (e) => {
		o();
		let t = e, n = () => {
			a.value += 1;
		};
		t?.addEventListener?.("CanExecuteChanged", n), t?.addEventListener?.("PropertyChanged", n), o = () => {
			t?.removeEventListener?.("CanExecuteChanged", n), t?.removeEventListener?.("PropertyChanged", n);
		}, n();
	}, {
		immediate: !0,
		flush: "sync"
	}), t(() => o()), e(() => {
		a.value;
		let e = i();
		return e && new Proxy(e, { get: (e, t) => {
			let n = Reflect.get(e, t, e);
			return typeof n == "function" ? n.bind(e) : n;
		} });
	});
};
//#endregion
export { i as useUICommand };

//# sourceMappingURL=uiCommandRuntime.js.map