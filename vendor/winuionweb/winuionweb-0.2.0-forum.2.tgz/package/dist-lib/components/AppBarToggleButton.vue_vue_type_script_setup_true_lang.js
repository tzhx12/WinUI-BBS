import { normalizeXamlNodes as e, resolveXamlHandler as t, resolveXamlValue as n, updateXamlBinding as r, xamlControlIdentityKey as i, xamlScopeKey as a } from "./xamlRuntime.js";
import { appBarBoolean as o, appBarProperty as s, appBarToggleContextKey as c } from "./appBarRuntime.js";
import l from "./AppBarButton.vue.js";
import { computed as u, defineComponent as d, getCurrentInstance as f, h as p, inject as m, provide as h, ref as g, unref as _, useAttrs as v, useSlots as y, watch as b } from "vue";
//#region src/components/AppBarToggleButton.vue?vue&type=script&setup=true&lang.ts
var x = s("AppBarToggleButton", "Icon"), S = s("AppBarToggleButton", "Content"), C = s("AppBarToggleButton", "KeyboardAccelerators"), w = /*@__PURE__*/ d({
	Icon: x,
	Content: S,
	KeyboardAccelerators: C,
	name: "AppBarToggleButton",
	inheritAttrs: !1,
	__name: "AppBarToggleButton",
	props: {
		IsChecked: {
			type: [Boolean, String],
			default: !1
		},
		IsThreeState: {
			type: [Boolean, String],
			default: !1
		}
	},
	emits: [
		"Click",
		"Checked",
		"Unchecked",
		"Indeterminate",
		"update:IsChecked",
		"update:IsThreeState"
	],
	setup(s, { expose: w, emit: T }) {
		let E = s, D = T, O = v(), k = y(), A = f(), j = g(null), M = (e) => e === null || e === "{x:Null}" ? null : o(e), N = (e) => n(e, A), P = g(M(N(E.IsChecked))), F = g(void 0), I = u({
			get: () => F.value === void 0 ? o(N(E.IsThreeState)) : o(F.value),
			set: (e) => {
				F.value = e, r(E.IsThreeState, e, A), D("update:IsThreeState", e);
			}
		}), L = u(() => Object.fromEntries(Object.entries(O).filter(([e]) => !/^(Click|Checked|Unchecked|Indeterminate)$/.test(e)))), R = /* @__PURE__ */ "Label,Icon,Content,Command,CommandParameter,IsCompact,LabelPosition,DynamicOverflowOrder,IsEnabled,IsTabStop,Visibility,AllowFocusOnInteraction,AllowFocusWhenDisabled,KeyboardAccelerators,KeyboardAcceleratorTextOverride,KeyboardAcceleratorPlacementMode,Background,Foreground,BorderBrush,BorderThickness,CornerRadius,Padding,Margin,Width,Height,MinWidth,MinHeight,MaxWidth,MaxHeight,FontFamily,FontWeight,FontSize,HorizontalAlignment,VerticalAlignment,HorizontalContentAlignment,VerticalContentAlignment,FlowDirection,Style,AutomationProperties.Name,ToolTipService.ToolTip".split(","), z = Object.fromEntries(R.map((e) => [e, u({
			get: () => j.value?.[e] ?? N(O[e]),
			set: (t) => {
				j.value && (j.value[e] = t);
			}
		})])), B = {
			...z,
			[i]: !0
		}, V = new Proxy(B, {
			get: (e, t) => _(Reflect.get(e, t)),
			set: (e, t, n) => {
				let r = Reflect.get(e, t);
				return r && typeof r == "object" && "value" in r && (r.value = n), !0;
			}
		}), H = () => V, U = (e, n) => {
			D(e, H(), n), O[e] !== void 0 && !A?.vnode.props?.[`on${e}`] && t(O[e], A)?.(H(), n);
		}, W = (e, t, n = !0) => {
			P.value !== e && (P.value = e, n && (r(E.IsChecked, e, A), D("update:IsChecked", e)), U(e === !0 ? "Checked" : e === !1 ? "Unchecked" : "Indeterminate", {
				OriginalSource: H(),
				Handled: !1,
				OriginalEvent: t
			}));
		}, G = u({
			get: () => P.value,
			set: (e) => W(M(e))
		});
		b(() => N(E.IsChecked), (e) => W(M(e), void 0, !1)), b(() => N(E.IsThreeState), () => {
			F.value = void 0;
		});
		let K = (e) => {
			W(P.value === !0 ? I.value ? null : !1 : P.value !== null, e);
		}, q = (e, t) => U("Click", t);
		h(c, {
			checked: G,
			toggle: K,
			sender: H
		}), h(a, {
			...m(a, {}),
			OnAppBarButtonClick: q
		});
		let J = d({
			name: "AppBarToggleButtonTemplate",
			setup() {
				let t = f(), n = (e) => {
					j.value = e;
				};
				return () => e([p(l, {
					...L.value,
					Click: "OnAppBarButtonClick",
					ref: n
				}, { default: () => k.default?.() ?? [] })], t)[0] ?? null;
			}
		});
		Object.assign(B, {
			IsChecked: G,
			IsThreeState: I,
			Name: u(() => String(N(O["data-xaml-ref"] ?? O["x:Name"] ?? O.Name ?? ""))),
			IsInOverflow: u(() => j.value?.IsInOverflow ?? !1),
			ActualWidth: u(() => j.value?.ActualWidth ?? 0),
			ActualHeight: u(() => j.value?.ActualHeight ?? 0),
			Focus: (e) => j.value?.Focus?.(e) ?? !1,
			$el: u(() => j.value?.$el)
		}), w(V);
		let Y = {
			AppBarToggleButtonIcon: x,
			AppBarToggleButtonContent: S,
			AppBarToggleButtonKeyboardAccelerators: C,
			props: E,
			emit: D,
			attrs: O,
			slots: k,
			instance: A,
			buttonRef: j,
			normalizeChecked: M,
			resolve: N,
			checkedValue: P,
			threeStateOverride: F,
			isThreeState: I,
			buttonAttrs: L,
			forwardedProperties: R,
			forwarded: z,
			publicProperties: B,
			eventSender: V,
			sender: H,
			dispatch: U,
			setChecked: W,
			isChecked: G,
			toggle: K,
			onButtonClick: q,
			ButtonPresenter: J
		};
		return Object.defineProperty(Y, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), Y;
	}
});
//#endregion
export { S as AppBarToggleButtonContent, x as AppBarToggleButtonIcon, C as AppBarToggleButtonKeyboardAccelerators, w as default };

//# sourceMappingURL=AppBarToggleButton.vue_vue_type_script_setup_true_lang.js.map