import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./ParallaxView.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                                 */
import { createElementBlock as n, createElementVNode as r, createVNode as i, normalizeStyle as a, openBlock as o } from "vue";
//#region src/components/ParallaxView.vue
function s(e, t, s, c, l, u) {
	return o(), n("div", {
		ref: "rootRef",
		class: "win-parallax-view",
		style: a(c.rootStyle)
	}, [r("div", {
		ref: "childHostRef",
		class: "parallax-child",
		style: a(c.childStyle)
	}, [i(c.ChildOutlet)], 4)], 4);
}
var c = /*#__PURE__*/ e(t, [
	["render", s],
	["__scopeId", "data-v-9d5b1a21"],
	["__file", "ParallaxView.vue"]
]);
//#endregion
export { c as default };

//# sourceMappingURL=ParallaxView.vue.js.map