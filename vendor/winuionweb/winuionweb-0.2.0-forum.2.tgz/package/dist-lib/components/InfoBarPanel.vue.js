import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./InfoBarPanel.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                                 */
import { createElementBlock as n, createVNode as r, normalizeClass as i, normalizeStyle as a, openBlock as o } from "vue";
//#region src/components/InfoBarPanel.vue
function s(e, t, s, c, l, u) {
	return o(), n("div", {
		ref: "root",
		class: i(["win-infobar-panel", { "is-vertical": c.isVertical }]),
		style: a(c.panelStyle)
	}, [r(c.ChildrenOutlet)], 6);
}
var c = /*#__PURE__*/ e(t, [
	["render", s],
	["__scopeId", "data-v-4394c16b"],
	["__file", "InfoBarPanel.vue"]
]);
//#endregion
export { c as default };

//# sourceMappingURL=InfoBarPanel.vue.js.map