import { alignment as e, useLayoutObserver as t, xamlThickness as n } from "./layout.js";
import { cssColor as r, isAcrylicBrush as i, isSolidColorBrush as a } from "./brushCore.js";
import { resolveBrushStyle as o } from "./AcrylicBrush.js";
import { resolveXamlValue as s, updateXamlBinding as c } from "./xamlRuntime.js";
import { brushProperty as l, useBrushProperty as u } from "./brushProperties.js";
import { vAcrylicBrush as d } from "./acrylicBrushVisual.js";
import f, { isRadialGradientBrush as p, radialGradientPaint as m } from "./RadialGradientVisual.js";
import { computed as h, defineComponent as g, getCurrentInstance as _, h as v, ref as y, useAttrs as b, useSlots as x, watch as S } from "vue";
var C = /*@__PURE__*/ g({
	Fill: l("Rectangle", "Fill"),
	Stroke: l("Rectangle", "Stroke"),
	inheritAttrs: !1,
	__name: "Rectangle",
	props: {
		Fill: {
			type: [String, Object],
			default: ""
		},
		Stroke: {
			type: [String, Object],
			default: ""
		},
		StrokeThickness: {
			type: [String, Number],
			default: ""
		},
		Stretch: {
			type: String,
			default: "Fill"
		},
		Width: {
			type: [String, Number],
			default: ""
		},
		Height: {
			type: [String, Number],
			default: ""
		},
		MinWidth: {
			type: [String, Number],
			default: ""
		},
		MinHeight: {
			type: [String, Number],
			default: ""
		},
		MaxWidth: {
			type: [String, Number],
			default: ""
		},
		MaxHeight: {
			type: [String, Number],
			default: ""
		},
		HorizontalAlignment: {
			type: String,
			default: "Stretch"
		},
		VerticalAlignment: {
			type: String,
			default: "Stretch"
		},
		RadiusX: {
			type: [String, Number],
			default: ""
		},
		RadiusY: {
			type: [String, Number],
			default: ""
		},
		Margin: {
			type: [String, Number],
			default: ""
		}
	},
	emits: ["update:Fill", "update:Stroke"],
	setup(l, { expose: C, emit: w }) {
		let T = l, E = b(), D = _(), O = y(null), k = y({
			X: 0,
			Y: 0
		});
		t(O, () => {
			if (!O.value) return;
			let e = O.value.offsetWidth, t = O.value.offsetHeight;
			(e !== k.value.X || t !== k.value.Y) && (k.value = {
				X: e,
				Y: t
			});
		});
		let A = x(), j = u("Fill", () => T.Fill, () => A.default?.() ?? [], D), M = u("Stroke", () => T.Stroke, () => A.default?.() ?? [], D), N = w, P = y(j.value.value), F = y(M.value.value);
		S(j.value, (e) => {
			P.value = e;
		}), S(M.value, (e) => {
			F.value = e;
		});
		let I = h({
			get: () => P.value,
			set: (e) => {
				P.value = s(e, D), c(T.Fill, e, D), N("update:Fill", e);
			}
		}), L = h({
			get: () => F.value,
			set: (e) => {
				F.value = s(e, D), c(T.Stroke, e, D), N("update:Stroke", e);
			}
		});
		C({
			Fill: I,
			Stroke: L,
			Element: O,
			ActualSize: k,
			ActualWidth: h(() => k.value.X),
			ActualHeight: h(() => k.value.Y)
		});
		let R = h(() => p(I.value) ? I.value : null), z = h(() => !!L.value || s(T.Stretch, D) !== "Fill"), B = (e, t = 0) => {
			let n = s(e, D);
			return n === "" || n == null || !Number.isFinite(Number(n)) ? t : Number(n);
		}, V = h(() => {
			let { X: e, Y: t } = k.value, n = Math.abs(B(T.StrokeThickness, 1)), r = L.value && n < e && n < t ? n : 0, i = Math.max(0, e - r), a = Math.max(0, t - r), o = s(T.Stretch, D);
			return o === "Uniform" ? i = a = Math.min(i, a) : o === "UniformToFill" ? i = a = Math.max(i, a) : o === "None" && (i = a = 0), {
				x: r / 2,
				y: r / 2,
				width: i,
				height: a,
				rx: Math.min(i / 2, Math.abs(B(T.RadiusX))),
				ry: Math.min(a / 2, Math.abs(B(T.RadiusY))),
				thickness: n
			};
		}), H = g({ setup: () => () => {
			let e = [], t = (t, n) => {
				if (p(t)) {
					let r = V.value, i = n === "stroke" ? r.thickness / 2 : 0, a = m(t, `rectangle-${D?.uid}-${n}`, {
						X: r.x - i,
						Y: r.y - i,
						Width: r.width + i * 2,
						Height: r.height + i * 2
					});
					return e.push(a.definition), {
						color: a.paint,
						opacity: a.opacity
					};
				}
				return a(t) ? {
					color: r(t.Color),
					opacity: t.Opacity
				} : {
					color: !t || i(t) ? "none" : r(t),
					opacity: 1
				};
			}, n = t(I.value, "fill"), o = t(L.value, "stroke"), { thickness: s, ...c } = V.value;
			return v("svg", {
				class: "win-rectangle-outline",
				width: "100%",
				height: "100%",
				"aria-hidden": "true",
				focusable: "false"
			}, [v("defs", e), v("rect", {
				...c,
				fill: n.color,
				"fill-opacity": n.opacity,
				stroke: o.color,
				"stroke-opacity": o.opacity,
				"stroke-width": s
			})]);
		} }), U = (e) => {
			let t = s(e, D);
			return t === "" || t == null ? "" : /^-?\d+(?:\.\d+)?$/.test(String(t).trim()) ? `${t}px` : String(t);
		}, W = {
			props: T,
			attrs: E,
			instance: D,
			root: O,
			actualSize: k,
			slots: A,
			fillBrush: j,
			strokeBrush: M,
			emit: N,
			currentFill: P,
			currentStroke: F,
			Fill: I,
			Stroke: L,
			radialFill: R,
			usesOutline: z,
			number: B,
			outline: V,
			OutlineVisual: H,
			cssLength: U,
			forwardedAttrs: h(() => {
				let { class: e, style: t, ...n } = E;
				return n;
			}),
			rectangleStyle: h(() => {
				let t = Math.abs(B(T.RadiusX)), r = Math.abs(B(T.RadiusY)), a = {
					width: U(T.Width) || void 0,
					height: U(T.Height) || void 0,
					margin: n(s(T.Margin, D)) || void 0,
					...z.value && !i(I.value) || R.value ? { background: "transparent" } : o(I.value, D),
					position: "relative",
					overflow: "hidden",
					minWidth: U(T.MinWidth) || void 0,
					minHeight: U(T.MinHeight) || void 0,
					maxWidth: U(T.MaxWidth) || void 0,
					maxHeight: U(T.MaxHeight) || void 0,
					justifySelf: e(T.HorizontalAlignment, "horizontal"),
					alignSelf: e(T.VerticalAlignment, "vertical"),
					borderRadius: t && r ? `${t}px / ${r}px` : void 0
				};
				return [E.style, a];
			}),
			get vAcrylicBrush() {
				return d;
			},
			get RadialGradientVisual() {
				return f;
			}
		};
		return Object.defineProperty(W, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), W;
	}
});
//#endregion
export { C as default };

//# sourceMappingURL=Rectangle.vue_vue_type_script_setup_true_lang.js.map