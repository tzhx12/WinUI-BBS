import { onBeforeUnmount as e, ref as t } from "vue";
//#region src/components/useFlyoutAnimation.ts
var n = {
	Origin: "edge",
	Direction: "top",
	Duration: 800,
	Easing: "cubic-bezier(0.092,1.003,0.028,0.997)",
	Margin: 15,
	StripSize: 36,
	RespectReducedMotion: !0
}, r = (e) => typeof e == "function" ? e() : e, i = (e, t, n) => Math.max(t, Math.min(n, e)), a = (e) => `polygon(${e.left}px ${e.top}px, ${e.right}px ${e.top}px, ${e.right}px ${e.bottom}px, ${e.left}px ${e.bottom}px)`, o = (e, t) => {
	let n = r(t);
	return n ? typeof n == "string" ? e?.querySelector(n) ?? null : n instanceof HTMLElement ? n : n.value instanceof HTMLElement ? n.value : null : null;
}, s = (e, t, i) => {
	let a = Math.max(1, Math.min(r(i) ?? n.StripSize, t === "left" || t === "right" ? e.width : e.height));
	switch (t) {
		case "bottom": return {
			left: 0,
			right: e.width,
			top: e.height - a,
			bottom: e.height
		};
		case "left": return {
			left: 0,
			right: a,
			top: 0,
			bottom: e.height
		};
		case "right": return {
			left: e.width - a,
			right: e.width,
			top: 0,
			bottom: e.height
		};
		default: return {
			left: 0,
			right: e.width,
			top: 0,
			bottom: a
		};
	}
}, c = (e) => ({
	left: 0,
	right: e.width,
	top: e.height / 2 - 2 / 2,
	bottom: e.height / 2 + 2 / 2
}), l = (e, t, n) => {
	let r = o(e, n);
	if (!r) return null;
	let a = r.getBoundingClientRect(), s = i(a.left - t.left, 0, t.width), c = i(a.right - t.left, s, t.width), l = i(a.top - t.top, 0, t.height), u = i(a.bottom - t.top, l, t.height);
	return u - l > 0 && c - s > 0 ? {
		left: s,
		right: c,
		top: l,
		bottom: u
	} : null;
}, u = (e, t) => {
	let n = typeof t == "function" ? t(e) : t;
	if (!n) return null;
	let r = i(n.left ?? 0, 0, e.width), a = i(n.right ?? e.width, r, e.width), o = i(n.top ?? 0, 0, e.height), s = i(n.bottom ?? e.height, o, e.height);
	return s - o > 0 && a - r > 0 ? {
		left: r,
		right: a,
		top: o,
		bottom: s
	} : null;
}, d = (e, t, i) => {
	let a = r(i.Origin) ?? n.Origin;
	return (a === "element" ? l(e, t, i.OriginElement) : a === "rect" ? u(t, i.StartRect) : a === "center" ? c(t) : null) ?? s(t, r(i.Direction) ?? n.Direction, i.StripSize);
}, f = (i, o = {}) => {
	let s = t(!1), c = null, l = () => {
		if (i instanceof HTMLElement) return i;
		let e = typeof i == "function" ? i() : i.value;
		return e instanceof HTMLElement ? e : null;
	}, u = () => {
		c &&= (c.cancel(), null);
		let e = l();
		e && (e.style.clipPath = ""), s.value = !1;
	}, f = (e) => {
		u();
		let t = l();
		if (!t || r(o.RespectReducedMotion) !== !1 && typeof window.matchMedia == "function" && window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
		let i = t.getBoundingClientRect();
		if (i.width === 0 || i.height === 0) return;
		let f = d(t, i, o), p = r(o.Margin) ?? n.Margin, m = {
			left: -p,
			right: i.width + p,
			top: -p,
			bottom: i.height + p
		}, h = r(o.Duration) ?? n.Duration, g = r(o.Easing) ?? n.Easing, _ = t.animate(e ? [{ clipPath: a(m) }, { clipPath: a(f) }] : [{ clipPath: a(f) }, { clipPath: a(m) }], {
			duration: h,
			easing: g,
			fill: "none"
		});
		c = _, s.value = !0, _.onfinish = () => {
			c === _ && (c = null, t.style.clipPath = "", s.value = !1);
		}, _.oncancel = () => {
			c === _ && (c = null, s.value = !1);
		};
	};
	return e(u), {
		play: () => f(!1),
		playReverse: () => f(!0),
		cancel: u,
		isPlaying: s
	};
};
//#endregion
export { f as useFlyoutAnimation };

//# sourceMappingURL=useFlyoutAnimation.js.map