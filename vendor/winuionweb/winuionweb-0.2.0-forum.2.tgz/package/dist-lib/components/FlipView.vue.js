import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./FlipView.vue_vue_type_script_setup_true_lang.js";
/* empty css                                             */
import { Fragment as n, createBlock as r, createElementBlock as i, createElementVNode as a, mergeProps as o, normalizeClass as s, normalizeStyle as c, openBlock as l, renderList as u, resolveDynamicComponent as d, withDirectives as f } from "vue";
//#region src/components/FlipView.vue
var p = [
	"HorizontalAlignment",
	"VerticalAlignment",
	"tabindex",
	"aria-disabled",
	"aria-orientation",
	"aria-activedescendant",
	"aria-label"
], m = [
	"id",
	"aria-selected",
	"aria-posinset",
	"aria-setsize",
	"tabindex",
	"onFocusin"
], h = [
	"disabled",
	"aria-hidden",
	"aria-label"
], g = [
	"disabled",
	"aria-hidden",
	"aria-label"
];
function _(e, t, _, v, y, b) {
	return f((l(), i("div", o({ ref: "rootRef" }, v.forwardedAttrs, {
		class: ["win-flip-view", [v.orientationClass, {
			disabled: !v.isEnabled,
			rtl: v.isRtl,
			focused: v.hasFocus
		}]],
		style: v.rootStyle,
		HorizontalAlignment: v.horizontalAlignment,
		VerticalAlignment: v.verticalAlignment,
		role: "listbox",
		tabindex: v.rootTabIndex,
		"aria-disabled": !v.isEnabled,
		"aria-orientation": v.orientationClass,
		"aria-activedescendant": v.activeDescendantId,
		"aria-label": v.automationName,
		onPointerenter: t[10] ||= (e) => v.onMouseEnter(e),
		onPointerleave: v.onMouseLeave,
		onFocusin: v.onFocusIn,
		onFocusout: v.onFocusOut,
		onKeydown: v.onKeyDown,
		onWheel: v.onWheel,
		onPointerdown: v.onPointerDown,
		onPointermove: v.onPointerMove,
		onPointerup: v.onPointerUp,
		onPointercancel: v.onPointerCancel,
		onLostpointercapture: v.onLostPointerCapture,
		onTouchstart: v.onTouchStart,
		onTouchmove: v.onTouchMove,
		onTouchend: v.onTouchEnd,
		onTouchcancel: v.onTouchCancel
	}), [
		a("div", {
			class: "flip-view-track",
			style: c(v.trackStyle),
			"aria-live": "polite"
		}, [(l(!0), i(n, null, u(v.items, (e, t) => (l(), i("div", {
			id: v.itemId(t),
			key: v.getItemKey(e, t),
			class: s(["flip-view-item", { selected: t === v.selectedIndex }]),
			style: c(v.itemStyle),
			role: "option",
			"aria-selected": t === v.selectedIndex,
			"aria-posinset": t + 1,
			"aria-setsize": v.items.length,
			tabindex: t === v.selectedIndex ? 0 : -1,
			onFocusin: (e) => v.onItemFocus(t)
		}, [(l(), r(d(v.ItemRenderer), {
			item: e,
			index: t
		}, null, 8, ["item", "index"]))], 46, m))), 128))], 4),
		f((l(), i("button", {
			type: "button",
			class: s(["flip-btn prev", { visible: v.previousButtonVisible }]),
			style: c(v.previousButtonBackgroundStyle),
			disabled: !v.isEnabled || v.selectedIndex <= 0,
			"aria-hidden": !v.previousButtonVisible,
			"aria-label": v.previousLabel,
			tabindex: "-1",
			onPointerenter: t[0] ||= (e) => v.onNavigationButtonEnter(e, "previous"),
			onPointerdown: t[1] ||= (e) => v.onNavigationButtonPressed("previous"),
			onPointerup: t[2] ||= (e) => v.onNavigationButtonReleased(e, "previous"),
			onPointercancel: t[3] ||= (e) => v.onNavigationButtonCanceled("previous"),
			onPointerleave: t[4] ||= (e) => {
				v.previousButtonState = "", v.onButtonLeave();
			},
			onClick: v.prev
		}, [v.orientationClass === "horizontal" ? (l(), r(v.FontIcon, {
			key: 0,
			class: "flip-arrow",
			Glyph: "",
			FontFamily: "{ThemeResource SymbolThemeFontFamily}",
			FontSize: "{ThemeResource FlipViewButtonFontSize}",
			Foreground: "{ThemeResource FlipViewNextPreviousArrowForeground}",
			HorizontalAlignment: "Center",
			VerticalAlignment: "Center",
			MirroredWhenRightToLeft: "True",
			UseLayoutRounding: "False",
			"aria-hidden": "true"
		})) : (l(), r(v.FontIcon, {
			key: 1,
			class: "flip-arrow",
			Glyph: "",
			FontFamily: "{ThemeResource SymbolThemeFontFamily}",
			FontSize: "{ThemeResource FlipViewButtonFontSize}",
			Foreground: "{ThemeResource FlipViewNextPreviousArrowForeground}",
			HorizontalAlignment: "Center",
			VerticalAlignment: "Center",
			UseLayoutRounding: "False",
			"aria-hidden": "true"
		}))], 46, h)), [[
			v.vAcrylicBrush,
			v.previousButtonBackgroundStyle,
			void 0,
			{ "host-backdrop": !0 }
		]]),
		f((l(), i("button", {
			type: "button",
			class: s(["flip-btn next", { visible: v.nextButtonVisible }]),
			style: c(v.nextButtonBackgroundStyle),
			disabled: !v.isEnabled || v.selectedIndex >= v.items.length - 1,
			"aria-hidden": !v.nextButtonVisible,
			"aria-label": v.nextLabel,
			tabindex: "-1",
			onPointerenter: t[5] ||= (e) => v.onNavigationButtonEnter(e, "next"),
			onPointerdown: t[6] ||= (e) => v.onNavigationButtonPressed("next"),
			onPointerup: t[7] ||= (e) => v.onNavigationButtonReleased(e, "next"),
			onPointercancel: t[8] ||= (e) => v.onNavigationButtonCanceled("next"),
			onPointerleave: t[9] ||= (e) => {
				v.nextButtonState = "", v.onButtonLeave();
			},
			onClick: v.next
		}, [v.orientationClass === "horizontal" ? (l(), r(v.FontIcon, {
			key: 0,
			class: "flip-arrow",
			Glyph: "",
			FontFamily: "{ThemeResource SymbolThemeFontFamily}",
			FontSize: "{ThemeResource FlipViewButtonFontSize}",
			Foreground: "{ThemeResource FlipViewNextPreviousArrowForeground}",
			HorizontalAlignment: "Center",
			VerticalAlignment: "Center",
			MirroredWhenRightToLeft: "True",
			UseLayoutRounding: "False",
			"aria-hidden": "true"
		})) : (l(), r(v.FontIcon, {
			key: 1,
			class: "flip-arrow",
			Glyph: "",
			FontFamily: "{ThemeResource SymbolThemeFontFamily}",
			FontSize: "{ThemeResource FlipViewButtonFontSize}",
			Foreground: "{ThemeResource FlipViewNextPreviousArrowForeground}",
			HorizontalAlignment: "Center",
			VerticalAlignment: "Center",
			UseLayoutRounding: "False",
			"aria-hidden": "true"
		}))], 46, g)), [[
			v.vAcrylicBrush,
			v.nextButtonBackgroundStyle,
			void 0,
			{ "host-backdrop": !0 }
		]])
	], 16, p)), [[v.vAcrylicBrush, v.backgroundStyle]]);
}
var v = /*#__PURE__*/ e(t, [["render", _], ["__file", "FlipView.vue"]]);
//#endregion
export { v as default };

//# sourceMappingURL=FlipView.vue.js.map