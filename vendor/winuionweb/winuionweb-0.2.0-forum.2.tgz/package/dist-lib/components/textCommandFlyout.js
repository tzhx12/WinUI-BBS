import e from "./AppBarButton.vue.js";
import t from "./CommandBarFlyout.vue.js";
import { defineComponent as n, h as r, provide as i } from "vue";
//#region src/components/textCommandFlyout.ts
var a = {
	cut: "Cut",
	copy: "Copy",
	paste: "Paste",
	undo: "Undo",
	redo: "Redo",
	selectAll: "SelectAll"
}, o = (o, s, c, l, u = () => ({})) => n({
	name: "TextCommandBarFlyout",
	setup() {
		return i("buttonFlyoutAnchor", null), i("buttonFlyoutController", null), () => {
			let n = u(), i = n.ShowMode === "Transient", d = (t) => s().filter((e) => (i && [
				"cut",
				"copy",
				"paste"
			].includes(e.Value ?? "")) === t).map((t) => r(e, {
				key: t.Value,
				Label: t.Text,
				Icon: a[t.Value ?? ""] ?? t.Icon,
				LabelPosition: "Collapsed",
				IsEnabled: t.IsEnabled ?? !0,
				Click: () => c(t)
			}));
			return r(t, {
				Placement: "BottomEdgeAlignedLeft",
				...n,
				ref: o,
				onClosed: l
			}, { default: () => [r(t.PrimaryCommands, null, { default: () => d(!0) }), r(t.SecondaryCommands, null, { default: () => d(!1) })] });
		};
	}
});
//#endregion
export { o as textCommandFlyout };

//# sourceMappingURL=textCommandFlyout.js.map