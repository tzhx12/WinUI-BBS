//#region src/components/TitleBarDragRegion.ts
var e = Object.freeze({
	Owner: "TitleBar",
	Name: "IsDragRegion",
	ClearValue: (e) => i(e)
}), t = (e) => e && ("Element" in e || "$el" in e) ? e.Element ?? e.$el : e;
function n(e, n) {
	let r = t(e);
	if (!r || typeof r.setAttribute != "function") return;
	let i = n === !0 || n === !1 ? String(n) : null;
	if (r.getAttribute("TitleBar.IsDragRegion") === i) return;
	n === !0 || n === !1 ? r.setAttribute("TitleBar.IsDragRegion", String(n)) : r.removeAttribute("TitleBar.IsDragRegion");
	let a = r.ownerDocument.defaultView?.CustomEvent ?? globalThis.CustomEvent;
	r.dispatchEvent(new a("winui-titlebar-drag-region-changed", { bubbles: !0 }));
}
function r(e) {
	let n = t(e);
	if (!n || typeof n.getAttribute != "function") return null;
	let r = n.getAttribute("TitleBar.IsDragRegion");
	return r === null ? null : r === "true" || r === "True" ? !0 : r === "false" || r === "False" ? !1 : null;
}
function i(e) {
	n(e, null);
}
var a = "button,input,select,textarea,a[href],[contenteditable=\"true\"],[role=\"button\"],[role=\"textbox\"],[role=\"combobox\"],[role=\"checkbox\"],[role=\"radio\"],[role=\"switch\"],[role=\"slider\"],[role=\"listbox\"],[tabindex]:not([tabindex=\"-1\"]),.win-autosuggestbox,.win-person-picture";
function o(e) {
	let t = [], n = (e, i) => {
		let o = e.ownerDocument.defaultView?.getComputedStyle(e);
		if (e.hidden || o?.display === "none" || o?.visibility === "hidden" || o?.pointerEvents === "none") return;
		let s = r(e), c = e.matches(a);
		if (s === !1) {
			t.push(e);
			return;
		}
		if (s === !0 && c) return;
		let l = s === !0 || i, u = !e.matches(":disabled,[aria-disabled=\"true\"],.is-disabled");
		if (!l && c && u) {
			t.push(e);
			return;
		}
		for (let t of e.children) n(t, l);
	};
	for (let t of e.children) n(t, !1);
	return t;
}
//#endregion
export { e as IsDragRegionProperty, o as findTitleBarInteractableElements, r as getIsDragRegion, n as setIsDragRegion };

//# sourceMappingURL=TitleBarDragRegion.js.map