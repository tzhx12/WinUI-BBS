import { alignment as e, boolValue as t, cssLength as n, xamlThickness as r } from "./layout.js";
import { useAcrylicBrushStyle as i } from "./AcrylicBrush.js";
import { normalizeXamlNodes as a, resolveXamlHandler as ee, resolveXamlValue as te, updateXamlBinding as ne } from "./xamlRuntime.js";
import { vAcrylicBrush as o } from "./acrylicBrushVisual.js";
import s from "./Border.vue.js";
import { Comment as re, Fragment as ie, Text as ae, computed as c, defineComponent as oe, getCurrentInstance as se, h as ce, isVNode as le, nextTick as ue, onBeforeUnmount as de, onMounted as fe, proxyRefs as pe, ref as l, useAttrs as me, useSlots as he, watch as u } from "vue";
//#region src/components/SplitView.vue?vue&type=script&setup=true&lang.ts
var ge = (e) => oe({
	name: `SplitView.${e[0].toUpperCase()}${e.slice(1)}`,
	__splitViewProperty: e,
	setup(e, { slots: t }) {
		return () => ce(ie, t.default?.());
	}
}), _e = ge("pane"), ve = ge("content"), ye = /*@__PURE__*/ oe({
	Pane: _e,
	Content: ve,
	name: "SplitView",
	inheritAttrs: !1,
	__name: "SplitView",
	props: {
		Pane: {
			type: [
				String,
				Number,
				Object
			],
			default: ""
		},
		Content: {
			type: [
				String,
				Number,
				Object
			],
			default: ""
		},
		IsPaneOpen: {
			type: [Boolean, String],
			default: !1
		},
		DisplayMode: {
			type: String,
			default: "Overlay"
		},
		PanePlacement: {
			type: String,
			default: "Left"
		},
		OpenPaneLength: {
			type: [String, Number],
			default: "{ThemeResource SplitViewOpenPaneThemeLength}"
		},
		CompactPaneLength: {
			type: [String, Number],
			default: "{ThemeResource SplitViewCompactPaneThemeLength}"
		},
		PaneBackground: {
			type: [String, Object],
			default: "{ThemeResource SystemControlPageBackgroundChromeLowBrush}"
		},
		LightDismissOverlayMode: {
			type: String,
			default: "Auto"
		},
		Background: {
			type: [String, Object],
			default: ""
		},
		Foreground: {
			type: [String, Object],
			default: ""
		},
		BorderBrush: {
			type: [String, Object],
			default: "{ThemeResource SystemControlForegroundTransparentBrush}"
		},
		BorderThickness: {
			type: [String, Number],
			default: "0,0,1,0"
		},
		CornerRadius: {
			type: [String, Number],
			default: "{ThemeResource SplitViewPaneRootCornerRadius}"
		},
		Padding: {
			type: [String, Number],
			default: 0
		},
		HorizontalContentAlignment: {
			type: String,
			default: "Stretch"
		},
		VerticalContentAlignment: {
			type: String,
			default: "Stretch"
		},
		Width: {
			type: [String, Number],
			default: ""
		},
		Height: {
			type: [String, Number],
			default: ""
		},
		MinWidth: {
			type: [String, Number],
			default: 0
		},
		MinHeight: {
			type: [String, Number],
			default: 0
		},
		MaxWidth: {
			type: [String, Number],
			default: ""
		},
		MaxHeight: {
			type: [String, Number],
			default: ""
		},
		Margin: {
			type: [String, Number],
			default: 0
		},
		HorizontalAlignment: {
			type: String,
			default: "Stretch"
		},
		VerticalAlignment: {
			type: String,
			default: "Stretch"
		},
		IsTabStop: {
			type: [Boolean, String],
			default: !0
		},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		IsHitTestVisible: {
			type: [Boolean, String],
			default: !0
		},
		Opacity: {
			type: [String, Number],
			default: 1
		},
		Visibility: {
			type: String,
			default: "Visible"
		}
	},
	emits: [
		"update:IsPaneOpen",
		"update:DisplayMode",
		"update:PanePlacement",
		"update:OpenPaneLength",
		"update:CompactPaneLength",
		"update:PaneBackground",
		"update:Background",
		"update:LightDismissOverlayMode",
		"PaneOpening",
		"PaneOpened",
		"PaneClosing",
		"PaneClosed"
	],
	setup(ye, { expose: be, emit: xe }) {
		let d = ye, Se = xe, f = se(), Ce = me(), we = he(), p = l(null), m = l(null), h = l(null), g = l(null), _ = (e) => te(e, f), v = (e) => {
			let t = l(_(d[e]));
			return u(() => _(d[e]), (e) => {
				t.value = e;
			}, { flush: "sync" }), c({
				get: () => t.value,
				set: (n) => {
					t.value = _(n), ne(d[e], n, f), Se(`update:${e}`, n);
				}
			});
		}, y = v("IsPaneOpen"), b = v("DisplayMode"), Te = v("PanePlacement"), x = v("OpenPaneLength"), Ee = v("CompactPaneLength"), De = v("PaneBackground"), Oe = v("Background"), ke = i(() => Oe.value || "Transparent", f), Ae = i(() => De.value || "Transparent", f), je = v("LightDismissOverlayMode"), S = c(() => t(y.value)), C = c(() => [
			"Overlay",
			"Inline",
			"CompactOverlay",
			"CompactInline"
		].includes(String(b.value)) ? String(b.value) : "Overlay"), w = c(() => Te.value === "Right" ? "Right" : "Left"), T = c(() => C.value === "CompactOverlay" || C.value === "CompactInline"), E = c(() => C.value === "Overlay" || C.value === "CompactOverlay"), Me = c(() => t(_(d.IsEnabled))), D = l(0), O = c(() => x.value === "Auto" || typeof x.value == "number" && Number.isNaN(x.value)), k = (e, t) => {
			let n = Number(e);
			if (e !== "" && e != null && Number.isFinite(n)) return Math.max(0, n);
			let r = String(e ?? "").match(/^var\((--[^,)]+)(?:,\s*([^)]*))?\)$/);
			if (r && p.value) {
				let e = Number(getComputedStyle(p.value).getPropertyValue(r[1]).trim() || r[2]);
				if (Number.isFinite(e)) return Math.max(0, e);
			}
			return t;
		}, A = c(() => O.value ? D.value : k(x.value, 320)), j = c(() => k(Ee.value, 48)), M = l(S.value ? "Open" : "Closed"), Ne = c(() => M.value !== "Closed" || T.value), N = c(() => E.value ? T.value ? j.value : 0 : S.value ? A.value : T.value ? j.value : 0), Pe = c(() => S.value ? `Open${E.value ? T.value ? "CompactOverlay" : "Overlay" : "Inline"}${w.value}` : T.value ? `ClosedCompact${w.value}` : "Closed"), Fe = c(() => (w.value === "Right" ? 1 : -1) * A.value), Ie = c(() => `translateX(${!S.value && !T.value ? Fe.value : 0}px)`), Le = (e) => {
			let t = !e && T.value ? Math.max(0, A.value - j.value) : 0;
			return w.value === "Right" ? `inset(0px 0px 0px ${t}px)` : `inset(0px ${t}px 0px 0px)`;
		}, Re = c(() => Le(S.value)), ze = c(() => Object.fromEntries(Object.entries(Ce).filter(([e]) => e !== "class" && e !== "style" && (/^(?:data-|aria-|Grid\.|Canvas\.|RelativePanel\.)/.test(e) || ["id", "title"].includes(e))))), Be = c(() => {
			let i = `${N.value}px`, a = {
				gridTemplateColumns: w.value === "Right" ? `minmax(0, 1fr) ${i}` : `${i} minmax(0, 1fr)`,
				...ke.value,
				color: String(_(d.Foreground) || "var(--TextFillColorPrimaryBrush)"),
				margin: r(_(d.Margin)),
				justifySelf: e(_(d.HorizontalAlignment), "horizontal"),
				alignSelf: e(_(d.VerticalAlignment), "vertical"),
				pointerEvents: t(_(d.IsHitTestVisible)) ? void 0 : "none",
				opacity: k(_(d.Opacity), 1)
			};
			for (let e of [
				"Width",
				"Height",
				"MinWidth",
				"MinHeight",
				"MaxWidth",
				"MaxHeight"
			]) {
				let t = n(_(d[e]));
				t && (a[e[0].toLowerCase() + e.slice(1)] = t);
			}
			return _(d.Visibility) === "Collapsed" && (a.display = "none"), a;
		}), Ve = c(() => String(_(d.CornerRadius) ?? 0).split(",").map((e) => n(e.trim())).join(" ")), He = c(() => ({
			width: O.value && !D.value ? "max-content" : `${A.value}px`,
			left: w.value === "Left" ? "0" : void 0,
			right: w.value === "Right" ? "0" : void 0,
			display: Ne.value || O.value ? "grid" : "none",
			visibility: !Ne.value && O.value ? "hidden" : void 0,
			transform: Ie.value,
			clipPath: Re.value,
			...Ae.value,
			borderColor: String(_(d.BorderBrush) || "transparent"),
			borderWidth: r(_(d.BorderThickness)),
			borderRadius: Ve.value
		})), Ue = c(() => ({ gridColumn: w.value === "Right" ? "1" : "2" })), We = c(() => E.value && M.value !== "Closed"), Ge = c(() => ({
			background: je.value === "On" ? "var(--SplitViewLightDismissOverlayBackground)" : "transparent",
			opacity: +!!S.value
		})), P = (e) => (Array.isArray(e) ? e : e ? [e] : []).flatMap((e) => e.type === re || e.type === ae && !String(e.children ?? "").trim() ? [] : e.type === ie && Array.isArray(e.children) ? P(e.children) : [e]), Ke = (e) => Array.isArray(e.children) ? P(e.children) : P(e.children?.default?.() ?? []), qe = (e) => e.type?.__splitViewProperty, Je = (e) => {
			let t = P(we.default?.() ?? []), n = t.find((t) => qe(t) === e);
			return a(n ? Ke(n) : e === "content" ? t.filter((e) => !qe(e)) : [], f);
		}, Ye = (e) => oe({
			name: `SplitView${e === "pane" ? "Pane" : "Content"}Outlet`,
			setup() {
				return () => {
					let t = Je(e);
					if (t.length) return ce(ie, t);
					let n = _(e === "pane" ? d.Pane : d.Content);
					return le(n) ? n : typeof n == "string" || typeof n == "number" ? String(n) : null;
				};
			}
		}), Xe = Ye("pane"), Ze = Ye("content"), F = !1, I = !1, L = 0, R = [], z, B = null, V = !1, H = !1, U = N.value, W, G, K = null, q, Qe = l(!1), J, Y = () => {
			Qe.value = J?.matches ?? !1;
		}, X = (e, t = null) => {
			Se(e, gt, t), ee(Ce[e], f)?.(gt, t);
		}, $e = () => {
			R.forEach((e) => e.cancel()), R = [], z !== void 0 && clearTimeout(z), z = void 0;
		}, et = () => Array.from(m.value?.querySelectorAll("button,[href],input,select,textarea,[tabindex]:not([tabindex=\"-1\"])") ?? []).filter((e) => !e.hasAttribute("disabled") && !e.closest("[inert]") && e.getClientRects().length), tt = () => {
			if (!B) return;
			let e = B.isConnected ? B : h.value?.querySelector("button,[href],input,select,textarea,[tabindex]:not([tabindex=\"-1\"])");
			B = null, e?.focus({ preventScroll: !0 });
		}, nt = (e) => {
			if (e !== L || I) return;
			$e();
			let t = M.value === "Opening" || M.value === "Closing";
			M.value = S.value ? "Open" : "Closed", S.value || (V = !1), t && X(S.value ? "PaneOpened" : "PaneClosed");
		}, rt = (e, t, n, r) => {
			e?.animate && R.push(e.animate(t, {
				duration: n,
				easing: r,
				fill: "both"
			}));
		}, it = async (e, t) => {
			let n = ++L, r = m.value ? getComputedStyle(m.value) : null, i = h.value ? getComputedStyle(h.value).transform : "none", a = r && r.display !== "none" ? r.transform : `translateX(${t || T.value ? 0 : Fe.value}px)`, ee = r?.clipPath || Le(t), te = g.value ? getComputedStyle(g.value).opacity : t ? "1" : "0", ne = U;
			if (U = N.value, $e(), M.value = e ? "Opening" : "Closing", e) {
				if (V = !1, X("PaneOpening"), n !== L) return;
				E.value && (B = document.activeElement instanceof HTMLElement ? document.activeElement : null);
			} else {
				if (H || X("PaneClosing", { Cancel: !1 }), H = !1, n !== L) return;
				E.value && tt();
			}
			if (await ue(), n !== L || I) return;
			e && E.value && (et()[0] ?? m.value)?.focus({ preventScroll: !0 });
			let o = E.value ? e ? 350 : 120 : T.value && !e && w.value === "Left" || e ? 200 : 100, s = E.value ? "cubic-bezier(0.1, 0.9, 0.2, 1)" : "cubic-bezier(0, 0.35, 0.15, 1)";
			if (rt(m.value, [{
				transform: a,
				clipPath: ee
			}, {
				transform: Ie.value,
				clipPath: Re.value
			}], o, s), !E.value) {
				let t = (w.value === "Right" ? 1 : -1) * (U - ne), n = i && i !== "none" ? Number(i.match(/^matrix\([^,]+,[^,]+,[^,]+,[^,]+,\s*([^,]+),/)?.[1] || 0) : 0, r = T.value && w.value === "Right" ? 0 : n + t;
				rt(h.value, [{ transform: `translateX(${r}px)` }, { transform: "translateX(0px)" }], e ? 199.99 : o, s);
			}
			E.value && rt(g.value, [{ opacity: Number(te) }, { opacity: +!!e }], o, s), R.length ? Promise.all(R.map((e) => e.finished)).then(() => nt(n), () => {}) : z = setTimeout(() => nt(n), o);
		};
		u(S, (e, t) => {
			if (!F) {
				M.value = e ? "Open" : "Closed";
				return;
			}
			it(e, t);
		}, { flush: "sync" });
		let Z = () => {
			if (!S.value || !E.value || V || !Me.value) return;
			V = !0;
			let e = { Cancel: !1 };
			X("PaneClosing", e), queueMicrotask(() => {
				if (!I) {
					if (e.Cancel || !S.value) {
						V = !1;
						return;
					}
					H = !0, y.value = !1;
				}
			});
		}, at = (e) => {
			e.preventDefault(), e.stopPropagation();
		}, ot = (e) => {
			at(e), e.isPrimary && e.button === 0 && Z();
		}, Q = () => {
			K = null, q !== void 0 && clearTimeout(q), q = void 0, document.removeEventListener("pointerdown", st, !0), document.removeEventListener("pointerup", ct, !0), document.removeEventListener("pointercancel", lt, !0), document.removeEventListener("click", ut, !0), window.removeEventListener("blur", Q);
		}, $ = (e) => {
			at(e), e.stopImmediatePropagation();
		}, st = (e) => {
			e.isPrimary && Q();
		}, ct = (e) => {
			e.pointerId === K && ($(e), q = setTimeout(Q, 500));
		}, lt = (e) => {
			e.pointerId === K && ($(e), Q());
		}, ut = (e) => {
			K === null || e.detail === 0 || e instanceof PointerEvent && e.pointerId !== K || ($(e), Q());
		}, dt = (e) => {
			!Me.value || !S.value || !E.value || !p.value || p.value.contains(e.target) || !e.isPrimary || e.button !== 0 || (Q(), K = e.pointerId, document.addEventListener("pointerdown", st, !0), document.addEventListener("pointerup", ct, !0), document.addEventListener("pointercancel", lt, !0), document.addEventListener("click", ut, !0), window.addEventListener("blur", Q), $(e), Z());
		}, ft = () => Z(), pt = (e) => {
			if (e.defaultPrevented || !S.value || !E.value) return;
			if (e.key === "Escape") {
				at(e), Z();
				return;
			}
			if (e.key !== "Tab" || !m.value?.contains(document.activeElement)) return;
			let t = et(), n = t[0], r = t[t.length - 1];
			if (!n) {
				e.preventDefault(), m.value?.focus({ preventScroll: !0 });
				return;
			}
			(document.activeElement === m.value || (e.shiftKey ? document.activeElement === n : document.activeElement === r)) && (e.preventDefault(), (e.shiftKey ? r : n)?.focus({ preventScroll: !0 }));
		};
		u([
			C,
			w,
			A,
			j
		], (e, t) => {
			e[0] !== t[0] && tt(), U = N.value, nt(L);
		}), u([S, E], ([e, t]) => {
			typeof document > "u" || (e && t ? document.addEventListener("pointerdown", dt, !0) : document.removeEventListener("pointerdown", dt, !0));
		}, { immediate: !0 }), fe(() => {
			F = !0, J = window.matchMedia("(forced-colors: active)"), Y(), J.addEventListener("change", Y), window.addEventListener("resize", ft), typeof ResizeObserver < "u" && p.value && (W = new ResizeObserver((e) => {
				let t = e.find((e) => e.target === p.value)?.contentRect;
				if (t && (G && (G.width !== t.width || G.height !== t.height) && Z(), G = {
					width: t.width,
					height: t.height
				}), O.value && m.value) {
					let e = [...m.value.children].find((e) => !e.classList.contains("win-acrylic-visual"));
					D.value = (e && [...e.children].find((e) => !e.classList.contains("win-acrylic-visual")))?.scrollWidth || e?.scrollWidth || 0;
				}
			}), W.observe(p.value), m.value && W.observe(m.value));
		}), de(() => {
			I = !0, L += 1, $e(), Q(), W?.disconnect(), J?.removeEventListener("change", Y), window.removeEventListener("resize", ft), document.removeEventListener("pointerdown", dt, !0);
		});
		let mt = c(() => ({
			OpenPaneLength: A.value,
			NegativeOpenPaneLength: -A.value,
			OpenPaneLengthMinusCompactLength: A.value - j.value,
			NegativeOpenPaneLengthMinusCompactLength: j.value - A.value,
			OpenPaneGridLength: A.value,
			CompactPaneGridLength: j.value
		})), ht = {
			IsPaneOpen: y,
			DisplayMode: b,
			PanePlacement: Te,
			OpenPaneLength: x,
			CompactPaneLength: Ee,
			PaneBackground: De,
			Background: Oe,
			LightDismissOverlayMode: je,
			TemplateSettings: mt
		}, gt = pe(ht);
		be(ht);
		let _t = {
			splitViewProperty: ge,
			SplitViewPane: _e,
			SplitViewContent: ve,
			props: d,
			emit: Se,
			instance: f,
			attrs: Ce,
			slots: we,
			root: p,
			paneRoot: m,
			contentRoot: h,
			lightDismissLayer: g,
			resolve: _,
			dependency: v,
			IsPaneOpen: y,
			DisplayMode: b,
			PanePlacement: Te,
			OpenPaneLength: x,
			CompactPaneLength: Ee,
			PaneBackground: De,
			Background: Oe,
			backgroundStyle: ke,
			paneBackgroundStyle: Ae,
			LightDismissOverlayMode: je,
			isOpen: S,
			displayMode: C,
			panePlacement: w,
			compact: T,
			overlay: E,
			enabled: Me,
			measuredPaneLength: D,
			autoPaneLength: O,
			resourceNumber: k,
			openLength: A,
			compactLength: j,
			phase: M,
			paneVisible: Ne,
			reservation: N,
			visualState: Pe,
			closedTranslate: Fe,
			targetTransform: Ie,
			paneClip: Le,
			targetClip: Re,
			rootAttrs: ze,
			rootStyle: Be,
			cornerRadius: Ve,
			paneStyle: He,
			contentStyle: Ue,
			lightDismissVisible: We,
			lightDismissStyle: Ge,
			flatten: P,
			childrenOf: Ke,
			propertyName: qe,
			nodesFor: Je,
			outlet: Ye,
			PaneOutlet: Xe,
			ContentOutlet: Ze,
			get mounted() {
				return F;
			},
			set mounted(e) {
				F = e;
			},
			get disposed() {
				return I;
			},
			set disposed(e) {
				I = e;
			},
			get transitionToken() {
				return L;
			},
			set transitionToken(e) {
				L = e;
			},
			get activeAnimations() {
				return R;
			},
			set activeAnimations(e) {
				R = e;
			},
			get completionTimer() {
				return z;
			},
			set completionTimer(e) {
				z = e;
			},
			get previousFocus() {
				return B;
			},
			set previousFocus(e) {
				B = e;
			},
			get lightDismissPending() {
				return V;
			},
			set lightDismissPending(e) {
				V = e;
			},
			get closingEventRaised() {
				return H;
			},
			set closingEventRaised(e) {
				H = e;
			},
			get activeReservation() {
				return U;
			},
			set activeReservation(e) {
				U = e;
			},
			get resizeObserver() {
				return W;
			},
			set resizeObserver(e) {
				W = e;
			},
			get priorSize() {
				return G;
			},
			set priorSize(e) {
				G = e;
			},
			get outerDismissPointer() {
				return K;
			},
			set outerDismissPointer(e) {
				K = e;
			},
			get outerDismissClickTimer() {
				return q;
			},
			set outerDismissClickTimer(e) {
				q = e;
			},
			highContrast: Qe,
			get contrastQuery() {
				return J;
			},
			set contrastQuery(e) {
				J = e;
			},
			updateContrast: Y,
			raise: X,
			clearAnimations: $e,
			focusablePaneChildren: et,
			restoreFocus: tt,
			finishTransition: nt,
			animatePart: rt,
			beginTransition: it,
			requestLightDismiss: Z,
			blockDismissPointer: at,
			onLightDismissReleased: ot,
			clearOuterDismissGesture: Q,
			consumeOuterDismissEvent: $,
			onOuterDismissPressed: st,
			onOuterDismissReleased: ct,
			onOuterDismissCanceled: lt,
			onOuterDismissClick: ut,
			onOuterPointerPressed: dt,
			onRootChanged: ft,
			onKeyDown: pt,
			TemplateSettings: mt,
			publicApi: ht,
			sender: gt,
			Border: s,
			get vAcrylicBrush() {
				return o;
			},
			get boolValue() {
				return t;
			}
		};
		return Object.defineProperty(_t, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), _t;
	}
});
//#endregion
export { ve as SplitViewContent, _e as SplitViewPane, ye as default };

//# sourceMappingURL=SplitView.vue_vue_type_script_setup_true_lang.js.map