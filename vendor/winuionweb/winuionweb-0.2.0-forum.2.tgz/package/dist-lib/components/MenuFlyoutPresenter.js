import { cssLength as e, xamlThickness as t } from "./layout.js";
import { xamlThemeKey as n } from "./brushCore.js";
import { useAcrylicBrushStyle as r } from "./AcrylicBrush.js";
import { vAcrylicBackdrop as i, vAcrylicBrush as a } from "./acrylicBrushVisual.js";
import { vThemeShadow as o } from "./themeShadowVisual.js";
import { fitPopupPosition as ee, popupBoundsFor as te, popupPlacementPosition as ne, resolvePopupElement as re } from "./popupRuntime.js";
import { flyoutContainsNode as ie, hasOpenDescendantFlyout as ae, hideDescendantFlyouts as oe, isDescendantFlyoutOpening as se, nestedFlyoutLayers as ce, registerFlyoutInputRegion as le } from "./flyoutInput.js";
import ue from "./ScrollViewer.vue.js";
import { menuBarFlyoutEnabledKey as de, menuBarFlyoutNavigationKey as fe } from "./menuBarContext.js";
import { menuFlyoutPresenterContextKey as pe } from "./menuFlyoutContext.js";
import { Fragment as me, Teleport as he, computed as s, defineComponent as c, getCurrentInstance as ge, h as l, inject as u, nextTick as d, onBeforeUnmount as _e, onMounted as ve, provide as ye, ref as f, shallowReactive as be, shallowRef as xe, unref as Se, watch as Ce, withDirectives as we } from "vue";
//#region src/components/MenuFlyoutPresenter.ts
var Te = c({
	name: "MenuFlyoutPresenter",
	inheritAttrs: !1,
	props: {
		Owner: {
			type: Object,
			required: !0
		},
		IsSubmenu: {
			type: Boolean,
			default: !1
		}
	},
	setup(c, { slots: Te, expose: Ee }) {
		let De = ge(), p = u(pe, null), Oe = c.IsSubmenu ? (p?.Depth ?? 0) + 1 : 0, ke = u(fe, null), Ae = u(de, () => !0), je = u(n, null) ?? u("winuiTheme", ""), m = f(null), Me = f(null), h = f(null), g = document.createElement("div");
		g.className = "win-menu-flyout-content-host", g.style.display = "none";
		let _ = document.createElement("div");
		_.className = "win-menu-flyout-portal", _.appendChild(g);
		let v = xe(g), y = f(!1), b = f(!1), x = f(!1), S = f(!1), C = f(null), w = f({
			left: 0,
			top: 0,
			right: 0,
			bottom: 0,
			width: 0,
			height: 0
		}), T = f({
			left: 0,
			top: 0
		}), E = f(null), D = f("Bottom"), Ne = f(!0), O = f("ltr"), k = f(0), A = be(/* @__PURE__ */ new Set()), j = p?.RootItems ?? /* @__PURE__ */ new Set(), M = 0, N = [], Pe = null, Fe = {}, P, Ie = f(!1), F = null, I = null, L = !1, R = null, z = null, B = "keyboard", V = () => c.Owner, H = {
			get Owner() {
				return V().Api;
			},
			get IsOpen() {
				return y.value;
			},
			get Target() {
				return C.value;
			},
			get Presenter() {
				return m.value;
			},
			get DismissLayer() {
				return Me.value;
			},
			Hide: Q
		}, Le = le(H), U = (e) => e !== !1 && e !== "False", W = () => {
			let e = {
				...p?.Options() ?? {},
				...V().Options?.() ?? {}
			};
			return c.IsSubmenu && (delete e.Position, delete e.ExclusionRect, delete e.Placement), {
				...e,
				...Fe
			};
		}, Re = () => {
			let e = W().PresenterStyle ?? {};
			return Object.fromEntries(Object.entries({
				HorizontalScrollMode: "Disabled",
				HorizontalScrollBarVisibility: "Disabled",
				VerticalScrollMode: "Auto",
				VerticalScrollBarVisibility: "Auto",
				IsHorizontalRailEnabled: !0,
				IsVerticalRailEnabled: !0,
				ZoomMode: "Disabled"
			}).map(([t, n]) => [t, e[`ScrollViewer.${t}`] ?? n]));
		}, G = s(() => String(W().ShowMode ?? "Standard")), K = () => [...A].sort((e, t) => !e.Element.value || !t.Element.value ? 0 : e.Element.value.compareDocumentPosition(t.Element.value) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1), ze = () => K().filter((e) => e.IsEnabled.value && e.IsVisible.value), q = (e = !1) => {
			let t = ze(), n = e ? t.at(-1) : t[0];
			n ? n.Focus() : m.value?.focus({ preventScroll: !0 });
		}, Be = () => A.forEach((e) => e.ClearPointer()), J = () => {
			P !== void 0 && window.clearTimeout(P), P = void 0, Ie.value = !1, p?.CancelPendingClose();
		}, Ve = () => A.forEach((e) => e.CloseSubmenu()), Y = () => {
			N.forEach((e) => e.cancel()), N = [];
		}, X = s(() => {
			k.value;
			let e = C.value?.closest("[data-theme], .win-theme-scope, .example-theme-wrapper, .theme-light, .theme-dark"), t = e?.getAttribute("data-theme")?.toLowerCase();
			return t === "dark" || t === "light" ? t : e?.classList.contains("theme-dark") ? "dark" : e?.classList.contains("theme-light") ? "light" : String(Se(je)).toLowerCase();
		}), He = s(() => ["light", "dark"].includes(X.value) ? `win-theme-scope theme-${X.value}` : "");
		ye(n, X), ye("winuiTheme", X);
		let Ue = r(() => W().PresenterStyle?.Background ?? "{ThemeResource MenuFlyoutPresenterBackground}", De), We = r(() => W().PresenterStyle?.SystemBackdrop ?? "{StaticResource MenuFlyoutSystemBackdrop}", De), Ge = s(() => {
			let n = W().PresenterStyle ?? {}, r = {
				left: `${T.value.left}px`,
				top: `${T.value.top}px`,
				zIndex: E.value?.presenter,
				"--menu-flyout-available-width": `${Math.max(0, w.value.width - 8)}px`,
				"--menu-flyout-available-height": `${Math.max(0, w.value.height - 8)}px`,
				"--menu-flyout-padding": t(n.Padding ?? "0,2,0,2"),
				"--menu-flyout-max-content-height": `${Math.max(0, w.value.height - 14)}px`
			};
			for (let [e, t] of Object.entries({
				Foreground: "color",
				BorderBrush: "borderColor"
			})) n[e] !== void 0 && (r[t] = n[e]);
			for (let t of [
				"Width",
				"Height",
				"MinWidth",
				"MinHeight",
				"MaxWidth",
				"MaxHeight"
			]) n[t] !== void 0 && (r[t[0].toLowerCase() + t.slice(1)] = `min(${e(n[t])}, var(--menu-flyout-available-${t.includes("Width") ? "width" : "height"}))`);
			return n.CornerRadius !== void 0 && (r.borderRadius = e(n.CornerRadius)), n.BorderThickness !== void 0 && (r.borderWidth = t(n.BorderThickness)), String(W().Placement) === "Full" && (r.width = `${Math.max(0, w.value.width - 8)}px`, r.height = `${Math.max(0, w.value.height - 8)}px`), r;
		}), Z = async () => {
			let e = m.value;
			if (!e || !C.value || !y.value) return;
			if (!C.value.isConnected) {
				Q(!1);
				return;
			}
			w.value = te(C.value, U(W().ShouldConstrainToRootBounds)), await d();
			let t = {
				width: e.offsetWidth,
				height: e.offsetHeight
			}, n = C.value.getBoundingClientRect(), r = String(W().Placement ?? (c.IsSubmenu ? "Right" : "Bottom")), i;
			if (c.IsSubmenu) {
				let e = w.value, r = O.value === "rtl", a = r ? n.left - e.left : e.right - n.right, o = r ? e.right - n.right : n.left - e.left, te = t.width > a && t.width < o, ne = r !== te, re = t.width > a && !te ? r ? e.left : e.right - t.width : ne ? n.left - t.width + 4 : n.right - 4, ie = t.height > e.bottom - n.top;
				i = {
					...ee({
						left: re,
						top: ie ? n.bottom - e.top >= t.height ? n.bottom - t.height : e.top : n.top
					}, t, e),
					placement: `${ie ? "Top" : ""}${ne ? "Left" : "Right"}`
				};
			} else i = ne(n, t, r, w.value, 4, O.value === "rtl");
			let a = W().Position;
			T.value = a ? ee({
				left: n.left + Number(a.X ?? 0),
				top: n.top + Number(a.Y ?? 0)
			}, t, w.value) : {
				left: i.left,
				top: i.top
			}, D.value = i.placement;
			let o = W().ExclusionRect;
			if (a && o && r.startsWith("Bottom")) {
				let e = n.top + Number(o.Y ?? 0), r = e + Number(o.Height ?? n.height);
				T.value.top < r && T.value.top + t.height > e && (T.value = ee({
					left: T.value.left,
					top: e - t.height
				}, t, w.value), D.value = "Top");
			}
			x.value = !0;
		}, Ke = (e, t) => {
			let n = m.value;
			if (!n || !U(W().AreOpenCloseAnimationsEnabled) || matchMedia("(prefers-reduced-motion: reduce)").matches) return Promise.resolve();
			let r = D.value.startsWith("Top"), i = n.offsetHeight * .5 * (r ? 1 : -1), a = r ? "inset(0 0 50% 0)" : "inset(50% 0 0 0)", o = t ?? {
				opacity: "1",
				transform: "translateY(0)",
				clipPath: "inset(0)"
			};
			return N = [n.animate(e ? [{ opacity: 0 }, { opacity: 1 }] : [{ opacity: o.opacity }, { opacity: 0 }], {
				duration: 83,
				easing: "linear",
				fill: "both"
			}), n.animate(e ? [{
				transform: `translateY(${i}px)`,
				clipPath: a
			}, {
				transform: "translateY(0)",
				clipPath: "inset(0)"
			}] : [{
				transform: o.transform,
				clipPath: o.clipPath
			}, {
				transform: o.transform,
				clipPath: o.clipPath
			}], {
				duration: e ? 250 : 83,
				easing: e ? "cubic-bezier(0, 0, 0, 1)" : "linear",
				fill: "both"
			})], Promise.allSettled(N.map((e) => e.finished)).then(() => void 0);
		}, qe = () => {
			I?.disconnect();
			let e = C.value?.closest("[data-theme], .win-theme-scope, .example-theme-wrapper, .theme-light, .theme-dark");
			e && I?.observe(e, {
				attributes: !0,
				attributeFilter: ["class", "data-theme"]
			}), I?.observe(document.documentElement, {
				attributes: !0,
				attributeFilter: ["class", "data-theme"]
			}), k.value++;
		};
		async function Je(e, t = {}) {
			let n = re(e);
			if (!n || L) return;
			if (C.value = n, E.value = ce(H), Fe = t, O.value = getComputedStyle(n).direction, Ne.value = B !== "touch", qe(), y.value) {
				await Z();
				return;
			}
			let r = ++M;
			if (Y(), Pe = document.activeElement instanceof HTMLElement ? document.activeElement : n, z = R ? { ...R } : null, S.value = !0, _.parentElement?.appendChild(_), c.IsSubmenu || window.dispatchEvent(new CustomEvent("winui-flyout-opening", { detail: V().Api })), V().Raise?.("Opening"), y.value = !0, b.value = !0, x.value = !1, await d(), h.value && (v.value = h.value), await d(), await Z(), r !== M || !y.value || L) return;
			F?.disconnect(), m.value && F?.observe(m.value), F?.observe(n), G.value !== "Transient" && U(W().AllowFocusOnInteraction) && q();
			let i = Ke(!0);
			V().Raise?.("Opened"), await i, r === M && (Y(), S.value = !1);
		}
		function Q(e = !0) {
			if (!y.value) return;
			let t = { Cancel: !1 };
			if (V().Raise?.("Closing", t), t.Cancel) return;
			oe(H);
			let n = ++M;
			J(), Ve(), Be();
			let r = m.value ? getComputedStyle(m.value) : null, i = r ? {
				opacity: r.opacity,
				transform: r.transform,
				clipPath: r.clipPath
			} : void 0;
			Y(), y.value = !1, S.value = !1, F?.disconnect();
			let a = ((e) => e?.isConnected && e.getClientRects().length > 0 && !e.closest(".is-closing, [inert], [hidden]"))(Pe) ? Pe : C.value, o = m.value?.contains(document.activeElement) || !c.IsSubmenu && [...j].some((e) => e.Element.value?.contains(document.activeElement));
			e && o && a?.isConnected && a.focus({ preventScroll: !0 }), Ke(!1, i).then(async () => {
				n !== M || y.value || L || (Y(), v.value = g, await d(), b.value = !1, x.value = !1, V().Raise?.("Closed"));
			});
		}
		let $ = {
			Depth: Oe,
			IsOpen: y,
			IsOpening: S,
			IsSubmenu: c.IsSubmenu,
			NarrowPadding: Ne,
			FlowDirection: O,
			ContainsCheckItems: s(() => [...A].some((e) => e.IsVisible.value && e.IsCheckItem)),
			ContainsIconItems: s(() => [...A].some((e) => e.IsVisible.value && e.HasIcon.value)),
			AcceleratorMinWidth: s(() => Math.max(0, ...[...A].map((e) => e.AcceleratorText.value.length * 6.5))),
			Register(e) {
				A.add(e), j.add(e);
			},
			Unregister(e) {
				A.delete(e), j.delete(e);
			},
			Items: K,
			RootItems: j,
			Dismiss() {
				p ? p.Dismiss() : V().Hide?.();
			},
			Close: Q,
			CloseSiblings(e) {
				A.forEach((t) => {
					t !== e && t.CloseSubmenu();
				});
			},
			FocusRelative(e, t) {
				let n = K(), r = n.indexOf(e);
				for (let e = 1; e <= n.length; e++) {
					let i = n[(r + t * e + n.length * 2) % n.length];
					if (i?.IsEnabled.value && i.IsVisible.value) {
						i.Focus();
						return;
					}
				}
				m.value?.focus({ preventScroll: !0 });
			},
			FocusBoundary: q,
			CanHover(e) {
				return !(!y.value || e.pointerType === "touch" || z && e.clientX === z.x && e.clientY === z.y && (e.type !== "pointermove" || e.movementX === 0 && e.movementY === 0) || (z &&= null, S.value && !z && e.movementX === 0 && e.movementY === 0));
			},
			CancelPendingClose: J,
			DelayClose() {
				P !== void 0 || !y.value || (J(), Ie.value = !0, P = window.setTimeout(() => Q(!1), 400));
			},
			Options: W
		};
		ye(pe, $);
		let Ye = (e) => {
			R = {
				x: e.clientX,
				y: e.clientY
			}, S.value || $.CancelPendingClose();
		}, Xe = (e) => {
			B = e.pointerType || "mouse", R = {
				x: e.clientX,
				y: e.clientY
			};
		}, Ze = (e) => {
			R = {
				x: e.clientX,
				y: e.clientY
			};
		}, Qe = (e) => {
			B = "keyboard", !c.IsSubmenu && y.value && !ae(H) && e.key === "Escape" && !m.value?.contains(document.activeElement) && ![...document.querySelectorAll(".win-menu-submenu-presenter")].some((e) => e.contains(document.activeElement)) && (e.preventDefault(), Q());
		}, $e = (e) => {
			if (c.IsSubmenu || !y.value || G.value !== "TransientWithDismissOnPointerMove" || !$.CanHover(e) || [...document.querySelectorAll(".win-menu-flyout-presenter:not(.is-closing)")].some((t) => t.contains(e.target))) return;
			let t = C.value?.getBoundingClientRect(), n = m.value?.getBoundingClientRect();
			!t || !n || (e.clientX < Math.min(t.left, n.left) - 12 || e.clientX > Math.max(t.right, n.right) + 12 || e.clientY < Math.min(t.top, n.top) - 12 || e.clientY > Math.max(t.bottom, n.bottom) + 12) && Q(!1);
		}, et = () => {
			y.value && Z();
		}, tt = (e) => {
			if (B = "keyboard", !y.value || !m.value?.contains(document.activeElement) && c.IsSubmenu) return;
			let t = O.value === "rtl" ? "ArrowLeft" : "ArrowRight", n = O.value === "rtl" ? "ArrowRight" : "ArrowLeft", r = K().find((e) => e.Element.value?.contains(document.activeElement));
			e.key === "ArrowDown" || e.key === "ArrowUp" ? (e.preventDefault(), r ? $.FocusRelative(r, e.key === "ArrowDown" ? 1 : -1) : q(e.key === "ArrowUp")) : e.key === "Home" || e.key === "End" ? (e.preventDefault(), q(e.key === "End")) : e.key === t && r?.HasSubmenu ? (e.preventDefault(), r.OpenSubmenu(!0)) : e.key === n && c.IsSubmenu ? (e.preventDefault(), Q()) : !c.IsSubmenu && !r?.HasSubmenu && (e.key === t || e.key === n) ? ke?.(e) : e.key === "Escape" ? (e.preventDefault(), c.IsSubmenu ? Q() : V().Hide?.()) : e.key === "Tab" && e.preventDefault(), e.defaultPrevented && e.stopPropagation();
		}, nt = (e) => {
			if (c.IsSubmenu || e.defaultPrevented || !Ae()) return;
			let t = [...j].find((t) => t.IsEnabled.value && t.IsVisible.value && t.MatchesAccelerator(e));
			t && (e.preventDefault(), e.stopPropagation(), t.Invoke(e));
		}, rt = (e) => {
			let t = e.detail;
			!c.IsSubmenu && t !== V().Api && !se(t, H) && Q();
		}, it = () => Q(!1), at = (e) => {
			if (!y.value || c.IsSubmenu) return;
			let t = e.target;
			if (!(ie(H, t) || [...j].some((e) => e.Element.value?.contains(t))) && ![...document.querySelectorAll(".win-menu-submenu-presenter")].some((e) => e.contains(t))) {
				if (re(W().OverlayInputPassThroughElement)?.contains(t)) {
					Q(!1);
					return;
				}
				(G.value === "Standard" || G.value === "Auto") && Q(!1);
			}
		};
		return ve(() => {
			document.body.appendChild(_), F = new ResizeObserver(() => {
				y.value && Z();
			}), I = new MutationObserver(() => k.value++), document.addEventListener("pointerdown", Xe, !0), document.addEventListener("pointermove", Ze, !0), document.addEventListener("pointermove", $e), document.addEventListener("keydown", Qe, !0), document.addEventListener("scroll", et, !0), document.addEventListener("pointerdown", at), document.addEventListener("keydown", nt), window.addEventListener("winui-flyout-opening", rt), window.addEventListener("blur", it), window.addEventListener("resize", Z);
		}), _e(() => {
			oe(H), Le(), L = !0, M++, J(), Y(), F?.disconnect(), I?.disconnect(), document.removeEventListener("pointerdown", Xe, !0), document.removeEventListener("pointermove", Ze, !0), document.removeEventListener("pointermove", $e), document.removeEventListener("keydown", Qe, !0), document.removeEventListener("scroll", et, !0), document.removeEventListener("pointerdown", at), document.removeEventListener("keydown", nt), window.removeEventListener("winui-flyout-opening", rt), window.removeEventListener("blur", it), window.removeEventListener("resize", Z), _.remove();
		}), Ce(() => V().Options?.(), () => {
			y.value && Z();
		}, { deep: !0 }), Ee({
			ShowAt: Je,
			Hide: Q,
			DelayClose: $.DelayClose,
			CancelPendingClose: J,
			IsDelayCloseTimerRunning: Ie,
			IsOpen: y,
			Target: C,
			Items: s(() => K().map((e) => e.Api)),
			Element: m
		}), () => l(me, [l(he, { to: _ }, [y.value && !c.IsSubmenu && ["Standard", "Auto"].includes(G.value) ? l("div", {
			ref: Me,
			class: ["win-menu-flyout-dismiss-layer", { "is-visible": W().LightDismissOverlayMode === "On" }],
			style: {
				left: `${w.value.left}px`,
				top: `${w.value.top}px`,
				width: `${w.value.width}px`,
				height: `${w.value.height}px`,
				zIndex: E.value?.overlay,
				pointerEvents: W().OverlayInputPassThroughElement ? "none" : void 0
			},
			onPointerdown: (e) => {
				e.preventDefault(), Q();
			}
		}) : null, b.value ? we(l("div", {
			ref: m,
			class: [
				"win-menu-flyout-presenter",
				He.value,
				{
					"win-menu-submenu-presenter": c.IsSubmenu,
					"is-positioning": !x.value,
					"is-opening": S.value,
					"is-closing": !y.value
				}
			],
			style: Ge.value,
			dir: O.value,
			role: "menu",
			tabindex: -1,
			onKeydown: tt,
			onPointermove: Ye,
			onPointerenter: J,
			onPointerleave: () => {
				c.IsSubmenu && $.DelayClose();
			},
			onPointercancel: Be,
			onLostpointercapture: Be
		}, [
			we(l("div", {
				class: "win-menu-flyout-material-layer",
				"data-menu-material": "SystemBackdrop",
				style: We.value,
				"aria-hidden": !0
			}), [[
				a,
				We.value,
				void 0,
				{ "no-backdrop": !0 }
			]]),
			we(l("div", {
				class: "win-menu-flyout-material-layer",
				"data-menu-material": "Background",
				style: Ue.value,
				"aria-hidden": !0
			}), [[
				a,
				Ue.value,
				void 0,
				{ "no-backdrop": !0 }
			]]),
			l(ue, {
				class: "win-menu-flyout-scroll",
				...Re(),
				IsTabStop: "False"
			}, { default: () => l("div", {
				ref: h,
				class: "win-menu-flyout-items-presenter"
			}) })
		]), [[i, [We.value, Ue.value]], [o, {
			Translation: 32 + 8 * Oe,
			Theme: X.value,
			Enabled: U(W().PresenterStyle?.IsDefaultShadowEnabled)
		}]]) : null]), l(he, { to: v.value }, Te.default?.() ?? [])]);
	}
});
//#endregion
export { Te as default };

//# sourceMappingURL=MenuFlyoutPresenter.js.map