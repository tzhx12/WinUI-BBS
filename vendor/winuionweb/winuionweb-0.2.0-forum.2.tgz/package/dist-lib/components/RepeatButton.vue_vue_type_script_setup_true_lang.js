import { boolValue as e } from "./layout.js";
import { resolveXamlHandler as t, resolveXamlValue as n, updateXamlBinding as r, xamlScopeKey as i } from "./xamlRuntime.js";
import { useUICommand as ee } from "./uiCommandRuntime.js";
import { buttonContentProperty as a, useButtonContent as te } from "./buttonContentRuntime.js";
import ne from "./Button.vue.js";
import { computed as o, defineComponent as s, getCurrentInstance as re, inject as ie, onBeforeUnmount as ae, onMounted as oe, provide as se, proxyRefs as ce, ref as c, useAttrs as le, useSlots as ue, watch as l } from "vue";
//#region src/components/RepeatButton.vue?vue&type=script&setup=true&lang.ts
var u = s({
	name: "RepeatButton.Content",
	__buttonProperty: "content",
	setup() {
		return () => null;
	}
}), d = /*@__PURE__*/ s({
	Content: u,
	ContentTemplate: a("RepeatButton", "ContentTemplate"),
	ContentTransitions: a("RepeatButton", "ContentTransitions"),
	Resources: a("RepeatButton", "Resources"),
	name: "RepeatButton",
	inheritAttrs: !1,
	__name: "RepeatButton",
	props: {
		Content: {
			type: null,
			default: ""
		},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		ContentTemplate: {
			type: null,
			default: void 0
		},
		ContentTransitions: {
			type: null,
			default: void 0
		},
		RequestedTheme: {
			type: String,
			default: "Default"
		},
		Delay: {
			type: [Number, String],
			default: 500
		},
		Interval: {
			type: [Number, String],
			default: 33
		},
		ClickMode: {
			type: String,
			default: "Press"
		}
	},
	emits: ["Click"],
	setup(a, { expose: s, emit: d }) {
		let f = a, p = d, m = le(), h = ue(), g = re(), _ = c(null), v = (e) => n(e, g), { ContentTemplate: y, ContentTransitions: b } = te(f, () => h.default?.() ?? [], g), x = ee(() => v(m.Command)), S = o(() => v(m.CommandParameter)), C = o(() => v(f.Content)), w = o(() => String(v(f.RequestedTheme))), T = c();
		l(w, () => {
			T.value = void 0;
		});
		let E = o({
			get: () => T.value ?? w.value,
			set: (e) => {
				T.value = e, r(f.RequestedTheme, e, g);
			}
		}), D = o(() => e(v(f.IsEnabled))), O = c(), k = o({
			get: () => (O.value ?? D.value) && (x.value?.CanExecute?.(S.value) ?? !0),
			set: (t) => {
				O.value = e(t), r(f.IsEnabled, O.value, g);
			}
		});
		l(D, () => {
			O.value = void 0;
		});
		let A = o(() => Number(v(f.Delay))), j = o(() => Number(v(f.Interval))), M = c(), N = c(), P = o({
			get: () => M.value ?? A.value,
			set: (e) => {
				if (!Number.isFinite(e) || e < 0) throw RangeError("RepeatButton.Delay must be non-negative");
				M.value = e, r(f.Delay, e, g);
			}
		}), F = o({
			get: () => N.value ?? j.value,
			set: (e) => {
				if (!Number.isFinite(e) || e <= 0) throw RangeError("RepeatButton.Interval must be positive");
				N.value = e, r(f.Interval, e, g);
			}
		});
		l(A, () => {
			M.value = void 0;
		}), l(j, () => {
			N.value = void 0;
		});
		let I = o(() => String(v(f.ClickMode))), de = o(() => Object.fromEntries(Object.entries(m).filter(([e]) => ![
			"Click",
			"onClick",
			"ClickMode",
			"PointerPressed",
			"PointerReleased",
			"PointerCanceled",
			"PointerCaptureLost",
			"PointerEntered",
			"PointerExited"
		].includes(e)))), fe = o(() => !!h.default), L = ce({
			Content: o({
				get: () => _.value?.Content ?? C.value,
				set: (e) => {
					_.value && (_.value.Content = e), r(f.Content, e, g);
				}
			}),
			ContentTemplate: y,
			ContentTransitions: b,
			IsEnabled: k,
			Delay: P,
			Interval: F,
			RequestedTheme: E,
			Command: x,
			CommandParameter: S,
			Name: o(() => m["data-xaml-ref"] ?? m["x:Name"] ?? m.Name ?? ""),
			Element: o(() => _.value?.Element),
			IsPressed: o(() => _.value?.IsPressed ?? !1),
			Focus: () => _.value?.Focus?.()
		});
		s(L);
		let R = null, z = null, B = "", V = !1, H;
		function U(e, n) {
			if (!k.value) return;
			n?.OriginalEvent && (H = n.OriginalEvent);
			let r = {
				OriginalSource: L,
				OriginalEvent: H,
				Handled: !1
			};
			p("Click", L, r), t(m.Click, g)?.(L, r), !n && (x.value?.CanExecute?.(S.value) ?? !0) && x.value?.Execute(S.value);
		}
		function W() {
			R !== null && clearTimeout(R), R = null;
		}
		function G() {
			W(), z = null, B = "", V = !1, H = void 0;
		}
		function K() {
			R = null, !(!k.value || I.value !== "Hover" && !_.value?.IsPressed || !B && (!V || z === null && I.value !== "Hover")) && (U(), k.value && (B || V && (z !== null || I.value === "Hover")) && (R = setTimeout(K, F.value)));
		}
		function q() {
			W(), R = setTimeout(K, P.value);
		}
		function J(e, t) {
			let n = t.OriginalEvent;
			!k.value || I.value === "Hover" || n.button !== 0 || z !== null || (z = n.pointerId, V = !0, H = n, q());
		}
		function Y() {
			I.value !== "Hover" && G();
		}
		function pe() {
			G();
		}
		function me() {
			V = !1, W();
		}
		function he(e, t) {
			if (t.OriginalEvent?.pointerType === "touch") {
				V = !1, W();
				return;
			}
			V = !0, (z !== null || I.value === "Hover") && q();
		}
		function ge(e) {
			if (z === null || I.value === "Hover") return;
			let t = e.IsPressed;
			t !== V && (V = t, t ? q() : W());
		}
		function X(e) {
			!k.value || I.value === "Hover" || e.repeat || B || e.key !== " " || (B = e.key, H = e, q());
		}
		function Z(e) {
			e.key === B && G();
		}
		let Q = null;
		oe(() => {
			Q = _.value?.Element ?? null, Q?.addEventListener("keydown", X), Q?.addEventListener("keyup", Z), Q?.addEventListener("blur", G), window.addEventListener("blur", G);
		}), ae(() => {
			G(), Q?.removeEventListener("keydown", X), Q?.removeEventListener("keyup", Z), Q?.removeEventListener("blur", G), window.removeEventListener("blur", G);
		}), l(k, (e) => {
			e || G();
		}), se(i, {
			...ie(i, {}),
			Content: C,
			ContentTemplate: y,
			ContentTransitions: b,
			IsEnabled: k,
			ClickMode: I,
			RequestedTheme: E,
			OnRepeatClick: U,
			OnPointerPressed: J,
			OnPointerReleased: Y,
			OnPointerCanceled: pe,
			OnPointerExited: me,
			OnPointerEntered: he,
			OnPointerMoved: ge
		});
		let $ = {
			RepeatButtonContent: u,
			props: f,
			emit: p,
			attrs: m,
			slots: h,
			instance: g,
			button: _,
			resolve: v,
			ContentTemplate: y,
			ContentTransitions: b,
			Command: x,
			CommandParameter: S,
			Content: C,
			sourceRequestedTheme: w,
			localRequestedTheme: T,
			RequestedTheme: E,
			sourceIsEnabled: D,
			localIsEnabled: O,
			IsEnabled: k,
			sourceDelay: A,
			sourceInterval: j,
			localDelay: M,
			localInterval: N,
			Delay: P,
			Interval: F,
			ClickMode: I,
			buttonAttrs: de,
			hasContent: fe,
			api: L,
			get timer() {
				return R;
			},
			set timer(e) {
				R = e;
			},
			get activePointer() {
				return z;
			},
			set activePointer(e) {
				z = e;
			},
			get activeKey() {
				return B;
			},
			set activeKey(e) {
				B = e;
			},
			get pointerInside() {
				return V;
			},
			set pointerInside(e) {
				V = e;
			},
			get lastEvent() {
				return H;
			},
			set lastEvent(e) {
				H = e;
			},
			raiseClick: U,
			stopTimer: W,
			stop: G,
			tick: K,
			schedule: q,
			onPointerPressed: J,
			onPointerReleased: Y,
			onPointerCanceled: pe,
			onPointerExited: me,
			onPointerEntered: he,
			onPointerMoved: ge,
			keyDown: X,
			keyUp: Z,
			get element() {
				return Q;
			},
			set element(e) {
				Q = e;
			},
			Button: ne
		};
		return Object.defineProperty($, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), $;
	}
});
//#endregion
export { u as RepeatButtonContent, d as default };

//# sourceMappingURL=RepeatButton.vue_vue_type_script_setup_true_lang.js.map