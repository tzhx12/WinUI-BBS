import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./ScrollView.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                               */
import { createBlock as n, createVNode as r, mergeProps as i, openBlock as a, renderSlot as o, withCtx as s } from "vue";
//#region src/components/ScrollView.vue
function c(e, t, c, l, u, d) {
	return a(), n(l.Grid, i({ "x:Name": "PART_Root" }, l.rootAttrs, {
		class: "win-scroll-view",
		Width: "{x:Bind properties.Width, Mode=OneWay}",
		Height: "{x:Bind properties.Height, Mode=OneWay}",
		MinWidth: "{x:Bind properties.MinWidth, Mode=OneWay}",
		MinHeight: "{x:Bind properties.MinHeight, Mode=OneWay}",
		MaxWidth: "{x:Bind properties.MaxWidth, Mode=OneWay}",
		MaxHeight: "{x:Bind properties.MaxHeight, Mode=OneWay}",
		Margin: "{x:Bind properties.Margin, Mode=OneWay}",
		HorizontalAlignment: "{x:Bind properties.HorizontalAlignment, Mode=OneWay}",
		VerticalAlignment: "{x:Bind properties.VerticalAlignment, Mode=OneWay}",
		BorderBrush: "{x:Bind properties.BorderBrush, Mode=OneWay}",
		BorderThickness: "{x:Bind properties.BorderThickness, Mode=OneWay}",
		CornerRadius: "{x:Bind properties.CornerRadius, Mode=OneWay}"
	}), {
		default: s(() => [
			r(l.Grid.RowDefinitions, null, {
				default: s(() => [r(l.RowDefinition, { Height: "*" }), r(l.RowDefinition, { Height: "Auto" })]),
				_: 1
			}),
			r(l.Grid.ColumnDefinitions, null, {
				default: s(() => [r(l.ColumnDefinition, { Width: "*" }), r(l.ColumnDefinition, { Width: "Auto" })]),
				_: 1
			}),
			r(l.ScrollPresenter, {
				"x:Name": "PART_ScrollPresenter",
				"Grid.ColumnSpan": "2",
				"Grid.RowSpan": "2"
			}, {
				default: s(() => [o(e.$slots, "default", {}, void 0, !0)]),
				_: 3
			}),
			r(l.Grid, {
				"Grid.Row": "1",
				class: "horizontal-scrollbar-host",
				Visibility: "{x:Bind horizontalVisibility, Mode=OneWay}",
				Padding: "{ThemeResource ScrollViewScrollBarsMargin}"
			}, {
				default: s(() => [r(l.ScrollBar, {
					"x:Name": "PART_HorizontalScrollBar",
					Orientation: "Horizontal",
					SmallChange: "16",
					LargeChange: "{x:Bind ScrollBars.Horizontal.ViewportSize, Mode=OneWay}",
					Minimum: "0",
					Maximum: "{x:Bind ScrollBars.Horizontal.Maximum, Mode=OneWay}",
					ViewportSize: "{x:Bind ScrollBars.Horizontal.ViewportSize, Mode=OneWay}",
					Value: "{x:Bind ScrollBars.Horizontal.Value, Mode=OneWay}",
					IndicatorMode: "{x:Bind ScrollBars.IndicatorMode, Mode=OneWay}",
					IsEnabled: "{x:Bind enabled, Mode=OneWay}",
					Scroll: "HorizontalScrollBar_Scroll"
				})]),
				_: 1
			}),
			r(l.Grid, {
				"Grid.Column": "1",
				class: "vertical-scrollbar-host",
				Visibility: "{x:Bind verticalVisibility, Mode=OneWay}",
				Padding: "{ThemeResource ScrollViewScrollBarsMargin}"
			}, {
				default: s(() => [r(l.ScrollBar, {
					"x:Name": "PART_VerticalScrollBar",
					Orientation: "Vertical",
					SmallChange: "16",
					LargeChange: "{x:Bind ScrollBars.Vertical.ViewportSize, Mode=OneWay}",
					Minimum: "0",
					Maximum: "{x:Bind ScrollBars.Vertical.Maximum, Mode=OneWay}",
					ViewportSize: "{x:Bind ScrollBars.Vertical.ViewportSize, Mode=OneWay}",
					Value: "{x:Bind ScrollBars.Vertical.Value, Mode=OneWay}",
					IndicatorMode: "{x:Bind ScrollBars.IndicatorMode, Mode=OneWay}",
					IsEnabled: "{x:Bind enabled, Mode=OneWay}",
					Scroll: "VerticalScrollBar_Scroll"
				})]),
				_: 1
			}),
			r(l.ScrollBarsSeparator, {
				"x:Name": "PART_ScrollBarsSeparator",
				"Grid.Row": "1",
				"Grid.Column": "1"
			})
		]),
		_: 3
	}, 16);
}
var l = /*#__PURE__*/ e(t, [
	["render", c],
	["__scopeId", "data-v-1e160bc0"],
	["__file", "ScrollView.vue"]
]);
//#endregion
export { l as default };

//# sourceMappingURL=ScrollView.vue.js.map