import { alignment as e, applyGridChildren as t, attachedValue as n, cssLength as r, gridDefinitionContextKey as i, useLayoutObserver as a, xamlThickness as o } from "./layout.js";
import { primitiveResourceScope as s, xamlPrimitiveResourceKey as c } from "./xamlPrimitives.js";
import { normalizeXamlNodes as l, resolveXamlValue as u, updateXamlBinding as d, xamlItemContextKey as ee } from "./xamlRuntime.js";
import { constrainedStarSizes as te, gridTrackCss as f, parseGridTracks as p } from "./gridTracks.js";
import { layoutResourceChildren as ne } from "./layoutResources.js";
import { collectXamlResources as re, useXamlBrushResources as ie } from "./xamlBrushResources.js";
import { brushProperty as m, isBrushProperty as ae, useBrushProperty as h } from "./brushProperties.js";
import { vAcrylicBrush as oe } from "./acrylicBrushVisual.js";
import { vRadialGradientBrush as se } from "./RadialGradientVisual.js";
import { vThemeShadow as ce } from "./themeShadowVisual.js";
import g from "./GridColumnDefinitions.vue.js";
import _ from "./GridRowDefinitions.vue.js";
import { GridResources as v } from "./gridResources.js";
import { Fragment as y, cloneVNode as b, computed as x, defineComponent as S, getCurrentInstance as le, h as C, inject as w, onBeforeUnmount as ue, provide as T, ref as E, shallowRef as D, useSlots as de, watch as fe } from "vue";
//#region src/components/Grid.vue?vue&type=script&setup=true&lang.ts
var O = S({
	name: "Grid.ContextFlyout",
	__contextFlyoutProperty: !0,
	setup(e, { slots: t }) {
		return () => C(y, t.default?.());
	}
}), k = /*@__PURE__*/ S({
	ColumnDefinitions: g,
	RowDefinitions: _,
	Resources: v,
	Background: m("Grid", "Background"),
	Shadow: m("Grid", "Shadow"),
	ContextFlyout: O,
	__name: "Grid",
	props: {
		Width: {
			type: [String, Number],
			default: ""
		},
		Height: {
			type: [String, Number],
			default: ""
		},
		MinWidth: {
			type: [String, Number],
			default: ""
		},
		MinHeight: {
			type: [String, Number],
			default: ""
		},
		MaxWidth: {
			type: [String, Number],
			default: ""
		},
		MaxHeight: {
			type: [String, Number],
			default: ""
		},
		Background: {
			type: [String, Object],
			default: ""
		},
		BackgroundSizing: {
			type: String,
			default: ""
		},
		BorderBrush: {
			type: String,
			default: ""
		},
		BorderThickness: {
			type: [String, Number],
			default: 0
		},
		CornerRadius: {
			type: [String, Number],
			default: ""
		},
		Padding: {
			type: [String, Number],
			default: ""
		},
		Margin: {
			type: [String, Number],
			default: ""
		},
		ColumnDefinitions: {
			type: [
				String,
				Array,
				Object
			],
			default: ""
		},
		RowDefinitions: {
			type: [
				String,
				Array,
				Object
			],
			default: ""
		},
		ColumnSpacing: {
			type: [String, Number],
			default: 0
		},
		RowSpacing: {
			type: [String, Number],
			default: 0
		},
		HorizontalAlignment: {
			type: String,
			default: ""
		},
		VerticalAlignment: {
			type: String,
			default: ""
		},
		Visibility: {
			type: String,
			default: "Visible"
		},
		Shadow: {
			type: [String, Object],
			default: null
		},
		Translation: {
			type: [String, Object],
			default: () => ({
				X: 0,
				Y: 0,
				Z: 0
			})
		}
	},
	emits: ["update:Shadow", "update:Translation"],
	setup(m, { expose: g, emit: _ }) {
		let v = m, k = E(null), A = _, j = de(), M = le(), N = ie(M), P = () => {
			let e = {}, t = (n) => {
				for (let r of n) r.type === y && Array.isArray(r.children) ? t(r.children) : r.type?.__gridResourcesProperty && re(Array.isArray(r.children) ? r.children : r.children?.default?.() ?? [], e);
			};
			t(j.default?.() ?? []), N.sync(e);
		}, F = h("Background", () => v.Background, () => j.default?.() ?? [], M), I = h("Shadow", () => v.Shadow, () => j.default?.() ?? [], M), L = D(), R = x({
			get: () => L.value === void 0 ? I.value.value : L.value,
			set: (e) => {
				L.value = e, d(v.Shadow, e, M), A("update:Shadow", e);
			}
		});
		fe(() => u(v.Shadow, M), () => {
			L.value = void 0;
		});
		let z = D(u(v.Translation, M)), B = x({
			get: () => z.value,
			set: (e) => {
				z.value = e, d(v.Translation, e, M), A("update:Translation", e);
			}
		});
		fe(() => u(v.Translation, M), (e) => {
			z.value = e;
		}, { deep: !0 }), g({
			Element: k,
			Shadow: R,
			Translation: B
		});
		let V = s(() => j.default?.() ?? [], w(c, null));
		T(c, V);
		let H = w(ee, void 0), pe = () => H && typeof H == "object" ? {
			Item: H,
			DataContext: H,
			...H
		} : {
			Item: H,
			DataContext: H
		}, U = (e) => u(e, M, pe()), W = [
			"Grid.Row",
			"Grid.Column",
			"Grid.RowSpan",
			"Grid.ColumnSpan",
			"Canvas.ZIndex",
			"HorizontalAlignment",
			"VerticalAlignment"
		], G = (e) => {
			if (e.type === y && Array.isArray(e.children)) {
				let t = b(e);
				return t.children = e.children.map(G), t;
			}
			let t = { ...e.props ?? {} };
			delete t.ref;
			for (let e of W) e in t && (t[e] = U(t[e]));
			let n = b(e, t);
			return n.ref = e.ref, n;
		}, me = S({
			name: "GridChildrenOutlet",
			setup() {
				return () => C(y, ne(l(j.default?.() ?? [], M), "__gridResourcesProperty").filter((e) => !e.type?.__contextFlyoutProperty && !ae(e)).map(G));
			}
		}), K = E(null), q = x(() => {
			let e = [], t = (n) => {
				for (let r of n) if (r.type === y && Array.isArray(r.children)) t(r.children);
				else if (r.type?.__contextFlyoutProperty) {
					let t = Array.isArray(r.children) ? r.children : r.children?.default?.() ?? [];
					e.push(...t);
				}
			};
			return t(j.default?.() ?? []), e;
		}), he = S({ setup: () => () => C(y, l(q.value, M).map((e) => b(e, { ref: (e) => {
			K.value = e;
		} }, !0))) }), ge = (e) => {
			if (!q.value.length || !k.value) return;
			e.preventDefault(), e.stopPropagation();
			let t = k.value.getBoundingClientRect();
			K.value?.ShowAt?.(k.value, { Position: {
				X: e.clientX - t.left,
				Y: e.clientY - t.top
			} });
		}, J = () => {
			K.value?.Hide?.();
		}, Y = E([]), X = E([]), _e = (e, t) => {
			let n = e === "columns" ? Y : X;
			return n.value = [...n.value, t], () => {
				n.value = n.value.filter((e) => e !== t);
			};
		};
		T(i, { registerDefinition: _e });
		let Z = x(() => p(Y.value.length ? Y.value : U(v.ColumnDefinitions), "Width")), Q = x(() => p(X.value.length ? X.value : U(v.RowDefinitions), "Height")), $ = (e) => Math.max(0, Number(U(e)) || 0), ve = x(() => {
			let t = {}, n = U(v.Width);
			n !== "" && n !== void 0 && n !== "Auto" && (t.flex = "0 0 auto");
			for (let [e, n] of Object.entries({
				Width: v.Width,
				Height: v.Height,
				MinWidth: v.MinWidth,
				MinHeight: v.MinHeight,
				MaxWidth: v.MaxWidth,
				MaxHeight: v.MaxHeight
			})) {
				let i = U(n);
				i !== "" && i != null && (t[e.charAt(0).toLowerCase() + e.slice(1)] = r(i));
			}
			U(v.Background);
			let i = U(v.BorderBrush), a = U(v.BorderThickness), s = U(v.CornerRadius);
			Object.assign(t, F.style.value), t.backgroundClip = U(v.BackgroundSizing) === "OuterBorderEdge" ? "border-box" : "padding-box", i && (t.borderColor = String(i)), a !== "" && a !== void 0 && (t.borderWidth = o(a)), (i || a !== "") && (t.borderStyle = "solid"), s !== "" && s !== void 0 && (t.borderRadius = String(s).split(",").map((e) => r(e.trim())).join(" ")), t.padding = o(U(v.Padding)), t.margin = o(U(v.Margin)), t.gridTemplateColumns = Z.value.map(f).join(" "), t.gridTemplateRows = Q.value.map(f).join(" "), t.columnGap = r($(v.ColumnSpacing)), t.rowGap = r($(v.RowSpacing)), t.justifySelf = e(U(v.HorizontalAlignment), "horizontal"), t.alignSelf = e(U(v.VerticalAlignment), "vertical");
			let c = B.value, l = typeof c == "object" ? c : void 0, [u, d] = typeof c == "string" ? c.split(",").map(Number) : [Number(l?.X), Number(l?.Y)];
			return (u || d) && (t.transform = `translate(${u || 0}px, ${d || 0}px)`), U(v.Visibility) === "Collapsed" ? t.display = "none" : U(v.Visibility) === "Hidden" && (t.visibility = "hidden"), t;
		}), ye = () => (P(), ve.value), be = () => {
			let e = k.value;
			if (!e) return;
			t(e);
			let r = (e, t, r) => Math.min(r - 1, Math.max(0, Math.floor(Number(n(e, t)) || 0))), i = (e, t, r) => Math.min(r, Math.max(1, Math.floor(Number(n(e, t)) || 1)));
			for (let t of Array.from(e.children)) {
				if (t.classList.contains("win-acrylic-visual") || t.classList.contains("win-radial-gradient-background") || t.classList.contains("win-theme-shadow-visual")) continue;
				let e = r(t, "Grid.Row", Q.value.length), n = r(t, "Grid.Column", Z.value.length);
				t.style.gridRow = `${e + 1} / span ${i(t, "Grid.RowSpan", Q.value.length - e)}`, t.style.gridColumn = `${n + 1} / span ${i(t, "Grid.ColumnSpan", Z.value.length - n)}`;
			}
			let a = getComputedStyle(e);
			for (let t of ["columns", "rows"]) {
				let n = t === "columns" ? Z.value : Q.value;
				if (!n.some((e) => e.unit !== "pixel" && Number.isFinite(e.max))) continue;
				let r = t === "columns", i = r ? "gridTemplateColumns" : "gridTemplateRows";
				e.style[i] = n.map(f).join(" ");
				let o = getComputedStyle(e)[i].split(" ").map((e) => Number.parseFloat(e)), s = r ? Number.parseFloat(a.paddingLeft) + Number.parseFloat(a.paddingRight) : Number.parseFloat(a.paddingTop) + Number.parseFloat(a.paddingBottom), c = (r ? e.clientWidth : e.clientHeight) - s - (n.length - 1) * $(r ? v.ColumnSpacing : v.RowSpacing);
				e.style[i] = te(n, c, o).map((e) => `${e}px`).join(" ");
			}
		};
		a(k, be), ue(J);
		let xe = {
			GridContextFlyout: O,
			props: v,
			root: k,
			emit: A,
			slots: j,
			instance: M,
			brushResources: N,
			syncBrushResources: P,
			backgroundBrush: F,
			shadowProperty: I,
			localShadow: L,
			Shadow: R,
			localTranslation: z,
			Translation: B,
			primitiveResources: V,
			itemContext: H,
			itemScope: pe,
			resolveProp: U,
			attachedProperties: W,
			normalizeChild: G,
			ChildrenOutlet: me,
			contextFlyoutRef: K,
			contextNodes: q,
			ContextFlyoutOutlet: he,
			onContextMenu: ge,
			closeContextMenu: J,
			columnDefinitions: Y,
			rowDefinitions: X,
			registerDefinition: _e,
			columns: Z,
			rows: Q,
			spacing: $,
			rootStyle: ve,
			resolveRootStyle: ye,
			arrangeChildren: be,
			get vAcrylicBrush() {
				return oe;
			},
			get vRadialGradientBrush() {
				return se;
			},
			get vThemeShadow() {
				return ce;
			}
		};
		return Object.defineProperty(xe, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), xe;
	}
});
//#endregion
export { O as GridContextFlyout, k as default };

//# sourceMappingURL=Grid.vue_vue_type_script_setup_true_lang.js.map