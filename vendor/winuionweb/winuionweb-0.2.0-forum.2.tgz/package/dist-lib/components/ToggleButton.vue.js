import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./ToggleButton.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                 */
import { createBlock as n, createCommentVNode as r, mergeProps as i, openBlock as a, renderSlot as o, withCtx as s } from "vue";
//#region src/components/ToggleButton.vue
function c(e, t, c, l, u, d) {
	return a(), n(l.Button, i({ ref: "button" }, l.buttonAttrs, {
		class: ["win-toggle-button", {
			"is-checked": l.IsChecked === !0,
			"is-indeterminate": l.IsChecked === null
		}],
		"aria-pressed": l.IsChecked === null ? "mixed" : l.IsChecked,
		Content: "{x:Bind Content, Mode=OneWay}",
		ContentTemplate: "{x:Bind ContentTemplate}",
		ContentTransitions: "{x:Bind ContentTransitions}",
		IsEnabled: "{x:Bind IsEnabled, Mode=OneWay}",
		RequestedTheme: "{x:Bind RequestedTheme}",
		Click: "OnButtonClick"
	}), {
		default: s(() => [l.hasContent ? o(e.$slots, "default", { key: 0 }) : r("", !0)]),
		_: 3
	}, 16, ["class", "aria-pressed"]);
}
var l = /*#__PURE__*/ e(t, [["render", c], ["__file", "ToggleButton.vue"]]);
//#endregion
export { l as default };

//# sourceMappingURL=ToggleButton.vue.js.map