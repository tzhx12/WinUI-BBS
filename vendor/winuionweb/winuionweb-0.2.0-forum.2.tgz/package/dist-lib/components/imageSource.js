import { resolveXamlResourceObject as e, resolveXamlValue as t } from "./xamlRuntime.js";
import { Fragment as n, defineComponent as r, h as i, isVNode as a, reactive as o } from "vue";
//#region src/components/imageSource.ts
var s = Symbol("winui-image-source"), c = r({
	name: "Image.Source",
	setup(e, { slots: t }) {
		return () => i(n, t.default?.());
	}
}), l = (e) => {
	let t = Number(e);
	return Number.isFinite(t) && t > 0 ? t : 0;
}, u = (e) => e === !0 || e === "True", d = (n, r, i) => {
	if (typeof n == "string") {
		let t = n.match(/^\{(?:StaticResource|ThemeResource)\s+([^\s}]+)\}$/)?.[1];
		if (t) {
			let n = e(t, r) ?? i?.[t];
			return a(n) ? typeof n.children == "string" ? n.children : String(n.props?.Value ?? "") : typeof n == "string" ? n : "";
		}
	}
	let o = t(n, r);
	return typeof o == "string" ? o : "";
}, f = (e = "BitmapImage") => {
	let t = o({
		pixelWidth: 0,
		pixelHeight: 0,
		animated: !1,
		playing: !1
	}), n = o({
		UriSource: "",
		AutoPlay: !0,
		DecodePixelWidth: 0,
		DecodePixelHeight: 0,
		DecodePixelType: "Physical",
		RasterizePixelWidth: 0,
		RasterizePixelHeight: 0,
		get PixelWidth() {
			return t.pixelWidth;
		},
		get PixelHeight() {
			return t.pixelHeight;
		},
		get IsAnimatedBitmap() {
			return t.animated;
		},
		get IsPlaying() {
			return t.playing;
		},
		Play: () => n.__play?.(),
		Stop: () => n.__stop?.(),
		__kind: e,
		__state: t
	});
	return n;
}, p = (e, t, n, r) => {
	if (!n && !r) return {
		width: e,
		height: t
	};
	let i = e / Math.max(1, t);
	return {
		width: Math.max(1, Math.round(n || r * i)),
		height: Math.max(1, Math.round(r || n / i))
	};
}, m = (e, t, n, r, i) => {
	if (i === "None" || !Number.isFinite(n) && !Number.isFinite(r)) return {
		width: e,
		height: t
	};
	let a = n / Math.max(1, e), o = r / Math.max(1, t);
	return Number.isFinite(a) ? Number.isFinite(o) ? i === "Uniform" ? a = o = Math.min(a, o) : i === "UniformToFill" && (a = o = Math.max(a, o)) : o = a : a = o, {
		width: Math.max(0, e * a),
		height: Math.max(0, t * o)
	};
};
//#endregion
export { c as ImageSourceProperty, f as createImageSourceModel, u as imageBoolean, p as imageDecodeSize, l as imageNumber, s as imageSourceContextKey, m as imageStretchSize, d as imageUri };

//# sourceMappingURL=imageSource.js.map