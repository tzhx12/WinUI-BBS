//#region src/components/systemBackdrop.ts
var e = class {
	listeners = /* @__PURE__ */ new Set();
	Changed() {
		for (let e of [...this.listeners]) e(this);
	}
	Subscribe(e) {
		return this.listeners.add(e), () => this.listeners.delete(e);
	}
}, t = class extends e {
	Type = "Mica";
	kind = "Base";
	get Kind() {
		return this.kind;
	}
	set Kind(e) {
		let t = e === "BaseAlt" ? "BaseAlt" : "Base";
		this.kind !== t && (this.kind = t, this.Changed());
	}
	ToConfig() {
		return {
			Type: "Mica",
			Kind: this.Kind
		};
	}
}, n = class extends e {
	Type = "DesktopAcrylic";
	ToConfig() {
		return {
			Type: "DesktopAcrylic",
			Kind: "Base"
		};
	}
}, r = class {
	static IsSupported() {
		return !1;
	}
	Type = "Mica";
	Kind = "Base";
	FallbackColor;
	TintColor;
	TintOpacity;
	LuminosityOpacity;
	ToConfig() {
		return {
			Type: "Mica",
			Kind: this.Kind,
			...this.FallbackColor === void 0 ? {} : { FallbackColor: this.FallbackColor },
			...this.TintColor === void 0 ? {} : { TintColor: this.TintColor },
			...this.TintOpacity === void 0 ? {} : { TintOpacity: this.TintOpacity },
			...this.LuminosityOpacity === void 0 ? {} : { LuminosityOpacity: this.LuminosityOpacity }
		};
	}
}, i = class {
	static IsSupported() {
		return !1;
	}
	Type = "DesktopAcrylic";
	Kind = "Base";
	FallbackColor;
	TintColor;
	TintOpacity;
	LuminosityOpacity;
	ToConfig() {
		return {
			Type: "DesktopAcrylic",
			Kind: this.Kind,
			...this.FallbackColor === void 0 ? {} : { FallbackColor: this.FallbackColor },
			...this.TintColor === void 0 ? {} : { TintColor: this.TintColor },
			...this.TintOpacity === void 0 ? {} : { TintOpacity: this.TintOpacity },
			...this.LuminosityOpacity === void 0 ? {} : { LuminosityOpacity: this.LuminosityOpacity }
		};
	}
};
function a(t) {
	if (t instanceof e || t instanceof r || t instanceof i) return t.ToConfig();
	if (!t || typeof t != "object") return null;
	let n = t, a = n.Type === "Mica" || n.Type === "DesktopAcrylic" ? n.Type : null;
	return a ? {
		Type: a,
		Kind: a === "Mica" ? n.Kind === "BaseAlt" ? "BaseAlt" : "Base" : n.Kind === "Thin" ? "Thin" : "Base",
		...typeof n.FallbackColor == "string" ? { FallbackColor: n.FallbackColor } : {},
		...typeof n.TintColor == "string" ? { TintColor: n.TintColor } : {},
		...typeof n.TintOpacity == "number" ? { TintOpacity: n.TintOpacity } : {},
		...typeof n.LuminosityOpacity == "number" ? { LuminosityOpacity: n.LuminosityOpacity } : {}
	} : null;
}
function o(e) {
	return e ? { ...e } : null;
}
//#endregion
export { n as DesktopAcrylicBackdrop, t as MicaBackdrop, e as SystemBackdrop, o as cloneSystemBackdropConfig, a as toSystemBackdropConfig };

//# sourceMappingURL=systemBackdrop.js.map