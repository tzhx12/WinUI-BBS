import { AnimatedIcon as e } from "./animatedIconRuntime.js";
import { onBeforeUnmount as t } from "vue";
//#region src/components/animatedIconInput.ts
var n = (n = !1, r = (e) => e === "Disabled" ? "Normal" : e) => {
	let i = /* @__PURE__ */ new Map(), a = (e) => {
		let t = i.get(e);
		return t || (t = {
			hovered: !1,
			pressed: !1,
			keyboardPressed: !1
		}, i.set(e, t)), t;
	}, o = (t) => {
		let n = a(t), i = t.disabled || t.getAttribute("aria-disabled") === "true" ? "Disabled" : n.pressed || n.keyboardPressed ? "Pressed" : n.hovered ? "PointerOver" : "Normal";
		e.SetState(t, r(i, t));
	}, s = (e) => {
		e instanceof HTMLElement && (i.has(e) || o(e));
	}, c = (e) => e.currentTarget instanceof HTMLElement ? e.currentTarget : null, l = (e) => {
		let t = c(e);
		t && (a(t).hovered = e.pointerType !== "touch", o(t));
	}, u = (e) => {
		let t = c(e);
		if (!t) return;
		let n = a(t);
		n.hovered = !1, n.pressed = !1, o(t);
	}, d = (e) => {
		let t = c(e);
		if (!t || e.button > 0) return;
		let n = a(t);
		e.pointerType === "touch" && (n.hovered = !1), n.pressed = !0, n.pointerId = e.pointerId, o(t);
	}, f = (e) => {
		let t = c(e);
		t && (a(t).pressed = !1, o(t));
	}, p = (e) => {
		if (e.repeat || ![" ", "Enter"].includes(e.key)) return;
		let t = c(e);
		t && (a(t).keyboardPressed = !0, o(t));
	}, m = (e) => {
		if (![" ", "Enter"].includes(e.key)) return;
		let t = c(e);
		t && (a(t).keyboardPressed = !1, o(t));
	}, h = (e) => {
		let t = c(e);
		t && (a(t).keyboardPressed = !1, o(t));
	}, g = (e) => {
		for (let [t, n] of i) {
			if (!t.isConnected) {
				i.delete(t);
				continue;
			}
			e && n.pointerId !== e.pointerId || (n.pressed = !1, e || (n.keyboardPressed = !1, n.hovered = !1), o(t));
		}
	}, _ = (e) => g(e), v = () => g();
	return window.addEventListener("pointerup", _, !0), window.addEventListener("pointercancel", _, !0), window.addEventListener("blur", v), t(() => {
		window.removeEventListener("pointerup", _, !0), window.removeEventListener("pointercancel", _, !0), window.removeEventListener("blur", v), i.clear();
	}), {
		Attach: s,
		PointerEntered: l,
		PointerExited: u,
		PointerPressed: d,
		PointerReleased: f,
		KeyDown: p,
		KeyUp: m,
		LostFocus: h,
		Reset: v,
		Refresh: () => {
			for (let e of i.keys()) o(e);
		}
	};
};
//#endregion
export { n as useAnimatedIconInput };

//# sourceMappingURL=animatedIconInput.js.map