import { xamlThickness as e } from "./layout.js";
import { normalizeXamlNodes as t, resolveXamlValue as n, updateXamlBinding as r, xamlScopeKey as i } from "./xamlRuntime.js";
import ee from "./Grid.vue.js";
import te from "./SymbolIcon.vue.js";
import ne from "./AppBarButton.vue.js";
import { useI18n as re } from "./i18n/index.js";
import ie from "./TextBlock.vue.js";
import ae from "./FontIcon.vue.js";
import oe from "./AppBarToggleButton.vue.js";
import se from "./Border.vue.js";
import ce from "./Flyout.vue.js";
import le from "./ColumnDefinition.vue.js";
import ue from "./RowDefinition.vue.js";
import de from "./StackPanel.vue.js";
import fe from "./RadioButton.vue.js";
import pe from "./ProgressBar.vue.js";
import me from "./Slider.vue.js";
import { mediaTransportControlDefaults as he } from "./MediaTransportControls.vue_vue_type_script_lang.js";
import { getBrowserMediaSource as ge, needsSoftwareMediaDecoder as _e } from "./mediaSource.js";
import { Fragment as ve, computed as a, defineComponent as ye, getCurrentInstance as be, h as xe, nextTick as Se, onBeforeUnmount as Ce, onMounted as we, provide as Te, ref as o, useSlots as Ee, watch as s } from "vue";
//#region src/components/MediaPlayerElement.vue?vue&type=script&setup=true&lang.ts
var De = ye({
	name: "MediaPlayerElement.TransportControls",
	__mediaTransportControlsProperty: !0,
	setup() {
		return () => null;
	}
}), Oe = /*@__PURE__*/ ye({
	TransportControls: De,
	__name: "MediaPlayerElement",
	props: {
		Source: {
			type: [String, Object],
			default: ""
		},
		AreTransportControlsEnabled: {
			type: [Boolean, String],
			default: !1
		},
		PosterSource: {
			type: [String, Object],
			default: ""
		},
		Stretch: {
			type: String,
			default: "Uniform"
		},
		AutoPlay: {
			type: [Boolean, String],
			default: !1
		},
		RenderTransform: {
			type: [String, Object],
			default: null
		},
		RenderTransformOrigin: {
			type: [String, Object],
			default: "0,0"
		},
		IsFullWindow: {
			type: [Boolean, String],
			default: !1
		},
		TransportControls: {
			type: Object,
			default: null
		},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		Margin: {
			type: [String, Number],
			default: ""
		},
		Visibility: {
			type: String,
			default: "Visible"
		},
		MaxWidth: {
			type: [String, Number],
			default: ""
		},
		Width: {
			type: [String, Number],
			default: ""
		},
		Height: {
			type: [String, Number],
			default: ""
		},
		MinWidth: {
			type: [String, Number],
			default: ""
		},
		MinHeight: {
			type: [String, Number],
			default: ""
		},
		MaxHeight: {
			type: [String, Number],
			default: ""
		},
		HorizontalAlignment: {
			type: String,
			default: ""
		},
		VerticalAlignment: {
			type: String,
			default: ""
		}
	},
	emits: ["Loaded", "update:IsFullWindow"],
	setup(Oe, { expose: ke, emit: Ae }) {
		let c = Oe, je = Ae, { t: l } = re(), u = be(), Me = Ee(), d = o(null), f = o(null), Ne = (e) => {
			f.value = e instanceof HTMLVideoElement ? e : null;
		}, Pe = o(null), Fe = (e) => {
			Pe.value = e;
		}, Ie = () => {
			let e = Pe.value;
			return e && "$el" in e ? e.$el : e;
		}, Le = o(String(n(c.Stretch, u))), p = o(!1), m = o(!1), h = o(0), g = o(0), _ = o(50), v = o(!1), y = o(!1), b = o(!1), x = o(!1), Re = o(""), S = o(!1), ze = o(!1), C = o(!1), w = o(""), Be = o(!1), T = o(!0), Ve = a(() => {
			let e = n(c.IsEnabled, u);
			return e !== !1 && e !== "False" && e !== "false";
		}), He = o(!1), Ue = a(() => g.value || 1), We = a(() => y.value || b.value), Ge = a(() => l("text.volume")), Ke = a(() => m.value ? l("text.unmute") : l("text.mute")), qe = a(() => p.value ? l("text.pause") : l("text.play")), Je = a(() => l("text.aspect-ratio")), Ye = a(() => l("text.cast")), Xe = a(() => w.value ? l(w.value) : ""), Ze = a(() => l(ze.value ? "text.exit-full-screen" : "text.full-screen")), Qe = a(() => ze.value ? "BackToWindow" : "FullScreen"), $e = a(() => l("text.media-failed")), et = a(() => qr(h.value)), tt = a(() => g.value > 0 ? qr(Math.floor(g.value) - Math.floor(h.value)) : ""), nt = a(() => l("text.media-transport-controls")), rt = ye({
			name: "MediaPlayerTransportControls",
			setup(e, { slots: n }) {
				let r = be();
				return () => xe(ve, t(n.default?.() ?? [], r));
			}
		}), E = o(!1), D = o(!1), it = o(!1), O = o(!1), k = null, A = null, at = null, j = 0, M = null, ot = null, N = 0, st = {
			RewindButton: 1,
			FastForwardButton: 1,
			RepeatButton: 1,
			PreviousTrackButton: 3,
			NextTrackButton: 3,
			SkipBackwardButton: 5,
			SkipForwardButton: 5,
			StopButton: 7,
			ZoomButton: 9,
			PlaybackRateButton: 10,
			CastButton: 11,
			FullWindowButton: 17,
			VolumeMuteButton: 19,
			PlayPauseButton: 23
		}, ct = () => {
			N = 0;
			let e = d.value?.querySelector(".win-media-command-bar");
			if (!e) return;
			let t = Array.from(e.querySelectorAll("button[data-template-part]"));
			for (let e of t) e.removeAttribute("data-media-dropout");
			let n = () => t.filter((e) => getComputedStyle(e).display !== "none"), r = () => {
				let t = n(), r = t.reduce((e, t) => e + t.getBoundingClientRect().width, 0);
				if (V.value) return r <= e.clientWidth;
				let i = t.filter((e) => e.closest(".win-media-command-center")).length * 40, ee = t.filter((e) => e.closest(".win-media-command-left")).length * 40, te = t.filter((e) => e.closest(".win-media-command-right")).length * 40;
				return r <= e.clientWidth && i <= e.clientWidth - 2 * Math.max(ee, te);
			};
			for (let e of [...new Set(Object.values(st))].sort((e, t) => e - t)) {
				if (r()) break;
				for (let t of n()) st[t.dataset.templatePart || ""] === e && t.setAttribute("data-media-dropout", "true");
			}
		}, lt = () => {
			N && cancelAnimationFrame(N), N = requestAnimationFrame(ct);
		}, P = !1, F = !1, ut = (e) => e instanceof Element && !!e.closest(".win-media-progress-slider"), dt = () => {
			P || !Ft.value || (P = !0, F = !!(f.value && !f.value.paused), f.value?.pause());
		}, ft = () => {
			P && (P = !1, F && H.value && f.value?.play().catch(() => {}), F = !1);
		}, pt = (e) => {
			ut(e.target) && [
				"ArrowLeft",
				"ArrowRight",
				"ArrowUp",
				"ArrowDown",
				"Home",
				"End",
				"PageUp",
				"PageDown"
			].includes(e.key) && dt();
		}, mt = (e) => {
			ut(e.target) && ft();
		}, I = () => {
			O.value = !1, D.value = !1, ft(), Z();
		}, L = (e) => {
			if (!(e === "" || e == null)) return typeof e == "number" || /^-?\d+(\.\d+)?$/.test(String(e).trim()) ? `${e}px` : String(e);
		}, ht = (e) => {
			if (typeof e == "string") return e;
			if (e && typeof e == "object") {
				let t = e;
				return t.CurrentItem && t.CurrentItem !== e ? ht(t.CurrentItem) : t.Source && t.Source !== e ? ht(t.Source) : String(t.UriSource || t.Uri || "");
			}
			return "";
		}, gt = a(() => n(c.Source, u)), R = a(() => {
			let e = gt.value;
			return e && typeof e == "object" && typeof e.getVideoTracks == "function" ? e : null;
		}), z = a(() => R.value ? "" : ht(gt.value)), _t = a(() => ht(n(c.PosterSource, u))), vt = a(() => {
			let e = n(c.AutoPlay, u);
			return e === !0 || e === "True" || e === "true";
		}), yt = a(() => {
			let e = {}, t = (n) => {
				for (let r of n) {
					if (!r || typeof r != "object") continue;
					let n = r;
					if (n.type?.__mediaTransportControlsProperty) {
						let t = (n.children?.default?.() ?? []).find((e) => e && typeof e == "object" && e.type?.__mediaTransportControls);
						Object.assign(e, t?.props ?? n.props ?? {});
					} else n.type === ve && Array.isArray(n.children) && t(n.children);
				}
			};
			return t(Me.default?.() ?? []), e;
		}), B = a(() => Object.fromEntries(Object.entries({
			...he,
			...yt.value,
			...n(c.TransportControls, u) || {}
		}).map(([e, t]) => [e, n(t, u)]))), bt = a(() => B.value.IsSeekBarVisible !== !1), xt = a(() => B.value.IsVolumeButtonVisible !== !1), St = a(() => B.value.IsZoomButtonVisible !== !1), Ct = a(() => B.value.IsFullWindowButtonVisible !== !1), V = a(() => B.value.IsCompact === !0), wt = a(() => V.value ? "48" : ""), Tt = a(() => V.value ? "3" : "0"), Et = a(() => V.value ? "12,-1,8,1" : "7,2,7,1"), Dt = a(() => V.value ? "Collapsed" : "Visible"), Ot = a(() => V.value ? "Visible" : "Collapsed"), kt = a(() => V.value ? "Collapsed" : "Visible"), At = a(() => V.value ? 2 : 1), jt = a(() => V.value ? 1 : 2), Mt = a(() => V.value ? "0" : "0,3"), Nt = a(() => !R.value), Pt = a(() => {
			let e = n(c.AreTransportControlsEnabled, u);
			return e === !0 || e === "True" || e === "true";
		}), H = a(() => !!((z.value || R.value) && !v.value && !x.value && Ve.value)), Ft = a(() => !!(H.value && g.value > 0 && B.value.IsSeekEnabled)), It = a(() => !!(H.value && B.value.IsVolumeEnabled)), Lt = a(() => !!(H.value && B.value.IsZoomEnabled)), Rt = a(() => H.value && !R.value && !C.value), zt = a(() => Ve.value && B.value.IsFullWindowEnabled !== !1 && !!d.value?.requestFullscreen && document.fullscreenEnabled !== !1), U = (e) => B.value[e] === !0, Bt = (e) => {
			if (typeof document > "u") return !1;
			let t = document.createElement("video");
			try {
				return t.playbackRate = e, t.playbackRate === e;
			} catch {
				return !1;
			}
		}, Vt = Bt(2), Ht = Bt(-2), Ut = a(() => B.value.FastPlayFallbackBehaviour === "Skip"), Wt = a(() => U("IsStopButtonVisible")), Gt = a(() => U("IsSkipBackwardButtonVisible")), Kt = a(() => U("IsSkipForwardButtonVisible")), qt = a(() => U("IsFastRewindButtonVisible") && (Ht || B.value.FastPlayFallbackBehaviour !== "Hide")), Jt = a(() => U("IsFastForwardButtonVisible") && (Vt || B.value.FastPlayFallbackBehaviour !== "Hide")), Yt = a(() => U("IsPreviousTrackButtonVisible")), Xt = a(() => U("IsNextTrackButtonVisible")), Zt = a(() => U("IsPlaybackRateButtonVisible")), Qt = a(() => U("IsRepeatButtonVisible")), $t = a(() => H.value && U("IsStopEnabled")), en = a(() => H.value && g.value > 0 && U("IsSkipBackwardEnabled")), tn = a(() => H.value && g.value > 0 && U("IsSkipForwardEnabled")), nn = a(() => H.value && p.value && g.value > 0 && U("IsFastRewindEnabled") && (Ht || Ut.value)), rn = a(() => H.value && p.value && g.value > 0 && U("IsFastForwardEnabled") && (Vt || Ut.value)), an = a(() => H.value && !R.value && U("IsPlaybackRateEnabled")), on = a(() => H.value && !R.value && U("IsRepeatEnabled")), W = a(() => {
			let e = gt.value;
			return e && typeof e == "object" ? e : null;
		}), sn = a(() => H.value && typeof W.value?.MoveNext == "function" && (!W.value.Items || W.value.AutoRepeatEnabled || Number(W.value.CurrentItemIndex ?? 0) < W.value.Items.length - 1)), cn = a(() => H.value && typeof W.value?.MovePrevious == "function" && (!W.value.Items || W.value.AutoRepeatEnabled || Number(W.value.CurrentItemIndex ?? 0) > 0)), G = o(1), K = o(0), ln = 1, q = o("None"), un = a(() => q.value !== "None"), dn = a(() => q.value === "One" ? "" : ""), fn = o(!1), pn = o(null), mn = o(null), hn = o(null), gn = a(() => l("media.stop")), _n = a(() => l("media.skip-backward")), vn = a(() => l("media.skip-forward")), yn = a(() => l("media.previous-track")), bn = a(() => l("media.next-track")), xn = a(() => K.value < 0 ? l("media.rewind-rate", { rate: Math.abs(K.value) }) : l("media.rewind")), Sn = a(() => K.value > 0 ? l("media.fast-forward-rate", { rate: K.value }) : l("media.fast-forward")), Cn = a(() => l(`media.repeat-${q.value.toLowerCase()}`)), wn = a(() => l("media.playback-rate")), Tn = a(() => l("media.playback-rate-value", { rate: G.value })), En = a(() => l("media.playback-rate-value", { rate: .25 })), Dn = a(() => l("media.playback-rate-value", { rate: .5 })), On = a(() => l("media.playback-rate-normal")), kn = a(() => l("media.playback-rate-value", { rate: 1.5 })), An = a(() => l("media.playback-rate-value", { rate: 2 })), jn = a(() => G.value === .25), Mn = a(() => G.value === .5), Nn = a(() => G.value === 1), Pn = a(() => G.value === 1.5), Fn = a(() => G.value === 2), In = () => {
			let e = f.value;
			e && (G.value = e.playbackRate, e.loop ? q.value = "One" : q.value === "One" && (q.value = "None"));
		}, J = () => {
			let e = f.value;
			K.value && e && (e.playbackRate = ln), K.value = 0;
		}, Ln = () => {
			let e = f.value;
			!e || !$t.value || (J(), e.pause(), Number.isFinite(e.duration) && (e.currentTime = 0), lr(), X());
		}, Rn = (e) => {
			let t = f.value;
			!t || !Number.isFinite(t.duration) || t.duration <= 0 || (t.currentTime = Math.max(0, Math.min(t.duration, t.currentTime + e)), lr(), X());
		}, zn = () => {
			en.value && Rn(-10);
		}, Bn = () => {
			tn.value && Rn(30);
		}, Vn = (e) => {
			let t = f.value;
			if (!t || !(e > 0 ? rn.value : nn.value)) return;
			let n = [
				2,
				4,
				8,
				16
			];
			K.value || (ln = t.playbackRate);
			let r = K.value * e > 0 ? Math.abs(K.value) : 0, i = n[(n.indexOf(r) + 1) % n.length] * e;
			try {
				t.playbackRate = i, K.value = i, t.play().catch(() => {});
			} catch {
				B.value.FastPlayFallbackBehaviour === "Skip" && Rn(e > 0 ? 30 : -10);
			}
			In(), X();
		}, Hn = () => Vn(-1), Un = () => Vn(1), Wn = (e) => {
			let t = f.value;
			!t || !an.value || (J(), t.playbackRate = e, G.value = e, pn.value?.Hide());
		}, Gn = () => Wn(.25), Kn = () => Wn(.5), qn = () => Wn(1), Jn = () => Wn(1.5), Yn = () => Wn(2), Xn = () => {
			fn.value = !0, S.value = !0;
		}, Zn = () => {
			fn.value = !1, S.value = !1;
		}, Qn = () => {
			let e = f.value;
			if (!e || !on.value) return;
			let t = W.value, n = typeof t?.MoveNext == "function";
			q.value = q.value === "None" ? "One" : q.value === "One" && n ? "All" : "None", e.loop = q.value === "One", n && t && (t.AutoRepeatEnabled = q.value === "All");
		}, $n = (e) => {
			let t = W.value, n = e > 0 ? t?.MoveNext : t?.MovePrevious;
			!t || typeof n != "function" || !(e > 0 ? sn.value : cn.value) || (J(), n.call(t), Jr(), X());
		}, er = () => $n(-1), tr = () => $n(1);
		s(gt, () => {
			J(), q.value = f.value?.loop ? "One" : "None";
		}), Ce(J);
		let nr = a(() => B.value.ShowAndHideAutomatically !== !1), rr = a(() => ({
			None: "none",
			Fill: "fill",
			Uniform: "contain",
			UniformToFill: "cover"
		})[Le.value] || "contain"), ir = a(() => ({ objectFit: rr.value })), ar = a(() => ze.value), or = a(() => {
			let t = n(c.RenderTransform, u), r = n(c.RenderTransformOrigin, u), i = typeof r == "string" ? r.split(",").map(Number) : [Number(r?.X || 0), Number(r?.Y || 0)];
			return {
				width: L(n(c.Width, u)),
				height: L(n(c.Height, u)),
				minWidth: L(n(c.MinWidth, u)),
				minHeight: L(n(c.MinHeight, u)),
				maxWidth: ar.value ? void 0 : L(n(c.MaxWidth, u)),
				maxHeight: L(n(c.MaxHeight, u)),
				margin: e(n(c.Margin, u)),
				display: n(c.Visibility, u) === "Collapsed" ? "none" : void 0,
				justifySelf: {
					Left: "start",
					Center: "center",
					Right: "end",
					Stretch: "stretch"
				}[String(n(c.HorizontalAlignment, u))] || void 0,
				alignSelf: {
					Top: "start",
					Center: "center",
					Bottom: "end",
					Stretch: "stretch"
				}[String(n(c.VerticalAlignment, u))] || void 0,
				transform: t ? `scale(${Number(t.ScaleX ?? 1)}, ${Number(t.ScaleY ?? 1)})` : void 0,
				transformOrigin: `${(i[0] || 0) * 100}% ${(i[1] || 0) * 100}%`
			};
		}), sr = a(() => p.value ? "" : ""), cr = a(() => m.value || _.value === 0 ? "" : ""), lr = (e) => {
			let t = e?.currentTarget;
			t instanceof HTMLVideoElement && f.value !== t && (f.value = t);
			let n = f.value || (t instanceof HTMLVideoElement ? t : null);
			n && (h.value = n.currentTime || 0, g.value = Number.isFinite(n.duration) ? n.duration : 0, He.value = n.readyState >= 2 && !v.value, m.value = n.muted, _.value = Math.round((n.volume || 0) * 100));
		}, Y = () => {
			at && window.clearTimeout(at), at = null;
		}, ur = (e) => {
			lr(e), Y(), v.value = !1, y.value = !1, b.value = !1, lr();
		}, dr = () => {
			y.value = !0;
			let e = f.value;
			e && e.readyState >= 2 && (b.value = !1), X(), k && window.clearTimeout(k);
		}, fr = () => {
			He.value = !1, h.value = 0, g.value = 0, p.value = !1;
		}, pr = () => {
			Y(), y.value = !1, b.value = !1, Z();
		}, mr = () => {
			v.value || x.value || (Y(), v.value = !0, He.value = !1, p.value = !1, y.value = !1, b.value = !1, X(), k && window.clearTimeout(k), k = null);
		}, hr = () => {
			p.value = !0, X();
		}, gr = () => {
			p.value = !1, k && window.clearTimeout(k), k = null, T.value = !0;
		}, _r = () => {
			let e = f.value;
			if (!(!e || !H.value)) {
				if (K.value) {
					J(), e.play().catch(() => {});
					return;
				}
				e.paused ? e.play().catch(() => {}) : e.pause();
			}
		}, vr = () => {
			S.value = !0;
		}, yr = () => {
			S.value = !1;
		}, br = () => {
			let e = f.value;
			!e || !It.value || (e.muted = !e.muted, m.value = e.muted, !e.muted && e.volume === 0 && (e.volume = 1, _.value = 100));
		}, xr = (e, t) => {
			let n = f.value;
			if (!n || !It.value || !Number.isFinite(t?.NewValue)) return;
			let r = Math.max(0, Math.min(100, t.NewValue));
			n.volume = r / 100, n.muted = r === 0, _.value = r, m.value = n.muted;
		}, Sr = () => {
			let e = d.value;
			return !!(e && (document.fullscreenElement === e || e.matches(":fullscreen")));
		}, Cr = () => {
			let e = Sr(), t = ze.value !== e;
			ze.value = e, e || (S.value = !1), t && je("update:IsFullWindow", e), r(c.IsFullWindow, e, u);
		}, wr = async () => {
			let e = d.value;
			if (e?.requestFullscreen) try {
				await e.requestFullscreen();
			} catch {} finally {
				Cr();
			}
		}, Tr = async () => {
			try {
				document.fullscreenElement && document.exitFullscreen && await document.exitFullscreen();
			} catch {} finally {
				Cr();
			}
		}, Er = () => Cr(), Dr = () => {
			zt.value && (Sr() ? Tr() : wr());
		}, Or = (e, t) => {
			let n = f.value;
			!n || !Ft.value || !Number.isFinite(t?.NewValue) || (n.currentTime = Math.max(0, Math.min(g.value, t.NewValue)), lr());
		}, kr = () => {
			let e = ["Uniform", "UniformToFill"];
			Le.value = e[(e.indexOf(Le.value) + 1) % e.length];
		}, Ar = () => {
			let e = window.chrome?.webview;
			return e?.postMessage ? (e.postMessage({
				source: "WinUIonWeb",
				type: "mediaCastRequested",
				sourceUri: z.value || f.value?.currentSrc
			}), !0) : !1;
		}, jr = async () => {
			let e = f.value;
			if (!e || !Rt.value) return;
			let t = ++j;
			C.value = !0, w.value = "";
			let n = "text.browser-does-not-support-casting";
			try {
				let r = document, i = r.permissionsPolicy || r.featurePolicy;
				if (i?.features?.().includes("remote-playback") && i.allowsFeature("remote-playback") === !1) n = "text.casting-permission-denied";
				else if (navigator.userActivation && !navigator.userActivation.isActive) n = "text.casting-user-activation-required";
				else {
					let r = e.remote;
					if (r?.prompt) try {
						await r.prompt();
						return;
					} catch (e) {
						if (t !== j) return;
						let r = e?.name;
						if (r === "AbortError") return;
						if (r === "SecurityError") n = "text.casting-permission-denied";
						else if (r === "NotAllowedError") n = "text.casting-request-not-approved";
						else if (r === "InvalidAccessError") n = "text.casting-user-activation-required";
						else if (n = r === "NotFoundError" ? "text.no-casting-devices-found" : "text.casting-is-not-available", Ar()) return;
					}
					else {
						let t = e;
						if (t.webkitShowPlaybackTargetPicker) {
							t.webkitShowPlaybackTargetPicker();
							return;
						}
						if (Ar()) return;
					}
				}
			} catch {
				n = "text.casting-is-not-available";
			} finally {
				t === j && (C.value = !1);
			}
			await Se(), t === j && (w.value = n);
		}, Mr = () => {
			w.value = "";
		};
		s(w, async (e) => {
			Be.value = !1, e && (await Se(), w.value === e && (Be.value = !0, hn.value?.ShowAt()));
		});
		let Nr = () => {
			let e = f.value;
			!e || !("remote" in e) || (M = e.remote, M.onconnecting = () => X(), M.onconnect = () => X(), M.ondisconnect = () => X());
		}, Pr = () => {
			M &&= (M.onconnecting = null, M.onconnect = null, M.ondisconnect = null, null);
		}, X = () => {
			T.value = !0, k && window.clearTimeout(k), A && window.clearTimeout(A), A = window.setTimeout(() => {
				A = null, Z();
			}, 0);
		}, Z = () => {
			k && window.clearTimeout(k), k = null, !(!nr.value || !p.value || y.value || v.value || E.value || D.value || it.value || O.value || S.value || C.value || w.value) && (k = window.setTimeout(() => {
				T.value = !1, k = null;
			}, 3e3));
		}, Fr = (e) => {
			E.value = e.pointerType !== "touch", E.value && k && window.clearTimeout(k);
		}, Ir = () => {
			E.value = !1, Z();
		}, Lr = () => {
			D.value = !0, it.value = !1, k && window.clearTimeout(k);
		}, Rr = () => {
			D.value = !1, Z();
		}, zr = (e) => {
			O.value = !1, D.value = !1;
			let t = e && Number.isFinite(e.clientX) && Number.isFinite(e.clientY) ? e : null, n = t ? document.elementFromPoint(t.clientX, t.clientY) : null;
			E.value = e.pointerType !== "touch" && !!(n && Ie()?.contains(n)), E.value || Z();
		}, Br = () => {
			D.value || (it.value = !0, k && window.clearTimeout(k));
		}, Vr = (e) => {
			let t = e.relatedTarget;
			t instanceof Node && e.currentTarget.contains(t) || (it.value = !1, ft(), Z());
		}, Hr = (e) => {
			O.value = !0, it.value = !1, k && window.clearTimeout(k), X(), ut(e.target) && dt();
		}, Ur = () => {
			O.value = !1, ft(), Z();
		}, Wr = () => {
			O.value = !1, Z();
		}, Gr = () => {
			O.value = !1, E.value = !1, Z();
		}, Kr = () => {
			p.value = !1, k && window.clearTimeout(k), k = null, T.value = !0;
		}, qr = (e) => {
			let t = Math.max(0, Math.floor(Number(e) || 0)) % 86400, n = Math.floor(t / 3600), r = Math.floor(t % 3600 / 60), i = String(t % 60).padStart(2, "0");
			return `${String(n).padStart(2, "0")}:${String(r).padStart(2, "0")}:${i}`;
		}, Q = 0, $ = "", Jr = async () => {
			let e = ++Q;
			P = !1, F = !1, Y(), v.value = !1, He.value = !1, h.value = 0, g.value = 0, p.value = !1, y.value = !!(z.value || R.value), b.value = !!(z.value || R.value), x.value = !1, X(), await Se();
			let t = f.value;
			if (!t || e !== Q) return;
			t.pause(), Re.value = "";
			let n = R.value;
			if (t.removeAttribute("src"), t.srcObject = n, $ && URL.revokeObjectURL($), $ = "", t.muted = n ? !0 : m.value, !n && z.value) {
				let n = z.value;
				if (_e(n, t)) {
					x.value = !0;
					try {
						let t = await ge(n);
						if (e !== Q) return;
						$ = URL.createObjectURL(t), n = $;
					} catch {
						if (e !== Q) return;
					} finally {
						e === Q && (x.value = !1);
					}
				}
				if (e !== Q) return;
				Re.value = n, t.src = n, t.load();
			} else n || t.load();
			vt.value && (R.value || z.value) && t.play().catch((n) => {
				if (e === Q) {
					if (n?.name === "NotAllowedError") {
						t.muted = !0, m.value = !0, t.play().catch(() => {});
						return;
					}
					e === Q && R.value && n?.name !== "AbortError" && t.dispatchEvent(new Event("error"));
				}
			});
		}, Yr = null, Xr = () => {
			if (!f.value || Yr === f.value) return;
			Yr = f.value, f.value.volume = .5, Nr(), Jr();
			let e = { MediaPlayer: f.value };
			je("Loaded", e, { OriginalSource: e });
		};
		s([z, R], Jr), s([z, R], () => {
			++j, C.value = !1, w.value = "";
		}), s(f, (e) => {
			e && Xr();
		}, { flush: "post" }), s(vt, (e) => {
			e ? f.value?.play().catch(() => {}) : f.value?.pause();
		}), s(() => n(c.IsFullWindow, u), (e) => {
			e && !Sr() ? wr() : !e && Sr() && Tr();
		}), s(S, (e) => {
			e ? X() : (mn.value?.Hide(), Z());
		}), s([C, w], ([e, t]) => {
			e || t ? X() : Z();
		}), s(nr, (e) => {
			e ? Z() : (k && window.clearTimeout(k), k = null, T.value = !0);
		}), s(() => n(c.Stretch, u), (e) => {
			Le.value = String(e);
		}), we(() => {
			ot = new ResizeObserver(lt), d.value && ot.observe(d.value), window.addEventListener("pointerup", I), window.addEventListener("pointercancel", I), window.addEventListener("blur", I), document.addEventListener("fullscreenchange", Er), document.addEventListener("webkitfullscreenchange", Er), f.value && (f.value.muted = !1, f.value.volume = .5, Xr()), n(c.IsFullWindow, u) === !0 && wr();
		}), Ce(() => {
			ot?.disconnect(), N && cancelAnimationFrame(N), ++Q, ++j, window.removeEventListener("pointerup", I), window.removeEventListener("pointercancel", I), window.removeEventListener("blur", I), f.value && (f.value.pause(), f.value.srcObject = null), $ && URL.revokeObjectURL($), document.removeEventListener("fullscreenchange", Er), document.removeEventListener("webkitfullscreenchange", Er), Pr(), k && window.clearTimeout(k), A && window.clearTimeout(A), Y();
		}), Te(i, {
			currentTime: h,
			seekMaximum: Ue,
			transportLoading: We,
			mediaError: v,
			volumePercent: _,
			volumeLabel: Ge,
			muteLabel: Ke,
			playLabel: qe,
			zoomLabel: Je,
			castLabel: Ye,
			castFeedbackText: Xe,
			castFeedbackOpen: Be,
			fullWindowLabel: Ze,
			fullWindowSymbol: Qe,
			canPlay: H,
			canSeek: Ft,
			canChangeVolume: It,
			canZoom: Lt,
			canRequestCast: Rt,
			canChangeFullWindow: zt,
			isCompact: V,
			isVolumeFlyoutOpen: S,
			controlPanelHeight: wt,
			controlPanelPadding: Tt,
			progressSliderMargin: Et,
			timeTextVisibility: Dt,
			compactPlayVisibility: Ot,
			normalPlayVisibility: kt,
			commandColumn: At,
			commandRow: jt,
			commandBarMargin: Mt,
			mediaErrorText: $e,
			elapsedTimeText: et,
			remainingTimeText: tt,
			transportControlsLabel: nt,
			volumeGlyph: cr,
			playGlyph: sr,
			onControlPanelEntered: Fr,
			onControlPanelExited: Ir,
			onControlPanelPressed: Lr,
			onControlPanelReleased: Rr,
			onControlPanelCaptureLost: zr,
			onControlPanelFocusEntered: Br,
			onControlPanelFocusExited: Vr,
			isStopButtonVisible: Wt,
			isSkipBackwardButtonVisible: Gt,
			isSkipForwardButtonVisible: Kt,
			isFastRewindButtonVisible: qt,
			isFastForwardButtonVisible: Jt,
			isPreviousTrackButtonVisible: Yt,
			isNextTrackButtonVisible: Xt,
			isPlaybackRateButtonVisible: Zt,
			isRepeatButtonVisible: Qt,
			canStop: $t,
			canSkipBackward: en,
			canSkipForward: tn,
			canFastRewind: nn,
			canFastForward: rn,
			canMovePrevious: cn,
			canMoveNext: sn,
			canChangePlaybackRate: an,
			canRepeat: on,
			stopLabel: gn,
			skipBackwardLabel: _n,
			skipForwardLabel: vn,
			previousTrackLabel: yn,
			nextTrackLabel: bn,
			fastRewindLabel: xn,
			fastForwardLabel: Sn,
			repeatLabel: Cn,
			playbackRateLabel: wn,
			playbackRateText: Tn,
			quarterSpeedLabel: En,
			halfSpeedLabel: Dn,
			normalSpeedLabel: On,
			oneAndHalfSpeedLabel: kn,
			doubleSpeedLabel: An,
			isLooping: un,
			repeatGlyph: dn,
			isQuarterSpeed: jn,
			isHalfSpeed: Mn,
			isNormalSpeed: Nn,
			isOneAndHalfSpeed: Pn,
			isDoubleSpeed: Fn,
			seekTo: Or,
			setVolume: xr,
			toggleMute: br,
			togglePlay: _r,
			toggleStretch: kr,
			toggleFullWindow: Dr,
			onCastRequested: jr,
			onCastFeedbackClosed: Mr,
			onVolumeFlyoutOpened: vr,
			onVolumeFlyoutClosed: yr,
			stopPlayback: Ln,
			skipBackward: zn,
			skipForward: Bn,
			fastRewind: Hn,
			fastForward: Un,
			movePreviousTrack: er,
			moveNextTrack: tr,
			toggleRepeat: Qn,
			setQuarterSpeed: Gn,
			setHalfSpeed: Kn,
			setNormalSpeed: qn,
			setOneAndHalfSpeed: Jn,
			setDoubleSpeed: Yn,
			onRateFlyoutOpened: Xn,
			onRateFlyoutClosed: Zn
		}), s([
			B,
			Nt,
			Pt
		], () => {
			Se(lt);
		}, {
			deep: !0,
			flush: "post"
		}), ke({ MediaPlayer: f });
		let Zr = {
			MediaPlayerTransportControlsProperty: De,
			props: c,
			emit: je,
			t: l,
			instance: u,
			slots: Me,
			rootRef: d,
			videoRef: f,
			setVideoElement: Ne,
			controlPanelRef: Pe,
			setControlPanelElement: Fe,
			controlPanelElement: Ie,
			activeStretch: Le,
			isPlaying: p,
			muted: m,
			currentTime: h,
			duration: g,
			volumePercent: _,
			mediaError: v,
			isBuffering: y,
			isMediaLoading: b,
			isSourcePreparing: x,
			playbackUri: Re,
			isVolumeFlyoutOpen: S,
			fullWindowState: ze,
			castRequestPending: C,
			castFeedbackKey: w,
			castFeedbackOpen: Be,
			controlsVisible: T,
			isEnabled: Ve,
			hasVideoFrame: He,
			seekMaximum: Ue,
			transportLoading: We,
			volumeLabel: Ge,
			muteLabel: Ke,
			playLabel: qe,
			zoomLabel: Je,
			castLabel: Ye,
			castFeedbackText: Xe,
			fullWindowLabel: Ze,
			fullWindowSymbol: Qe,
			mediaErrorText: $e,
			elapsedTimeText: et,
			remainingTimeText: tt,
			transportControlsLabel: nt,
			TransportControls: rt,
			controlPanelPointerOver: E,
			controlPanelPointerPressed: D,
			controlPanelHasFocus: it,
			rootPointerPressed: O,
			get hideControlsTimer() {
				return k;
			},
			set hideControlsTimer(e) {
				k = e;
			},
			get pointerMoveEndTimer() {
				return A;
			},
			set pointerMoveEndTimer(e) {
				A = e;
			},
			get mediaLoadTimer() {
				return at;
			},
			set mediaLoadTimer(e) {
				at = e;
			},
			get castRequestVersion() {
				return j;
			},
			set castRequestVersion(e) {
				j = e;
			},
			get remotePlayback() {
				return M;
			},
			set remotePlayback(e) {
				M = e;
			},
			get transportSizeObserver() {
				return ot;
			},
			set transportSizeObserver(e) {
				ot = e;
			},
			get commandArrangeFrame() {
				return N;
			},
			set commandArrangeFrame(e) {
				N = e;
			},
			commandDropoutOrder: st,
			arrangeTransportCommands: ct,
			scheduleCommandArrangement: lt,
			get scrubbing() {
				return P;
			},
			set scrubbing(e) {
				P = e;
			},
			get resumeAfterScrubbing() {
				return F;
			},
			set resumeAfterScrubbing(e) {
				F = e;
			},
			isProgressSliderTarget: ut,
			beginScrubbing: dt,
			endScrubbing: ft,
			onTransportKeyDown: pt,
			onTransportKeyUp: mt,
			clearPointerState: I,
			cssLength: L,
			mediaUri: ht,
			sourceValue: gt,
			sourceStream: R,
			sourceUri: z,
			posterUri: _t,
			autoPlayEnabled: vt,
			nestedTransportControls: yt,
			transport: B,
			isSeekBarVisible: bt,
			isVolumeButtonVisible: xt,
			isZoomButtonVisible: St,
			isFullWindowButtonVisible: Ct,
			isCompact: V,
			controlPanelHeight: wt,
			controlPanelPadding: Tt,
			progressSliderMargin: Et,
			timeTextVisibility: Dt,
			compactPlayVisibility: Ot,
			normalPlayVisibility: kt,
			commandColumn: At,
			commandRow: jt,
			commandBarMargin: Mt,
			isCastButtonVisible: Nt,
			areTransportControlsEnabled: Pt,
			canPlay: H,
			canSeek: Ft,
			canChangeVolume: It,
			canZoom: Lt,
			canRequestCast: Rt,
			canChangeFullWindow: zt,
			transportFlag: U,
			supportsNativePlaybackRate: Bt,
			supportsForwardRate: Vt,
			supportsReverseRate: Ht,
			allowsRateFallback: Ut,
			isStopButtonVisible: Wt,
			isSkipBackwardButtonVisible: Gt,
			isSkipForwardButtonVisible: Kt,
			isFastRewindButtonVisible: qt,
			isFastForwardButtonVisible: Jt,
			isPreviousTrackButtonVisible: Yt,
			isNextTrackButtonVisible: Xt,
			isPlaybackRateButtonVisible: Zt,
			isRepeatButtonVisible: Qt,
			canStop: $t,
			canSkipBackward: en,
			canSkipForward: tn,
			canFastRewind: nn,
			canFastForward: rn,
			canChangePlaybackRate: an,
			canRepeat: on,
			playbackList: W,
			canMoveNext: sn,
			canMovePrevious: cn,
			playbackRate: G,
			trickPlaybackRate: K,
			get originalPlaybackRate() {
				return ln;
			},
			set originalPlaybackRate(e) {
				ln = e;
			},
			repeatMode: q,
			isLooping: un,
			repeatGlyph: dn,
			isRateFlyoutOpen: fn,
			rateFlyoutRef: pn,
			volumeFlyoutRef: mn,
			castFeedbackFlyoutRef: hn,
			stopLabel: gn,
			skipBackwardLabel: _n,
			skipForwardLabel: vn,
			previousTrackLabel: yn,
			nextTrackLabel: bn,
			fastRewindLabel: xn,
			fastForwardLabel: Sn,
			repeatLabel: Cn,
			playbackRateLabel: wn,
			playbackRateText: Tn,
			quarterSpeedLabel: En,
			halfSpeedLabel: Dn,
			normalSpeedLabel: On,
			oneAndHalfSpeedLabel: kn,
			doubleSpeedLabel: An,
			isQuarterSpeed: jn,
			isHalfSpeed: Mn,
			isNormalSpeed: Nn,
			isOneAndHalfSpeed: Pn,
			isDoubleSpeed: Fn,
			syncOptionalPlaybackState: In,
			resetTrickPlayback: J,
			stopPlayback: Ln,
			skipBy: Rn,
			skipBackward: zn,
			skipForward: Bn,
			enterTrickPlayback: Vn,
			fastRewind: Hn,
			fastForward: Un,
			setPlaybackSpeed: Wn,
			setQuarterSpeed: Gn,
			setHalfSpeed: Kn,
			setNormalSpeed: qn,
			setOneAndHalfSpeed: Jn,
			setDoubleSpeed: Yn,
			onRateFlyoutOpened: Xn,
			onRateFlyoutClosed: Zn,
			toggleRepeat: Qn,
			movePlaybackTrack: $n,
			movePreviousTrack: er,
			moveNextTrack: tr,
			showAndHideAutomatically: nr,
			stretchValue: rr,
			videoStyle: ir,
			isFullWindowActive: ar,
			rootStyle: or,
			playGlyph: sr,
			volumeGlyph: cr,
			syncFromVideo: lr,
			clearMediaLoadTimer: Y,
			onMediaLoaded: ur,
			onBufferingStarted: dr,
			onMediaEmptied: fr,
			onBufferingEnded: pr,
			onMediaError: mr,
			onPlay: hr,
			onPause: gr,
			togglePlay: _r,
			onVolumeFlyoutOpened: vr,
			onVolumeFlyoutClosed: yr,
			toggleMute: br,
			setVolume: xr,
			isRootFullscreen: Sr,
			syncFullscreenState: Cr,
			enterFullWindow: wr,
			exitFullWindow: Tr,
			onFullscreenChanged: Er,
			toggleFullWindow: Dr,
			seekTo: Or,
			toggleStretch: kr,
			postCastRequestToWebView: Ar,
			onCastRequested: jr,
			onCastFeedbackClosed: Mr,
			attachRemotePlayback: Nr,
			detachRemotePlayback: Pr,
			showControls: X,
			startControlPanelHideTimer: Z,
			onControlPanelEntered: Fr,
			onControlPanelExited: Ir,
			onControlPanelPressed: Lr,
			onControlPanelReleased: Rr,
			onControlPanelCaptureLost: zr,
			onControlPanelFocusEntered: Br,
			onControlPanelFocusExited: Vr,
			onRootPressed: Hr,
			onRootReleased: Ur,
			onRootCaptureLost: Wr,
			onRootExited: Gr,
			onEnded: Kr,
			formatTime: qr,
			get sourceVersion() {
				return Q;
			},
			set sourceVersion(e) {
				Q = e;
			},
			get decodedObjectUrl() {
				return $;
			},
			set decodedObjectUrl(e) {
				$ = e;
			},
			applySource: Jr,
			get loadedElement() {
				return Yr;
			},
			set loadedElement(e) {
				Yr = e;
			},
			notifyLoaded: Xr,
			AppBarButton: ne,
			Border: se,
			Grid: ee,
			ColumnDefinition: le,
			RowDefinition: ue,
			StackPanel: de,
			TextBlock: ie,
			FontIcon: ae,
			SymbolIcon: te,
			AppBarToggleButton: oe,
			RadioButton: fe,
			Flyout: ce,
			ProgressBar: pe,
			Slider: me
		};
		return Object.defineProperty(Zr, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), Zr;
	}
});
//#endregion
export { De as MediaPlayerTransportControlsProperty, Oe as default };

//# sourceMappingURL=MediaPlayerElement.vue_vue_type_script_setup_true_lang.js.map