import { alignment as e, cssLength as t, xamlThickness as n } from "./layout.js";
import { normalizeXamlNodes as r, resolveXamlValue as i } from "./xamlRuntime.js";
import { RichTextBlockBlocks as a, RichTextBlockTextHighlighters as o, createTextHighlights as s, readTextHighlighters as c, restoreInlineInteractions as ee, textBrush as l, textContentNodes as u, textFontWeight as d, textPosition as f } from "./TextInline.js";
import { useI18n as p } from "./i18n/index.js";
import { textCommandFlyout as te } from "./textCommandFlyout.js";
import { Fragment as ne, computed as m, defineComponent as re, getCurrentInstance as ie, h as ae, nextTick as oe, onBeforeUnmount as se, onMounted as ce, onUpdated as le, reactive as ue, ref as h, useAttrs as de, useSlots as fe, watch as g } from "vue";
var _ = /*@__PURE__*/ re({
	Blocks: a,
	TextHighlighters: o,
	inheritAttrs: !1,
	__name: "RichTextBlock",
	props: {
		OverflowContentTarget: {
			type: [String, Object],
			default: null
		},
		FontFamily: {
			type: String,
			default: ""
		},
		FontSize: {
			type: [String, Number],
			default: 14
		},
		FontStyle: {
			type: String,
			default: ""
		},
		FontWeight: {
			type: [String, Number],
			default: ""
		},
		FontStretch: {
			type: String,
			default: ""
		},
		Foreground: {
			type: [String, Object],
			default: "{ThemeResource TextFillColorPrimaryBrush}"
		},
		IsTextSelectionEnabled: {
			type: [Boolean, String],
			default: !0
		},
		SelectionHighlightColor: {
			type: [String, Object],
			default: "Highlight"
		},
		TextAlignment: {
			type: String,
			default: "Left"
		},
		HorizontalTextAlignment: {
			type: String,
			default: ""
		},
		CharacterSpacing: {
			type: [String, Number],
			default: 0
		},
		LineHeight: {
			type: [String, Number],
			default: 0
		},
		LineStackingStrategy: {
			type: String,
			default: "MaxHeight"
		},
		TextIndent: {
			type: [String, Number],
			default: 0
		},
		TextLineBounds: {
			type: String,
			default: "Full"
		},
		OpticalMarginAlignment: {
			type: String,
			default: "None"
		},
		IsColorFontEnabled: {
			type: [Boolean, String],
			default: !0
		},
		IsTextScaleFactorEnabled: {
			type: [Boolean, String],
			default: !0
		},
		TextReadingOrder: {
			type: String,
			default: "Default"
		},
		FlowDirection: {
			type: String,
			default: "LeftToRight"
		},
		TextDecorations: {
			type: String,
			default: "None"
		},
		SelectionFlyout: {
			type: [String, Object],
			default: null
		},
		TextWrapping: {
			type: String,
			default: "Wrap"
		},
		TextTrimming: {
			type: String,
			default: "None"
		},
		MaxLines: {
			type: [String, Number],
			default: 0
		},
		Width: {
			type: [String, Number],
			default: ""
		},
		Height: {
			type: [String, Number],
			default: ""
		},
		Margin: {
			type: [String, Number],
			default: ""
		},
		Padding: {
			type: [String, Number],
			default: ""
		},
		MinWidth: {
			type: [String, Number],
			default: 0
		},
		MinHeight: {
			type: [String, Number],
			default: 0
		},
		MaxWidth: {
			type: [String, Number],
			default: ""
		},
		MaxHeight: {
			type: [String, Number],
			default: ""
		},
		HorizontalAlignment: {
			type: String,
			default: "Stretch"
		},
		VerticalAlignment: {
			type: String,
			default: "Stretch"
		},
		Visibility: {
			type: String,
			default: "Visible"
		},
		Opacity: {
			type: [String, Number],
			default: 1
		}
	},
	emits: [
		"SelectionChanged",
		"ContextMenuOpening",
		"IsTextTrimmedChanged"
	],
	setup(a, { expose: o, emit: _ }) {
		let v = _, { t: y } = p(), pe = a, b = ie(), x = fe(), S = de(), C = h(null), w = h(null), T = h(null), E = (e) => i(pe[e], b), D = m(() => E("IsTextSelectionEnabled") === !0), me = m(() => ({
			...Object.fromEntries(Object.entries(S).filter(([e]) => e !== "style" && e !== "AutomationProperties.Name")),
			"aria-label": String(i(S["AutomationProperties.Name"], b) ?? "")
		})), O = m(() => !!E("OverflowContentTarget")), he = re({ setup: () => () => ae(ne, r(u(x.default?.() ?? [], "Blocks"), b)) }), ge = m(() => ({
			fontFamily: E("FontFamily") === "XamlAutoFontFamily" ? "var(--ContentControlThemeFontFamily)" : E("FontFamily"),
			fontSize: t(E("FontSize")),
			fontStyle: String(E("FontStyle")).toLowerCase(),
			fontWeight: d(E("FontWeight")),
			fontStretch: String(E("FontStretch")).replace(/([a-z])([A-Z])/g, "$1-$2").toLowerCase(),
			color: l(E("Foreground")),
			textAlign: String(E("HorizontalTextAlignment") || E("TextAlignment")).toLowerCase(),
			lineHeight: Number(E("LineHeight")) > 0 ? t(E("LineHeight")) : E("TextLineBounds") === "Tight" ? "1" : Number(E("FontSize")) === 14 ? "20px" : "normal",
			letterSpacing: `${Number(E("CharacterSpacing")) / 1e3}em`,
			textIndent: t(E("TextIndent")),
			direction: E("FlowDirection") === "RightToLeft" ? "rtl" : "ltr",
			unicodeBidi: E("TextReadingOrder") === "DetectFromContent" ? "plaintext" : "normal",
			textDecorationLine: String(E("TextDecorations")).replace("Strikethrough", "line-through").toLowerCase(),
			whiteSpace: E("TextWrapping") === "NoWrap" ? "nowrap" : "normal",
			overflowWrap: E("TextWrapping") === "Wrap" ? "anywhere" : "normal",
			width: t(E("Width")),
			height: t(E("Height")),
			margin: n(E("Margin")),
			padding: n(E("Padding")),
			minWidth: t(E("MinWidth")),
			minHeight: t(E("MinHeight")),
			maxWidth: t(E("MaxWidth")),
			maxHeight: t(E("MaxHeight")),
			opacity: E("Opacity"),
			justifySelf: e(E("HorizontalAlignment"), "horizontal"),
			alignSelf: e(E("VerticalAlignment"), "vertical"),
			userSelect: D.value ? "text" : "none",
			WebkitUserSelect: D.value ? "text" : "none",
			"--rich-text-selection": l(E("SelectionHighlightColor")),
			...E("IsTextScaleFactorEnabled") === !1 ? {
				textSizeAdjust: "none",
				WebkitTextSizeAdjust: "none"
			} : {},
			...O.value || E("TextTrimming") !== "None" ? {
				overflow: "hidden",
				textOverflow: E("TextTrimming") === "Clip" ? "clip" : "ellipsis"
			} : {},
			...Number(E("MaxLines")) > 0 ? {
				display: "-webkit-box",
				WebkitLineClamp: String(E("MaxLines")),
				WebkitBoxOrient: "vertical",
				overflow: "hidden"
			} : {},
			...E("Visibility") === "Collapsed" ? { display: "none" } : {}
		})), k = ue([]), A = s(`win-rich-text-${b?.uid}`), j = [], M, N = 0, P = "", F = !0, I = /* @__PURE__ */ new Set(), L = /* @__PURE__ */ new Set(), R = h(!1), z = h(!1), B = h(""), _e = {
			Add: (e) => k.push(e),
			Clear: () => k.splice(0),
			Remove: (e) => {
				let t = k.indexOf(e);
				t >= 0 && k.splice(t, 1);
			},
			RemoveAt: (e) => k.splice(e, 1),
			GetAt: (e) => k[e],
			get Count() {
				return k.length;
			}
		}, V = () => {
			let e = window.getSelection();
			if (!e || !e.rangeCount || !D.value) return "";
			let t = e.getRangeAt(0), n = (e) => j.some((t) => t.Element.contains(e));
			return n(t.startContainer) && n(t.endContainer) ? e.toString() : "";
		}, H = () => {
			let e = V();
			B.value !== e && (B.value = e, v("SelectionChanged", J, {
				OriginalSource: C.value,
				Handled: !1
			}));
		}, U = () => {
			if (!D.value || !j.length) return;
			let e = document.createRange();
			e.setStart(j[0].Element, 0);
			let t = j.at(-1).Element;
			e.setEnd(t, t.childNodes.length);
			let n = window.getSelection();
			n?.removeAllRanges(), n?.addRange(e), H();
		}, ve = (e, t) => {
			if (!D.value || !j.length) return;
			let n = (e) => {
				let t = [...j].reverse().find((t) => t.Start <= e) ?? j[0];
				return f(t.Element, e - t.Start);
			}, r = document.createRange();
			r.setStart(...n(e.Offset)), r.setEnd(...n(t.Offset));
			let i = window.getSelection();
			i?.removeAllRanges(), i?.addRange(r), H();
		}, W = () => {
			let e = V();
			e && navigator.clipboard?.writeText(e);
		}, G = (e) => {
			let t = V();
			t && (e.clipboardData?.setData("text/plain", t), e.preventDefault());
		}, K = h(null), ye = m(() => [...B.value ? [{
			Text: y("text.copy"),
			Icon: "Copy",
			Value: "copy"
		}] : [], {
			Text: y("text.select-all"),
			Icon: "SelectAll",
			Value: "selectAll"
		}]), be = te(K, () => ye.value, (e) => {
			e.Value === "copy" && W(), e.Value === "selectAll" && U(), K.value?.Hide?.();
		}, () => {}), q = (e) => {
			if (!D.value) return;
			H();
			let t = {
				OriginalSource: e.target,
				CursorLeft: e.clientX,
				CursorTop: e.clientY,
				Handled: !1
			};
			if (v("ContextMenuOpening", J, t), t.Handled) {
				e.preventDefault();
				return;
			}
			e.preventDefault();
			let n = e.currentTarget, r = {
				X: e.clientX - n.getBoundingClientRect().left,
				Y: e.clientY - n.getBoundingClientRect().top
			}, i = E("SelectionFlyout");
			(i?.ShowAt ? i : K.value)?.ShowAt?.(n, { Position: r });
		}, J = {
			Element: C,
			TextHighlighters: _e,
			get HasOverflowContent() {
				return R.value;
			},
			get IsTextTrimmed() {
				return z.value;
			},
			get SelectedText() {
				return B.value;
			},
			get ContentStart() {
				return { Offset: 0 };
			},
			get ContentEnd() {
				return { Offset: w.value?.textContent?.length ?? 0 };
			},
			SelectAll: U,
			Select: ve,
			CopySelectionToClipboard: W
		};
		o(J);
		let Y = (e) => {
			z.value !== e && (z.value = e, v("IsTextTrimmedChanged", J, { IsTextTrimmed: e }));
		}, X = (e) => {
			I.forEach((t) => {
				e.includes(t) || (M?.unobserve(t), I.delete(t));
			}), e.forEach((e) => {
				I.has(e) || (M?.observe(e), I.add(e));
			});
		}, Z = (e) => {
			e.replaceChildren(), e.removeEventListener("contextmenu", q), e.removeEventListener("copy", G);
		}, xe = () => {
			if (!w.value || !C.value) return;
			if (!O.value || !T.value) {
				L.forEach(Z), L.clear(), X([C.value]), j.splice(0, j.length, {
					Element: w.value,
					Start: 0
				}), R.value = !1, Y(E("TextTrimming") !== "None" && (C.value.scrollHeight > C.value.clientHeight || C.value.scrollWidth > C.value.clientWidth)), P = "";
				return;
			}
			let e = [T.value], t = [C.value], n = E("OverflowContentTarget"), r = /* @__PURE__ */ new Set();
			for (; n && !r.has(n);) r.add(n), n.Element instanceof HTMLElement && (e.push(n.Element), t.push(n.Element)), n = n.OverflowContentTarget;
			L.forEach((t) => {
				e.includes(t) || Z(t);
			}), L.clear(), e.slice(1).forEach((e) => {
				L.add(e), e.removeEventListener("contextmenu", q), e.addEventListener("contextmenu", q), e.removeEventListener("copy", G), e.addEventListener("copy", G);
			}), X(t);
			let i = getComputedStyle(C.value), a = [
				"font-family",
				"font-size",
				"font-weight",
				"font-style",
				"font-stretch",
				"line-height",
				"letter-spacing",
				"color",
				"text-align",
				"text-indent",
				"white-space",
				"overflow-wrap",
				"direction",
				"user-select",
				"--rich-text-selection"
			];
			e.forEach((e) => a.forEach((t) => e.style.setProperty(t, i.getPropertyValue(t))));
			let o = w.value.innerHTML + t.map((e) => `${e.clientWidth}:${e.clientHeight}`).join("|") + a.map((e) => i.getPropertyValue(e)).join("|");
			if (o === P) return;
			P = o;
			let s = document.createElement("div");
			Object.assign(s.style, {
				position: "fixed",
				visibility: "hidden",
				pointerEvents: "none",
				left: "0",
				top: "0"
			}), a.forEach((e) => s.style.setProperty(e, i.getPropertyValue(e))), s.className = "win-rich-text-block", document.body.append(s);
			let c = w.value.textContent?.length ?? 0, l = 0;
			j.splice(0), e.forEach((e, n) => {
				let r = t[n], i = getComputedStyle(r), a = Math.max(0, r.clientWidth - parseFloat(i.paddingLeft || "0") - parseFloat(i.paddingRight || "0")), o = Math.max(0, r.clientHeight - parseFloat(i.paddingTop || "0") - parseFloat(i.paddingBottom || "0"));
				s.style.width = `${a}px`;
				let u = l, d = c, p = (e) => {
					let t = document.createRange();
					t.setStart(...f(w.value, l)), t.setEnd(...f(w.value, e));
					let n = t.cloneContents();
					return n.querySelectorAll("p").forEach((e) => {
						!e.textContent && !e.querySelector("img,br,.win-inline-ui-container") && e.remove();
					}), n;
				};
				for (; u < d && a > 0 && o > 0;) {
					let e = Math.ceil((u + d) / 2);
					s.replaceChildren(p(e)), s.scrollHeight <= o ? u = e : d = e - 1;
				}
				if (u < c && u > l) {
					let e = w.value.textContent ?? "", t = u;
					for (; t > l && !/\s/.test(e[t] ?? "");) t--;
					t > l && (u = t + 1);
				}
				u > l && /[\uD800-\uDBFF]/.test(w.value.textContent?.[u - 1] ?? "") && u--, e.replaceChildren(p(u)), ee(e), j.push({
					Element: e,
					Start: l
				}), n === 0 && (R.value = u < c), l = u;
			}), Y(l < c && E("TextTrimming") !== "None"), s.remove();
		}, Q = () => {
			F && (cancelAnimationFrame(N), N = requestAnimationFrame(() => {
				xe(), A.Update(j, [...c(x.default?.() ?? [], b), ...k]);
			}));
		};
		ce(async () => {
			await oe(), M = new ResizeObserver(Q), C.value && X([C.value]), Q(), document.fonts.ready.then(Q), document.addEventListener("selectionchange", H);
		}), le(Q), g(k, Q, { deep: !0 }), g(() => {
			let e = [], t = /* @__PURE__ */ new Set(), n = E("OverflowContentTarget");
			for (; n && !t.has(n);) t.add(n), e.push(n), n = n.OverflowContentTarget;
			return e;
		}, () => {
			P = "", Q();
		}, { flush: "post" }), g(D, (e) => {
			e || (B.value && window.getSelection()?.removeAllRanges(), B.value = "", K.value?.Hide?.());
		}), se(() => {
			F = !1, M?.disconnect(), cancelAnimationFrame(N), document.removeEventListener("selectionchange", H), L.forEach(Z), A.Clear();
		});
		let $ = {
			emit: v,
			t: y,
			props: pe,
			instance: b,
			slots: x,
			attrs: S,
			element: C,
			source: w,
			flow: T,
			resolve: E,
			selectionEnabled: D,
			forwardedAttrs: me,
			hasOverflow: O,
			ContentOutlet: he,
			style: ge,
			highlighters: k,
			highlights: A,
			visibleRoots: j,
			get observer() {
				return M;
			},
			set observer(e) {
				M = e;
			},
			get frame() {
				return N;
			},
			set frame(e) {
				N = e;
			},
			get lastSignature() {
				return P;
			},
			set lastSignature(e) {
				P = e;
			},
			get active() {
				return F;
			},
			set active(e) {
				F = e;
			},
			observed: I,
			overflowHosts: L,
			hasOverflowContent: R,
			isTextTrimmed: z,
			selectedText: B,
			textHighlighterCollection: _e,
			selectionText: V,
			selectionChanged: H,
			selectAll: U,
			select: ve,
			copySelection: W,
			onCopy: G,
			contextMenuRef: K,
			contextMenuItems: ye,
			ContextMenu: be,
			onContextMenu: q,
			api: J,
			setTrimmed: Y,
			updateObserved: X,
			clearOverflowHost: Z,
			layoutOverflow: xe,
			schedule: Q
		};
		return Object.defineProperty($, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), $;
	}
});
//#endregion
export { _ as default };

//# sourceMappingURL=RichTextBlock.vue_vue_type_script_setup_true_lang.js.map