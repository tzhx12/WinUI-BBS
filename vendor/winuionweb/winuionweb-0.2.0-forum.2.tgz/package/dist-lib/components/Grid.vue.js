import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./Grid.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                         */
import { createElementBlock as n, createVNode as r, normalizeStyle as i, openBlock as a, withDirectives as o } from "vue";
//#region src/components/Grid.vue
var s = ["data-horizontal-alignment"];
function c(e, t, c, l, u, d) {
	return o((a(), n("div", {
		ref: "root",
		class: "win-grid",
		"data-horizontal-alignment": l.resolveProp(l.props.HorizontalAlignment) || void 0,
		style: i(l.resolveRootStyle()),
		onContextmenu: l.onContextMenu
	}, [r(l.ChildrenOutlet), r(l.ContextFlyoutOutlet)], 44, s)), [
		[l.vAcrylicBrush, l.resolveRootStyle()],
		[l.vRadialGradientBrush, l.backgroundBrush.value.value],
		[l.vThemeShadow, {
			Shadow: l.Shadow,
			Translation: l.Translation
		}]
	]);
}
var l = /*#__PURE__*/ e(t, [
	["render", c],
	["__scopeId", "data-v-8f142460"],
	["__file", "Grid.vue"]
]);
//#endregion
export { l as default };

//# sourceMappingURL=Grid.vue.js.map