import { boolValue as e } from "./layout.js";
import { resolveXamlHandler as t, resolveXamlValue as n, updateXamlBinding as r, xamlScopeKey as i } from "./xamlRuntime.js";
import { useUICommand as a } from "./uiCommandRuntime.js";
import { buttonContentProperty as o, useButtonContent as s } from "./buttonContentRuntime.js";
import c from "./Button.vue.js";
import { computed as l, defineComponent as u, getCurrentInstance as d, inject as f, provide as p, proxyRefs as m, ref as h, useAttrs as g, useSlots as _, watch as v } from "vue";
//#region src/components/ToggleButton.vue?vue&type=script&setup=true&lang.ts
var y = u({
	name: "ToggleButton.Content",
	__buttonProperty: "content",
	setup() {
		return () => null;
	}
}), b = /*@__PURE__*/ u({
	Content: y,
	ContentTemplate: o("ToggleButton", "ContentTemplate"),
	ContentTransitions: o("ToggleButton", "ContentTransitions"),
	Resources: o("ToggleButton", "Resources"),
	name: "ToggleButton",
	inheritAttrs: !1,
	__name: "ToggleButton",
	props: {
		Content: {
			type: null,
			default: ""
		},
		ContentTemplate: {
			type: null,
			default: void 0
		},
		ContentTransitions: {
			type: null,
			default: void 0
		},
		IsChecked: {
			type: [Boolean, String],
			default: !1
		},
		IsThreeState: {
			type: [Boolean, String],
			default: !1
		},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		RequestedTheme: {
			type: String,
			default: "Default"
		}
	},
	emits: [
		"Click",
		"Checked",
		"Unchecked",
		"Indeterminate"
	],
	setup(o, { expose: u, emit: b }) {
		let x = o, S = b, C = g(), w = _(), T = d(), E = h(null), D = (e) => n(e, T), { ContentTemplate: O, ContentTransitions: k } = s(x, () => w.default?.() ?? [], T), A = a(() => D(C.Command)), j = l(() => D(C.CommandParameter)), M = l(() => D(x.Content)), N = l(() => String(D(x.RequestedTheme))), P = h();
		v(N, () => {
			P.value = void 0;
		});
		let F = l({
			get: () => P.value ?? N.value,
			set: (e) => {
				P.value = e, r(x.RequestedTheme, e, T);
			}
		}), I = (t) => t === null || t === "{x:Null}" ? null : e(t), L = l(() => I(D(x.IsChecked))), R = h(), z = l({
			get: () => R.value === void 0 ? L.value : R.value,
			set: (e) => J(I(e))
		}), B = l(() => e(D(x.IsEnabled))), V = h(), H = l({
			get: () => (V.value ?? B.value) && (A.value?.CanExecute?.(j.value) ?? !0),
			set: (t) => {
				V.value = e(t), r(x.IsEnabled, V.value, T);
			}
		}), U = l(() => e(D(x.IsThreeState))), W = l(() => Object.fromEntries(Object.entries(C).filter(([e]) => ![
			"Click",
			"onClick",
			"Checked",
			"onChecked",
			"Unchecked",
			"onUnchecked",
			"Indeterminate",
			"onIndeterminate"
		].includes(e)))), G = l(() => !!w.default), K = m({
			IsChecked: z,
			IsEnabled: H,
			IsThreeState: U,
			RequestedTheme: F,
			Command: A,
			CommandParameter: j,
			ContentTemplate: O,
			ContentTransitions: k,
			Name: l(() => C["data-xaml-ref"] ?? C["x:Name"] ?? C.Name ?? ""),
			Content: l({
				get: () => E.value?.Content ?? M.value,
				set: (e) => {
					E.value && (E.value.Content = e), r(x.Content, e, T);
				}
			}),
			Element: l(() => E.value?.Element),
			IsPressed: l(() => E.value?.IsPressed ?? !1),
			Focus: () => E.value?.Focus?.()
		});
		u(K);
		function q(e, n) {
			let r = {
				OriginalSource: K,
				OriginalEvent: n,
				Handled: !1
			};
			S(e, K, r), t(C[e], T)?.(K, r);
		}
		function J(e, t) {
			e !== z.value && (R.value = e, r(x.IsChecked, e, T), q(e === !0 ? "Checked" : e === !1 ? "Unchecked" : "Indeterminate", t));
		}
		function Y(e, t) {
			H.value && (J(z.value === !0 ? U.value ? null : !1 : z.value === !1, t?.OriginalEvent), q("Click", t?.OriginalEvent));
		}
		v(L, (e, t) => {
			let n = R.value !== void 0 && R.value === e;
			R.value = void 0, !n && e !== t && q(e === !0 ? "Checked" : e === !1 ? "Unchecked" : "Indeterminate");
		}), v(B, () => {
			V.value = void 0;
		}), p(i, {
			...f(i, {}),
			Content: M,
			ContentTemplate: O,
			ContentTransitions: k,
			IsEnabled: H,
			RequestedTheme: F,
			OnButtonClick: Y
		});
		let X = {
			ToggleButtonContent: y,
			props: x,
			emit: S,
			attrs: C,
			slots: w,
			instance: T,
			button: E,
			resolve: D,
			ContentTemplate: O,
			ContentTransitions: k,
			Command: A,
			CommandParameter: j,
			Content: M,
			sourceRequestedTheme: N,
			localRequestedTheme: P,
			RequestedTheme: F,
			checkedValue: I,
			sourceChecked: L,
			localChecked: R,
			IsChecked: z,
			sourceIsEnabled: B,
			localIsEnabled: V,
			IsEnabled: H,
			IsThreeState: U,
			buttonAttrs: W,
			hasContent: G,
			api: K,
			raise: q,
			setChecked: J,
			onClick: Y,
			Button: c
		};
		return Object.defineProperty(X, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), X;
	}
});
//#endregion
export { y as ToggleButtonContent, b as default };

//# sourceMappingURL=ToggleButton.vue_vue_type_script_setup_true_lang.js.map