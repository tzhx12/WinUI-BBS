import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./CalendarDatePicker.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                                       */
/* empty css                                                       */
import { createBlock as n, createCommentVNode as r, createElementBlock as i, createElementVNode as a, createVNode as o, mergeProps as s, openBlock as c, withCtx as l } from "vue";
//#region src/components/CalendarDatePicker.vue
var u = {
	ref: "buttonRef",
	class: "picker-hit-target",
	type: "button",
	"Grid.Row": "1",
	"Grid.Column": "1",
	"Grid.ColumnSpan": "2"
};
function d(e, t, d, f, p, m) {
	return c(), i("div", s({
		ref: "rootRef",
		class: "win-calendar-date-picker"
	}, f.rootAttrs, {
		class: [f.rootClasses, f.attrs.class],
		style: f.rootStyle
	}), [o(f.Grid, { class: "calendar-picker-root" }, {
		default: l(() => [
			o(f.Grid.RowDefinitions, null, {
				default: l(() => [
					o(f.RowDefinition, { Height: "Auto" }),
					o(f.RowDefinition, { Height: "*" }),
					o(f.RowDefinition, { Height: "Auto" })
				]),
				_: 1
			}),
			o(f.Grid.ColumnDefinitions, null, {
				default: l(() => [
					o(f.ColumnDefinition, { Width: "Auto" }),
					o(f.ColumnDefinition, { Width: "*" }),
					o(f.ColumnDefinition, {
						Width: "32",
						MaxWidth: "32"
					})
				]),
				_: 1
			}),
			f.hasHeader ? (c(), n(f.ContentPresenter, {
				key: 0,
				class: "picker-header",
				"Grid.Row": "0",
				"Grid.Column": "1",
				"Grid.ColumnSpan": "2"
			}, {
				default: l(() => [o(f.HeaderContent)]),
				_: 1
			})) : r("", !0),
			o(f.Border, {
				class: "picker-background",
				"Grid.Row": "1",
				"Grid.Column": "1",
				"Grid.ColumnSpan": "2",
				MinHeight: "32"
			}),
			o(f.TextBlock, {
				class: "picker-date-text",
				"Grid.Row": "1",
				"Grid.Column": "1",
				Text: "{x:Bind PickerText}",
				Padding: "12,0,0,2",
				VerticalAlignment: "Center"
			}),
			o(f.FontIcon, {
				class: "picker-calendar-glyph",
				"Grid.Row": "1",
				"Grid.Column": "2",
				Glyph: "",
				FontSize: "12"
			}),
			a("button", u, null, 512),
			f.hasDescription ? (c(), n(f.ContentPresenter, {
				key: 1,
				class: "picker-description",
				"Grid.Row": "2",
				"Grid.Column": "1",
				"Grid.ColumnSpan": "2"
			}, {
				default: l(() => [o(f.DescriptionContent)]),
				_: 1
			})) : r("", !0),
			o(f.Flyout, {
				Placement: "Bottom",
				ShouldConstrainToRootBounds: "False"
			}, {
				default: l(() => [o(f.CalendarView, {
					ref: "calendarRef",
					Style: "{x:Bind PickerCalendarViewStyle}",
					CalendarIdentifier: "{x:Bind PickerCalendarIdentifier}",
					DayOfWeekFormat: "{x:Bind PickerDayOfWeekFormat}",
					DisplayMode: "{x:Bind PickerDisplayMode}",
					FirstDayOfWeek: "{x:Bind PickerFirstDayOfWeek}",
					IsEnabled: "{x:Bind PickerEnabled}",
					IsGroupLabelVisible: "{x:Bind PickerGroupLabelVisible}",
					IsOutOfScopeEnabled: "{x:Bind PickerOutOfScopeEnabled}",
					IsTodayHighlighted: "{x:Bind PickerTodayHighlighted}",
					MinDate: "{x:Bind PickerMinDate}",
					MaxDate: "{x:Bind PickerMaxDate}",
					SelectedDates: "{x:Bind PickerSelectedDates}",
					Language: "{x:Bind PickerLanguage}",
					SelectionMode: "Single",
					CornerRadius: "{ThemeResource OverlayCornerRadius}",
					SelectedDatesChanged: "OnSelectedDatesChanged",
					CalendarViewDayItemChanging: "OnCalendarViewDayItemChanging"
				}, null, 512)]),
				_: 1
			})
		]),
		_: 1
	})], 16);
}
var f = /*#__PURE__*/ e(t, [
	["render", d],
	["__scopeId", "data-v-662ddfee"],
	["__file", "CalendarDatePicker.vue"]
]);
//#endregion
export { f as default };

//# sourceMappingURL=CalendarDatePicker.vue.js.map