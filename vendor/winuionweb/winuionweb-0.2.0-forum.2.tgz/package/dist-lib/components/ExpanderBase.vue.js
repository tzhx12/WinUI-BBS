import { cssColor as e, isSolidColorBrush as t } from "./brushCore.js";
import { resolveBrushStyle as n } from "./AcrylicBrush.js";
import { resolveXamlValue as r, updateXamlBinding as i } from "./xamlRuntime.js";
import a from "../_virtual/_plugin-vue_export-helper.js";
import o from "./TextBlock.vue.js";
import s from "./AnimatedIcon.vue.js";
import { useAnimatedIconInput as c } from "./animatedIconInput.js";
/* empty css                                                                 */
import { Fragment as ee, computed as l, createBlock as u, createCommentVNode as d, createElementBlock as f, createElementVNode as p, createTextVNode as m, createVNode as h, getCurrentInstance as g, nextTick as _, normalizeClass as v, normalizeStyle as y, onBeforeUnmount as b, onMounted as te, openBlock as x, ref as S, renderSlot as C, resolveComponent as w, toDisplayString as T, useSlots as E, watch as D, withCtx as O } from "vue";
//#region src/components/ExpanderBase.vue
var k = {
	__name: "ExpanderBase",
	props: {
		Header: {
			type: [String, Number],
			default: ""
		},
		Content: {
			type: [String, Number],
			default: ""
		},
		Description: {
			type: [String, Number],
			default: ""
		},
		HeaderIcon: {
			type: String,
			default: ""
		},
		HeaderTemplate: {
			type: [
				Object,
				Function,
				String
			],
			default: null
		},
		HeaderTemplateSelector: {
			type: [
				Object,
				Function,
				String
			],
			default: null
		},
		IsExpanded: {
			type: [Boolean, String],
			default: !1
		},
		ExpandDirection: {
			type: [String, Number],
			default: "Down"
		},
		Padding: {
			type: [String, Number],
			default: "16"
		},
		Background: {
			type: [String, Object],
			default: "{ThemeResource ExpanderContentBackground}"
		},
		BorderBrush: {
			type: [String, Object],
			default: "{ThemeResource ExpanderContentBorderBrush}"
		},
		BorderThickness: {
			type: [String, Number],
			default: ""
		},
		CornerRadius: {
			type: [String, Number],
			default: "{ThemeResource ControlCornerRadius}"
		},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		HorizontalContentAlignment: {
			type: String,
			default: "Stretch"
		},
		VerticalContentAlignment: {
			type: String,
			default: "Stretch"
		},
		Width: {
			type: [String, Number],
			default: ""
		},
		MinWidth: {
			type: [String, Number],
			default: ""
		},
		Height: {
			type: [String, Number],
			default: ""
		},
		MaxWidth: {
			type: [String, Number],
			default: ""
		},
		HorizontalAlignment: {
			type: String,
			default: ""
		},
		VerticalAlignment: {
			type: String,
			default: ""
		}
	},
	emits: [
		"update:IsExpanded",
		"Expanding",
		"Collapsed"
	],
	setup(a, { expose: ee, emit: u }) {
		let d = a, f = u, p = E(), m = g(), h = (e) => e === !0 || String(e).toLowerCase() === "true", v = l(() => h(r(d.IsExpanded, m))), y = l(() => h(r(d.IsEnabled, m))), x = l(() => r(d.ExpandDirection, m) || "Down"), C = l(() => r(d.Padding, m)), w = l(() => r(d.HorizontalContentAlignment, m)), T = l(() => r(d.VerticalContentAlignment, m)), O = S(v.value), k = S(O.value), A = S(null), j, M, N = 0, P = async (e) => {
			let t = ++N;
			clearTimeout(M);
			let n = A.value && k.value ? getComputedStyle(A.value).transform : null;
			if (j?.cancel(), k.value = !0, await _(), t !== N || !A.value) return;
			let r = A.value, i = `translateY(${r.getBoundingClientRect().height * (x.value === "Up" ? 1 : -1)}px)`, a = n && n !== "none" ? n : e ? i : "translateY(0px)", o = e ? 333 : 167;
			j = r.animate([{ transform: a }, { transform: e ? "translateY(0px)" : i }], {
				duration: o,
				easing: e ? "cubic-bezier(0, 0, 0, 1)" : "cubic-bezier(1, 1, 0, 1)",
				fill: "forwards"
			}), e ? j.onfinish = () => {
				t === N && j?.cancel();
			} : M = setTimeout(() => {
				t === N && (k.value = !1, j?.cancel());
			}, x.value === "Up" ? 200 : 167);
		};
		b(() => {
			N += 1, clearTimeout(M), j?.cancel();
		});
		let F = S(null), I = c(!1, (e) => {
			let t = O.value !== (x.value === "Up");
			return `${e === "Disabled" ? "Normal" : e}${t ? "On" : "Off"}`;
		});
		te(() => I.Attach(F.value)), D([
			O,
			x,
			y
		], I.Refresh, { flush: "post" }), D(y, (e) => {
			e || I.Reset();
		});
		let L = l(() => r(d.Header, m)), ne = l(() => r(d.Content, m)), R = l(() => r(d.Description, m)), z = l(() => r(d.HeaderIcon, m)), B = l(() => !!z.value || !!p.HeaderIcon), V = l(() => !!p.HeaderControls), re = l(() => !!L.value || !!R.value || B.value || !!p.Header || !!p.Description || V.value), ie = l(() => String(z.value || "").trim().startsWith("<")), H = (e) => e === "" || e == null ? "" : typeof e == "string" && e.trim() !== "" && !Number.isNaN(Number(e.trim())) ? `${Number(e.trim())}px` : typeof e == "number" ? `${e}px` : e, U = (e) => {
			let t = H(e);
			if (!t || t === "auto") return "";
			let n = typeof e == "number" ? e : typeof e == "string" && e.trim() !== "" && !Number.isNaN(Number(e.trim())) ? Number(e.trim()) : null;
			return n === null ? `calc(${t} - 2px)` : `${Math.max(n - 2, 0)}px`;
		}, W = (e) => {
			if (e === "" || e == null) return "";
			let t = String(e).split(",").map((e) => {
				let t = e.trim();
				return H(Number.isNaN(Number(t)) ? t : Number(t));
			});
			return t.length === 1 ? t[0] : t.length === 2 ? `${t[1]} ${t[0]}` : t.length === 4 ? `${t[1]} ${t[2]} ${t[3]} ${t[0]}` : String(e);
		}, G = (e) => ({
			Left: "flex-start",
			Center: "center",
			Right: "flex-end",
			Stretch: "stretch"
		})[e] ?? "stretch", K = (e) => ({
			Top: "flex-start",
			Center: "center",
			Bottom: "flex-end",
			Stretch: "flex-start"
		})[e] ?? "flex-start", q = (e) => ({
			Top: "flex-start",
			Center: "center",
			Bottom: "flex-end",
			Stretch: "stretch"
		})[e] ?? "stretch", J = (e) => ({
			Left: "start",
			Center: "center",
			Right: "end",
			Stretch: "stretch"
		})[e] ?? "stretch", ae = l(() => ({
			...n(d.Background, m),
			borderColor: Y(r(d.BorderBrush, m)),
			...d.BorderThickness === "" ? {} : { borderWidth: W(r(d.BorderThickness, m)) },
			padding: W(C.value),
			alignItems: G(w.value),
			justifyContent: K(T.value)
		})), Y = (n) => t(n) ? `color-mix(in srgb, ${e(n.Color)} ${n.Opacity * 100}%, transparent)` : n == null ? void 0 : e(n), oe = l(() => {
			let e = {}, t = String(r(d.CornerRadius, m) ?? "4").split(",").map((e) => H(e.trim())), n = t.length === 4 ? t : [
				t[0],
				t[0],
				t[0],
				t[0]
			];
			if (e["--win-expander-corner-radius"] = n.join(" "), e["--win-expander-top-corner-radius"] = `${n[0]} ${n[1]} 0 0`, e["--win-expander-bottom-corner-radius"] = `0 0 ${n[2]} ${n[3]}`, d.Height !== "") {
				let t = H(d.Height);
				if (t) {
					e.minHeight = t;
					let n = U(d.Height);
					n && (e["--win-expander-header-height"] = n);
				}
			}
			return d.Width !== "" && (e.width = H(d.Width)), d.MinWidth !== "" && (e.minWidth = H(d.MinWidth)), d.MaxWidth !== "" && (e.maxWidth = H(d.MaxWidth)), d.HorizontalAlignment && (e.justifySelf = J(d.HorizontalAlignment)), d.VerticalAlignment && (e.alignSelf = q(d.VerticalAlignment)), e;
		});
		D(v, (e) => {
			O.value = e;
		}), D(O, (e) => {
			let t = m?.vnode.props?.[e ? "onExpanding" : "onCollapsed"];
			for (let e of Array.isArray(t) ? t : [t]) typeof e == "function" && e(m?.exposeProxy ?? m?.proxy, null);
			P(e);
		}), D(x, () => {
			k.value && P(O.value);
		});
		let X = [
			"button",
			"a[href]",
			"input",
			"select",
			"textarea",
			"summary",
			"[contenteditable=\"\"]",
			"[contenteditable=\"true\"]",
			"[role=\"button\"]",
			"[role=\"checkbox\"]",
			"[role=\"link\"]",
			"[role=\"menuitem\"]",
			"[role=\"menuitemcheckbox\"]",
			"[role=\"menuitemradio\"]",
			"[role=\"option\"]",
			"[role=\"radio\"]",
			"[role=\"switch\"]",
			"[role=\"tab\"]",
			"[role=\"textbox\"]",
			"[tabindex]:not([tabindex=\"-1\"])"
		].join(","), Z = (e) => {
			let t = e.target, n = e.currentTarget;
			if (!t?.closest || !n?.contains) return !1;
			let r = t.closest(X);
			return !!(r && r !== n && n.contains(r));
		}, se = (e) => {
			!y.value || e.defaultPrevented || Z(e) || $();
		}, ce = (e) => {
			!y.value || e.defaultPrevented || Z(e) || (I.KeyDown(e), !(e.repeat || e.key !== "Enter" && e.key !== " ") && (e.preventDefault(), $()));
		}, Q = (e) => {
			let t = h(e);
			t !== O.value && (O.value = t, f("update:IsExpanded", t), i(d.IsExpanded, t, m));
		}, $ = () => {
			y.value && Q(!O.value);
		};
		ee({
			get IsExpanded() {
				return O.value;
			},
			set IsExpanded(e) {
				Q(e);
			}
		});
		let le = {
			props: d,
			emit: f,
			slots: p,
			instance: m,
			xamlBoolean: h,
			resolvedIsExpanded: v,
			isEnabled: y,
			resolvedExpandDirection: x,
			resolvedPadding: C,
			resolvedHorizontalContentAlignment: w,
			resolvedVerticalContentAlignment: T,
			isExpandedState: O,
			contentVisible: k,
			contentRef: A,
			get contentAnimation() {
				return j;
			},
			set contentAnimation(e) {
				j = e;
			},
			get collapseTimer() {
				return M;
			},
			set collapseTimer(e) {
				M = e;
			},
			get transitionVersion() {
				return N;
			},
			set transitionVersion(e) {
				N = e;
			},
			animateContent: P,
			headerRef: F,
			AnimatedGlyphInput: I,
			resolvedHeader: L,
			resolvedContent: ne,
			resolvedDescription: R,
			resolvedHeaderIcon: z,
			hasHeaderIcon: B,
			hasHeaderControls: V,
			hasHeaderContent: re,
			isHeaderIconMarkup: ie,
			cssLength: H,
			expanderHeaderHeight: U,
			xamlThickness: W,
			flexAlignment: G,
			flexDistribution: K,
			selfAlignment: q,
			justifySelfAlignment: J,
			contentStyle: ae,
			brushColor: Y,
			rootStyle: oe,
			interactiveHeaderSelector: X,
			isInteractiveHeaderChild: Z,
			onHeaderClick: se,
			onHeaderKeyDown: ce,
			setIsExpanded: Q,
			toggleExpanded: $,
			computed: l,
			getCurrentInstance: g,
			nextTick: _,
			onBeforeUnmount: b,
			onMounted: te,
			ref: S,
			useSlots: E,
			watch: D,
			AnimatedIcon: s,
			get useAnimatedIconInput() {
				return c;
			},
			TextBlock: o,
			get resolveXamlValue() {
				return r;
			},
			get updateXamlBinding() {
				return i;
			},
			get resolveBrushStyle() {
				return n;
			},
			get cssColor() {
				return e;
			},
			get isSolidColorBrush() {
				return t;
			}
		};
		return Object.defineProperty(le, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), le;
	}
}, A = [
	"aria-expanded",
	"aria-disabled",
	"tabindex"
], j = { class: "win-expander-header-main" }, M = {
	key: 0,
	class: "win-expander-header-icon icon",
	"aria-hidden": "true"
}, N = ["innerHTML"], P = { class: "win-expander-header-content" }, F = {
	key: 0,
	class: "win-expander-header-controls"
}, I = {
	class: "win-expander-chevron",
	"aria-hidden": "true"
}, L = ["aria-hidden", "inert"], ne = { class: "win-expander-inner" };
function R(e, t, n, r, i, a) {
	let o = w("animatedvisuals:AnimatedChevronUpDownSmallVisualSource"), s = w("FontIconSource");
	return x(), f("div", {
		class: v(["win-expander", {
			"is-expanded": r.isExpandedState,
			"is-disabled": !r.isEnabled,
			"expand-up": r.resolvedExpandDirection === "Up",
			"has-header-content": r.hasHeaderContent,
			"has-header-controls": r.hasHeaderControls
		}]),
		style: y(r.rootStyle)
	}, [p("div", {
		ref: "headerRef",
		class: "win-expander-header",
		onClick: r.onHeaderClick,
		onKeydown: r.onHeaderKeyDown,
		onPointerenter: t[0] ||= (...e) => r.AnimatedGlyphInput.PointerEntered && r.AnimatedGlyphInput.PointerEntered(...e),
		onPointerleave: t[1] ||= (...e) => r.AnimatedGlyphInput.PointerExited && r.AnimatedGlyphInput.PointerExited(...e),
		onPointerdown: t[2] ||= (...e) => r.AnimatedGlyphInput.PointerPressed && r.AnimatedGlyphInput.PointerPressed(...e),
		onPointerup: t[3] ||= (...e) => r.AnimatedGlyphInput.PointerReleased && r.AnimatedGlyphInput.PointerReleased(...e),
		onPointercancel: t[4] ||= (...e) => r.AnimatedGlyphInput.PointerExited && r.AnimatedGlyphInput.PointerExited(...e),
		onLostpointercapture: t[5] ||= (...e) => r.AnimatedGlyphInput.PointerReleased && r.AnimatedGlyphInput.PointerReleased(...e),
		onKeyup: t[6] ||= (...e) => r.AnimatedGlyphInput.KeyUp && r.AnimatedGlyphInput.KeyUp(...e),
		onBlur: t[7] ||= (...e) => r.AnimatedGlyphInput.LostFocus && r.AnimatedGlyphInput.LostFocus(...e),
		"aria-expanded": r.isExpandedState,
		"aria-disabled": !r.isEnabled,
		role: "button",
		tabindex: r.isEnabled ? 0 : -1
	}, [
		p("div", j, [r.hasHeaderIcon ? (x(), f("span", M, [C(e.$slots, "HeaderIcon", {}, () => [r.isHeaderIconMarkup ? (x(), f("span", {
			key: 0,
			innerHTML: r.resolvedHeaderIcon
		}, null, 8, N)) : (x(), f(ee, { key: 1 }, [m(T(r.resolvedHeaderIcon), 1)], 64))])])) : d("", !0), p("div", P, [C(e.$slots, "Header", {}, () => [r.resolvedHeader ? (x(), u(r.TextBlock, {
			key: 0,
			class: "win-expander-header-text",
			Text: r.resolvedHeader,
			FontSize: "14",
			LineHeight: "20",
			TextWrapping: "Wrap"
		}, null, 8, ["Text"])) : d("", !0)]), C(e.$slots, "Description", {}, () => [r.resolvedDescription ? (x(), u(r.TextBlock, {
			key: 0,
			class: "win-expander-description",
			Text: r.resolvedDescription,
			FontSize: "var(--SettingsCardDescriptionFontSize, 12px)",
			LineHeight: "16",
			Foreground: "var(--TextFillColorSecondaryBrush, var(--text-secondary))",
			TextWrapping: "Wrap"
		}, null, 8, ["Text"])) : d("", !0)])])]),
		r.hasHeaderControls ? (x(), f("div", F, [C(e.$slots, "HeaderControls")])) : d("", !0),
		p("span", I, [h(r.AnimatedIcon, {
			class: "win-expander-arrow",
			"x:Name": "ExpandCollapseChevron",
			Width: "12",
			Height: "12",
			Foreground: "{ThemeResource ExpanderChevronForeground}",
			HorizontalAlignment: "Center",
			VerticalAlignment: "Center",
			"AutomationProperties.AccessibilityView": "Raw"
		}, {
			default: O(() => [h(r.AnimatedIcon.Source, null, {
				default: O(() => [h(o)]),
				_: 1
			}), h(r.AnimatedIcon.FallbackIconSource, null, {
				default: O(() => [h(s, {
					Glyph: "",
					FontFamily: "{ThemeResource SymbolThemeFontFamily}",
					FontSize: "12",
					IsTextScaleFactorEnabled: "False"
				})]),
				_: 1
			})]),
			_: 1
		})])
	], 40, A), p("div", {
		class: "win-expander-grid",
		style: y({ display: r.contentVisible ? "" : "none" }),
		"aria-hidden": !r.isExpandedState,
		inert: !r.isExpandedState
	}, [p("div", ne, [p("div", {
		ref: "contentRef",
		class: "win-expander-content",
		style: y(r.contentStyle)
	}, [C(e.$slots, "default", {}, () => [m(T(r.resolvedContent), 1)])], 4)])], 12, L)], 6);
}
var z = /*#__PURE__*/ a(k, [
	["render", R],
	["__scopeId", "data-v-beb80a82"],
	["__file", "ExpanderBase.vue"]
]);
//#endregion
export { z as default };

//# sourceMappingURL=ExpanderBase.vue.js.map