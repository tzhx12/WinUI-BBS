import { resolveXamlHandler as e, resolveXamlValue as t } from "./xamlRuntime.js";
import { iconSourceKind as n } from "./IconSource.js";
import { SwipeItemsCollection as r } from "./SwipeItemsCollection.js";
import { Comment as i, Fragment as a, Text as o, defineComponent as s, reactive as c } from "vue";
//#region src/components/SwipeControlProperties.ts
var l = (e, t) => s({
	name: e,
	__swipeProperty: t,
	setup() {
		return () => null;
	}
}), u = l("SwipeItems"), d = l("SwipeItem.IconSource", "IconSource"), f = l("SwipeItem.Background", "Background"), p = l("SwipeItem.Foreground", "Foreground"), m = Object.assign(l("SwipeItem"), {
	IconSource: d,
	Background: f,
	Foreground: p
}), h = l("GradientStop"), g = l("LinearGradientBrush"), _ = (e, n) => {
	let r = t(e, n);
	if (typeof r == "string") return r;
	if (!r || typeof r != "object") return;
	let i = r;
	if (S(i) !== "LinearGradientBrush") return "Color" in r ? String(t(r.Color, n)) : void 0;
	let a = (e, t) => String(i.props?.[e] ?? t).split(",").map(Number), [o, s] = a("StartPoint", "0,0"), [c, l] = a("EndPoint", "1,1"), u = Math.atan2(c - o, s - l) * 180 / Math.PI, d = b(i).filter((e) => S(e) === "GradientStop").map((e) => {
		let r = t(e.props?.Color, n);
		return `${String(r ?? "transparent")} ${Number(e.props?.Offset ?? 0) * 100}%`;
	});
	return d.length ? `linear-gradient(${u}deg, ${d.join(", ")})` : void 0;
}, v = Object.fromEntries([
	"LeftItems",
	"RightItems",
	"TopItems",
	"BottomItems",
	"Content",
	"ContentTemplate"
].map((e) => [e, l(`SwipeControl.${e}`, e)])), y = (e) => e.flatMap((e) => e.type === i || e.type === o && !String(e.children ?? "").trim() ? [] : e.type === a && Array.isArray(e.children) ? y(e.children) : [e]), b = (e) => Array.isArray(e.children) ? y(e.children) : y(e.children?.default?.() ?? []), x = (e) => e.type?.__swipeProperty, S = (e) => {
	let t = e.type;
	return typeof t == "string" ? t : t?.name ?? t?.__name ?? "";
}, C = (r) => {
	let i = /* @__PURE__ */ new Map(), a = /* @__PURE__ */ new Map();
	return (o, s) => {
		let l = i.get(s);
		l || (l = c({}), i.set(s, l));
		let u = o.props ?? {}, d = a.get(s) ?? {}, f = {};
		for (let e of [
			"Text",
			"Background",
			"Foreground",
			"BehaviorOnInvoked",
			"Command",
			"CommandParameter"
		]) {
			let n = t(u[e], r);
			f[e] = n, Object.is(d[e], n) || Object.assign(l, { [e]: n });
		}
		for (let e of ["Background", "Foreground"]) {
			let t = b(o).find((t) => x(t) === e), n = t && b(t)[0];
			if (!n) continue;
			let i = _(n, r);
			f[`${e}Brush`] = i, d[`${e}Brush`] !== i && (l[e] = i);
		}
		u.IconSource !== void 0 && (f.IconSource = t(u.IconSource, r), Object.is(d.IconSource, f.IconSource) || (l.IconSource = f.IconSource));
		let p = b(o).find((e) => x(e) === "IconSource"), m = p && b(p)[0];
		if (m && n(m)) {
			let e = Object.fromEntries(Object.entries(m.props ?? {}).filter(([e]) => !e.startsWith("x:")).map(([e, n]) => [e, t(n, r)]));
			f.IconProperties = JSON.stringify(e), d.IconProperties !== f.IconProperties && (l.IconSource = e);
		}
		return f.Invoked = u.Invoked ?? u.onInvoked, d.Invoked !== f.Invoked && (l.Invoked = e(f.Invoked, r)), a.set(s, f), l;
	};
}, w = /* @__PURE__ */ new WeakMap(), T = (e, n, i, a) => {
	let o = t(e.props?.Mode, i) ?? "Reveal", s = b(e).filter((e) => S(e) === "SwipeItem").map((e, t) => a(e, `${n}:${String(e.key ?? t)}`)), c = w.get(a);
	c || (c = /* @__PURE__ */ new Map(), w.set(a, c));
	let l = c.get(n);
	if (!l) {
		let e = new r();
		return e.Mode = o, e.ReplaceAll(s), l = {
			collection: e,
			mode: o,
			items: s
		}, c.set(n, l), e;
	}
	let u = s.length !== l.items.length || s.some((e, t) => e !== l.items[t]);
	if (o === "Execute" && s.length > 1) throw RangeError("SwipeItems in Execute mode cannot contain more than one SwipeItem.");
	return o !== l.mode && o === "Reveal" && (l.collection.Mode = o), u && l.collection.ReplaceAll(s), o !== l.mode && o === "Execute" && (l.collection.Mode = o), l.mode = o, l.items = s, l.collection;
};
//#endregion
export { h as GradientStop, g as LinearGradientBrush, m as SwipeItem, f as SwipeItemBackground, p as SwipeItemForeground, d as SwipeItemIconSource, u as SwipeItems, C as createSwipeItemReader, T as readSwipeItems, _ as swipeBrush, b as swipeChildren, v as swipeControlProperties, S as swipeNodeName, y as swipeNodes, x as swipeProperty };

//# sourceMappingURL=SwipeControlProperties.js.map