import { materializeXamlVNode as e, normalizeXamlNodes as t, resolveXamlValue as n, updateXamlBinding as r } from "./xamlRuntime.js";
import { frameworkLayoutStyle as i } from "./frameworkLayout.js";
import { getVNodeChildren as ee } from "./CollectionProperties.js";
import { menuBarContextKey as a } from "./menuBarContext.js";
import { cloneVNode as te, computed as o, defineComponent as s, getCurrentInstance as c, h as l, inject as u, isVNode as d, nextTick as f, onBeforeUnmount as ne, onMounted as re, provide as p, ref as m, shallowRef as h, toRaw as g, unref as ie, watch as _ } from "vue";
//#region src/components/MenuBar.vue?vue&type=script&lang.ts
var v = s({
	name: "MenuBar.Items",
	__menuBarProperty: "Items",
	setup: () => () => null
}), y = s({
	name: "MenuBar",
	inheritAttrs: !1,
	props: {
		Items: {
			type: [
				Array,
				Object,
				String
			],
			default: void 0
		},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		Visibility: {
			type: String,
			default: "Visible"
		},
		RequestedTheme: {
			type: String,
			default: "Default"
		}
	},
	emits: [
		"update:Items",
		"update:IsEnabled",
		"update:Visibility"
	],
	setup(s, { attrs: v, slots: y, expose: b, emit: x }) {
		let S = c(), C = u("winuiTheme", ""), w = o(() => String(n(s.RequestedTheme, S)).toLowerCase()), T = o(() => ["light", "dark"].includes(w.value) ? w.value : ie(C));
		p("winuiTheme", T);
		let E = m(null), D = h([]), O = h(null), k = h(null), A = [], j = h(null), M = /* @__PURE__ */ new WeakMap(), N = /* @__PURE__ */ new Map(), P = 0, F = m(), I = m(), L = o(() => F.value ?? ![
			!1,
			"False",
			"false"
		].includes(n(s.IsEnabled, S))), R = o(() => I.value ?? String(n(s.Visibility, S))), z = o(() => R.value !== "Collapsed"), B = !1, V = () => D.value.slice().sort((e, t) => {
			let n = e.element(), r = t.element();
			return n === r ? 0 : n && r && n.compareDocumentPosition(r) & Node.DOCUMENT_POSITION_PRECEDING ? 1 : -1;
		}), H = () => V().filter((e) => L.value && z.value && e.isEnabled() && e.isVisible()), U = () => H().filter((e) => e.isTabStop()), W = (e = !1) => {
			let t = k.value;
			k.value = null, t?.close(e);
		}, G = async (e, t = "first") => {
			!L.value || !z.value || !e.isEnabled() || !e.isVisible() || !e.hasItems() || (k.value && k.value !== e && W(!1), O.value = e, k.value = e, await f(), !B && k.value === e && e.open(t));
		}, K = (e) => {
			O.value = e, e.element()?.focus({ preventScroll: !0 });
		}, q = (e, t, n = !1) => {
			let r = H();
			if (!r.length) return;
			let i = r[(r.indexOf(e) + t + r.length) % r.length];
			K(i), n && (W(!1), G(i));
		};
		p(a, {
			element: () => E.value,
			isEnabled: () => L.value,
			isVisible: () => z.value,
			register(e) {
				D.value = [...D.value, e], !O.value && e.isEnabled() && e.isVisible() && e.isTabStop() && (O.value = e);
			},
			unregister(e) {
				k.value === e && W(!1), D.value = D.value.filter((t) => t !== e), O.value === e && (O.value = H()[0] ?? null);
			},
			tabIndex(e) {
				let t = U();
				return e === (O.value && t.includes(O.value) ? O.value : t[0]) ? 0 : -1;
			},
			onItemFocus(e) {
				O.value = e;
			},
			onItemPointerEnter(e, t) {
				t.pointerType !== "touch" && k.value && k.value !== e && G(e, "none");
			},
			onItemKeyDown: (e, t) => {
				if (t.altKey) return;
				let n = E.value && getComputedStyle(E.value).direction === "rtl";
				t.key === "ArrowLeft" || t.key === "ArrowRight" ? (t.preventDefault(), q(e, (t.key === "ArrowRight" ? 1 : -1) * (n ? -1 : 1))) : t.key === "ArrowDown" || t.key === "Enter" || t.key === " " ? (t.preventDefault(), G(e)) : t.key === "Escape" && (t.preventDefault(), W(!0));
			},
			onFlyoutKeyDown(e, t) {
				if (t.key === "ArrowLeft" || t.key === "ArrowRight") {
					t.preventDefault(), t.stopPropagation();
					let n = E.value && getComputedStyle(E.value).direction === "rtl";
					q(e, (t.key === "ArrowRight" ? 1 : -1) * (n ? -1 : 1), !0);
				}
			},
			onItemClosed(e) {
				k.value === e && (k.value = null);
			},
			toggle(e, t = "first") {
				k.value === e ? W(!0) : G(e, t);
			},
			open: G,
			close: W
		});
		let J = (e, t, n) => {
			if (e.key !== null) return e;
			let r = e.props?.["x:Name"] ?? e.props?.Name ?? e.props?.["data-xaml-ref"], i;
			if (typeof r == "string" && r) i = `menu-bar-name:${r}`;
			else {
				let r = g(e);
				i = n ? M.get(r) ?? "" : N.get(t) ?? "", i || (i = `menu-bar-item:${S?.uid ?? 0}:${++P}`, n ? M.set(r, i) : N.set(t, i));
			}
			return te(e, { key: i });
		}, ae = () => {
			let r = t(y.default?.() ?? [], S), i = r.find((e) => e.type?.__menuBarProperty === "Items"), a = n(s.Items, S);
			return A = (s.Items === void 0 ? i ? ee(i) : r : Array.isArray(a) ? a : d(a) ? [a] : []).filter((e) => d(e) && !!e.type?.__menuBarItem).map((e, t) => J(e, t, s.Items !== void 0)), (j.value ?? A).map((t, n) => e(J(t, n, !0), void 0, S));
		}, Y = (e) => {
			if (!d(e) || !e.type?.__menuBarItem) throw TypeError("MenuBar.Items accepts MenuBarItem elements.");
			return e;
		}, X = (e) => {
			j.value = e, r(s.Items, e, S), x("update:Items", e);
		}, Z = () => [...j.value ?? A], Q = {
			GetAt(e) {
				return V()[e]?.api;
			},
			IndexOf(e) {
				return V().findIndex((t) => t.api === e);
			},
			Add(e) {
				let t = Z();
				t.push(Y(e)), X(t);
			},
			Append(e) {
				Q.Add(e);
			},
			InsertAt(e, t) {
				let n = Z();
				n.splice(e, 0, Y(t)), X(n);
			},
			SetAt(e, t) {
				let n = Z();
				n.splice(e, 1, Y(t)), X(n);
			},
			RemoveAt(e) {
				let t = Z();
				t.splice(e, 1), X(t);
			},
			RemoveAtEnd() {
				let e = Z();
				e.pop(), X(e);
			},
			Clear() {
				X([]);
			},
			ReplaceAll(e) {
				X(e.map(Y));
			}
		}, oe = new Proxy(Q, { get(e, t) {
			return t === "Count" || t === "Size" || t === "length" ? D.value.length : t === Symbol.iterator ? () => V().map((e) => e.api)[Symbol.iterator]() : t in e ? e[t] : V().map((e) => e.api)[t];
		} });
		b({
			get Items() {
				return oe;
			},
			set Items(e) {
				X(e.map(Y));
			},
			Focus: () => {
				let e = H()[0];
				return e && K(e), !!e;
			},
			get Element() {
				return E.value;
			},
			get IsEnabled() {
				return L.value;
			},
			set IsEnabled(e) {
				F.value = e, r(s.IsEnabled, e, S), x("update:IsEnabled", e);
			},
			get Visibility() {
				return R.value;
			},
			set Visibility(e) {
				I.value = e, r(s.Visibility, e, S), x("update:Visibility", e);
			}
		}), _(() => n(s.IsEnabled, S), () => {
			F.value = void 0;
		}), _(() => n(s.Visibility, S), () => {
			I.value = void 0;
		}), _(() => n(s.Items, S), () => {
			j.value = null;
		}), _(L, (e) => {
			e || W(!1);
		}), _(z, (e) => {
			e || W(!1);
		});
		let $ = () => {
			let e = k.value;
			W(!1), D.value.slice().forEach((t) => {
				t !== e && t.close(!1);
			});
		};
		return re(() => window.addEventListener("blur", $)), ne(() => {
			B = !0, W(!1), window.removeEventListener("blur", $);
		}), () => l("nav", {
			...Object.fromEntries(Object.entries(v).filter(([e]) => /^(Grid|Canvas|RelativePanel)\./.test(e)).map(([e, t]) => [e, n(t, S)])),
			ref: E,
			class: [
				"win-menu-bar win-menu-bar-layout-root",
				["light", "dark"].includes(w.value) && ["win-theme-scope", `theme-${T.value}`],
				v.class
			],
			style: [i({
				...v,
				...s,
				Visibility: R.value
			}, S), v.style],
			id: v["x:Name"] ?? v.id,
			dir: n(v.FlowDirection, S) === "RightToLeft" ? "rtl" : void 0,
			role: "menubar",
			"aria-label": n(v["AutomationProperties.Name"], S),
			"aria-disabled": !L.value || void 0,
			"data-theme": ["light", "dark"].includes(w.value) ? w.value : void 0
		}, [l("div", { class: "win-menu-bar-content-root" }, [l("div", {
			class: "win-menu-bar-items-presenter",
			role: "presentation"
		}, ae())])]);
	}
}), b = Object.assign(y, { Items: v });
//#endregion
export { v as MenuBarItemsProperty, b as default };

//# sourceMappingURL=MenuBar.vue_vue_type_script_lang.js.map