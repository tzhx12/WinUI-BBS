import { toolTipOwnerContextKey as e } from "./toolTipRuntime.js";
import { Fragment as t, defineComponent as n, getCurrentInstance as r, h as i, onMounted as a, onUpdated as o, provide as s, ref as c, shallowRef as l } from "vue";
//#region src/components/ToolTipServiceProperties.ts
var u = n({
	name: "ToolTipService.ToolTip",
	__toolTipServiceProperty: !0,
	setup(n, { slots: u }) {
		let d = r(), f = l(null);
		s(e, {
			owner: f,
			inputMode: c("none"),
			point: c(null),
			theme: c(""),
			attached: !0
		});
		let p = () => {
			let e = d?.parent;
			for (; e;) {
				let t = e.subTree, n = e.vnode.el instanceof HTMLElement ? e.vnode.el : Array.isArray(t?.children) ? t.children.find((e) => e && typeof e == "object" && "el" in e && e.el instanceof HTMLElement)?.el : void 0;
				if (n instanceof HTMLElement) {
					f.value = n;
					return;
				}
				e = e.parent;
			}
		};
		return a(p), o(p), () => i(t, u.default?.());
	}
}), d = (e) => !!e.type?.__toolTipServiceProperty, f = n({
	name: "ToolTip.Content",
	__toolTipContentProperty: !0,
	setup(e, { slots: n }) {
		return () => i(t, n.default?.());
	}
}), p = (e) => !!e.type?.__toolTipContentProperty, m = (e) => n({
	name: `ToolTip.${e}`,
	__toolTipProperty: e,
	setup(e, { slots: n }) {
		return () => i(t, n.default?.());
	}
}), h = m("ContentTemplate"), g = m("ContentTransitions");
//#endregion
export { f as ToolTipContent, h as ToolTipContentTemplate, g as ToolTipContentTransitions, u as ToolTipServiceToolTip, d as getToolTipServiceProperty, p as isToolTipContentProperty };

//# sourceMappingURL=ToolTipServiceProperties.js.map