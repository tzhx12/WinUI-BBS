//#region src/components/commandBarResources.ts
var e = (e) => `var(--${e})`, t = {
	AppBarThemeMinHeight: 64,
	AppBarThemeCompactHeight: 48,
	AppBarMoreButtonColumnMinWidth: 6,
	AppBarEllipsisButtonInnerBorderMargin: "2,6,6,6",
	CommandBarOverflowMinWidth: 160,
	CommandBarOverflowTouchMinWidth: 240,
	CommandBarOverflowMaxWidth: 480,
	CommandBarOverflowMaxHeight: 198,
	CommandBarBorderThicknessOpen: "1",
	CommandBarOverflowPresenterBorderThickness: "1",
	CommandBarOverflowPresenterBorderDownThickness: "0,0,0,1",
	CommandBarOverflowPresenterBorderUpThickness: "0,1,0,0",
	CommandBarOverflowPresenterBorderPadding: "0",
	CommandBarOverflowPresenterBorderDownPadding: "0",
	CommandBarOverflowPresenterBorderUpPadding: "0",
	CommandBarOverflowPresenterMargin: "0,4,0,4",
	CommandBarFlyoutAppBarButtonInnerBorderMargin: "2",
	CommandBarFlyoutAppBarEllipsisButtonInnerBorderMargin: "2,2,6,2",
	CommandBarFlyoutBorderThemeThickness: "1",
	CommandBarFlyoutBorderUpThemeThickness: "1,1,1,0",
	CommandBarFlyoutBorderDownThemeThickness: "1,0,1,1",
	CommandBarBackground: e("ControlFillColorTransparentBrush"),
	CommandBarBackgroundOpen: e("AcrylicInAppFillColorDefaultBrush"),
	CommandBarBorderBrushOpen: e("CardStrokeColorDefaultSolidBrush"),
	CommandBarForeground: e("TextFillColorPrimaryBrush"),
	CommandBarHighContrastBorder: e("ControlFillColorTransparentBrush"),
	CommandBarEllipsisIconForegroundDisabled: e("TextFillColorDisabledBrush"),
	CommandBarOverflowPresenterBackground: e("AcrylicInAppFillColorDefaultBrush"),
	CommandBarOverflowPresenterBorderBrush: e("SystemControlTransientBorderBrush"),
	CommandBarLightDismissOverlayBackground: e("SystemControlPageBackgroundMediumAltMediumBrush"),
	CommandBarFlyoutBackground: e("DesktopAcrylicTransparentBrush"),
	CommandBarFlyoutForeground: e("TextFillColorPrimaryBrush"),
	CommandBarFlyoutBorderBrush: e("ControlStrokeColorDefaultBrush"),
	CommandBarFlyoutButtonBackground: e("SystemControlTransparentBrush"),
	CommandBarFlyoutAppBarButtonBorderBrush: e("SubtleFillColorTransparentBrush")
};
for (let [n, r, i] of [
	[
		"",
		"SubtleFillColorTransparentBrush",
		"TextFillColorPrimaryBrush"
	],
	[
		"PointerOver",
		"SubtleFillColorSecondaryBrush",
		"TextFillColorPrimaryBrush"
	],
	[
		"Pressed",
		"SubtleFillColorTertiaryBrush",
		"TextFillColorSecondaryBrush"
	],
	[
		"Disabled",
		"SubtleFillColorDisabledBrush",
		"TextFillColorDisabledBrush"
	]
]) t[`CommandBarFlyoutAppBarButtonBackground${n}`] = e(r), t[`CommandBarFlyoutAppBarButtonForeground${n}`] = e(i);
for (let [n, r, i] of [
	[
		"",
		"AccentFillColorDefaultBrush",
		"TextOnAccentFillColorPrimaryBrush"
	],
	[
		"PointerOver",
		"AccentFillColorSecondaryBrush",
		"TextOnAccentFillColorPrimaryBrush"
	],
	[
		"Pressed",
		"AccentFillColorTertiaryBrush",
		"TextOnAccentFillColorSecondaryBrush"
	],
	[
		"Disabled",
		"AccentFillColorDisabledBrush",
		"TextOnAccentFillColorDisabledBrush"
	]
]) t[`CommandBarFlyoutAppBarButtonBackgroundChecked${n}`] = e(r), t[`CommandBarFlyoutAppBarButtonForegroundChecked${n}`] = e(i);
for (let n of [
	"",
	"PointerOver",
	"Pressed"
]) t[`CommandBarFlyoutAppBarButtonKeyboardTextLabelForeground${n}`] = e(n === "Pressed" ? "TextFillColorTertiaryBrush" : "TextFillColorSecondaryBrush");
for (let n of [
	"",
	"PointerOver",
	"Pressed",
	"SubMenuOpened",
	"Disabled"
]) t[`CommandBarFlyoutAppBarButtonSubItemChevron${n ? `${n}Foreground` : "Foreground"}`] = e(n === "Disabled" ? "TextFillColorDisabledBrush" : n === "Pressed" ? "TextFillColorTertiaryBrush" : "TextFillColorSecondaryBrush");
var n = Object.freeze(t);
//#endregion
export { n as commandBarResources };

//# sourceMappingURL=commandBarResources.js.map