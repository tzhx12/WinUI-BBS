import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./MenuBar.vue_vue_type_script_lang.js";
/* empty css                                                            */
//#region src/components/MenuBar.vue
var n = /*#__PURE__*/ e(t, [["__scopeId", "data-v-719997cf"], ["__file", "MenuBar.vue"]]);
//#endregion
export { n as default };

//# sourceMappingURL=MenuBar.vue.js.map