import { shallowRef as e } from "vue";
//#region src/components/frameNavigationRuntime.ts
var t = e(!1), n = /* @__PURE__ */ new Map(), r = [
	"pointerdown",
	"pointerup",
	"pointermove",
	"mousedown",
	"mouseup",
	"mousemove",
	"click",
	"dblclick",
	"contextmenu",
	"keydown",
	"keyup",
	"wheel",
	"touchstart",
	"touchmove",
	"dragstart",
	"dragover",
	"drop"
], i = 0, a = (e) => {
	e.cancelable && e.preventDefault(), e.stopImmediatePropagation();
}, o = (e) => {
	if (typeof document > "u") return () => {};
	let o = document.getElementById("app") ?? e ?? document.body;
	if (!o) return () => {};
	let s = n.get(o);
	if (s || (s = {
		Element: o,
		WasInert: o.hasAttribute("inert"),
		Busy: o.getAttribute("aria-busy"),
		Count: 0
	}, n.set(o, s)), s.Count += 1, o.setAttribute("inert", ""), o.setAttribute("aria-busy", "true"), i++ === 0) {
		for (let e of r) window.addEventListener(e, a, {
			capture: !0,
			passive: !1
		});
		t.value = !0;
	}
	let c = !1;
	return () => {
		if (!c && (c = !0, --s.Count, s.Count || (o.toggleAttribute("inert", s.WasInert), s.Busy === null ? o.removeAttribute("aria-busy") : o.setAttribute("aria-busy", s.Busy), n.delete(o)), --i === 0)) {
			for (let e of r) window.removeEventListener(e, a, !0);
			t.value = !1;
		}
	};
}, s = [], c = /* @__PURE__ */ new Set(), l = () => Promise.all([...c].map((e) => e.completion)).then((e) => e.every(Boolean)), u = () => Promise.all([...c].filter((e) => e.kind === "Route").map((e) => e.completion)).then((e) => e.every(Boolean)), d = () => [...c].some((e) => e.kind === "Route"), f = (e, t = "Frame") => {
	let n = o(e), r, i = !1, a = {
		kind: t,
		completion: new Promise((e) => {
			r = e;
		}),
		complete: (e) => {
			i || (i = !0, c.delete(a), r(e), n());
		}
	};
	c.add(a);
	for (let e of s) e.push(a);
	return a;
}, p = (e) => {
	let t = [], n = o();
	s.push(t);
	try {
		return {
			result: e(),
			hasRouteNavigation: t.some((e) => e.kind === "Route"),
			completion: Promise.all(t.map((e) => e.completion)).then((e) => e.every(Boolean)),
			release: n
		};
	} catch (e) {
		throw n(), e;
	} finally {
		s.pop();
	}
};
//#endregion
export { f as beginNavigationCommit, p as captureFrameNavigationCommit, d as hasPendingRouteNavigation, t as navigationInputFrozen, l as pendingNavigationCompletion, u as pendingRouteNavigationCompletion };

//# sourceMappingURL=frameNavigationRuntime.js.map