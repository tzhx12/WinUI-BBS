import { pivotChildren as e } from "./PivotProperties.js";
import { defineComponent as t } from "vue";
//#region src/components/TabViewProperties.ts
var n = (e, n) => t({
	name: `${e}.${n}`,
	__tabViewPropertyOwner: e,
	__tabViewProperty: n,
	...n === "Resources" ? { __xamlResourceProperty: "resources" } : {},
	setup: () => () => null
}), r = n("TabView", "TabItems"), i = n("TabView", "TabItemTemplate"), a = n("TabView", "TabStripHeader"), o = n("TabView", "TabStripHeaderTemplate"), s = n("TabView", "TabStripFooter"), c = n("TabView", "TabStripFooterTemplate"), l = n("TabView", "Resources"), u = n("TabView", "KeyboardAccelerators"), d = n("TabViewItem", "Header"), f = n("TabViewItem", "HeaderTemplate"), p = n("TabViewItem", "IconSource"), m = n("TabViewItem", "Content"), h = n("TabViewItem", "ContentTemplate"), g = n("TabViewItem", "ContextFlyout"), _ = n("TabViewItem", "Resources"), v = {
	TabItems: r,
	TabItemTemplate: i,
	TabStripHeader: a,
	TabStripHeaderTemplate: o,
	TabStripFooter: s,
	TabStripFooterTemplate: c,
	Resources: l,
	KeyboardAccelerators: u
}, y = {
	Header: d,
	HeaderTemplate: f,
	IconSource: p,
	Content: m,
	ContentTemplate: h,
	ContextFlyout: g,
	Resources: _
}, b = (e, t) => {
	let n = e.type;
	return n?.__tabViewPropertyOwner === t ? n.__tabViewProperty : void 0;
}, x = (t, n, r) => {
	let i = t.find((e) => b(e, n) === r);
	return i ? e(i) : [];
}, S = Symbol("WinUIonWeb.TabViewItemIdentity"), C = Symbol("WinUIonWeb.TabViewItemTransfer"), w = Symbol("WinUIonWeb.TabViewItemLiveControl"), T = Symbol("WinUIonWeb.TabViewItemOwner"), E = Symbol("WinUIonWeb.TabViewItemRecord");
//#endregion
export { b as getTabViewProperty, S as tabViewItemIdentityKey, w as tabViewItemLiveControlKey, T as tabViewItemOwnerKey, y as tabViewItemProperties, E as tabViewItemRecordKey, C as tabViewItemTransferKey, v as tabViewProperties, x as tabViewPropertyChildren };

//# sourceMappingURL=TabViewProperties.js.map