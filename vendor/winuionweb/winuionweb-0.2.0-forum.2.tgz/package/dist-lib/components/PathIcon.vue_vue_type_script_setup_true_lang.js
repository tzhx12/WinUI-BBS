import { iconElementProps as e, useIconElement as t } from "./iconElementRuntime.js";
import n from "./Grid.vue.js";
import { resolveIconGeometry as r } from "./iconGeometry.js";
import { computed as i, defineComponent as a, getCurrentInstance as o, nextTick as s, onMounted as c, ref as l, useAttrs as u, useSlots as d, watch as f } from "vue";
//#region src/components/PathIcon.vue?vue&type=script&setup=true&lang.ts
var p = a({
	name: "PathIcon.Data",
	__iconGeometryProperty: !0,
	setup() {
		return () => null;
	}
}), m = /*@__PURE__*/ a({
	Data: p,
	inheritAttrs: !1,
	__name: "PathIcon",
	props: {
		Data: {
			type: [String, Object],
			default: null
		},
		...e
	},
	setup(e, { expose: a }) {
		let m = e, h = u(), g = d(), _ = o(), { Element: v, read: y, layoutStyle: b, rootAttrs: x, api: S } = t(m, h, _, ["Data"]);
		a(S);
		let C = l(), w = l({
			width: 0,
			height: 0
		}), T = i(() => {
			let e = y("Data");
			return r(e === "" || e === null ? g.default?.() ?? [] : e, _);
		}), E = async () => {
			if (await s(), !T.value.path) {
				w.value = {
					width: 0,
					height: 0
				};
				return;
			}
			try {
				let e = C.value?.getBBox();
				w.value = e ? {
					width: Math.max(0, e.x + e.width),
					height: Math.max(0, e.y + e.height)
				} : {
					width: 0,
					height: 0
				};
			} catch {
				w.value = {
					width: 0,
					height: 0
				};
			}
		};
		f(T, E), c(E);
		let D = {
			PathIconData: p,
			props: m,
			attrs: h,
			slots: g,
			instance: _,
			Element: v,
			read: y,
			layoutStyle: b,
			rootAttrs: x,
			api: S,
			pathElement: C,
			naturalSize: w,
			geometry: T,
			measureGeometry: E,
			iconStyle: i(() => ({
				width: `${w.value.width}px`,
				height: `${w.value.height}px`,
				...b.value
			})),
			Grid: n
		};
		return Object.defineProperty(D, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), D;
	}
});
//#endregion
export { p as PathIconData, m as default };

//# sourceMappingURL=PathIcon.vue_vue_type_script_setup_true_lang.js.map