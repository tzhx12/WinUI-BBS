import { alignment as e, boolValue as t, cssLength as n, xamlThickness as r } from "./layout.js";
import { normalizeXamlNodes as i, resolveXamlHandler as a, resolveXamlValue as o, updateXamlBinding as s, xamlScopeKey as c } from "./xamlRuntime.js";
import { brushProperty as ee, isBrushProperty as te, useBrushProperty as ne } from "./brushProperties.js";
import re from "./Grid.vue.js";
import { useUICommand as ie } from "./uiCommandRuntime.js";
import { getToolTipServiceProperty as ae } from "./ToolTipServiceProperties.js";
import { isHoverPointer as l } from "./pointerInput.js";
import oe from "./ContentPresenter.vue.js";
import { useAnimatedIconInput as se } from "./animatedIconInput.js";
import ce from "./FocusVisual.vue.js";
import { buttonContentProperty as u, getButtonContentProperty as le, useButtonContent as ue } from "./buttonContentRuntime.js";
import { Comment as de, Fragment as d, Text as fe, computed as f, defineComponent as p, getCurrentInstance as pe, h as m, inject as me, isVNode as h, onBeforeUnmount as he, onMounted as ge, provide as _e, proxyRefs as ve, ref as g, shallowRef as ye, useAttrs as be, useSlots as xe, watch as _ } from "vue";
//#region src/components/Button.vue?vue&type=script&setup=true&lang.ts
var v = p({
	name: "Button.Flyout",
	__buttonProperty: "flyout",
	setup(e, { slots: t }) {
		return () => m("span", { class: "button-flyout-property" }, t.default?.());
	}
}), Se = p({
	name: "Button.Content",
	__buttonProperty: "content",
	setup() {
		return () => null;
	}
}), y = p({
	name: "Button.KeyboardAccelerators",
	__buttonProperty: "keyboardAccelerators",
	setup() {
		return () => null;
	}
}), Ce = /*@__PURE__*/ p({
	Flyout: v,
	Content: Se,
	ContentTemplate: u("Button", "ContentTemplate"),
	ContentTransitions: u("Button", "ContentTransitions"),
	Resources: u("Button", "Resources"),
	KeyboardAccelerators: y,
	Background: ee("Button", "Background"),
	inheritAttrs: !1,
	__name: "Button",
	props: {
		Style: {
			type: String,
			default: ""
		},
		RequestedTheme: {
			type: String,
			default: "Default"
		},
		Content: {
			type: null,
			default: void 0
		},
		ContentTemplate: {
			type: null,
			default: void 0
		},
		ContentTransitions: {
			type: null,
			default: void 0
		},
		ClickMode: {
			type: String,
			default: "Release"
		},
		IsTabStop: {
			type: [Boolean, String],
			default: !0
		},
		Command: {
			type: [Object, String],
			default: void 0
		},
		CommandParameter: {
			type: null,
			default: void 0
		},
		Flyout: {
			type: null,
			default: void 0
		},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		Visibility: {
			type: String,
			default: "Visible"
		},
		Background: {
			type: [String, Object],
			default: ""
		},
		BackgroundSizing: {
			type: String,
			default: ""
		},
		Foreground: {
			type: String,
			default: ""
		},
		BorderBrush: {
			type: String,
			default: ""
		},
		BorderThickness: {
			type: [String, Number],
			default: ""
		},
		Padding: {
			type: String,
			default: ""
		},
		Margin: {
			type: String,
			default: ""
		},
		Width: {
			type: [String, Number],
			default: ""
		},
		Height: {
			type: [String, Number],
			default: ""
		},
		MaxWidth: {
			type: [String, Number],
			default: ""
		},
		MaxHeight: {
			type: [String, Number],
			default: ""
		},
		MinWidth: {
			type: [String, Number],
			default: ""
		},
		MinHeight: {
			type: [String, Number],
			default: ""
		},
		HorizontalAlignment: {
			type: String,
			default: "Left"
		},
		VerticalAlignment: {
			type: String,
			default: "Center"
		},
		HorizontalContentAlignment: {
			type: String,
			default: ""
		},
		VerticalContentAlignment: {
			type: String,
			default: ""
		},
		FontFamily: {
			type: String,
			default: ""
		},
		FontWeight: {
			type: String,
			default: ""
		},
		FontSize: {
			type: [String, Number],
			default: ""
		},
		UseSystemFocusVisuals: {
			type: [Boolean, String],
			default: !0
		},
		FocusVisualMargin: {
			type: [String, Number],
			default: ""
		},
		CornerRadius: {
			type: [String, Number],
			default: ""
		}
	},
	emits: [
		"Click",
		"GotFocus",
		"LostFocus",
		"KeyDown",
		"KeyUp",
		"ContextRequested",
		"PointerEntered",
		"PointerExited",
		"PointerMoved",
		"PointerPressed",
		"PointerReleased",
		"PointerCanceled",
		"PointerCaptureLost"
	],
	setup(ee, { expose: u, emit: Ce }) {
		let b = ee, x = Ce, S = be(), C = pe(), w = xe(), { ContentTemplate: we, ContentTransitions: Te, renderTemplate: Ee } = ue(b, () => w.default?.() ?? [], C), T = ne("Background", () => b.Background, () => w.default?.() ?? [], C), E = g(null), D = se(), O = g(!1), k = g(!1), A = null, j = "", M = !1;
		_(E, (e) => D.Attach(e), { flush: "post" });
		let De = {
			mouse: "Mouse",
			touch: "Touch",
			pen: "Pen"
		}, N = (e, t, n) => {
			n(t);
			let r = Z, i = {
				OriginalSource: r,
				OriginalEvent: t,
				Handled: !1,
				Pointer: {
					PointerId: t.pointerId,
					PointerDeviceType: De[t.pointerType] || "Mouse"
				},
				GetCurrentPoint: (e) => {
					let n = (e instanceof HTMLElement ? e : e?.Element)?.getBoundingClientRect();
					return {
						Position: {
							X: t.clientX - (n?.left ?? 0),
							Y: t.clientY - (n?.top ?? 0)
						},
						IsInContact: t.buttons > 0
					};
				}
			};
			x(e, r, i), S[e] && !C?.vnode.props?.[`on${e}`] && a(S[e], C)?.(r, i), i.Handled && (t.preventDefault(), t.stopPropagation());
		}, Oe = (e) => {
			k.value = l(e), A !== null && e.buttons > 0 && (O.value = !0), N("PointerEntered", e, D.PointerEntered), l(e) && !X.value && o(b.ClickMode, C) === "Hover" && $(e);
		}, ke = (e) => {
			k.value = !1, O.value = !1, N("PointerExited", e, D.PointerExited);
		}, P = () => {
			let e = A;
			if (A = null, O.value = !1, j = "", e !== null && E.value?.hasPointerCapture?.(e)) try {
				E.value.releasePointerCapture(e);
			} catch {}
		}, Ae = (e) => {
			l(e) || (k.value = !1), !X.value && e.button === 0 && o(b.ClickMode, C) !== "Hover" && (M = !1, A = e.pointerId, O.value = !0, E.value?.setPointerCapture?.(e.pointerId), o(b.ClickMode, C) === "Press" && ($(e), M = !0)), N("PointerPressed", e, D.PointerPressed);
		}, je = (e) => {
			let t = E.value?.getBoundingClientRect();
			return t && e.clientX >= t.left && e.clientX <= t.right && e.clientY >= t.top && e.clientY <= t.bottom;
		}, Me = (e) => {
			e.pointerId === A && (O.value = !!je(e), k.value = l(e) && O.value), N("PointerMoved", e, () => {});
		}, Ne = (e) => {
			A !== null && !je(e) && (M = !0), P(), l(e) || (k.value = !1), N("PointerReleased", e, D.PointerReleased);
		}, Pe = (e) => {
			P(), l(e) || (k.value = !1), M = !0, N("PointerCanceled", e, D.PointerExited);
		}, Fe = (e) => {
			P(), l(e) || (k.value = !1), N("PointerCaptureLost", e, D.PointerExited);
		}, F = ie(() => o(b.Command, C)), I = f(() => o(b.CommandParameter, C)), Ie = (e) => {
			if (X.value || !S.ContextRequested && !C?.vnode.props?.onContextRequested) return;
			let t = Z, n = {
				OriginalSource: t,
				OriginalEvent: e,
				Handled: !1,
				PointerPosition: {
					X: e.clientX,
					Y: e.clientY
				},
				TryGetPosition: (t) => {
					let n = (t instanceof HTMLElement ? t : t?.Element)?.getBoundingClientRect();
					return {
						X: e.clientX - (n?.left ?? 0),
						Y: e.clientY - (n?.top ?? 0)
					};
				}
			};
			x("ContextRequested", t, n), S.ContextRequested && !C?.vnode.props?.onContextRequested && a(S.ContextRequested, C)?.(t, n), e.preventDefault();
		}, L = ye(null), R = f(() => o(b.Flyout, C)), z = ye(void 0);
		_(R, () => {
			z.value = void 0;
		}), _e("buttonFlyoutAnchor", E), _e("buttonFlyoutController", L);
		let B = f(() => {
			let e = [], t = [], n = [], r = [], i = (a) => {
				for (let o of a) {
					if (o.type === de || o.type === fe && !String(o.children ?? "").trim() || te(o) || le(o)) continue;
					if (o.type === d && Array.isArray(o.children)) {
						i(o.children);
						continue;
					}
					let a = o?.type, s = a && typeof a == "object" ? a.__buttonProperty : void 0;
					if (ae(o)) n.push(o);
					else if (s === "flyout" || s === "content" || s === "keyboardAccelerators") {
						let n = o.children && typeof o.children == "object" ? o.children.default : void 0;
						n && (s === "flyout" ? t : s === "content" ? e : r).push(...n());
					} else e.push(o);
				}
			};
			i(w.default?.() ?? []);
			let a = z.value === void 0 ? R.value : z.value;
			return z.value !== void 0 && (t.length = 0), !t.length && h(a) && t.push(a), {
				content: e,
				flyout: t,
				attached: n,
				keyboardAccelerators: r
			};
		}), Le = p({
			name: "ButtonContentOutlet",
			setup() {
				return () => {
					let e = Ee(K.value === void 0 ? q.value : K.value);
					if (e) return e;
					if (K.value !== void 0) return typeof K.value == "string" || typeof K.value == "number" ? m("span", { class: "win-button-default-text" }, String(K.value)) : m(d, h(K.value) ? i([K.value], C) : []);
					let t = i(B.value.content, C);
					return t.every((e) => e.type === fe) ? m("span", { class: "win-button-default-text" }, t.map((e) => String(e.children ?? "")).join("")) : m(d, t);
				};
			}
		}), Re = p({
			name: "ButtonFlyoutOutlet",
			setup() {
				return () => m(d, B.value.flyout);
			}
		}), ze = p({ setup: () => () => {
			let e = q.value;
			return Ee(e) ?? (h(e) ? m(d, i([e], C)) : typeof e == "string" || typeof e == "number" ? m("span", { class: "win-button-default-text" }, String(e)) : null);
		} }), Be = p({ setup: () => () => m(d, B.value.attached) }), Ve = f(() => {
			let e = { ...S };
			delete e.class, delete e.style, delete e.disabled, delete e.Click, delete e.GotFocus, delete e.ContextRequested;
			for (let t of [
				"LostFocus",
				"KeyDown",
				"KeyUp",
				"PointerEntered",
				"PointerExited",
				"PointerMoved",
				"PointerPressed",
				"PointerReleased",
				"PointerCanceled",
				"PointerCaptureLost"
			]) delete e[t];
			let t = (t) => Object.keys(e).find((e) => e.toLowerCase() === t.toLowerCase()), n = t("ToolTipService.ToolTip"), r = t("AutomationProperties.Name"), i = n ? e[n] : void 0, a = r ? e[r] : void 0;
			n && delete e[n], r && delete e[r];
			let s = n || B.value.attached.length ? o(i, C) : F.value?.Description, c = o(a, C);
			return s != null && s !== "" && (e["tooltipservice.tooltip"] = String(s)), c != null && c !== "" && (e["aria-label"] = String(c)), e;
		}), He = f(() => o(b.IsEnabled, C)), Ue = f(() => F.value?.CanExecute?.(I.value) ?? !0), V = g(void 0);
		_(He, () => {
			V.value = void 0;
		});
		let We = f({
			get: () => (V.value ?? t(He.value)) && Ue.value,
			set: (e) => {
				V.value = !!e, s(b.IsEnabled, !!e, C);
			}
		}), H = f(() => String(o(b.Visibility, C)).toLowerCase() === "collapsed"), U = f(() => b.Content === void 0 ? F.value?.Label ?? "" : o(b.Content, C)), W = f(() => String(o(b.RequestedTheme, C))), G = g();
		_(W, () => {
			G.value = void 0;
		});
		let Ge = f({
			get: () => G.value ?? W.value,
			set: (e) => {
				G.value = e, s(b.RequestedTheme, e, C);
			}
		}), K = ye(void 0);
		_(U, () => {
			K.value = void 0;
		});
		let q = f({
			get: () => K.value === void 0 ? U.value : K.value,
			set: (e) => {
				K.value = e, s(b.Content, e, C);
			}
		}), J = f(() => String(o(b.Style, C) || "")), Y = f(() => J.value.includes("TitleBarBackButtonStyle") ? "TitleBarBackButton" : J.value.includes("TitleBarPaneToggleButtonStyle") ? "TitleBarPaneToggleButton" : ""), X = f(() => !We.value);
		_(X, () => {
			P(), D.Refresh();
		}, { flush: "post" });
		let Ke = f({
			get: () => K.value === void 0 ? B.value.content[0] ?? q.value : K.value,
			set: (e) => {
				q.value = e;
			}
		}), qe = f({
			get: () => z.value !== void 0 && !h(z.value) ? z.value : L.value ?? (h(R.value) ? null : R.value),
			set: (e) => {
				z.value = e, s(b.Flyout, e, C);
			}
		}), Z = ve({
			Element: E,
			Flyout: qe,
			IsEnabled: We,
			RequestedTheme: Ge,
			Name: f(() => S["data-xaml-ref"] ?? S["x:Name"] ?? S.Name ?? ""),
			Content: Ke,
			ContentTemplate: we,
			ContentTransitions: Te,
			Command: F,
			CommandParameter: I,
			IsPressed: O,
			IsPointerOver: k,
			Focus: () => (E.value?.focus(), !X.value)
		});
		u(Z);
		let Je = f(() => o(b.HorizontalContentAlignment, C) || "Center"), Ye = f(() => o(b.VerticalContentAlignment, C) || "Center"), Xe = f(() => T.value.value && typeof T.value.value == "object" && !X.value && !O.value && !k.value ? T.value.value : "var(--ButtonBackgroundCurrent)"), Ze = f(() => o(b.BackgroundSizing, C) || (J.value.includes("AccentButtonStyle") ? "OuterBorderEdge" : "InnerBorderEdge")), Qe = f(() => "var(--ButtonBorderBrushCurrent)"), Q = (e) => o(e, C), $e = f(() => Q(b.BorderThickness) === "" ? 1 : Q(b.BorderThickness)), et = f(() => o(b.Padding, C) || "11,5,11,6"), tt = f(() => Q(b.CornerRadius) === "" ? 4 : Q(b.CornerRadius)), nt = me(c, {});
		_e(c, {
			...nt,
			ContentTemplate: we,
			ContentTransitions: Te,
			PresenterHorizontalAlignment: Je,
			PresenterVerticalAlignment: Ye,
			PresenterBackground: Xe,
			PresenterBackgroundSizing: Ze,
			PresenterBorderBrush: Qe,
			PresenterBorderThickness: $e,
			PresenterPadding: et,
			PresenterCornerRadius: tt
		});
		let rt = {
			Left: "flex-start",
			Center: "center",
			Right: "flex-end",
			Stretch: "stretch",
			Top: "flex-start",
			Bottom: "flex-end"
		}, it = (e) => rt[String(e)] ?? "", at = f(() => ({
			DefaultButtonStyle: !J.value || J.value.includes("DefaultButtonStyle"),
			AccentButtonStyle: J.value.includes("AccentButtonStyle"),
			SubtleButtonStyle: J.value.includes("SubtleButtonStyle"),
			"win-titlebar-template-button": !!Y.value
		})), ot = f(() => {
			let t = {}, i = (e) => o(b[e], C);
			if (Y.value) {
				for (let e of [
					"",
					"PointerOver",
					"Pressed",
					"Disabled"
				]) t[`--ButtonBackground${e}`] = `var(--${Y.value}Background${e})`, t[`--ButtonForeground${e}`] = `var(--${Y.value}Foreground${e})`, t[`--ButtonBorderBrush${e}`] = "transparent";
				t["--ButtonBorderThemeThickness"] = "0px", t["--ButtonPresenterBorderThickness"] = "0px", t.width = n(o(`{ThemeResource ${Y.value}Width}`, C)), t.margin = "2px";
			}
			if (T.value.value && (t["--ButtonBackground"] = typeof T.value.value == "object" ? "transparent" : String(T.value.value)), b.Foreground && (t["--ButtonForeground"] = String(i("Foreground") ?? "")), b.BorderThickness !== "" && (t["--ButtonPresenterBorderThickness"] = r(i("BorderThickness"))), b.BorderBrush) {
				let e = String(i("BorderBrush") ?? "");
				t["--ButtonBorderBrush"] = e, /(?:linear-gradient|(?:Accent)?ControlElevationBorderBrush|(?:DateTime|Date|Time)Picker(?:Flyout)?ButtonBorderBrush)/i.test(e) || (t["--ButtonBorderBrushSide"] = e, t["--ButtonBorderBrushTop"] = e, t["--ButtonBorderBrushBottom"] = e);
			}
			let a = o(b.Margin, C);
			return a != null && a !== "" && (t.margin = r(a)), b.Width !== "" && (t.width = n(i("Width"))), b.Height !== "" && (t.height = n(i("Height"))), b.MaxWidth !== "" && (t.maxWidth = n(i("MaxWidth"))), b.MaxHeight !== "" && (t.maxHeight = n(i("MaxHeight"))), b.MinWidth !== "" && (t.minWidth = n(i("MinWidth"))), b.MinHeight !== "" && (t.minHeight = n(i("MinHeight"))), b.HorizontalAlignment && (t.justifySelf = e(i("HorizontalAlignment"), "horizontal")), b.VerticalAlignment && (t.alignSelf = e(i("VerticalAlignment"), "vertical")), b.HorizontalContentAlignment && (t.justifyContent = i("HorizontalContentAlignment") === "Stretch" ? "flex-start" : it(i("HorizontalContentAlignment"))), b.VerticalContentAlignment && (t.alignItems = it(i("VerticalContentAlignment"))), b.FontFamily && (t.fontFamily = String(i("FontFamily") ?? "")), b.FontWeight && (t.fontWeight = i("FontWeight") === "SemiBold" ? 600 : String(i("FontWeight") ?? "")), b.FontSize !== "" && (t.fontSize = n(i("FontSize"))), b.CornerRadius !== "" && (t["--ButtonCornerRadius"] = r(i("CornerRadius"))), H.value && (t.display = "none"), [S.style, t];
		}), $ = (e) => {
			if (X.value || H.value) return;
			let t = Z, n = {
				OriginalSource: t,
				OriginalEvent: e,
				Handled: !1
			}, r = C?.vnode.props?.onClick;
			for (let e of Array.isArray(r) ? r : [r]) typeof e == "function" && e(t, n);
			r || a(S.Click, C)?.(t, n);
			let i = F.value, o = I.value;
			(i?.CanExecute?.(o) ?? !0) && i?.Execute(o), (typeof KeyboardEvent < "u" && e instanceof KeyboardEvent || !B.value.flyout.length) && qe.value?.ShowAt?.(E.value);
		}, st = (e) => {
			if (M) {
				M = !1;
				return;
			}
			o(b.ClickMode, C) !== "Hover" && $(e);
		}, ct = {
			" ": "Space",
			ArrowDown: "Down",
			ArrowUp: "Up",
			ArrowLeft: "Left",
			ArrowRight: "Right"
		}, lt = (e, t) => {
			let n = Z, r = {
				OriginalSource: n,
				OriginalEvent: t,
				Key: ct[t.key] ?? t.key,
				Handled: !1
			};
			return x(e, n, r), a(S[e], C)?.(n, r), r.Handled && t.preventDefault(), r.Handled;
		}, ut = (e) => {
			if (D.KeyDown(e), !lt("KeyDown", e) && !(X.value || o(b.ClickMode, C) === "Hover")) {
				if (e.key !== " " && e.key !== "Enter") {
					j = "", O.value = !1;
					return;
				}
				e.preventDefault(), !(e.repeat || j || A !== null) && (j = e.key, O.value = !0, o(b.ClickMode, C) === "Press" && $(e));
			}
		}, dt = (e) => {
			if (D.KeyUp(e), lt("KeyUp", e)) {
				P();
				return;
			}
			if (X.value || o(b.ClickMode, C) === "Hover" || e.key !== " " && e.key !== "Enter") return;
			e.preventDefault();
			let t = j === e.key && O.value;
			P(), t && o(b.ClickMode, C) === "Release" && $(e);
		}, ft = (e) => {
			P(), M = !1, D.LostFocus(e);
			let t = Z, n = {
				OriginalSource: t,
				OriginalEvent: e,
				Handled: !1
			};
			x("LostFocus", t, n), a(S.LostFocus, C)?.(t, n);
		}, pt = (e) => {
			if (e.defaultPrevented || e.repeat || X.value || H.value) return;
			let n = F.value;
			for (let n of B.value.keyboardAccelerators) {
				let r = n.props ?? {}, i = String(o(r.Key, C) ?? ""), a = String(o(r.Modifiers, C) ?? "None").split(/[ ,]+/);
				if (i.toLowerCase() === e.key.toLowerCase() && e.ctrlKey === a.includes("Control") && e.altKey === a.includes("Menu") && e.shiftKey === a.includes("Shift") && e.metaKey === a.includes("Windows") && t(o(r.IsEnabled ?? !0, C))) {
					e.preventDefault(), $(e);
					return;
				}
			}
			n && "MatchesKeyboardEvent" in n && typeof n.MatchesKeyboardEvent == "function" && n.MatchesKeyboardEvent(e) && (e.preventDefault(), $(e));
		}, mt = () => {
			P(), M = !1, D.Refresh();
		};
		ge(() => {
			document.addEventListener("keydown", pt), window.addEventListener("blur", mt);
		}), he(() => {
			document.removeEventListener("keydown", pt), window.removeEventListener("blur", mt);
		});
		let ht = {
			ButtonFlyout: v,
			ButtonContent: Se,
			ButtonKeyboardAccelerators: y,
			props: b,
			emit: x,
			attrs: S,
			instance: C,
			slots: w,
			ContentTemplate: we,
			ContentTransitions: Te,
			renderTemplate: Ee,
			backgroundBrush: T,
			buttonRef: E,
			iconInput: D,
			IsPressed: O,
			IsPointerOver: k,
			get activePointer() {
				return A;
			},
			set activePointer(e) {
				A = e;
			},
			get keyPressed() {
				return j;
			},
			set keyPressed(e) {
				j = e;
			},
			get suppressClick() {
				return M;
			},
			set suppressClick(e) {
				M = e;
			},
			pointerDeviceTypes: De,
			pointerEvent: N,
			onPointerEntered: Oe,
			onPointerExited: ke,
			clearPressed: P,
			onPointerPressed: Ae,
			pointerInside: je,
			onPointerMoved: Me,
			onPointerReleased: Ne,
			onPointerCanceled: Pe,
			onPointerCaptureLost: Fe,
			command: F,
			commandParameter: I,
			onContextRequested: Ie,
			flyoutController: L,
			sourceFlyout: R,
			localFlyout: z,
			propertyNodes: B,
			ContentOutlet: Le,
			FlyoutOutlet: Re,
			ContentValueOutlet: ze,
			AttachedOutlet: Be,
			buttonAttrs: Ve,
			resolvedIsEnabled: He,
			commandCanExecute: Ue,
			localIsEnabled: V,
			IsEnabled: We,
			isCollapsed: H,
			sourceContent: U,
			sourceRequestedTheme: W,
			localRequestedTheme: G,
			RequestedTheme: Ge,
			localContent: K,
			resolvedContent: q,
			resolvedStyle: J,
			titleBarStylePrefix: Y,
			isDisabled: X,
			exposedContent: Ke,
			Flyout: qe,
			publicApi: Z,
			PresenterHorizontalAlignment: Je,
			PresenterVerticalAlignment: Ye,
			PresenterBackground: Xe,
			PresenterBackgroundSizing: Ze,
			PresenterBorderBrush: Qe,
			resolveLength: Q,
			PresenterBorderThickness: $e,
			PresenterPadding: et,
			PresenterCornerRadius: tt,
			inheritedScope: nt,
			contentAlignments: rt,
			contentAlignment: it,
			styleClass: at,
			buttonStyle: ot,
			onClick: $,
			onNativeClick: st,
			keyNames: ct,
			raiseKey: lt,
			onKeyDown: ut,
			onKeyUp: dt,
			onLostFocus: ft,
			onAccelerator: pt,
			onWindowBlur: mt,
			onGotFocus: (e) => {
				let t = Z, n = {
					OriginalSource: t,
					OriginalEvent: e,
					Handled: !1
				};
				x("GotFocus", t, n), a(S.GotFocus, C)?.(t, n);
			},
			get resolveXamlValue() {
				return o;
			},
			ContentPresenter: oe,
			FocusVisual: ce,
			Grid: re,
			get boolValue() {
				return t;
			}
		};
		return Object.defineProperty(ht, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), ht;
	}
});
//#endregion
export { Se as ButtonContent, v as ButtonFlyout, y as ButtonKeyboardAccelerators, Ce as default };

//# sourceMappingURL=Button.vue_vue_type_script_setup_true_lang.js.map