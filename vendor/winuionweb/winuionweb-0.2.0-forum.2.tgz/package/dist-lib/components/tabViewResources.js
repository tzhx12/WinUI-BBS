//#region src/components/tabViewResources.ts
var e = {
	SystemAccentColor: "var(--accent-base, #0078D7)",
	SystemAccentColorDark1: "var(--SystemAccentColorDark1, #005A9E)",
	SystemAccentColorDark2: "var(--SystemAccentColorDark2, #004275)",
	SystemAccentColorDark3: "var(--SystemAccentColorDark3, #002642)",
	SystemAccentColorLight1: "var(--SystemAccentColorLight1, #429CE3)",
	SystemAccentColorLight2: "var(--SystemAccentColorLight2, #76B9ED)",
	SystemAccentColorLight3: "var(--SystemAccentColorLight3, #A6D8FF)",
	TabViewHeaderPadding: "0,8,0,0",
	TabViewItemHeaderPadding: "8,3,4,3",
	TabViewSelectedItemHeaderPadding: "9,3,5,4",
	TabViewItemMinHeight: 32,
	TabViewItemMaxWidth: 240,
	TabViewItemMinWidth: 100,
	TabViewItemHeaderFontSize: 12,
	TabViewItemHeaderIconSize: 16,
	TabViewItemHeaderIconMargin: "0,0,10,0",
	TabViewItemHeaderCloseButtonHeight: 24,
	TabViewItemHeaderCloseButtonWidth: 32,
	TabViewItemHeaderCloseButtonSize: 16,
	TabViewItemHeaderCloseFontSize: 12,
	TabViewItemHeaderCloseMargin: "4,0,0,0",
	TabViewItemHeaderPaddingWithCloseButton: "8,3,4,3",
	TabViewItemHeaderPaddingWithoutCloseButton: "8,3,8,3",
	TabViewItemScrollButtonWidth: 32,
	TabViewItemScrollButtonHeight: 24,
	TabViewItemScrollButonFontSize: 8,
	TabViewItemScrollButtonPadding: "7,3,7,3",
	TabViewItemLeftScrollButtonContainerPadding: "8,0,3,3",
	TabViewItemRightScrollButtonContainerPadding: "3,0,8,3",
	TabViewItemAddButtonWidth: 32,
	TabViewItemAddButtonHeight: 24,
	TabViewItemAddButtonFontSize: 12,
	TabViewItemAddButtonContainerPadding: "3,0,0,3",
	TabViewShadowDepth: 16,
	TabViewItemSeparatorMargin: "0,8,0,8",
	TabViewItemBorderThickness: 1,
	TabViewSelectedItemBorderThickness: "1,1,1,0",
	TabViewSelectedItemHeaderMargin: "-1,0,-1,1",
	TabViewButtonBorderThickness: 0,
	TabViewItemHeaderCloseButtonBorderThickness: 0,
	TabViewBackground: "var(--SubtleFillColorTransparentBrush, transparent)",
	TabViewItemHeaderBackground: "var(--LayerOnMicaBaseAltFillColorTransparentBrush, transparent)",
	TabViewItemHeaderBackgroundSelected: "var(--SolidBackgroundFillColorTertiaryBrush, var(--background-solid-tertiary, var(--background-layer)))",
	TabViewItemHeaderDragBackground: "var(--SolidBackgroundFillColorTertiaryBrush, var(--background-solid-tertiary, var(--background-layer)))",
	TabViewItemHeaderBackgroundPointerOver: "var(--LayerOnMicaBaseAltFillColorSecondaryBrush, var(--subtle-secondary))",
	TabViewItemHeaderBackgroundPressed: "var(--LayerOnMicaBaseAltFillColorDefaultBrush, var(--subtle-tertiary))",
	TabViewItemHeaderBackgroundDisabled: "transparent",
	TabViewItemSeparator: "var(--DividerStrokeColorDefaultBrush, var(--stroke-divider))",
	TabViewBorderBrush: "var(--CardStrokeColorDefaultBrush, var(--card-stroke))",
	TabViewItemBorderBrush: "transparent"
};
for (let t of ["TabViewItemHeaderForeground", "TabViewItemIconForeground"]) for (let [n, r] of Object.entries({
	"": "Secondary",
	Pressed: "Tertiary",
	Selected: "Primary",
	PointerOver: "Secondary",
	Disabled: "Disabled"
})) e[`${t}${n}`] = `var(--TextFillColor${r}Brush, var(--text-${r.toLowerCase()}))`;
for (let t of [
	"TabViewButton",
	"TabViewScrollButton",
	"TabViewItemHeaderCloseButton"
]) for (let [n, r] of Object.entries({
	"": "Transparent",
	PointerOver: "Secondary",
	Pressed: "Tertiary",
	Disabled: "Transparent"
})) e[`${t}Background${n}`] = `var(--SubtleFillColor${r}Brush, ${r === "Transparent" ? "transparent" : `var(--subtle-${r.toLowerCase()})`})`, e[`${t}Foreground${n}`] = `var(--TextFillColor${n === "Disabled" ? "Disabled" : n === "Pressed" || t === "TabViewScrollButton" ? "Secondary" : "Primary"}Brush, var(--text-${n === "Disabled" ? "disabled" : n === "Pressed" || t === "TabViewScrollButton" ? "secondary" : "primary"}))`, e[`${t}BorderBrush${n}`] = "transparent";
for (let t of [
	"Pressed",
	"PointerOver",
	"Selected",
	"Disabled"
]) e[`TabViewItemHeader${t}CloseButtonBackground`] = "transparent", e[`TabViewItemHeader${t}CloseButtonForeground`] = `var(--TextFillColor${t === "Disabled" ? "Disabled" : "Primary"}Brush, var(--text-${t === "Disabled" ? "disabled" : "primary"}))`;
var t = Object.freeze(Object.fromEntries(Object.entries(e).map(([e, t]) => [e, typeof t == "string" && /var\(|transparent/.test(t) ? `var(--${e}, ${t})` : t])));
//#endregion
export { t as tabViewResources };

//# sourceMappingURL=tabViewResources.js.map