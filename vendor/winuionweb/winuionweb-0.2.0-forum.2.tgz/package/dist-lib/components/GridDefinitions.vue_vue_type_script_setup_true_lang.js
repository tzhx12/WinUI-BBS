import { gridDefinitionTargetKey as e } from "./layout.js";
import { defineComponent as t, provide as n } from "vue";
//#region src/components/GridDefinitions.vue?vue&type=script&setup=true&lang.ts
var r = /*@__PURE__*/ t({
	__name: "GridDefinitions",
	props: { axis: {} },
	setup(t, { expose: r }) {
		r();
		let i = t;
		n(e, i.axis);
		let a = { props: i };
		return Object.defineProperty(a, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), a;
	}
});
//#endregion
export { r as default };

//# sourceMappingURL=GridDefinitions.vue_vue_type_script_setup_true_lang.js.map