import { acrylicNoise as e } from "./acrylicNoise.js";
import { normalizeStyle as t } from "vue";
//#region src/components/acrylicBrushVisual.ts
var n = /* @__PURE__ */ new WeakMap(), r = (e) => {
	let t = document.createElement("div");
	return t.className = `win-acrylic-${e}`, Object.assign(t.style, {
		position: "absolute",
		inset: "0",
		pointerEvents: "none"
	}), t;
}, i = (e) => {
	let t = n.get(e);
	t && (clearTimeout(t.timer), e.removeEventListener("scroll", t.syncViewport), t.root.remove(), e.style.position === "relative" && !t.position && (e.style.position = ""), (e.style.isolation === "isolate" || e.style.isolation === "auto") && (e.style.isolation = t.isolation), t.hostBackdrop && (e.style.backdropFilter = t.backdropFilter, e.style.setProperty("-webkit-backdrop-filter", t.webkitBackdropFilter)), n.delete(e));
}, a = (e, t) => {
	l(e, t, !1, !0);
	let n = !1;
	return {
		update(t) {
			n || l(e, t, !1, !0);
		},
		dispose() {
			n || (n = !0, i(e));
		}
	};
}, o = (e, t) => {
	let n = a(e, t);
	return () => n.dispose();
}, s = (t, n = .03) => {
	let r = Number.isFinite(n) ? Math.max(0, Math.min(1, n)) : .03, a = {
		"--acrylic-tint": "transparent",
		"--acrylic-luminosity": "transparent",
		"--acrylic-noise": `url("${e}")`,
		"--acrylic-noise-opacity": String(r),
		"--acrylic-fallback": "transparent",
		"--acrylic-fallback-opacity": "0",
		"--acrylic-opaque": "1"
	};
	l(t, a, !1, !0);
	let o = !1;
	return {
		update() {
			o || l(t, a, !1, !0);
		},
		dispose() {
			o || (o = !0, i(t));
		}
	};
}, c = (e, t = .03) => {
	let n = s(e, t);
	return () => n.dispose();
}, l = (e, a, o = !1, s = !1) => {
	let c = t(a);
	if (!c?.["--acrylic-tint"]) {
		i(e);
		return;
	}
	let l = n.get(e);
	l && (l.hostBackdrop !== o || l.noBackdrop !== s) && (i(e), l = void 0);
	let u = !l;
	if (!l) {
		let t = r("visual");
		t.setAttribute("aria-hidden", "true"), Object.assign(t.style, {
			zIndex: "-1",
			borderRadius: "inherit",
			overflow: "hidden",
			isolation: o || s ? "auto" : "isolate"
		});
		let i = () => {
			t.style.transform = `translate(${e.scrollLeft}px, ${e.scrollTop}px)`;
		};
		l = {
			root: t,
			acrylic: r("effects"),
			blur: r("backdrop"),
			luminosity: r("luminosity"),
			tint: r("tint"),
			noise: r("noise"),
			fallback: r("fallback"),
			fallbackActive: !1,
			position: e.style.position,
			isolation: e.style.isolation,
			hostBackdrop: o,
			noBackdrop: s,
			backdropFilter: e.style.backdropFilter,
			webkitBackdropFilter: e.style.getPropertyValue("-webkit-backdrop-filter"),
			syncViewport: i
		}, l.acrylic.append(l.blur, l.luminosity, l.tint, l.noise), t.append(l.acrylic, l.fallback), n.set(e, l), e.addEventListener("scroll", i, { passive: !0 });
	}
	l.root.parentElement !== e && e.appendChild(l.root), l.acrylic.replaceChildren(l.blur, l.luminosity, l.tint, l.noise), getComputedStyle(e).position === "static" && (e.style.position = "relative"), e.style.isolation = s ? "auto" : "isolate", l.syncViewport();
	let d = c["--acrylic-fallback-opacity"] === "1", f = c["--acrylic-opaque"] === "1", p = c["--acrylic-tint-duration"] ?? "500ms", m = c["--acrylic-fallback-duration"] ?? "167ms", h = u ? "none" : `background-color ${p} linear`;
	l.root.style.opacity = c["--acrylic-brush-opacity"] ?? "1", l.acrylic.style.transition = u ? "none" : `opacity ${m} cubic-bezier(.5, 0, 0, .9)`, l.acrylic.style.opacity = d ? "0" : "1", l.luminosity.style.mixBlendMode = "luminosity", l.luminosity.style.transition = h, l.luminosity.style.backgroundColor = c["--acrylic-luminosity"], l.tint.style.mixBlendMode = f ? "normal" : "color", l.tint.style.transition = h, l.tint.style.backgroundColor = c["--acrylic-tint"], l.noise.style.backgroundImage = c["--acrylic-noise"] ?? "none", l.noise.style.backgroundRepeat = "repeat", l.noise.style.backgroundSize = "256px 256px", l.noise.style.opacity = c["--acrylic-noise-opacity"] ?? ".02", l.fallback.style.transition = u ? "none" : `opacity ${m} cubic-bezier(.5, 0, 0, .9), background-color ${p} linear`, l.fallback.style.backgroundColor = c["--acrylic-fallback"], l.fallback.style.opacity = d ? "1" : "0";
	let g = (t) => {
		if (l.noBackdrop) return;
		let n = l.hostBackdrop ? e : l.root;
		n.style.backdropFilter = t && !f ? "blur(30px)" : "none", n.style.setProperty("-webkit-backdrop-filter", t && !f ? "blur(30px)" : "none");
	};
	d ? u || l.fallbackActive ? l.timer === void 0 && g(!1) : l.timer = setTimeout(() => {
		g(!1), l.timer = void 0;
	}, Number.parseFloat(m)) : (clearTimeout(l.timer), l.timer = void 0, g(!0)), l.fallbackActive = d;
}, u = {
	mounted: (e, t) => l(e, t.value, !!t.modifiers["host-backdrop"], !!t.modifiers["no-backdrop"]),
	updated: (e, t) => l(e, t.value, !!t.modifiers["host-backdrop"], !!t.modifiers["no-backdrop"]),
	beforeUnmount: i
}, d = /* @__PURE__ */ new WeakMap(), f = (e) => {
	let t = d.get(e);
	t && (clearTimeout(t.timer), e.style.backdropFilter = t.backdropFilter, e.style.setProperty("-webkit-backdrop-filter", t.webkitBackdropFilter), d.delete(e));
}, p = (e, n) => {
	let r = (Array.isArray(n) ? n : [n]).map((e) => t(e)).filter((e) => e?.["--acrylic-tint"]);
	if (!r.length) {
		f(e);
		return;
	}
	let i = d.get(e), a = !i;
	i || (i = {
		backdropFilter: e.style.backdropFilter,
		webkitBackdropFilter: e.style.getPropertyValue("-webkit-backdrop-filter"),
		fallbackActive: !1
	}, d.set(e, i));
	let o = r.some((e) => e["--acrylic-fallback-opacity"] !== "1" && e["--acrylic-opaque"] !== "1"), s = () => {
		e.style.backdropFilter = o ? "blur(30px)" : "none", e.style.setProperty("-webkit-backdrop-filter", o ? "blur(30px)" : "none");
	};
	o ? (clearTimeout(i.timer), i.timer = void 0, s()) : a || i.fallbackActive ? i.timer === void 0 && s() : i.timer = setTimeout(() => {
		s(), i.timer = void 0;
	}, Math.max(...r.map((e) => Number.parseFloat(e["--acrylic-fallback-duration"] ?? "167ms")))), i.fallbackActive = !o;
}, m = {
	mounted: (e, t) => p(e, t.value),
	updated: (e, t) => p(e, t.value),
	beforeUnmount: f
};
//#endregion
export { a as createAcrylicMaterialLayer, s as createAcrylicNoiseLayer, o as mountAcrylicMaterialLayer, c as mountAcrylicNoiseLayer, m as vAcrylicBackdrop, u as vAcrylicBrush };

//# sourceMappingURL=acrylicBrushVisual.js.map