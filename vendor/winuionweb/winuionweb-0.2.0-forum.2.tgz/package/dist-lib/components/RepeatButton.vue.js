import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./RepeatButton.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                 */
import { createBlock as n, createCommentVNode as r, mergeProps as i, openBlock as a, renderSlot as o, withCtx as s } from "vue";
//#region src/components/RepeatButton.vue
function c(e, t, c, l, u, d) {
	return a(), n(l.Button, i({ ref: "button" }, l.buttonAttrs, {
		class: "win-repeat-button",
		Content: "{x:Bind Content, Mode=OneWay}",
		IsEnabled: "{x:Bind IsEnabled, Mode=OneWay}",
		ContentTemplate: "{x:Bind ContentTemplate}",
		ContentTransitions: "{x:Bind ContentTransitions}",
		RequestedTheme: "{x:Bind RequestedTheme}",
		ClickMode: "{x:Bind ClickMode}",
		Click: "OnRepeatClick",
		PointerPressed: "OnPointerPressed",
		PointerReleased: "OnPointerReleased",
		PointerMoved: "OnPointerMoved",
		PointerCanceled: "OnPointerCanceled",
		PointerCaptureLost: "OnPointerCanceled",
		PointerExited: "OnPointerExited",
		PointerEntered: "OnPointerEntered"
	}), {
		default: s(() => [l.hasContent ? o(e.$slots, "default", { key: 0 }) : r("", !0)]),
		_: 3
	}, 16);
}
var l = /*#__PURE__*/ e(t, [["render", c], ["__file", "RepeatButton.vue"]]);
//#endregion
export { l as default };

//# sourceMappingURL=RepeatButton.vue.js.map