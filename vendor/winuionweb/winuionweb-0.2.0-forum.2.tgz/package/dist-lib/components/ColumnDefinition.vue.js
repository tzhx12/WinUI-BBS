import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./ColumnDefinition.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                                     */
import { createElementBlock as n, openBlock as r } from "vue";
//#region src/components/ColumnDefinition.vue
var i = {
	class: "win-definition",
	"aria-hidden": "true"
};
function a(e, t, a, o, s, c) {
	return r(), n("span", i);
}
var o = /*#__PURE__*/ e(t, [
	["render", a],
	["__scopeId", "data-v-21982947"],
	["__file", "ColumnDefinition.vue"]
]);
//#endregion
export { o as default };

//# sourceMappingURL=ColumnDefinition.vue.js.map