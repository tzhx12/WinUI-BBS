import { alignment as e, boolValue as t, cssLength as n, xamlThickness as r } from "./layout.js";
import { normalizeXamlNodes as i, resolveXamlHandler as ee, resolveXamlValue as te, updateXamlBinding as a, xamlScopeKey as ne } from "./xamlRuntime.js";
import re from "./Grid.vue.js";
import { useUICommand as ie } from "./uiCommandRuntime.js";
import { animatedIconVisualSourceComponents as ae } from "./animatedIconVisuals.js";
import oe from "./AnimatedIcon.vue.js";
import { buttonContentProperty as o, getButtonContentProperty as se, useButtonContent as ce } from "./buttonContentRuntime.js";
import le from "./Button.vue.js";
import { FontIconSource as ue } from "./IconSource.js";
import { Comment as de, Fragment as s, Text as fe, cloneVNode as pe, computed as c, defineComponent as l, getCurrentInstance as me, h as u, inject as he, isVNode as ge, onBeforeUnmount as _e, onMounted as ve, provide as d, proxyRefs as ye, ref as f, shallowRef as be, useAttrs as xe, useSlots as Se, watch as p } from "vue";
//#region src/components/SplitButton.vue?vue&type=script&setup=true&lang.ts
var m = l({
	name: "SplitButton.Flyout",
	__splitButtonProperty: "flyout",
	setup() {
		return () => null;
	}
}), h = l({
	name: "SplitButton.Content",
	__splitButtonProperty: "content",
	setup() {
		return () => null;
	}
}), Ce = /*@__PURE__*/ l({
	Flyout: m,
	Content: h,
	ContentTemplate: o("SplitButton", "ContentTemplate"),
	ContentTransitions: o("SplitButton", "ContentTransitions"),
	Resources: o("SplitButton", "Resources"),
	name: "SplitButton",
	inheritAttrs: !1,
	__name: "SplitButton",
	props: {
		Content: {
			type: null,
			default: ""
		},
		Flyout: {
			type: null,
			default: void 0
		},
		ContentTemplate: {
			type: null,
			default: void 0
		},
		ContentTransitions: {
			type: null,
			default: void 0
		},
		Command: {
			type: [Object, String],
			default: void 0
		},
		CommandParameter: { default: void 0 },
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		IsTabStop: {
			type: [Boolean, String],
			default: !0
		},
		Background: {
			type: String,
			default: ""
		},
		Foreground: {
			type: String,
			default: ""
		},
		BorderBrush: {
			type: String,
			default: ""
		},
		BorderThickness: {
			type: [String, Number],
			default: 1
		},
		Width: {
			type: [String, Number],
			default: ""
		},
		Height: {
			type: [String, Number],
			default: ""
		},
		MinWidth: {
			type: [String, Number],
			default: ""
		},
		MinHeight: {
			type: [String, Number],
			default: ""
		},
		MaxWidth: {
			type: [String, Number],
			default: ""
		},
		MaxHeight: {
			type: [String, Number],
			default: ""
		},
		Padding: {
			type: [String, Number],
			default: "11,6,11,7"
		},
		Margin: {
			type: [String, Number],
			default: ""
		},
		HorizontalAlignment: {
			type: String,
			default: "Left"
		},
		VerticalAlignment: {
			type: String,
			default: "Center"
		},
		HorizontalContentAlignment: {
			type: String,
			default: "Center"
		},
		VerticalContentAlignment: {
			type: String,
			default: "Center"
		},
		FontFamily: {
			type: String,
			default: "{ThemeResource ContentControlThemeFontFamily}"
		},
		FontSize: {
			type: [String, Number],
			default: 14
		},
		FontWeight: {
			type: String,
			default: "Normal"
		},
		CornerRadius: {
			type: [String, Number],
			default: 4
		},
		UseSystemFocusVisuals: {
			type: [Boolean, String],
			default: !0
		},
		FocusVisualMargin: {
			type: [String, Number],
			default: -1
		},
		Visibility: {
			type: String,
			default: "Visible"
		},
		RequestedTheme: {
			type: String,
			default: "Default"
		}
	},
	emits: ["Click"],
	setup(o, { expose: Ce, emit: we }) {
		let g = o, Te = we, _ = xe(), v = Se(), y = me();
		d("buttonFlyoutAnchor", null), d("buttonFlyoutController", null);
		let b = (e) => te(e, y), { ContentTemplate: x, ContentTransitions: S, renderTemplate: Ee } = ce(g, () => v.default?.() ?? [], y), C = f(null), De = f(null), Oe = f(null), w = f(null), T = f(!1), E = f(""), D = f(!1), O = f(!1), k = f(!1), A = f(!1), j = f("mouse"), M = he("toggleSplitButtonState", null), N = c(() => M?.IsChecked.value ?? !1), P = c(() => t(b(g.IsEnabled))), F = f(), I = c({
			get: () => (F.value ?? P.value) && (W.value?.CanExecute?.(G.value) ?? !0),
			set: (e) => {
				F.value = t(e), a(g.IsEnabled, F.value, y);
			}
		}), ke = c(() => t(b(g.IsTabStop))), L = c(() => b(g.Content)), R = be(void 0);
		p(L, () => {
			R.value = void 0;
		});
		let z = c({
			get: () => R.value === void 0 ? L.value : R.value,
			set: (e) => {
				R.value = e, a(g.Content, e, y);
			}
		}), B = c(() => b(g.Flyout)), V = be(void 0);
		p(B, () => {
			V.value = void 0;
		});
		let H = c(() => String(b(g.RequestedTheme))), U = f();
		p(H, () => {
			U.value = void 0;
		});
		let Ae = c({
			get: () => U.value ?? H.value,
			set: (e) => {
				U.value = e, a(g.RequestedTheme, e, y);
			}
		}), W = ie(() => b(g.Command)), G = c(() => b(g.CommandParameter)), je = ae.AnimatedChevronDownSmallVisualSource, K = c(() => {
			let e = [], t = [], n = (r) => {
				for (let i of r) {
					if (i.type === de || i.type === fe && !String(i.children ?? "").trim()) continue;
					if (i.type === s && Array.isArray(i.children)) {
						n(i.children);
						continue;
					}
					if (se(i)) continue;
					let r = i.type?.__splitButtonProperty;
					if (r) {
						let n = i.children?.default;
						n && (r === "flyout" ? t : e).push(...n());
					} else e.push(i);
				}
			};
			return n(v.default?.() ?? []), {
				main: e,
				flyout: t
			};
		}), Me = c(() => {
			if (V.value === void 0 && K.value.flyout.length) return K.value.flyout;
			let e = V.value === void 0 ? B.value : V.value;
			return ge(e) ? [e] : [];
		}), Ne = l({ setup: () => () => {
			let e = Ee(z.value);
			if (e) return e;
			if (R.value === void 0 && K.value.main.length) {
				let e = i(K.value.main, y);
				return e.every((e) => e.type === fe) ? u("span", { class: "win-button-default-text" }, e.map((e) => String(e.children ?? "")).join("")) : u(s, e);
			}
			return typeof z.value == "string" || typeof z.value == "number" ? u("span", { class: "win-button-default-text" }, String(z.value)) : ge(z.value) ? u(s, i([z.value], y)) : null;
		} }), Pe = l({ setup: () => () => u(s, i(Me.value, y).map((e) => pe(e, {
			ref: (e) => {
				w.value = e;
			},
			onOpened: () => {
				T.value = !0;
			},
			onClosed: () => {
				T.value = !1;
			}
		}, !0))) }), q = c({
			get: () => V.value !== void 0 && !ge(V.value) ? V.value : w.value ?? B.value,
			set: (e) => {
				q.value?.Hide?.(), w.value = null, V.value = e, T.value = !1, a(g.Flyout, e, y);
			}
		}), Fe = c(() => b(g.Padding)), Ie = c(() => b(g.CornerRadius)), Le = c(() => b(g.FontFamily)), Re = c(() => b(g.FontSize)), ze = c(() => b(g.FontWeight)), Be = c(() => b(g.HorizontalContentAlignment)), Ve = c(() => b(g.VerticalContentAlignment)), J = (e) => `var(--SplitButton${e})`, He = c(() => !!E.value || j.value === "touch" && (k.value || A.value)), Y = c(() => T.value || He.value ? "Pressed" : ""), Ue = c(() => I.value ? !N.value && !Y.value && !D.value && !k.value && g.Background ? b(g.Background) : J(`Background${N.value ? "Checked" : ""}${Y.value || (k.value ? "Pressed" : D.value && j.value !== "touch" ? "PointerOver" : "")}`) : "transparent"), We = c(() => I.value ? !N.value && !Y.value && !O.value && !A.value && g.Background ? b(g.Background) : J(`Background${N.value ? "Checked" : ""}${Y.value || (A.value ? "Pressed" : O.value && j.value !== "touch" ? "PointerOver" : "")}`) : "transparent"), Ge = c(() => I.value ? !N.value && !Y.value && !D.value && !k.value && g.Foreground ? b(g.Foreground) : J(`Foreground${N.value ? "Checked" : ""}${Y.value || (k.value ? "Pressed" : D.value && j.value !== "touch" ? "PointerOver" : "")}`) : J("ForegroundDisabled")), Ke = c(() => I.value ? N.value ? J(`ForegroundChecked${Y.value || (A.value ? "Pressed" : O.value ? "PointerOver" : "")}`) : J(Y.value || A.value ? "ForegroundSecondaryPressed" : O.value ? "ForegroundPointerOver" : "ForegroundSecondary") : J("ForegroundDisabled")), X = c(() => I.value ? !N.value && !Y.value && !k.value && g.BorderBrush ? b(g.BorderBrush) : J(`BorderBrush${N.value ? "Checked" : ""}${Y.value || (!N.value && k.value ? "Pressed" : "")}`) : J("BorderBrushDisabled")), qe = c(() => I.value ? !N.value && !Y.value && !A.value && g.BorderBrush ? b(g.BorderBrush) : J(`BorderBrush${N.value ? "Checked" : ""}${Y.value || (!N.value && A.value ? "Pressed" : "")}`) : J("BorderBrushDisabled")), Je = c(() => J(N.value ? "BorderBrushCheckedDivider" : "BorderBrushDivider")), Ye = c(() => {
			let e = Object.fromEntries(Object.entries(_).filter(([e]) => ![
				"class",
				"style",
				"Click",
				"onClick"
			].includes(e))), t = e["AutomationProperties.Name"];
			return delete e["AutomationProperties.Name"], t && (e["aria-label"] = String(b(t))), e;
		}), Xe = c(() => {
			let t = {
				margin: r(b(g.Margin)),
				justifySelf: e(b(g.HorizontalAlignment), "horizontal"),
				alignSelf: e(b(g.VerticalAlignment), "vertical"),
				outlineOffset: n(b(g.FocusVisualMargin))
			};
			t["--SplitButtonPrimaryBorderBrush"] = X.value, t["--SplitButtonSecondaryBorderBrush"] = qe.value;
			for (let e of [
				"Width",
				"Height",
				"MinWidth",
				"MinHeight",
				"MaxWidth",
				"MaxHeight"
			]) b(g[e]) !== "" && (t[e[0].toLowerCase() + e.slice(1)] = n(b(g[e])));
			return b(g.Visibility) === "Collapsed" && (t.display = "none"), b(g.Visibility) === "Hidden" && (t.visibility = "hidden"), [_.style, t];
		}), Z = ye({
			IsEnabled: I,
			RequestedTheme: Ae,
			ContentTemplate: x,
			ContentTransitions: S,
			Name: c(() => _["data-xaml-ref"] ?? _["x:Name"] ?? _.Name ?? ""),
			Content: c({
				get: () => R.value === void 0 ? K.value.main[0] ?? z.value : R.value,
				set: (e) => {
					z.value = e;
				}
			}),
			Flyout: q,
			Command: W,
			CommandParameter: G,
			Element: C,
			IsFlyoutOpen: T,
			Focus: () => (C.value?.focus(), I.value)
		});
		Ce(Z);
		function Ze(e) {
			if (!I.value) return;
			M?.Invoke(e);
			let t = {
				OriginalSource: Z,
				OriginalEvent: e
			};
			Te("Click", Z, t), ee(_.Click, y)?.(Z, t), (W.value?.CanExecute?.(G.value) ?? !0) && W.value?.Execute(G.value);
		}
		function Qe() {
			I.value && q.value?.ShowAt && q.value.ShowAt(C.value, { Placement: "BottomEdgeAlignedLeft" });
		}
		function $e(e, t) {
			C.value?.focus({ preventScroll: !0 }), Ze(t?.OriginalEvent);
		}
		function et() {
			C.value?.focus({ preventScroll: !0 }), Qe();
		}
		function Q(e) {
			j.value = e?.OriginalEvent?.pointerType ?? "mouse";
		}
		function tt(e, t) {
			Q(t), D.value = !0;
		}
		function nt(e, t) {
			Q(t), D.value = !1, k.value = !1;
		}
		function rt(e, t) {
			Q(t), k.value = !0;
		}
		function it(e, t) {
			Q(t), k.value = !1;
		}
		function at(e) {
			k.value = e.IsPressed, D.value = e.IsPointerOver;
		}
		function ot(e, t) {
			Q(t), O.value = !0;
		}
		function st(e, t) {
			Q(t), O.value = !1, A.value = !1;
		}
		function ct(e, t) {
			Q(t), A.value = !0;
		}
		function lt(e, t) {
			Q(t), A.value = !1;
		}
		function ut(e) {
			A.value = e.IsPressed, O.value = e.IsPointerOver;
		}
		function $() {
			E.value = "", k.value = !1, A.value = !1;
		}
		function dt(e) {
			!I.value || e.target !== C.value || ((e.key === " " || e.key === "Enter") && (e.preventDefault(), e.repeat || (E.value = e.key)), (e.key === "F4" || e.key === "ArrowDown" && e.altKey) && e.preventDefault());
		}
		function ft(e) {
			if (!(!I.value || e.target !== C.value)) if (e.key === " " || e.key === "Enter") {
				e.preventDefault();
				let t = E.value === e.key;
				$(), t && Ze(e);
			} else (e.key === "F4" || e.key === "ArrowDown" && e.altKey) && (e.preventDefault(), Qe());
		}
		p(P, () => {
			F.value = void 0;
		}), p(I, (e) => {
			e || ($(), q.value?.Hide?.());
		}), ve(() => window.addEventListener("blur", $)), _e(() => {
			window.removeEventListener("blur", $), q.value?.Hide?.();
		}), d(ne, {
			...he(ne, {}),
			IsEnabled: I,
			Content: z,
			ContentTemplate: x,
			ContentTransitions: S,
			CornerRadius: Ie,
			Padding: Fe,
			FontFamily: Le,
			FontSize: Re,
			FontWeight: ze,
			HorizontalContentAlignment: Be,
			VerticalContentAlignment: Ve,
			PrimaryBackground: Ue,
			SecondaryBackground: We,
			PrimaryForeground: Ge,
			SecondaryForeground: Ke,
			PrimaryBorderBrush: X,
			SecondaryBorderBrush: qe,
			DividerBackground: Je,
			OnPrimaryClick: $e,
			OnSecondaryClick: et,
			OnPrimaryEntered: tt,
			OnPrimaryExited: nt,
			OnPrimaryPressed: rt,
			OnPrimaryReleased: it,
			OnPrimaryMoved: at,
			OnSecondaryEntered: ot,
			OnSecondaryExited: st,
			OnSecondaryPressed: ct,
			OnSecondaryReleased: lt,
			OnSecondaryMoved: ut
		});
		let pt = {
			SplitButtonFlyout: m,
			SplitButtonContent: h,
			props: g,
			emit: Te,
			attrs: _,
			slots: v,
			instance: y,
			resolve: b,
			ContentTemplate: x,
			ContentTransitions: S,
			renderTemplate: Ee,
			root: C,
			primaryButton: De,
			secondaryButton: Oe,
			attachedFlyout: w,
			isOpen: T,
			keyPressed: E,
			primaryOver: D,
			secondaryOver: O,
			primaryPressed: k,
			secondaryPressed: A,
			pointerType: j,
			internalChecked: M,
			checked: N,
			sourceEnabled: P,
			localEnabled: F,
			IsEnabled: I,
			IsTabStop: ke,
			sourceContent: L,
			localContent: R,
			Content: z,
			sourceFlyout: B,
			localFlyout: V,
			sourceRequestedTheme: H,
			localRequestedTheme: U,
			RequestedTheme: Ae,
			Command: W,
			CommandParameter: G,
			AnimatedChevronDownSmallVisualSource: je,
			propertyNodes: K,
			flyoutNodes: Me,
			MainOutlet: Ne,
			FlyoutOutlet: Pe,
			Flyout: q,
			Padding: Fe,
			CornerRadius: Ie,
			FontFamily: Le,
			FontSize: Re,
			FontWeight: ze,
			HorizontalContentAlignment: Be,
			VerticalContentAlignment: Ve,
			resource: J,
			touchPressed: He,
			commonSuffix: Y,
			PrimaryBackground: Ue,
			SecondaryBackground: We,
			PrimaryForeground: Ge,
			SecondaryForeground: Ke,
			PrimaryBorderBrush: X,
			SecondaryBorderBrush: qe,
			DividerBackground: Je,
			hostAttrs: Ye,
			hostStyle: Xe,
			api: Z,
			invoke: Ze,
			openFlyout: Qe,
			onPrimaryClick: $e,
			onSecondaryClick: et,
			pointer: Q,
			onPrimaryEntered: tt,
			onPrimaryExited: nt,
			onPrimaryPressed: rt,
			onPrimaryReleased: it,
			onPrimaryMoved: at,
			onSecondaryEntered: ot,
			onSecondaryExited: st,
			onSecondaryPressed: ct,
			onSecondaryReleased: lt,
			onSecondaryMoved: ut,
			clearKey: $,
			onKeyDown: dt,
			onKeyUp: ft,
			Grid: re,
			Button: le,
			AnimatedIcon: oe,
			get FontIconSource() {
				return ue;
			},
			get boolValue() {
				return t;
			}
		};
		return Object.defineProperty(pt, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), pt;
	}
});
//#endregion
export { h as SplitButtonContent, m as SplitButtonFlyout, Ce as default };

//# sourceMappingURL=SplitButton.vue_vue_type_script_setup_true_lang.js.map