import { alignment as e, boolValue as t, cssLength as n, xamlThickness as r } from "./layout.js";
import { normalizeXamlNodes as ee, resolveXamlHandler as te, resolveXamlValue as ne, updateXamlBinding as re, xamlScopeKey as i } from "./xamlRuntime.js";
import { useUICommand as ie } from "./uiCommandRuntime.js";
import ae from "./ContentPresenter.vue.js";
import { buttonContentProperty as a, getButtonContentProperty as oe, useButtonContent as se } from "./buttonContentRuntime.js";
import { Fragment as o, Text as ce, computed as s, defineComponent as c, getCurrentInstance as le, h as l, inject as ue, isVNode as de, onBeforeUnmount as fe, onMounted as pe, provide as u, proxyRefs as me, ref as d, useAttrs as he, useSlots as ge, watch as f } from "vue";
//#region src/components/HyperlinkButton.vue?vue&type=script&setup=true&lang.ts
var p = c({
	name: "HyperlinkButton.Content",
	__hyperlinkButtonProperty: "content",
	setup() {
		return () => null;
	}
}), m = /*@__PURE__*/ c({
	Content: p,
	ContentTemplate: a("HyperlinkButton", "ContentTemplate"),
	ContentTransitions: a("HyperlinkButton", "ContentTransitions"),
	Resources: a("HyperlinkButton", "Resources"),
	name: "HyperlinkButton",
	inheritAttrs: !1,
	__name: "HyperlinkButton",
	props: {
		Content: {
			type: null,
			default: ""
		},
		NavigateUri: {
			type: String,
			default: ""
		},
		TargetName: {
			type: String,
			default: ""
		},
		ContentTemplate: {
			type: null,
			default: void 0
		},
		ContentTransitions: {
			type: null,
			default: void 0
		},
		RequestedTheme: {
			type: String,
			default: "Default"
		},
		Command: {
			type: [Object, String],
			default: void 0
		},
		CommandParameter: {
			type: null,
			default: void 0
		},
		ClickMode: {
			type: String,
			default: "Release"
		},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		IsTabStop: {
			type: [Boolean, String],
			default: !0
		},
		Visibility: {
			type: String,
			default: "Visible"
		},
		Background: {
			type: String,
			default: ""
		},
		BackgroundSizing: {
			type: String,
			default: "OuterBorderEdge"
		},
		Foreground: {
			type: String,
			default: ""
		},
		BorderBrush: {
			type: String,
			default: ""
		},
		BorderThickness: {
			type: [String, Number],
			default: 1
		},
		Width: {
			type: [String, Number],
			default: ""
		},
		Height: {
			type: [String, Number],
			default: ""
		},
		MinWidth: {
			type: [String, Number],
			default: ""
		},
		MinHeight: {
			type: [String, Number],
			default: ""
		},
		MaxWidth: {
			type: [String, Number],
			default: ""
		},
		MaxHeight: {
			type: [String, Number],
			default: ""
		},
		Margin: {
			type: [String, Number],
			default: ""
		},
		Padding: {
			type: [String, Number],
			default: "11,5,11,6"
		},
		HorizontalAlignment: {
			type: String,
			default: "Left"
		},
		VerticalAlignment: {
			type: String,
			default: "Center"
		},
		HorizontalContentAlignment: {
			type: String,
			default: "Left"
		},
		VerticalContentAlignment: {
			type: String,
			default: "Top"
		},
		FontFamily: {
			type: String,
			default: ""
		},
		FontSize: {
			type: [String, Number],
			default: 14
		},
		FontWeight: {
			type: String,
			default: "Normal"
		},
		CornerRadius: {
			type: [String, Number],
			default: 4
		},
		UseSystemFocusVisuals: {
			type: [Boolean, String],
			default: !0
		},
		FocusVisualMargin: {
			type: [String, Number],
			default: -3
		}
	},
	emits: ["Click"],
	setup(a, { expose: m, emit: _e }) {
		let h = a, g = _e, _ = he(), v = ge(), y = le(), b = d(null), x = (e) => ne(e, y), { ContentTemplate: S, ContentTransitions: C, renderTemplate: w } = se(h, () => v.default?.() ?? [], y), T = (e) => {
			let t = s(() => x(h[e])), n = d(void 0);
			return f(t, () => {
				n.value = void 0;
			}), s({
				get: () => n.value === void 0 ? t.value : n.value,
				set: (t) => {
					n.value = t, re(h[e], t, y);
				}
			});
		}, E = T("Content"), D = T("NavigateUri"), ve = c({
			inheritAttrs: !1,
			setup(e, { attrs: t, slots: n }) {
				return () => l(D.value ? "a" : "button", {
					...t,
					ref: b
				}, n.default?.());
			}
		}), O = T("RequestedTheme"), k = T("IsEnabled"), A = ie(() => x(h.Command)), j = s(() => x(h.CommandParameter)), M = s({
			get: () => t(k.value) && (A.value?.CanExecute?.(j.value) ?? !0),
			set: (e) => {
				k.value = t(e);
			}
		}), N = s(() => t(x(h.IsTabStop))), P = s(() => t(x(h.UseSystemFocusVisuals))), F = s(() => String(x(h.TargetName) ?? "")), I = d(!1), L = s(() => String(x(h.ClickMode))), R = !1, z = null, B = null, ye = s(() => {
			let e = Object.fromEntries(Object.entries(_).filter(([e]) => ![
				"class",
				"style",
				"Click",
				"onClick"
			].includes(e)));
			for (let t of ["AutomationProperties.Name", "ToolTipService.ToolTip"]) {
				let n = Object.keys(e).find((e) => e.toLowerCase() === t.toLowerCase());
				if (!n) continue;
				let r = x(e[n]);
				delete e[n], r != null && r !== "" && (e[t === "AutomationProperties.Name" ? "aria-label" : "tooltipservice.tooltip"] = String(r));
			}
			return e;
		}), be = s(() => {
			let t = {
				margin: r(x(h.Margin)),
				justifySelf: e(x(h.HorizontalAlignment), "horizontal"),
				alignSelf: e(x(h.VerticalAlignment), "vertical"),
				fontFamily: x(h.FontFamily) || "var(--ContentControlThemeFontFamily)",
				fontSize: n(x(h.FontSize)),
				fontWeight: x(h.FontWeight) === "SemiBold" ? "600" : String(x(h.FontWeight) || "normal")
			};
			for (let e of [
				"Width",
				"Height",
				"MinWidth",
				"MinHeight",
				"MaxWidth",
				"MaxHeight"
			]) x(h[e]) !== "" && (t[e[0].toLowerCase() + e.slice(1)] = n(x(h[e])));
			return x(h.Visibility) === "Collapsed" && (t.display = "none"), x(h.Visibility) === "Hidden" && (t.visibility = "hidden"), h.Background && (t["--HyperlinkButtonBackground"] = x(h.Background)), h.Foreground && (t["--HyperlinkButtonForeground"] = x(h.Foreground)), h.BorderBrush && (t["--HyperlinkButtonBorderBrush"] = x(h.BorderBrush)), t.outlineOffset = n(x(h.FocusVisualMargin)), [_.style, t];
		}), xe = c({
			name: "HyperlinkButtonContent",
			setup() {
				return () => {
					let e = w(E.value);
					if (e) return e;
					if (v.default) {
						let e = (t) => t.flatMap((t) => t.type === o && Array.isArray(t.children) ? e(t.children) : oe(t) ? [] : t.type?.__hyperlinkButtonProperty === "content" ? t.children?.default?.() ?? [] : [t]), t = ee(e(v.default()), y);
						return t.every((e) => e.type === ce) ? l("span", { class: "win-button-default-text" }, t.map((e) => String(e.children ?? "")).join("")) : l(o, t);
					}
					return de(E.value) ? E.value : typeof E.value == "string" || typeof E.value == "number" ? l("span", { class: "win-button-default-text" }, String(E.value)) : null;
				};
			}
		}), V = s(() => "var(--HyperlinkButtonCurrentBackground, var(--HyperlinkButtonBackground, transparent))"), H = s(() => "var(--HyperlinkButtonCurrentBorderBrush, var(--HyperlinkButtonBorderBrush, transparent))"), U = s(() => x(h.BorderThickness)), W = s(() => x(h.Padding)), G = s(() => x(h.BackgroundSizing)), K = s(() => x(h.CornerRadius)), q = s(() => x(h.HorizontalContentAlignment)), J = s(() => x(h.VerticalContentAlignment));
		u(i, {
			...ue(i, {}),
			ContentTemplate: S,
			ContentTransitions: C,
			PresenterBackground: V,
			PresenterBackgroundSizing: G,
			PresenterBorderBrush: H,
			PresenterBorderThickness: U,
			PresenterPadding: W,
			PresenterCornerRadius: K,
			PresenterHorizontalAlignment: q,
			PresenterVerticalAlignment: J
		});
		let Y = me({
			IsEnabled: M,
			NavigateUri: D,
			Content: E,
			ContentTemplate: S,
			ContentTransitions: C,
			RequestedTheme: O,
			Command: A,
			CommandParameter: j,
			Name: s(() => _["data-xaml-ref"] ?? _["x:Name"] ?? _.Name ?? ""),
			Element: b,
			IsPressed: I,
			Focus: () => (b.value?.focus(), M.value)
		});
		m(Y);
		function Se(e) {
			if (!M.value) {
				e.preventDefault(), e.stopPropagation();
				return;
			}
			if (e.detail > 0 && (R || L.value === "Hover")) {
				R = !1, e.preventDefault();
				return;
			}
			let t = {
				OriginalSource: Y,
				OriginalEvent: e,
				Handled: !1
			};
			g("Click", Y, t), te(_.Click, y)?.(Y, t), (A.value?.CanExecute?.(j.value) ?? !0) && A.value?.Execute(j.value), t.Handled && e.preventDefault();
		}
		function X() {
			let e = z;
			if (z = null, I.value = !1, B = null, e !== null && b.value?.hasPointerCapture?.(e)) try {
				b.value.releasePointerCapture(e);
			} catch {}
		}
		function Z(e) {
			let t = b.value?.getBoundingClientRect();
			return !!(t && e.clientX >= t.left && e.clientX <= t.right && e.clientY >= t.top && e.clientY <= t.bottom);
		}
		function Ce(e) {
			z === e.pointerId && (I.value = Z(e));
		}
		function Q() {
			I.value = !1;
		}
		function we(e) {
			z === e.pointerId && !Z(e) && (R = !0), X();
		}
		function Te() {
			R = !0, X();
		}
		function Ee(e) {
			!M.value || e.button !== 0 || L.value === "Hover" || (R = !1, z = e.pointerId, I.value = !0, b.value?.setPointerCapture?.(e.pointerId), L.value === "Press" && (b.value?.click(), R = !0));
		}
		function De(e) {
			z === e.pointerId && e.buttons > 0 && (I.value = !0), e.pointerType !== "touch" && M.value && L.value === "Hover" && b.value?.click();
		}
		function Oe(e) {
			if (!(!M.value || L.value === "Hover")) {
				if (e.key !== " " && e.key !== "Enter") {
					X();
					return;
				}
				e.preventDefault(), !(e.repeat || I.value || z !== null) && (B = e.key, I.value = !0, L.value === "Press" && b.value?.click());
			}
		}
		function ke(e) {
			if (e.key !== " " && e.key !== "Enter") return;
			e.preventDefault();
			let t = M.value && I.value && B === e.key;
			X(), t && L.value === "Release" && b.value?.click();
		}
		f(M, X), pe(() => window.addEventListener("blur", X)), fe(() => window.removeEventListener("blur", X));
		let $ = {
			HyperlinkButtonContent: p,
			props: h,
			emit: g,
			attrs: _,
			slots: v,
			instance: y,
			root: b,
			resolve: x,
			ContentTemplate: S,
			ContentTransitions: C,
			renderTemplate: w,
			property: T,
			Content: E,
			NavigateUri: D,
			NativeHyperlinkHost: ve,
			RequestedTheme: O,
			IsEnabledProperty: k,
			Command: A,
			CommandParameter: j,
			IsEnabled: M,
			IsTabStop: N,
			UseSystemFocusVisuals: P,
			TargetName: F,
			pressed: I,
			ClickMode: L,
			get suppressPointerClick() {
				return R;
			},
			set suppressPointerClick(e) {
				R = e;
			},
			get activePointer() {
				return z;
			},
			set activePointer(e) {
				z = e;
			},
			get pressedKey() {
				return B;
			},
			set pressedKey(e) {
				B = e;
			},
			buttonAttrs: ye,
			hostStyle: be,
			ContentOutlet: xe,
			PresenterBackground: V,
			PresenterBorderBrush: H,
			PresenterBorderThickness: U,
			PresenterPadding: W,
			PresenterBackgroundSizing: G,
			PresenterCornerRadius: K,
			PresenterHorizontalAlignment: q,
			PresenterVerticalAlignment: J,
			publicApi: Y,
			onClick: Se,
			clearPressed: X,
			pointerInside: Z,
			onPointerMoved: Ce,
			onPointerExited: Q,
			onPointerReleased: we,
			onPointerCanceled: Te,
			onPointerDown: Ee,
			onPointerEntered: De,
			onKeyDown: Oe,
			onKeyUp: ke,
			ContentPresenter: ae
		};
		return Object.defineProperty($, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), $;
	}
});
//#endregion
export { p as HyperlinkButtonContent, m as default };

//# sourceMappingURL=HyperlinkButton.vue_vue_type_script_setup_true_lang.js.map