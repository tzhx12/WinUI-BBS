import { normalizeXamlNodes as e, resolveXamlHandler as t, resolveXamlValue as n, updateXamlBinding as r } from "./xamlRuntime.js";
import { brushProperty as i, isBrushProperty as a, useBrushProperty as o } from "./brushProperties.js";
import { isThemeShadow as ee } from "./themeShadowRuntime.js";
import { clearThemeShadowVisual as te, setThemeShadowVisual as ne } from "./themeShadowVisual.js";
import { fitPopupPosition as re, popupBoundsFor as ie, popupPlacementPosition as ae, resolvePopupElement as oe } from "./popupRuntime.js";
import { Fragment as se, computed as s, defineComponent as c, getCurrentInstance as ce, h as le, inject as ue, isVNode as de, nextTick as fe, onBeforeUnmount as pe, onMounted as me, onUpdated as he, ref as l, shallowRef as u, unref as ge, useAttrs as _e, useSlots as ve, watch as d, watchEffect as ye } from "vue";
//#region src/components/Popup.vue?vue&type=script&setup=true&lang.ts
var be = c({
	name: "Popup.Child",
	__popupProperty: "child",
	setup() {
		return () => null;
	}
}), xe = /*@__PURE__*/ c({
	Child: be,
	Shadow: i("Popup", "Shadow"),
	name: "Popup",
	inheritAttrs: !1,
	__name: "Popup",
	props: {
		IsOpen: {
			type: [Boolean, String],
			default: void 0
		},
		Child: {
			type: [Object, String],
			default: void 0
		},
		Shadow: {
			type: [Object, String],
			default: null
		},
		Translation: {
			type: [Object, String],
			default: () => ({
				X: 0,
				Y: 0,
				Z: 0
			})
		},
		HorizontalOffset: {
			type: [Number, String],
			default: 0
		},
		VerticalOffset: {
			type: [Number, String],
			default: 0
		},
		IsLightDismissEnabled: {
			type: [Boolean, String],
			default: !1
		},
		LightDismissOverlayMode: {
			type: String,
			default: "Off"
		},
		ShouldConstrainToRootBounds: {
			type: [Boolean, String],
			default: !0
		},
		PlacementTarget: {
			type: [Object, String],
			default: null
		},
		DesiredPlacement: {
			type: String,
			default: "Auto"
		},
		RequestedTheme: {
			type: String,
			default: "Default"
		},
		FlowDirection: {
			type: String,
			default: "LeftToRight"
		}
	},
	emits: [
		"update:IsOpen",
		"update:Child",
		"update:Shadow",
		"update:Translation",
		"Opened",
		"Closed",
		"ActualPlacementChanged"
	],
	setup(i, { expose: xe, emit: Se }) {
		let f = i, p = Se, m = ce(), h = _e(), Ce = ve(), we = ue("winuiTheme", null), g = (e) => n(e, m), Te = s(() => Object.fromEntries(Object.entries(h).filter(([e]) => /^(?:Grid\.(?:Row|Column|RowSpan|ColumnSpan)|Canvas\.(?:Left|Top)|HorizontalAlignment|VerticalAlignment|Margin|data-xaml-ref)$/i.test(e)).map(([e, t]) => [e, g(t)]))), _ = (e) => g(e) === !0 || g(e) === "True", v = (e) => {
			let t = Number(g(e));
			return Number.isFinite(t) ? t : 0;
		}, y = (e, t) => {
			let n = u(void 0);
			return d(() => g(f[e]), () => {
				n.value = void 0;
			}), s({
				get: () => t(n.value === void 0 ? g(f[e]) : n.value),
				set: (t) => {
					n.value = t, r(f[e], t, m);
				}
			});
		}, b = l(null), x = l(null), S = l(null), C = l(_(f.IsOpen)), w = l("Auto"), T = l({
			left: 0,
			top: 0,
			width: 0,
			height: 0,
			rootLeft: 0,
			rootTop: 0,
			ready: !1
		}), E = y("IsLightDismissEnabled", _), D = y("FlowDirection", String), O = y("HorizontalOffset", v), k = y("VerticalOffset", v), A = y("PlacementTarget", oe), j = y("DesiredPlacement", String), Ee = y("RequestedTheme", String), M = y("ShouldConstrainToRootBounds", _), De = y("LightDismissOverlayMode", String), N = u([]), Oe = o("Shadow", () => f.Shadow, () => N.value, m), P = u(), F = s({
			get: () => P.value === void 0 ? Oe.value.value : P.value,
			set: (e) => {
				P.value = e, r(f.Shadow, e, m), p("update:Shadow", e);
			}
		});
		d(() => g(f.Shadow), () => {
			P.value = void 0;
		});
		let ke = y("Translation", (e) => e), I = s({
			get: () => ke.value,
			set: (e) => {
				ke.value = e, p("update:Translation", e);
			}
		}), L = s(() => {
			let e = I.value;
			return (typeof e == "string" ? e.split(",").map(Number) : [
				e?.X ?? 0,
				e?.Y ?? 0,
				e?.Z ?? 0
			]).map((e) => Number(e) || 0);
		}), R = u(void 0), Ae = u(null), z = s(() => R.value === void 0 ? g(f.Child) : R.value);
		d(() => g(f.Child), () => {
			R.value = void 0;
		});
		let je = s(() => {
			let e = Ee.value.toLowerCase(), t = String(ge(we) ?? "").toLowerCase(), n = e === "light" || e === "dark" ? e : t;
			return n === "light" || n === "dark" ? `win-theme-scope theme-${n}` : "";
		}), Me = s(() => ({
			left: `${T.value.left}px`,
			top: `${T.value.top}px`,
			maxWidth: `${T.value.width}px`,
			maxHeight: `${T.value.height}px`,
			visibility: T.value.ready ? "visible" : "hidden",
			transform: L.value[0] || L.value[1] ? `translate(${L.value[0]}px, ${L.value[1]}px)` : void 0
		})), Ne = s(() => ({
			left: `${T.value.rootLeft}px`,
			top: `${T.value.rootTop}px`,
			width: `${T.value.width}px`,
			height: `${T.value.height}px`,
			visibility: T.value.ready ? "visible" : "hidden"
		})), B = (e) => {
			let t = [];
			for (let n of e) if (n.type === se && Array.isArray(n.children)) t.push(...B(n.children));
			else if (n.type.__popupProperty === "child") {
				let e = n.children?.default;
				t.push(...e?.() ?? []);
			} else a(n) || t.push(n);
			return t;
		}, Pe = c({
			name: "PopupChildOutlet",
			setup() {
				return () => {
					N.value = Ce.default?.() ?? [], F.value;
					let t = z.value;
					return le(se, e(t === void 0 ? B(N.value) : de(t) ? [t] : [], m));
				};
			}
		}), V = null, H = u(null), U = () => {
			let e = x.value;
			if (!e) return;
			let t = z.value, n = oe(t);
			V && V !== n && V.parentElement === e && V.remove(), V = n, n && n.parentElement !== e && e.appendChild(n);
			let r = Array.from(e.children).find((e) => e !== S.value);
			Ae.value = t === void 0 ? r ?? null : t, H.value = r ?? null;
		}, Fe = Symbol("Popup.Child delegated ThemeShadow"), Ie = () => {
			S.value && te(S.value, Fe);
		}, W = () => {
			let e = S.value, t = x.value, n = H.value;
			if (!e || !t || !n) return;
			let r = n.getBoundingClientRect(), i = t.getBoundingClientRect();
			Object.assign(e.style, {
				left: `${r.left - i.left}px`,
				top: `${r.top - i.top}px`,
				width: `${r.width}px`,
				height: `${r.height}px`
			});
		}, Le = (e) => {
			let t = e, n = t.__vueParentComponent;
			return n?.vnode.el === e && n.exposed && "Shadow" in n.exposed ? ge(n.exposed.Shadow) : t.Shadow;
		};
		ye(() => {
			let e = H.value, t = S.value, n = F.value, r = e ? Le(e) : null;
			if (!C.value || !t || !e || !ee(n) || n.IsDisposed || ee(r) && !r.IsDisposed) {
				Ie();
				return;
			}
			W();
			let i = getComputedStyle(e), a = Math.max(...[
				i.borderTopLeftRadius,
				i.borderTopRightRadius,
				i.borderBottomRightRadius,
				i.borderBottomLeftRadius
			].map((e) => Number.parseFloat(e) || 0));
			ne(t, {
				Shadow: n,
				Caster: e,
				Translation: I.value,
				Theme: je.value,
				CornerRadius: a
			}, Fe);
		}, { flush: "post" });
		let Re = s({
			get: () => z.value === void 0 ? Ae.value : z.value,
			set: (e) => {
				if (e !== null && !de(e) && !oe(e)) throw TypeError("Popup.Child must be a UIElement or null");
				R.value = e, r(f.Child, e, m), p("update:Child", e);
			}
		});
		d(z, async () => {
			await fe(), U(), C.value && $();
		}, { flush: "post" }), me(U), he(U);
		let G = (e) => {
			e !== C.value && (C.value = e, r(f.IsOpen, e, m), p("update:IsOpen", e));
		}, ze = s({
			get: () => C.value,
			set: (e) => G(!!e)
		}), Be = {
			IsOpen: ze,
			ActualPlacement: s(() => w.value),
			HorizontalOffset: O,
			VerticalOffset: k,
			PlacementTarget: A,
			DesiredPlacement: j,
			IsLightDismissEnabled: E,
			LightDismissOverlayMode: De,
			RequestedTheme: Ee,
			FlowDirection: D,
			ShouldConstrainToRootBounds: M,
			IsConstrainedToRootBounds: s(() => M.value),
			Child: Re,
			Shadow: F,
			Translation: I,
			Element: x
		};
		xe(Be);
		let K = (e) => {
			let n = m?.exposeProxy ?? new Proxy(Be, { get: (e, t) => ge(Reflect.get(e, t)) }), r = m?.vnode.props?.[`on${e}`];
			typeof r == "function" ? r(n, {}) : Array.isArray(r) ? r.forEach((e) => e(n, {})) : (p(e, n, {}), t(h[e], m)?.(n, {}));
		}, Ve = () => G(!1), q = 0, J = null, Y = null, X = 0, Z = !1, Q = () => {
			let e = x.value, t = b.value?.parentElement;
			if (!e || !t || !C.value) return;
			let n = ie(t, M.value);
			e.style.maxWidth = `${n.width}px`, e.style.maxHeight = `${n.height}px`;
			let r = e.getBoundingClientRect(), i = b.value?.getBoundingClientRect(), a = {
				left: (i?.left ?? n.left) + O.value,
				top: (i?.top ?? n.top) + k.value
			}, o = "Auto";
			if (A.value && j.value !== "Auto") {
				let e = ae(A.value.getBoundingClientRect(), r, j.value, n, 0, D.value === "RightToLeft");
				a = {
					left: e.left + O.value,
					top: e.top + k.value
				}, o = e.placement;
			}
			M.value && (a = re(a, r, n)), T.value = {
				...a,
				rootLeft: n.left,
				rootTop: n.top,
				width: n.width,
				height: n.height,
				ready: n.width > 0 && n.height > 0
			}, W(), w.value !== o && (w.value = o, K("ActualPlacementChanged"));
		}, $ = () => {
			X ||= requestAnimationFrame(() => {
				X = 0, Q();
			});
		}, He = (e) => {
			!C.value || !E.value || e.defaultPrevented || e.composedPath().includes(x.value) || G(!1);
		}, Ue = (e) => {
			if (!(!C.value || !E.value)) {
				if (e.key === "Escape") e.preventDefault(), e.stopPropagation(), G(!1);
				else if (e.key === "Tab" && x.value) {
					let t = Array.from(x.value.querySelectorAll("button:not(:disabled), input:not(:disabled), select:not(:disabled), textarea:not(:disabled), a[href], [tabindex]:not([tabindex=\"-1\"])")).filter((e) => !e.hasAttribute("disabled") && e.getClientRects().length), n = t[0], r = t[t.length - 1];
					n ? e.shiftKey && (document.activeElement === n || !x.value.contains(document.activeElement)) ? (e.preventDefault(), r?.focus({ preventScroll: !0 })) : !e.shiftKey && document.activeElement === r && (e.preventDefault(), n.focus({ preventScroll: !0 })) : (e.preventDefault(), x.value.focus({ preventScroll: !0 }));
				}
			}
		}, We = () => {
			document.removeEventListener("pointerdown", He, !0), document.removeEventListener("keydown", Ue, !0), window.removeEventListener("resize", $), window.removeEventListener("scroll", $, !0), window.visualViewport?.removeEventListener("resize", $), Y?.disconnect(), Y = null, X && cancelAnimationFrame(X), X = 0;
		};
		d(() => f.IsOpen === void 0 ? void 0 : g(f.IsOpen), (e) => {
			e !== void 0 && (C.value = _(e));
		}, { flush: "sync" }), d(C, async (e) => {
			let t = ++q;
			if (!e) {
				let e = document.activeElement, t = Z && (!e || e === document.body || x.value?.contains(e));
				We(), t && J?.isConnected && J.focus({ preventScroll: !0 }), Z = !1, J = null, T.value.ready = !1, K("Closed");
				return;
			}
			J = document.activeElement instanceof HTMLElement ? document.activeElement : null, Z = E.value, await fe(), await new Promise((e) => requestAnimationFrame(() => e())), !(t !== q || !C.value) && (U(), Q(), await fe(), !(t !== q || !C.value) && (Y = new ResizeObserver($), x.value && Y.observe(x.value), b.value?.parentElement && Y.observe(b.value.parentElement), A.value && Y.observe(A.value), document.addEventListener("pointerdown", He, !0), document.addEventListener("keydown", Ue, !0), window.addEventListener("resize", $), window.addEventListener("scroll", $, !0), window.visualViewport?.addEventListener("resize", $), E.value && x.value && window.setTimeout(() => {
				t !== q || !C.value || !x.value?.isConnected || (Q(), x.value.style.visibility = T.value.ready ? "visible" : "hidden", (x.value.querySelector("button:not(:disabled), input:not(:disabled), select:not(:disabled), textarea:not(:disabled), a[href], [tabindex]:not([tabindex=\"-1\"])") ?? x.value).focus({ preventScroll: !0 }));
			}, 0), K("Opened")));
		}, {
			flush: "sync",
			immediate: C.value
		}), d([
			O,
			k,
			A,
			j,
			D,
			M
		], () => {
			C.value && $();
		}), pe(() => {
			q += 1, Ie(), We(), Z && x.value?.contains(document.activeElement) && J?.isConnected && J.focus({ preventScroll: !0 });
		});
		let Ge = {
			PopupChild: be,
			props: f,
			emit: p,
			instance: m,
			attrs: h,
			slots: Ce,
			inheritedTheme: we,
			resolve: g,
			originAttributes: Te,
			boolean: _,
			number: v,
			dependencyProperty: y,
			originRef: b,
			popupRef: x,
			shadowHostRef: S,
			isOpen: C,
			actualPlacement: w,
			position: T,
			lightDismiss: E,
			flowDirection: D,
			horizontalOffset: O,
			verticalOffset: k,
			placementTarget: A,
			desiredPlacement: j,
			requestedTheme: Ee,
			constrainToRoot: M,
			overlayMode: De,
			declarationNodes: N,
			shadowProperty: Oe,
			shadowOverride: P,
			Shadow: F,
			translationProperty: ke,
			Translation: I,
			translationCoordinates: L,
			childOverride: R,
			retainedChild: Ae,
			suppliedChild: z,
			themeClass: je,
			popupStyle: Me,
			overlayStyle: Ne,
			childNodes: B,
			ChildOutlet: Pe,
			get adoptedChild() {
				return V;
			},
			set adoptedChild(e) {
				V = e;
			},
			shadowChildElement: H,
			synchronizeChild: U,
			delegatedShadowOwner: Fe,
			clearDelegatedShadow: Ie,
			synchronizeShadowGeometry: W,
			childShadow: Le,
			publicChild: Re,
			setIsOpen: G,
			publicIsOpen: ze,
			popupApi: Be,
			dispatch: K,
			DismissPopup: Ve,
			get version() {
				return q;
			},
			set version(e) {
				q = e;
			},
			get previousFocus() {
				return J;
			},
			set previousFocus(e) {
				J = e;
			},
			get resizeObserver() {
				return Y;
			},
			set resizeObserver(e) {
				Y = e;
			},
			get animationFrame() {
				return X;
			},
			set animationFrame(e) {
				X = e;
			},
			get restoreFocus() {
				return Z;
			},
			set restoreFocus(e) {
				Z = e;
			},
			updatePosition: Q,
			schedulePosition: $,
			onPointerDown: He,
			onKeyDown: Ue,
			removeListeners: We
		};
		return Object.defineProperty(Ge, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), Ge;
	}
});
//#endregion
export { xe as default };

//# sourceMappingURL=Popup.vue_vue_type_script_setup_true_lang.js.map