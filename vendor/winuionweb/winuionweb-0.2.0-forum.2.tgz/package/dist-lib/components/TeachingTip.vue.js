import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./TeachingTip.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                */
import { Fragment as n, Teleport as r, createBlock as i, createCommentVNode as a, createElementBlock as o, createElementVNode as s, createVNode as c, mergeProps as l, normalizeClass as u, normalizeStyle as d, openBlock as f, withCtx as p, withDirectives as m, withModifiers as h } from "vue";
//#region src/components/TeachingTip.vue
var g = {
	ref: "hostRef",
	class: "teaching-tip-host",
	"aria-hidden": "true"
}, _ = [
	"aria-label",
	"aria-modal",
	"aria-hidden",
	"inert"
], v = ["viewBox"], y = ["points"];
function b(e, t, b, x, S, C) {
	return f(), o(n, null, [s("span", g, null, 512), (f(), i(r, { to: "body" }, [x.isVisible && x.IsLightDismissEnabled ? (f(), o("div", l({
		key: 0,
		class: "teaching-tip-light-dismiss-indicator",
		style: x.lightDismissStyle
	}, x.lightDismissEvents, {
		"aria-hidden": "true",
		onPointerdown: h(x.OnLightDismissPointerDown, ["prevent", "stop"])
	}), null, 16)) : a("", !0), s("section", {
		ref: "tipRef",
		class: u(["teaching-tip-root", [
			x.themeClass,
			`tail-${x.tailSide}`,
			`hero-${x.effectiveHeroPlacement.toLowerCase()}`,
			{
				"teaching-tip-container": x.isVisible,
				"is-light-dismiss": x.IsLightDismissEnabled
			}
		]]),
		style: d(x.containerStyle),
		role: "dialog",
		"aria-label": x.automationName || String(x.Title || "") || void 0,
		"aria-modal": x.IsLightDismissEnabled || void 0,
		"aria-hidden": !x.isVisible || void 0,
		inert: !x.isVisible,
		tabindex: "-1"
	}, [c(x.Grid, { class: "teaching-tip-layout-root" }, {
		default: p(() => [
			c(x.Grid.ColumnDefinitions, null, {
				default: p(() => [
					c(x.ColumnDefinition, { Width: "{StaticResource TeachingTipTailShortSideLength}" }),
					c(x.ColumnDefinition, { Width: "{StaticResource TeachingTipTailMargin}" }),
					c(x.ColumnDefinition, { Width: "*" }),
					c(x.ColumnDefinition, { Width: "{StaticResource TeachingTipTailMargin}" }),
					c(x.ColumnDefinition, { Width: "{StaticResource TeachingTipTailShortSideLength}" })
				]),
				_: 1
			}),
			c(x.Grid.RowDefinitions, null, {
				default: p(() => [
					c(x.RowDefinition, { Height: "{StaticResource TeachingTipTailShortSideLength}" }),
					c(x.RowDefinition, { Height: "{StaticResource TeachingTipTailMargin}" }),
					c(x.RowDefinition, { Height: "*" }),
					c(x.RowDefinition, { Height: "{StaticResource TeachingTipTailMargin}" }),
					c(x.RowDefinition, { Height: "{StaticResource TeachingTipTailShortSideLength}" })
				]),
				_: 1
			}),
			c(x.Grid, {
				class: "teaching-tip-tail-occlusion-grid",
				"Grid.RowSpan": "5",
				"Grid.ColumnSpan": "5"
			}, {
				default: p(() => [
					c(x.Grid.ColumnDefinitions, null, {
						default: p(() => [
							c(x.ColumnDefinition, { Width: "{StaticResource TeachingTipTailShortSideLength}" }),
							c(x.ColumnDefinition, { Width: "{StaticResource TeachingTipTailMargin}" }),
							c(x.ColumnDefinition, { Width: "*" }),
							c(x.ColumnDefinition, { Width: "{StaticResource TeachingTipTailMargin}" }),
							c(x.ColumnDefinition, { Width: "{StaticResource TeachingTipTailShortSideLength}" })
						]),
						_: 1
					}),
					c(x.Grid.RowDefinitions, null, {
						default: p(() => [
							c(x.RowDefinition, { Height: "{StaticResource TeachingTipTailShortSideLength}" }),
							c(x.RowDefinition, { Height: "{StaticResource TeachingTipTailMargin}" }),
							c(x.RowDefinition, { Height: "*" }),
							c(x.RowDefinition, { Height: "{StaticResource TeachingTipTailMargin}" }),
							c(x.RowDefinition, { Height: "{StaticResource TeachingTipTailShortSideLength}" })
						]),
						_: 1
					}),
					c(x.Grid, {
						class: "teaching-tip-content-root-grid",
						"Grid.Row": "1",
						"Grid.Column": "1",
						"Grid.RowSpan": "3",
						"Grid.ColumnSpan": "3",
						Background: "{x:Bind TipBackground}",
						BorderBrush: "{x:Bind TipBorderBrush}",
						BorderThickness: "{x:Bind TipBorderThickness}",
						CornerRadius: "{x:Bind TipCornerRadius}",
						Shadow: "{x:Bind ContentShadow, Mode=OneWay}",
						Translation: "0,0,32"
					}, {
						default: p(() => [
							c(x.Grid.RowDefinitions, null, {
								default: p(() => [
									c(x.RowDefinition, { Height: "Auto" }),
									c(x.RowDefinition, { Height: "*" }),
									c(x.RowDefinition, { Height: "Auto" })
								]),
								_: 1
							}),
							c(x.Border, {
								class: "teaching-tip-hero-content-border",
								Visibility: "{x:Bind HeroVisibility}",
								"Grid.Row": "{x:Bind HeroRow}",
								CornerRadius: "{x:Bind HeroCornerRadius}"
							}, {
								default: p(() => [c(x.HeroContentOutlet)]),
								_: 1
							}),
							c(x.Grid, {
								class: "teaching-tip-non-hero-content-root-grid",
								"Grid.Row": "1"
							}, {
								default: p(() => [c(x.ScrollViewer, {
									class: "teaching-tip-scroll-viewer",
									VerticalScrollBarVisibility: "Auto"
								}, {
									default: p(() => [c(x.StackPanel, { Margin: "{StaticResource TeachingTipContentMargin}" }, {
										default: p(() => [
											c(x.Grid, null, {
												default: p(() => [
													c(x.Grid.ColumnDefinitions, null, {
														default: p(() => [c(x.ColumnDefinition, { Width: "Auto" }), c(x.ColumnDefinition, { Width: "*" })]),
														_: 1
													}),
													c(x.Border, {
														class: "teaching-tip-icon-presenter",
														Visibility: "{x:Bind IconVisibility}",
														"Grid.Column": "0",
														Margin: "{StaticResource TeachingTipIconPresenterMarginWithIcon}"
													}, {
														default: p(() => [c(x.IconSourceOutlet)]),
														_: 1
													}),
													c(x.StackPanel, {
														"Grid.Column": "1",
														Margin: "{x:Bind TitlesMargin}"
													}, {
														default: p(() => [c(x.TextBlock, {
															class: "teaching-tip-title",
															Visibility: "{x:Bind TitleVisibility}",
															Text: "{x:Bind TeachingTipTitleValue}",
															TextWrapping: "WrapWholeWords",
															FontWeight: "SemiBold"
														}), c(x.TextBlock, {
															class: "teaching-tip-subtitle",
															Visibility: "{x:Bind SubtitleVisibility}",
															Text: "{x:Bind TeachingTipSubtitleValue}",
															TextWrapping: "WrapWholeWords"
														})]),
														_: 1
													})
												]),
												_: 1
											}),
											c(x.Border, {
												class: "teaching-tip-main-content-presenter",
												Visibility: "{x:Bind ContentVisibility}",
												Margin: "{StaticResource TeachingTipMainContentPresentMargin}"
											}, {
												default: p(() => [c(x.ContentOutlet)]),
												_: 1
											}),
											c(x.Grid, { class: "teaching-tip-buttons-grid" }, {
												default: p(() => [
													c(x.Grid.ColumnDefinitions, null, {
														default: p(() => [c(x.ColumnDefinition, { Width: "*" }), c(x.ColumnDefinition, { Width: "*" })]),
														_: 1
													}),
													c(x.Button, {
														class: "teaching-tip-action-button",
														Visibility: "{x:Bind ActionVisibility}",
														HorizontalAlignment: "Stretch",
														Style: "{x:Bind ActionStyle}",
														"Grid.ColumnSpan": "{x:Bind ActionSpan}",
														Margin: "{x:Bind ActionMargin}",
														Click: "OnActionButtonClick"
													}, {
														default: p(() => [c(x.ActionContentOutlet)]),
														_: 1
													}),
													c(x.Button, {
														class: "teaching-tip-close-button",
														Visibility: "{x:Bind CloseVisibility}",
														HorizontalAlignment: "Stretch",
														Style: "{x:Bind CloseStyle}",
														"Grid.Column": "{x:Bind CloseColumn}",
														"Grid.ColumnSpan": "{x:Bind CloseSpan}",
														Margin: "{x:Bind CloseMargin}",
														Click: "OnCloseButtonClick"
													}, {
														default: p(() => [c(x.CloseContentOutlet)]),
														_: 1
													})
												]),
												_: 1
											})
										]),
										_: 1
									})]),
									_: 1
								}), c(x.Button, {
									class: "teaching-tip-alternate-close-button",
									Visibility: "{x:Bind AlternateCloseVisibility}",
									Style: "SubtleButtonStyle",
									Width: "{ThemeResource TeachingTipAlternateCloseButtonSize}",
									Height: "{ThemeResource TeachingTipAlternateCloseButtonSize}",
									Padding: "4",
									Margin: "0",
									BorderThickness: "{ThemeResource TeachingTipAlternateCloseButtonBorderThickness}",
									CornerRadius: "{ThemeResource ControlCornerRadius}",
									FocusVisualMargin: "-3",
									HorizontalAlignment: "Right",
									VerticalAlignment: "Top",
									Content: "",
									FontFamily: "{ThemeResource SymbolThemeFontFamily}",
									FontSize: "{ThemeResource TeachingTipAlternateCloseButtonGlyphSize}",
									"AutomationProperties.Name": "{x:Bind AlternateCloseButtonLabel}",
									"ToolTipService.ToolTip": "{x:Bind AlternateCloseButtonLabel}",
									Click: "OnCloseButtonClick"
								})]),
								_: 1
							})
						]),
						_: 1
					}),
					x.hasVisibleTail ? m((f(), o("div", {
						key: 0,
						class: "teaching-tip-tail-material",
						"Grid.RowSpan": "5",
						"Grid.ColumnSpan": "5",
						style: d(x.tailMaterialStyle),
						"aria-hidden": "true"
					}, null, 4)), [[
						x.vAcrylicBrush,
						x.tailMaterialStyle,
						void 0,
						{ "host-backdrop": !0 }
					]]) : a("", !0),
					x.hasVisibleTail ? (f(), o("svg", {
						key: 1,
						class: "teaching-tip-tail-polygon",
						"Grid.RowSpan": "5",
						"Grid.ColumnSpan": "5",
						viewBox: x.tailViewBox,
						"aria-hidden": "true"
					}, [s("polyline", { points: x.tailPoints }, null, 8, y)], 8, v)) : a("", !0)
				]),
				_: 1
			})
		]),
		_: 1
	})], 14, _)]))], 64);
}
var x = /*#__PURE__*/ e(t, [["render", b], ["__file", "TeachingTip.vue"]]);
//#endregion
export { x as default };

//# sourceMappingURL=TeachingTip.vue.js.map