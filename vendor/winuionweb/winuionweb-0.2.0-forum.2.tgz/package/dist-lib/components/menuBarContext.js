//#region src/components/menuBarContext.ts
var e = Symbol("MenuBar"), t = Symbol("MenuBarFlyoutNavigation"), n = Symbol("MenuBarFlyoutEnabled");
//#endregion
export { e as menuBarContextKey, n as menuBarFlyoutEnabledKey, t as menuBarFlyoutNavigationKey };

//# sourceMappingURL=menuBarContext.js.map