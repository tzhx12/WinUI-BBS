import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./CommandBarFlyout.vue_vue_type_script_setup_true_lang.js";
import { Fragment as n, Teleport as r, createBlock as i, createCommentVNode as a, createElementBlock as o, createElementVNode as s, createVNode as c, mergeProps as l, normalizeClass as u, normalizeStyle as d, openBlock as f, renderList as p, vShow as m, withDirectives as h, withModifiers as g } from "vue";
//#region src/components/CommandBarFlyout.vue
var _ = {
	ref: "anchor",
	class: "commandbar-flyout-anchor",
	"aria-hidden": "true"
}, v = ["data-theme"], y = { class: "win-cbf-layout-root" }, b = { class: "win-cbf-outer-content-root" }, x = { class: "win-cbf-content-root" }, S = {
	ref: "primaryRoot",
	class: "win-cbf-primary-items-root"
}, C = {
	ref: "primaryMount",
	class: "win-cbf-primary-items-control",
	role: "toolbar"
}, w = ["aria-label", "aria-expanded"], T = {
	ref: "overflowRoot",
	class: "win-cbf-outer-overflow-content-root"
}, E = { class: "win-cbf-overflow-content-root" }, D = {
	ref: "secondaryMount",
	class: "win-cbf-secondary-items-control",
	role: "menu"
};
function O(e, t, O, k, A, j) {
	return f(), o(n, null, [
		s("span", _, null, 512),
		c(k.DeclarationOutlet),
		(f(), i(r, { to: "body" }, [h(s("div", {
			ref: "flyout",
			class: u(["win-commandbar-flyout", [k.themeClass, {
				"is-positioning": !k.positioned,
				"is-closing": !k.isOpen,
				"is-expanded": k.expandedPresent,
				"is-expanding": k.suppressShadow,
				"has-primary": k.primaryCommands.length > 0,
				"has-primary-labels": k.hasPrimaryLabels,
				"expands-up": k.expandsUp
			}]]),
			style: d(k.flyoutStyle),
			"data-theme": k.theme,
			role: "menu",
			tabindex: "-1",
			onKeydown: k.onKeyDown,
			onPointerdown: t[2] ||= g(() => {}, ["stop"])
		}, [s("div", y, [s("div", b, [s("div", x, [h((f(), o("div", S, [
			h(s("div", {
				class: "win-cbf-material-layer",
				"data-menu-material": "PrimaryItemsSystemBackdropRoot",
				style: d(k.flyoutBackdropStyle),
				"aria-hidden": "true"
			}, null, 4), [[
				k.vAcrylicBrush,
				k.flyoutBackdropStyle,
				void 0,
				{ "no-backdrop": !0 }
			]]),
			h(s("div", {
				class: "win-cbf-material-layer",
				"data-menu-material": "Background",
				style: d(k.flyoutBackgroundStyle),
				"aria-hidden": "true"
			}, null, 4), [[
				k.vAcrylicBrush,
				k.flyoutBackgroundStyle,
				void 0,
				{ "no-backdrop": !0 }
			]]),
			s("div", C, null, 512),
			k.showMore ? (f(), o("button", l({ key: 0 }, k.moreButtonAttributes, {
				class: "commandbar-more-button win-cbf-more-button",
				type: "button",
				tabindex: "-1",
				"aria-label": k.moreButtonLabel,
				"aria-expanded": k.expanded,
				onPointerdown: t[0] ||= g(() => {}, ["prevent"]),
				onClick: t[1] ||= (e) => k.setExpanded(!k.expanded)
			}), [...t[3] ||= [s("span", { class: "commandbar-ellipsis-content" }, [s("span", {
				class: "commandbar-ellipsis-icon",
				"aria-hidden": "true"
			}, "")], -1)]], 16, w)) : a("", !0)
		])), [
			[m, k.primaryCommands.length || k.showMore],
			[k.vAcrylicBackdrop, [k.flyoutBackdropStyle, k.flyoutBackgroundStyle]],
			[k.vThemeShadow, {
				Translation: 32,
				Theme: k.theme,
				Enabled: k.isOpen && k.primaryCommands.length > 0 && !k.suppressShadow
			}]
		]), h((f(), o("div", T, [s("div", E, [
			h(s("div", {
				class: "win-cbf-material-layer",
				"data-menu-material": "OverflowPopupSystemBackdropRoot",
				style: d(k.flyoutBackdropStyle),
				"aria-hidden": "true"
			}, null, 4), [[
				k.vAcrylicBrush,
				k.flyoutBackdropStyle,
				void 0,
				{ "no-backdrop": !0 }
			]]),
			h(s("div", {
				class: "win-cbf-material-layer",
				"data-menu-material": "Background",
				style: d(k.flyoutBackgroundStyle),
				"aria-hidden": "true"
			}, null, 4), [[
				k.vAcrylicBrush,
				k.flyoutBackgroundStyle,
				void 0,
				{ "no-backdrop": !0 }
			]]),
			s("div", D, null, 512)
		])])), [
			[m, k.expandedPresent],
			[k.vAcrylicBackdrop, [k.flyoutBackdropStyle, k.flyoutBackgroundStyle]],
			[k.vThemeShadow, {
				Translation: 32,
				Theme: k.theme,
				Enabled: k.isPresent && k.expandedPresent && (!k.primaryCommands.length || !k.expandsUp)
			}]
		])])])]), (f(!0), o(n, null, p(k.entries, (e) => (f(), i(k.CommandPortal, {
			key: e.id,
			node: e.node,
			host: e.host,
			overflow: e.secondary || k.overflowIds.has(e.id),
			context: k.commonContext
		}, null, 8, [
			"node",
			"host",
			"overflow"
		]))), 128))], 46, v), [[m, k.isPresent]])]))
	], 64);
}
var k = /*#__PURE__*/ e(t, [["render", O], ["__file", "CommandBarFlyout.vue"]]);
//#endregion
export { k as default };

//# sourceMappingURL=CommandBarFlyout.vue.js.map