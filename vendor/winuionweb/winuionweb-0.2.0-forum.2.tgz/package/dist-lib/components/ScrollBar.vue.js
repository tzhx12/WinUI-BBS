import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./ScrollBar.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                              */
import { createElementBlock as n, createElementVNode as r, createVNode as i, mergeProps as a, normalizeClass as o, normalizeStyle as s, openBlock as c, withDirectives as l } from "vue";
//#region src/components/ScrollBar.vue
var u = [
	"aria-orientation",
	"aria-valuemin",
	"aria-valuemax",
	"aria-valuenow",
	"aria-disabled",
	"data-indicator-state",
	"data-conscious-state"
], d = { class: "scrollbar-mouse-root" }, f = ["disabled"], p = ["disabled"], m = { class: "scrollbar-panning-root" };
function h(e, t, h, g, _, v) {
	return c(), n("div", a({ ref: "root" }, g.forwardedAttrs, {
		class: ["win-scrollbar scrollbar", [g.vertical ? "scrollbar-vertical" : "scrollbar-horizontal", {
			expanded: g.expanded,
			dragging: g.dragging,
			"no-auto-hide": g.noAutoHide,
			"no-indicator": g.indicator === "None",
			"touch-indicator": g.indicator === "TouchIndicator",
			disabled: !g.enabled
		}]],
		style: g.layoutStyle,
		role: "scrollbar",
		"aria-orientation": g.vertical ? "vertical" : "horizontal",
		"aria-valuemin": g.minimum,
		"aria-valuemax": g.maximum,
		"aria-valuenow": g.value,
		"aria-disabled": !g.enabled,
		"data-indicator-state": g.indicator,
		"data-conscious-state": g.expanded ? "Expanded" : "Collapsed",
		onPointerenter: g.enter,
		onPointermove: g.activity,
		onPointerleave: g.leave,
		onWheel: g.wheel
	}), [r("div", d, [
		l(r("div", {
			class: "scrollbar-track",
			style: s(g.trackBackgroundStyle),
			onPointerdown: g.startTrack
		}, null, 36), [[
			g.vAcrylicBrush,
			g.trackBackgroundStyle,
			void 0,
			{ "host-backdrop": !0 }
		]]),
		r("button", {
			ref: "decrease",
			class: o(["scrollbar-button decrease", { "is-pressed": g.pressed === -1 }]),
			type: "button",
			tabindex: "-1",
			"aria-hidden": "true",
			disabled: !g.enabled,
			onPointerdown: t[0] ||= (e) => g.startArrow(-1, e)
		}, [i(g.FontIcon, {
			Glyph: "{x:Bind DecreaseGlyph, Mode=OneWay}",
			FontFamily: "{ThemeResource SymbolThemeFontFamily}",
			FontSize: "{ThemeResource ScrollBarButtonArrowIconFontSize}",
			HorizontalAlignment: "Center",
			VerticalAlignment: "Center"
		})], 42, f),
		r("div", {
			ref: "thumb",
			class: "scrollbar-thumb",
			style: s(g.thumbStyle),
			onPointerdown: g.startDrag
		}, [...t[2] ||= [r("div", { class: "scrollbar-thumb-visual" }, null, -1)]], 36),
		r("button", {
			ref: "increase",
			class: o(["scrollbar-button increase", { "is-pressed": g.pressed === 1 }]),
			type: "button",
			tabindex: "-1",
			"aria-hidden": "true",
			disabled: !g.enabled,
			onPointerdown: t[1] ||= (e) => g.startArrow(1, e)
		}, [i(g.FontIcon, {
			Glyph: "{x:Bind IncreaseGlyph, Mode=OneWay}",
			FontFamily: "{ThemeResource SymbolThemeFontFamily}",
			FontSize: "{ThemeResource ScrollBarButtonArrowIconFontSize}",
			HorizontalAlignment: "Center",
			VerticalAlignment: "Center"
		})], 42, p)
	]), r("div", m, [r("div", {
		class: "scrollbar-panning-thumb",
		style: s(g.panningStyle)
	}, null, 4)])], 16, u);
}
var g = /*#__PURE__*/ e(t, [
	["render", h],
	["__scopeId", "data-v-a4d18a5d"],
	["__file", "ScrollBar.vue"]
]);
//#endregion
export { g as default };

//# sourceMappingURL=ScrollBar.vue.js.map