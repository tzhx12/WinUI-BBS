import { alignment as e, applyStackChildren as t, cssLength as n, useLayoutObserver as r, xamlThickness as i } from "./layout.js";
import { primitiveResourceScope as a, primitiveResourceStyles as ee, xamlPrimitiveResourceKey as o } from "./xamlPrimitives.js";
import { normalizeXamlNodes as s, resolveXamlValue as c, updateXamlBinding as l, xamlItemContextKey as u } from "./xamlRuntime.js";
import { collectXamlResources as d, useXamlBrushResources as te } from "./xamlBrushResources.js";
import { brushProperty as f, isBrushProperty as ne, useBrushProperty as p } from "./brushProperties.js";
import { vAcrylicBrush as m } from "./acrylicBrushVisual.js";
import { vRadialGradientBrush as h } from "./RadialGradientVisual.js";
import { Fragment as g, cloneVNode as _, computed as v, defineComponent as y, getCurrentInstance as re, h as ie, inject as b, nextTick as x, onMounted as ae, onUpdated as oe, provide as S, ref as C, unref as se, useSlots as ce, watch as w } from "vue";
//#region src/components/StackPanel.vue?vue&type=script&setup=true&lang.ts
var T = y({
	name: "StackPanel.Resources",
	__xamlResourceProperty: "resources",
	setup() {
		return () => null;
	}
}), E = /*@__PURE__*/ y({
	Resources: T,
	Background: f("StackPanel", "Background"),
	__name: "StackPanel",
	props: {
		Orientation: {
			type: String,
			default: "Vertical"
		},
		Spacing: {
			type: [String, Number],
			default: 0
		},
		Width: {
			type: [String, Number],
			default: ""
		},
		Height: {
			type: [String, Number],
			default: ""
		},
		MinWidth: {
			type: [String, Number],
			default: ""
		},
		MinHeight: {
			type: [String, Number],
			default: ""
		},
		MaxWidth: {
			type: [String, Number],
			default: ""
		},
		MaxHeight: {
			type: [String, Number],
			default: ""
		},
		Background: {
			type: [String, Object],
			default: ""
		},
		BackgroundSizing: {
			type: String,
			default: ""
		},
		BorderBrush: {
			type: String,
			default: ""
		},
		BorderThickness: {
			type: [String, Number],
			default: ""
		},
		CornerRadius: {
			type: [String, Number],
			default: ""
		},
		Padding: {
			type: [String, Number],
			default: ""
		},
		Margin: {
			type: [String, Number],
			default: ""
		},
		HorizontalAlignment: {
			type: String,
			default: ""
		},
		VerticalAlignment: {
			type: String,
			default: ""
		},
		Visibility: {
			type: String,
			default: "Visible"
		},
		Opacity: {
			type: [String, Number],
			default: 1
		}
	},
	emits: ["update:Orientation", "update:Spacing"],
	setup(f, { expose: E, emit: le }) {
		let D = f, O = le, k = C(null), A = re(), j = ce(), M = p("Background", () => D.Background, () => j.default?.() ?? [], A), N = (e) => c(e, A), P = v(() => N(D.Orientation) === "Horizontal" ? "Horizontal" : "Vertical"), F = C(P.value);
		w(P, (e) => {
			F.value = e;
		});
		let I = v({
			get: () => F.value,
			set: (e) => {
				let t = e === "Horizontal" ? "Horizontal" : "Vertical";
				t !== F.value && (F.value = t, l(D.Orientation, t, A), O("update:Orientation", t));
			}
		}), L = v(() => Math.max(0, Number(N(D.Spacing)) || 0)), R = C(L.value);
		w(L, (e) => {
			R.value = e;
		});
		let z = v({
			get: () => R.value,
			set: (e) => {
				let t = Math.max(0, Number(e) || 0);
				t !== R.value && (R.value = t, l(D.Spacing, t, A), O("update:Spacing", t));
			}
		}), B = Symbol.for("WinUIonWeb.StackPanel.ImplicitStyles"), V = b(B, null), H = (e) => {
			let t = e.type;
			return typeof t == "string" ? t : t?.name ?? t?.__name ?? "";
		}, U = (e) => {
			if (Array.isArray(e.children)) return e.children;
			let t = e.children;
			return typeof t?.default == "function" ? t.default() : [];
		}, W = (e) => e.flatMap((e) => e?.type === g ? W(U(e)) : e ? [e] : []), G = (e) => H(e) === "StackPanel.Resources", K = b(u, void 0), q = v(() => (se(K), W(j.default?.() ?? []))), J = b(o, null), Y = a(() => q.value);
		S(o, a(() => q.value, J));
		let X = te(A), Z = v(() => {
			let e = { ...V?.value ?? {} };
			for (let t of q.value.filter(G)) for (let n of W(U(t))) {
				if (H(n) !== "Style" || n.props?.["x:Key"]) continue;
				let t = String(N(n.props?.TargetType) ?? "").replace(/^\{x:Type\s+|\}$/g, "").split(":").pop() ?? "";
				if (!t) continue;
				let r = {};
				for (let e of W(U(n))) {
					if (H(e) !== "Setter") continue;
					let t = e.props?.Property;
					typeof t == "string" && t && (r[t] = N(e.props?.Value));
				}
				e[t] = r;
			}
			return e;
		});
		S(B, Z);
		let Q = () => {
			k.value && t(k.value, I.value);
		}, ue = y({
			name: "StackPanelContentOutlet",
			setup() {
				return ae(() => {
					x(Q);
				}), oe(() => {
					x(Q);
				}), () => {
					let e = {};
					for (let t of q.value.filter(G)) d(U(t), e);
					return X.sync(e), ie(g, s(q.value.filter((e) => !G(e) && !ne(e)).map((e) => {
						let t = {
							...Z.value[H(e)],
							...e.props ?? {}
						}, n = e.type?.props, r = (e) => N(t[e] ?? n?.[e]?.default) || "Stretch";
						delete t.ref;
						let i = _(e, {
							...t,
							"data-stack-panel-horizontal-alignment": r("HorizontalAlignment"),
							"data-stack-panel-vertical-alignment": r("VerticalAlignment"),
							"data-stack-panel-width": N(t.Width) ?? "",
							"data-stack-panel-height": N(t.Height) ?? ""
						});
						return i.ref = e.ref, i;
					}), A));
				};
			}
		}), de = v(() => {
			let t = {
				...ee(Y.value),
				flexDirection: I.value === "Horizontal" ? "row" : "column",
				gap: n(z.value),
				alignItems: "stretch",
				opacity: String(N(D.Opacity))
			};
			for (let [e, r] of Object.entries({
				Width: D.Width,
				Height: D.Height,
				MinWidth: D.MinWidth,
				MinHeight: D.MinHeight,
				MaxWidth: D.MaxWidth,
				MaxHeight: D.MaxHeight
			})) {
				let i = N(r);
				i !== "" && i != null && (t[e.charAt(0).toLowerCase() + e.slice(1)] = n(i));
			}
			let r = N(D.Background), a = N(D.BorderBrush), o = N(D.BorderThickness);
			Object.assign(t, M.style.value), r && (t.backgroundClip = N(D.BackgroundSizing) === "OuterBorderEdge" ? "border-box" : "padding-box"), (a || o !== "" && o != null) && (t.borderColor = String(a || "transparent"), t.borderWidth = i(o) || "0px", t.borderStyle = "solid");
			let s = N(D.CornerRadius);
			s !== "" && s !== void 0 && (t.borderRadius = String(s).split(",").map((e) => n(e.trim())).join(" "));
			let c = N(D.Padding), l = N(D.Margin);
			c !== "" && (t.padding = i(c)), l !== "" && (t.margin = i(l));
			let u = N(D.HorizontalAlignment), d = N(D.VerticalAlignment);
			return u && (t.justifySelf = e(u, "horizontal")), d && (t.alignSelf = e(d, "vertical")), N(D.Visibility) === "Collapsed" && (t.display = "none"), t;
		});
		r(k, Q), E({
			Orientation: I,
			Spacing: z
		});
		let $ = {
			StackPanelResources: T,
			props: D,
			emit: O,
			root: k,
			instance: A,
			slots: j,
			backgroundBrush: M,
			resolve: N,
			resolvedOrientation: P,
			localOrientation: F,
			Orientation: I,
			resolvedSpacing: L,
			localSpacing: R,
			Spacing: z,
			implicitStyleKey: B,
			inheritedStyles: V,
			nodeName: H,
			childrenOf: U,
			flatten: W,
			isResources: G,
			itemContext: K,
			nodes: q,
			inheritedPrimitives: J,
			localPrimitives: Y,
			brushResources: X,
			implicitStyles: Z,
			applyChildren: Q,
			ContentOutlet: ue,
			rootStyle: de,
			get vAcrylicBrush() {
				return m;
			},
			get vRadialGradientBrush() {
				return h;
			}
		};
		return Object.defineProperty($, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), $;
	}
});
//#endregion
export { E as default };

//# sourceMappingURL=StackPanel.vue_vue_type_script_setup_true_lang.js.map