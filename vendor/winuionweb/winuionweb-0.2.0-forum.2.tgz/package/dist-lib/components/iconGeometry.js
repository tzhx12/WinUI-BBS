import { resolveXamlResourceObject as e, resolveXamlValue as t } from "./xamlRuntime.js";
import { Fragment as n, isVNode as r } from "vue";
//#region src/components/iconGeometry.ts
var i = (e) => Array.isArray(e.children) ? e.children.filter(r) : e.children?.default?.() ?? [], a = (o, s) => {
	let c = (e) => t(e, s), l = (e) => Number(c(e)) || 0, u = (e) => {
		let t = c(e);
		if (t && typeof t == "object") return [l(t.X), l(t.Y)];
		let n = String(t ?? "").split(/[\s,]+/).map(Number);
		return [n[0] || 0, n[1] || 0];
	}, d = (t) => {
		let n = t.trim(), r = n.match(/^\{(?:StaticResource|ThemeResource)\s+([^\s}]+)\}$/)?.[1] ?? n.match(/^var\(--([^,)]+)\)$/)?.[1];
		if (r) {
			let t = e(r, s);
			return t && t !== o ? a(t, s) : {
				path: "",
				fillRule: "evenodd"
			};
		}
		let i = n.match(/^F([01])\s*/i);
		return {
			path: i ? n.slice(i[0].length) : n,
			fillRule: i?.[1] === "1" ? "nonzero" : "evenodd"
		};
	};
	if (typeof o == "string") {
		let e = c(o);
		return e && typeof e == "object" ? a(e, s) : d(String(e ?? ""));
	}
	if (!o || typeof o != "object") return {
		path: "",
		fillRule: "evenodd"
	};
	if (Array.isArray(o)) {
		let e = o.map((e) => a(e, s));
		return {
			path: e.map((e) => e.path).filter(Boolean).join(" "),
			fillRule: e.find((e) => e.path)?.fillRule ?? "evenodd"
		};
	}
	if (r(o) && o.type === n) return a(i(o), s);
	let f = r(o) ? o : null, p = f?.type, m = f?.props ?? o, h = p?.__geometryKind ?? p?.name ?? String(m.__geometryKind ?? m.Kind ?? ("Rect" in m ? "RectangleGeometry" : "RadiusX" in m || "RadiusY" in m ? "EllipseGeometry" : "StartPoint" in m || "EndPoint" in m ? "LineGeometry" : "Children" in m ? "GeometryGroup" : "")), g = c(m.FillRule) === "Nonzero" ? "nonzero" : "evenodd";
	if (p?.__iconGeometryProperty || p?.__geometryProperty || h === "GeometryGroup") {
		let e = a(f ? i(f) : m.Children, s);
		return {
			path: e.path,
			fillRule: h === "GeometryGroup" ? g : e.fillRule
		};
	}
	if (h === "LineGeometry") {
		let e = u(m.StartPoint), t = u(m.EndPoint);
		return {
			path: `M ${e.join(",")} L ${t.join(",")}`,
			fillRule: g
		};
	}
	if (h === "EllipseGeometry") {
		let [e, t] = u(m.Center), n = Math.max(0, l(m.RadiusX)), r = Math.max(0, l(m.RadiusY));
		return {
			path: n && r ? `M ${e - n},${t} A ${n},${r} 0 1 0 ${e + n},${t} A ${n},${r} 0 1 0 ${e - n},${t} Z` : "",
			fillRule: g
		};
	}
	if (h === "RectangleGeometry") {
		let e = c(m.Rect), [t, n, r, i] = e && typeof e == "object" ? [
			"X",
			"Y",
			"Width",
			"Height"
		].map((t) => l(e[t])) : String(e ?? "").split(/[\s,]+/).map(Number);
		return {
			path: r > 0 && i > 0 ? `M ${t || 0},${n || 0} h ${r} v ${i} h ${-r} Z` : "",
			fillRule: g
		};
	}
	return typeof m.Data == "string" ? d(String(c(m.Data) ?? "")) : {
		path: "",
		fillRule: g
	};
};
//#endregion
export { a as resolveIconGeometry };

//# sourceMappingURL=iconGeometry.js.map