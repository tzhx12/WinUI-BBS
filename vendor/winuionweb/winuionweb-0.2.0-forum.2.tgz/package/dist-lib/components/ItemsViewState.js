//#region src/components/ItemsViewState.ts
var e = Symbol("WinUIonWeb.itemContainerController"), t = Symbol("WinUIonWeb.itemsViewItemContext"), n = Symbol("WinUIonWeb.itemsViewElement");
//#endregion
export { e as itemContainerControllerKey, n as itemsViewElementKey, t as itemsViewItemContextKey };

//# sourceMappingURL=ItemsViewState.js.map