import { alignment as e, cssLength as t, xamlThickness as n } from "./layout.js";
import { resolveXamlHandler as r, resolveXamlValue as i } from "./xamlRuntime.js";
import ee from "../_virtual/_plugin-vue_export-helper.js";
import { progressBoolean as a, progressBrush as o, progressCornerRadius as s, progressNumber as te, progressThickness as c, useProgressProperty as l, useProgressRange as ne } from "./progressRuntime.js";
/* empty css                                                                */
import { computed as u, createElementBlock as re, createElementVNode as d, getCurrentInstance as ie, mergeProps as f, nextTick as ae, normalizeStyle as p, onBeforeUnmount as oe, onMounted as se, openBlock as m, ref as h, useAttrs as ce, watch as g } from "vue";
//#region src/components/ProgressBar.vue
var _ = /*@__PURE__*/ Object.assign({ inheritAttrs: !1 }, {
	__name: "ProgressBar",
	props: {
		Value: {
			type: [Number, String],
			default: 0
		},
		Minimum: {
			type: [Number, String],
			default: 0
		},
		Maximum: {
			type: [Number, String],
			default: 100
		},
		IsIndeterminate: {
			type: [Boolean, String],
			default: !1
		},
		ShowError: {
			type: [Boolean, String],
			default: !1
		},
		ShowPaused: {
			type: [Boolean, String],
			default: !1
		},
		Width: {
			type: [Number, String],
			default: ""
		},
		Height: {
			type: [Number, String],
			default: ""
		},
		MinWidth: {
			type: [Number, String],
			default: 0
		},
		MinHeight: {
			type: [Number, String],
			default: 3
		},
		MaxWidth: {
			type: [Number, String],
			default: ""
		},
		MaxHeight: {
			type: [Number, String],
			default: ""
		},
		Margin: {
			type: [Number, String],
			default: ""
		},
		Padding: {
			type: [Number, String],
			default: 0
		},
		BorderThickness: {
			type: [Number, String],
			default: 0
		},
		BorderBrush: {
			type: [String, Object],
			default: "{ThemeResource ProgressBarBorderBrush}"
		},
		Background: {
			type: [String, Object],
			default: "{ThemeResource ProgressBarBackground}"
		},
		Foreground: {
			type: [String, Object],
			default: "{ThemeResource ProgressBarForeground}"
		},
		CornerRadius: {
			type: [Number, String],
			default: 1.5
		},
		HorizontalAlignment: {
			type: String,
			default: "Stretch"
		},
		VerticalAlignment: {
			type: String,
			default: "Center"
		},
		Visibility: {
			type: String,
			default: "Visible"
		},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		IsTabStop: {
			type: [Boolean, String],
			default: !1
		},
		IsHitTestVisible: {
			type: [Boolean, String],
			default: !0
		}
	},
	emits: [
		"update:Value",
		"update:Minimum",
		"update:Maximum",
		"update:Background",
		"update:Foreground",
		"update:IsIndeterminate",
		"update:ShowError",
		"update:ShowPaused",
		"ValueChanged"
	],
	setup(ee, { expose: re, emit: d }) {
		let f = ee, p = d, m = ie(), _ = ce(), v = (e, t) => p("update:" + e, t), { Value: y, Minimum: b, Maximum: x, minimum: le, maximum: ue, fraction: de, coercedValue: fe } = ne(f, m, v), S = l(f, "IsIndeterminate", m, v), C = l(f, "ShowError", m, v), w = l(f, "ShowPaused", m, v), T = l(f, "Background", m, v), E = l(f, "Foreground", m, v), pe = h(null), D = h(null), O = h(null), k = h(null), A = h(null), j = h(null), M = h({
			width: 0,
			height: 0
		}), N = h(0), P = (e) => i(e, m), F = u(() => P(f.Visibility)), I = u(() => a(S.value) && F.value === "Visible"), me = u(() => a(P(f.IsEnabled), !0)), he = u(() => a(P(f.IsTabStop))), L = u(() => {
			let e = I.value ? "Indeterminate" : "";
			return a(C.value) ? e + "Error" : a(w.value) ? e + "Paused" : I.value ? "Indeterminate" : "Determinate";
		}), ge = u(() => {
			let e = { ..._ };
			for (let t of [
				"class",
				"style",
				"role",
				"aria-valuenow",
				"aria-valuemin",
				"aria-valuemax",
				"aria-busy",
				"ValueChanged"
			]) delete e[t];
			return e["AutomationProperties.Name"] && (e["aria-label"] = P(e["AutomationProperties.Name"])), delete e["AutomationProperties.Name"], e;
		}), R = u(() => c(P(f.Padding))), z = u(() => c(P(f.BorderThickness))), B = u(() => Math.max(0, M.value.width - R.value.left - R.value.right - z.value.left - z.value.right)), V = u(() => a(S.value) ? 0 : B.value * de.value), _e = u(() => {
			let r = te(P(f.MinHeight), 3), i = r + R.value.top + R.value.bottom + z.value.top + z.value.bottom;
			return [_.style, {
				width: t(P(f.Width)) || (P(f.HorizontalAlignment) === "Stretch" ? "100%" : void 0),
				flex: t(P(f.Width)) ? "0 0 auto" : void 0,
				height: t(P(f.Height)) || i + "px",
				maxInlineSize: "100%",
				minWidth: t(P(f.MinWidth)),
				minHeight: r + "px",
				maxWidth: t(P(f.MaxWidth)) || void 0,
				maxHeight: t(P(f.MaxHeight)) || void 0,
				margin: n(P(f.Margin)) || void 0,
				display: F.value === "Collapsed" ? "none" : "inline-block",
				alignSelf: e(P(f.VerticalAlignment), "vertical"),
				justifySelf: e(P(f.HorizontalAlignment), "horizontal"),
				pointerEvents: a(P(f.IsHitTestVisible), !0) ? void 0 : "none",
				"--progress-bar-foreground": o(E.value),
				"--progress-bar-background": o(T.value),
				"--progress-bar-corner-radius": s(P(f.CornerRadius))
			}];
		}), ve = u(() => ({
			borderWidth: n(P(f.BorderThickness)),
			borderColor: o(P(f.BorderBrush)),
			borderRadius: s(P(f.CornerRadius)),
			padding: n(P(f.Padding))
		})), ye = u(() => ({ height: t(P(f.MinHeight)) || "3px" })), be = u(() => ({ width: V.value + "px" })), xe = u(() => ({ width: B.value * .4 + "px" })), Se = u(() => ({ width: B.value * (a(w.value) || a(C.value) ? 1 : .6) + "px" })), H = u(() => {
			let { width: e, height: t } = M.value, n = R.value;
			return {
				ContainerAnimationStartPosition: e * -.4,
				ContainerAnimationEndPosition: e * 1.2,
				Container2AnimationStartPosition: e * -.9,
				Container2AnimationEndPosition: e * .6 * 1.66,
				ContainerAnimationMidPosition: 0,
				IndicatorLengthDelta: N.value,
				ClipRect: {
					X: n.left,
					Y: n.top,
					Width: Math.max(0, e - n.left - n.right),
					Height: Math.max(0, t - n.top - n.bottom)
				},
				EllipseAnimationEndPosition: e / 3,
				EllipseAnimationWellPosition: e * 2 / 3,
				EllipseDiameter: e <= 180 ? 4 : e <= 280 ? 5 : 6,
				EllipseOffset: e <= 180 ? 4 : e <= 280 ? 7 : 9
			};
		});
		re({
			Value: y,
			Minimum: b,
			Maximum: x,
			IsIndeterminate: S,
			ShowError: C,
			ShowPaused: w,
			Background: T,
			Foreground: E,
			TemplateSettings: H
		});
		let U, W = !1, G = 0, K = /* @__PURE__ */ new Set(), q, J = (e, t, n) => {
			if (!e?.animate) return null;
			let r = e.animate(t, n);
			return K.add(r), r.finished?.catch(() => {}), r;
		}, Y = () => {
			for (let e of K) e.cancel();
			K.clear();
		}, X = (e) => "translateX(" + e + "px)", Z = (e) => "translate(" + e + "px, -50%)", Ce = () => {
			let e = H.value;
			J(A.value, [
				{
					transform: X(e.ContainerAnimationStartPosition),
					offset: 0,
					easing: "cubic-bezier(0.4, 0, 0.6, 1)"
				},
				{
					transform: X(e.ContainerAnimationEndPosition),
					offset: .75
				},
				{
					transform: X(e.ContainerAnimationEndPosition),
					offset: 1
				}
			], {
				duration: 2e3,
				iterations: Infinity
			}), J(j.value, [
				{
					transform: X(e.Container2AnimationStartPosition),
					offset: 0
				},
				{
					transform: X(e.Container2AnimationStartPosition),
					offset: .375,
					easing: "cubic-bezier(0.4, 0, 0.6, 1)"
				},
				{
					transform: X(e.Container2AnimationEndPosition),
					offset: 1
				}
			], {
				duration: 2e3,
				iterations: Infinity
			});
		}, Q = async (e, t) => {
			if (!W) return;
			let n = ++G, r = j.value ? getComputedStyle(j.value).transform : "none";
			if (Y(), e === "Indeterminate") {
				if (t === "IndeterminatePaused" || t === "IndeterminateError") {
					let e = H.value;
					J(A.value, [{ opacity: 0 }, { opacity: 0 }], { duration: 500 }), J(j.value, [{
						transform: r,
						easing: "cubic-bezier(1, 0, 1, 1)"
					}, { transform: X(e.ContainerAnimationEndPosition) }], {
						duration: 333,
						fill: "forwards"
					});
					let t = J(O.value, [{
						transform: Z(0),
						easing: "cubic-bezier(1, 0, 1, 1)"
					}, { transform: Z(e.ContainerAnimationEndPosition) }], { duration: 500 });
					if (t && await t.finished.catch(() => {}), n !== G) return;
					Y();
				}
				Ce();
			} else if (e === "IndeterminatePaused" || e === "IndeterminateError") {
				let e = H.value;
				J(j.value, [
					{
						transform: r,
						offset: 0,
						easing: "cubic-bezier(1, 1, 0, 1)"
					},
					{
						transform: X(e.Container2AnimationEndPosition),
						offset: .166 / .75,
						easing: "steps(1, end)"
					},
					{
						transform: X(e.Container2AnimationStartPosition),
						offset: .167 / .75,
						easing: "cubic-bezier(0, 0, 0, 1)"
					},
					{
						transform: X(e.ContainerAnimationMidPosition),
						offset: 1
					}
				], {
					duration: 750,
					fill: "forwards"
				}), J(O.value, [{
					transform: Z(e.Container2AnimationStartPosition),
					easing: "cubic-bezier(0, 0, 0, 1)"
				}, { transform: Z(0) }], { duration: 750 });
			} else if (t === "Indeterminate") for (let e of [
				A.value,
				j.value,
				O.value
			]) J(e, [{ opacity: 0 }, { opacity: 1 }], { duration: 167 });
		}, $ = () => {
			D.value && (M.value = {
				width: D.value.clientWidth,
				height: D.value.clientHeight
			});
		};
		g([L, () => M.value.width], ([e], [t]) => Q(e, t), { flush: "post" }), g(V, (e, t) => {
			N.value = t - e, !(!W || I.value || L.value === "Paused") && (q?.cancel(), q = k.value?.animate?.([{
				transform: X(N.value),
				easing: "cubic-bezier(0.1, 0.9, 0.2, 1)"
			}, { transform: X(0) }], { duration: 200 }), q?.finished?.catch(() => {}));
		}, { flush: "post" }), g(fe, (e, t) => {
			if (Object.is(e, t)) return;
			let n = {
				OldValue: t,
				NewValue: e
			};
			r(_.ValueChanged, m)?.(m?.exposed, n), p("ValueChanged", n);
		}), se(async () => {
			await ae(), $(), W = !0, Q(L.value), typeof ResizeObserver < "u" && D.value && (U = new ResizeObserver($), U.observe(D.value));
		}), oe(() => {
			W = !1, G++, U?.disconnect(), Y(), q?.cancel();
		});
		let we = {
			props: f,
			emit: p,
			instance: m,
			attrs: _,
			publish: v,
			Value: y,
			Minimum: b,
			Maximum: x,
			minimum: le,
			maximum: ue,
			fraction: de,
			progressValue: fe,
			IsIndeterminate: S,
			ShowError: C,
			ShowPaused: w,
			Background: T,
			Foreground: E,
			rootRef: pe,
			layoutRef: D,
			trackRef: O,
			determinateRef: k,
			indeterminateRef: A,
			indeterminate2Ref: j,
			measuredSize: M,
			indicatorLengthDelta: N,
			resolve: P,
			visibility: F,
			isIndeterminate: I,
			isEnabled: me,
			isTabStop: he,
			visualState: L,
			forwardedAttrs: ge,
			padding: R,
			border: z,
			contentWidth: B,
			indicatorWidth: V,
			rootStyle: _e,
			borderStyle: ve,
			gridStyle: ye,
			determinateIndicatorStyle: be,
			indeterminateIndicatorStyle: xe,
			indeterminateIndicator2Style: Se,
			TemplateSettings: H,
			get resizeObserver() {
				return U;
			},
			set resizeObserver(e) {
				U = e;
			},
			get mounted() {
				return W;
			},
			set mounted(e) {
				W = e;
			},
			get stateGeneration() {
				return G;
			},
			set stateGeneration(e) {
				G = e;
			},
			stateAnimations: K,
			get repositionAnimation() {
				return q;
			},
			set repositionAnimation(e) {
				q = e;
			},
			animate: J,
			cancelStateAnimations: Y,
			translate: X,
			trackTranslate: Z,
			startIndeterminateStoryboard: Ce,
			updateVisualState: Q,
			updateMeasuredSize: $,
			computed: u,
			getCurrentInstance: ie,
			nextTick: ae,
			onBeforeUnmount: oe,
			onMounted: se,
			ref: h,
			useAttrs: ce,
			watch: g,
			get resolveXamlHandler() {
				return r;
			},
			get resolveXamlValue() {
				return i;
			},
			get alignment() {
				return e;
			},
			get cssLength() {
				return t;
			},
			get xamlThickness() {
				return n;
			},
			get progressBoolean() {
				return a;
			},
			get progressBrush() {
				return o;
			},
			get progressCornerRadius() {
				return s;
			},
			get progressNumber() {
				return te;
			},
			get progressThickness() {
				return c;
			},
			get useProgressProperty() {
				return l;
			},
			get useProgressRange() {
				return ne;
			}
		};
		return Object.defineProperty(we, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), we;
	}
}), v = [
	"tabindex",
	"aria-valuenow",
	"aria-valuemin",
	"aria-valuemax",
	"aria-busy",
	"aria-disabled"
], y = {
	ref: "layoutRef",
	class: "LayoutRoot"
}, b = { class: "ProgressBarClip" }, x = {
	ref: "trackRef",
	class: "ProgressBarTrack"
};
function le(e, t, n, r, i, ee) {
	return m(), re("div", f({ ref: "rootRef" }, r.forwardedAttrs, {
		class: ["win-progress-bar", [r.attrs.class, "state-" + r.visualState]],
		style: r.rootStyle,
		role: "progressbar",
		tabindex: r.isTabStop && r.isEnabled ? 0 : void 0,
		"aria-valuenow": r.isIndeterminate ? void 0 : r.progressValue,
		"aria-valuemin": r.isIndeterminate ? void 0 : r.minimum,
		"aria-valuemax": r.isIndeterminate ? void 0 : r.maximum,
		"aria-busy": r.isIndeterminate ? "true" : void 0,
		"aria-disabled": !r.isEnabled || void 0
	}), [d("div", y, [d("div", {
		class: "ProgressBarRoot",
		style: p(r.borderStyle)
	}, [d("div", b, [d("div", {
		class: "ProgressBarGrid",
		style: p(r.gridStyle)
	}, [
		d("div", x, null, 512),
		d("div", {
			ref: "determinateRef",
			class: "DeterminateProgressBarIndicator",
			style: p(r.determinateIndicatorStyle)
		}, null, 4),
		d("div", {
			ref: "indeterminateRef",
			class: "IndeterminateProgressBarIndicator",
			style: p(r.indeterminateIndicatorStyle)
		}, null, 4),
		d("div", {
			ref: "indeterminate2Ref",
			class: "IndeterminateProgressBarIndicator2",
			style: p(r.indeterminateIndicator2Style)
		}, null, 4)
	], 4)])], 4)], 512)], 16, v);
}
var ue = /*#__PURE__*/ ee(_, [
	["render", le],
	["__scopeId", "data-v-2c857079"],
	["__file", "ProgressBar.vue"]
]);
//#endregion
export { ue as default };

//# sourceMappingURL=ProgressBar.vue.js.map