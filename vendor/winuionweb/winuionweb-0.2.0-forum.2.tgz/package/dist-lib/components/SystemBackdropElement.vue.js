import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./SystemBackdropElement.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                                          */
import { createElementBlock as n, createVNode as r, mergeProps as i, openBlock as a } from "vue";
//#region src/components/SystemBackdropElement.vue
function o(e, t, o, s, c, l) {
	return a(), n("div", i({ ref: "element" }, s.forwardedAttrs, {
		class: ["win-system-backdrop-element", s.attrs.class],
		style: [s.attrs.style, s.layoutStyle],
		"aria-hidden": "true"
	}), [r(s.BackdropDeclarationOutlet)], 16);
}
var s = /*#__PURE__*/ e(t, [
	["render", o],
	["__scopeId", "data-v-c7d88d9c"],
	["__file", "SystemBackdropElement.vue"]
]);
//#endregion
export { s as default };

//# sourceMappingURL=SystemBackdropElement.vue.js.map