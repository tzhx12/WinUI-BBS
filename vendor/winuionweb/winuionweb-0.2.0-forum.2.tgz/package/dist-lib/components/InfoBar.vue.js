import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./InfoBar.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                            */
import { createElementBlock as n, createVNode as r, mergeProps as i, normalizeClass as a, openBlock as o, withCtx as s } from "vue";
//#region src/components/InfoBar.vue
var c = [
	"aria-label",
	"aria-live",
	"aria-hidden"
];
function l(e, t, l, u, d, f) {
	return o(), n("section", i({
		ref: "rootRef",
		class: "win-infobar win-theme-scope"
	}, u.rootAttrs, {
		class: [
			u.severityClass,
			u.themeClass,
			u.attrs.class
		],
		style: u.rootStyle,
		role: "status",
		"aria-label": u.LandmarkLabel,
		"aria-live": u.Severity === "Error" || u.Severity === "Warning" ? "assertive" : "polite",
		"aria-hidden": !u.IsOpen || void 0
	}), [r(u.Border, {
		class: "win-infobar-content-root",
		Visibility: "{x:Bind RootVisibility}",
		VerticalAlignment: "Top",
		Background: "{x:Bind SeverityBackground}",
		BorderBrush: "{x:Bind InfoBarBorderBrush}",
		BorderThickness: "{x:Bind InfoBarBorderThickness}",
		CornerRadius: "{x:Bind InfoBarCornerRadius}"
	}, {
		default: s(() => [r(u.Grid, {
			class: "win-infobar-layout",
			HorizontalAlignment: "Stretch",
			MinHeight: "{ThemeResource InfoBarMinHeight}",
			Background: "{x:Bind InfoBarBackground}",
			CornerRadius: "{x:Bind InfoBarCornerRadius}",
			Padding: "{StaticResource InfoBarContentRootPadding}"
		}, {
			default: s(() => [
				r(u.Grid.ColumnDefinitions, null, {
					default: s(() => [
						r(u.ColumnDefinition, { Width: "Auto" }),
						r(u.ColumnDefinition, { Width: "*" }),
						r(u.ColumnDefinition, { Width: "Auto" })
					]),
					_: 1
				}),
				r(u.Grid.RowDefinitions, null, {
					default: s(() => [r(u.RowDefinition, { Height: "Auto" }), r(u.RowDefinition, { Height: "Auto" })]),
					_: 1
				}),
				r(u.Grid, {
					class: "win-infobar-standard-icon-area",
					Visibility: "{x:Bind StandardIconVisibility}"
				}, {
					default: s(() => [r(u.TextBlock, {
						class: "win-infobar-icon-background",
						"Grid.Column": "0",
						VerticalAlignment: "Top",
						Margin: "{StaticResource InfoBarIconMargin}",
						FontSize: "{StaticResource InfoBarIconFontSize}",
						Text: "{StaticResource InfoBarIconBackgroundGlyph}",
						Foreground: "{x:Bind SeverityIconBackground}",
						FontFamily: "{ThemeResource SymbolThemeFontFamily}",
						"aria-hidden": "true"
					}), r(u.TextBlock, {
						class: "win-infobar-standard-icon",
						"Grid.Column": "0",
						VerticalAlignment: "Top",
						Margin: "{StaticResource InfoBarIconMargin}",
						FontSize: "{StaticResource InfoBarIconFontSize}",
						Text: "{x:Bind SeverityIconGlyph}",
						Foreground: "{x:Bind SeverityIconForeground}",
						FontFamily: "{ThemeResource SymbolThemeFontFamily}",
						"AutomationProperties.Name": "{x:Bind SeverityLabel}"
					})]),
					_: 1
				}),
				r(u.Viewbox, {
					class: "win-infobar-user-icon-box",
					"Grid.Column": "0",
					Visibility: "{x:Bind UserIconVisibility}",
					VerticalAlignment: "Top",
					MaxWidth: "{ThemeResource InfoBarIconFontSize}",
					MaxHeight: "{ThemeResource InfoBarIconFontSize}",
					Margin: "{ThemeResource InfoBarIconMargin}"
				}, {
					default: s(() => [r(u.IconOutlet)]),
					_: 1
				}),
				r(u.InfoBarPanel, {
					"Grid.Column": "1",
					Margin: "{StaticResource InfoBarPanelMargin}",
					HorizontalOrientationPadding: "{StaticResource InfoBarPanelHorizontalOrientationPadding}",
					VerticalOrientationPadding: "{StaticResource InfoBarPanelVerticalOrientationPadding}"
				}, {
					default: s(() => [
						r(u.TextBlock, {
							class: "win-infobar-title",
							Visibility: "{x:Bind TitleVisibility}",
							Text: "{x:Bind InfoBarTitle}",
							Foreground: "{x:Bind TitleForeground}",
							"InfoBarPanel.HorizontalOrientationMargin": "{StaticResource InfoBarTitleHorizontalOrientationMargin}",
							"InfoBarPanel.VerticalOrientationMargin": "{StaticResource InfoBarTitleVerticalOrientationMargin}",
							TextWrapping: "WrapWholeWords",
							FontWeight: "{StaticResource InfoBarTitleFontWeight}",
							FontSize: "{StaticResource InfoBarTitleFontSize}"
						}),
						r(u.TextBlock, {
							class: "win-infobar-message",
							Visibility: "{x:Bind MessageVisibility}",
							Text: "{x:Bind InfoBarMessage}",
							Foreground: "{x:Bind MessageForeground}",
							"InfoBarPanel.HorizontalOrientationMargin": "{StaticResource InfoBarMessageHorizontalOrientationMargin}",
							"InfoBarPanel.VerticalOrientationMargin": "{StaticResource InfoBarMessageVerticalOrientationMargin}",
							TextWrapping: "WrapWholeWords",
							FontWeight: "{StaticResource InfoBarMessageFontWeight}",
							FontSize: "{StaticResource InfoBarMessageFontSize}"
						}),
						r(u.ContentPresenter, {
							class: "win-infobar-action",
							Visibility: "{x:Bind ActionVisibility}",
							"InfoBarPanel.HorizontalOrientationMargin": "{StaticResource InfoBarActionHorizontalOrientationMargin}",
							"InfoBarPanel.VerticalOrientationMargin": "{StaticResource InfoBarActionVerticalOrientationMargin}",
							VerticalAlignment: "Top"
						}, {
							default: s(() => [r(u.ActionOutlet)]),
							_: 1
						})
					]),
					_: 1
				}),
				r(u.ContentPresenter, {
					class: "win-infobar-content-area",
					"Grid.Column": "1",
					"Grid.Row": "{x:Bind ContentRow}",
					VerticalAlignment: "Center"
				}, {
					default: s(() => [r(u.ContentOutlet)]),
					_: 1
				}),
				r(u.Button, {
					class: a(["win-infobar-close-button", { "uses-default-close-button-style": u.usesDefaultCloseStyle }]),
					"Grid.Column": "2",
					Visibility: "{x:Bind CloseVisibility}",
					IsEnabled: "{x:Bind CloseButtonEnabled}",
					Style: "{x:Bind InfoBarCloseStyle}",
					Width: "{x:Bind CloseButtonWidth}",
					Height: "{x:Bind CloseButtonHeight}",
					MinWidth: "{x:Bind CloseButtonMinWidth}",
					MinHeight: "{x:Bind CloseButtonMinHeight}",
					MaxWidth: "{x:Bind CloseButtonMaxWidth}",
					MaxHeight: "{x:Bind CloseButtonMaxHeight}",
					Margin: "{x:Bind CloseButtonMargin}",
					Padding: "{x:Bind CloseButtonPadding}",
					HorizontalAlignment: "{x:Bind CloseButtonHorizontalAlignment}",
					VerticalAlignment: "{x:Bind CloseButtonVerticalAlignment}",
					HorizontalContentAlignment: "{x:Bind CloseButtonHorizontalContentAlignment}",
					VerticalContentAlignment: "{x:Bind CloseButtonVerticalContentAlignment}",
					Background: "{x:Bind CloseButtonBackground}",
					Foreground: "{x:Bind CloseButtonForeground}",
					BorderBrush: "{x:Bind CloseButtonBorderBrush}",
					BorderThickness: "{x:Bind CloseButtonBorderThickness}",
					CornerRadius: "{x:Bind CloseButtonCornerRadius}",
					FontFamily: "{x:Bind CloseButtonFontFamily}",
					FontWeight: "{x:Bind CloseButtonFontWeight}",
					FontSize: "{x:Bind CloseButtonFontSize}",
					"AutomationProperties.Name": "{x:Bind CloseLabel}",
					"ToolTipService.ToolTip": "{x:Bind CloseTooltip}",
					Click: "OnCloseButtonClick"
				}, {
					default: s(() => [r(u.Viewbox, {
						Width: "{StaticResource InfoBarCloseButtonGlyphSize}",
						Height: "{StaticResource InfoBarCloseButtonGlyphSize}",
						HorizontalAlignment: "Center",
						VerticalAlignment: "Center"
					}, {
						default: s(() => [r(u.SymbolIcon, { Symbol: "{StaticResource InfoBarCloseButtonSymbol}" })]),
						_: 1
					})]),
					_: 1
				}, 8, ["class"])
			]),
			_: 1
		})]),
		_: 1
	})], 16, c);
}
var u = /*#__PURE__*/ e(t, [
	["render", l],
	["__scopeId", "data-v-2cc5903a"],
	["__file", "InfoBar.vue"]
]);
//#endregion
export { u as default };

//# sourceMappingURL=InfoBar.vue.js.map