//#region src/components/textControlResources.ts
var e = Object.freeze({
	TextControlThemeMinWidth: 64,
	TextControlThemeMinHeight: 32,
	TextControlThemePadding: "10,5,6,6",
	TextControlBorderThemeThickness: 1,
	TextControlBorderThemeThicknessFocused: "1,1,1,2",
	TextBoxTopHeaderMargin: "0,0,0,8",
	PasswordBoxTopHeaderMargin: "0,0,0,8",
	AutoSuggestBoxTopHeaderMargin: "0,0,0,8",
	TextBoxInnerButtonMargin: "0,4,4,4",
	TextBoxIconFontSize: 12,
	PasswordBoxIconFontSize: 12,
	AutoSuggestBoxIconFontSize: 12,
	TextControlBackground: "var(--ControlFillColorDefaultBrush)",
	TextControlBackgroundPointerOver: "var(--ControlFillColorSecondaryBrush)",
	TextControlBackgroundFocused: "var(--ControlFillColorInputActiveBrush)",
	TextControlBackgroundDisabled: "var(--ControlFillColorDisabledBrush)",
	TextControlForeground: "var(--TextFillColorPrimaryBrush)",
	TextControlForegroundPointerOver: "var(--TextFillColorPrimaryBrush)",
	TextControlForegroundFocused: "var(--TextFillColorPrimaryBrush)",
	TextControlForegroundDisabled: "var(--TextFillColorDisabledBrush)",
	TextControlHeaderForeground: "var(--TextFillColorPrimaryBrush)",
	TextControlHeaderForegroundDisabled: "var(--TextFillColorDisabledBrush)",
	TextControlPlaceholderForeground: "var(--TextFillColorSecondaryBrush)",
	TextControlPlaceholderForegroundPointerOver: "var(--TextFillColorSecondaryBrush)",
	TextControlPlaceholderForegroundFocused: "var(--TextFillColorSecondaryBrush)",
	TextControlPlaceholderForegroundDisabled: "var(--TextFillColorDisabledBrush)",
	TextControlSelectionHighlightColor: "var(--AccentFillColorSelectedTextBackgroundBrush, Highlight)",
	TextControlButtonForeground: "var(--TextFillColorSecondaryBrush)",
	TextControlButtonForegroundPointerOver: "var(--TextFillColorSecondaryBrush)",
	TextControlButtonForegroundPressed: "var(--TextFillColorTertiaryBrush)",
	TextControlButtonBackground: "transparent",
	TextControlButtonBackgroundPointerOver: "var(--SubtleFillColorSecondaryBrush)",
	TextControlButtonBackgroundPressed: "var(--SubtleFillColorTertiaryBrush)",
	TextControlButtonBorderBrush: "transparent",
	TextControlButtonBorderBrushPointerOver: "transparent",
	TextControlButtonBorderBrushPressed: "transparent"
});
//#endregion
export { e as textControlResources };

//# sourceMappingURL=textControlResources.js.map