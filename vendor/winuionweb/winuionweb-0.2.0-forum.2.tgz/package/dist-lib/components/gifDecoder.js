//#region src/components/gifDecoder.ts
var e = (e, t) => {
	let n = document.createElement("canvas");
	return n.width = e, n.height = t, n;
};
async function t(t) {
	let n = globalThis.ImageDecoder;
	if (!n) return null;
	let r = new n({
		data: t.slice(0),
		type: "image/gif",
		preferAnimation: !0
	}), i = [];
	try {
		await r.tracks.ready;
		let t = r.tracks.selectedTrack;
		if (!t?.frameCount) return null;
		let n = 0, a = 0;
		for (let o = 0; o < t.frameCount; o += 1) {
			let { image: t } = await r.decode({
				frameIndex: o,
				completeFramesOnly: !0
			}), s = Number(t.displayWidth ?? t.width), c = Number(t.displayHeight ?? t.height), l = e(s, c);
			l.getContext("2d")?.drawImage(t, 0, 0), i.push({
				image: l,
				duration: Math.max(20, Number(t.duration ?? 1e5) / 1e3)
			}), n = s, a = c, t.close?.();
		}
		return {
			width: n,
			height: a,
			frames: i,
			repetitions: Number.isFinite(t.repetitionCount) ? Math.max(1, t.repetitionCount + 1) : Infinity,
			dispose: () => i.splice(0)
		};
	} finally {
		r.close();
	}
}
var n = (e, t, n) => {
	let r = 1 << t, i = r + 1, a = [], o = t + 1, s = 0, c, l = [], u = () => {
		a.length = 0;
		for (let e = 0; e < r; e += 1) a.push([e]);
		a.push([], []), o = t + 1, c = void 0;
	}, d = () => {
		let t = 0;
		for (let n = 0; n < o; n += 1) {
			let r = s++;
			t |= ((e[r >> 3] ?? 0) >> (r & 7) & 1) << n;
		}
		return t;
	};
	for (u(); s + o <= e.length * 8 && l.length < n;) {
		let e = d();
		if (e === r) {
			u();
			continue;
		}
		if (e === i) break;
		let t = a[e] ?? (e === a.length && c ? [...c, c[0]] : void 0);
		if (!t?.length) throw Error("Invalid GIF LZW data");
		l.push(...t), c && a.length < 4096 && (a.push([...c, t[0]]), a.length === 1 << o && o < 12 && (o += 1)), c = t;
	}
	return Uint8Array.from(l.slice(0, n));
};
function r(t) {
	let r = new Uint8Array(t), i = 0, a = () => {
		if (i >= r.length) throw Error("Incomplete GIF data");
		return r[i++];
	}, o = () => a() | a() << 8, s = (e) => {
		if (i + e > r.length) throw Error("Incomplete GIF data");
		let t = r.slice(i, i + e);
		return i += e, t;
	}, c = () => {
		let e = [];
		for (let t = a(); t > 0; t = a()) e.push(s(t));
		return Uint8Array.from(e.flatMap((e) => Array.from(e)));
	}, l = String.fromCharCode(...s(6));
	if (l !== "GIF87a" && l !== "GIF89a") throw Error("The source is not a GIF");
	let u = o(), d = o();
	if (!u || !d) throw Error("Invalid GIF dimensions");
	let f = a(), p = a();
	a();
	let m = f & 128 ? s(3 * (1 << (f & 7) + 1)) : new Uint8Array(), h = new Uint8ClampedArray(u * d * 4), g = [], _ = 0, v = 100, y, b = 1, x;
	for (; i < r.length;) {
		let t = a();
		if (t === 59) break;
		if (t === 33) {
			let e = a();
			if (e === 249) {
				if (a() !== 4) throw Error("Invalid GIF control extension");
				let e = a();
				_ = e >> 2 & 7;
				let t = o();
				v = t < 2 ? 100 : t * 10;
				let n = a();
				y = e & 1 ? n : void 0, a();
			} else if (e === 255) {
				let e = String.fromCharCode(...s(a())), t = c();
				if ((e === "NETSCAPE2.0" || e === "ANIMEXTS1.0") && t[0] === 1) {
					let e = (t[1] ?? 0) | (t[2] ?? 0) << 8;
					b = e === 0 ? Infinity : e + 1;
				}
			} else c();
			continue;
		}
		if (t !== 44) throw Error("Invalid GIF block");
		if (x?.disposal === 2) for (let e = x.top; e < Math.min(d, x.top + x.height); e += 1) for (let t = x.left; t < Math.min(u, x.left + x.width); t += 1) {
			let n = (e * u + t) * 4;
			x.transparent === void 0 ? (h[n] = m[p * 3] ?? 0, h[n + 1] = m[p * 3 + 1] ?? 0, h[n + 2] = m[p * 3 + 2] ?? 0, h[n + 3] = 255) : h.fill(0, n, n + 4);
		}
		else x?.disposal === 3 && x.snapshot && h.set(x.snapshot);
		let r = o(), i = o(), l = o(), f = o(), S = a(), C = S & 128 ? s(3 * (1 << (S & 7) + 1)) : m, w = a(), T = n(c(), w, l * f);
		if (T.length !== l * f) throw Error("Incomplete GIF frame");
		if (!g.length && y === void 0) for (let e = 0; e < h.length; e += 4) h[e] = m[p * 3] ?? 0, h[e + 1] = m[p * 3 + 1] ?? 0, h[e + 2] = m[p * 3 + 2] ?? 0, h[e + 3] = 255;
		let E = _ === 3 ? h.slice() : void 0, D = [];
		if (S & 64) for (let [e, t] of [
			[0, 8],
			[4, 8],
			[2, 4],
			[1, 2]
		]) for (let n = e; n < f; n += t) D.push(n);
		else for (let e = 0; e < f; e += 1) D.push(e);
		for (let e = 0; e < f; e += 1) {
			let t = i + D[e];
			for (let n = 0; n < l; n += 1) {
				let i = T[e * l + n];
				if (i === void 0 || i === y || r + n >= u || t >= d) continue;
				let a = (t * u + r + n) * 4;
				h[a] = C[i * 3] ?? 0, h[a + 1] = C[i * 3 + 1] ?? 0, h[a + 2] = C[i * 3 + 2] ?? 0, h[a + 3] = 255;
			}
		}
		let O = e(u, d);
		O.getContext("2d")?.putImageData(new ImageData(h.slice(), u, d), 0, 0), g.push({
			image: O,
			duration: v
		}), x = {
			disposal: _,
			left: r,
			top: i,
			width: l,
			height: f,
			snapshot: E,
			transparent: y
		}, _ = 0, v = 100, y = void 0;
	}
	if (!g.length) throw Error("The GIF has no image frames");
	return {
		width: u,
		height: d,
		frames: g,
		repetitions: b,
		dispose: () => g.splice(0)
	};
}
async function i(e) {
	try {
		let n = await t(e);
		if (n) return n;
	} catch {}
	return r(e);
}
//#endregion
export { i as decodeGif };

//# sourceMappingURL=gifDecoder.js.map