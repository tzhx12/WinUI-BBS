import { selectorBarStyleSetter as e } from "./selectorBarResources.js";
import { normalizeXamlNodes as t, resolveXamlValue as n, updateXamlBinding as r, xamlControlIdentityKey as i, xamlNameScopeKey as a, xamlScopeKey as o } from "./xamlRuntime.js";
import s from "./SymbolIcon.vue.js";
import { itemsViewElementKey as c } from "./ItemsViewState.js";
import { Fragment as l, cloneVNode as u, defineComponent as d, h as f, isVNode as p, markRaw as m, provide as h, reactive as g, shallowReactive as _, shallowRef as v } from "vue";
//#region src/components/selectorBarRuntime.ts
var y = Symbol("WinUIonWeb.selectorBarItem"), b = Symbol("WinUIonWeb.selectorBarPointerFocus"), x = (e) => d({
	name: `SelectorBar.${e}`,
	__selectorBarProperty: e,
	setup(e, { slots: t }) {
		return () => f(l, t.default?.());
	}
}), S = x("Items"), C = x("Icon"), w = x("Child"), T = {
	Style: null,
	Text: "",
	Tag: "",
	Icon: null,
	Child: null,
	IsSelected: !1,
	IsEnabled: !0,
	IsTabStop: !0,
	IsHitTestVisible: !0,
	Visibility: "Visible",
	BackgroundSizing: "OuterBorderEdge",
	Background: "Transparent",
	Foreground: "{ThemeResource SelectorBarItemForeground}",
	BorderBrush: "{ThemeResource SelectorBarItemBorderBrush}",
	BorderThickness: 1,
	Padding: "12,10,12,7",
	CornerRadius: "{ThemeResource ControlCornerRadius}",
	FontFamily: "{ThemeResource ContentControlThemeFontFamily}",
	FontSize: 14,
	FontWeight: "Normal",
	HorizontalAlignment: "Left",
	VerticalAlignment: "Center",
	HorizontalContentAlignment: "Left",
	VerticalContentAlignment: "Top",
	Width: "",
	Height: "",
	MinWidth: 0,
	MinHeight: 0,
	MaxWidth: "",
	MaxHeight: "",
	Margin: 0,
	Opacity: 1,
	FlowDirection: "LeftToRight",
	FocusVisualMargin: -2,
	UseSystemFocusVisuals: !0
}, E = Symbol("WinUIonWeb.selectorBarElementNode"), D = (e) => typeof e.type == "string" ? e.type : e.type?.name || e.type?.__name || "", O = (e, s) => {
	let p = e, g = v(e), y = _({}), b = {}, x, S = d({
		name: "SelectorBarPropertyElement",
		setup() {
			let e = s?.parent?.provides?.[o] ?? s?.provides?.[o], n = s?.provides?.[a];
			return e && h(o, e), n && h(a, n), () => f(l, t([C()], s));
		}
	}), C = () => {
		let e = u(g.value, y), t = e.props?.onVnodeMounted, n = e.props?.onVnodeUpdated, r = (e, t) => {
			e.component && (e.component.exposed = x, e.component.exposeProxy = null), typeof t == "function" && t(e);
		};
		return e.props = {
			...e.props,
			onVnodeMounted: (e) => r(e, t),
			onVnodeUpdated: (e) => r(e, n)
		}, e;
	};
	return Object.defineProperties(b, {
		[i]: { value: !0 },
		[E]: { get: () => p },
		[c]: { value: () => f(S) },
		UpdateElementNode: { value: (e) => {
			p = e, g.value = e;
		} },
		Type: { get: () => D(p) }
	}), x = m(new Proxy(b, {
		get(e, t, r) {
			if (Reflect.has(e, t)) return Reflect.get(e, t, r);
			if (typeof t != "string" || t.startsWith("__v_")) return;
			if (t in y) return y[t];
			let i = g.value.props?.[t];
			return i === void 0 ? t === "Symbol" && D(g.value) === "SymbolIcon" ? "Emoji" : void 0 : n(i, s);
		},
		set(e, t, i, a) {
			if (Reflect.has(e, t)) return Reflect.set(e, t, i, a);
			if (typeof t != "string") return !1;
			y[t] = i;
			let o = g.value.props?.[t];
			return r(o, i, s), typeof o == "string" && /Mode\s*=\s*TwoWay/i.test(o) && Object.is(n(o, s), i) && delete y[t], !0;
		},
		ownKeys: (e) => [...new Set([
			...Reflect.ownKeys(e),
			...Object.keys(g.value.props ?? {}),
			...Object.keys(y)
		])],
		getOwnPropertyDescriptor: (e, t) => Reflect.getOwnPropertyDescriptor(e, t) ?? (typeof t == "string" && (t in (g.value.props ?? {}) || t in y) ? {
			configurable: !0,
			enumerable: !0,
			writable: !0,
			value: void 0
		} : void 0)
	})), x;
}, k = (e) => {
	let t = /* @__PURE__ */ new Map(), n = /* @__PURE__ */ new WeakMap();
	return (r, i) => {
		if (i == null || i === "") return null;
		if (typeof i == "object" && typeof i[c] == "function") return i;
		if (r === "Icon" && (typeof i == "string" || typeof i == "number")) {
			let n = t.get(i);
			return n || (n = O(f(s, { Symbol: i }), e), t.set(i, n)), n;
		}
		if (p(i)) {
			let t = n.get(i);
			return t || (t = O(i, e), n.set(i, t)), t;
		}
		return i;
	};
}, A = (t, a, o) => {
	let s = v(t), l = g({}), d = _({}), f = g({}), p = k(a), m = {}, h = !1;
	for (let [t, i] of Object.entries(T)) Object.defineProperty(m, t, {
		enumerable: !0,
		get: () => {
			if ((t === "Icon" || t === "Child") && t in d && !f[t]) return d[t];
			let r = t === "Style" ? void 0 : e(m.Style, t, "SelectorBarItem"), o = n(t in l ? l[t] : s.value.props?.[t] ?? r ?? i, a);
			return t === "Icon" || t === "Child" ? p(t, o) : o;
		},
		set: (e) => {
			let n = m[t];
			(t === "Icon" || t === "Child") && (f[t] = !0), l[t] = e, !(n === e || h) && (r(s.value.props?.[t], e, a), t === "IsSelected" && o(m, e === !0 || e === "True"));
		}
	});
	return Object.defineProperties(m, {
		[i]: { value: !0 },
		[y]: { value: !0 },
		[c]: { value: () => u(s.value) },
		SetPropertyElement: { value: (e, t) => {
			if (!f[e]) if (t == null) delete d[e];
			else {
				let n = d[e], r = n?.[E];
				n && r && r.type === t.type && r.key === t.key ? n.UpdateElementNode(t) : d[e] = O(t, a);
			}
		} },
		HasPropertyElementOverride: { value: (e) => !!f[e] },
		SynchronizeBoundProperty: { value: (e) => {
			delete l[e], delete f[e];
		} },
		UpdateNode: { value: (e) => {
			s.value = e;
		} },
		SynchronizeSelection: { value: (e) => {
			h = !0;
			let t = m.IsSelected;
			l.IsSelected = e, t !== e && r(s.value.props?.IsSelected, e, a), h = !1;
		} }
	}), m;
};
//#endregion
export { w as SelectorBarItemChild, C as SelectorBarItemIcon, S as SelectorBarItems, A as createSelectorBarItem, k as selectorBarElementFactory, T as selectorBarItemDefaults, y as selectorBarItemKey, b as selectorBarPointerFocusKey };

//# sourceMappingURL=selectorBarRuntime.js.map