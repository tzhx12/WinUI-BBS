import { toolTipOwnerContextKey as e } from "./toolTipRuntime.js";
import t from "./ToolTip.vue.js";
import { computed as n, defineComponent as r, h as i, provide as a, ref as o } from "vue";
//#region src/components/tabViewToolTip.ts
var s = r({
	name: "TabViewTemplateToolTip",
	props: {
		Owner: {
			type: Object,
			default: null
		},
		Content: {
			type: String,
			default: ""
		},
		Placement: {
			type: String,
			default: "Top"
		},
		IsEnabled: {
			type: Boolean,
			default: !0
		}
	},
	setup(r) {
		return a(e, {
			owner: n(() => r.Owner),
			inputMode: o("none"),
			point: o(null),
			theme: o(""),
			attached: !0
		}), () => i(t, {
			Content: r.Content,
			Placement: r.Placement,
			PlacementTarget: r.Owner,
			IsEnabled: r.IsEnabled && r.Content.length > 0
		});
	}
});
//#endregion
export { s as TabViewTemplateToolTip };

//# sourceMappingURL=tabViewToolTip.js.map