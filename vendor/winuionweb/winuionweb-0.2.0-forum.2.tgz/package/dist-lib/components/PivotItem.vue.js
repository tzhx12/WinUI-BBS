import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./PivotItem.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                              */
import { createElementBlock as n, createElementVNode as r, createVNode as i, mergeProps as a, normalizeStyle as o, openBlock as s } from "vue";
//#region src/components/PivotItem.vue
var c = [
	"aria-disabled",
	"inert",
	"tabindex"
];
function l(e, t, l, u, d, f) {
	return s(), n("div", a({ ref: "rootRef" }, u.rootAttrs, {
		class: ["win-pivot-item", u.attrs.class],
		style: [u.attrs.style, u.rootStyle],
		"aria-disabled": u.enabled ? void 0 : "true",
		inert: !u.enabled || !u.visible,
		tabindex: u.property("IsTabStop") === !0 ? 0 : -1
	}), [r("div", {
		class: "win-pivot-item-content-presenter",
		style: o(u.presenterStyle)
	}, [i(u.ContentOutlet)], 4)], 16, c);
}
var u = /*#__PURE__*/ e(t, [
	["render", l],
	["__scopeId", "data-v-324cea77"],
	["__file", "PivotItem.vue"]
]);
//#endregion
export { u as default };

//# sourceMappingURL=PivotItem.vue.js.map