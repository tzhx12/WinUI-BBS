import { resolveXamlValue as e } from "./xamlRuntime.js";
//#region src/components/scrollViewerTemplateBindings.ts
var t = (t, n, r = {}) => {
	let i = {
		HorizontalScrollMode: "Disabled",
		HorizontalScrollBarVisibility: "Disabled",
		VerticalScrollMode: "Enabled",
		VerticalScrollBarVisibility: "Auto",
		IsHorizontalRailEnabled: !0,
		IsVerticalRailEnabled: !0,
		IsHorizontalScrollChainingEnabled: !0,
		IsVerticalScrollChainingEnabled: !0,
		ZoomMode: "Disabled",
		...r
	}, a = {};
	for (let [r, o] of Object.entries(i)) Object.defineProperty(a, r, {
		enumerable: !0,
		get: () => {
			let i = t(`ScrollViewer.${r}`);
			return i === void 0 ? o : e(i, n);
		}
	});
	return a;
};
//#endregion
export { t as scrollViewerTemplateBindings };

//# sourceMappingURL=scrollViewerTemplateBindings.js.map