import { colorString as e, createSolidColorBrush as t } from "./brushCore.js";
import { resolveXamlValue as n } from "./xamlRuntime.js";
import { Fragment as r, Text as i, computed as a, defineComponent as o, watch as s } from "vue";
//#region src/components/xamlPrimitives.ts
var c = Symbol.for("WinUIonWeb.Xaml.PrimitiveResources"), l = (e) => o({
	name: e,
	__xamlPrimitive: e,
	setup: () => () => null
}), u = l("x:Double"), d = l("x:Int32"), f = l("x:Boolean"), p = l("Thickness"), m = l("HorizontalAlignment"), h = l("VerticalAlignment"), g = o({
	name: "ResourceDictionary",
	__xamlResourceDictionary: !0,
	ThemeDictionaries: o({
		name: "ResourceDictionary.ThemeDictionaries",
		__xamlThemeDictionaries: !0,
		setup: () => () => null
	}),
	MergedDictionaries: o({
		name: "ResourceDictionary.MergedDictionaries",
		__xamlResourceDictionary: !0,
		setup: () => () => null
	}),
	setup: () => () => null
}), _ = o({
	name: "StaticResource",
	__createXamlResource: (e, t) => a(() => n(`{StaticResource ${String(e("ResourceKey") ?? "")}}`, t.instance)),
	setup: () => () => null
}), v = o({
	name: "SolidColorBrush",
	__xamlBrush: !0,
	__createXamlResource: (n, r) => {
		let i = t(), a = s(() => [n("Color"), n("Opacity")], ([t, n]) => {
			t !== void 0 && (i.Color = e(t)), n !== void 0 && (i.Opacity = Math.max(0, Math.min(1, Number(n))));
		}, { immediate: !0 });
		return r?.Dispose(a), i;
	},
	setup: () => () => null
}), y = (e) => Array.isArray(e.children) ? e.children : e.children?.default?.() ?? [], b = (e) => typeof e.children == "string" ? e.children : y(e).map((e) => e.type === i ? String(e.children ?? "") : b(e)).join(""), x = Object.freeze({
	ControlContentThemeFontSize: 14,
	ContentControlFontSize: 14,
	TextControlThemeMinHeight: 24,
	TextControlThemePadding: "2,2,6,1",
	ListViewItemMinHeight: 32,
	TreeViewItemMinHeight: 24,
	TreeViewItemMultiSelectCheckBoxMinHeight: 24,
	TreeViewItemPresenterMargin: 0,
	TreeViewItemPresenterPadding: 0,
	TimePickerHostPadding: "0,1,0,2",
	DatePickerHostPadding: "0,1,0,2",
	DatePickerHostMonthPadding: "9,0,0,1",
	ComboBoxEditableTextPadding: "10,0,30,0",
	ComboBoxMinHeight: 24,
	ComboBoxPadding: "12,1,0,3",
	NavigationViewItemOnLeftMinHeight: 32
}), S = (e) => {
	let t = {};
	for (let [n, r] of Object.entries(e)) if (typeof r == "number") t[`--${n}`] = `${r}px`;
	else if (typeof r == "string" && /^-?\d+(?:\.\d+)?(?:\s*,\s*-?\d+(?:\.\d+)?){0,3}$/.test(r)) {
		let e = r.split(",").map((e) => `${Number(e.trim())}px`);
		t[`--${n}`] = e.length === 4 ? [
			e[1],
			e[2],
			e[3],
			e[0]
		].join(" ") : e.length === 2 ? [e[1], e[0]].join(" ") : e.join(" ");
	}
	return t;
}, C = (e, t) => a(() => {
	let n = { ...t?.value }, i = (e, t = !1) => {
		for (let a of e) {
			if (!a || typeof a != "object") continue;
			let e = a.type, o = typeof a.type == "string" ? a.type : e.name ?? "";
			if (a.type === r || o === "ResourceDictionary" || o === "ResourceDictionary.ThemeDictionaries" || o === "ResourceDictionary.MergedDictionaries") t && o === "ResourceDictionary" && a.props?.Source === "ms-appx:///Microsoft.UI.Xaml/DensityStyles/Compact.xaml" && Object.assign(n, x), i(y(a), t);
			else if (o.endsWith(".Resources")) i(y(a), !0);
			else if (t && [
				"x:Double",
				"x:Int32",
				"x:Boolean",
				"x:String",
				"Thickness",
				"HorizontalAlignment",
				"VerticalAlignment"
			].includes(o)) {
				let e = a.props?.["x:Key"];
				if (typeof e != "string") continue;
				let t = b(a).trim(), r = [
					"x:String",
					"Thickness",
					"HorizontalAlignment",
					"VerticalAlignment"
				].includes(o) ? t : o === "x:Boolean" ? t === "True" : Number(t);
				(typeof r != "number" || Number.isFinite(r)) && (n[e] = r);
			}
		}
	};
	return i(e()), n;
});
//#endregion
export { m as HorizontalAlignment, g as ResourceDictionary, v as SolidColorBrush, _ as StaticResource, p as Thickness, h as VerticalAlignment, f as XamlBoolean, u as XamlDouble, d as XamlInt32, C as primitiveResourceScope, S as primitiveResourceStyles, c as xamlPrimitiveResourceKey };

//# sourceMappingURL=xamlPrimitives.js.map