import { entranceSpline as e, opacitySpline as t, page as n, scale as r, tween as i } from "./shared.js";
//#region src/components/navigationTransitions/drillIn.ts
var a = (a) => {
	let o = a ? 1.06 : .94, s = a ? 333 : 783, c = a ? "cubic-bezier(0.12, 0, 0, 1)" : e;
	return {
		Entrance: n([i("transform", r(o), r(1), s, c), i("opacity", 0, 1, 333, t)], {
			opacity: 0,
			transform: r(o)
		}, "50% 50%"),
		Exit: n([i("transform", r(1), r(a ? .96 : 1.04), 100, e), i("opacity", 1, 0, 100, t)], {}, "50% 50%")
	};
};
//#endregion
export { a as createDrillInStoryboards };

//# sourceMappingURL=drillIn.js.map