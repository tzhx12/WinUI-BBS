//#region src/components/navigationTransitions/suppress.ts
var e = () => null;
//#endregion
export { e as createSuppressStoryboards };

//# sourceMappingURL=suppress.js.map