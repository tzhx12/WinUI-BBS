import { attachedElements as e, discreteOpacity as t, entranceSpline as n, exitSpline as r, page as i, translateY as a, tween as o } from "./shared.js";
//#region src/components/navigationTransitions/entrance.ts
var s = (e) => e ? {
	Entrance: i([o("opacity", 0, 1, 300, n, 150)], { opacity: 0 }),
	Exit: i([o("transform", a(0), a(140), 150, r), t(1, 0, 150)], {})
} : {
	Entrance: i([o("transform", a(140), a(0), 300, n, 150), t(0, 1, 150)], {
		opacity: 0,
		transform: a(140)
	}),
	Exit: i([o("opacity", 1, 0, 150, r)], {})
}, c = (t, n, r) => [{
	Element: e(n, "EntranceNavigationTransitionInfo.IsTargetElement")[0] ?? n,
	Storyboard: r ? t.Entrance : t.Exit
}];
//#endregion
export { s as createEntranceStoryboards, c as resolveEntranceStoryboards };

//# sourceMappingURL=entrance.js.map