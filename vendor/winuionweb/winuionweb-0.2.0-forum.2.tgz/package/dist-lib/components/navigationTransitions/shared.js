//#region src/components/navigationTransitions/shared.ts
var e = "cubic-bezier(0.1, 0.9, 0.2, 1)", t = "cubic-bezier(0.7, 0, 1, 0.5)", n = "cubic-bezier(0.17, 0.17, 0, 1)", r = (e) => (t) => Math.expm1(e * t) / Math.expm1(e), i = (e) => (t) => 1 - r(e)(1 - t), a = (e) => e < .5 ? r(.75)(e * 2) / 2 : 1 - r(.75)((1 - e) * 2) / 2, o = (e) => Math.sqrt(1 - (e - 1) ** 2), s = (e) => 1 - (1 - e) ** 2, c = (e, t, n, r, i = "linear", a = 0) => ({
	Keyframes: [{ [e]: t }, { [e]: n }],
	Duration: r,
	Delay: a,
	Easing: i
}), l = (e, t, n, r, i, a = (e) => e, o = 0, s = Math.max(1, Math.ceil(r))) => ({
	Keyframes: Array.from({ length: s + 1 }, (r, o) => {
		let c = o / s;
		return {
			offset: c,
			[e]: a(t + (n - t) * i(c))
		};
	}),
	Duration: r,
	Delay: o,
	Easing: "linear"
}), u = (e, t, n) => c("opacity", e, t, n, "steps(1, end)"), d = (e, t, n) => {
	let r = /* @__PURE__ */ new Set();
	for (let t of e) {
		let e = Object.keys(t.Keyframes[0] ?? {}).find((e) => e !== "offset");
		e && r.has(e) && (t.Fill = "forwards"), e && r.add(e);
	}
	return {
		Tracks: e,
		InitialStyle: t,
		TransformOrigin: n
	};
}, f = (e) => `scale(${e})`, p = (e) => `translateY(${e}px)`, m = `matrix3d(${1e3 / 999}, 0, 0, 0, 0, ${1e3 / 999}, 0, 0, 0, 0, 1, ${-1 / 999}, 0, 0, 0, 1)`, h = (e, t) => ["true", "True"].includes(e.getAttribute(t) ?? ""), g = (e, t) => Array.from(e.querySelectorAll("*")).filter((e) => h(e, t)), _ = (e, t) => {
	let n = e instanceof HTMLElement ? e : e && typeof e == "object" ? e.$el ?? e.Element : null;
	return n instanceof HTMLElement && t.contains(n) ? n : null;
};
//#endregion
export { g as attachedElements, o as circleOut, u as discreteOpacity, e as entranceSpline, t as exitSpline, r as exponentialIn, a as exponentialInOut, i as exponentialOut, n as opacitySpline, d as page, m as planeProjection, s as quadraticOut, l as sampled, f as scale, _ as transitionElement, p as translateY, c as tween };

//# sourceMappingURL=shared.js.map