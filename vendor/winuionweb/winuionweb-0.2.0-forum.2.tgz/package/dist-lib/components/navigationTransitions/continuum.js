import { attachedElements as e, circleOut as t, exponentialIn as n, exponentialInOut as r, exponentialOut as i, page as a, planeProjection as o, quadraticOut as s, sampled as c, scale as l, transitionElement as u, translateY as d, tween as f } from "./shared.js";
//#region src/components/navigationTransitions/continuum.ts
var p = (e) => e ? {
	Entrance: a([c("opacity", 0, 1, 350, t, void 0, 267)], { opacity: 0 }),
	Exit: a([
		c("transform", 0, 200, 250, n(6), d),
		f("opacity", 1, 1, 240),
		f("opacity", 1, 0, 10, "linear", 240)
	], {})
} : {
	Entrance: a([
		c("transform", .9, 1, 350, t, l, 267),
		f("opacity", 0, 0, 266),
		f("opacity", 0, 1, 1, "linear", 266)
	], {
		opacity: 0,
		transform: l(.9)
	}, "50% 50%"),
	Exit: a([f("opacity", 1, 1, 120), c("opacity", 1, 0, 130, t, void 0, 120)], {})
}, m = (e, t) => !t && e ? null : e ? a([
	c("transform", 90, 0, 200, i(4), (e) => `translate(50%, 50%) ${o} translate(-50%, -50%) rotateX(${e}deg)`, 267),
	c("translate", -20, 0, 200, i(4), (e) => `0 ${e}px`, 267),
	f("opacity", 0, 0, 266),
	f("opacity", 0, 1, 1, "linear", 266)
], {}, "0% 0%") : t ? a([
	c("transform", 50, 0, 350, s, (e) => `translate(50%, 50%) ${o} translate(-50%, 50%) rotateX(${e}deg) translateY(-100%)`, 267),
	c("translate", 200, -40, 100, i(8), (e) => `0 ${e}px`, 267),
	c("translate", -40, 0, 250, r, (e) => `0 ${e}px`, 367),
	c("scale", 1.5, 1, 350, s, (e) => String(e), 267),
	c("opacity", 0, 1, 167, i(6), void 0, 267)
], {}, "0% 0%") : a([
	c("transform", 0, -80, 120, n(2), (e) => `translate(50%, -50%) ${o} translate(-50%, 50%) rotateX(${e}deg)`),
	c("translate", 0, 200, 120, n(6), (e) => `0 ${e}px`),
	c("scale", 1, 1.5, 120, n(6), (e) => String(e)),
	f("opacity", 1, 1, 100),
	f("opacity", 1, 0, 20, "linear", 100)
], {}, "0% 100%"), h = (t, n, r) => {
	let i = [{
		Element: n,
		Storyboard: r ? t.Entrance : t.Exit
	}], a = r && !t.IsBack ? e(n, "ContinuumNavigationTransitionInfo.IsEntranceElement")[0] : u(t.Info.ExitElement, n), o = m(t.IsBack, r);
	return a && o && i.push({
		Element: a,
		Storyboard: o
	}), i;
};
//#endregion
export { p as createContinuumStoryboards, h as resolveContinuumStoryboards };

//# sourceMappingURL=continuum.js.map