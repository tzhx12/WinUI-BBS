import { attachedElements as e, exponentialIn as t, exponentialOut as n, page as r, planeProjection as i, sampled as a, tween as o } from "./shared.js";
//#region src/components/navigationTransitions/common.ts
var s = "50% 50% 0px", c = (e) => `${i} translate3d(-60%, 0, -100px) rotateY(${e}deg) translate3d(60%, 0, 100px)`, l = (e) => {
	let i = e ? -50 : 80, l = e ? 80 : -50;
	return {
		Entrance: r([
			a("transform", i, 0, 428, n(6), c, 128),
			o("opacity", 0, 0, 128),
			o("opacity", 0, 1, 1, "linear", 128)
		], {
			opacity: 0,
			transform: c(i)
		}, s),
		Exit: r([
			a("transform", 0, l, 128, t(6), c),
			o("opacity", 1, 1, 128),
			o("opacity", 1, 0, 1, "linear", 128)
		], {}, s)
	};
}, u = (i, l, u) => {
	let d = u ? i.Entrance : i.Exit;
	if (i.Info.IsStaggeringEnabled !== !0 && i.Info.IsStaggeringEnabled !== "True") return [{
		Element: l,
		Storyboard: d
	}];
	let f = l.getBoundingClientRect(), p = e(l, "CommonNavigationTransitionInfo.IsStaggerElement").filter((e) => {
		let t = e.getBoundingClientRect();
		return t.width > 0 && t.height > 0 && t.left <= f.right && t.right >= f.left && t.top <= f.bottom && t.bottom >= f.top;
	});
	if (!p.length) return [{
		Element: l,
		Storyboard: d
	}];
	let m = i.IsBack ? -50 : 80, h = i.IsBack ? 80 : -50;
	return [{
		Element: l,
		Storyboard: r(d.Tracks.filter((e) => "opacity" in e.Keyframes[0]), {})
	}, ...p.map((e, l) => {
		let d = u ? 64 + l * 33 : l * 33, f = u ? 278 + l * 33 : 64 + l * 33;
		return {
			Element: e,
			Storyboard: r([
				a("transform", u ? m : 0, u ? 0 : h, f - d, u ? i.IsBack ? (e) => e : n(6) : i.IsBack ? t(6) : (e) => e, c, d),
				o("opacity", +!u, +!u, u ? d : f),
				o("opacity", +!u, +!!u, 1, "linear", u ? d : f)
			], {}, s)
		};
	})];
};
//#endregion
export { l as createCommonStoryboards, u as resolveCommonStoryboards };

//# sourceMappingURL=common.js.map