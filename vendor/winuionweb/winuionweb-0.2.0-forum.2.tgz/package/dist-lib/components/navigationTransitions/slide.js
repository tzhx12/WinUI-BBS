import { discreteOpacity as e, entranceSpline as t, exitSpline as n, exponentialIn as r, exponentialOut as i, page as a, sampled as o, translateY as s, tween as c } from "./shared.js";
//#region src/components/navigationTransitions/slide.ts
var l = (l, u) => {
	if (u.Effect === "FromLeft" || u.Effect === "FromRight") {
		let r = u.Effect === "FromLeft" ? 1 : -1, i = (l ? 150 : -200) * r, o = (l ? -200 : 150) * r, s = (e) => `translateX(${e}px)`;
		return {
			Entrance: a([c("transform", s(i), s(0), 300, t, 150), e(0, 1, 150)], {
				opacity: 0,
				transform: s(i)
			}),
			Exit: a([c("transform", s(0), s(o), 150, n), e(1, 0, 150)], {})
		};
	}
	return l ? {
		Entrance: a([e(0, 1, 250)], { opacity: 0 }),
		Exit: a([o("transform", 0, 200, 600, r(6), s), e(1, 0, 250)], {})
	} : {
		Entrance: a([o("transform", 200, 0, 350, i(6), s, 250), e(0, 1, 250)], {
			opacity: 0,
			transform: s(200)
		}),
		Exit: a([e(1, 0, 250)], {})
	};
};
//#endregion
export { l as createSlideStoryboards };

//# sourceMappingURL=slide.js.map