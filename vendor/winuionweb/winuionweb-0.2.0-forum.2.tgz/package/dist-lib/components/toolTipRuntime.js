//#region src/components/toolTipRuntime.ts
var e = Symbol("winui-tool-tip-owner"), t = /* @__PURE__ */ new WeakMap(), n = (e, n) => {
	let r = e.hasAttribute("tooltipservice.tooltip");
	return r || e.setAttribute("tooltipservice.tooltip", ""), t.set(e, n), () => {
		t.get(e) === n && (t.delete(e), r || e.removeAttribute("tooltipservice.tooltip"));
	};
}, r = (e) => t.get(e), i = (e, t, n) => {
	let r = [t, n].flatMap((e) => [
		{
			x: e.left,
			y: e.top
		},
		{
			x: e.right,
			y: e.top
		},
		{
			x: e.right,
			y: e.bottom
		},
		{
			x: e.left,
			y: e.bottom
		}
	]).sort((e, t) => e.x - t.x || e.y - t.y), i = (e, t, n) => (t.x - e.x) * (n.y - e.y) - (t.y - e.y) * (n.x - e.x), a = (e) => {
		let t = [];
		for (let n of e) {
			for (; t.length >= 2 && i(t[t.length - 2], t[t.length - 1], n) <= 0;) t.pop();
			t.push(n);
		}
		return t;
	}, o = [...a(r).slice(0, -1), ...a([...r].reverse()).slice(0, -1)];
	return o.length >= 3 && o.every((t, n) => i(t, o[(n + 1) % o.length], e) >= -.5);
};
//#endregion
export { i as isInToolTipSafeZone, n as registerToolTip, r as registeredToolTip, e as toolTipOwnerContextKey };

//# sourceMappingURL=toolTipRuntime.js.map