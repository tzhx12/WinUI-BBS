import { cssLength as e, xamlThickness as t } from "./layout.js";
import { resolveBrushStyle as n } from "./AcrylicBrush.js";
import { normalizeXamlNodes as r, resolveXamlHandler as i, resolveXamlValue as ee, updateXamlBinding as a, xamlControlIdentityKey as o } from "./xamlRuntime.js";
import { frameworkLayoutStyle as te } from "./frameworkLayout.js";
import ne from "./Viewbox.vue.js";
import { useI18n as re } from "./i18n/index.js";
import { ToolTipServiceToolTip as s, getToolTipServiceProperty as c } from "./ToolTipServiceProperties.js";
import { isHoverPointer as l } from "./pointerInput.js";
import ie from "./ToolTip.vue.js";
import ae from "./IconSourceElement.vue.js";
import { pivotNodes as oe, pivotRootAttributes as se, pivotTemplate as ce, pivotText as le, renderPivotPresenter as ue } from "./PivotProperties.js";
import { TabViewTemplateToolTip as de } from "./tabViewToolTip.js";
import { getTabViewProperty as fe, tabViewItemIdentityKey as pe, tabViewItemLiveControlKey as u, tabViewItemOwnerKey as me, tabViewItemProperties as d, tabViewItemRecordKey as he, tabViewPropertyChildren as ge } from "./TabViewProperties.js";
/* empty css                  */
import { Fragment as f, cloneVNode as p, computed as m, defineComponent as h, getCurrentInstance as _e, h as g, inject as _, isVNode as v, nextTick as ve, onBeforeUnmount as ye, onMounted as be, ref as y, shallowReactive as xe, shallowRef as Se, useAttrs as Ce, useSlots as we, watch as b } from "vue";
var x = /*@__PURE__*/ h({
	...d,
	name: "TabViewItem",
	inheritAttrs: !1,
	__name: "TabViewItem",
	props: {
		Header: {
			type: null,
			default: null
		},
		HeaderTemplate: {
			type: null,
			default: null
		},
		IconSource: {
			type: null,
			default: null
		},
		Content: {
			type: null,
			default: null
		},
		ContentTemplate: {
			type: null,
			default: null
		},
		IsClosable: {
			type: null,
			default: !0
		},
		IsEnabled: {
			type: null,
			default: !0
		},
		IsSelected: {
			type: null,
			default: !1
		},
		IsTabStop: {
			type: null,
			default: !0
		},
		Visibility: {
			type: null,
			default: "Visible"
		},
		Background: {
			type: null,
			default: ""
		},
		Foreground: {
			type: null,
			default: ""
		},
		BorderBrush: {
			type: null,
			default: ""
		},
		BorderThickness: {
			type: null,
			default: 1
		},
		CornerRadius: {
			type: null,
			default: "{ThemeResource OverlayCornerRadius}"
		},
		Width: {
			type: null,
			default: ""
		},
		Height: {
			type: null,
			default: ""
		},
		MinWidth: {
			type: null,
			default: ""
		},
		MaxWidth: {
			type: null,
			default: ""
		},
		MinHeight: {
			type: null,
			default: 32
		},
		MaxHeight: {
			type: null,
			default: ""
		},
		Margin: {
			type: null,
			default: 0
		},
		Padding: {
			type: null,
			default: ""
		},
		HorizontalAlignment: {
			type: null,
			default: "Stretch"
		},
		VerticalAlignment: {
			type: null,
			default: "Stretch"
		},
		HorizontalContentAlignment: {
			type: null,
			default: "Stretch"
		},
		VerticalContentAlignment: {
			type: null,
			default: "Center"
		},
		FontSize: {
			type: null,
			default: 12
		},
		FontWeight: {
			type: null,
			default: "Normal"
		},
		Opacity: {
			type: null,
			default: 1
		},
		ContextFlyout: {
			type: null,
			default: null
		},
		AccessKey: {
			type: null,
			default: ""
		},
		DataContext: {
			type: null,
			default: null
		}
	},
	emits: ["CloseRequested", "update:IsSelected"],
	setup(d, { expose: x, emit: Te }) {
		let S = d, C = Te, w = _e(), T = Ce(), E = we(), D = _(me, null), O = _(he, void 0), k = y(null), Ee = y(null), A = y(!1), j = y(!1), M = Se(null), N = Se(null), P = xe({}), F = () => O ?? w?.vnode.key, I = (e) => ee(e, w), L = (e) => {
			let t = e in P ? P[e] : S[e];
			return /Template$/.test(e) && typeof t == "string" && /^\{(?:StaticResource|ThemeResource)\s/.test(t) ? t : I(t);
		}, R = m(() => oe(E.default?.() ?? [])), z = (e) => ge(R.value, "TabViewItem", e), B = m(() => D ? D.Selected(F()) : L("IsSelected") === !0), V = m(() => L("IsEnabled") !== !1 && (!D || D.Enabled())), De = m(() => D?.Compact(F()) ?? !1), H = m(() => L("IsClosable") !== !1), Oe = m(() => H.value && (!D || D.OverlayMode() !== "OnPointerOver" || B.value || A.value)), U = m(() => !!L("IconSource") || z("IconSource").length > 0), W = m(() => z("Content").length ? z("Content") : R.value.filter((e) => !fe(e, "TabViewItem") && !c(e))), G = m(() => R.value.filter(c)), ke = m(() => G.value.length > 0 || Object.keys(T).some((e) => e.toLowerCase() === "tooltipservice.tooltip")), Ae = m(() => typeof L("Header") == "string" ? String(L("Header")) : ""), K = m(() => {
			let e = Object.keys(T).find((e) => e.toLowerCase() === "tooltipservice.tooltip"), t = e ? T[e] : void 0;
			return typeof t == "string" && /^\{(?:StaticResource|ThemeResource)\s+([^}]+)\}$/.exec(t)?.[1]?.trim() ? ce(t, w) ?? I(t) : I(t);
		}), je = h({ setup: () => () => {
			if (G.value.length) return g(f, r(G.value, w));
			let e = K.value;
			return v(e) ? g(s, {}, () => r([p(e)], w)) : e && typeof e == "object" ? g(s, {}, () => g(ie, e)) : null;
		} }), Me = h({ setup: () => () => ue(L("Header"), "Header" in P ? [] : z("Header"), L("HeaderTemplate"), z("HeaderTemplate"), w) }), q = m(() => Number(I("{ThemeResource TabViewItemHeaderIconSize}")) || 16), J = h({ setup: () => () => g(ne, {
			MaxWidth: q.value,
			MaxHeight: q.value,
			class: "win-tab-view-icon-viewbox"
		}, () => g(ae, {
			ref: (e) => {
				N.value = e;
			},
			IconSource: L("IconSource")
		}, () => r(z("IconSource"), w))) }), Ne = h({ setup: () => () => {
			let e = z("ContextFlyout")[0] ?? (v(L("ContextFlyout")) ? L("ContextFlyout") : null);
			return e ? g(f, r([p(e, { ref: (e) => {
				M.value = e;
			} })], w)) : null;
		} }), Pe = m(() => {
			let e = se(T, w);
			for (let t of Object.keys(e)) if (t.toLowerCase().startsWith("tooltipservice.")) {
				let n = t.toLowerCase() === "tooltipservice.tooltip" ? K.value : I(e[t]);
				e[t] = n && typeof n == "object" ? "" : n;
			}
			return e;
		}), Fe = m(() => ({
			...te({
				...Object.fromEntries(Object.keys(S).map((e) => [e, L(e)])),
				Padding: "",
				Background: "",
				BorderBrush: "",
				BorderThickness: "",
				CornerRadius: ""
			}, w),
			width: L("Width") === "" ? D?.Width(F()) ? `${D.Width(F())}px` : void 0 : `${Number(L("Width"))}px`,
			color: L("Foreground") ? n(L("Foreground"), w).background : void 0,
			opacity: D?.Dragging(F()) ? .8 : String(L("Opacity")),
			"--tab-custom-foreground": L("Foreground") ? n(L("Foreground"), w).background : void 0,
			"--tab-custom-background": L("Background") ? n(L("Background"), w).background : void 0,
			"--tab-custom-border": L("BorderBrush") ? n(L("BorderBrush"), w).background : void 0,
			"--tab-corner-radius": e(L("CornerRadius")),
			"--tab-border-thickness": t(L("BorderThickness"))
		})), { t: Y } = re(), X = (e) => String(Y(e)), Ie = m(() => X("TabViewCloseButtonName")), Le = m(() => X("TabViewCloseButtonTooltipWithKA")), Re = m(() => V.value ? B.value ? j.value ? "PressedSelected" : A.value ? "PointerOverSelected" : "Selected" : j.value ? "Pressed" : A.value ? "PointerOver" : "Normal" : "Disabled"), Z = /* @__PURE__ */ new Map(), Q = (e, t, n) => {
			if (Z.get(e)?.cancel(), !k.value?.animate || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
			let r = k.value.animate(t, {
				duration: n,
				easing: "linear"
			});
			Z.set(e, r), r.finished.catch(() => {}).finally(() => {
				Z.get(e) === r && (Z.delete(e), r.cancel());
			});
		};
		b(() => D?.Dragging(F()) ?? !1, (e, t) => {
			e || (j.value = !1), !(!k.value || D?.IsNativeDrag()) && Q("DragStates", [{ opacity: t ? .8 : 1 }, { opacity: e ? .8 : 1 }], e ? 240 : 200);
		}), b(() => D?.ReorderHint(F()) ?? 0, (e, t) => {
			Q("ReorderHintStates", [{ transform: `translateX(${t}px)` }, { transform: `translateX(${e}px)` }], 200), k.value && (k.value.style.transform = e ? `translateX(${e}px)` : "");
		});
		let $ = new Proxy({
			[pe]: `tab-view-item-${w?.uid}`,
			get Element() {
				return k.value;
			},
			get $el() {
				return k.value;
			},
			get ParentTabView() {
				return D?.Api();
			},
			get TabView() {
				return D?.Api();
			},
			get IsSelected() {
				return B.value;
			},
			set IsSelected(e) {
				e ? D?.Select(F()) : P.IsSelected = e, a(S.IsSelected, e, w), C("update:IsSelected", e);
			},
			get Content() {
				return "Content" in P || S.Content !== null ? L("Content") : W.value.length ? g(f, r(W.value, w)) : null;
			},
			get ContentTemplate() {
				return z("ContentTemplate").length ? z("ContentTemplate") : L("ContentTemplate");
			},
			get ActualWidth() {
				return k.value?.clientWidth ?? 0;
			},
			get ActualHeight() {
				return k.value?.clientHeight ?? 0;
			},
			get TabViewTemplateSettings() {
				return {
					IconElement: U.value ? g(J) : null,
					TabGeometry: k.value ? `M0,${k.value.clientHeight} L0,4 Q0,0 4,0 L${k.value.clientWidth - 4},0 Q${k.value.clientWidth},0 ${k.value.clientWidth},4 L${k.value.clientWidth},${k.value.clientHeight} Z` : ""
				};
			},
			Focus() {
				return k.value?.focus(), !!k.value;
			},
			RequestClose() {
				V.value && H.value && D?.Close(F());
			},
			RaiseCloseRequested(e) {
				let t = D?.Container(F()) ?? $;
				C("CloseRequested", t, e), i(T.CloseRequested, w)?.(t, e);
			}
		}, {
			get(e, t, n) {
				let r = e[u];
				return t !== u && t !== o && r && r !== n ? Reflect.get(r, t, r) : Reflect.get(e, t, n);
			},
			set(e, t, n, r) {
				let i = e[u];
				return t !== u && i && i !== r ? Reflect.set(i, t, n, i) : Reflect.set(e, t, n, r);
			}
		});
		Object.defineProperty($, o, { value: $ });
		for (let e of Object.keys(S)) [
			"IsSelected",
			"Content",
			"ContentTemplate"
		].includes(e) || (Object.defineProperty($, e, {
			enumerable: !0,
			configurable: !0,
			get: () => e === "IconSource" ? N.value?.IconSource ?? L(e) : e === "ContextFlyout" ? M.value ?? L(e) : e === "Header" && z("Header").length && !("Header" in P) ? g(f, r(z("Header"), w)) : L(e),
			set: (t) => {
				P[e] = t, a(S[e], t, w);
			}
		}), b(() => I(S[e]), () => {
			delete P[e];
		}));
		Object.defineProperty($, "Content", {
			enumerable: !0,
			configurable: !0,
			get: () => "Content" in P || S.Content !== null ? L("Content") : W.value.length ? g(f, r(W.value, w)) : null,
			set: (e) => {
				P.Content = e, a(S.Content, e, w);
			}
		}), Object.defineProperty($, "ContentTemplate", {
			enumerable: !0,
			configurable: !0,
			get: () => z("ContentTemplate").length ? z("ContentTemplate") : L("ContentTemplate"),
			set: (e) => {
				P.ContentTemplate = e, a(S.ContentTemplate, e, w);
			}
		});
		let ze = () => {
			V.value && D?.Select(F());
		}, Be = (e) => {
			!V.value || e.target?.closest(".win-tab-view-close-button") || e.button === 0 && (j.value = !0, l(e) || (A.value = !1), D?.PointerDown(e, F()));
		}, Ve = (e) => {
			j.value = !1, l(e) || (A.value = !1), e.button === 1 && H.value && A.value && (e.preventDefault(), D?.Close(F()));
		}, He = (e) => {
			V.value && ((e.key === "Enter" || e.key === " ") && (e.preventDefault(), ze()), D?.KeyDown(e, F()));
		}, Ue = async (e) => {
			let t = M.value ?? L("ContextFlyout");
			!V.value || !t?.ShowAt || (e.preventDefault(), await t.ShowAt(k.value, { Position: {
				X: e.clientX - (k.value?.getBoundingClientRect().left ?? 0),
				Y: e.clientY - (k.value?.getBoundingClientRect().top ?? 0)
			} }));
		};
		b(V, (e) => {
			e || (j.value = !1, A.value = !1);
		}), b(() => L("IsSelected"), (e) => {
			e === !0 && D && D.Select(F());
		}), b(B, (e) => {
			a(S.IsSelected, e, w), C("update:IsSelected", e);
		}), be(async () => {
			D?.SetContainer(F(), $), await ve(), D?.SetElement(F(), k.value), k.value && Object.assign(k.value, {
				TabViewItem: D?.Container(F()) ?? $,
				ParentTabView: D?.Api()
			});
		}), ye(() => {
			for (let e of Z.values()) e.cancel();
			Z.clear(), D?.SetElement(F(), null), D?.SetContainer(F(), null);
		}), x($);
		let We = {
			props: S,
			emit: C,
			instance: w,
			attrs: T,
			slots: E,
			owner: D,
			recordKey: O,
			rootRef: k,
			closeButtonRef: Ee,
			hovered: A,
			pressed: j,
			contextFlyout: M,
			realizedIconSource: N,
			overrides: P,
			key: F,
			value: I,
			property: L,
			nodes: R,
			children: z,
			selected: B,
			enabled: V,
			compact: De,
			closable: H,
			showClose: Oe,
			hasIcon: U,
			contentNodes: W,
			toolTipDeclarations: G,
			hasAuthorToolTip: ke,
			headerToolTip: Ae,
			authorToolTip: K,
			ToolTipDeclarationOutlet: je,
			HeaderOutlet: Me,
			iconSize: q,
			IconOutlet: J,
			ContextFlyoutOutlet: Ne,
			rootAttrs: Pe,
			rootStyle: Fe,
			t: Y,
			localized: X,
			closeName: Ie,
			closeTooltip: Le,
			visualState: Re,
			runningAnimations: Z,
			animateState: Q,
			publicApi: $,
			select: ze,
			pointerDown: Be,
			pointerUp: Ve,
			keyDown: He,
			contextMenu: Ue,
			get TabViewTemplateToolTip() {
				return de;
			},
			get isHoverPointer() {
				return l;
			},
			get tabViewText() {
				return le;
			}
		};
		return Object.defineProperty(We, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), We;
	}
});
//#endregion
export { x as default };

//# sourceMappingURL=TabViewItem.vue_vue_type_script_setup_true_lang.js.map