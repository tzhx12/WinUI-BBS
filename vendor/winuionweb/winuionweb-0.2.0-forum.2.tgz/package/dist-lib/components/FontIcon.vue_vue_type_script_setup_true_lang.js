import { cssLength as e } from "./layout.js";
import { xamlScopeKey as t } from "./xamlRuntime.js";
import { iconBoolean as n, iconElementProps as r, iconFontFamily as i, iconFontWeight as a, useIconElement as o } from "./iconElementRuntime.js";
import s from "./Grid.vue.js";
import c from "./TextBlock.vue.js";
import { computed as l, defineComponent as u, getCurrentInstance as d, nextTick as f, onBeforeUnmount as p, onMounted as m, provide as h, useAttrs as g, watch as _ } from "vue";
//#region src/components/FontIcon.vue?vue&type=script&setup=true&lang.ts
var v = /*@__PURE__*/ u({
	inheritAttrs: !1,
	__name: "FontIcon",
	props: {
		Glyph: {
			type: [String, Number],
			default: ""
		},
		FontFamily: {
			type: String,
			default: "Segoe Fluent Icons,Segoe MDL2 Assets"
		},
		FontSize: {
			type: [String, Number],
			default: 20
		},
		FontStyle: {
			type: String,
			default: "Normal"
		},
		FontWeight: {
			type: [String, Number],
			default: "Normal"
		},
		IsTextScaleFactorEnabled: {
			type: [Boolean, String],
			default: !0
		},
		MirroredWhenRightToLeft: {
			type: [Boolean, String],
			default: !1
		},
		...r
	},
	setup(r, { expose: u }) {
		let v = r, y = g(), b = d(), { Element: x, read: S, layoutStyle: C, rootAttrs: w, api: T } = o(v, y, b, [
			"Glyph",
			"FontFamily",
			"FontSize",
			"FontStyle",
			"FontWeight",
			"IsTextScaleFactorEnabled",
			"MirroredWhenRightToLeft"
		]);
		u(T);
		let E = l(() => {
			let e = S("Glyph");
			return typeof e == "string" || typeof e == "number" ? String(e) : "";
		}), D = null, O = () => {
			let e = x.value, t = e?.querySelector(".win-font-icon-glyph");
			!e || !t || (t.style.transform = n(S("MirroredWhenRightToLeft")) && getComputedStyle(e).direction === "rtl" ? "scaleX(-1)" : "");
		}, k = () => {
			if (D?.disconnect(), D = null, O(), !(!n(S("MirroredWhenRightToLeft")) || !x.value)) {
				D = new MutationObserver(O);
				for (let e = x.value; e; e = e.parentElement) D.observe(e, {
					attributes: !0,
					attributeFilter: [
						"dir",
						"style",
						"class",
						"FlowDirection"
					]
				});
			}
		};
		_(() => [S("FlowDirection"), S("MirroredWhenRightToLeft")], () => {
			f(k);
		}), m(k), p(() => D?.disconnect()), h(t, {
			FontIconTemplateGlyph: E,
			FontIconTemplateFontFamily: l(() => i(S("FontFamily"))),
			FontIconTemplateFontSize: l(() => n(S("IsTextScaleFactorEnabled"), !0) ? `calc(${e(S("FontSize")) || "20px"} * var(--TextScaleFactor, 1))` : S("FontSize")),
			FontIconTemplateFontStyle: l(() => S("FontStyle")),
			FontIconTemplateFontWeight: l(() => a(S("FontWeight")))
		});
		let A = {
			props: v,
			attrs: y,
			instance: b,
			Element: x,
			read: S,
			layoutStyle: C,
			rootAttrs: w,
			api: T,
			glyph: E,
			get directionObserver() {
				return D;
			},
			set directionObserver(e) {
				D = e;
			},
			updateDirection: O,
			observeDirection: k,
			Grid: s,
			TextBlock: c
		};
		return Object.defineProperty(A, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), A;
	}
});
//#endregion
export { v as default };

//# sourceMappingURL=FontIcon.vue_vue_type_script_setup_true_lang.js.map