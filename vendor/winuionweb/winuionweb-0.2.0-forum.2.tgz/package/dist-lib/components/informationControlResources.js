//#region src/components/informationControlResources.ts
var e = Object.freeze({
	InfoBadgeMinHeight: 4,
	InfoBadgeMinWidth: 4,
	InfoBadgeMaxHeight: 16,
	InfoBadgeValueFontSize: 11,
	InfoBadgeIconWidth: 12,
	InfoBadgePadding: "0,0,0,0",
	IconInfoBadgeFontIconMargin: "4,0,4,2",
	ValueInfoBadgeTextMargin: "4,0,4,2",
	IconInfoBadgeIconMargin: "4,4,4,4",
	InfoBarTitleFontSize: 14,
	InfoBarTitleFontWeight: "SemiBold",
	InfoBarMessageFontSize: 14,
	InfoBarMessageFontWeight: "Normal",
	InfoBarMinHeight: 48,
	InfoBarCloseButtonSize: 38,
	InfoBarCloseButtonGlyphSize: 16,
	InfoBarHyperlinkButtonMargin: "-12,0,0,0",
	InfoBarIconBackgroundGlyph: "",
	InfoBarInformationalIconGlyph: "",
	InfoBarErrorIconGlyph: "",
	InfoBarWarningIconGlyph: "",
	InfoBarSuccessIconGlyph: "",
	InfoBarContentRootPadding: "16,0,0,0",
	InfoBarIconMargin: "0,16,14,16",
	InfoBarIconFontSize: 16,
	InfoBarPanelMargin: "0,0,16,0",
	InfoBarPanelHorizontalOrientationPadding: "0,0,0,0",
	InfoBarPanelVerticalOrientationPadding: "0,14,0,18",
	InfoBarTitleHorizontalOrientationMargin: "0,14,0,0",
	InfoBarTitleVerticalOrientationMargin: "0,14,0,0",
	InfoBarMessageHorizontalOrientationMargin: "12,14,0,0",
	InfoBarMessageVerticalOrientationMargin: "0,4,0,0",
	InfoBarActionHorizontalOrientationMargin: "16,8,0,0",
	InfoBarActionVerticalOrientationMargin: "0,12,0,0",
	InfoBarCloseButtonSymbol: "Cancel"
});
//#endregion
export { e as informationControlResources };

//# sourceMappingURL=informationControlResources.js.map