import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./ToolTip.vue_vue_type_script_setup_true_lang.js";
/* empty css                                            */
import { Fragment as n, Teleport as r, createBlock as i, createElementBlock as a, createElementVNode as o, normalizeClass as s, normalizeStyle as c, openBlock as l, withDirectives as u } from "vue";
//#region src/components/ToolTip.vue
var d = {
	ref: "hostRef",
	style: { display: "none" },
	"aria-hidden": "true"
}, f = [
	"data-placement",
	"role",
	"aria-hidden",
	"aria-description"
], p = { class: "tooltip-content-clip" };
function m(e, t, m, h, g, _) {
	return l(), a(n, null, [o("span", d, null, 512), (l(), i(r, {
		to: h.teleportTarget,
		disabled: !h.teleportTarget
	}, [u((l(), a("div", {
		id: h.tooltipId,
		ref: "tooltipRef",
		popover: "manual",
		class: s([h.present ? "tooltip win-tooltip LayoutRoot" : "tooltip-content-cache", h.themeClass]),
		style: c([h.tooltipStyle, { display: h.present ? "flex" : "none" }]),
		"data-placement": h.actualPlacement,
		role: h.present ? "tooltip" : void 0,
		"aria-hidden": !h.isVisible || void 0,
		"aria-description": h.fullDescription || void 0
	}, [o("div", p, [h.contentNodes.length || h.hasContentTemplate || h.hasVisualContent ? (l(), i(h.ContentOutlet, { key: 0 })) : (l(), i(h.TextBlock, {
		key: 1,
		Text: "{x:Bind ToolTipText}",
		TextWrapping: "WrapWholeWords"
	}))])], 14, f)), [[
		h.vAcrylicBrush,
		h.backgroundStyle,
		void 0,
		{ "host-backdrop": !0 }
	], [h.vThemeShadow, {
		Translation: 16,
		Enabled: h.present
	}]])], 8, ["to", "disabled"]))], 64);
}
var h = /*#__PURE__*/ e(t, [["render", m], ["__file", "ToolTip.vue"]]);
//#endregion
export { h as default };

//# sourceMappingURL=ToolTip.vue.js.map