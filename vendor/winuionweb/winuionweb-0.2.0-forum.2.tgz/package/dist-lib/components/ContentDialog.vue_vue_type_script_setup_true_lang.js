import { cssLength as e, xamlThickness as t } from "./layout.js";
import { normalizeXamlNodes as n, resolveXamlHandler as r, resolveXamlValue as i, xamlNameScopeKey as ee, xamlScopeKey as a, xamlTemplateComponent as te } from "./xamlRuntime.js";
import { vThemeShadow as ne } from "./themeShadowVisual.js";
import re from "./Grid.vue.js";
import { xamlResourceDictionaryKey as ie } from "./Page.vue_vue_type_script_lang.js";
import ae from "./TextBlock.vue.js";
import oe from "./ScrollViewer.vue.js";
import se from "./Button.vue.js";
import ce from "./ColumnDefinition.vue.js";
import le from "./RowDefinition.vue.js";
import { acquireContentDialog as ue, contentDialogFocusableElements as de, createContentDialogEventArgs as fe } from "./contentDialogRuntime.js";
import { Fragment as pe, computed as o, defineComponent as me, getCurrentInstance as he, h as s, inject as ge, isVNode as _e, nextTick as ve, onBeforeUnmount as ye, onMounted as be, provide as xe, reactive as Se, ref as c, unref as Ce, useAttrs as we, useSlots as Te } from "vue";
//#region src/components/ContentDialog.vue?vue&type=script&setup=true&lang.ts
var l = (e) => me({
	name: `ContentDialog.${e}`,
	__contentDialogProperty: e.toLowerCase(),
	setup(e, { slots: t }) {
		return () => s(pe, t.default?.());
	}
}), Ee = /*@__PURE__*/ me({
	Title: l("Title"),
	Content: l("Content"),
	TitleTemplate: l("TitleTemplate"),
	ContentTemplate: l("ContentTemplate"),
	name: "ContentDialog",
	inheritAttrs: !1,
	__name: "ContentDialog",
	props: {
		Title: {
			type: [
				String,
				Number,
				Object
			],
			default: ""
		},
		Content: {
			type: [
				String,
				Number,
				Object
			],
			default: ""
		},
		TitleTemplate: {
			type: [
				String,
				Object,
				Function
			],
			default: void 0
		},
		ContentTemplate: {
			type: [
				String,
				Object,
				Function
			],
			default: void 0
		},
		PrimaryButtonText: {
			type: [String, Number],
			default: ""
		},
		SecondaryButtonText: {
			type: [String, Number],
			default: ""
		},
		CloseButtonText: {
			type: [String, Number],
			default: ""
		},
		PrimaryButtonStyle: {
			type: [String, Object],
			default: "{ThemeResource DefaultButtonStyle}"
		},
		SecondaryButtonStyle: {
			type: [String, Object],
			default: "{ThemeResource DefaultButtonStyle}"
		},
		CloseButtonStyle: {
			type: [String, Object],
			default: "{ThemeResource DefaultButtonStyle}"
		},
		PrimaryButtonCommand: {
			type: [
				Object,
				Function,
				String
			],
			default: void 0
		},
		SecondaryButtonCommand: {
			type: [
				Object,
				Function,
				String
			],
			default: void 0
		},
		CloseButtonCommand: {
			type: [
				Object,
				Function,
				String
			],
			default: void 0
		},
		PrimaryButtonCommandParameter: {
			type: null,
			default: void 0
		},
		SecondaryButtonCommandParameter: {
			type: null,
			default: void 0
		},
		CloseButtonCommandParameter: {
			type: null,
			default: void 0
		},
		DefaultButton: {
			type: String,
			default: "None"
		},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		IsPrimaryButtonEnabled: {
			type: [Boolean, String],
			default: !0
		},
		IsSecondaryButtonEnabled: {
			type: [Boolean, String],
			default: !0
		},
		FullSizeDesired: {
			type: [Boolean, String],
			default: !1
		},
		RequestedTheme: {
			type: String,
			default: "Default"
		},
		XamlRoot: {
			type: [Object, String],
			default: void 0
		},
		Style: {
			type: [String, Object],
			default: "{StaticResource DefaultContentDialogStyle}"
		},
		Foreground: {
			type: String,
			default: "{ThemeResource ContentDialogForeground}"
		},
		Background: {
			type: String,
			default: "{ThemeResource ContentDialogBackground}"
		},
		BorderBrush: {
			type: String,
			default: "{ThemeResource ContentDialogBorderBrush}"
		},
		BorderThickness: {
			type: [String, Number],
			default: "{ThemeResource ContentDialogBorderWidth}"
		},
		CornerRadius: {
			type: [String, Number],
			default: "{ThemeResource OverlayCornerRadius}"
		},
		FlowDirection: {
			type: String,
			default: "LeftToRight"
		}
	},
	emits: [
		"PrimaryButtonClick",
		"SecondaryButtonClick",
		"CloseButtonClick",
		"Opened",
		"Closing",
		"Closed",
		"Loaded"
	],
	setup(Ee, { expose: De }) {
		let Oe = Ee, u = he(), ke = we(), Ae = Te(), je = ge("winuiTheme", null), Me = ge(ie, null), d = Se({}), f = c(null), p = c(null), m = c(null), Ne = c(null), h = c(!1), g = c("Popup"), _ = c({}), Pe = `content-dialog-title-${u?.uid ?? 0}`, Fe = c(0), v = (e) => i(e in d ? d[e] : Oe[e], u), y = (e) => o({
			get: () => v(e),
			set: (t) => {
				d[e] = t;
			}
		}), b = (e) => v(e) !== !1 && v(e) !== "False", Ie = y("Title"), Le = y("Content"), x = y("PrimaryButtonText"), S = y("SecondaryButtonText"), C = y("CloseButtonText"), w = o(() => b("IsEnabled")), T = o(() => w.value && b("IsPrimaryButtonEnabled") && Z("Primary")), E = o(() => w.value && b("IsSecondaryButtonEnabled") && Z("Secondary")), Re = o(() => w.value && Z("Close")), ze = o(() => b("FullSizeDesired")), D = y("DefaultButton"), Be = y("Background"), O = c(null), k = (e) => o(() => D.value === e && (!O.value || O.value === e) ? "AccentButtonStyle" : v(`${e}ButtonStyle`)), Ve = k("Primary"), He = k("Secondary"), Ue = k("Close"), A = o(() => !!(x.value && S.value && C.value)), We = o(() => !!(x.value || S.value || C.value)), Ge = o(() => x.value ? "Visible" : "Collapsed"), Ke = o(() => S.value ? "Visible" : "Collapsed"), qe = o(() => C.value ? "Visible" : "Collapsed"), Je = o(() => A.value ? "{ThemeResource ContentDialogButtonSpacing}" : 0), Ye = o(() => A.value ? "*" : 0), Xe = o(() => !S.value && !C.value ? 4 : 0), Ze = o(() => A.value ? 2 : C.value ? 0 : 4), Qe = o(() => A.value ? "all-visible" : "partial-visible"), $e = o(() => String(i(ke["AutomationProperties.Name"], u) ?? "")), et = o(() => {
			Fe.value;
			let e = String(v("RequestedTheme") ?? "Default").toLowerCase();
			if (e === "light" || e === "dark") return `theme-${e}`;
			let t = String(Ce(je) ?? "").toLowerCase();
			if (t === "light" || t === "dark") return `theme-${t}`;
			let n = f.value?.closest(".theme-light, .theme-dark, [data-theme]");
			return n?.classList.contains("theme-dark") || n?.getAttribute("data-theme") === "dark" ? "theme-dark" : n?.classList.contains("theme-light") || n?.getAttribute("data-theme") === "light" ? "theme-light" : document.documentElement.classList.contains("theme-dark") || document.documentElement.dataset.theme === "dark" ? "theme-dark" : document.documentElement.classList.contains("theme-light") || document.documentElement.dataset.theme === "light" ? "theme-light" : window.matchMedia("(prefers-color-scheme: dark)").matches ? "theme-dark" : "theme-light";
		}), tt = o(() => ({
			..._.value,
			direction: v("FlowDirection") === "RightToLeft" ? "rtl" : "ltr"
		})), nt = o(() => ({
			color: String(v("Foreground")),
			backgroundColor: String(Be.value),
			borderColor: String(v("BorderBrush")),
			borderWidth: t(v("BorderThickness")),
			borderRadius: e(v("CornerRadius"))
		})), j = o(() => {
			let e = {
				title: [],
				content: [],
				titletemplate: [],
				contenttemplate: []
			}, t = (n) => {
				for (let r of n) {
					if (r.type === pe && Array.isArray(r.children)) {
						t(r.children);
						continue;
					}
					let n = r.type?.__contentDialogProperty, i = r.children;
					n && typeof i?.default == "function" ? e[n].push(...i.default()) : e.content.push(r);
				}
			};
			return t(Ae.default?.() ?? []), e;
		}), rt = (e) => me({
			name: `ContentDialog${e}Outlet`,
			setup() {
				return () => {
					let t = e === "title" ? "Title" : "Content", r = e === "title" ? "TitleTemplate" : "ContentTemplate";
					if (!(t in d) && j.value[e].length) return s(pe, n(j.value[e], u));
					let i = e === "title" ? Ie.value : Le.value, ee = r in d ? [] : j.value[`${e}template`];
					if (ee.length) return te(ee.flatMap((e) => e.type?.name === "DataTemplate" ? e.children?.default?.() ?? [] : [e]), i, u);
					let a = v(r);
					if (typeof a == "string") {
						let e = a.match(/^\{\s*(?:StaticResource|ThemeResource)\s+([^\s}]+)\s*\}$/)?.[1] ?? a.match(/^var\(--([^,)]+)\)$/)?.[1];
						e && (a = Me?.[e]);
					}
					if (typeof a == "function") return a(i);
					if (_e(a)) {
						let e = a.type;
						return te((e?.name ?? e?.__name) === "DataTemplate" ? a.children?.default?.() ?? [] : [a], i, u);
					}
					if (a && typeof a == "object" && ("render" in a || "setup" in a)) return s(a, { Content: i });
					if (_e(i)) return s(pe, n([i], u));
					if (i && typeof i == "object" && ("render" in i || "setup" in i)) return s(i);
					let ne = typeof i == "string" || typeof i == "number" ? i : "";
					return s(ae, e === "title" ? {
						Text: ne,
						FontSize: 20,
						FontWeight: "SemiBold",
						TextWrapping: "Wrap",
						MaxLines: 2
					} : {
						Text: ne,
						TextWrapping: "Wrap"
					});
				};
			}
		}), it = rt("title"), at = rt("content"), ot = o(() => !!(!("Title" in d) && j.value.title.length || Ie.value || !("TitleTemplate" in d) && j.value.titletemplate.length || v("TitleTemplate")));
		xe(ee, Se({}));
		let M = null, N = null, P = "None", F = !1, I = !1, L = !1, R = null, z = null, B = null, V = null, H = null, U = null, W = null, G = null, K = () => {
			Fe.value += 1;
		}, q = /* @__PURE__ */ new Map(), J = /* @__PURE__ */ new Set(), st = Object.fromEntries(Object.keys(Oe).map((e) => [e, y(e)])), Y = {
			ShowAsync: pt,
			Hide: ht
		};
		for (let [e, t] of Object.entries(st)) Object.defineProperty(Y, e, {
			enumerable: !0,
			get: () => e === "XamlRoot" ? t.value ?? f.value?.ownerDocument : t.value,
			set: (e) => {
				t.value = e;
			}
		});
		function X(e, t) {
			let n = u?.vnode.props?.[`on${e}`];
			for (let e of Array.isArray(n) ? n : [n]) typeof e == "function" && e(Y, t);
			r(ke[e], u)?.(Y, t);
		}
		function Z(e) {
			let t = v(`${e}ButtonCommand`);
			return !t?.CanExecute || t.CanExecute(v(`${e}ButtonCommandParameter`)) !== !1;
		}
		function ct() {
			let e = de(Ne.value)[0], t = D.value === "None" ? null : m.value?.querySelector(`[data-template-part="${D.value}Button"]:not([disabled])`), n = e ?? t ?? de(m.value)[0] ?? m.value;
			n?.focus({ preventScroll: !0 }), z = n ?? null;
		}
		function lt(e) {
			if (!h.value) return;
			let t = e.target;
			m.value?.contains(t) ? (z = t, O.value = t?.closest("[data-template-part=\"CommandSpace\"]") ? t.closest("[data-template-part$=\"Button\"]")?.getAttribute("data-template-part")?.replace("Button", "") ?? null : null) : (g.value === "InPlace" ? f.value?.parentElement?.contains(t) : !V || V.contains(t)) && (z?.isConnected ? z.focus({ preventScroll: !0 }) : ct());
		}
		function ut(e) {
			if (!(e.defaultPrevented || e.isComposing)) {
				if (e.key === "Tab") {
					let t = de(m.value), n = t.indexOf(document.activeElement);
					(!t.length || e.shiftKey && n <= 0 || !e.shiftKey && n === t.length - 1) && (e.preventDefault(), (e.shiftKey ? t.at(-1) : t[0])?.focus({ preventScroll: !0 }));
				} else if (e.key === "Escape") e.preventDefault(), e.stopPropagation(), C.value && w.value && Z("Close") ? $("Close") : ht();
				else if (e.key === "Enter" && !e.repeat) {
					if (e.target.closest("button, textarea, [contenteditable=\"true\"]")) return;
					let t = D.value;
					(t === "Primary" && x.value && T.value || t === "Secondary" && S.value && E.value || t === "Close" && C.value && w.value && Z("Close")) && (e.preventDefault(), e.stopPropagation(), $(t));
				}
			}
		}
		function Q() {
			if (!V || g.value === "InPlace") {
				_.value = {};
				return;
			}
			let e = V.getBoundingClientRect();
			_.value = {
				inset: "auto",
				left: `${e.left}px`,
				top: `${e.top}px`,
				width: `${e.width}px`,
				height: `${e.height}px`
			};
		}
		function dt() {
			if (g.value === "InPlace") return;
			let e = V ? V.children : document.body.children, t = (e) => {
				e === p.value || e.contains(p.value) || e.matches(".win-titlebar-caption-host.is-portal") || (q.has(e) || q.set(e, e.inert), e.inert = !0);
			};
			for (let n of Array.from(e)) n instanceof HTMLElement && t(n);
		}
		function ft() {
			document.removeEventListener("focusin", lt, !0), window.removeEventListener("resize", Q), window.removeEventListener("scroll", Q, !0), H?.disconnect(), H = null, U?.disconnect(), U = null;
			for (let [e, t] of q) e.inert = t;
			if (q.clear(), R?.isConnected && R.focus({ preventScroll: !0 }), !R || document.activeElement !== R) {
				let e = document.activeElement?.closest(".content-dialog-container");
				if (!e || e === p.value) {
					let e = V ?? (g.value === "InPlace" ? f.value?.parentElement : null) ?? document.body;
					(de(e).find((e) => !e.closest(".content-dialog-container")) ?? (e.hasAttribute("tabindex") ? e : null))?.focus({ preventScroll: !0 });
				}
			}
			R = null, z = null;
		}
		function pt(e = "Popup") {
			if (![
				"Popup",
				"InPlace",
				"UnconstrainedPopup"
			].includes(e)) return Promise.reject(/* @__PURE__ */ Error("Invalid ContentDialogPlacement."));
			if (M) return Promise.reject(/* @__PURE__ */ Error("This ContentDialog already has a pending ShowAsync operation."));
			if (!f.value?.isConnected) return Promise.reject(/* @__PURE__ */ Error("ContentDialog must be associated with a XamlRoot before ShowAsync."));
			let t = v("XamlRoot"), n = t instanceof HTMLElement ? t : t?.$el ?? t?.Content;
			V = n instanceof HTMLElement ? n : null, B = t && typeof t == "object" ? t : f.value.ownerDocument;
			try {
				N = ue(B, Y, e === "InPlace" ? f.value.parentElement : null, f.value);
			} catch (e) {
				return Promise.reject(e);
			}
			g.value = e, F = !1, I = !1, L = !1, O.value = null, P = "None", R = document.activeElement instanceof HTMLElement ? document.activeElement : null;
			let r = new Promise((e, t) => {
				M = {
					resolve: e,
					reject: t
				};
			}), i = M;
			return Q(), h.value = !0, K(), ve().then(() => {
				M !== i || !h.value || I || (dt(), U = new MutationObserver(dt), U.observe(V ?? document.body, { childList: !0 }), document.addEventListener("focusin", lt, !0), window.addEventListener("resize", Q), window.addEventListener("scroll", Q, !0), V && (H = new ResizeObserver(Q), H.observe(V)), ct(), F = !0, X("Opened", {}));
			}).catch((e) => {
				M === i && _t(e);
			}), r;
		}
		async function $(e) {
			if (!M || I || L || !w.value || !Z(e) || e === "Primary" && !T.value || e === "Secondary" && !E.value) return;
			let t = M;
			L = !0;
			let n = fe();
			J.add(n);
			try {
				if (X(`${e}ButtonClick`, n.args), n.finishDispatch(), await n.completed, M !== t || n.args.Cancel || I) return;
				let r = v(`${e}ButtonCommand`), i = v(`${e}ButtonCommandParameter`);
				typeof r == "function" ? r(i) : r?.Execute?.(i), await mt(e === "Close" ? "None" : e);
			} catch (e) {
				M === t && _t(e);
			} finally {
				J.delete(n), M === t && (L = !1);
			}
		}
		async function mt(e) {
			if (!M || I) return;
			let t = M;
			I = !0;
			let n = fe(e);
			J.add(n);
			try {
				if (F && X("Closing", n.args), n.finishDispatch(), await n.completed, M !== t) return;
				if (n.args.Cancel) {
					I = !1;
					return;
				}
				P = e, N?.(), N = null, ft();
				let r = !!m.value;
				h.value = !1, r || gt();
			} catch (e) {
				M === t && _t(e);
			} finally {
				J.delete(n);
			}
		}
		function ht() {
			mt("None");
		}
		function gt() {
			if (!M) return;
			let e = M, t = P;
			M = null;
			for (let e of J) e.disconnect();
			J.clear(), I = !1, L = !1, F = !1;
			try {
				X("Closed", { Result: t });
			} finally {
				e.resolve(t);
			}
		}
		function _t(e) {
			let t = M;
			M = null;
			for (let e of J) e.disconnect();
			J.clear(), h.value = !1, ft(), N?.(), N = null, I = !1, L = !1, t?.reject(e);
		}
		let vt = () => {
			$("Primary");
		}, yt = () => {
			$("Secondary");
		}, bt = () => {
			$("Close");
		};
		xe(a, {
			DialogTitle: Ie,
			DialogContent: Le,
			DialogBackground: Be,
			PrimaryButtonText: x,
			SecondaryButtonText: S,
			CloseButtonText: C,
			PrimaryButtonVisibility: Ge,
			SecondaryButtonVisibility: Ke,
			CloseButtonVisibility: qe,
			PrimaryButtonStyle: Ve,
			SecondaryButtonStyle: He,
			CloseButtonStyle: Ue,
			IsPrimaryButtonEnabled: T,
			IsSecondaryButtonEnabled: E,
			IsCloseButtonEnabled: Re,
			IsEnabled: w,
			FirstSpacerWidth: Je,
			SecondaryColumnWidth: Ye,
			PrimaryButtonColumn: Xe,
			SecondaryButtonColumn: Ze,
			OnPrimaryButtonClick: vt,
			OnSecondaryButtonClick: yt,
			OnCloseButtonClick: bt
		}), be(() => {
			W = new MutationObserver(K), W.observe(document.documentElement, {
				attributes: !0,
				attributeFilter: ["class", "data-theme"]
			}), G = window.matchMedia("(prefers-color-scheme: dark)"), G.addEventListener("change", K), X("Loaded", { OriginalSource: Y });
		}), ye(() => {
			W?.disconnect(), G?.removeEventListener("change", K);
			for (let e of J) e.disconnect();
			J.clear(), M &&= (ft(), N?.(), N = null, M.resolve("None"), null);
		}), De({
			ShowAsync: pt,
			Hide: ht,
			...st
		});
		let xt = {
			propertyElement: l,
			props: Oe,
			instance: u,
			attrs: ke,
			slots: Ae,
			inheritedTheme: je,
			pageResources: Me,
			overrides: d,
			host: f,
			layoutRoot: p,
			backgroundElement: m,
			contentElement: Ne,
			isShowing: h,
			placement: g,
			rootBounds: _,
			titleId: Pe,
			themeRevision: Fe,
			resolve: v,
			property: y,
			boolean: b,
			DialogTitle: Ie,
			DialogContent: Le,
			PrimaryButtonText: x,
			SecondaryButtonText: S,
			CloseButtonText: C,
			IsEnabled: w,
			IsPrimaryButtonEnabled: T,
			IsSecondaryButtonEnabled: E,
			IsCloseButtonEnabled: Re,
			FullSizeDesired: ze,
			DefaultButton: D,
			DialogBackground: Be,
			focusedCommand: O,
			buttonStyle: k,
			PrimaryButtonStyle: Ve,
			SecondaryButtonStyle: He,
			CloseButtonStyle: Ue,
			allButtonsVisible: A,
			hasCommandButtons: We,
			PrimaryButtonVisibility: Ge,
			SecondaryButtonVisibility: Ke,
			CloseButtonVisibility: qe,
			FirstSpacerWidth: Je,
			SecondaryColumnWidth: Ye,
			PrimaryButtonColumn: Xe,
			SecondaryButtonColumn: Ze,
			buttonVisibilityClass: Qe,
			automationName: $e,
			themeClass: et,
			containerStyle: tt,
			backgroundStyle: nt,
			propertyNodes: j,
			outlet: rt,
			TitleOutlet: it,
			ContentOutlet: at,
			hasTitle: ot,
			get operation() {
				return M;
			},
			set operation(e) {
				M = e;
			},
			get releaseDialog() {
				return N;
			},
			set releaseDialog(e) {
				N = e;
			},
			get closingResult() {
				return P;
			},
			set closingResult(e) {
				P = e;
			},
			get opened() {
				return F;
			},
			set opened(e) {
				F = e;
			},
			get hideInProgress() {
				return I;
			},
			set hideInProgress(e) {
				I = e;
			},
			get buttonClickInProgress() {
				return L;
			},
			set buttonClickInProgress(e) {
				L = e;
			},
			get previousFocus() {
				return R;
			},
			set previousFocus(e) {
				R = e;
			},
			get lastFocus() {
				return z;
			},
			set lastFocus(e) {
				z = e;
			},
			get activeRoot() {
				return B;
			},
			set activeRoot(e) {
				B = e;
			},
			get rootElement() {
				return V;
			},
			set rootElement(e) {
				V = e;
			},
			get rootObserver() {
				return H;
			},
			set rootObserver(e) {
				H = e;
			},
			get backgroundObserver() {
				return U;
			},
			set backgroundObserver(e) {
				U = e;
			},
			get themeObserver() {
				return W;
			},
			set themeObserver(e) {
				W = e;
			},
			get themeMedia() {
				return G;
			},
			set themeMedia(e) {
				G = e;
			},
			updateTheme: K,
			backgroundInert: q,
			deferralEvents: J,
			apiProperties: st,
			sender: Y,
			dispatch: X,
			canExecute: Z,
			focusInitial: ct,
			onFocusIn: lt,
			onKeyDown: ut,
			updateRootBounds: Q,
			isolateBackground: dt,
			releaseInteraction: ft,
			ShowAsync: pt,
			clickButton: $,
			close: mt,
			Hide: ht,
			finishClose: gt,
			failOperation: _t,
			OnPrimaryButtonClick: vt,
			OnSecondaryButtonClick: yt,
			OnCloseButtonClick: bt,
			Button: se,
			Grid: re,
			RowDefinition: le,
			ColumnDefinition: ce,
			ScrollViewer: oe,
			get vThemeShadow() {
				return ne;
			}
		};
		return Object.defineProperty(xt, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), xt;
	}
});
//#endregion
export { Ee as default };

//# sourceMappingURL=ContentDialog.vue_vue_type_script_setup_true_lang.js.map