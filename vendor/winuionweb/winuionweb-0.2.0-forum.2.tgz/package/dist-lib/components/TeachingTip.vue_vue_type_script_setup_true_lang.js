import { useAcrylicBrushStyle as e } from "./AcrylicBrush.js";
import { normalizeXamlNodes as t, resolveXamlHandler as n, resolveXamlValue as r, updateXamlBinding as i, xamlScopeKey as a } from "./xamlRuntime.js";
import { vAcrylicBrush as o } from "./acrylicBrushVisual.js";
import { createThemeShadow as s } from "./themeShadowRuntime.js";
import ee from "./Grid.vue.js";
import te from "./SymbolIcon.vue.js";
import { fitPopupPosition as ne, popupBoundsFor as re, resolvePopupElement as ie } from "./popupRuntime.js";
import { useI18n as ae } from "./i18n/index.js";
import oe from "./TextBlock.vue.js";
import se from "./ScrollViewer.vue.js";
import ce from "./Border.vue.js";
import le from "./Button.vue.js";
import ue from "./ColumnDefinition.vue.js";
import de from "./RowDefinition.vue.js";
import fe from "./StackPanel.vue.js";
import { TeachingTipActionButtonContent as pe, TeachingTipCloseButtonContent as me, TeachingTipContent as he, TeachingTipHeroContent as c, TeachingTipIconSource as ge, getTeachingTipProperty as _e } from "./TeachingTipProperties.js";
import { teachingTipPlacement as ve, teachingTipTailSide as ye, teachingTipThickness as be } from "./teachingTipPlacement.js";
import { Fragment as xe, computed as l, defineComponent as Se, getCurrentInstance as Ce, h as we, inject as Te, isVNode as Ee, nextTick as De, onBeforeUnmount as Oe, onMounted as ke, provide as Ae, proxyRefs as je, ref as u, shallowReactive as Me, unref as Ne, useAttrs as Pe, useSlots as Fe, watch as d } from "vue";
var f = /*@__PURE__*/ Se({
	HeroContent: c,
	Content: he,
	IconSource: ge,
	ActionButtonContent: pe,
	CloseButtonContent: me,
	name: "TeachingTip",
	inheritAttrs: !1,
	__name: "TeachingTip",
	props: {
		IsOpen: {
			type: [Boolean, String],
			default: void 0
		},
		Target: {
			type: [Object, String],
			default: null
		},
		Title: {
			type: String,
			default: ""
		},
		Subtitle: {
			type: String,
			default: ""
		},
		Content: {
			type: [
				String,
				Number,
				Object
			],
			default: null
		},
		HeroContent: {
			type: [
				String,
				Number,
				Object
			],
			default: null
		},
		ActionButtonContent: {
			type: [
				String,
				Number,
				Object
			],
			default: null
		},
		CloseButtonContent: {
			type: [
				String,
				Number,
				Object
			],
			default: null
		},
		ActionButtonStyle: {
			type: [String, Object],
			default: "{ThemeResource DefaultButtonStyle}"
		},
		CloseButtonStyle: {
			type: [String, Object],
			default: "{ThemeResource DefaultButtonStyle}"
		},
		ActionButtonCommand: {
			type: [
				Function,
				Object,
				String
			],
			default: null
		},
		ActionButtonCommandParameter: { default: null },
		CloseButtonCommand: {
			type: [
				Function,
				Object,
				String
			],
			default: null
		},
		CloseButtonCommandParameter: { default: null },
		IconSource: {
			type: [String, Object],
			default: null
		},
		TailVisibility: {
			type: String,
			default: "Auto"
		},
		PreferredPlacement: {
			type: String,
			default: "Auto"
		},
		PlacementMargin: {
			type: [
				String,
				Number,
				Object
			],
			default: 0
		},
		ShouldConstrainToRootBounds: {
			type: [Boolean, String],
			default: !0
		},
		IsLightDismissEnabled: {
			type: [Boolean, String],
			default: !1
		},
		HeroContentPlacement: {
			type: String,
			default: "Auto"
		},
		RequestedTheme: {
			type: String,
			default: "Default"
		},
		Background: {
			type: String,
			default: "{ThemeResource TeachingTipBackgroundBrush}"
		},
		Foreground: {
			type: String,
			default: "{ThemeResource TeachingTipForegroundBrush}"
		},
		BorderBrush: {
			type: String,
			default: "{ThemeResource TeachingTipBorderBrush}"
		},
		BorderThickness: {
			type: [String, Number],
			default: 1
		},
		CornerRadius: {
			type: [String, Number],
			default: "{ThemeResource OverlayCornerRadius}"
		}
	},
	emits: [
		"update:IsOpen",
		"ActionButtonClick",
		"CloseButtonClick",
		"Closing",
		"Closed",
		"Opened"
	],
	setup(pe, { expose: me, emit: he }) {
		let c = pe, ge = he, f = Ce(), Ie = Pe(), Le = Fe(), { t: Re } = ae(), ze = Te("winuiTheme", null), p = u(null), m = u(null), h = u(!1), g = u(!1), Be = s(), Ve = l(() => g.value ? Be : null), _ = u(!1), He = u("light"), v = u({
			left: 0,
			top: 0,
			tailX: 160,
			tailY: 40
		}), y = u({
			width: 336,
			height: 520
		}), b = u({
			left: 0,
			top: 0,
			width: 0,
			height: 0
		}), x = u("Bottom"), S = (e) => r(e, f), C = Me({}), w = (e) => C[e] === void 0 ? S(c[e]) : C[e], T = (e) => (d(() => S(c[e]), () => {
			delete C[e];
		}), l({
			get: () => w(e),
			set: (t) => {
				C[e] = t, i(c[e], t, f);
			}
		})), E = (e) => S(e) === !0 || S(e) === "True", D = l(() => E(w("IsLightDismissEnabled"))), O = h;
		d(() => S(c.IsOpen), (e) => {
			e !== void 0 && (h.value = e === !0 || e === "True");
		}, { immediate: !0 });
		let k = T("Target"), A = T("Title"), j = T("Subtitle"), Ue = A, We = j, Ge = l(() => Re("control.teachingtip.close")), Ke = l(() => String(S(Ie["AutomationProperties.Name"]) ?? "")), qe = l(() => `win-theme-scope theme-${He.value}`), M = l(() => {
			let e = {
				heroContent: [],
				content: [],
				iconSource: [],
				actionButtonContent: [],
				closeButtonContent: []
			}, n = [], r = (i) => {
				for (let a of i) {
					if (a.type === xe && Array.isArray(a.children)) {
						r(a.children);
						continue;
					}
					let i = _e(a);
					if (!i) {
						n.push(a);
						continue;
					}
					let o = a.children?.default;
					o && e[i].push(...t(o(), f));
				}
			};
			return r(Le.default?.() ?? []), e.content.length || (e.content = t(n, f)), e;
		}), N = (e, t) => M.value[e].length > 0 || t != null && t !== "", Je = l(() => N("heroContent", w("HeroContent"))), Ye = l(() => N("content", w("Content"))), Xe = l(() => N("iconSource", w("IconSource"))), P = l(() => N("actionButtonContent", w("ActionButtonContent"))), F = l(() => N("closeButtonContent", w("CloseButtonContent"))), Ze = l(() => !F.value && !D.value), Qe = l(() => Je.value ? "Visible" : "Collapsed"), $e = l(() => Xe.value ? "Visible" : "Collapsed"), et = l(() => A.value ? "Visible" : "Collapsed"), tt = l(() => j.value ? "Visible" : "Collapsed"), nt = l(() => Ye.value ? "Visible" : "Collapsed"), rt = l(() => P.value ? "Visible" : "Collapsed"), it = l(() => F.value ? "Visible" : "Collapsed"), at = l(() => Ze.value ? "Visible" : "Collapsed"), ot = l(() => {
			let e = w("HeroContentPlacement");
			return e === "Top" || e === "Bottom" ? e : St.value && [
				"Bottom",
				"BottomLeft",
				"BottomRight",
				"LeftBottom",
				"RightBottom"
			].includes(x.value) ? "Bottom" : "Top";
		}), st = l(() => ot.value === "Top" ? 0 : 2), ct = l(() => ot.value === "Top" ? "var(--OverlayCornerRadius) var(--OverlayCornerRadius) 0 0" : "0 0 var(--OverlayCornerRadius) var(--OverlayCornerRadius)"), lt = l(() => S(Ze.value ? "{StaticResource TeachingTipTitleStackPanelMarginWithHeaderCloseButton}" : "{StaticResource TeachingTipTitleStackPanelMarginWithFooterCloseButton}")), ut = l(() => S(F.value ? "{ThemeResource TeachingTipLeftButtonMargin}" : "{ThemeResource TeachingTipButtonPanelMargin}")), dt = l(() => S(P.value ? "{ThemeResource TeachingTipRightButtonMargin}" : "{ThemeResource TeachingTipButtonPanelMargin}")), ft = l(() => F.value ? 1 : 2), pt = l(() => P.value ? 1 : 2), mt = l(() => +!!P.value), ht = l(() => w("ActionButtonStyle")), gt = l(() => w("CloseButtonStyle")), _t = l(() => D.value ? "{ThemeResource TeachingTipTransientBackground}" : w("Background")), vt = e(() => _t.value, f), yt = l(() => w("BorderBrush")), bt = l(() => w("BorderThickness")), xt = l(() => w("CornerRadius")), St = l(() => w("TailVisibility") !== "Collapsed" && (!!q() || w("TailVisibility") === "Visible")), I = l(() => St.value ? ye(x.value) : "none"), Ct = l(() => I.value === "left" || I.value === "right" ? "0 0 10 20" : "0 0 20 10"), wt = l(() => ({
			top: "0,10 10,0 20,10",
			bottom: "0,0 10,10 20,0",
			left: "10,0 0,10 10,20",
			right: "0,0 10,10 0,20",
			none: ""
		})[I.value]), Tt = l(() => ({
			display: g.value ? void 0 : "none",
			left: `${v.value.left}px`,
			top: `${v.value.top}px`,
			visibility: _.value ? "visible" : "hidden",
			"--teaching-tip-width": `${y.value.width}px`,
			"--teaching-tip-height": `${y.value.height}px`,
			"--teaching-tip-tail-x": `${v.value.tailX}px`,
			"--teaching-tip-tail-y": `${v.value.tailY}px`,
			"--teaching-tip-foreground": w("Foreground"),
			"--teaching-tip-border": w("BorderBrush"),
			"--teaching-tip-radius": typeof w("CornerRadius") == "number" ? `${w("CornerRadius")}px` : w("CornerRadius"),
			"--teaching-tip-border-width": `${Number(w("BorderThickness")) || 0}px`
		})), Et = l(() => ({
			left: `${b.value.left}px`,
			top: `${b.value.top}px`,
			width: `${b.value.width}px`,
			height: `${b.value.height}px`,
			visibility: _.value ? "visible" : "hidden"
		})), Dt = { onClick: (e) => {
			e.preventDefault(), e.stopPropagation();
		} }, L = (e, t) => Se({
			name: `TeachingTip${e}Presenter`,
			setup() {
				return () => {
					if (M.value[e].length) return we(xe, M.value[e]);
					let n = S(t());
					if (Ee(n)) return n;
					if (e === "iconSource" && n) {
						let e = n;
						return we(te, {
							Symbol: String(e.Symbol ?? n),
							Foreground: e.Foreground
						});
					}
					return typeof n == "string" || typeof n == "number" ? we("span", { class: "teaching-tip-presenter-text" }, String(n)) : null;
				};
			}
		}), Ot = L("heroContent", () => w("HeroContent")), kt = L("content", () => w("Content")), At = L("iconSource", () => w("IconSource")), jt = L("actionButtonContent", () => w("ActionButtonContent")), Mt = L("closeButtonContent", () => w("CloseButtonContent")), R = null, z = Promise.resolve(), B = null, V = null, H = null, U = null, W = !1, G = 0, K = null;
		function q() {
			let e = ie(k.value);
			if (e) return e;
			let t = String(c.Target ?? "").match(/^\{x:Bind\s+([\w]+)(?:,.*)?\}$/)?.[1];
			return t ? p.value?.closest(".example-display")?.querySelector(`[data-xaml-ref="${t}"]`) ?? null : null;
		}
		function J(e, t) {
			ge(e, Ht, t), n(Ie[e], f)?.(Ht, t);
		}
		function Y(e) {
			h.value = e, i(c.IsOpen, e, f), ge("update:IsOpen", e);
		}
		let Nt = l({
			get: () => O.value,
			set: Y
		});
		function X() {
			let e = (q() ?? p.value)?.closest(".theme-light, .theme-dark"), t = String(w("RequestedTheme") ?? "").toLowerCase();
			He.value = t === "light" || t === "dark" ? t : e?.classList.contains("theme-dark") ? "dark" : e?.classList.contains("theme-light") ? "light" : String(Ne(ze) || document.documentElement.dataset.theme || "light").toLowerCase() === "dark" ? "dark" : "light";
		}
		function Pt() {
			return [...m.value?.querySelectorAll("button:not(:disabled), input:not(:disabled), [tabindex=\"0\"]") ?? []].find((e) => e.getClientRects().length > 0 && getComputedStyle(e).visibility !== "hidden") ?? m.value;
		}
		async function Z() {
			await De();
			let e = m.value;
			if (!e || W || !g.value) return;
			let t = q(), n = re(t ?? p.value, E(w("ShouldConstrainToRootBounds")));
			b.value = n;
			let r = (t, n) => Number.parseFloat(getComputedStyle(e).getPropertyValue(`--${t}`)) || n;
			y.value = {
				width: Math.min(r("TeachingTipMaxWidth", 336), n.width),
				height: Math.min(r("TeachingTipMaxHeight", 520), n.height)
			}, await De();
			let i = {
				width: e.offsetWidth,
				height: e.offsetHeight
			}, a = ve(t?.getBoundingClientRect() ?? null, i, n, String(w("PreferredPlacement")), be(w("PlacementMargin")), String(w("HeroContentPlacement")), Je.value, getComputedStyle(t ?? p.value ?? document.documentElement).direction === "rtl");
			x.value = a.placement;
			let o = E(w("ShouldConstrainToRootBounds")) ? ne(a, i, n) : a, s = t?.getBoundingClientRect();
			v.value = {
				...o,
				tailX: s ? Math.max(28, Math.min(i.width - 28, s.left + s.width / 2 - o.left)) : i.width / 2,
				tailY: s ? Math.max(28, Math.min(i.height - 28, s.top + s.height / 2 - o.top)) : i.height / 2
			}, _.value = !0, X();
		}
		async function Ft(e) {
			let t = m.value;
			if (!t || (R?.cancel(), window.matchMedia("(prefers-reduced-motion: reduce)").matches || !t.animate)) return;
			let n = I.value;
			t.style.transformOrigin = n === "bottom" ? `${v.value.tailX}px 100%` : n === "top" ? `${v.value.tailX}px 0` : n === "left" ? `0 ${v.value.tailY}px` : n === "right" ? `100% ${v.value.tailY}px` : "50% 50%";
			let r = `scale(${20 / t.offsetWidth}, ${20 / t.offsetHeight})`, i = t.animate(e ? [{ transform: "scale(0.01)" }, { transform: "scale(1)" }] : [{ transform: "scale(1)" }, { transform: r }], {
				duration: e ? 300 : 200,
				easing: e ? "cubic-bezier(0.1, 0.9, 0.2, 1)" : "cubic-bezier(0.7, 0, 1, 0.5)",
				fill: "both"
			});
			R = i;
			try {
				await i.finished;
			} catch {
				return;
			}
			R === i && (i.cancel(), R = null);
		}
		async function It() {
			let e = ++G, t = window.scrollX, n = window.scrollY;
			B && await B, !(W || !O.value || g.value) && (g.value = !0, _.value = !1, z = (async () => {
				await Z(), !(W || e !== G) && (m.value && H?.observe(m.value), D.value && (U = document.activeElement instanceof HTMLElement ? document.activeElement : null, Pt()?.focus({ preventScroll: !0 }), window.scrollTo({
					left: t,
					top: n,
					behavior: "instant"
				})), await Ft(!0));
			})(), await z, g.value && O.value && !W && J("Opened", {}));
		}
		async function Q(e = "Programmatic") {
			if (!g.value || B) return B;
			Y(!1), B = (async () => {
				let t = 0, n = !1, r, i = new Promise((e) => {
					r = e;
				}), a = {
					Reason: e,
					Cancel: !1,
					GetDeferral() {
						t += 1;
						let e = !1;
						return { Complete() {
							e || (e = !0, --t, n && t === 0 && r());
						} };
					}
				};
				if (J("Closing", a), n = !0, t === 0 && r(), await i, !W) {
					if (a.Cancel) {
						Y(!0);
						return;
					}
					await z, !W && (await Ft(!1), !W && (g.value = !1, _.value = !1, J("Closed", { Reason: e }), (e === "CloseButton" || D.value) && U?.focus({ preventScroll: !0 }), U = null));
				}
			})();
			try {
				await B;
			} finally {
				B = null;
			}
			O.value && !W && It();
		}
		function Lt(e, t) {
			let n = S(e), r = S(t);
			typeof n == "function" ? n(r) : n && (!n.CanExecute || n.CanExecute(r)) && n.Execute?.(r);
		}
		function Rt() {
			Lt(w("ActionButtonCommand"), w("ActionButtonCommandParameter")), J("ActionButtonClick", null);
		}
		function zt() {
			Lt(w("CloseButtonCommand"), w("CloseButtonCommandParameter")), J("CloseButtonClick", null), Q("CloseButton");
		}
		let Bt = Object.fromEntries(Object.keys(c).filter((e) => ![
			"IsOpen",
			"Target",
			"Title",
			"Subtitle"
		].includes(e)).map((e) => [e, T(e)])), Vt = {
			...Bt,
			IsOpen: Nt,
			Target: k,
			Title: A,
			Subtitle: j,
			Element: m,
			TemplateSettings: l(() => ({ IconElement: w("IconSource") }))
		}, Ht = je(Vt);
		Ae(a, {
			TeachingTipTitleValue: Ue,
			TeachingTipSubtitleValue: We,
			HeroVisibility: Qe,
			IconVisibility: $e,
			TitleVisibility: et,
			SubtitleVisibility: tt,
			ContentVisibility: nt,
			ActionVisibility: rt,
			CloseVisibility: it,
			AlternateCloseVisibility: at,
			TipBackground: _t,
			TipBorderBrush: yt,
			TipBorderThickness: bt,
			TipCornerRadius: xt,
			ContentShadow: Ve,
			HeroCornerRadius: ct,
			HeroRow: st,
			TitlesMargin: lt,
			ActionMargin: ut,
			CloseMargin: dt,
			ActionSpan: ft,
			CloseSpan: pt,
			CloseColumn: mt,
			ActionStyle: ht,
			CloseStyle: gt,
			AlternateCloseButtonLabel: Ge,
			OnActionButtonClick: Rt,
			OnCloseButtonClick: zt
		}), me(Vt), d(O, (e) => {
			e ? It() : Q();
		}, { flush: "post" }), d(() => [
			k.value,
			w("PreferredPlacement"),
			w("PlacementMargin"),
			w("HeroContentPlacement"),
			w("TailVisibility"),
			A.value,
			j.value,
			M.value,
			P.value,
			F.value
		], () => {
			g.value && Z();
		}), d(() => w("RequestedTheme"), X);
		function $() {
			g.value && Z();
		}
		function Ut(e) {
			!g.value || !D.value || !(e.target instanceof Node) || m.value?.contains(e.target) || Q("LightDismiss");
		}
		function Wt() {
			Q("LightDismiss");
		}
		function Gt(e) {
			g.value && (e.key === "Escape" && D.value && (e.preventDefault(), Q("LightDismiss")), e.key === "F6" && (e.preventDefault(), m.value?.contains(document.activeElement) ? U?.focus({ preventScroll: !0 }) : (U = document.activeElement instanceof HTMLElement ? document.activeElement : null, Pt()?.focus({ preventScroll: !0 }))));
		}
		ke(() => {
			K = p.value?.closest("[data-xaml-root]") ?? null, X(), V = new MutationObserver(X), V.observe(document.documentElement, {
				attributes: !0,
				attributeFilter: ["class", "data-theme"]
			});
			let e = p.value?.closest(".theme-light, .theme-dark") ?? K;
			e && V.observe(e, {
				attributes: !0,
				attributeFilter: ["class", "data-theme"]
			}), H = new ResizeObserver($), K && H.observe(K), q() && H.observe(q()), window.addEventListener("resize", $), window.addEventListener("scroll", $, !0), document.addEventListener("pointerdown", Ut, !0), document.addEventListener("keydown", Gt, !0), O.value && It();
		}), Oe(() => {
			W = !0, Be.Dispose(), R?.cancel(), V?.disconnect(), H?.disconnect(), window.removeEventListener("resize", $), window.removeEventListener("scroll", $, !0), document.removeEventListener("pointerdown", Ut, !0), document.removeEventListener("keydown", Gt, !0);
		});
		let Kt = {
			props: c,
			emit: ge,
			instance: f,
			attrs: Ie,
			slots: Le,
			t: Re,
			inheritedTheme: ze,
			hostRef: p,
			tipRef: m,
			localIsOpen: h,
			isVisible: g,
			contentShadow: Be,
			ContentShadow: Ve,
			positioned: _,
			theme: He,
			position: v,
			sizeLimit: y,
			rootBounds: b,
			actualPlacement: x,
			resolve: S,
			propertyOverrides: C,
			propertyValue: w,
			dependencyProperty: T,
			boolean: E,
			IsLightDismissEnabled: D,
			requestedOpen: O,
			Target: k,
			Title: A,
			Subtitle: j,
			TeachingTipTitleValue: Ue,
			TeachingTipSubtitleValue: We,
			AlternateCloseButtonLabel: Ge,
			automationName: Ke,
			themeClass: qe,
			propertyNodes: M,
			hasValue: N,
			hasHeroContent: Je,
			hasContent: Ye,
			hasIconSource: Xe,
			hasActionButton: P,
			hasCloseButton: F,
			ShowAlternateCloseButton: Ze,
			HeroVisibility: Qe,
			IconVisibility: $e,
			TitleVisibility: et,
			SubtitleVisibility: tt,
			ContentVisibility: nt,
			ActionVisibility: rt,
			CloseVisibility: it,
			AlternateCloseVisibility: at,
			effectiveHeroPlacement: ot,
			HeroRow: st,
			HeroCornerRadius: ct,
			TitlesMargin: lt,
			ActionMargin: ut,
			CloseMargin: dt,
			ActionSpan: ft,
			CloseSpan: pt,
			CloseColumn: mt,
			ActionStyle: ht,
			CloseStyle: gt,
			TipBackground: _t,
			tailMaterialStyle: vt,
			TipBorderBrush: yt,
			TipBorderThickness: bt,
			TipCornerRadius: xt,
			hasVisibleTail: St,
			tailSide: I,
			tailViewBox: Ct,
			tailPoints: wt,
			containerStyle: Tt,
			lightDismissStyle: Et,
			lightDismissEvents: Dt,
			outlet: L,
			HeroContentOutlet: Ot,
			ContentOutlet: kt,
			IconSourceOutlet: At,
			ActionContentOutlet: jt,
			CloseContentOutlet: Mt,
			get animation() {
				return R;
			},
			set animation(e) {
				R = e;
			},
			get animationTask() {
				return z;
			},
			set animationTask(e) {
				z = e;
			},
			get closingTask() {
				return B;
			},
			set closingTask(e) {
				B = e;
			},
			get themeObserver() {
				return V;
			},
			set themeObserver(e) {
				V = e;
			},
			get resizeObserver() {
				return H;
			},
			set resizeObserver(e) {
				H = e;
			},
			get previouslyFocused() {
				return U;
			},
			set previouslyFocused(e) {
				U = e;
			},
			get unmounted() {
				return W;
			},
			set unmounted(e) {
				W = e;
			},
			get openGeneration() {
				return G;
			},
			set openGeneration(e) {
				G = e;
			},
			get boundsHost() {
				return K;
			},
			set boundsHost(e) {
				K = e;
			},
			targetElement: q,
			dispatch: J,
			setOpen: Y,
			IsOpen: Nt,
			syncTheme: X,
			firstFocusable: Pt,
			updatePosition: Z,
			animate: Ft,
			openTip: It,
			requestClose: Q,
			executeCommand: Lt,
			OnActionButtonClick: Rt,
			OnCloseButtonClick: zt,
			exposedProperties: Bt,
			api: Vt,
			publicApi: Ht,
			viewportChanged: $,
			pointerDown: Ut,
			OnLightDismissPointerDown: Wt,
			keyDown: Gt,
			Border: ce,
			Button: le,
			ColumnDefinition: ue,
			Grid: ee,
			RowDefinition: de,
			ScrollViewer: se,
			StackPanel: fe,
			TextBlock: oe,
			get vAcrylicBrush() {
				return o;
			}
		};
		return Object.defineProperty(Kt, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), Kt;
	}
});
//#endregion
export { f as default };

//# sourceMappingURL=TeachingTip.vue_vue_type_script_setup_true_lang.js.map