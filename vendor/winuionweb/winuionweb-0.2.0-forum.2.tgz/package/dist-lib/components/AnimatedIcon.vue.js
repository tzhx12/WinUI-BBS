import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./AnimatedIcon.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                                 */
import { createBlock as n, createElementBlock as r, createElementVNode as i, createVNode as a, mergeProps as o, normalizeClass as s, normalizeStyle as c, openBlock as l } from "vue";
//#region src/components/AnimatedIcon.vue
var u = [
	"data-animated-icon-state",
	"data-animated-icon-progress",
	"data-animated-icon-playing",
	"data-animated-icon-source"
], d = ["viewBox", "innerHTML"];
function f(e, t, f, p, m, h) {
	return l(), r("span", o({ ref: "rootElement" }, p.elementAttrs, {
		class: "win-animated-icon",
		style: p.iconStyle,
		"data-animated-icon-state": p.currentState,
		"data-animated-icon-progress": p.progress,
		"data-animated-icon-playing": p.isPlaying,
		"data-animated-icon-source": p.visualSource?.name,
		"aria-hidden": "true"
	}), [a(p.DeclarationOutlet), i("span", { class: s(["win-animated-icon-grid", { "has-animated-visual": p.visualSource }]) }, [t[0] ||= i("svg", { class: "win-animated-icon-collapsed-path" }, [i("path")], -1), p.visualSource ? (l(), r("svg", {
		key: 0,
		class: "win-animated-icon-visual",
		viewBox: p.viewBox,
		preserveAspectRatio: "xMidYMid meet",
		style: c(p.visualStyle),
		innerHTML: p.visualMarkup
	}, null, 12, d)) : (l(), n(p.FallbackOutlet, { key: 1 }))], 2)], 16, u);
}
var p = /*#__PURE__*/ e(t, [
	["render", f],
	["__scopeId", "data-v-25255edd"],
	["__file", "AnimatedIcon.vue"]
]);
//#endregion
export { p as default };

//# sourceMappingURL=AnimatedIcon.vue.js.map