import { alignment as e, xamlThickness as t } from "./layout.js";
import { resolveXamlValue as n, updateXamlBinding as r } from "./xamlRuntime.js";
import { frameworkLayoutStyle as i } from "./frameworkLayout.js";
import { getPivotProperty as a, pivotItemContextKey as o, pivotItemIdentityKey as s, pivotItemProperties as c, pivotNodes as l, pivotPropertyChildren as u, pivotRootAttributes as d, renderPivotPresenter as f } from "./PivotProperties.js";
import { computed as p, defineComponent as m, getCurrentInstance as h, inject as g, ref as _, shallowReactive as v, useAttrs as y, useSlots as b, watch as x } from "vue";
var S = /*@__PURE__*/ m({
	...c,
	name: "PivotItem",
	inheritAttrs: !1,
	__name: "PivotItem",
	props: {
		Header: {
			type: null,
			default: null
		},
		Content: {
			type: null,
			default: null
		},
		ContentTemplate: {
			type: null,
			default: null
		},
		Background: {
			type: null,
			default: "{ThemeResource PivotItemBackground}"
		},
		Foreground: {
			type: null,
			default: ""
		},
		Margin: {
			type: null,
			default: "{ThemeResource PivotItemMargin}"
		},
		Padding: {
			type: null,
			default: 0
		},
		HorizontalContentAlignment: {
			type: null,
			default: "Stretch"
		},
		VerticalContentAlignment: {
			type: null,
			default: "Stretch"
		},
		IsEnabled: {
			type: null,
			default: !0
		},
		IsTabStop: {
			type: null,
			default: !1
		},
		Visibility: {
			type: null,
			default: "Visible"
		},
		Width: {
			type: null,
			default: ""
		},
		Height: {
			type: null,
			default: ""
		},
		MinWidth: {
			type: null,
			default: ""
		},
		MinHeight: {
			type: null,
			default: ""
		},
		MaxWidth: {
			type: null,
			default: ""
		},
		MaxHeight: {
			type: null,
			default: ""
		},
		HorizontalAlignment: {
			type: null,
			default: "Stretch"
		},
		VerticalAlignment: {
			type: null,
			default: "Stretch"
		},
		Opacity: {
			type: null,
			default: 1
		},
		IsHitTestVisible: {
			type: null,
			default: !0
		},
		AccessKey: {
			type: null,
			default: ""
		}
	},
	setup(c, { expose: S }) {
		let C = c, w = h(), T = y(), E = b(), D = _(null), O = g(o, null), k = (e) => n(e, w), A = v({}), j = (e) => {
			let t = e in A ? A[e] : C[e];
			return e === "ContentTemplate" && typeof t == "string" && /^\{(?:StaticResource|ThemeResource)\s/.test(t) ? t : k(t);
		}, M = () => w?.vnode.key, N = p(() => !O || O.isVisible(M())), P = p(() => j("IsEnabled") !== !1 && (!O || O.isEnabled())), F = p(() => l(E.default?.() ?? [])), I = p(() => {
			let e = u(F.value, "PivotItem", "content");
			return e.length ? e : F.value.filter((e) => !a(e, "PivotItem"));
		}), L = m({ setup: () => () => O && !O.isLoaded(M()) ? null : f(j("Content"), "Content" in A ? [] : I.value, j("ContentTemplate"), u(F.value, "PivotItem", "contentTemplate"), w) }), R = p(() => d(T, w)), z = p(() => ({
			...i({
				...Object.fromEntries(Object.keys(C).map((e) => [e, j(e)])),
				Padding: ""
			}, w),
			margin: t(j("Margin")),
			color: j("Foreground") ? String(j("Foreground")) : void 0,
			display: N.value && j("Visibility") !== "Collapsed" ? "grid" : "none"
		})), B = p(() => ({
			margin: t(j("Padding")),
			justifyItems: e(j("HorizontalContentAlignment"), "horizontal"),
			alignItems: e(j("VerticalContentAlignment"), "vertical")
		})), V = {
			[s]: `pivot-item-${w?.uid}`,
			get ActualWidth() {
				return D.value?.clientWidth ?? 0;
			},
			get ActualHeight() {
				return D.value?.clientHeight ?? 0;
			},
			Focus() {
				return D.value?.focus(), !!D.value;
			},
			InvokeAccessKey() {
				O?.select(M());
			}
		};
		for (let e of Object.keys(C)) Object.defineProperty(V, e, {
			enumerable: !0,
			configurable: !0,
			get: () => e === "IsEnabled" ? P.value : j(e),
			set: (t) => {
				A[e] = t, r(C[e], t, w), O?.setProperty(M(), e, t);
			}
		}), x(() => k(C[e]), () => {
			delete A[e], O?.setProperty(M(), e, void 0);
		});
		S(V);
		let H = {
			props: C,
			instance: w,
			attrs: T,
			slots: E,
			rootRef: D,
			owner: O,
			value: k,
			overrides: A,
			property: j,
			itemKey: M,
			visible: N,
			enabled: P,
			nodes: F,
			contentNodes: I,
			ContentOutlet: L,
			rootAttrs: R,
			rootStyle: z,
			presenterStyle: B,
			publicApi: V
		};
		return Object.defineProperty(H, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), H;
	}
});
//#endregion
export { S as default };

//# sourceMappingURL=PivotItem.vue_vue_type_script_setup_true_lang.js.map