import { boolValue as e } from "./layout.js";
import { resolveXamlHandler as t, resolveXamlValue as n, updateXamlBinding as r, xamlScopeKey as i } from "./xamlRuntime.js";
import { useUICommand as a } from "./uiCommandRuntime.js";
import { buttonContentProperty as o, useButtonContent as s } from "./buttonContentRuntime.js";
import c from "./SplitButton.vue.js";
import { computed as l, defineComponent as u, getCurrentInstance as d, inject as f, provide as p, proxyRefs as m, ref as h, useAttrs as g, useSlots as _, watch as v } from "vue";
//#region src/components/ToggleSplitButton.vue?vue&type=script&setup=true&lang.ts
var y = u({
	name: "ToggleSplitButton.Flyout",
	__splitButtonProperty: "flyout",
	setup() {
		return () => null;
	}
}), b = u({
	name: "ToggleSplitButton.Content",
	__splitButtonProperty: "content",
	setup() {
		return () => null;
	}
}), x = /*@__PURE__*/ u({
	Flyout: y,
	Content: b,
	ContentTemplate: o("ToggleSplitButton", "ContentTemplate"),
	ContentTransitions: o("ToggleSplitButton", "ContentTransitions"),
	Resources: o("ToggleSplitButton", "Resources"),
	name: "ToggleSplitButton",
	inheritAttrs: !1,
	__name: "ToggleSplitButton",
	props: {
		Content: {
			type: null,
			default: ""
		},
		ContentTemplate: {
			type: null,
			default: void 0
		},
		ContentTransitions: {
			type: null,
			default: void 0
		},
		Flyout: {
			type: null,
			default: void 0
		},
		IsChecked: {
			type: [Boolean, String],
			default: !1
		},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		RequestedTheme: {
			type: String,
			default: "Default"
		}
	},
	emits: ["Click", "IsCheckedChanged"],
	setup(o, { expose: u, emit: x }) {
		let S = o, C = x, w = g(), T = _(), E = d(), D = h(null), O = (e) => n(e, E), { ContentTemplate: k, ContentTransitions: A } = s(S, () => T.default?.() ?? [], E), j = a(() => O(w.Command)), M = l(() => O(w.CommandParameter)), N = l(() => O(S.Content)), P = l(() => String(O(S.RequestedTheme))), F = h();
		v(P, () => {
			F.value = void 0;
		});
		let I = l({
			get: () => F.value ?? P.value,
			set: (e) => {
				F.value = e, r(S.RequestedTheme, e, E);
			}
		}), L = l(() => O(S.Flyout)), R = l(() => e(O(S.IsChecked))), z = h(), B = l({
			get: () => z.value ?? R.value,
			set: (t) => J(e(t))
		}), V = l(() => e(O(S.IsEnabled))), H = h(), U = l({
			get: () => (H.value ?? V.value) && (j.value?.CanExecute?.(M.value) ?? !0),
			set: (t) => {
				H.value = e(t), r(S.IsEnabled, H.value, E);
			}
		}), W = l(() => Object.fromEntries(Object.entries(w).filter(([e]) => ![
			"Click",
			"onClick",
			"IsCheckedChanged",
			"onIsCheckedChanged"
		].includes(e)))), G = l(() => !!T.default), K = m({
			IsChecked: B,
			IsEnabled: U,
			RequestedTheme: I,
			ContentTemplate: k,
			ContentTransitions: A,
			Name: l(() => w["data-xaml-ref"] ?? w["x:Name"] ?? w.Name ?? ""),
			Content: l({
				get: () => D.value?.Content ?? N.value,
				set: (e) => {
					D.value && (D.value.Content = e), r(S.Content, e, E);
				}
			}),
			Flyout: l({
				get: () => D.value?.Flyout,
				set: (e) => {
					D.value && (D.value.Flyout = e), r(S.Flyout, e, E);
				}
			}),
			Element: l(() => D.value?.Element),
			Focus: () => D.value?.Focus?.()
		});
		u(K);
		function q(e) {
			let n = {
				OriginalSource: K,
				OriginalEvent: e
			};
			C("IsCheckedChanged", K, n), t(w.IsCheckedChanged, E)?.(K, n);
		}
		function J(e, t) {
			e !== B.value && (z.value = e, r(S.IsChecked, e, E), q(t));
		}
		function Y(e, n) {
			let r = {
				OriginalSource: K,
				OriginalEvent: n?.OriginalEvent
			};
			C("Click", K, r), t(w.Click, E)?.(K, r);
		}
		v(R, (e, t) => {
			let n = z.value !== void 0 && z.value === e;
			z.value = void 0, !n && e !== t && q();
		}), v(V, () => {
			H.value = void 0;
		}), p("toggleSplitButtonState", {
			IsChecked: B,
			Invoke: (e) => J(!B.value, e)
		}), p(i, {
			...f(i, {}),
			IsEnabled: U,
			Content: N,
			ContentTemplate: k,
			ContentTransitions: A,
			Flyout: L,
			RequestedTheme: I,
			OnSplitClick: Y
		});
		let X = {
			ToggleSplitButtonFlyout: y,
			ToggleSplitButtonContent: b,
			props: S,
			emit: C,
			attrs: w,
			slots: T,
			instance: E,
			split: D,
			resolve: O,
			ContentTemplate: k,
			ContentTransitions: A,
			Command: j,
			CommandParameter: M,
			Content: N,
			sourceRequestedTheme: P,
			localRequestedTheme: F,
			RequestedTheme: I,
			Flyout: L,
			sourceChecked: R,
			localChecked: z,
			IsChecked: B,
			sourceEnabled: V,
			localEnabled: H,
			IsEnabled: U,
			splitAttrs: W,
			hasContent: G,
			api: K,
			raiseChanged: q,
			setChecked: J,
			onSplitClick: Y,
			SplitButton: c
		};
		return Object.defineProperty(X, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), X;
	}
});
//#endregion
export { b as ToggleSplitButtonContent, y as ToggleSplitButtonFlyout, x as default };

//# sourceMappingURL=ToggleSplitButton.vue_vue_type_script_setup_true_lang.js.map