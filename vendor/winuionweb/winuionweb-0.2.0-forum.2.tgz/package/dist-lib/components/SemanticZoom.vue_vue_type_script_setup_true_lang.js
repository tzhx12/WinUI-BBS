import { normalizeXamlNodes as e, resolveXamlHandler as t, resolveXamlValue as n, updateXamlBinding as r, xamlScopeKey as i } from "./xamlRuntime.js";
import { useI18n as a } from "./i18n/index.js";
import ee from "./ScrollViewer.vue.js";
import o from "./Button.vue.js";
import { Fragment as s, computed as c, defineComponent as l, getCurrentInstance as u, h as d, nextTick as te, onBeforeUnmount as f, onMounted as ne, provide as re, proxyRefs as ie, ref as p, useAttrs as ae, useSlots as oe, watch as se } from "vue";
//#region src/components/SemanticZoom.vue?vue&type=script&setup=true&lang.ts
var m = (e) => l({
	name: `SemanticZoom.${e}`,
	__semanticZoomProperty: e,
	setup() {
		return () => null;
	}
}), h = m("ZoomedInView"), ce = m("ZoomedOutView"), le = /*@__PURE__*/ l({
	ZoomedInView: h,
	ZoomedOutView: ce,
	inheritAttrs: !1,
	__name: "SemanticZoom",
	props: {
		ZoomedInView: {
			type: Object,
			default: null
		},
		ZoomedOutView: {
			type: Object,
			default: null
		},
		IsZoomedInViewActive: {
			type: [Boolean, String],
			default: !0
		},
		CanChangeViews: {
			type: [Boolean, String],
			default: !0
		},
		IsZoomOutButtonEnabled: {
			type: [Boolean, String],
			default: !1
		},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		IsTabStop: {
			type: [Boolean, String],
			default: !1
		},
		TabNavigation: {
			type: String,
			default: "Once"
		},
		Width: {
			type: [Number, String],
			default: ""
		},
		Height: {
			type: [Number, String],
			default: ""
		},
		MinWidth: {
			type: [Number, String],
			default: ""
		},
		MaxWidth: {
			type: [Number, String],
			default: ""
		},
		MinHeight: {
			type: [Number, String],
			default: ""
		},
		MaxHeight: {
			type: [Number, String],
			default: ""
		},
		Margin: {
			type: [Number, String],
			default: 0
		},
		Padding: {
			type: [Number, String],
			default: 0
		},
		Background: {
			type: String,
			default: "Transparent"
		},
		BorderBrush: {
			type: String,
			default: "Transparent"
		},
		BorderThickness: {
			type: [Number, String],
			default: 0
		},
		"ScrollViewer.HorizontalScrollMode": {
			type: String,
			default: "Disabled"
		},
		"ScrollViewer.VerticalScrollMode": {
			type: String,
			default: "Disabled"
		},
		"ScrollViewer.IsHorizontalRailEnabled": {
			type: [Boolean, String],
			default: !1
		},
		"ScrollViewer.IsVerticalRailEnabled": {
			type: [Boolean, String],
			default: !1
		},
		"ScrollViewer.ZoomMode": {
			type: String,
			default: "Disabled"
		}
	},
	emits: [
		"update:IsZoomedInViewActive",
		"ViewChangeStarted",
		"ViewChangeCompleted"
	],
	setup(le, { expose: ue, emit: de }) {
		let g = le, _ = de, v = u(), y = ae(), fe = oe(), pe = c(() => Object.fromEntries(Object.entries(y).filter(([e]) => !["ViewChangeStarted", "ViewChangeCompleted"].includes(e)))), { t: me } = a(), b = (e) => n(g[e], v), x = c(() => b("IsEnabled") !== !1), S = c(() => b("CanChangeViews") !== !1), he = c(() => b("IsTabStop") === !0), C = c(() => b("IsZoomOutButtonEnabled") === !0), w = c(() => b("ScrollViewer.ZoomMode")), T = p(), E = p(), D = p(), O = p(b("IsZoomedInViewActive") !== !1), k = p(!1), A = p(!1), j = p(null), M = p(null), N = p("50% 50%"), P = (e) => e === "" || e == null ? void 0 : Number.isFinite(Number(e)) ? `${Number(e)}px` : String(e), F = (e) => {
			let t = String(e ?? 0).split(",").map(P);
			return t.length === 4 ? `${t[1]} ${t[2]} ${t[3]} ${t[0]}` : t.length === 2 ? `${t[1]} ${t[0]}` : t[0];
		}, ge = c(() => ({
			width: P(b("Width")),
			height: P(b("Height")),
			minWidth: P(b("MinWidth")),
			maxWidth: P(b("MaxWidth")),
			minHeight: P(b("MinHeight")),
			maxHeight: P(b("MaxHeight")),
			margin: F(b("Margin")),
			touchAction: w.value === "Enabled" ? "none" : "pan-x pan-y"
		})), _e = c(() => ({
			background: String(b("Background")),
			borderColor: String(b("BorderBrush")),
			borderWidth: F(b("BorderThickness")),
			padding: F(b("Padding"))
		})), I = c(() => j.value ?? M.value ?? (O.value ? 1 : .5)), ve = c(() => ({
			transform: `scale(${I.value})`,
			transformOrigin: N.value
		})), ye = c(() => ({
			transform: `scale(${I.value * 2})`,
			transformOrigin: N.value
		})), be = c(() => {
			let t = {
				ZoomedInView: [],
				ZoomedOutView: []
			}, n = (r) => {
				for (let i of r) {
					if (i.type === s && Array.isArray(i.children)) {
						n(i.children);
						continue;
					}
					let r = i.type?.__semanticZoomProperty;
					if (!r) continue;
					let a = i.children;
					t[r] = e(a?.default?.() ?? [], v);
				}
			};
			return n(fe.default?.() ?? []), t;
		}), L = (e) => l({
			name: `SemanticZoom${e}Presenter`,
			setup() {
				return () => d(s, be.value[e].length ? be.value[e] : g[e] ? [d(g[e])] : []);
			}
		}), xe = L("ZoomedInView"), Se = L("ZoomedOutView"), Ce = l({
			name: "ControlTemplate",
			setup() {
				return () => null;
			}
		}), we = l({
			name: "ScrollContentPresenter",
			setup() {
				return () => null;
			}
		}), R = (e) => {
			let t = (e ? E : D).value;
			for (let e of Array.from(t?.querySelectorAll("*") ?? [])) {
				let t = e.__vueParentComponent?.exposed;
				if (t && (t.StartViewChangeFrom || t.StartViewChangeTo)) return ie(t);
			}
		}, z = !1, B = {
			get IsZoomedInViewActive() {
				return O.value;
			},
			ToggleActiveView: (e) => Y(!O.value, e),
			HasFocus: () => !!T.value?.contains(document.activeElement) || z && document.activeElement === document.body,
			StartBringIntoView: () => T.value?.scrollIntoView({
				block: "nearest",
				inline: "nearest"
			})
		}, V = 0, H = [], U, W, G = !1, K, Te = () => window.matchMedia?.("(prefers-reduced-motion: reduce)").matches ? 0 : 167, q = () => {
			for (let e of H) e.cancel();
			H = [];
		}, Ee = (e, t = null) => {
			let n = T.value?.getBoundingClientRect(), r = e?.getBoundingClientRect();
			return {
				Item: t,
				Bounds: {
					X: r && n ? r.left - n.left : 0,
					Y: r && n ? r.top - n.top : 0,
					Width: r?.width ?? 0,
					Height: r?.height ?? 0
				}
			};
		}, J = () => {
			clearTimeout(K), K = void 0, A.value = !1;
		}, De = () => {
			for (let e of [!0, !1]) {
				let t = R(e);
				t && (t.SemanticZoomOwner = B, t.IsZoomedInView = e, t.IsActiveView = e === O.value);
			}
		}, Y = (e, n) => {
			if (!S.value || !x.value) return !1;
			if (k.value) return U = {
				target: e,
				request: n
			}, !0;
			if (e === O.value) return !1;
			J();
			let i = O.value, a = I.value, ee = e ? 1 : .5;
			M.value = a, G = n?.Gesture === !0;
			let o = T.value?.getBoundingClientRect();
			N.value = n?.ZoomPoint && o ? `${n.ZoomPoint.X - o.left}px ${n.ZoomPoint.Y - o.top}px` : "50% 50%";
			let s = (i ? E : D).value, c = (e ? E : D).value, l = R(i), u = R(e), d = {
				IsSourceZoomedInView: i,
				SourceItem: Ee(n?.OriginalSource ?? s, n?.Item),
				DestinationItem: Ee(c)
			};
			d.SourceItem.ZoomPoint = n?.ZoomPoint, z = !!T.value?.contains(document.activeElement), l?.InitializeViewChange?.(), u?.InitializeViewChange?.(), l?.StartViewChangeFrom?.(d.SourceItem, d.DestinationItem), u?.StartViewChangeTo?.(d.SourceItem, d.DestinationItem), k.value = !0;
			let f = ++V;
			return _("ViewChangeStarted", B, d), t(y.ViewChangeStarted, v)?.(B, d), O.value = e, _("update:IsZoomedInViewActive", e), r(g.IsZoomedInViewActive, e, v), De(), u?.MakeVisible?.(d.DestinationItem), te().then(async () => {
				if (f !== V) return;
				u?.MakeVisible?.(d.DestinationItem), q();
				let e = Te();
				if (e && s?.animate && c?.animate) {
					H = [s.animate([{ opacity: 1 }, { opacity: 0 }], {
						duration: e,
						easing: "linear",
						fill: "both"
					}), c.animate([{ opacity: 0 }, { opacity: 1 }], {
						duration: e,
						easing: "linear",
						fill: "both"
					})];
					let t = (e) => {
						for (let [t, n] of [[E.value, 1], [D.value, 2]]) t && H.push(t.animate([{ transform: `scale(${e * n})` }, { transform: `scale(${ee * n})` }], {
							duration: 250,
							easing: "cubic-bezier(0.1,0.9,0.2,1)",
							fill: "both"
						}));
					};
					if (n?.Gesture) {
						if (await Promise.all(H.map((e) => e.finished.catch(() => void 0))), X.size >= 2 && await new Promise((e) => {
							W = e;
						}), f !== V) return;
						let e = I.value;
						M.value = e, j.value = null, t(e);
					} else t(a);
					await Promise.all(H.map((e) => e.finished.catch(() => void 0)));
				}
				if (f !== V) return;
				q(), j.value = null, M.value = null, G = !1, N.value = "50% 50%", k.value = !1, l?.CompleteViewChangeFrom?.(d.SourceItem, d.DestinationItem), u?.CompleteViewChangeTo?.(d.SourceItem, d.DestinationItem), l?.CompleteViewChange?.(), u?.CompleteViewChange?.(), z = !1, _("ViewChangeCompleted", B, d), t(y.ViewChangeCompleted, v)?.(B, d);
				let r = U;
				U = void 0, r && Y(r.target, r.request);
			}), !0;
		}, Oe = (e) => {
			Y(!O.value, e.detail) && e.stopPropagation();
		}, ke = (e) => {
			e.pointerType === "touch" || !C.value || !O.value || !x.value || k.value || (A.value = !0, clearTimeout(K), K = setTimeout(J, Te() + 3e3));
		}, X = /* @__PURE__ */ new Map(), Z = 0, Q = 1, Ae = () => {
			let e = [...X.values()];
			return e.length === 2 ? Math.hypot(e[0].x - e[1].x, e[0].y - e[1].y) : 0;
		}, $ = () => {
			let e = [...X.keys()];
			k.value && j.value !== null && (M.value = j.value), X.clear(), j.value = null, Z = 0, W?.(), W = void 0;
			for (let t of e) T.value?.hasPointerCapture?.(t) && T.value.releasePointerCapture(t);
		}, je = (e) => {
			if (!(!x.value || !S.value || w.value === "Disabled" || e.pointerType === "mouse") && (X.set(e.pointerId, {
				x: e.clientX,
				y: e.clientY
			}), X.size === 2)) {
				Z = Ae(), Q = O.value ? 1 : .5;
				for (let e of X.keys()) T.value?.setPointerCapture?.(e);
			}
		}, Me = (e) => {
			if (ke(e), !X.has(e.pointerId) || (X.set(e.pointerId, {
				x: e.clientX,
				y: e.clientY
			}), !Z || k.value && !G || X.size !== 2)) return;
			let t = Math.max(.5, Math.min(1, Q * Ae() / Z));
			j.value = t, e.preventDefault();
			let n = [...X.values()], r = {
				X: (n[0].x + n[1].x) / 2,
				Y: (n[0].y + n[1].y) / 2
			};
			k.value || (O.value && t < .9 ? Y(!1, {
				ZoomPoint: r,
				Gesture: !0
			}) : !O.value && t > .6 && Y(!0, {
				ZoomPoint: r,
				Gesture: !0
			}));
		}, Ne = (e) => {
			X.delete(e.pointerId), T.value?.hasPointerCapture?.(e.pointerId) && T.value.releasePointerCapture(e.pointerId), X.size < 2 && (Z = 0, W?.(), W = void 0, k.value || (j.value = null));
		}, Pe = (e) => {
			w.value === "Enabled" && (X.size > 1 || k.value) && (e.stopPropagation(), e.preventDefault());
		}, Fe = (e) => {
			e.ctrlKey && w.value !== "Disabled" && e.deltaY && Y(e.deltaY < 0, { ZoomPoint: {
				X: e.clientX,
				Y: e.clientY
			} }) && (e.preventDefault(), e.stopPropagation());
		}, Ie = (e) => {
			if (!e.ctrlKey || e.altKey || e.metaKey) return;
			let t = ["-", "_"].includes(e.key) || e.code === "NumpadSubtract", n = ["+", "="].includes(e.key) || e.code === "NumpadAdd";
			(n || t) && Y(n) && (e.preventDefault(), e.stopPropagation());
		};
		re(i, {
			ZoomOutButton_Click: () => Y(!1),
			get templateIsEnabled() {
				return x.value;
			},
			get zoomOutLabel() {
				return me("text.zoom-out");
			},
			get templateHorizontalScrollMode() {
				return b("ScrollViewer.HorizontalScrollMode");
			},
			get templateVerticalScrollMode() {
				return b("ScrollViewer.VerticalScrollMode");
			},
			get templateHorizontalRailEnabled() {
				return b("ScrollViewer.IsHorizontalRailEnabled");
			},
			get templateVerticalRailEnabled() {
				return b("ScrollViewer.IsVerticalRailEnabled");
			},
			get templateZoomMode() {
				return w.value;
			}
		}), se(() => b("IsZoomedInViewActive"), (e) => {
			typeof e == "boolean" && Y(e);
		}), se([
			x,
			S,
			C
		], () => {
			(!x.value || !S.value) && ($(), U = void 0), (!C.value || !x.value) && J();
		}), ne(() => {
			De(), window.addEventListener("blur", $);
		}), f(() => {
			V++, q(), J(), $(), window.removeEventListener("blur", $);
		}), ue({
			ToggleActiveView: B.ToggleActiveView,
			StartBringIntoView: B.StartBringIntoView,
			IsZoomedInViewActive: c({
				get: () => O.value,
				set: (e) => {
					Y(e);
				}
			}),
			ZoomedInView: c(() => R(!0)),
			ZoomedOutView: c(() => R(!1))
		});
		let Le = {
			viewProperty: m,
			SemanticZoomZoomedInView: h,
			SemanticZoomZoomedOutView: ce,
			props: g,
			emit: _,
			instance: v,
			attrs: y,
			slots: fe,
			forwardedAttrs: pe,
			t: me,
			value: b,
			isEnabled: x,
			canChangeViews: S,
			isTabStop: he,
			zoomButtonEnabled: C,
			zoomMode: w,
			rootRef: T,
			zoomedInPresenterRef: E,
			zoomedOutPresenterRef: D,
			isZoomedIn: O,
			isChangingView: k,
			isZoomOutButtonVisible: A,
			gestureFactor: j,
			transitionFactor: M,
			zoomOrigin: N,
			length: P,
			thickness: F,
			rootStyle: ge,
			surfaceStyle: _e,
			zoomFactor: I,
			zoomedInPresenterStyle: ve,
			zoomedOutPresenterStyle: ye,
			nodes: be,
			outlet: L,
			ZoomedInOutlet: xe,
			ZoomedOutOutlet: Se,
			ControlTemplate: Ce,
			ScrollContentPresenter: we,
			view: R,
			get takeFocusAtCompletion() {
				return z;
			},
			set takeFocusAtCompletion(e) {
				z = e;
			},
			sender: B,
			get sequence() {
				return V;
			},
			set sequence(e) {
				V = e;
			},
			get animations() {
				return H;
			},
			set animations(e) {
				H = e;
			},
			get queued() {
				return U;
			},
			set queued(e) {
				U = e;
			},
			get releaseGesture() {
				return W;
			},
			set releaseGesture(e) {
				W = e;
			},
			get gestureTransitionActive() {
				return G;
			},
			set gestureTransitionActive(e) {
				G = e;
			},
			get buttonTimer() {
				return K;
			},
			set buttonTimer(e) {
				K = e;
			},
			duration: Te,
			cancelAnimations: q,
			location: Ee,
			hideButton: J,
			syncViews: De,
			changeView: Y,
			onSemanticZoomRequest: Oe,
			showButton: ke,
			pointers: X,
			get pinchDistance() {
				return Z;
			},
			set pinchDistance(e) {
				Z = e;
			},
			get pinchStart() {
				return Q;
			},
			set pinchStart(e) {
				Q = e;
			},
			distance: Ae,
			resetGesture: $,
			onPointerDown: je,
			onPointerMove: Me,
			onPointerEnd: Ne,
			onLegacyTouch: Pe,
			onWheel: Fe,
			onKeyDown: Ie,
			Button: o,
			ScrollViewer: ee
		};
		return Object.defineProperty(Le, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), Le;
	}
});
//#endregion
export { h as SemanticZoomZoomedInView, ce as SemanticZoomZoomedOutView, le as default };

//# sourceMappingURL=SemanticZoom.vue_vue_type_script_setup_true_lang.js.map