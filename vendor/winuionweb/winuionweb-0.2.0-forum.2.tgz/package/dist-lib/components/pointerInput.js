//#region src/components/pointerInput.ts
var e = (e) => e.pointerType !== "touch", t = !1, n = 500, r = 12, i = null, a = null, o = () => {
	i && window.clearTimeout(i.timer), i = null;
}, s = (e, t) => e === t || e.contains(t) || t.contains(e), c = (e) => {
	if (e.pointerType !== "touch" || !e.isPrimary || e.button !== 0 || !(e.target instanceof Node)) return;
	o();
	let t = {
		pointerId: e.pointerId,
		target: e.target,
		clientX: e.clientX,
		clientY: e.clientY,
		timer: 0,
		contextRequested: !1
	};
	t.timer = window.setTimeout(() => {
		i !== t || !t.target.isConnected || t.contextRequested || t.target.dispatchEvent(new MouseEvent("contextmenu", {
			bubbles: !0,
			cancelable: !0,
			composed: !0,
			view: window,
			button: 2,
			clientX: t.clientX,
			clientY: t.clientY,
			screenX: e.screenX,
			screenY: e.screenY
		})) || (t.contextRequested = !0, a = {
			target: t.target,
			clientX: t.clientX,
			clientY: t.clientY,
			expiresAt: Date.now() + 1200
		});
	}, n), i = t;
}, l = (e) => {
	let t = i;
	!t || t.pointerId !== e.pointerId || Math.hypot(e.clientX - t.clientX, e.clientY - t.clientY) > r && o();
}, u = (e) => {
	let t = i;
	!t || t.pointerId !== e.pointerId || (t.contextRequested && a && (a.expiresAt = Date.now() + 1200), o());
}, d = (e) => {
	if (!e.defaultPrevented) return;
	let t = i;
	!e.isTrusted || !t || !s(t.target, e.target) || Math.hypot(e.clientX - t.clientX, e.clientY - t.clientY) > r * 2 || (t.contextRequested = !0, a = {
		target: t.target,
		clientX: t.clientX,
		clientY: t.clientY,
		expiresAt: Date.now() + 1200
	}, window.clearTimeout(t.timer));
}, f = (e) => {
	let t = a;
	if (t) {
		if (Date.now() > t.expiresAt) {
			a = null;
			return;
		}
		e.detail === 0 || !(e.target instanceof Node) || !s(t.target, e.target) || Math.hypot(e.clientX - t.clientX, e.clientY - t.clientY) > r * 2 || (e.preventDefault(), e.stopImmediatePropagation(), a = null);
	}
}, p = () => {
	if (t || typeof document > "u") return;
	t = !0;
	let e = document.documentElement, n = (t) => {
		t.pointerType === "touch" && !e.classList.contains("winui-touch-input") ? e.classList.add("winui-touch-input") : (t.pointerType === "mouse" || t.pointerType === "pen") && e.classList.contains("winui-touch-input") && e.classList.remove("winui-touch-input");
	};
	document.addEventListener("pointerdown", n, !0), document.addEventListener("pointermove", n, !0), document.addEventListener("pointerdown", c, !0), document.addEventListener("pointermove", l, !0), document.addEventListener("pointerup", u, !0), document.addEventListener("pointercancel", u, !0), document.addEventListener("contextmenu", d), document.addEventListener("click", f, !0), document.addEventListener("keydown", (t) => {
		[
			"Tab",
			"Enter",
			" ",
			"ArrowUp",
			"ArrowDown",
			"ArrowLeft",
			"ArrowRight",
			"Home",
			"End",
			"PageUp",
			"PageDown"
		].includes(t.key) && e.classList.remove("winui-touch-input");
	}, !0), window.addEventListener("blur", o);
};
//#endregion
export { p as installPointerInput, e as isHoverPointer };

//# sourceMappingURL=pointerInput.js.map