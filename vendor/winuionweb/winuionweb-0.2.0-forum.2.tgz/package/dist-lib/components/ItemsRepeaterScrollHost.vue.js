import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./ItemsRepeaterScrollHost.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                                            */
import { createElementBlock as n, mergeProps as r, openBlock as i, renderSlot as a } from "vue";
//#region src/components/ItemsRepeaterScrollHost.vue
function o(e, t, o, s, c, l) {
	return i(), n("div", r({
		class: "win-items-repeater-scroll-host",
		style: s.hostStyle
	}, e.$attrs), [a(e.$slots, "default", {}, void 0, !0)], 16);
}
var s = /*#__PURE__*/ e(t, [
	["render", o],
	["__scopeId", "data-v-f50ce47a"],
	["__file", "ItemsRepeaterScrollHost.vue"]
]);
//#endregion
export { s as default };

//# sourceMappingURL=ItemsRepeaterScrollHost.vue.js.map