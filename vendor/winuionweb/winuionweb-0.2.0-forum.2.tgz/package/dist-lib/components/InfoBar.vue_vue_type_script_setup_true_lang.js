import { alignment as e, boolValue as t, cssLength as n, xamlThickness as r } from "./layout.js";
import { normalizeXamlNodes as i, resolveXamlHandler as ee, resolveXamlValue as te, updateXamlBinding as ne, xamlScopeKey as re, xamlTemplateComponent as ie } from "./xamlRuntime.js";
import ae from "./Grid.vue.js";
import oe from "./SymbolIcon.vue.js";
import se from "./Viewbox.vue.js";
import { useI18n as ce } from "./i18n/index.js";
import { xamlResourceDictionaryKey as le } from "./Page.vue_vue_type_script_lang.js";
import ue from "./TextBlock.vue.js";
import de from "./FontIcon.vue.js";
import fe from "./Border.vue.js";
import pe from "./ContentPresenter.vue.js";
import me from "./Button.vue.js";
import he from "./ColumnDefinition.vue.js";
import ge from "./RowDefinition.vue.js";
import _e from "./Image.vue.js";
import ve from "./InfoBarPanel.vue.js";
import { InfoBarActionButton as ye, InfoBarContent as be, InfoBarContentTemplate as xe, InfoBarIconSource as a, getInfoBarProperty as Se } from "./InfoBarProperties.js";
import { Comment as Ce, Fragment as we, Text as Te, cloneVNode as Ee, computed as o, defineComponent as s, getCurrentInstance as De, h as c, inject as Oe, isVNode as l, nextTick as ke, onBeforeUnmount as Ae, onMounted as je, provide as Me, proxyRefs as Ne, ref as Pe, shallowRef as Fe, useAttrs as Ie, useSlots as Le, watch as Re } from "vue";
var u = /*@__PURE__*/ s({
	ActionButton: ye,
	Content: be,
	ContentTemplate: xe,
	IconSource: a,
	name: "InfoBar",
	inheritAttrs: !1,
	__name: "InfoBar",
	props: {
		IsOpen: {
			type: [Boolean, String],
			default: !1
		},
		Title: {
			type: String,
			default: ""
		},
		Message: {
			type: String,
			default: ""
		},
		Severity: {
			type: [String, Number],
			default: "Informational"
		},
		IconSource: {
			type: null,
			default: null
		},
		IsIconVisible: {
			type: [Boolean, String],
			default: !0
		},
		IsClosable: {
			type: [Boolean, String],
			default: !0
		},
		CloseButtonStyle: {
			type: [String, Object],
			default: "{StaticResource InfoBarCloseButtonStyle}"
		},
		CloseButtonCommand: {
			type: null,
			default: null
		},
		CloseButtonCommandParameter: {
			type: null,
			default: null
		},
		ActionButton: {
			type: null,
			default: null
		},
		Content: {
			type: null,
			default: null
		},
		ContentTemplate: {
			type: null,
			default: null
		},
		Background: {
			type: String,
			default: "Transparent"
		},
		Foreground: {
			type: String,
			default: ""
		},
		BorderBrush: {
			type: String,
			default: "{ThemeResource InfoBarBorderBrush}"
		},
		BorderThickness: {
			type: [String, Number],
			default: "{ThemeResource InfoBarBorderThickness}"
		},
		CornerRadius: {
			type: [String, Number],
			default: "{ThemeResource ControlCornerRadius}"
		},
		Width: {
			type: [String, Number],
			default: ""
		},
		Height: {
			type: [String, Number],
			default: ""
		},
		MinWidth: {
			type: [String, Number],
			default: 0
		},
		MinHeight: {
			type: [String, Number],
			default: 0
		},
		MaxWidth: {
			type: [String, Number],
			default: ""
		},
		MaxHeight: {
			type: [String, Number],
			default: ""
		},
		Margin: {
			type: [String, Number],
			default: 0
		},
		HorizontalAlignment: {
			type: String,
			default: "Stretch"
		},
		VerticalAlignment: {
			type: String,
			default: "Top"
		},
		Visibility: {
			type: String,
			default: "Visible"
		},
		RequestedTheme: {
			type: String,
			default: "Default"
		},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		}
	},
	emits: [
		"update:IsOpen",
		"CloseButtonClick",
		"Closing",
		"Closed",
		"Opened"
	],
	setup(ye, { expose: be, emit: xe }) {
		let a = ye, u = xe, d = De(), f = Ie(), ze = Le(), Be = Oe(le, null), { t: p } = ce(), Ve = Pe(null), m = (e) => te(e, d), He = s({
			name: "InfoBarTemplateButton",
			inheritAttrs: !1,
			setup(e, { attrs: t, slots: n }) {
				let r = De();
				return () => c(me, Object.fromEntries(Object.entries(t).map(([e, t]) => [e, te(t, r)])), n);
			}
		}), h = /* @__PURE__ */ new Map(), g = (e, t = (e) => e) => {
			let n = Fe(void 0);
			h.set(e, n);
			let r = o(() => t(m(a[e])));
			return je(() => {
				Re(r, () => {
					n.value = void 0;
				});
			}), o({
				get: () => n.value === void 0 ? r.value : n.value,
				set: (r) => {
					n.value = t(r), ne(a[e], n.value, d);
				}
			});
		}, _ = g("Title", (e) => String(e ?? "")), v = g("Message", (e) => String(e ?? "")), y = g("Severity", (e) => typeof e == "number" ? [
			"Informational",
			"Success",
			"Warning",
			"Error"
		][e] ?? "Informational" : [
			"Informational",
			"Success",
			"Warning",
			"Error"
		].includes(String(e)) ? String(e) : "Informational"), b = g("IsIconVisible", t), x = g("IsClosable", t), S = g("IsEnabled", t), C = g("RequestedTheme", (e) => String(e ?? "Default")), w = g("ActionButton"), T = g("IconSource"), E = g("Content"), D = g("ContentTemplate"), Ue = g("Background"), O = g("Foreground"), k = g("BorderBrush"), A = g("BorderThickness"), We = g("CornerRadius"), Ge = g("CloseButtonStyle"), j = g("CloseButtonCommand"), M = g("CloseButtonCommandParameter"), N = o(() => t(m(a.IsOpen))), P = Pe(N.value), F = o({
			get: () => P.value,
			set: (e) => z(t(e), "Programmatic")
		}), Ke = o(() => ({ IconElement: K.value })), I = Ne({
			IsOpen: F,
			Title: _,
			Message: v,
			Severity: y,
			IsIconVisible: b,
			IsClosable: x,
			IsEnabled: S,
			RequestedTheme: C,
			ActionButton: w,
			IconSource: T,
			Content: E,
			ContentTemplate: D,
			TemplateSettings: Ke,
			Background: Ue,
			Foreground: O,
			BorderBrush: k,
			BorderThickness: A,
			CornerRadius: We,
			CloseButtonStyle: Ge,
			CloseButtonCommand: j,
			CloseButtonCommandParameter: M,
			Element: Ve
		});
		be(I);
		let L = /* @__PURE__ */ new Set(), R = (e, t) => {
			let n = d?.vnode.props?.[`on${e}`];
			Array.isArray(n) ? n.forEach((e) => e(I, t)) : n ? n(I, t) : ee(f[e], d)?.(I, t);
			let r = d?.vnode.props?.[`on${e}Once`];
			r && !L.has(e) && (L.add(e), Array.isArray(r) ? r.forEach((e) => e(I, t)) : r(I, t));
		};
		function z(e, t) {
			if (P.value !== e) {
				if (P.value = e, !e) {
					let e = {
						Reason: t,
						Cancel: !1
					};
					if (R("Closing", e), e.Cancel) {
						z(!0, "Programmatic");
						return;
					}
				}
				ne(a.IsOpen, P.value, d), u("update:IsOpen", P.value), R(e ? "Opened" : "Closed", e ? {} : { Reason: t });
			}
		}
		Re(N, (e) => z(e, "Programmatic"));
		function qe() {
			if (!F.value || !Y.value) return;
			R("CloseButtonClick", null), z(!1, "CloseButton");
			let e = j.value, t = M.value;
			typeof e == "function" ? e(t) : e && (!e.CanExecute || e.CanExecute(t)) && e.Execute?.(t);
		}
		let B = (e) => Array.isArray(e.children) ? e.children : e.children?.default?.() ?? [], V = (e) => e.flatMap((e) => e.type === we ? V(B(e)) : e.type === Ce || e.type === Te && !String(e.children ?? "").trim() ? [] : [e]), H = o(() => {
			let e = {
				ActionButton: [],
				Content: [],
				ContentTemplate: [],
				IconSource: []
			};
			for (let t of V(ze.default?.() ?? [])) {
				let n = Se(t);
				n ? e[n].push(...V(B(t))) : e.Content.push(t);
			}
			return e;
		}), U = o(() => w.value !== null && w.value !== void 0 || h.get("ActionButton")?.value === void 0 && H.value.ActionButton.length > 0), W = (e) => e ? Object.fromEntries(Object.entries(e.props ?? {}).map(([e, t]) => [e, m(t)])) : null, G = (e) => {
			if (l(e)) return e;
			let t = typeof e == "string" ? e.match(/^\{(?:StaticResource|ThemeResource)\s+([^}]+)\}$/)?.[1] ?? e.match(/^var\(--([^,)]+)\)$/)?.[1] : void 0;
			return t ? Be?.[t] : void 0;
		}, K = o(() => {
			let e = h.get("IconSource")?.value === void 0 ? T.value ?? W(H.value.IconSource[0]) : T.value, t = G(e);
			return t ? W(t) : e;
		}), q = o(() => H.value.IconSource[0]?.type?.__iconSourceKind), Je = s({
			name: "InfoBarIconPresenter",
			setup() {
				return () => {
					let e = K.value;
					return e ? l(e) ? e : e.Glyph !== void 0 || q.value === "FontIcon" ? c(de, {
						...e,
						FontFamily: e.FontFamily || "var(--SymbolThemeFontFamily)",
						FontSize: e.FontSize ?? 20
					}) : e.Symbol !== void 0 || q.value === "SymbolIcon" ? c(oe, e) : e.Data !== void 0 || q.value === "PathIcon" ? c("svg", {
						viewBox: "0 0 20 20",
						width: 20,
						height: 20,
						"aria-hidden": "true",
						style: { fill: e.Foreground || "currentColor" }
					}, [c("path", { d: e.Data })]) : e.UriSource || e.ImageSource ? c(_e, {
						Source: e.UriSource ?? e.ImageSource,
						Stretch: "Uniform"
					}) : H.value.IconSource.length ? i(H.value.IconSource, d)[0] : null : null;
				};
			}
		}), Ye = s({
			name: "InfoBarActionPresenter",
			setup() {
				return () => {
					if (w.value === null && h.get("ActionButton")?.value !== void 0) return null;
					if (l(w.value)) return S.value ? w.value : Ee(w.value, { IsEnabled: !1 });
					let e = i(H.value.ActionButton, d);
					return c(we, S.value ? e : e.map((e) => Ee(e, { IsEnabled: !1 })));
				};
			}
		}), Xe = s({
			name: "InfoBarContentPresenter",
			setup() {
				return () => {
					let e = E.value;
					if (e === null && h.get("Content")?.value !== void 0) return null;
					let t = G(D.value), n = t ? B(t) : H.value.ContentTemplate.flatMap((e) => B(e));
					return n.length ? c(ie(n, e, d)) : typeof D.value == "function" || D.value && typeof D.value == "object" && !l(D.value) ? c(D.value, { Content: e }) : l(e) ? e : H.value.Content.length ? c(we, i(H.value.Content, d)) : typeof e == "string" || typeof e == "number" ? c(ue, {
						Text: String(e),
						TextWrapping: "WrapWholeWords"
					}) : null;
				};
			}
		}), J = (e) => e ? "Visible" : "Collapsed", Ze = o(() => J(F.value)), Qe = o(() => J(_.value)), $e = o(() => J(v.value)), et = o(() => J(b.value && !K.value)), tt = o(() => J(b.value && K.value)), nt = o(() => J(x.value)), Y = o(() => {
			let e = j.value;
			return S.value && (typeof e?.CanExecute != "function" || e.CanExecute(M.value));
		}), rt = o(() => J(U.value)), it = o(() => _.value || v.value || U.value ? 1 : 0), at = o(() => `var(--InfoBar${y.value}SeverityBackgroundBrush)`), ot = o(() => `var(--InfoBar${y.value}SeverityIconBackground)`), st = o(() => `var(--InfoBar${y.value}SeverityIconForeground)`), ct = o(() => ({
			Informational: "",
			Success: "",
			Warning: "",
			Error: ""
		})[String(y.value)]), lt = o(() => p(`control.infobar.severity-${String(y.value).toLowerCase()}`)), ut = o(() => String(m(f["AutomationProperties.Name"]) || p("control.infobar.landmark-name"))), dt = o(() => p("control.infobar.close-button-name")), ft = o(() => p("control.infobar.close-button-tooltip")), pt = o(() => O.value || "var(--InfoBarTitleForeground)"), mt = o(() => O.value || "var(--InfoBarMessageForeground)"), ht = _, gt = v, _t = Ue, vt = k, yt = A, bt = We, xt = (e) => typeof e == "string" ? e.match(/^\{(?:StaticResource|ThemeResource)\s+([^}]+)\}$/)?.[1] ?? e.match(/^var\(--([^,)]+)\)$/)?.[1] ?? e : "", X = (e, t = /* @__PURE__ */ new Set()) => {
			if (!e || t.has(e)) return {
				name: "DefaultButtonStyle",
				setters: {},
				infoBarStyle: !1
			};
			t.add(e);
			let n = xt(e), r = G(e);
			if (r) {
				let e = X(r.props?.BasedOn, t), n = { ...e.setters }, i = (e) => {
					for (let t of V(e)) (typeof t.type == "string" ? t.type : t.type?.name ?? t.type?.__name) === "Setter" && typeof t.props?.Property == "string" ? n[t.props.Property] = m(t.props.Value) : i(B(t));
				};
				return i(B(r)), {
					...e,
					setters: n
				};
			}
			if (n === "InfoBarCloseButtonStyle") return {
				name: "DefaultButtonStyle",
				infoBarStyle: !0,
				setters: {
					Width: m("{StaticResource InfoBarCloseButtonSize}"),
					Height: m("{StaticResource InfoBarCloseButtonSize}"),
					VerticalAlignment: "Top",
					Margin: "5"
				}
			};
			if (typeof e == "object" && !l(e)) {
				let n = e, r = X(n.BasedOn, t), i = { ...r.setters };
				if (Array.isArray(n.Setters)) for (let e of n.Setters) e.Property && (i[e.Property] = m(e.Value));
				else for (let [e, t] of Object.entries(n.Setters ?? n)) [
					"BasedOn",
					"Setters",
					"TargetType"
				].includes(e) || (i[e] = m(t));
				return {
					...r,
					setters: i
				};
			}
			return {
				name: n || "DefaultButtonStyle",
				setters: {},
				infoBarStyle: !1
			};
		}, Z = o(() => X(Ge.value)), St = o(() => Object.fromEntries(Object.entries(Z.value.setters).map(([e, t]) => [e, [
			"Padding",
			"Margin",
			"FontWeight",
			"FontFamily",
			"HorizontalAlignment",
			"VerticalAlignment"
		].includes(e) ? String(t ?? "") : t]))), Q = (e) => o(() => St.value[e] ?? ""), Ct = Q("Width"), wt = Q("Height"), Tt = Q("MinWidth"), Et = Q("MinHeight"), Dt = Q("MaxWidth"), Ot = Q("MaxHeight"), kt = Q("Margin"), At = Q("Padding"), jt = Q("HorizontalAlignment"), Mt = Q("VerticalAlignment"), Nt = Q("HorizontalContentAlignment"), Pt = Q("VerticalContentAlignment"), Ft = Q("Background"), It = Q("Foreground"), Lt = Q("BorderBrush"), Rt = Q("BorderThickness"), zt = Q("CornerRadius"), Bt = Q("FontFamily"), Vt = Q("FontWeight"), Ht = Q("FontSize"), Ut = o(() => Z.value.name), Wt = o(() => Z.value.infoBarStyle), Gt = o(() => `win-infobar-${String(y.value).toLowerCase()}`), Kt = o(() => ["Light", "Dark"].includes(String(C.value)) ? `theme-${String(C.value).toLowerCase()}` : ""), qt = o(() => Object.fromEntries(Object.entries(f).filter(([e]) => ![
			"class",
			"style",
			"CloseButtonClick",
			"Closing",
			"Closed",
			"Opened",
			"AutomationProperties.Name"
		].includes(e)))), Jt = o(() => {
			let t = {
				justifySelf: e(m(a.HorizontalAlignment), "horizontal"),
				alignSelf: e(m(a.VerticalAlignment), "vertical"),
				margin: r(m(a.Margin))
			};
			for (let e of [
				"Width",
				"Height",
				"MinWidth",
				"MinHeight",
				"MaxWidth",
				"MaxHeight"
			]) m(a[e]) !== "" && (t[e[0].toLowerCase() + e.slice(1)] = n(m(a[e])));
			return (!F.value || m(a.Visibility) === "Collapsed") && (t.display = "none"), m(a.Visibility) === "Hidden" && (t.visibility = "hidden"), [f.style, t];
		});
		Me(re, {
			RootVisibility: Ze,
			TitleVisibility: Qe,
			MessageVisibility: $e,
			StandardIconVisibility: et,
			UserIconVisibility: tt,
			CloseVisibility: nt,
			CloseButtonEnabled: Y,
			CloseButtonWidth: Ct,
			CloseButtonHeight: wt,
			CloseButtonMinWidth: Tt,
			CloseButtonMinHeight: Et,
			CloseButtonMaxWidth: Dt,
			CloseButtonMaxHeight: Ot,
			CloseButtonMargin: kt,
			CloseButtonPadding: At,
			CloseButtonHorizontalAlignment: jt,
			CloseButtonVerticalAlignment: Mt,
			CloseButtonHorizontalContentAlignment: Nt,
			CloseButtonVerticalContentAlignment: Pt,
			CloseButtonBackground: Ft,
			CloseButtonForeground: It,
			CloseButtonBorderBrush: Lt,
			CloseButtonBorderThickness: Rt,
			CloseButtonCornerRadius: zt,
			CloseButtonFontFamily: Bt,
			CloseButtonFontWeight: Vt,
			CloseButtonFontSize: Ht,
			ActionVisibility: rt,
			ContentRow: it,
			SeverityBackground: at,
			SeverityIconBackground: ot,
			SeverityIconForeground: st,
			SeverityIconGlyph: ct,
			SeverityLabel: lt,
			CloseLabel: dt,
			CloseTooltip: ft,
			TitleForeground: pt,
			MessageForeground: mt,
			InfoBarTitle: ht,
			InfoBarMessage: gt,
			InfoBarBackground: _t,
			InfoBarBorderBrush: vt,
			InfoBarBorderThickness: yt,
			InfoBarCornerRadius: bt,
			InfoBarCloseStyle: Ut,
			OnCloseButtonClick: qe
		});
		let $ = !1;
		je(() => {
			ke(() => {
				$ || ee(f.Loaded, d)?.(I, {});
			});
		}), Ae(() => {
			$ = !0;
		});
		let Yt = {
			props: a,
			emit: u,
			instance: d,
			attrs: f,
			slots: ze,
			resources: Be,
			t: p,
			rootRef: Ve,
			resolve: m,
			Button: He,
			overrides: h,
			dependency: g,
			Title: _,
			Message: v,
			Severity: y,
			IsIconVisible: b,
			IsClosable: x,
			IsEnabled: S,
			RequestedTheme: C,
			ActionButton: w,
			IconSource: T,
			Content: E,
			ContentTemplate: D,
			Background: Ue,
			Foreground: O,
			BorderBrush: k,
			BorderThickness: A,
			CornerRadius: We,
			CloseButtonStyle: Ge,
			CloseButtonCommand: j,
			CloseButtonCommandParameter: M,
			sourceOpen: N,
			localOpen: P,
			IsOpen: F,
			TemplateSettings: Ke,
			publicApi: I,
			onceEvents: L,
			dispatch: R,
			setOpen: z,
			OnCloseButtonClick: qe,
			nodeChildren: B,
			visualNodes: V,
			propertyNodes: H,
			hasAction: U,
			sourceFromNode: W,
			resourceNode: G,
			effectiveIcon: K,
			iconKind: q,
			IconOutlet: Je,
			ActionOutlet: Ye,
			ContentOutlet: Xe,
			visibility: J,
			RootVisibility: Ze,
			TitleVisibility: Qe,
			MessageVisibility: $e,
			StandardIconVisibility: et,
			UserIconVisibility: tt,
			CloseVisibility: nt,
			CloseButtonEnabled: Y,
			ActionVisibility: rt,
			ContentRow: it,
			SeverityBackground: at,
			SeverityIconBackground: ot,
			SeverityIconForeground: st,
			SeverityIconGlyph: ct,
			SeverityLabel: lt,
			LandmarkLabel: ut,
			CloseLabel: dt,
			CloseTooltip: ft,
			TitleForeground: pt,
			MessageForeground: mt,
			InfoBarTitle: ht,
			InfoBarMessage: gt,
			InfoBarBackground: _t,
			InfoBarBorderBrush: vt,
			InfoBarBorderThickness: yt,
			InfoBarCornerRadius: bt,
			styleName: xt,
			resolveCloseStyle: X,
			closeStyle: Z,
			closeStyleSetters: St,
			closeStyleValue: Q,
			CloseButtonWidth: Ct,
			CloseButtonHeight: wt,
			CloseButtonMinWidth: Tt,
			CloseButtonMinHeight: Et,
			CloseButtonMaxWidth: Dt,
			CloseButtonMaxHeight: Ot,
			CloseButtonMargin: kt,
			CloseButtonPadding: At,
			CloseButtonHorizontalAlignment: jt,
			CloseButtonVerticalAlignment: Mt,
			CloseButtonHorizontalContentAlignment: Nt,
			CloseButtonVerticalContentAlignment: Pt,
			CloseButtonBackground: Ft,
			CloseButtonForeground: It,
			CloseButtonBorderBrush: Lt,
			CloseButtonBorderThickness: Rt,
			CloseButtonCornerRadius: zt,
			CloseButtonFontFamily: Bt,
			CloseButtonFontWeight: Vt,
			CloseButtonFontSize: Ht,
			InfoBarCloseStyle: Ut,
			usesDefaultCloseStyle: Wt,
			severityClass: Gt,
			themeClass: Kt,
			rootAttrs: qt,
			rootStyle: Jt,
			get disposed() {
				return $;
			},
			set disposed(e) {
				$ = e;
			},
			Border: fe,
			ColumnDefinition: he,
			ContentPresenter: pe,
			Grid: ae,
			InfoBarPanel: ve,
			RowDefinition: ge,
			SymbolIcon: oe,
			TextBlock: ue,
			Viewbox: se
		};
		return Object.defineProperty(Yt, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), Yt;
	}
});
//#endregion
export { u as default };

//# sourceMappingURL=InfoBar.vue_vue_type_script_setup_true_lang.js.map