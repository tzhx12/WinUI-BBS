import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./Canvas.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                           */
import { createElementBlock as n, createVNode as r, mergeProps as i, openBlock as a, withDirectives as o } from "vue";
//#region src/components/Canvas.vue
function s(e, t, s, c, l, u) {
	return o((a(), n("div", i({ ref: "root" }, c.attrs, {
		class: "win-canvas",
		style: [c.attrs.style, c.resolveRootStyle()]
	}), [r(c.ChildrenOutlet)], 16)), [[c.vAcrylicBrush, c.resolveRootStyle()], [c.vRadialGradientBrush, c.backgroundBrush.value.value]]);
}
var c = /*#__PURE__*/ e(t, [
	["render", s],
	["__scopeId", "data-v-79fd0f1c"],
	["__file", "Canvas.vue"]
]);
//#endregion
export { c as default };

//# sourceMappingURL=Canvas.vue.js.map