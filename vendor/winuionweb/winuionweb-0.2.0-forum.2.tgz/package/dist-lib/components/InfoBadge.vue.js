import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./InfoBadge.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                              */
import { createElementBlock as n, createVNode as r, mergeProps as i, openBlock as a, withCtx as o } from "vue";
//#region src/components/InfoBadge.vue
var s = [
	"HorizontalAlignment",
	"VerticalAlignment",
	"aria-label"
];
function c(e, t, c, l, u, d) {
	return a(), n("span", i({ ref: "rootRef" }, l.badgeAttrs, {
		class: ["win-infobadge win-theme-scope", [
			l.displayKindClass,
			l.themeClass,
			l.attrs.class
		]],
		HorizontalAlignment: l.value(l.props.HorizontalAlignment),
		VerticalAlignment: l.value(l.props.VerticalAlignment),
		style: l.badgeStyle,
		"aria-label": l.automationName
	}), [r(l.Grid, {
		"x:Name": "RootGrid",
		class: "win-infobadge-root-grid",
		Background: "{x:Bind BadgeBackground, Mode=OneWay}",
		CornerRadius: "{x:Bind TemplateSettings.InfoBadgeCornerRadius, Mode=OneWay}",
		Padding: "{x:Bind BadgePadding, Mode=OneWay}"
	}, {
		default: o(() => [r(l.TextBlock, {
			"x:Name": "ValueTextBlock",
			class: "win-infobadge-value-text",
			Text: "{x:Bind BadgeValue, Mode=OneWay}",
			Foreground: "{x:Bind BadgeForeground, Mode=OneWay}",
			FontSize: "{ThemeResource InfoBadgeValueFontSize}",
			Visibility: "{x:Bind ValueVisibility, Mode=OneWay}",
			Margin: "{x:Bind ValueMargin, Mode=OneWay}",
			HorizontalAlignment: "Center",
			VerticalAlignment: "Center"
		}), r(l.Viewbox, {
			"x:Name": "IconPresenter",
			class: "win-infobadge-icon-presenter",
			Width: "{x:Bind IconViewportWidth, Mode=OneWay}",
			Height: "{x:Bind IconViewportHeight, Mode=OneWay}",
			Visibility: "{x:Bind IconVisibility, Mode=OneWay}",
			Margin: "{x:Bind IconMargin, Mode=OneWay}",
			HorizontalAlignment: "Center",
			VerticalAlignment: "Stretch"
		}, {
			default: o(() => [r(l.ContentPresenter, null, {
				default: o(() => [r(l.IconElementPresenter)]),
				_: 1
			})]),
			_: 1
		})]),
		_: 1
	})], 16, s);
}
var l = /*#__PURE__*/ e(t, [
	["render", c],
	["__scopeId", "data-v-d4df3e1a"],
	["__file", "InfoBadge.vue"]
]);
//#endregion
export { l as default };

//# sourceMappingURL=InfoBadge.vue.js.map