//#region src/components/scrollBarOwner.ts
var e = Symbol("ScrollBar template owner");
//#endregion
export { e as scrollBarOwnerKey };

//# sourceMappingURL=scrollBarOwner.js.map