import { normalizeXamlNodes as e, resolveXamlHandler as t, resolveXamlResourceObject as n, resolveXamlValue as r, updateXamlBinding as i } from "./xamlRuntime.js";
import { resolvePopupElement as a } from "./popupRuntime.js";
import { getVNodeChildren as o } from "./CollectionProperties.js";
import s from "./MenuFlyoutPresenter.js";
import { MenuFlyoutItemsProperty as c, MenuFlyoutPresenterStyleProperty as l } from "./MenuFlyoutItems.js";
import { Fragment as u, computed as d, defineComponent as f, getCurrentInstance as p, h as m, inject as h, isVNode as g, onBeforeUnmount as _, onMounted as v, proxyRefs as y, ref as b, shallowReactive as ee, shallowRef as te, useAttrs as ne, useSlots as re, watch as x } from "vue";
var S = /*@__PURE__*/ f({
	Items: c,
	MenuFlyoutPresenterStyle: l,
	__menuFlyoutDefinition: !0,
	name: "MenuFlyout",
	inheritAttrs: !1,
	__name: "MenuFlyout",
	props: {
		Items: {
			type: null,
			default: void 0
		},
		MenuFlyoutPresenterStyle: {
			type: null,
			default: void 0
		},
		Placement: {
			type: String,
			default: "Bottom"
		},
		ShowMode: {
			type: String,
			default: "Standard"
		},
		LightDismissOverlayMode: {
			type: String,
			default: "Auto"
		},
		AreOpenCloseAnimationsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		ShouldConstrainToRootBounds: {
			type: [Boolean, String],
			default: !0
		},
		AllowFocusOnInteraction: {
			type: [Boolean, String],
			default: !0
		},
		AllowFocusWhenDisabled: {
			type: [Boolean, String],
			default: !1
		},
		OverlayInputPassThroughElement: {
			type: null,
			default: void 0
		}
	},
	emits: [
		"Opening",
		"Opened",
		"Closing",
		"Closed",
		"update:Items",
		"update:MenuFlyoutPresenterStyle",
		"update:Placement",
		"update:ShowMode",
		"update:LightDismissOverlayMode",
		"update:AreOpenCloseAnimationsEnabled",
		"update:ShouldConstrainToRootBounds",
		"update:AllowFocusOnInteraction",
		"update:AllowFocusWhenDisabled",
		"update:OverlayInputPassThroughElement"
	],
	setup(c, { expose: l, emit: S }) {
		let C = c, w = S, T = p(), E = ne(), D = re(), O = b(null), k = b(null), A = h("buttonFlyoutAnchor", null), j = h("buttonFlyoutController", null), M = ee({}), N = (e) => e in M ? M[e] : r(C[e], T), P = (e) => d({
			get: () => N(e),
			set: (t) => {
				M[e] = t, i(C[e], t, T), w(`update:${e}`, t);
			}
		}), F = Object.fromEntries(Object.keys(C).filter((e) => e !== "Items").map((e) => [e, P(e)]));
		for (let e of Object.keys(C)) x(() => r(C[e], T), () => {
			delete M[e];
		});
		let I = te([]), L = (e) => e.type?.__menuFlyoutProperty, R = d(() => {
			if ("Items" in M || C.Items !== void 0) {
				let t = N("Items");
				return e(Array.isArray(t) ? t.filter(g) : g(t) ? [t] : [], T);
			}
			let t = I.value.find((e) => L(e) === "Items");
			return e(t ? o(t) : I.value.filter((e) => !L(e)), T);
		}), z = f({
			name: "MenuFlyoutItemsOutlet",
			setup() {
				return () => (I.value = D.default?.() ?? [], m(u, R.value));
			}
		}), B = d(() => {
			let e = I.value.find((e) => L(e) === "MenuFlyoutPresenterStyle");
			if (e && !("MenuFlyoutPresenterStyle" in M)) {
				let t = {};
				for (let n of o(e)) for (let e of o(n)) typeof e.props?.Property == "string" && (t[e.props.Property] = ["Background", "SystemBackdrop"].includes(e.props.Property) ? e.props.Value : r(e.props.Value, T));
				return t;
			}
			let t = N("MenuFlyoutPresenterStyle"), i = typeof t == "string" ? t.match(/^\{(?:StaticResource|ThemeResource)\s+([^}]+)\}$/)?.[1] : "", a = i ? n(i, T) : t;
			if (!a || typeof a != "object") return {};
			let s = a.Setters;
			return Array.isArray(s) ? Object.fromEntries(s.map((e) => [e.Property, ["Background", "SystemBackdrop"].includes(e.Property) ? e.Value : r(e.Value, T)])) : a;
		}), V = () => k.value?.Items ?? [], H = (e) => {
			M.Items = e, i(C.Items, e, T), w("update:Items", e);
		}, U = () => "Items" in M || C.Items !== void 0 ? [...Array.isArray(N("Items")) ? N("Items") : []] : [...R.value], W = (e) => {
			if (!g(e) || !e.type?.__menuFlyoutItem) throw TypeError("MenuFlyout.Items accepts MenuFlyoutItemBase elements.");
			return e;
		}, G = {
			GetAt: (e) => V()[e],
			Add: (e) => {
				let t = U();
				t.push(W(e)), H(t);
			},
			Append: (e) => {
				G.Add(e);
			},
			InsertAt: (e, t) => {
				let n = U();
				n.splice(e, 0, W(t)), H(n);
			},
			SetAt: (e, t) => {
				let n = U();
				n.splice(e, 1, W(t)), H(n);
			},
			RemoveAt: (e) => {
				let t = U();
				t.splice(e, 1), H(t);
			},
			RemoveAtEnd: () => {
				let e = U();
				e.pop(), H(e);
			},
			Clear: () => H([]),
			IndexOf: (e) => V().indexOf(e),
			ReplaceAll: (e) => H(e.map(W))
		}, K = new Proxy(G, { get(e, t) {
			if (t === "Count" || t === "Size" || t === "length") return V().length;
			if (t === Symbol.iterator) return function* () {
				yield* V();
			};
			if (t in e) return e[t];
			let n = V(), r = n[t];
			return typeof r == "function" ? r.bind(n) : r;
		} }), q = d({
			get: () => K,
			set: H
		});
		async function J(e, t) {
			let n = a(e) || A?.value || O.value?.parentElement;
			n && await k.value?.ShowAt(n, t);
		}
		function Y(e = !0) {
			k.value?.Hide(e);
		}
		let X = y({
			...F,
			Items: q,
			ShowAt: J,
			Hide: Y,
			IsOpen: d(() => k.value?.IsOpen ?? !1),
			Target: d(() => k.value?.Target ?? null),
			IsConstrainedToRootBounds: d(() => N("ShouldConstrainToRootBounds") !== !1 && N("ShouldConstrainToRootBounds") !== "False")
		}), Z = (e, n = {}) => {
			let r = T?.vnode.props?.[`on${e}`];
			for (let e of Array.isArray(r) ? r : r ? [r] : []) typeof e == "function" && e(X, n);
			t(E[e], T)?.(X, n);
		}, ie = {
			Api: X,
			Hide: Y,
			Raise: Z,
			Options: () => ({
				...Object.fromEntries(Object.keys(C).filter((e) => !["Items", "MenuFlyoutPresenterStyle"].includes(e)).map((e) => [e, N(e)])),
				PresenterStyle: B.value
			})
		}, Q = () => {
			J(A?.value);
		};
		A && x(A, (e, t) => {
			t?.removeEventListener("click", Q), e?.addEventListener("click", Q);
		}, { immediate: !0 }), v(() => {
			j && (j.value = X);
		}), _(() => {
			A?.value?.removeEventListener("click", Q), j?.value === X && (j.value = null);
		}), l({
			...F,
			Items: q,
			ShowAt: J,
			Hide: Y,
			IsOpen: d(() => k.value?.IsOpen ?? !1),
			Target: d(() => k.value?.Target ?? null),
			IsConstrainedToRootBounds: d(() => N("ShouldConstrainToRootBounds") !== !1 && N("ShouldConstrainToRootBounds") !== "False")
		});
		let $ = {
			props: C,
			emit: w,
			instance: T,
			attrs: E,
			slots: D,
			anchor: O,
			presenter: k,
			buttonAnchor: A,
			buttonController: j,
			overrides: M,
			value: N,
			dependency: P,
			dependencies: F,
			propertyNodes: I,
			marker: L,
			nodes: R,
			ItemsOutlet: z,
			style: B,
			currentItems: V,
			replaceItems: H,
			editableNodes: U,
			requireItem: W,
			collectionMethods: G,
			collection: K,
			itemCollection: q,
			ShowAt: J,
			Hide: Y,
			api: X,
			raise: Z,
			owner: ie,
			onButtonClick: Q,
			get MenuFlyoutPresenter() {
				return s;
			}
		};
		return Object.defineProperty($, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), $;
	}
});
//#endregion
export { S as default };

//# sourceMappingURL=MenuFlyout.vue_vue_type_script_setup_true_lang.js.map