import { createThemeShadow as e, getThemeShadowRecipe as t, isThemeShadow as n, shadowCornerRadius as r, themeShadowVisualStyle as i } from "./themeShadowRuntime.js";
/* empty css                      */
import { shallowRef as a, watchEffect as o } from "vue";
//#region src/components/themeShadowVisual.ts
var s = Symbol("ThemeShadow directive"), c = /* @__PURE__ */ new WeakMap(), l = (e) => typeof e == "number" ? e : Number(typeof e == "string" ? e.split(",")[2] ?? 0 : e?.Z ?? 0), u = (e, t) => {
	if (typeof t == "string" && /\bdark\b/i.test(t)) return "dark";
	if (typeof t == "string" && /\blight\b/i.test(t)) return "light";
	let n = e;
	for (; n;) {
		if (n.classList.contains("theme-dark") || n.dataset.theme === "dark") return "dark";
		if (n.classList.contains("theme-light") || n.dataset.theme === "light") return "light";
		n = n.parentElement;
	}
	return typeof matchMedia < "u" && matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
}, d = (e, t = s) => {
	let n = c.get(e);
	n && (n.owners.get(t)?.dispose(), n.owners.delete(t), !n.owners.size && (n.appliedPosition && e.style.position === "relative" && (e.style.position = n.previousPosition), c.delete(e)));
}, f = (f, p, m = s) => {
	let h = c.get(f), g = h?.owners.get(m);
	if (!p || p.Enabled === !1 || "Shadow" in p && !n(p.Shadow)) {
		d(f, m);
		return;
	}
	if (g) {
		g.options.value = p;
		return;
	}
	h || (h = {
		owners: /* @__PURE__ */ new Map(),
		previousPosition: f.style.position,
		appliedPosition: !1
	}, c.set(f, h));
	let _ = h, v = a(p), y = a(0), b = null, x = null, S = null, C, w = document.createElement("div");
	w.className = "win-theme-shadow-visual", w.setAttribute("aria-hidden", "true"), f.prepend(w);
	let T = new MutationObserver(() => {
		y.value++;
	});
	for (let e = f; e; e = e.parentElement) T.observe(e, {
		attributes: !0,
		attributeFilter: ["class", "data-theme"]
	});
	let E = matchMedia("(prefers-color-scheme: dark)"), D = () => {
		y.value++;
	};
	E.addEventListener("change", D);
	let O = o(() => {
		y.value;
		let n = v.value, a = "Shadow" in n;
		!a && !b && (b = e());
		let o = a ? n.Shadow ?? null : b, s = n.Caster ?? f;
		if ((o !== x || s !== S) && (C?.(), C = void 0, x = o, S = s, o && !o.IsDisposed && (C = o.AttachCaster(s))), a && b && (b.Dispose(), b = null), !o || o.IsDisposed) {
			w.style.display = "none";
			return;
		}
		getComputedStyle(f).position === "static" && (f.style.position = "relative", _.appliedPosition = !0);
		let c = getComputedStyle(f), d = n.CornerRadius === void 0 ? Math.max(...[
			c.borderTopLeftRadius,
			c.borderTopRightRadius,
			c.borderBottomRightRadius,
			c.borderBottomLeftRadius
		].map((e) => Number.parseFloat(e) || 0)) : r(n.CornerRadius), p = l(n.Translation);
		w.style.cssText = "", Object.assign(w.style, i(t(p, u(f, n.Theme)), d)), w.dataset.translationZ = String(p);
	});
	_.owners.set(m, {
		options: v,
		dispose: () => {
			O(), T.disconnect(), E.removeEventListener("change", D), C?.(), b?.Dispose(), w.remove();
		}
	});
}, p = {
	mounted: (e, t) => f(e, t.value),
	updated: (e, t) => f(e, t.value),
	beforeUnmount: (e) => d(e)
};
//#endregion
export { d as clearThemeShadowVisual, f as setThemeShadowVisual, p as vThemeShadow };

//# sourceMappingURL=themeShadowVisual.js.map