import { resolveXamlValue as e, updateXamlBinding as t, xamlTemplateComponent as n } from "./xamlRuntime.js";
import { xamlResourceDictionaryKey as r } from "./Page.vue_vue_type_script_lang.js";
import { getVNodeChildren as i } from "./CollectionProperties.js";
import { Fragment as a, computed as o, defineComponent as s, h as c, inject as l, isVNode as u, provide as d, shallowRef as f, watch as p } from "vue";
//#region src/components/buttonContentRuntime.ts
var m = (e) => {
	if (Array.isArray(e.children)) return e.children;
	let t = e.children?.default?.();
	return Array.isArray(t) ? t : t ? [t] : [];
}, h = (e, t) => s({
	name: `${e}.${t}`,
	__buttonContentProperty: t,
	setup() {
		return () => null;
	}
}), g = (e) => {
	let t = e.type;
	return typeof t != "string" && t?.__buttonContentProperty ? t.__buttonContentProperty : (typeof t == "string" ? t : t?.name ?? t?.__name ?? "").match(/^(?:Button|HyperlinkButton|RepeatButton|ToggleButton|SplitButton|ToggleSplitButton|DropDownButton)\.(ContentTemplate|ContentTransitions|Resources)$/)?.[1];
}, _ = (s, h, _) => {
	let v = l(r, {}), y = o(() => {
		let e = {
			ContentTemplate: [],
			ContentTransitions: [],
			Resources: []
		}, t = (n) => {
			for (let r of n) {
				if (r.type === a && Array.isArray(r.children)) {
					t(r.children);
					continue;
				}
				let n = g(r);
				n && e[n].push(...m(r));
			}
		};
		return t(h()), e;
	}), b = o(() => {
		let e = (t) => t.flatMap((t) => {
			let n = t.type, r = typeof n == "string" ? n : n?.name ?? n?.__name;
			return t.type === a || r === "ResourceDictionary" ? e(m(t)) : [t];
		});
		return Object.fromEntries(e(y.value.Resources).filter((e) => e.props?.["x:Key"]).map((e) => [e.props["x:Key"], e]));
	});
	d(r, new Proxy(v, { get: (e, t) => b.value[t] ?? e[t] }));
	let x = (t) => {
		let n = e(t, _);
		if (typeof n != "string") return n;
		let r = t?.toString().match(/^\{\s*(?:ThemeResource|StaticResource)\s+([^\s}]+)\s*\}$/)?.[1] ?? n.match(/^var\(--([^,)]+)\)$/)?.[1];
		return r ? b.value[r] ?? v[r] ?? n : n;
	}, S = (e) => {
		let n = o(() => x(s[e])), r = f(void 0);
		return p(n, () => {
			r.value = void 0;
		}), o({
			get: () => {
				if (r.value !== void 0) return r.value;
				let t = y.value[e];
				return e === "ContentTransitions" ? t.length ? t.flatMap((e) => {
					let t = e.type;
					return (typeof t == "string" ? t : t?.name ?? t?.__name) === "TransitionCollection" ? m(e) : [e];
				}) : n.value : t[0] ?? n.value;
			},
			set: (n) => {
				r.value = n, t(s[e], n, _);
			}
		});
	}, C = S("ContentTemplate");
	return {
		ContentTemplate: C,
		ContentTransitions: S("ContentTransitions"),
		renderTemplate: (e) => {
			let t = C.value;
			if (u(t)) {
				let r = t.type;
				return n((r?.name ?? r?.__name) === "DataTemplate" ? i(t) : [t], e, _);
			}
			return typeof t == "function" ? t(e) : t && typeof t == "object" && ("render" in t || "setup" in t) ? c(t, { Content: e }) : null;
		}
	};
};
//#endregion
export { h as buttonContentProperty, g as getButtonContentProperty, _ as useButtonContent };

//# sourceMappingURL=buttonContentRuntime.js.map