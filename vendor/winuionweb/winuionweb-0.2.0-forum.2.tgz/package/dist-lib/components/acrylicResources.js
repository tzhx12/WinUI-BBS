import { createAcrylicBrush as e, createSolidColorBrush as t } from "./brushCore.js";
//#region src/components/acrylicResources.ts
var n = [
	"ToolTipBackgroundBrush",
	"FlyoutPresenterBackground",
	"ComboBoxDropDownBackground",
	"NavigationViewDefaultPaneBackground",
	"TeachingTipTransientBackground",
	"CommandBarBackgroundOpen",
	"CommandBarOverflowPresenterBackground",
	"MediaTransportControlsPanelBackground",
	"FlipViewNextPreviousButtonBackground",
	"FlipViewNextPreviousButtonBackgroundPointerOver",
	"FlipViewNextPreviousButtonBackgroundPressed",
	"ScrollBarTrackFill",
	"ScrollBarTrackFillPointerOver",
	"ScrollBarTrackFillPressed",
	"ScrollBarTrackFillDisabled",
	"ScrollBarTrackStroke",
	"ScrollBarTrackStrokePointerOver",
	"ScrollBarTrackStrokePressed",
	"ScrollBarTrackStrokeDisabled"
], r = [
	"AutoSuggestBoxSuggestionsListBackground",
	"DatePickerFlyoutPresenterBackground",
	"TimePickerFlyoutPresenterBackground",
	"LoopingSelectorUpDownButtonBackground",
	"NumberBoxPopupBackground",
	"BreadcrumbBarEllipsisFlyoutPresenterBackground",
	"MediaTransportControlsFlyoutBackground",
	"AcrylicBackgroundFillColorDefaultBackdrop",
	"MenuFlyoutSystemBackdrop",
	"CommandBarFlyoutSystemBackdrop"
], i = ["MenuFlyoutPresenterBackground", "CommandBarFlyoutBackground"], a = Object.freeze({
	...Object.fromEntries(n.map((e) => [e, "AcrylicInAppFillColorDefaultBrush"])),
	...Object.fromEntries(r.map((e) => [e, "AcrylicBackgroundFillColorDefaultBrush"])),
	...Object.fromEntries(i.map((e) => [e, "DesktopAcrylicTransparentBrush"]))
}), o = {
	Default: {
		dark: [
			"#2C2C2C",
			.15,
			.96,
			"#2C2C2C"
		],
		light: [
			"#FCFCFC",
			0,
			.85,
			"#F9F9F9"
		]
	},
	Base: {
		dark: [
			"#202020",
			.5,
			.96,
			"#1C1C1C"
		],
		light: [
			"#F3F3F3",
			0,
			.9,
			"#EEEEEE"
		]
	}
}, s = {
	SystemAccentColorDark1: "#005A9E",
	SystemAccentColorDark2: "#004578",
	SystemAccentColorLight3: "#A6D8FF"
}, c = (n, r = s, c = !1) => {
	let l = { DesktopAcrylicTransparentBrush: t("Transparent") }, u = (n, r) => {
		l[n] = c ? t(n.includes("Inverse") ? "CanvasText" : "Canvas") : e({
			TintColor: r[0],
			TintOpacity: r[1],
			TintLuminosityOpacity: r[2],
			FallbackColor: r[3]
		});
	};
	for (let e of ["Background", "InApp"]) for (let t of ["Default", "Base"]) {
		u(`Acrylic${e}FillColor${t}Brush`, o[t][n]), t === "Default" && u(`Acrylic${e}FillColorDefaultInverseBrush`, o.Default[n === "dark" ? "light" : "dark"]);
		let i = (typeof r == "string" ? {
			SystemAccentColorDark1: r,
			SystemAccentColorDark2: r,
			SystemAccentColorLight3: r
		} : r)[n === "light" ? "SystemAccentColorLight3" : t === "Default" ? "SystemAccentColorDark1" : "SystemAccentColorDark2"];
		u(`AccentAcrylic${e}FillColor${t}Brush`, [
			i,
			.8,
			n === "dark" ? .8 : .9,
			i
		]);
	}
	for (let [e, t] of Object.entries(a)) l[e] = l[t];
	if (c) for (let e of i) l[e] = t("Canvas");
	return l;
}, l = /* @__PURE__ */ new Map(), u = (e, t = "light", n = s, r = !1) => {
	let i = `${t}:${JSON.stringify(n)}:${r}`;
	return l.has(i) || l.set(i, c(t, n, r)), l.get(i)?.[e];
}, d = (e) => !!a[e] || /^(?:Accent)?Acrylic(?:Background|InApp)FillColor(?:Default|DefaultInverse|Base)Brush$/.test(e) || e === "DesktopAcrylicTransparentBrush";
//#endregion
export { u as acrylicResource, a as acrylicResourceAliases, d as isAcrylicResource };

//# sourceMappingURL=acrylicResources.js.map