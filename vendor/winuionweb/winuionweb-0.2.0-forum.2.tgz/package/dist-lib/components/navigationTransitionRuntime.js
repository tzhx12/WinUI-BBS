import { createCommonStoryboards as e, resolveCommonStoryboards as t } from "./navigationTransitions/common.js";
import { createContinuumStoryboards as n, resolveContinuumStoryboards as r } from "./navigationTransitions/continuum.js";
import { createDrillInStoryboards as i } from "./navigationTransitions/drillIn.js";
import { createEntranceStoryboards as a, resolveEntranceStoryboards as o } from "./navigationTransitions/entrance.js";
import { createSlideStoryboards as s } from "./navigationTransitions/slide.js";
import { createSuppressStoryboards as c } from "./navigationTransitions/suppress.js";
//#region src/components/navigationTransitionRuntime.ts
var l = (t, r, o = !1) => {
	let l = t && typeof t == "object" ? t : {}, u = String(l.Type ?? (o ? "EntranceNavigationTransitionInfo" : "")), d = r === "Back", f;
	switch (u) {
		case "SuppressNavigationTransitionInfo": return c();
		case "EntranceNavigationTransitionInfo":
			f = a(d);
			break;
		case "SlideNavigationTransitionInfo":
			f = s(d, l);
			break;
		case "DrillInNavigationTransitionInfo":
			f = i(d);
			break;
		case "CommonNavigationTransitionInfo":
			f = e(d);
			break;
		case "ContinuumNavigationTransitionInfo":
			f = n(d);
			break;
		default: return null;
	}
	return {
		Type: u,
		...f,
		Info: l,
		IsBack: d,
		DisableHitTesting: u === "CommonNavigationTransitionInfo" || u === "SlideNavigationTransitionInfo" || u === "ContinuumNavigationTransitionInfo"
	};
}, u = (e, n, i) => {
	switch (e.Type) {
		case "EntranceNavigationTransitionInfo": return o(e, n, i);
		case "CommonNavigationTransitionInfo": return t(e, n, i);
		case "ContinuumNavigationTransitionInfo": return r(e, n, i);
		default: return [{
			Element: n,
			Storyboard: i ? e.Entrance : e.Exit
		}];
	}
};
//#endregion
export { l as getNavigationTransitionStoryboard, u as resolveNavigationPageStoryboards };

//# sourceMappingURL=navigationTransitionRuntime.js.map