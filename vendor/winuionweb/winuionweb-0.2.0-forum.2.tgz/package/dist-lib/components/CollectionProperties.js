import { Fragment as e, defineComponent as t, h as n } from "vue";
//#region src/components/CollectionProperties.ts
var r = (r) => t({
	name: `Collection.${r[0].toUpperCase()}${r.slice(1)}`,
	__collectionProperty: r,
	setup(t, { slots: r }) {
		return () => n(e, r.default?.());
	}
}), i = r("itemTemplate"), a = r("itemTemplateSelector"), o = r("itemsPanel"), s = r("items"), c = r("resources"), l = r("groupHeaderTemplate"), u = r("groupStyle"), d = r("groupStyleHeaderTemplate"), f = r("itemContainerStyle"), p = r("itemContainerStyleSelector"), m = r("itemContainerTransitions"), h = t({
	name: "Style",
	setup(t, { slots: r }) {
		return () => n(e, r.default?.());
	}
}), g = t({
	name: "Setter",
	setup(t, { slots: r }) {
		return () => n(e, r.default?.());
	}
}), _ = t({
	name: "DataTemplate",
	setup(t, { slots: r }) {
		return () => n(e, r.default?.());
	}
}), v = t({
	name: "DataTemplateSelector",
	setup(t, { slots: r }) {
		return () => n(e, r.default?.());
	}
}), y = t({
	name: "ItemsPanelTemplate",
	setup(t, { slots: r }) {
		return () => n(e, r.default?.());
	}
}), b = t({
	name: "ItemsStackPanel",
	setup(t, { slots: r }) {
		return () => n(e, r.default?.());
	}
}), x = t({
	name: "ItemsWrapGrid",
	setup() {
		return () => null;
	}
}), S = t({
	name: "ControlTemplate",
	setup(t, { slots: r }) {
		return () => n(e, r.default?.());
	}
}), C = t({
	name: "ScrollContentPresenter",
	setup() {
		return () => null;
	}
}), w = (r) => t({
	name: r,
	__layoutType: r,
	setup(t, { slots: r }) {
		return () => n(e, r.default?.());
	}
}), T = w("StackLayout"), E = w("UniformGridLayout"), D = w("LinedFlowLayout"), O = w("ActivityFeedLayout"), k = w("VariedImageSizeLayout"), A = t({
	name: "Collection.Layout",
	__collectionProperty: "layout",
	setup(t, { slots: r }) {
		return () => n(e, r.default?.());
	}
}), j = (e) => {
	let t = e.type;
	if (t?.__collectionProperty) return t.__collectionProperty;
	if (typeof e.type == "string") {
		if (e.type.endsWith(".Items")) return "items";
		if (e.type.endsWith(".Resources")) return "resources";
		if (e.type.endsWith(".ItemTemplate")) return "itemTemplate";
		if (e.type.endsWith(".ItemTemplateSelector")) return "itemTemplateSelector";
		if (e.type.endsWith(".ItemsPanel")) return "itemsPanel";
		if (e.type.endsWith(".GroupHeaderTemplate")) return "groupHeaderTemplate";
		if (e.type.endsWith(".GroupStyle")) return "groupStyle";
		if (e.type.endsWith(".HeaderTemplate") && e.type.startsWith("GroupStyle.")) return "groupStyleHeaderTemplate";
		if (e.type.endsWith(".Layout")) return "layout";
		if (e.type.endsWith(".ItemContainerStyle")) return "itemContainerStyle";
		if (e.type.endsWith(".ItemContainerStyleSelector")) return "itemContainerStyleSelector";
		if (e.type.endsWith(".ItemContainerTransitions")) return "itemContainerTransitions";
	}
}, M = (e) => {
	let t = e.find(Boolean);
	if (!t) return;
	let n = t.type, r = typeof n == "string" ? n : n?.__layoutType || n?.name || n?.__name || "", i = { ...t.props ?? {} };
	return r && (i.Type = r), i;
}, N = (e) => {
	if (Array.isArray(e.children)) return e.children;
	if (e.children && typeof e.children == "object") {
		let t = e.children.default;
		if (typeof t == "function") {
			let e = t();
			return Array.isArray(e) ? e : e ? [e] : [];
		}
	}
	return [];
}, P = (t) => (Array.isArray(t) ? t : [t]).flatMap((t) => {
	if (!t) return [];
	let n = t.type, r = typeof n == "string" ? n : n?.name || n?.__name || "";
	return t.type === e || /^(DataTemplate|ItemsPanelTemplate)$/i.test(r) ? P(N(t)) : [t];
}), F = (e) => P(N(e));
//#endregion
export { O as ActivityFeedLayout, l as CollectionGroupHeaderTemplate, u as CollectionGroupStyle, d as CollectionGroupStyleHeaderTemplate, f as CollectionItemContainerStyle, p as CollectionItemContainerStyleSelector, m as CollectionItemContainerTransitions, i as CollectionItemTemplate, a as CollectionItemTemplateSelector, s as CollectionItems, o as CollectionItemsPanel, A as CollectionLayout, c as CollectionResources, S as ControlTemplate, _ as DataTemplate, v as DataTemplateSelector, y as ItemsPanelTemplate, b as ItemsStackPanel, x as ItemsWrapGrid, D as LinedFlowLayout, C as ScrollContentPresenter, T as StackLayout, E as UniformGridLayout, k as VariedImageSizeLayout, g as XamlSetter, h as XamlStyle, j as getCollectionProperty, M as getLayoutDescriptor, F as getVNodeChildren };

//# sourceMappingURL=CollectionProperties.js.map