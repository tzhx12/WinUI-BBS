import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./AppBarToggleButton.vue_vue_type_script_setup_true_lang.js";
import { createBlock as n, openBlock as r } from "vue";
//#region src/components/AppBarToggleButton.vue
function i(e, t, i, a, o, s) {
	return r(), n(a.ButtonPresenter);
}
var a = /*#__PURE__*/ e(t, [["render", i], ["__file", "AppBarToggleButton.vue"]]);
//#endregion
export { a as default };

//# sourceMappingURL=AppBarToggleButton.vue.js.map