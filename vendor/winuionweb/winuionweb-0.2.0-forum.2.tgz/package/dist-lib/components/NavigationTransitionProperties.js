import { resolveXamlValue as e } from "./xamlRuntime.js";
import { Fragment as t, defineComponent as n } from "vue";
//#region src/components/NavigationTransitionProperties.ts
var r = (e, t) => n({
	name: e,
	__frameProperty: t,
	setup() {
		return () => null;
	}
}), i = r("Frame.ContentTransitions", "contentTransitions"), a = r("TransitionCollection"), o = r("NavigationThemeTransition.DefaultNavigationTransitionInfo"), s = Object.assign(r("NavigationThemeTransition"), { DefaultNavigationTransitionInfo: o }), c = r("EntranceNavigationTransitionInfo"), l = r("DrillInNavigationTransitionInfo"), u = r("SuppressNavigationTransitionInfo"), d = r("SlideNavigationTransitionInfo"), f = r("CommonNavigationTransitionInfo"), p = r("ContinuumNavigationTransitionInfo"), m = (e) => typeof e.type == "string" ? e.type : e.type.name ?? e.type.__name ?? "", h = (e) => Array.isArray(e.children) ? e.children : (e.children && typeof e.children == "object" ? e.children.default : void 0)?.() ?? [], g = (e) => e.flatMap((e) => e.type === t ? g(h(e)) : [e]), _ = (e) => e.type.__frameProperty === "contentTransitions" || m(e) === "Frame.ContentTransitions" ? "contentTransitions" : void 0, v = (t, n) => {
	let r = m(t);
	if (!r.endsWith("NavigationTransitionInfo")) return null;
	let i = { Type: r }, a = r === "SlideNavigationTransitionInfo" ? ["Effect"] : r === "CommonNavigationTransitionInfo" ? ["IsStaggeringEnabled"] : r === "ContinuumNavigationTransitionInfo" ? ["ExitElement"] : [];
	for (let r of a) {
		let a = e(t.props?.[r], n);
		a !== void 0 && (i[r] = a);
	}
	return r === "SlideNavigationTransitionInfo" && i.Effect === void 0 && (i.Effect = "FromBottom"), i;
}, y = (t, n, r) => {
	let i = g(t).find((e) => _(e) === "contentTransitions"), a = (i ? g(h(i)) : []).flatMap((e) => m(e) === "TransitionCollection" ? g(h(e)) : [e]).find((e) => m(e) === "NavigationThemeTransition");
	if (a) {
		let t = g(h(a)).find((e) => m(e) === "NavigationThemeTransition.DefaultNavigationTransitionInfo"), r = t ? g(h(t))[0] : void 0;
		return {
			Enabled: !0,
			DefaultNavigationTransitionInfo: r ? v(r, n) : e(a.props?.DefaultNavigationTransitionInfo, n) ?? null
		};
	}
	let o = e(r, n), s = (Array.isArray(o) ? o : o ? [o] : []).find((e) => e && typeof e == "object" && e.Type === "NavigationThemeTransition");
	return {
		Enabled: !!s,
		DefaultNavigationTransitionInfo: s?.DefaultNavigationTransitionInfo ?? null
	};
};
//#endregion
export { f as CommonNavigationTransitionInfo, p as ContinuumNavigationTransitionInfo, l as DrillInNavigationTransitionInfo, c as EntranceNavigationTransitionInfo, i as FrameContentTransitions, s as NavigationThemeTransition, d as SlideNavigationTransitionInfo, u as SuppressNavigationTransitionInfo, a as TransitionCollection, _ as getFrameProperty, y as readFrameNavigationTransition };

//# sourceMappingURL=NavigationTransitionProperties.js.map