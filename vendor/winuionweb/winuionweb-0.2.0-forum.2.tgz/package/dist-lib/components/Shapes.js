import { isSolidColorBrush as e } from "./brushCore.js";
import { normalizeXamlNodes as t, resolveXamlValue as n, updateXamlBinding as r, xamlColor as i, xamlNameScopeKey as a } from "./xamlRuntime.js";
import { frameworkLayoutStyle as o } from "./frameworkLayout.js";
import { brushProperty as s, isBrushProperty as c, useBrushProperty as l } from "./brushProperties.js";
import { isRadialGradientBrush as u, radialGradientPaint as d } from "./RadialGradientVisual.js";
import { Fragment as f, computed as p, defineComponent as m, getCurrentInstance as h, h as g, inject as ee, onBeforeUnmount as te, onMounted as ne, onUpdated as re, reactive as _, ref as v, unref as y, watch as b } from "vue";
//#region src/components/Shapes.ts
var x = (e, t = 0) => Number.isFinite(Number(e)) ? Number(e) : t, S = (e) => Array.isArray(e) ? e.flatMap((e) => typeof e == "object" && e ? [x(e.X), x(e.Y)] : [x(e)]) : String(e ?? "").trim().split(/[\s,]+/).filter(Boolean).map((e) => x(e)), C = (e) => {
	if (e && typeof e == "object" && !Array.isArray(e)) return [x(e.X), x(e.Y)];
	let t = S(e);
	return [t[0] ?? 0, t[1] ?? 0];
}, w = (e) => Array.isArray(e.children) ? e.children : e.children?.default?.() ?? [], T = (e) => m({
	name: e,
	__geometryProperty: !0,
	setup(e, { slots: t }) {
		return () => g(f, t.default?.() ?? []);
	}
}), E = T("GeometryGroup.Children"), D = (e, i) => m({
	name: e,
	__geometryKind: e,
	inheritAttrs: !1,
	props: Object.fromEntries(Object.entries(i).map(([e, t]) => [e, {
		type: [
			String,
			Number,
			Object,
			Array
		],
		default: t
	}])),
	setup(e, { slots: a, expose: o, emit: s }) {
		let c = h(), l = _({}), u = Object.fromEntries(Object.keys(i).map((t) => [t, p({
			get: () => t in l ? l[t] : n(e[t], c),
			set: (n) => {
				l[t] = n, r(e[t], n, c), s(`update:${t}`, n);
			}
		})]));
		for (let t of Object.keys(i)) b(() => n(e[t], c), () => {
			delete l[t];
		});
		return o(u), () => g(f, t(a.default?.() ?? [], c));
	}
}), O = Object.assign(D("GeometryGroup", { FillRule: "EvenOdd" }), { Children: E }), k = D("LineGeometry", {
	StartPoint: "0,0",
	EndPoint: "0,0"
}), A = D("EllipseGeometry", {
	Center: "0,0",
	RadiusX: 0,
	RadiusY: 0
}), j = D("RectangleGeometry", { Rect: "0,0,0,0" }), M = T("Path.Data"), N = (s, T) => {
	let E = {
		...T,
		Stroke: "",
		Fill: "",
		StrokeThickness: 1,
		Stretch: "None",
		Width: "",
		Height: "",
		MinWidth: 0,
		MinHeight: 0,
		MaxWidth: "",
		MaxHeight: "",
		Margin: 0,
		HorizontalAlignment: "Stretch",
		VerticalAlignment: "Stretch",
		Visibility: "Visible",
		Opacity: 1,
		IsHitTestVisible: !0,
		StrokeStartLineCap: "Flat",
		StrokeEndLineCap: "Flat",
		StrokeDashCap: "Flat",
		StrokeLineJoin: "Miter",
		StrokeMiterLimit: 10,
		StrokeDashArray: "",
		StrokeDashOffset: 0
	};
	return m({
		name: s,
		inheritAttrs: !1,
		props: Object.fromEntries(Object.entries(E).map(([e, t]) => [e, {
			type: [
				String,
				Number,
				Boolean,
				Object,
				Array
			],
			default: t
		}])),
		setup(m, { attrs: T, slots: D, expose: O, emit: k }) {
			let A = h(), j = ee(a, null), M = v(null), N = v(null), P = v({
				x: 0,
				y: 0,
				width: 0,
				height: 0
			}), F = v({
				width: 0,
				height: 0
			}), I = v(!1), L = _({}), R = (e) => n(e, A), ie = {
				Fill: l("Fill", () => m.Fill, () => D.default?.() ?? [], A),
				Stroke: l("Stroke", () => m.Stroke, () => D.default?.() ?? [], A)
			}, z = (e) => e in L ? L[e] : e === "Fill" || e === "Stroke" ? y(ie[e].value.value) : R(m[e]), B = (e) => x(z(e)), ae = Object.fromEntries(Object.keys(E).map((e) => [e, p({
				get: () => z(e),
				set: (t) => {
					L[e] = t, r(m[e], t, A), k(`update:${e}`, t);
				}
			})]));
			for (let e of Object.keys(E)) b(() => R(m[e]), () => {
				delete L[e];
			});
			let V = (e, t) => {
				let n = String(e.props?.["x:Name"] ?? e.props?.["data-xaml-ref"] ?? "");
				return n && j?.[n] ? j[n][t] : R(e.props?.[t]);
			}, H = (e) => e.map((e) => {
				if (!e || e.type === f) return e ? H(w(e)) : "";
				let t = e.type;
				if (t.__geometryKind === "GeometryGroup" || t.__geometryProperty) return H(w(e));
				if (t.__geometryKind === "LineGeometry") return `M ${C(V(e, "StartPoint")).join(",")} L ${C(V(e, "EndPoint")).join(",")}`;
				if (t.__geometryKind === "EllipseGeometry") {
					let [t, n] = C(V(e, "Center")), r = Math.max(0, x(V(e, "RadiusX"))), i = Math.max(0, x(V(e, "RadiusY")));
					return `M ${t - r},${n} A ${r},${i} 0 1 0 ${t + r},${n} A ${r},${i} 0 1 0 ${t - r},${n} Z`;
				}
				if (t.__geometryKind === "RectangleGeometry") {
					let [t = 0, n = 0, r = 0, i = 0] = S(V(e, "Rect"));
					return `M ${t},${n} h ${Math.max(0, r)} v ${Math.max(0, i)} h ${-Math.max(0, r)} Z`;
				}
				return "";
			}).filter(Boolean).join(" "), oe = p(() => {
				if (s === "Line") return `M ${B("X1")},${B("Y1")} L ${B("X2")},${B("Y2")}`;
				if (s === "Polyline") {
					let e = S(z("Points"));
					return e.length < 4 || e.length % 2 != 0 ? "" : e.reduce((t, n, r) => r % 2 == 0 ? t + `${r ? " L" : "M"} ${n},${e[r + 1]}` : t, "");
				}
				return z("Data") ? String(z("Data")).replace(/^\s*F[01]\s*/i, "") : H(D.default?.() ?? []);
			}), se = p(() => {
				if (s === "Polyline") return z("FillRule") === "Nonzero" ? "nonzero" : "evenodd";
				if (/^\s*F1\b/i.test(String(z("Data") ?? ""))) return "nonzero";
				let e = (t) => {
					for (let n of t) {
						if (n.type.__geometryKind === "GeometryGroup") return String(V(n, "FillRule") ?? "EvenOdd");
						let t = e(w(n));
						if (t) return t;
					}
					return "";
				};
				return e(D.default?.() ?? []) === "Nonzero" ? "nonzero" : "evenodd";
			}), U = (t) => {
				let n = z(t);
				return u(n) ? d(n, `win-shape-${A?.uid}-${t}`).paint : e(n) ? i(n.Color) : typeof n == "string" && i(n) || "none";
			}, W = p(() => U("Stroke") === "none" ? 0 : Math.abs(B("StrokeThickness"))), G = p(() => ({
				width: Math.max(0, P.value.x + P.value.width + W.value / 2),
				height: Math.max(0, P.value.y + P.value.height + W.value / 2)
			})), K = (e, t) => {
				let n = z(e);
				return n === "" || n == null || n === "Auto" ? t : Math.max(0, x(n));
			}, q = p(() => {
				let e = z("Stretch");
				if (e === "None") return;
				let t = I.value ? F.value.width : K("Width", G.value.width), n = I.value ? F.value.height : K("Height", G.value.height), r = W.value, i = Math.max(0, t - r), a = Math.max(0, n - r);
				if (i <= 1e-5 && (i = i > 0 ? i : r), a <= 1e-5 && (a = a > 0 ? a : r), i <= 0 || a <= 0) return;
				let o = P.value.width > 0 ? P.value.width : 1, s = P.value.height > 0 ? P.value.height : 1, c = i / o, l = a / s, u = 0, d = 0;
				return e === "Uniform" ? c > l ? (c = l, u = (i - o * c) / 2) : (l = c, d = (a - s * l) / 2) : e === "UniformToFill" && (c = l = Math.max(c, l)), {
					x: c,
					y: l,
					offsetX: r / 2 + u,
					offsetY: r / 2 + d
				};
			}), ce = p(() => {
				let e = q.value;
				return e ? `translate(${e.offsetX},${e.offsetY}) scale(${e.x},${e.y}) translate(${-P.value.x},${-P.value.y})` : void 0;
			}), J = p(() => {
				let e = q.value, t = (t, n) => e ? [(t - P.value.x) * e.x + e.offsetX, (n - P.value.y) * e.y + e.offsetY] : [t, n];
				return [t(B("X1"), B("Y1")), t(B("X2"), B("Y2"))];
			}), Y = () => {
				if (!N.value || typeof N.value.getBBox != "function") return;
				let e = s === "Line" ? {
					x: Math.min(B("X1"), B("X2")),
					y: Math.min(B("Y1"), B("Y2")),
					width: Math.abs(B("X2") - B("X1")),
					height: Math.abs(B("Y2") - B("Y1"))
				} : N.value.getBBox();
				[
					e.x,
					e.y,
					e.width,
					e.height
				].some((e) => !Number.isFinite(e)) || (P.value.x !== e.x || P.value.y !== e.y || P.value.width !== e.width || P.value.height !== e.height) && (P.value = {
					x: e.x,
					y: e.y,
					width: e.width,
					height: e.height
				});
			}, X;
			ne(() => {
				Y(), M.value && typeof ResizeObserver < "u" && (X = new ResizeObserver((e) => {
					let t = e[0]?.contentRect;
					t && ((F.value.width !== t.width || F.value.height !== t.height) && (F.value = {
						width: t.width,
						height: t.height
					}), I.value = !0);
				}), X.observe(M.value));
			}), re(Y), te(() => X?.disconnect()), O({
				...ae,
				Element: M,
				ActualWidth: p(() => F.value.width),
				ActualHeight: p(() => F.value.height)
			});
			let Z = (e) => `win-shape-${A?.uid}-${e}`, Q = (t, n) => {
				let r = z(t);
				if (r === "Flat") return null;
				let i = r === "Round" ? g("path", { d: "M 0,-.5 A .5,.5 0 0 1 0,.5 Z" }) : r === "Square" ? g("rect", {
					x: 0,
					y: -.5,
					width: .5,
					height: 1
				}) : g("polygon", { points: "0,-.5 .5,0 0,.5" }), a = z("Stroke");
				return g("marker", {
					id: Z(n),
					markerUnits: "strokeWidth",
					markerWidth: 1,
					markerHeight: 1,
					refX: 0,
					refY: 0,
					viewBox: "-.5 -.5 1 1",
					orient: "auto-start-reverse",
					overflow: "visible",
					fill: U("Stroke"),
					opacity: s !== "Line" && (e(a) || u(a)) ? a.Opacity : void 0
				}, [i]);
			}, $ = (e, t, n) => {
				if (e === "Flat") return null;
				let r = W.value / 2, i = [-n[1], n[0]], a = (e, r) => [t[0] + n[0] * e + i[0] * r, t[1] + n[1] * e + i[1] * r];
				return e === "Round" ? `M ${a(0, -r).join(",")} A ${r},${r} 0 0 1 ${a(0, r).join(",")} Z` : e === "Square" ? `M ${a(0, -r).join(",")} L ${a(r, -r).join(",")} L ${a(r, r).join(",")} L ${a(0, r).join(",")} Z` : `M ${a(0, -r).join(",")} L ${a(r, 0).join(",")} L ${a(0, r).join(",")} Z`;
			}, le = (e) => {
				let [t, n] = J.value, r = Math.hypot(n[0] - t[0], n[1] - t[1]), i = r ? [(n[0] - t[0]) / r, (n[1] - t[1]) / r] : [1, 0], a = [-i[1], i[0]], o = W.value / 2, s = (e, n = 0) => [t[0] + i[0] * e + a[0] * n, t[1] + i[1] * e + a[1] * n], c = e ?? [{
					first: 0,
					last: r,
					startCap: z("StrokeStartLineCap"),
					endCap: z("StrokeEndLineCap")
				}], l = [], u = (e, t, n) => {
					let r = s(t);
					if (e === "Square") l.push(s(t + n * o, -o), s(t + n * o, o));
					else if (e === "Triangle") l.push(s(t + n * o));
					else if (e === "Round") for (let e of [
						[o, 0],
						[-o, 0],
						[0, o],
						[0, -o]
					]) (e[0] * i[0] + e[1] * i[1]) * n >= -1e-8 && l.push([r[0] + e[0], r[1] + e[1]]);
				};
				for (let e of c) l.push(s(e.first, -o), s(e.first, o), s(e.last, -o), s(e.last, o)), u(e.startCap, e.first, -1), u(e.endCap, e.last, 1);
				if (!l.length) return {
					X: t[0],
					Y: t[1],
					Width: 0,
					Height: 0
				};
				let d = l.map((e) => e[0]), f = l.map((e) => e[1]), p = Math.min(...d), m = Math.min(...f);
				return {
					X: p,
					Y: m,
					Width: Math.max(...d) - p,
					Height: Math.max(...f) - m
				};
			}, ue = (e) => {
				let [t, n] = J.value, r = Math.hypot(n[0] - t[0], n[1] - t[1]), i = e.length % 2 ? [...e, ...e] : e, a = i.reduce((e, t) => e + t, 0);
				if (!r || !a) return null;
				let o = (e) => [t[0] + (n[0] - t[0]) * e / r, t[1] + (n[1] - t[1]) * e / r], s = [(n[0] - t[0]) / r, (n[1] - t[1]) / r], c = (B("StrokeDashOffset") * W.value % a + a) % a, l = 0;
				for (; c >= i[l] && l < i.length - 1;) c -= i[l], l++;
				let u = -c, d = [], f = [], p = [];
				for (; u < r;) {
					let e = u + i[l];
					if (l % 2 == 0 && e >= 0) {
						let t = Math.max(0, u), n = Math.min(r, e);
						f.push(`M ${o(t).join(",")} L ${o(n).join(",")}`);
						let i = z(t === 0 ? "StrokeStartLineCap" : "StrokeDashCap"), a = z(n === r ? "StrokeEndLineCap" : "StrokeDashCap");
						p.push({
							first: t,
							last: n,
							startCap: i,
							endCap: a
						}), d.push($(i, o(t), [-s[0], -s[1]]), $(a, o(n), s));
					}
					u = e, l = (l + 1) % i.length;
				}
				return {
					data: f.join(" "),
					caps: d,
					intervals: p
				};
			};
			return () => {
				let n = S(z("StrokeDashArray")).map((e) => Math.max(0, e) * W.value), r = (t) => {
					let n = z(t);
					return e(n) || u(n) ? n.Opacity : void 0;
				}, i = s === "Line" && n.length ? ue(n) : null, a = s === "Line" ? le(i?.intervals) : void 0, l = ["Fill", "Stroke"].flatMap((e) => {
					let t = z(e);
					return u(t) ? [d(t, `win-shape-${A?.uid}-${e}`, e === "Stroke" ? a : void 0).definition] : [];
				}), f = s === "Line" ? i?.data ?? `M ${J.value[0].join(",")} L ${J.value[1].join(",")}` : oe.value, p = i?.caps ?? (s === "Line" ? (() => {
					let [e, t] = J.value, n = Math.hypot(t[0] - e[0], t[1] - e[1]), r = n ? [(t[0] - e[0]) / n, (t[1] - e[1]) / n] : [1, 0];
					return [$(z("StrokeStartLineCap"), e, [-r[0], -r[1]]), $(z("StrokeEndLineCap"), t, r)];
				})() : []), m = s === "Line" ? (() => {
					let [e, t] = J.value, n = Math.hypot(t[0] - e[0], t[1] - e[1]), r = n ? [(t[0] - e[0]) / n, (t[1] - e[1]) / n] : [1, 0], a = W.value / 2, o = (t, n) => [e[0] + r[0] * t - r[1] * n, e[1] + r[1] * t + r[0] * n];
					return [...(i?.intervals ?? [{
						first: 0,
						last: n
					}]).map((e) => `M ${o(e.first, -a).join(",")} L ${o(e.last, -a).join(",")} L ${o(e.last, a).join(",")} L ${o(e.first, a).join(",")} Z`), ...p.filter(Boolean)].join(" ");
				})() : "", h = s === "Line" ? { opacity: x(z("Opacity"), 1) * (r("Stroke") ?? 1) } : {};
				return g("svg", {
					...T,
					ref: M,
					class: [T.class, `win-shape win-${s.toLowerCase()}`],
					"data-stack-panel-width": z("Width") === "" ? "Auto" : String(z("Width")),
					"data-stack-panel-horizontal-alignment": z("HorizontalAlignment"),
					width: K("Width", G.value.width),
					height: K("Height", G.value.height),
					style: [T.style, {
						display: "block",
						flex: "0 0 auto",
						overflow: "visible",
						...o(Object.fromEntries(Object.keys(E).map((e) => [e, z(e)])), A),
						...h,
						...z("Visibility") === !1 ? { display: "none" } : {},
						...z("IsHitTestVisible") === !1 || z("IsHitTestVisible") === "False" ? { pointerEvents: "none" } : {},
						...z("Stretch") === "UniformToFill" || z("Width") !== "" && z("Height") !== "" ? { overflow: "hidden" } : {}
					}],
					"aria-hidden": !0
				}, [g("defs", null, [
					...s === "Line" ? [g("path", {
						ref: N,
						class: "win-shape-centerline",
						d: f
					})] : [Q("StrokeStartLineCap", "start"), Q("StrokeEndLineCap", "end")],
					...l,
					...t((D.default?.() ?? []).filter((e) => !c(e)), A)
				]), g("path", {
					ref: s === "Line" ? void 0 : N,
					class: "win-shape-paint",
					d: s === "Line" ? m : f,
					transform: s === "Line" ? void 0 : ce.value,
					stroke: s === "Line" ? "none" : U("Stroke"),
					fill: U(s === "Line" ? "Stroke" : "Fill"),
					"stroke-width": W.value,
					"stroke-opacity": s === "Line" ? void 0 : r("Stroke"),
					"fill-opacity": s === "Line" ? void 0 : r("Fill"),
					"stroke-linejoin": String(z("StrokeLineJoin")).toLowerCase(),
					"stroke-miterlimit": B("StrokeMiterLimit"),
					"stroke-linecap": n.length && !i ? {
						Round: "round",
						Square: "square"
					}[String(z("StrokeDashCap"))] ?? "butt" : "butt",
					"stroke-dasharray": n.length && !i ? n.join(" ") : void 0,
					"stroke-dashoffset": B("StrokeDashOffset") * W.value,
					"marker-start": s === "Line" || z("StrokeStartLineCap") === "Flat" ? void 0 : `url(#${Z("start")})`,
					"marker-end": s === "Line" || z("StrokeEndLineCap") === "Flat" ? void 0 : `url(#${Z("end")})`,
					"vector-effect": "non-scaling-stroke",
					"fill-rule": s === "Line" ? "nonzero" : se.value
				})]);
			};
		}
	});
}, P = Object.assign(N("Line", {
	X1: 0,
	X2: 0,
	Y1: 0,
	Y2: 0
}), {
	Fill: s("Line", "Fill"),
	Stroke: s("Line", "Stroke")
}), F = Object.assign(N("Polyline", {
	Points: "",
	FillRule: "EvenOdd"
}), {
	Fill: s("Polyline", "Fill"),
	Stroke: s("Polyline", "Stroke")
}), I = Object.assign(N("Path", { Data: "" }), {
	Data: M,
	Fill: s("Path", "Fill"),
	Stroke: s("Path", "Stroke")
});
//#endregion
export { A as EllipseGeometry, O as GeometryGroup, P as Line, k as LineGeometry, I as Path, F as Polyline, j as RectangleGeometry };

//# sourceMappingURL=Shapes.js.map