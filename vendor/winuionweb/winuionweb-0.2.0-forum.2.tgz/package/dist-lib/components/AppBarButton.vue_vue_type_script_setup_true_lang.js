import { cssLength as e, xamlThickness as t } from "./layout.js";
import { normalizeXamlNodes as n, resolveXamlHandler as r, resolveXamlValue as ee, updateXamlBinding as te, xamlControlIdentityKey as ne, xamlScopeKey as re } from "./xamlRuntime.js";
import { frameworkLayoutStyle as ie } from "./frameworkLayout.js";
import ae from "./BitmapIcon.vue.js";
import oe from "./SymbolIcon.vue.js";
import se from "./PathIcon.vue.js";
import ce from "./Viewbox.vue.js";
import { appBarBoolean as i, appBarProperty as a, appBarToggleContextKey as le, commandBarContextKey as ue } from "./appBarRuntime.js";
/* empty css                 */
import { useUICommand as de } from "./uiCommandRuntime.js";
import fe from "./FontIcon.vue.js";
import { Comment as pe, Fragment as o, Text as me, cloneVNode as he, computed as s, defineComponent as c, getCurrentInstance as ge, h as l, inject as _e, isVNode as ve, onBeforeUnmount as ye, onMounted as be, provide as xe, ref as u, shallowReactive as Se, unref as Ce, useAttrs as we, useSlots as Te, watch as Ee } from "vue";
//#region src/components/AppBarButton.vue?vue&type=script&setup=true&lang.ts
var d = a("AppBarButton", "Flyout"), f = a("AppBarButton", "Icon"), p = a("AppBarButton", "Content"), De = a("AppBarButton", "KeyboardAccelerators"), Oe = /*@__PURE__*/ c({
	Flyout: d,
	Icon: f,
	Content: p,
	KeyboardAccelerators: De,
	name: "AppBarButton",
	inheritAttrs: !1,
	__name: "AppBarButton",
	props: {
		Label: {
			type: String,
			default: void 0
		},
		Icon: {
			type: null,
			default: void 0
		},
		Content: {
			type: null,
			default: void 0
		},
		Command: {
			type: null,
			default: void 0
		},
		CommandParameter: {
			type: null,
			default: void 0
		},
		Flyout: {
			type: null,
			default: void 0
		},
		IsCompact: {
			type: [Boolean, String],
			default: void 0
		},
		LabelPosition: {
			type: String,
			default: "Default"
		},
		DynamicOverflowOrder: {
			type: [Number, String],
			default: 0
		},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		IsTabStop: {
			type: [Boolean, String],
			default: !0
		},
		Visibility: {
			type: String,
			default: "Visible"
		},
		AllowFocusOnInteraction: {
			type: [Boolean, String],
			default: void 0
		},
		AllowFocusWhenDisabled: {
			type: [Boolean, String],
			default: !1
		},
		KeyboardAccelerators: {
			type: null,
			default: void 0
		},
		KeyboardAcceleratorTextOverride: {
			type: String,
			default: ""
		},
		KeyboardAcceleratorPlacementMode: {
			type: String,
			default: "Hidden"
		},
		Background: {
			type: null,
			default: void 0
		},
		Foreground: {
			type: null,
			default: void 0
		},
		BorderBrush: {
			type: null,
			default: void 0
		},
		BorderThickness: {
			type: [Number, String],
			default: void 0
		},
		CornerRadius: {
			type: [Number, String],
			default: void 0
		},
		Padding: {
			type: [Number, String],
			default: void 0
		},
		Margin: {
			type: [Number, String],
			default: void 0
		},
		Width: {
			type: [Number, String],
			default: void 0
		},
		Height: {
			type: [Number, String],
			default: void 0
		},
		MinWidth: {
			type: [Number, String],
			default: 0
		},
		MinHeight: {
			type: [Number, String],
			default: 0
		},
		MaxWidth: {
			type: [Number, String],
			default: void 0
		},
		MaxHeight: {
			type: [Number, String],
			default: void 0
		},
		FontFamily: {
			type: String,
			default: void 0
		},
		FontWeight: {
			type: [Number, String],
			default: void 0
		},
		FontSize: {
			type: [Number, String],
			default: void 0
		},
		HorizontalAlignment: {
			type: String,
			default: "Left"
		},
		VerticalAlignment: {
			type: String,
			default: "Top"
		},
		HorizontalContentAlignment: {
			type: String,
			default: "Center"
		},
		VerticalContentAlignment: {
			type: String,
			default: "Center"
		},
		FlowDirection: {
			type: String,
			default: "LeftToRight"
		},
		Style: {
			type: null,
			default: void 0
		},
		"AutomationProperties.Name": {
			type: String,
			default: ""
		},
		"ToolTipService.ToolTip": {
			type: null,
			default: void 0
		}
	},
	emits: /* @__PURE__ */ "Click,PointerEntered,PointerExited,PointerPressed,PointerReleased,PointerMoved,PointerCanceled,PointerCaptureLost,KeyDown,KeyUp,GotFocus,LostFocus,update:Label,update:Icon,update:Content,update:Command,update:CommandParameter,update:Flyout,update:IsCompact,update:LabelPosition,update:DynamicOverflowOrder,update:IsEnabled,update:IsTabStop,update:Visibility,update:AllowFocusOnInteraction,update:AllowFocusWhenDisabled,update:KeyboardAccelerators,update:KeyboardAcceleratorTextOverride,update:KeyboardAcceleratorPlacementMode,update:Background,update:Foreground,update:BorderBrush,update:BorderThickness,update:CornerRadius,update:Padding,update:Margin,update:Width,update:Height,update:MinWidth,update:MinHeight,update:MaxWidth,update:MaxHeight,update:FontFamily,update:FontWeight,update:FontSize,update:HorizontalAlignment,update:VerticalAlignment,update:HorizontalContentAlignment,update:VerticalContentAlignment,update:FlowDirection,update:Style,update:AutomationProperties.Name,update:ToolTipService.ToolTip".split(","),
	setup(a, { expose: Oe, emit: ke }) {
		let m = a, h = ke, g = we(), Ae = Te(), _ = ge(), v = _e(ue, null), y = _e(le, null), b = u(null), x = u(null), S = Se({}), C = (e) => ee(e, _), w = (e) => e in S ? S[e] : C(m[e]), T = (e, t) => {
			S[e] = t, te(m[e], t, _), h(`update:${e}`, t);
		};
		for (let e of Object.keys(m)) Ee(() => C(m[e]), () => {
			delete S[e];
		});
		let E = de(() => w("Command")), je = s(() => String(w("Label") ?? E.value?.Label ?? "")), D = s(() => i(w("IsEnabled")) && v?.isEnabled?.value !== !1 && (E.value?.CanExecute?.(w("CommandParameter")) ?? !0)), Me = s(() => w("Visibility") !== "Collapsed"), Ne = s(() => i(w("IsTabStop"))), O = s(() => v?.isInOverflow.value ?? !1), k = s(() => v?.isInFlyout?.value ?? !1), Pe = s(() => w("AllowFocusOnInteraction") === void 0 ? k.value : i(w("AllowFocusOnInteraction"))), A = s(() => w("IsCompact") === void 0 ? v?.compact.value ?? !1 : i(w("IsCompact"))), j = s(() => {
			if (w("LabelPosition") !== "Default") return w("LabelPosition");
			let e = v?.defaultLabelPosition.value;
			return e === "Right" || e === "Collapsed" ? e : "Bottom";
		}), Fe = s(() => v?.hasIcons.value ?? !1), M = s(() => v?.hasToggleButtons.value ?? !1), N = s(() => y ? y.checked.value : !1), Ie = s(() => ({
			ContentWidth: O.value ? 16 : "",
			ContentHorizontalAlignment: O.value || j.value === "Right" ? "Left" : "Stretch",
			ContentVerticalAlignment: O.value ? "Center" : "Top",
			ContentMargin: O.value ? M.value ? "38,0,12,0" : "12,0,12,0" : j.value === "Right" ? "12,16,0,10" : "0,16,0,2"
		}));
		xe(re, {
			..._e(re, {}),
			TemplateSettings: Ie
		}), xe(le, null);
		let P = u(!1), F = u(!1), I = u(!1), L = u(null), Le = s(() => F.value || I.value), R = u(!1), Re = s(() => String(w("AutomationProperties.Name") || "")), z = (e) => Array.isArray(e.children) ? e.children : e.children?.default?.() ?? [], B = (e) => e.flatMap((e) => e.type === o ? B(z(e)) : e.type === pe || e.type === me && !String(e.children ?? "").trim() ? [] : [e]), V = s(() => {
			let e = {
				Content: [],
				Icon: [],
				Flyout: [],
				KeyboardAccelerators: []
			};
			for (let t of B(Ae.default?.() ?? [])) {
				let n = t.type, r = n?.__appBarButtonProperty ?? (n?.__buttonProperty === "flyout" ? "Flyout" : n?.__buttonProperty === "content" ? "Content" : void 0);
				r && r in e ? e[r].push(...B(z(t))) : e.Content.push(t);
			}
			return e;
		}), H = (e) => Array.isArray(e) ? e.filter(ve) : ve(e) ? [e] : [], U = s(() => w("Icon") ?? E.value?.IconSource), W = s(() => !("Content" in S) && V.value.Content.length ? V.value.Content : H(w("Content"))), G = s(() => !("Icon" in S) && V.value.Icon.length ? V.value.Icon : H(U.value)), K = s(() => !("Flyout" in S) && V.value.Flyout.length ? V.value.Flyout : H(w("Flyout"))), q = s(() => {
			let e = w("Flyout");
			return e && typeof e.ShowAt == "function" ? e : x.value;
		}), J = s(() => K.value.length > 0 || !!q.value), ze = s(() => K.value.some((e) => {
			let t = e.type;
			return (t.name ?? t.__name) === "MenuFlyout";
		})), Be = s(() => {
			if (!("KeyboardAccelerators" in S) && V.value.KeyboardAccelerators.length) return V.value.KeyboardAccelerators.map((e) => Object.fromEntries(Object.entries(e.props ?? {}).map(([e, t]) => [e, C(t)])));
			let e = w("KeyboardAccelerators") ?? E.value?.KeyboardAccelerators;
			return Array.isArray(e) ? e : [];
		}), Ve = (e) => Array.isArray(e.Modifiers) ? e.Modifiers.map(String) : String(e.Modifiers ?? "").split(",").map((e) => e.trim()).filter(Boolean), He = (e) => ({
			Number0: "0",
			Number1: "1",
			Number2: "2",
			Number3: "3",
			Number4: "4",
			Number5: "5",
			Number6: "6",
			Number7: "7",
			Number8: "8",
			Number9: "9",
			Space: " ",
			Menu: "Alt",
			Esc: "Escape",
			Del: "Delete",
			Add: "+",
			Subtract: "-",
			Multiply: "*",
			Divide: "/",
			Decimal: "."
		})[String(e)] ?? String(e ?? ""), Ue = s(() => {
			if (w("KeyboardAcceleratorTextOverride")) return String(w("KeyboardAcceleratorTextOverride"));
			let e = Be.value[0];
			if (!e) return "";
			let t = Ve(e).map((e) => e === "Control" ? "Ctrl" : e === "Menu" ? "Alt" : e === "Windows" ? "Win" : e), n = He(e.Key);
			return [...t, n === " " ? "Space" : n.toUpperCase()].filter(Boolean).join("+");
		}), We = s(() => w("ToolTipService.ToolTip") ?? E.value?.Description ?? (A.value || j.value === "Collapsed" || k.value ? je.value : void 0)), Ge = s(() => {
			let e = Object.fromEntries(Object.entries(g).filter(([e]) => !/^(Click|Checked|Unchecked|Indeterminate|PointerEntered|PointerExited|PointerPressed|PointerReleased|PointerMoved|PointerCanceled|PointerCaptureLost|KeyDown|KeyUp|GotFocus|LostFocus|x:Name)$/.test(e)));
			return We.value && (e["tooltipservice.tooltip"] = We.value), e;
		}), Ke = c({
			name: "AppBarButtonContentPresenter",
			setup() {
				return () => {
					if (W.value.length) return l(o, n(W.value, _));
					let e = w("Content");
					if (e != null && !ve(e)) return l("span", { class: "appbar-button-content" }, typeof e == "object" ? "" : String(e));
					if (G.value.length) return l(o, n(G.value, _));
					let t = U.value;
					if (typeof t == "string" || typeof t == "number") return l(oe, {
						Symbol: t,
						FontSize: 20
					});
					if (t && typeof t == "object") {
						let e = t;
						if ("Symbol" in e) return l(oe, {
							...e,
							FontSize: e.FontSize ?? 20
						});
						if ("Glyph" in e) return l(fe, {
							...e,
							FontSize: e.FontSize ?? 20
						});
						if ("UriSource" in e) return l(ae, e);
						if ("Data" in e) return l(se, e);
					}
					return null;
				};
			}
		}), qe = c({
			name: "AppBarButtonFlyoutPresenter",
			setup() {
				return () => l(o, n(K.value, _).map((e) => he(e, {
					ref: (e) => {
						x.value = e;
					},
					onOpened: () => {
						R.value = !0;
					},
					onClosed: () => {
						R.value = !1;
					}
				}, !0)));
			}
		}), Je = s(() => O.value ? `Overflow${M.value ? "WithToggleButtons" : ""}${Fe.value ? M.value ? "AndMenuIcons" : "WithMenuIcons" : ""}` : j.value === "Right" ? "LabelOnRight" : j.value === "Collapsed" ? "LabelCollapsed" : A.value ? "Compact" : "FullSize"), Ye = s(() => {
			let e = O.value ? "Overflow" : "", t = D.value ? Le.value ? "Pressed" : R.value ? "SubMenuOpened" : P.value ? "PointerOver" : "Normal" : "Disabled", n = y && N.value !== !1 ? "Checked" : "";
			return `${e}${n}${n && t === "Normal" ? "" : t}`;
		}), Xe = s(() => ({
			compact: A.value && j.value === "Bottom" && !O.value,
			"label-right": j.value === "Right" && !O.value,
			"label-collapsed": j.value === "Collapsed" && !O.value,
			"is-overflow": O.value,
			"is-in-commandbar-flyout": k.value,
			"overflow-with-icons": O.value && Fe.value,
			"overflow-with-toggles": O.value && M.value,
			"pointer-over": P.value && D.value,
			pressed: Le.value && D.value,
			"submenu-opened": R.value && D.value,
			"has-flyout": J.value,
			"win-appbar-toggle-button": !!y,
			"appbar-toggle-button-checked": !!y && N.value !== !1,
			"appbar-toggle-button-indeterminate": !!y && N.value === null
		})), Ze = s(() => {
			let n = ie(Object.fromEntries(Object.keys(m).map((e) => [e, w(e)])), _);
			for (let e of [
				"background",
				"borderColor",
				"borderWidth",
				"padding"
			]) delete n[e];
			return {
				...n,
				margin: t(w("Margin")) || void 0,
				width: e(w("Width")) || void 0,
				height: e(w("Height")) || void 0,
				minWidth: e(w("MinWidth")) || void 0,
				minHeight: e(w("MinHeight")) || void 0,
				maxWidth: e(w("MaxWidth")) || void 0,
				maxHeight: e(w("MaxHeight")) || void 0,
				"--AppBarButtonBackground": w("Background") || void 0,
				"--AppBarButtonForeground": w("Foreground") || void 0,
				"--AppBarButtonBorderBrush": w("BorderBrush") || void 0,
				"--AppBarButtonBorderThickness": t(w("BorderThickness")) || void 0,
				"--AppBarButtonCornerRadius": e(w("CornerRadius")) || void 0,
				fontFamily: w("FontFamily") || void 0,
				fontWeight: w("FontWeight") === "Normal" ? "400" : w("FontWeight") || void 0,
				fontSize: e(w("FontSize")) || void 0,
				direction: w("FlowDirection") === "RightToLeft" ? "rtl" : "ltr",
				justifySelf: O.value && !_?.vnode.props?.HorizontalAlignment ? "stretch" : n.justifySelf
			};
		}), Qe = Object.fromEntries(Object.keys(m).map((e) => [e, s({
			get: () => w(e),
			set: (t) => T(e, t)
		})])), $e = {
			...Qe,
			[ne]: !0,
			Name: s(() => String(C(g["data-xaml-ref"] ?? g["x:Name"] ?? g.Name ?? ""))),
			IsInOverflow: O,
			Label: s({
				get: () => je.value,
				set: (e) => T("Label", e)
			}),
			IsEnabled: s({
				get: () => D.value,
				set: (e) => T("IsEnabled", e)
			}),
			ActualWidth: s(() => b.value?.getBoundingClientRect().width ?? 0),
			ActualHeight: s(() => b.value?.getBoundingClientRect().height ?? 0),
			Focus: () => D.value || i(w("AllowFocusWhenDisabled")) ? (b.value?.focus(), !0) : !1,
			$el: b
		}, et = new Proxy($e, {
			get: (e, t) => Ce(Reflect.get(e, t)),
			set: (e, t, n) => {
				let r = Reflect.get(e, t);
				return r && typeof r == "object" && "value" in r && (r.value = n), !0;
			}
		}), Y = () => y?.sender() ?? et, tt = (e) => ({
			OriginalSource: Y(),
			Handled: !1,
			OriginalEvent: e
		}), X = (e, t) => {
			let n = _?.vnode.props?.[`on${e}`];
			if (n) for (let e of Array.isArray(n) ? n : [n]) typeof e == "function" && e(Y(), t);
			else h(e, Y(), t);
			g[e] !== void 0 && !n && r(g[e], _)?.(Y(), t);
		}, Z = (e, t) => {
			let n = tt(t);
			return t instanceof PointerEvent && (n.Pointer = {
				PointerId: t.pointerId,
				PointerDeviceType: t.pointerType === "touch" ? "Touch" : t.pointerType === "pen" ? "Pen" : "Mouse",
				IsInContact: t.buttons !== 0
			}, n.GetCurrentPoint = (e) => {
				let n = (e instanceof HTMLElement ? e : e?.$el)?.getBoundingClientRect();
				return {
					Position: {
						X: t.clientX - (n?.left ?? 0),
						Y: t.clientY - (n?.top ?? 0)
					},
					PointerId: t.pointerId,
					IsInContact: t.buttons !== 0,
					Properties: {
						IsLeftButtonPressed: (t.buttons & 1) != 0,
						IsRightButtonPressed: (t.buttons & 2) != 0
					}
				};
			}), t instanceof KeyboardEvent && (n.Key = t.key === " " ? "Space" : t.key, n.OriginalKey = n.Key, n.KeyStatus = {
				IsKeyReleased: t.type === "keyup",
				RepeatCount: t.repeat ? 2 : 1
			}), X(e, n), n.Handled && (t.preventDefault(), t.stopPropagation()), n;
		}, nt = (e) => {
			if (!D.value || !Me.value) return;
			y?.toggle(e);
			let t = tt(e);
			X("Click", t), t.Handled && e.stopPropagation(), E.value?.Execute?.(w("CommandParameter")), J.value && b.value ? q.value?.IsOpen || R.value ? q.value?.Hide?.() : q.value?.ShowAt?.(b.value) : v?.invokeCommand ? v.invokeCommand(Y(), t) : O.value && v?.closeOverflow();
		}, rt = (e) => {
			if (Q(), e.detail > 0 && b.value) {
				let t = document.elementFromPoint(e.clientX, e.clientY);
				if (!t || !b.value.contains(t)) return;
			}
			nt(e);
		}, Q = () => {
			F.value = !1, I.value = !1, L.value = null;
		}, $ = () => {
			Q(), P.value = !1;
		}, it = (e) => {
			D.value && (P.value = e.pointerType !== "touch", L.value === e.pointerId && e.buttons === 1 && (F.value = !0), Z("PointerEntered", e));
		}, at = (e) => {
			P.value = !1, F.value = !1, Z("PointerExited", e);
		}, ot = (e) => {
			if (D.value) {
				if (L.value === e.pointerId && e.buttons === 1) {
					let t = document.elementFromPoint(e.clientX, e.clientY);
					F.value = !!t && !!b.value?.contains(t), P.value = e.pointerType !== "touch" && F.value;
				}
				Z("PointerMoved", e);
			}
		}, st = (e) => {
			Q(), D.value && Z("PointerReleased", e);
		}, ct = (e) => {
			$(), Z("PointerCanceled", e);
		}, lt = (e) => {
			Q(), Z("PointerCaptureLost", e);
		}, ut = (e) => Z("GotFocus", e), dt = (e) => {
			Q(), Z("LostFocus", e);
		}, ft = (e) => {
			if (!(!D.value || e.button !== 0)) {
				if (L.value = e.pointerId, F.value = !0, P.value = e.pointerType !== "touch", Z("PointerPressed", e).Handled) {
					Q();
					return;
				}
				try {
					b.value?.setPointerCapture(e.pointerId);
				} catch {}
				Pe.value || e.preventDefault();
			}
		}, pt = (e) => {
			Z("KeyDown", e).Handled || ((e.key === " " || e.key === "Enter") && (I.value = !0), J.value && (e.key === "ArrowDown" || O.value && e.key === "ArrowRight") && (e.preventDefault(), b.value && q.value?.ShowAt?.(b.value)), e.key === "Escape" && R.value && (e.preventDefault(), q.value?.Hide?.(), b.value?.focus()));
		}, mt = (e) => {
			I.value = !1, Z("KeyUp", e);
		}, ht = (e) => {
			!D.value || !Me.value || e.defaultPrevented || e.repeat || Be.value.some((t) => {
				if (t.IsEnabled !== void 0 && !i(t.IsEnabled)) return !1;
				let n = Ve(t);
				return (e.key.toLowerCase() === He(t.Key).toLowerCase() || t.Key === "Add" && e.code === "NumpadAdd" || t.Key === "Subtract" && e.code === "NumpadSubtract") && e.ctrlKey === n.includes("Control") && e.shiftKey === n.includes("Shift") && e.altKey === (n.includes("Menu") || n.includes("Alt")) && e.metaKey === n.includes("Windows");
			}) && (e.preventDefault(), b.value?.click());
		}, gt = () => {
			$(), q.value?.Hide?.();
		};
		Ee(D, (e) => {
			e || ($(), q.value?.Hide?.());
		}), be(() => {
			document.addEventListener("pointerup", Q, !0), document.addEventListener("pointercancel", $, !0), document.addEventListener("keydown", ht), window.addEventListener("blur", gt);
		}), ye(() => {
			document.removeEventListener("pointerup", Q, !0), document.removeEventListener("pointercancel", $, !0), document.removeEventListener("keydown", ht), window.removeEventListener("blur", gt), q.value?.Hide?.();
		}), Oe(et);
		let _t = {
			AppBarButtonFlyout: d,
			AppBarButtonIcon: f,
			AppBarButtonContent: p,
			AppBarButtonKeyboardAccelerators: De,
			props: m,
			emit: h,
			attrs: g,
			slots: Ae,
			instance: _,
			barContext: v,
			toggleContext: y,
			buttonRef: b,
			structuralFlyout: x,
			overrides: S,
			resolve: C,
			value: w,
			setValue: T,
			command: E,
			label: je,
			enabled: D,
			visible: Me,
			isTabStop: Ne,
			inOverflow: O,
			inFlyout: k,
			allowFocusOnInteraction: Pe,
			compact: A,
			labelPosition: j,
			hasMenuIcons: Fe,
			hasToggleButtons: M,
			checked: N,
			templateSettings: Ie,
			hovered: P,
			pointerPressed: F,
			keyboardPressed: I,
			pointerId: L,
			pressed: Le,
			flyoutOpen: R,
			automationName: Re,
			childNodes: z,
			flatten: B,
			declarations: V,
			asNodes: H,
			icon: U,
			contentNodes: W,
			iconNodes: G,
			flyoutNodes: K,
			flyout: q,
			hasFlyout: J,
			flyoutIsMenu: ze,
			acceleratorObjects: Be,
			modifiersFor: Ve,
			keyName: He,
			acceleratorText: Ue,
			toolTip: We,
			buttonAttrs: Ge,
			ContentOutlet: Ke,
			FlyoutOutlet: qe,
			applicationViewState: Je,
			commonState: Ye,
			buttonClasses: Xe,
			buttonStyle: Ze,
			exposedProperties: Qe,
			publicProperties: $e,
			eventSender: et,
			sender: Y,
			routedArgs: tt,
			raise: X,
			dispatchInput: Z,
			invoke: nt,
			onClick: rt,
			clearPressed: Q,
			clearPointerState: $,
			onPointerEnter: it,
			onPointerLeave: at,
			onPointerMove: ot,
			onPointerUp: st,
			onPointerCancel: ct,
			onCaptureLost: lt,
			onFocus: ut,
			onBlur: dt,
			onPointerDown: ft,
			onButtonKeyDown: pt,
			onButtonKeyUp: mt,
			onAccelerator: ht,
			onWindowBlur: gt,
			Viewbox: ce
		};
		return Object.defineProperty(_t, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), _t;
	}
});
//#endregion
export { p as AppBarButtonContent, d as AppBarButtonFlyout, f as AppBarButtonIcon, De as AppBarButtonKeyboardAccelerators, Oe as default };

//# sourceMappingURL=AppBarButton.vue_vue_type_script_setup_true_lang.js.map