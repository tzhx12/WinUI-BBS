//#region src/components/tabViewNativeDragBridge.ts
var e = Symbol.for("WinUI.TabView.NativeDragBridge"), t = Symbol.for("WinUI.TabView.NativeDropHandled");
//#endregion
export { e as tabViewNativeDragBridgeKey, t as tabViewNativeDropHandledKey };

//# sourceMappingURL=tabViewNativeDragBridge.js.map