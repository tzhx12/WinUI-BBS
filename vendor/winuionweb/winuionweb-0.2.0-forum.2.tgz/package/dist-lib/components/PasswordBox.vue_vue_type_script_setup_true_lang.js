import { eventNames as e, normalizeXamlNodes as t, resolveXamlHandler as n, resolveXamlValue as r, updateXamlBinding as i, xamlScopeKey as a } from "./xamlRuntime.js";
import { useI18n as o } from "./i18n/index.js";
import { textCommandFlyout as ee } from "./textCommandFlyout.js";
import { getVNodeChildren as te } from "./CollectionProperties.js";
import { textInputTemplateKey as ne } from "./textInputTemplate.js";
import re from "./TextBox.vue.js";
import { Fragment as s, cloneVNode as ie, computed as c, defineComponent as l, getCurrentInstance as ae, h as u, inject as oe, nextTick as d, onBeforeUnmount as se, onMounted as ce, provide as le, reactive as ue, ref as f, useAttrs as de, useSlots as fe, watch as p } from "vue";
//#region src/components/PasswordBox.vue?vue&type=script&setup=true&lang.ts
var m = (e) => l({
	name: `PasswordBox.${e}`,
	__passwordProperty: e,
	setup: () => () => null
}), pe = m("Header"), me = m("HeaderTemplate"), he = m("Description"), ge = m("ContextFlyout"), _e = m("SelectionFlyout"), ve = /*@__PURE__*/ l({
	Header: pe,
	HeaderTemplate: me,
	Description: he,
	ContextFlyout: ge,
	SelectionFlyout: _e,
	inheritAttrs: !1,
	__name: "PasswordBox",
	props: {
		Password: { default: "" },
		Header: { default: "" },
		HeaderTemplate: {},
		Description: { default: "" },
		PlaceholderText: { default: "" },
		ContextFlyout: {},
		SelectionFlyout: {},
		PasswordChar: { default: "●" },
		PasswordRevealMode: { default: "Peek" },
		MaxLength: { default: 0 },
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		InputScope: { default: "Password" },
		SelectionHighlightColor: { default: "" },
		PreventKeyboardDisplayOnProgrammaticFocus: { type: [Boolean, String] },
		Width: { default: "" },
		Height: { default: "" },
		MinWidth: { default: 64 },
		MaxWidth: { default: "" },
		Margin: { default: "" },
		Padding: { default: "" },
		HorizontalAlignment: { default: "" },
		VerticalAlignment: { default: "" },
		Background: { default: "" },
		BorderBrush: { default: "" },
		BorderThickness: { default: 1 },
		CornerRadius: { default: 4 },
		FontFamily: { default: "" },
		FontSize: { default: 14 },
		FontWeight: { default: 400 },
		Foreground: { default: "" }
	},
	emits: [
		"update:Password",
		"PasswordChanging",
		"PasswordChanged",
		"GotFocus",
		"LostFocus",
		"Paste",
		"KeyDown",
		"ContextMenuOpening"
	],
	setup(ve, { expose: ye, emit: be }) {
		let h = ve, g = ae(), _ = de(), xe = fe(), { t: v } = o(), y = ue({}), b = new Proxy(h, { get: (e, t) => typeof t == "string" && t in y ? y[t] : r(Reflect.get(e, t), g) }), Se = c(() => Object.fromEntries(Object.entries(_).filter(([t]) => !e.has(t) && !t.startsWith("on") && !t.startsWith("AutomationProperties.")))), x = (e) => {
			let n = (t) => t.flatMap((t) => t.type === s ? n(te(t)) : t.type?.__passwordProperty === e ? te(t) : []);
			return t(n(xe.default?.() ?? []), g);
		}, Ce = c(() => x("Header")), we = c(() => x("HeaderTemplate")), Te = c(() => x("Description")), Ee = l({ setup: () => () => u(s, Ce.value) }), De = l({ setup: () => () => u(s, we.value) }), Oe = l({ setup: () => () => u(s, Te.value) }), ke = be, S = (e, t = { Handled: !1 }) => {
			let r = g?.exposeProxy ?? g?.exposed ?? g?.proxy, i = g?.vnode.props?.[`on${e}`];
			if (i) for (let e of Array.isArray(i) ? i : [i]) typeof e == "function" && e(r, t);
			else ke(e, r, t), n(_[e], g)?.(r, t);
		}, C = f(null), w = f(null), T = f(null), E = f(null), D = f(""), O = f({
			start: 0,
			end: 0
		}), k = f("Standard"), A = 0, Ae = l({ setup: () => () => u(s, ["ContextFlyout", "SelectionFlyout"].flatMap((e) => x(e).map((t) => ie(t, { ref: (t) => {
			e === "ContextFlyout" ? T.value = t : E.value = t;
		} }, !0)))) }), j = async () => {
			try {
				return await navigator.clipboard?.readText() ?? "";
			} catch {
				return "";
			}
		}, je = async () => {
			if (!b.IsEnabled || !C.value) return;
			let e = { Handled: !1 };
			if (S("Paste", e), e.Handled) return;
			let t = await j();
			if (!b.IsEnabled || !C.value?.isConnected) return;
			let n = O.value.start, r = O.value.end;
			X(t, {
				value: M.value,
				start: n,
				end: r
			}), C.value.focus({ preventScroll: !0 });
			let i = Math.min(n + t.length, M.value.length);
			C.value.setSelectionRange(i, i);
		}, Me = ee(w, () => [...D.value ? [{
			Text: v("text.paste"),
			Value: "paste"
		}] : [], ...M.value ? [{
			Text: v("text.select-all"),
			Value: "selectAll"
		}] : []], (e) => {
			e.Value === "paste" ? je() : C.value?.select();
		}, void 0, () => ({ ShowMode: k.value })), Ne = async (e) => {
			if (e.preventDefault(), !b.IsEnabled || !C.value) return;
			let t = {
				Handled: !1,
				CursorLeft: e.offsetX,
				CursorTop: e.offsetY
			};
			if (S("ContextMenuOpening", t), t.Handled || b.ContextFlyout === null) return;
			k.value = "Standard", Z(), C.value.focus({ preventScroll: !0 }), O.value = {
				start: C.value.selectionStart ?? 0,
				end: C.value.selectionEnd ?? 0
			};
			let n = ++A;
			if (D.value = await j(), n !== A || !C.value?.isConnected || !b.IsEnabled || document.activeElement !== C.value) return;
			let r = T.value ?? b.ContextFlyout ?? w.value;
			await d();
			let i = C.value.getBoundingClientRect();
			r?.ShowAt?.(C.value, { Position: {
				X: e.clientX - i.left,
				Y: e.clientY - i.top
			} });
		}, Pe = async (e) => {
			if (e.button !== 0 || !["touch", "pen"].includes(e.pointerType) || !b.IsEnabled || b.SelectionFlyout === null || !C.value || (O.value = {
				start: C.value.selectionStart ?? 0,
				end: C.value.selectionEnd ?? 0
			}, O.value.start === O.value.end)) return;
			k.value = "Transient";
			let t = ++A;
			D.value = await j(), !(t !== A || !C.value?.isConnected || document.activeElement !== C.value || C.value.selectionStart !== O.value.start || C.value.selectionEnd !== O.value.end) && (await d(), (E.value ?? b.SelectionFlyout ?? w.value)?.ShowAt?.(C.value, {
				ShowMode: "Transient",
				Placement: "TopEdgeAlignedLeft"
			}));
		}, M = f(String(b.Password ?? "")), N = f(!1), P = f(!1), F = f(!1), Fe = f(0), I = c(() => b.PasswordRevealMode), L = f(!1), R = c(() => I.value === "Visible" || P.value), Ie = c(() => I.value === "Peek" && N.value && F.value && M.value.length > 0 && b.IsEnabled && Fe.value > Number(b.FontSize) * 5), z = c(() => {
			let e = String(b.PasswordChar);
			if (e.length !== 1 || e === "\0") throw RangeError("PasswordBox.PasswordChar must be one non-null UTF-16 character.");
			return e;
		}), B = c(() => !R.value && z.value !== "●"), Le = c(() => B.value ? z.value.repeat(M.value.length) : M.value), Re = c(() => ({
			fontFamily: b.FontFamily || void 0,
			fontSize: `${Number(b.FontSize)}px`,
			fontWeight: b.FontWeight,
			color: b.Foreground || void 0
		})), V = [], H = [], U, W, G, K = () => ({
			value: M.value,
			start: C.value?.selectionStart ?? 0,
			end: C.value?.selectionEnd ?? 0
		}), q = (e, t = e) => {
			C.value?.setSelectionRange(Math.min(e, M.value.length), Math.min(t, M.value.length));
		}, J = () => {
			C.value && !L.value && (C.value.value = Le.value);
		}, Y = (e, t = !1) => {
			let n = Number(b.MaxLength), r = n > 0 ? e.slice(0, n) : e;
			r !== M.value && (t && M.value.length === 0 && (F.value = !0), r || (F.value = !1), M.value = r, J(), i(h.Password, r, g), ke("update:Password", r), S("PasswordChanging", { IsContentChanging: !0 }), S("PasswordChanged"));
		}, X = (e, t = K()) => {
			let n = Number(b.MaxLength), r = n > 0 ? Math.max(0, n - t.value.length + t.end - t.start) : e.length, i = e.slice(0, r), a = t.value.slice(0, t.start) + i + t.value.slice(t.end);
			a !== M.value && (V.push(t), V.length > 100 && V.shift(), H.length = 0, Y(a, !0)), J();
			let o = t.start + i.length;
			q(o), d(() => q(o));
		}, ze = (e) => {
			let t = e ? H : V, n = e ? V : H, r = t.pop();
			r && (n.push(K()), Y(r.value, !0), q(r.start, r.end), d(() => q(r.start, r.end)));
		}, Be = (e, t) => {
			if (t.start !== t.end) return t;
			if (e.includes("Word") || e.includes("Line")) return e.endsWith("Backward") ? {
				...t,
				start: 0
			} : {
				...t,
				end: t.value.length
			};
			let n = [...new Intl.Segmenter(void 0, { granularity: "grapheme" }).segment(t.value)].map((e) => e.index);
			return n.push(t.value.length), e.endsWith("Backward") ? {
				...t,
				start: n.filter((e) => e < t.start).at(-1) ?? 0
			} : {
				...t,
				end: n.find((e) => e > t.end) ?? t.value.length
			};
		}, Ve = (e) => {
			U = K(), !(!B.value || L.value || e.isComposing || !e.cancelable) && (e.inputType === "historyUndo" || e.inputType === "historyRedo" ? (e.preventDefault(), ze(e.inputType === "historyRedo")) : e.inputType.startsWith("delete") ? (e.preventDefault(), X("", Be(e.inputType, U))) : e.inputType.startsWith("insert") && e.data !== null && (e.preventDefault(), X(e.data, U)));
		}, He = (e) => {
			if (L.value) return;
			if (G !== void 0 && e.data === G) {
				G = void 0, J();
				return;
			}
			G = void 0;
			let t = e.target;
			if (!B.value) t.value !== M.value && (V.push(U ?? K()), H.length = 0, Y(t.value, !0));
			else {
				let n = U ?? K();
				if (e.inputType?.startsWith("delete")) X("", Be(e.inputType, n));
				else if (e.data !== null && e.data !== void 0) X(e.data, n);
				else {
					let e = z.value.repeat(n.value.length), r = t.value, i = 0, a = e.length, o = r.length;
					for (; i < a && i < o && e[i] === r[i];) i++;
					for (; a > i && o > i && e[a - 1] === r[o - 1];) a--, o--;
					X(r.slice(i, o), {
						...n,
						start: i,
						end: a
					});
				}
			}
			U = void 0;
		}, Ue = () => {
			G = void 0, W = K(), L.value = !0, w.value?.Hide?.(!1);
		}, We = (e) => {
			L.value = !1, B.value && W ? (G = e.data, X(e.data, W)) : C.value && Y(C.value.value, !0), W = void 0, U = void 0;
		}, Z = () => {
			P.value = !1;
		}, Ge = (e) => {
			let t = { Handled: !1 };
			if (S("Paste", t), t.Handled) {
				e.preventDefault();
				return;
			}
			L.value || B.value && e.clipboardData && (e.preventDefault(), X(e.clipboardData.getData("text/plain")));
		}, Ke = (e) => {
			let t = {
				Key: e.key,
				Handled: !1,
				OriginalSource: C.value
			};
			if (S("KeyDown", t), t.Handled) {
				e.preventDefault();
				return;
			}
			L.value || e.isComposing || e.keyCode === 229 || (U = K(), (e.ctrlKey || e.metaKey) && !e.altKey && ["z", "y"].includes(e.key.toLowerCase()) && (e.preventDefault(), ze(e.key.toLowerCase() === "y" || e.shiftKey)));
		};
		le(a, {
			...oe(a, {}),
			PasswordTemplate: b
		}), le(ne, {
			HideDeleteButton: !0,
			Field: (e) => u("div", { class: "win-password-content" }, [u("input", {
				ref: C,
				class: ["win-textbox-field", {
					"custom-password-mask": B.value,
					"is-composing": L.value
				}],
				style: Re.value,
				type: R.value || B.value ? "text" : "password",
				value: Le.value,
				placeholder: b.PlaceholderText,
				maxlength: Number(b.MaxLength) > 0 ? b.MaxLength : void 0,
				disabled: !b.IsEnabled,
				autocomplete: "current-password",
				spellcheck: !1,
				autocapitalize: "off",
				autocorrect: "off",
				inputmode: b.InputScope === "NumericPin" ? "numeric" : "text",
				"aria-label": r(_["AutomationProperties.Name"], g) ?? b.Header,
				onBeforeinput: Ve,
				onInput: He,
				onCompositionstart: Ue,
				onCompositionend: We,
				onFocus: () => {
					N.value = !0, F.value = M.value.length === 0, e.Focused(), S("GotFocus");
				},
				onBlur: () => {
					N.value = !1, F.value = !1, Z(), e.Blurred(), S("LostFocus");
				},
				onPointerenter: e.PointerEntered,
				onPointerleave: e.PointerExited,
				onCopy: (e) => e.preventDefault(),
				onCut: (e) => e.preventDefault(),
				onPaste: Ge,
				onKeydown: Ke,
				onContextmenu: Ne,
				onPointerup: Pe,
				onDrop: (e) => {
					B.value && e.dataTransfer && (e.preventDefault(), X(e.dataTransfer.getData("text/plain")));
				}
			})]),
			Actions: () => Ie.value ? u("button", {
				class: "win-textbox-action-button win-password-reveal",
				type: "button",
				tabindex: -1,
				"aria-label": v("text.reveal-password"),
				"ToolTipService.ToolTip": v("text.reveal-password"),
				onPointerdown: (e) => {
					e.preventDefault(), e.currentTarget.setPointerCapture(e.pointerId), P.value = !0;
				},
				onPointerup: Z,
				onPointercancel: Z,
				onLostpointercapture: Z,
				onKeydown: (e) => {
					(e.key === " " || e.key === "Enter") && (e.preventDefault(), P.value = !0);
				},
				onKeyup: Z
			}, [u("span", "")]) : null
		}), p(() => r(h.Password, g), (e) => Y(String(e ?? ""))), p(() => b.PasswordRevealMode, Z), p(() => b.IsEnabled, () => {
			Z(), b.IsEnabled || C.value?.blur();
		}), p(h, () => {
			for (let e of Object.keys(y)) delete y[e];
		});
		let qe = (e) => e instanceof Element && !!e.closest(".win-commandbar-flyout,.win-menu-flyout,.win-flyout"), Je = (e) => {
			let t = e.target;
			if (!(!C.value || !t)) {
				if (C.value.closest(".win-password-box")?.contains(t)) {
					t === C.value && e.button === 0 && (A++, w.value?.Hide?.(!1));
					return;
				}
				qe(e.target) || (A++, w.value?.Hide?.(!1), C.value.blur());
			}
		}, Q = (e) => {
			C.value && !C.value.closest(".win-password-box")?.contains(e.target) && !qe(e.target) && (A++, w.value?.Hide?.(!1));
		};
		p([R, z], () => {
			let e = K();
			d(() => {
				J(), q(e.start, e.end);
			});
		}, { flush: "sync" });
		let $;
		ce(() => {
			document.addEventListener("pointerdown", Je, !0), document.addEventListener("focusin", Q, !0);
			let e = C.value?.closest(".win-textbox-border");
			e && ($ = new ResizeObserver(() => {
				Fe.value = e.getBoundingClientRect().width;
			}), $.observe(e)), window.addEventListener("blur", Z);
		}), se(() => {
			document.removeEventListener("pointerdown", Je, !0), document.removeEventListener("focusin", Q, !0), A++, w.value?.Hide?.(!1), window.removeEventListener("blur", Z), $?.disconnect();
		}), ye({
			get Password() {
				return M.value;
			},
			set Password(e) {
				Y(String(e ?? ""));
			},
			get PasswordChar() {
				return z.value;
			},
			set PasswordChar(e) {
				if (e.length !== 1 || e === "\0") throw RangeError("PasswordBox.PasswordChar must be one non-null UTF-16 character.");
				y.PasswordChar = e;
			},
			get PasswordRevealMode() {
				return I.value;
			},
			set PasswordRevealMode(e) {
				y.PasswordRevealMode = e, Z();
			},
			get IsEnabled() {
				return b.IsEnabled;
			},
			set IsEnabled(e) {
				y.IsEnabled = e;
			},
			Focus: () => C.value?.focus({ preventScroll: !!b.PreventKeyboardDisplayOnProgrammaticFocus }),
			SelectAll: () => C.value?.select(),
			PasteFromClipboard: () => (O.value = {
				start: C.value?.selectionStart ?? 0,
				end: C.value?.selectionEnd ?? 0
			}, je()),
			get ContextFlyout() {
				return b.ContextFlyout === void 0 ? T.value ?? w.value : b.ContextFlyout;
			},
			set ContextFlyout(e) {
				y.ContextFlyout = e;
			},
			get SelectionFlyout() {
				return b.SelectionFlyout === void 0 ? E.value ?? w.value : b.SelectionFlyout;
			},
			set SelectionFlyout(e) {
				y.SelectionFlyout = e;
			},
			get Element() {
				return C.value;
			}
		});
		let Ye = {
			passwordProperty: m,
			PasswordBoxHeader: pe,
			PasswordBoxHeaderTemplate: me,
			PasswordBoxDescription: he,
			PasswordBoxContextFlyout: ge,
			PasswordBoxSelectionFlyout: _e,
			rawProps: h,
			instance: g,
			attrs: _,
			slots: xe,
			t: v,
			overrides: y,
			props: b,
			surfaceAttrs: Se,
			propertyNodes: x,
			headerNodes: Ce,
			headerTemplateNodes: we,
			descriptionNodes: Te,
			HeaderOutlet: Ee,
			HeaderTemplateOutlet: De,
			DescriptionOutlet: Oe,
			emit: ke,
			dispatch: S,
			field: C,
			contextMenu: w,
			customContext: T,
			customSelection: E,
			clipboard: D,
			contextSelection: O,
			flyoutMode: k,
			get menuRequest() {
				return A;
			},
			set menuRequest(e) {
				A = e;
			},
			CustomFlyouts: Ae,
			readClipboard: j,
			pasteFromClipboard: je,
			ContextMenu: Me,
			onContextMenu: Ne,
			onSelectionPointerUp: Pe,
			password: M,
			focused: N,
			peeking: P,
			revealEligible: F,
			fieldWidth: Fe,
			mode: I,
			composing: L,
			visible: R,
			showReveal: Ie,
			maskCharacter: z,
			customMask: B,
			editorText: Le,
			fieldStyle: Re,
			undoHistory: V,
			redoHistory: H,
			get pendingEdit() {
				return U;
			},
			set pendingEdit(e) {
				U = e;
			},
			get compositionEdit() {
				return W;
			},
			set compositionEdit(e) {
				W = e;
			},
			get compositionCommitted() {
				return G;
			},
			set compositionCommitted(e) {
				G = e;
			},
			editState: K,
			restoreSelection: q,
			syncEditor: J,
			applyPassword: Y,
			replacePasswordRange: X,
			restoreHistory: ze,
			deletionRange: Be,
			onBeforeInput: Ve,
			onPasswordInput: He,
			onCompositionStart: Ue,
			onCompositionEnd: We,
			stopPeek: Z,
			onPaste: Ge,
			onKeyDown: Ke,
			isMenuTarget: qe,
			onDocumentPointerDown: Je,
			onDocumentFocusIn: Q,
			get sizeObserver() {
				return $;
			},
			set sizeObserver(e) {
				$ = e;
			},
			TextBox: re
		};
		return Object.defineProperty(Ye, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), Ye;
	}
});
//#endregion
export { ge as PasswordBoxContextFlyout, he as PasswordBoxDescription, pe as PasswordBoxHeader, me as PasswordBoxHeaderTemplate, _e as PasswordBoxSelectionFlyout, ve as default };

//# sourceMappingURL=PasswordBox.vue_vue_type_script_setup_true_lang.js.map