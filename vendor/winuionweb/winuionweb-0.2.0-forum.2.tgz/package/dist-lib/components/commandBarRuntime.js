import { normalizeXamlNodes as e } from "./xamlRuntime.js";
import { commandBarContextKey as t } from "./appBarRuntime.js";
import { Fragment as n, Teleport as r, computed as i, defineComponent as a, getCurrentInstance as o, h as s, isVNode as c, provide as l } from "vue";
//#region src/components/commandBarRuntime.ts
var u = (e, t) => a({
	name: `${e}.${t}`,
	__commandBarProperty: t,
	setup() {
		return () => null;
	}
}), d = (e) => Array.isArray(e.children) ? e.children.filter(c) : e.children?.default?.() ?? [], f = (e) => e.flatMap((e) => e.type === n ? f(d(e)) : e.type && typeof e.type != "symbol" ? [e] : []), p = (e) => String(e.type.name || e.type.__name || ""), m = (e) => p(e) === "AppBarSeparator", h = (e) => !!(e.props?.Icon || e.props?.Command || d(e).some((e) => String(e.type.name || "").endsWith(".Icon"))), g = (e) => p(e) === "AppBarToggleButton", _ = (e) => [
	"AppBarButton",
	"AppBarToggleButton",
	"AppBarSeparator",
	"AppBarElementContainer"
].includes(p(e)), v = (e) => (Object.defineProperties(e, {
	Count: {
		configurable: !0,
		get: () => e.length
	},
	Size: {
		configurable: !0,
		get: () => e.length
	},
	Add: {
		configurable: !0,
		value: (t) => {
			if (!c(t)) throw TypeError("Command collection requires AppBar command elements");
			e.push(t);
		}
	},
	Append: {
		configurable: !0,
		value: (t) => {
			if (!c(t)) throw TypeError("Command collection requires AppBar command elements");
			e.push(t);
		}
	},
	RemoveAt: {
		configurable: !0,
		value: (t) => {
			if (t < 0 || t >= e.length) throw RangeError("Command collection index is out of range");
			e.splice(t, 1);
		}
	},
	Clear: {
		configurable: !0,
		value: () => e.splice(0)
	},
	GetAt: {
		configurable: !0,
		value: (t) => e[t]
	},
	InsertAt: {
		configurable: !0,
		value: (t, n) => {
			if (!c(n)) throw TypeError("Command collection requires AppBar command elements");
			e.splice(t, 0, n);
		}
	},
	SetAt: {
		configurable: !0,
		value: (t, n) => {
			if (!c(n)) throw TypeError("Command collection requires AppBar command elements");
			e.splice(t, 1, n);
		}
	}
}), e), y = a({
	name: "CommandBarCommandPortal",
	props: {
		node: {
			type: Object,
			required: !0
		},
		host: {
			type: Object,
			required: !0
		},
		overflow: {
			type: Boolean,
			required: !0
		},
		context: {
			type: Object,
			required: !0
		}
	},
	setup(n) {
		let a = o();
		return l(t, {
			...n.context,
			isInOverflow: i(() => n.overflow)
		}), () => s(r, { to: n.host }, e([n.node], a));
	}
});
a({
	name: "CommandBarCommandsOutlet",
	props: {
		nodes: {
			type: Array,
			required: !0
		},
		context: {
			type: Object,
			required: !0
		}
	},
	setup(r) {
		let i = o();
		return l(t, r.context), () => s(n, e(r.nodes, i));
	}
});
//#endregion
export { y as CommandPortal, u as commandBarProperty, d as commandChildren, v as commandCollection, h as commandHasIcon, f as flattenCommandNodes, _ as isAppBarCommand, m as isCommandSeparator, g as isCommandToggle };

//# sourceMappingURL=commandBarRuntime.js.map