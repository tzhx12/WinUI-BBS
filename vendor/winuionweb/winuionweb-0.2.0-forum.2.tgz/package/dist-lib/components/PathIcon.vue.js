import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./PathIcon.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                             */
import { createElementBlock as n, createElementVNode as r, createVNode as i, mergeProps as a, openBlock as o, withCtx as s } from "vue";
//#region src/components/PathIcon.vue
var c = ["width", "height"], l = ["d", "fill-rule"];
function u(e, t, u, d, f, p) {
	return o(), n("span", a({ ref: "Element" }, d.rootAttrs, {
		class: ["win-icon-element win-path-icon", d.attrs.class],
		style: [d.attrs.style, d.iconStyle]
	}), [i(d.Grid, {
		class: "win-icon-grid",
		"data-icon-part": "LayoutRoot",
		Background: "Transparent"
	}, {
		default: s(() => [(o(), n("svg", {
			class: "win-path-icon-path",
			"data-icon-part": "Path",
			width: d.naturalSize.width,
			height: d.naturalSize.height,
			"aria-hidden": "true"
		}, [r("path", {
			ref: "pathElement",
			d: d.geometry.path,
			"fill-rule": d.geometry.fillRule
		}, null, 8, l)], 8, c))]),
		_: 1
	})], 16);
}
var d = /*#__PURE__*/ e(t, [
	["render", u],
	["__scopeId", "data-v-e1d4bdbe"],
	["__file", "PathIcon.vue"]
]);
//#endregion
export { d as default };

//# sourceMappingURL=PathIcon.vue.js.map