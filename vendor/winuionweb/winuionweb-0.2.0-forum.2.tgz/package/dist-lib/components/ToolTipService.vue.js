import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./ToolTipService.vue_vue_type_script_setup_true_lang.js";
import { Fragment as n, createElementBlock as r, createElementVNode as i, createVNode as a, openBlock as o } from "vue";
//#region src/components/ToolTipService.vue
var s = {
	ref: "hostRef",
	class: "tooltip-service-host",
	"aria-hidden": "true",
	style: { display: "none" }
};
function c(e, t, c, l, u, d) {
	return o(), r(n, null, [i("span", s, null, 512), a(l.ToolTip, {
		ref: "fallbackRef",
		Content: "{x:Bind ServiceContent}"
	}, null, 512)], 64);
}
var l = /*#__PURE__*/ e(t, [["render", c], ["__file", "ToolTipService.vue"]]);
//#endregion
export { l as default };

//# sourceMappingURL=ToolTipService.vue.js.map