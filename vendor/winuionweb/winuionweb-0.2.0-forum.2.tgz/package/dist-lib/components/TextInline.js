import { cssLength as e, xamlThickness as t } from "./layout.js";
import { cssColor as n, isSolidColorBrush as r } from "./brushCore.js";
import { normalizeXamlNodes as i, resolveXamlHandler as a, resolveXamlValue as o } from "./xamlRuntime.js";
import { Comment as s, Fragment as c, defineComponent as l, getCurrentInstance as u, h as d, onBeforeUnmount as f, ref as p } from "vue";
//#region src/components/TextInline.ts
var m = (e, t) => l({
	name: `${e}.${t}`,
	__textProperty: t,
	setup: () => () => null
}), h = m("TextBlock", "Inlines"), g = m("TextBlock", "TextHighlighters"), _ = m("RichTextBlock", "Blocks"), v = m("RichTextBlock", "TextHighlighters"), y = m("Span", "Inlines"), b = m("Paragraph", "Inlines"), x = m("InlineUIContainer", "Child"), S = m("TextHighlighter", "Ranges"), C = l({
	name: "TextHighlighter",
	Ranges: S,
	__textHighlighter: !0,
	setup: () => () => null
}), w = l({
	name: "TextRange",
	__textRange: !0,
	setup: () => () => null
}), T = (e) => {
	if (Array.isArray(e.children)) return e.children;
	let t = e.children?.default;
	return typeof t == "function" ? t() : [];
}, E = (e) => e.type?.__textProperty ?? (typeof e.type == "string" ? e.type.match(/^(?:TextBlock|RichTextBlock|Span|Bold|Italic|Underline|Hyperlink|Paragraph|InlineUIContainer|TextHighlighter)\.(\w+)$/)?.[1] : void 0), D = (e, t) => e.flatMap((e) => {
	if (e.type === s) return [];
	if (e.type === c) return D(T(e), t);
	let n = E(e);
	return n ? n === t ? T(e) : [] : [e];
}), O = (e) => {
	if (r(e)) {
		let t = n(e.Color);
		return e.Opacity === 1 ? t : `color-mix(in srgb, ${t} ${e.Opacity * 100}%, transparent)`;
	}
	return e == null || e === "" ? "" : n(e);
}, k = (e) => ({
	Thin: 100,
	ExtraLight: 200,
	Light: 300,
	SemiLight: 350,
	Normal: 400,
	Regular: 400,
	Medium: 500,
	SemiBold: 600,
	Bold: 700,
	ExtraBold: 800,
	Black: 900,
	ExtraBlack: 950
})[String(e)] ?? String(e ?? ""), A = {
	CharacterSpacing: [String, Number],
	FontFamily: String,
	FontSize: [String, Number],
	FontStretch: String,
	FontStyle: String,
	FontWeight: [String, Number],
	Foreground: [String, Object],
	TextDecorations: String,
	FlowDirection: String,
	Language: String,
	IsTextScaleFactorEnabled: [String, Boolean]
}, j = (t, n) => {
	let r = (e) => o(t[e], n), i = r("FontFamily");
	return {
		fontFamily: i === "XamlAutoFontFamily" ? "var(--ContentControlThemeFontFamily)" : i,
		fontSize: e(r("FontSize")),
		fontStretch: String(r("FontStretch") ?? "").replace(/([a-z])([A-Z])/g, "$1-$2").toLowerCase(),
		fontStyle: String(r("FontStyle") ?? "").toLowerCase(),
		fontWeight: k(r("FontWeight")),
		color: O(r("Foreground")),
		letterSpacing: r("CharacterSpacing") === void 0 ? void 0 : `${Number(r("CharacterSpacing")) / 1e3}em`,
		textDecorationLine: String(r("TextDecorations") ?? "").replace("Strikethrough", "line-through").toLowerCase(),
		direction: r("FlowDirection") === "RightToLeft" ? "rtl" : r("FlowDirection") === "LeftToRight" ? "ltr" : void 0,
		...r("IsTextScaleFactorEnabled") === !1 ? {
			textSizeAdjust: "none",
			WebkitTextSizeAdjust: "none"
		} : {}
	};
}, M = (n, r, a = {}) => l({
	name: n,
	inheritAttrs: !1,
	Inlines: n === "Paragraph" ? b : y,
	props: {
		...A,
		...a
	},
	setup(a, { slots: s, attrs: c }) {
		let l = u(), f = a;
		return () => d(r, {
			lang: o(f.Language, l),
			style: [
				j(a, l),
				n === "Paragraph" ? {
					margin: t(o(f.Margin, l) ?? 0),
					textIndent: e(o(f.TextIndent, l)),
					textAlign: String(o(f.TextAlignment, l) ?? "").toLowerCase(),
					lineHeight: Number(o(f.LineHeight, l)) > 0 ? e(o(f.LineHeight, l)) : void 0
				} : void 0,
				c.style
			]
		}, i(D(s.default?.() ?? [], "Inlines"), l));
	}
}), N = l({
	name: "Run",
	inheritAttrs: !1,
	props: {
		...A,
		Text: {
			type: [String, Number],
			default: ""
		}
	},
	setup(e, { slots: t, attrs: n }) {
		let r = u();
		return () => d("span", {
			lang: o(e.Language, r),
			style: [j(e, r), n.style]
		}, e.Text === "" ? i(t.default?.() ?? [], r) : String(o(e.Text, r, void 0, !0) ?? ""));
	}
}), P = M("Span", "span"), F = M("Bold", "b"), I = M("Italic", "i"), L = M("Underline", "u"), R = M("Paragraph", "p", {
	Margin: [String, Number],
	TextIndent: [String, Number],
	TextAlignment: String,
	LineHeight: [String, Number],
	LineStackingStrategy: String
}), z = l({
	name: "LineBreak",
	setup: () => () => d("br")
}), B = l({
	name: "InlineUIContainer",
	inheritAttrs: !1,
	Child: x,
	setup(e, { slots: t }) {
		let n = u();
		return () => d("span", {
			class: "win-inline-ui-container",
			style: {
				display: "inline-block",
				maxWidth: "100%",
				verticalAlign: "baseline",
				overflow: "hidden"
			}
		}, i(D(t.default?.() ?? [], "Child"), n));
	}
}), V = globalThis, H = V[Symbol.for("WinUIonWeb.TextInlineInteractions")] ??= /* @__PURE__ */ new Map(), U = (e) => {
	e.querySelectorAll("[data-text-inline-id]").forEach((e) => {
		let t = H.get(e.dataset.textInlineId ?? "");
		t && e.addEventListener("click", t);
	});
}, W = l({
	name: "Hyperlink",
	inheritAttrs: !1,
	Inlines: y,
	props: {
		...A,
		NavigateUri: {
			type: String,
			default: ""
		},
		Click: {
			type: [String, Function],
			default: void 0
		},
		UnderlineStyle: {
			type: String,
			default: "Single"
		}
	},
	emits: ["Click"],
	setup(e, { slots: t, expose: n }) {
		let r = u(), s = p(null), c = `hyperlink-${r?.uid}`, l = {
			Element: s,
			get NavigateUri() {
				return o(e.NavigateUri, r);
			}
		};
		n(l);
		let m = (t) => {
			l.NavigateUri || t.preventDefault();
			let n = {
				OriginalSource: t.target,
				Handled: !1
			};
			a(e.Click, r)?.(l, n);
			let i = r?.vnode.props?.onClick;
			for (let e of Array.isArray(i) ? i : [i]) typeof e == "function" && e(l, n);
			n.Handled && t.preventDefault();
		};
		return H.set(c, m), f(() => H.delete(c)), () => d("a", {
			ref: s,
			href: String(l.NavigateUri || "#"),
			class: "win-text-hyperlink",
			"data-text-inline-id": c,
			onClick: m,
			style: [j(e, r), { textDecorationLine: o(e.UnderlineStyle, r) === "None" ? "none" : "underline" }]
		}, i(D(t.default?.() ?? [], "Inlines"), r));
	}
}), G = (e, t) => {
	let n = document.createTreeWalker(e, NodeFilter.SHOW_TEXT), r = n.nextNode();
	for (t = Math.max(0, t); r;) {
		let e = r.textContent?.length ?? 0;
		if (t <= e) return [r, t];
		t -= e;
		let i = n.nextNode();
		if (!i) return [r, e];
		r = i;
	}
	return [e, 0];
}, K = (e, t) => e.filter((e) => E(e) === "TextHighlighters").flatMap((e) => T(e)).map((e) => ({
	Background: o(e.props?.Background, t),
	Foreground: o(e.props?.Foreground, t),
	Ranges: T(e).flatMap((e) => E(e) === "Ranges" ? T(e) : [e]).filter((e) => e.type?.__textRange || e.type === "TextRange").map((e) => ({
		StartIndex: Number(o(e.props?.StartIndex, t)),
		Length: Number(o(e.props?.Length, t))
	}))
})), q = (e) => {
	let t, n = /* @__PURE__ */ new Set(), r = () => {
		let e = typeof CSS > "u" ? void 0 : CSS.highlights;
		n.forEach((t) => e?.delete(t)), n.clear(), t?.remove(), t = void 0;
	};
	return {
		Clear: r,
		Update: (i, a) => {
			if (r(), typeof CSS > "u" || !("highlights" in CSS) || !("Highlight" in window)) return;
			let o = [];
			a.forEach((t, r) => {
				let a = [];
				if (i.forEach(({ Element: e, Start: n }) => {
					let r = e.textContent?.length ?? 0;
					t.Ranges.forEach((t) => {
						if (!Number.isFinite(t.StartIndex) || !Number.isFinite(t.Length) || t.Length <= 0) return;
						let i = Math.max(0, t.StartIndex - n), o = Math.min(r, t.StartIndex + t.Length - n);
						if (i >= o || i >= r) return;
						let s = document.createRange();
						s.setStart(...G(e, i)), s.setEnd(...G(e, o)), a.push(s);
					});
				}), !a.length) return;
				let s = `${e}-${r}`;
				CSS.highlights.set(s, new window.Highlight(...a)), n.add(s);
				let c = document.createElement("span").style;
				c.backgroundColor = O(t.Background) || "var(--TextControlHighlighterBackground, Yellow)", c.color = O(t.Foreground) || "var(--TextControlHighlighterForeground, #000000)", o.push(`::highlight(${s}) { ${c.cssText} }`);
			}), o.length && (t = document.createElement("style"), t.textContent = o.join("\n"), document.head.append(t));
		}
	};
};
//#endregion
export { F as Bold, W as Hyperlink, B as InlineUIContainer, x as InlineUIContainerChild, I as Italic, z as LineBreak, R as Paragraph, b as ParagraphInlines, _ as RichTextBlockBlocks, v as RichTextBlockTextHighlighters, N as Run, P as Span, y as SpanInlines, h as TextBlockInlines, g as TextBlockTextHighlighters, C as TextHighlighter, S as TextHighlighterRanges, w as TextRange, L as Underline, q as createTextHighlights, K as readTextHighlighters, U as restoreInlineInteractions, O as textBrush, D as textContentNodes, k as textFontWeight, G as textPosition };

//# sourceMappingURL=TextInline.js.map