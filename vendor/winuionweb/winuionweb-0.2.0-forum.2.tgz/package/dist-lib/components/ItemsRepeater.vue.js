import { useAcrylicBrushStyle as e } from "./AcrylicBrush.js";
import { materializeXamlVNode as t, normalizeXamlNodes as n, resolveXamlHandler as r, resolveXamlResourceObject as i, resolveXamlValue as a, xamlItemContextKey as o, xamlNameScopeKey as s } from "./xamlRuntime.js";
import { vAcrylicBrush as ee } from "./acrylicBrushVisual.js";
import te from "../_virtual/_plugin-vue_export-helper.js";
import { xamlResourceDictionaryKey as c } from "./Page.vue_vue_type_script_lang.js";
import { CollectionItemTemplate as l, CollectionLayout as ne, getCollectionProperty as re, getLayoutDescriptor as u, getVNodeChildren as d } from "./CollectionProperties.js";
import ie from "./TextBlock.vue.js";
import { computeRepeaterLayout as ae, measureBoxFor as oe, normalizeLayoutKind as se } from "./repeaterLayouts.js";
/* empty css                                                                  */
import { Fragment as f, computed as p, createBlock as ce, createElementBlock as le, defineComponent as ue, getCurrentInstance as de, h as fe, inject as pe, mergeProps as m, nextTick as me, normalizeClass as he, normalizeStyle as h, onBeforeUnmount as ge, onMounted as _e, openBlock as g, provide as ve, ref as _, renderList as v, resolveDynamicComponent as y, shallowReactive as ye, shallowRef as be, useAttrs as xe, useSlots as Se, watch as b, withDirectives as x } from "vue";
//#region src/components/ItemsRepeater.vue
var S = /*@__PURE__*/ Object.assign({
	ItemTemplate: l,
	Layout: ne
}, { inheritAttrs: !1 }, {
	__name: "ItemsRepeater",
	props: {
		ItemsSource: {
			type: [
				String,
				Array,
				Object
			],
			default: null
		},
		ItemTemplate: {
			type: [
				String,
				Object,
				Function
			],
			default: void 0
		},
		Layout: {
			type: [String, Object],
			default: void 0
		},
		HorizontalCacheLength: {
			type: [String, Number],
			default: 2
		},
		VerticalCacheLength: {
			type: [String, Number],
			default: 2
		},
		Background: {
			type: [String, Object],
			default: ""
		},
		HorizontalAlignment: {
			type: String,
			default: "Stretch"
		},
		VerticalAlignment: {
			type: String,
			default: "Stretch"
		},
		Margin: {
			type: [String, Number],
			default: ""
		},
		Width: {
			type: [String, Number],
			default: void 0
		},
		Height: {
			type: [String, Number],
			default: void 0
		},
		MinWidth: {
			type: [String, Number],
			default: void 0
		},
		MinHeight: {
			type: [String, Number],
			default: void 0
		},
		MaxWidth: {
			type: [String, Number],
			default: void 0
		},
		MaxHeight: {
			type: [String, Number],
			default: void 0
		},
		Visibility: {
			type: String,
			default: "Visible"
		}
	},
	emits: [
		"ElementPrepared",
		"ElementClearing",
		"ElementIndexChanged",
		"GettingFocus",
		"KeyDown"
	],
	setup(te, { expose: ce, emit: le }) {
		let m = te, he = le, h = _(null), g = Se(), v = xe(), y = de(), x = be({}), S = (e) => e in x.value ? x.value[e] : m[e], Ce = p(() => Object.fromEntries(Object.entries(v).filter(([e]) => ![
			"ElementPrepared",
			"ElementClearing",
			"ElementIndexChanged",
			"GettingFocus",
			"KeyDown"
		].includes(e)))), C = pe(c, null), w = g.default?.(), T = be(Array.isArray(w) ? w : w ? [w] : []), E = (e) => {
			if (!(e == null || e === "")) return typeof e == "number" || /^-?\d+(?:\.\d+)?$/.test(String(e)) ? `${e}px` : String(e);
		}, we = (e) => {
			if (e == null || e === "") return;
			let t = String(e).split(",").map((e) => E(e.trim()));
			return t.length === 1 ? t[0] : t.length === 2 ? `${t[1]} ${t[0]}` : t.length === 4 ? `${t[1]} ${t[2]} ${t[3]} ${t[0]}` : String(e);
		}, Te = (e, t) => (t === "horizontal" ? {
			Left: "flex-start",
			Center: "center",
			Right: "flex-end",
			Stretch: "stretch"
		} : {
			Top: "flex-start",
			Center: "center",
			Bottom: "flex-end",
			Stretch: "stretch"
		})[String(e ?? "")] ?? "", D = (e, t) => {
			let n = a(e, y);
			if (n == null || n === "") return t;
			let r = Number(n);
			return Number.isFinite(r) ? r : t;
		}, Ee = (e) => {
			let t = a(e, y);
			if (t == null || t === "") return null;
			let n = Number(t);
			return Number.isFinite(n) && n >= 0 ? n : null;
		}, O = _(0), k = p(() => a(S("ItemsSource"), y)), A;
		b(k, (e) => {
			if (A?.(), A = void 0, typeof e?.addEventListener == "function") {
				let t = () => {
					O.value += 1;
				};
				e.addEventListener("CollectionChanged", t), A = () => e.removeEventListener("CollectionChanged", t);
			}
		}, { immediate: !0 });
		let j = p(() => {
			O.value;
			let e = k.value;
			if (Array.isArray(e)) return {
				Count: e.length,
				GetAt: (t) => e[t],
				IndexOf: (t) => e.indexOf(t),
				Source: e
			};
			if (e && typeof e == "object") {
				if (Number.isFinite(e.Count)) {
					let t = e.Count, n = e.GetAt;
					return {
						Count: t,
						GetAt: (t) => n ? n.call(e, t) : e[t],
						IndexOf: (t) => e.IndexOf?.(t) ?? -1,
						Source: e
					};
				}
				if (typeof e[Symbol.iterator] == "function") {
					let t = Array.from(e);
					return {
						Count: t.length,
						GetAt: (e) => t[e],
						IndexOf: (e) => t.indexOf(e),
						Source: t
					};
				}
			}
			return {
				Count: 0,
				GetAt: () => void 0,
				IndexOf: () => -1,
				Source: []
			};
		}), M = p(() => {
			let e = j.value;
			return Array.from({ length: e.Count }, (t, n) => e.GetAt(n));
		}), De = p(() => {
			for (let e of T.value) if (re(e) === "layout") return d(e);
			return [];
		}), Oe = (e, t) => {
			let n = (e) => {
				if (typeof e != "string") return "";
				let t = e.trim().match(/^\{\s*(?:StaticResource|ThemeResource)\s+([^\s}]+)\s*\}$/i);
				return t ? t[1] : e.trim().match(/^var\(--([^,)]+)\)$/)?.[1] ?? "";
			};
			return n(e) || n(t);
		}, ke = p(() => {
			let e = Oe(S("Layout"), a(S("Layout"), y));
			if (e && C?.[e]) {
				let t = C[e], n = P(t);
				if (/Layout$/.test(n) && !/^Collection\./i.test(n)) return u([t]);
				let r = d(t);
				return u(r.length ? r : [t]);
			}
			let t = a(S("Layout"), y);
			return typeof t == "object" && t ? t : De.value.length ? u(De.value) : { Type: "StackLayout" };
		}), N = p(() => {
			let e = ke.value ?? {}, t = {};
			for (let [n, r] of Object.entries(e)) t[n] = a(r, y);
			return t.Type = se(t.Type ?? e.__layoutType ?? "StackLayout"), t;
		}), Ae = (e) => {
			if (typeof e != "string") return "";
			let t = e.trim().match(/^\{\s*StaticResource\s+([^\s}]+)\s*\}$/i);
			return t ? t[1] : e.trim().match(/^var\(--([^,)]+)\)$/)?.[1] ?? "";
		}, P = (e) => {
			let t = e?.type;
			return typeof t == "string" ? t : t?.name || t?.__name || "";
		}, je = (e) => e.flatMap((e) => e ? e.type === f || /DataTemplateSelector$/i.test(P(e)) ? je(d(e)) : [e] : []), Me = (e) => {
			let t = e?.props?.["x:Key"];
			return typeof t == "string" ? t : "";
		}, Ne = (e) => e && C?.[e] ? d(C[e]) : null, Pe = p(() => T.value.flatMap((e) => re(e) === "itemTemplate" ? d(e) : [])), Fe = (e) => {
			let t = e ? C?.[e] : null;
			if (!t) return null;
			let n = t.props ?? {}, r = [];
			for (let [e, t] of Object.entries(n)) {
				if (e === "x:Key") continue;
				let n = Ae(a(t, y) ?? t);
				n && r.push({
					Name: e,
					Key: n
				});
			}
			return r.length ? r : null;
		}, Ie = (e, t) => {
			let n = i(e, y);
			if (n && typeof n.SelectTemplate == "function") return (e) => n.SelectTemplate(e);
			let r = C?.[e]?.type?.SelectTemplateCore;
			return typeof r == "function" ? (e) => t?.find((t) => t.Name === r(e))?.Key : null;
		}, Le = p(() => {
			let e = Oe(S("ItemTemplate"), a(S("ItemTemplate"), y)), t = a(S("ItemTemplate"), y);
			if (t && typeof t.SelectTemplate == "function") return { select: t.SelectTemplate.bind(t) };
			let n = Ie(e, Fe(e));
			if (n) return { select: n };
			let r = Ne(e);
			if (r) return { nodes: r };
			for (let t of T.value) {
				if (re(t) !== "itemTemplate") continue;
				let n = je(d(t)).filter((e) => /DataTemplate$/i.test(P(e)));
				return n.length ? { nodes: d((e ? n.find((t) => Me(t) === e) : n[0]) ?? n[0]) } : { nodes: d(t) };
			}
			let i = T.value.find((e) => P(e) === "DataTemplate");
			return i ? { nodes: d(i) } : { nodes: null };
		}), Re = (e) => {
			let t = Le.value;
			if (!t.select) return t.nodes ?? [];
			let n = t.select(e);
			if (typeof n != "string" || !n) return [];
			let r = Ne(n);
			if (r) return r;
			let i = Pe.value.find((e) => Me(e) === n);
			return i ? d(i) : [];
		}, F = /* @__PURE__ */ new Map(), ze = (e, t) => {
			let n = j.value.Source;
			return typeof n.KeyFromIndex == "function" ? `key:${n.KeyFromIndex(t)}` : typeof e == "object" && e ? e : `index:${t}:${String(e ?? "")}`;
		}, Be = (e, r) => {
			let i = e && typeof e == "object" ? e : `primitive:${r}:${String(e ?? "")}`, a = F.get(i);
			if (a) return a;
			let ee = ue({
				name: "ItemsRepeaterItemTemplate",
				setup() {
					let r = de();
					return ve(o, e), ve(s, ye({})), () => {
						O.value;
						let i = Re(e);
						return i.length ? fe(f, n(t(i, e, r), r)) : fe(ie, { Text: e && typeof e == "object" && e.toString === Object.prototype.toString ? "" : String(e ?? "") });
					};
				}
			});
			return F.set(i, ee), ee;
		}, I = be([]), L = !1, R = _({
			width: 0,
			height: 0,
			scrollableX: !1,
			scrollableY: !1,
			scrollX: 0,
			scrollY: 0
		}), z, B, V = null, H = null, U = !1, Ve, He = () => {
			let e = h.value?.parentElement ?? null;
			for (; e;) {
				if (e.classList?.contains("win-scroll-viewer-viewport") || e.classList?.contains("win-scroll-presenter")) return e;
				e = e.parentElement;
			}
			return null;
		}, Ue = () => {
			let e = R.value, t = He();
			if (t && t.clientWidth > 0) {
				let e = getComputedStyle(t), n = /auto|scroll/.test(e.overflowX), r = /auto|scroll/.test(e.overflowY);
				return {
					width: Math.min(t.clientWidth, h.value?.parentElement?.clientWidth || t.clientWidth),
					height: t.clientHeight,
					scrollableX: n,
					scrollableY: r,
					scrollX: t.getBoundingClientRect().left - h.value.getBoundingClientRect().left,
					scrollY: t.getBoundingClientRect().top - h.value.getBoundingClientRect().top
				};
			}
			let n = h.value?.parentElement ?? null, r = null;
			for (; n;) n.clientWidth > 0 && !r && (r = {
				width: n.clientWidth,
				height: n.clientHeight,
				scrollableX: !1,
				scrollableY: !1,
				scrollX: e.scrollX,
				scrollY: e.scrollY
			}), n = n.parentElement;
			return r ?? e;
		}, We = () => {
			if (!V) return;
			let e = Ue();
			e.scrollX === R.value.scrollX && e.scrollY === R.value.scrollY || (R.value = e);
		}, W = p(() => {
			let e = D(S("MaxWidth"), Infinity), t = D(m.MaxHeight, Infinity), n = R.value, r = Ee(m.Width) ?? Math.min(e, n.scrollableX ? Infinity : n.width), i = Ee(m.Height) ?? Math.min(t, n.scrollableY ? Infinity : n.height);
			return {
				width: Number.isFinite(r) && r > 0 ? r : Infinity,
				height: Number.isFinite(i) && i > 0 ? i : Infinity
			};
		}), G = p(() => ae({
			count: M.value.length,
			naturals: I.value,
			available: W.value,
			props: N.value
		})), Ge = p(() => oe(N.value.Type, N.value, W.value, G.value.itemSize ?? null)), Ke = (e) => {
			let t = Ge.value, n = {
				width: "max-content",
				height: "auto"
			};
			return t && Number.isFinite(t.width) && (n.width = `${t.width}px`), t && Number.isFinite(t.height) && (n.height = `${t.height}px`), N.value.Type === "ActivityFeedLayout" && (n.width = `${G.value.rects[e]?.width ?? t?.width ?? 0}px`), n;
		}, qe = (e) => {
			let t = G.value.rects[e];
			return t ? {
				position: "absolute",
				left: `${t.x}px`,
				top: `${t.y}px`,
				width: `${t.width}px`,
				height: `${t.height}px`
			} : { display: "none" };
		}, Je = qe, Ye = (e) => !!$e(e), Xe = e(() => m.Background || void 0, y), Ze = p(() => {
			let e = G.value, t = N.value.Type === "StackLayout" ? String(N.value.Orientation ?? "Vertical").toLowerCase() === "horizontal" : e.horizontal, n = {
				...Xe.value,
				position: "relative",
				boxSizing: "border-box",
				display: "flex",
				flexDirection: t ? "row" : "column",
				alignItems: "stretch",
				minWidth: E(a(m.MinWidth, y)),
				minHeight: E(a(m.MinHeight, y)),
				maxWidth: E(a(S("MaxWidth"), y)),
				maxHeight: E(a(m.MaxHeight, y)),
				margin: we(a(m.Margin, y)),
				justifySelf: Te(a(m.HorizontalAlignment, y), "horizontal"),
				alignSelf: Te(a(m.VerticalAlignment, y), "vertical")
			}, r = a(m.Visibility, y) ?? m.Visibility;
			r === "Collapsed" ? n.display = "none" : r === "Hidden" && (n.visibility = "hidden");
			let i = E(a(m.Width, y)), o = E(a(m.Height, y));
			return n.width = i ?? (e.horizontal || !Number.isFinite(W.value.width) ? `${e.extent.width}px` : "100%"), n.height = o ?? `${e.extent.height}px`, n;
		}), Qe = (e) => h.value?.querySelector(`:scope > [data-index="${e}"]`) ?? null, $e = (e) => Qe(e)?.firstElementChild ?? null, et = (e) => {
			let t = e?.closest?.(".win-items-repeater-element");
			return t?.parentElement === h.value ? Number(t.dataset.index) : -1;
		}, tt = (e) => {
			let t = $e(e);
			return t && Ye(e) ? t : null;
		}, K = _(/* @__PURE__ */ new Set()), nt = (e) => {
			if (!Number.isInteger(e) || e < 0 || e >= M.value.length) throw RangeError("ItemsRepeater index is outside ItemsSourceView");
			return tt(e) || (K.value = new Set([...K.value, e]), y.update(), Q()), tt(e);
		}, q = /* @__PURE__ */ new Map(), J = (e, t) => {
			he(e, t), r(v[e], y)?.(t);
		}, rt = () => {
			let e = /* @__PURE__ */ new Map();
			for (let t of at.value) {
				let n = $e(t);
				if (!n) continue;
				let r = ze(M.value[t], t), i = q.get(r);
				e.set(r, {
					Element: n,
					Index: t
				}), !i || i.Element !== n ? (i && J("ElementClearing", { Element: i.Element }), J("ElementPrepared", {
					Element: n,
					Index: t
				})) : i.Index !== t && J("ElementIndexChanged", {
					Element: n,
					OldIndex: i.Index,
					NewIndex: t
				});
			}
			for (let [t, n] of q) e.has(t) || J("ElementClearing", { Element: n.Element });
			q = e;
		}, Y = 0, X = !1, Z = !1, it = p(() => {
			let e = M.value.length;
			if (e <= 120) return {
				start: 0,
				end: e
			};
			let t = I.value, n = G.value, r = n.horizontal, i = r ? R.value.scrollX : R.value.scrollY, a = r ? R.value.width : R.value.height, o = D(r ? m.HorizontalCacheLength : m.VerticalCacheLength, 2), s = Math.max(0, a * o / 2);
			if (t.reduce((e, t) => e + +!!t, 0) === 0 || a <= 0) return {
				start: 0,
				end: Math.min(e, 120)
			};
			let ee = (e) => {
				let t = n.rects[e];
				return t ? r ? t.x : t.y : Infinity;
			}, te = (e) => {
				let t = n.rects[e];
				return t ? r ? t.x + t.width : t.y + t.height : Infinity;
			}, c = e, l = 0;
			for (let t = 0; t < e; t += 1) te(t) >= i - s && ee(t) <= i + a + s && (c = Math.min(c, t), l = t + 1);
			return {
				start: c,
				end: l
			};
		}), at = p(() => {
			let e = M.value.length, t = it.value, n = [];
			for (let r = t.start; r < t.end && r < e; r += 1) n.push(r);
			for (let t of K.value) t < e && !n.includes(t) && n.push(t);
			let r = et(document.activeElement);
			return r >= 0 && !n.includes(r) && n.push(r), n.sort((e, t) => e - t);
		});
		b(at, async (e, t = []) => {
			if (!(e.length === t.length && e.every((e, n) => e === t[n]))) {
				if (e.some((e) => !I.value[e])) {
					Q();
					return;
				}
				await me(), h.value && (rt(), ut());
			}
		});
		let ot = (e) => {
			let t = M.value.length, n = I.value, r = Array(t).fill(null), i = [...e.querySelectorAll(":scope > .win-items-repeater-element")], a = i.map((e) => e.getAttribute("style"));
			try {
				for (let e of i) Object.assign(e.style, Ke(Number(e.dataset.index)));
				for (let e of i) {
					let n = Number(e.dataset.index);
					if (!Number.isInteger(n) || n < 0 || n >= t) continue;
					let i = e.firstElementChild;
					if (!i) continue;
					let a = getComputedStyle(i);
					r[n] = {
						width: i.offsetWidth + (parseFloat(a.marginLeft) || 0) + (parseFloat(a.marginRight) || 0),
						height: i.offsetHeight + (parseFloat(a.marginTop) || 0) + (parseFloat(a.marginBottom) || 0)
					};
				}
			} finally {
				i.forEach((e, t) => {
					a[t] === null ? e.removeAttribute("style") : e.setAttribute("style", a[t]);
				});
			}
			for (let e = 0; e < t; e += 1) !r[e] && n[e] && (r[e] = n[e]);
			return r;
		}, st = (e, t) => e.length !== t.length || e.some((e, n) => {
			let r = t[n];
			return !e || !r ? !!e != !!r : Math.abs(r.width - e.width) > .5 || Math.abs(r.height - e.height) > .5;
		}), ct = async () => {
			let e = ++Y;
			L = !0;
			try {
				for (let t = 0; t < 2; t += 1) {
					if (await me(), e !== Y) return;
					let t = h.value;
					if (!t) break;
					let n = ot(t), r = st(n, I.value);
					if (I.value = n, !r) break;
				}
			} finally {
				L = !1;
			}
			await me(), e === Y && (rt(), ut());
		}, Q = async () => {
			if (X) {
				Z = !0;
				return;
			}
			X = !0;
			try {
				do
					Z = !1, await ct();
				while (Z);
			} finally {
				X = !1;
			}
		}, lt = p(() => JSON.stringify({
			type: N.value.Type,
			props: N.value,
			width: W.value.width,
			height: W.value.height,
			template: S("ItemTemplate")
		}));
		b(lt, () => {
			I.value = [], Q();
		}), b(M, (e, t = []) => {
			let n = new Map(t.map((e, t) => [e, I.value[t]]));
			I.value = e.map((e) => n.get(e) ?? null), K.value = /* @__PURE__ */ new Set();
			let r = new Set(e.map((e, t) => e && typeof e == "object" ? e : `primitive:${t}:${String(e ?? "")}`));
			for (let e of F.keys()) r.has(e) || F.delete(e);
			Q();
		}), _e(() => {
			V = He(), R.value = Ue(), V?.addEventListener("scroll", We, { passive: !0 });
			let e = h.value?.parentElement;
			e && typeof ResizeObserver == "function" && (z = new ResizeObserver(() => {
				cancelAnimationFrame(B), B = requestAnimationFrame(() => {
					let e = Ue();
					(e.width !== R.value.width || e.height !== R.value.height || e.scrollableX !== R.value.scrollableX || e.scrollableY !== R.value.scrollableY) && (R.value = {
						...e,
						scrollX: R.value.scrollX,
						scrollY: R.value.scrollY
					}, Q());
				});
			}), z.observe(e)), typeof ResizeObserver == "function" && h.value && (H = new ResizeObserver(() => {
				L || U || (U = !0, Ve = requestAnimationFrame(() => {
					if (U = !1, L) return;
					let e = h.value;
					e && st(ot(e), I.value) && Q();
				}));
			}), ut()), Q();
		});
		let ut = () => {
			if (!(!H || !h.value)) {
				H.disconnect();
				for (let e of h.value.querySelectorAll(":scope > .win-items-repeater-element")) e.firstElementChild && H.observe(e.firstElementChild);
			}
		}, dt = (e) => {
			let t = {
				OldFocusedElement: e.relatedTarget,
				NewFocusedElement: e.target,
				OriginalSource: e.target
			};
			J("GettingFocus", t), t.NewFocusedElement !== e.target && t.NewFocusedElement?.focus({ preventScroll: !0 });
		}, ft = (e) => {
			let t = {
				Key: e.key,
				Handled: !1,
				OriginalSource: e.target,
				NativeEvent: e
			};
			if (J("KeyDown", t), t.Handled) e.preventDefault();
			else if (["ArrowUp", "ArrowDown"].includes(e.key) && e.target.matches("button")) {
				let t = et(e.target) + (e.key === "ArrowUp" ? -1 : 1);
				t >= 0 && t < M.value.length && (e.preventDefault(), nt(t)?.focus({ preventScroll: !0 }));
			}
		};
		ge(() => {
			Y += 1, A?.(), z?.disconnect(), cancelAnimationFrame(B), H?.disconnect(), cancelAnimationFrame(Ve), V?.removeEventListener("scroll", We);
			for (let e of q.values()) J("ElementClearing", { Element: e.Element });
			q.clear();
		});
		let $ = (e) => p({
			get: () => a(S(e), y),
			set: (t) => {
				x.value = {
					...x.value,
					[e]: t
				};
			}
		}), pt = p(() => ({
			...j.value,
			HasKeyIndexMapping: typeof k.value?.KeyFromIndex == "function" && typeof k.value?.IndexFromKey == "function",
			KeyFromIndex: (e) => k.value?.KeyFromIndex?.(e),
			IndexFromKey: (e) => k.value?.IndexFromKey?.(e) ?? -1
		}));
		ce({
			ItemsSourceView: pt,
			ItemsSource: $("ItemsSource"),
			ItemTemplate: $("ItemTemplate"),
			Layout: $("Layout"),
			MaxWidth: $("MaxWidth"),
			GetElementIndex: et,
			TryGetElement: tt,
			GetOrCreateElement: nt
		});
		let mt = {
			props: m,
			emit: he,
			rootRef: h,
			slots: g,
			attrs: v,
			instance: y,
			propertyOverrides: x,
			propertyValue: S,
			forwardedAttrs: Ce,
			pageResources: C,
			initialSlotNodes: w,
			slotNodes: T,
			toCssLength: E,
			thicknessToCss: we,
			alignmentValue: Te,
			resolvedNumber: D,
			explicitLength: Ee,
			sourceVersion: O,
			sourceData: k,
			get unsubscribeSource() {
				return A;
			},
			set unsubscribeSource(e) {
				A = e;
			},
			asItemsSourceView: j,
			items: M,
			layoutNodes: De,
			resourceKeyOf: Oe,
			layoutDescriptor: ke,
			resolvedLayoutProps: N,
			templateResourceKey: Ae,
			typeNameOf: P,
			unwrapTemplates: je,
			templateNodeKey: Me,
			templateNodesForKey: Ne,
			inlineTemplateCandidates: Pe,
			selectorBranchesForKey: Fe,
			makeSelectorPicker: Ie,
			itemTemplateResolver: Le,
			resolveItemTemplateNodes: Re,
			itemComponentCache: F,
			itemKey: ze,
			itemComponent: Be,
			itemNaturals: I,
			get isMeasuring() {
				return L;
			},
			set isMeasuring(e) {
				L = e;
			},
			hostBox: R,
			get hostObserver() {
				return z;
			},
			set hostObserver(e) {
				z = e;
			},
			get hostResizeFrame() {
				return B;
			},
			set hostResizeFrame(e) {
				B = e;
			},
			get hostScrollViewport() {
				return V;
			},
			set hostScrollViewport(e) {
				V = e;
			},
			get settleObserver() {
				return H;
			},
			set settleObserver(e) {
				H = e;
			},
			get settleScheduled() {
				return U;
			},
			set settleScheduled(e) {
				U = e;
			},
			get settleFrame() {
				return Ve;
			},
			set settleFrame(e) {
				Ve = e;
			},
			findScrollHost: He,
			readHostBox: Ue,
			onHostScroll: We,
			availableSize: W,
			layoutResult: G,
			measureBox: Ge,
			measureElementStyle: Ke,
			arrangeStyle: qe,
			elementStyle: Je,
			isRealized: Ye,
			backgroundStyle: Xe,
			rootStyle: Ze,
			wrapperForIndex: Qe,
			elementForIndex: $e,
			GetElementIndex: et,
			TryGetElement: tt,
			forcedIndices: K,
			GetOrCreateElement: nt,
			get realizedElements() {
				return q;
			},
			set realizedElements(e) {
				q = e;
			},
			dispatch: J,
			raiseRealizationEvents: rt,
			get measureToken() {
				return Y;
			},
			set measureToken(e) {
				Y = e;
			},
			get measureRunning() {
				return X;
			},
			set measureRunning(e) {
				X = e;
			},
			get measureQueued() {
				return Z;
			},
			set measureQueued(e) {
				Z = e;
			},
			MEASURE_PASSES: 2,
			VIRTUALIZE_THRESHOLD: 120,
			measureWindow: it,
			renderedIndices: at,
			readNaturals: ot,
			naturalsDiffer: st,
			runMeasure: ct,
			measureItems: Q,
			layoutSignature: lt,
			observeSettleTargets: ut,
			onGettingFocus: dt,
			onKeyDown: ft,
			dependencyProperty: $,
			publicItemsSourceView: pt,
			get CollectionItemTemplate() {
				return l;
			},
			get CollectionLayout() {
				return ne;
			},
			computed: p,
			defineComponent: ue,
			Fragment: f,
			getCurrentInstance: de,
			h: fe,
			inject: pe,
			nextTick: me,
			onBeforeUnmount: ge,
			onMounted: _e,
			provide: ve,
			ref: _,
			shallowReactive: ye,
			shallowRef: be,
			useAttrs: xe,
			useSlots: Se,
			watch: b,
			TextBlock: ie,
			get useAcrylicBrushStyle() {
				return e;
			},
			get vAcrylicBrush() {
				return ee;
			},
			get getCollectionProperty() {
				return re;
			},
			get getLayoutDescriptor() {
				return u;
			},
			get getVNodeChildren() {
				return d;
			},
			xamlResourceDictionaryKey: c,
			get computeRepeaterLayout() {
				return ae;
			},
			get measureBoxFor() {
				return oe;
			},
			get normalizeLayoutKind() {
				return se;
			},
			get materializeXamlVNode() {
				return t;
			},
			get normalizeXamlNodes() {
				return n;
			},
			get resolveXamlHandler() {
				return r;
			},
			get resolveXamlResourceObject() {
				return i;
			},
			get resolveXamlValue() {
				return a;
			},
			get xamlItemContextKey() {
				return o;
			},
			get xamlNameScopeKey() {
				return s;
			}
		};
		return Object.defineProperty(mt, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), mt;
	}
}), Ce = ["data-index"];
function C(e, t, n, r, i, a) {
	return x((g(), le("div", m({ ref: "rootRef" }, r.forwardedAttrs, {
		class: ["win-items-repeater", { "is-horizontal": r.layoutResult.horizontal }],
		style: r.rootStyle
	}), [(g(!0), le(f, null, v(r.renderedIndices, (e) => (g(), le("div", {
		key: r.itemKey(r.items[e], e),
		class: he(["win-items-repeater-element", { "is-realized": r.isRealized(e) }]),
		"data-index": e,
		style: h(r.elementStyle(e)),
		onFocusin: r.onGettingFocus,
		onKeydown: r.onKeyDown
	}, [(g(), ce(y(r.itemComponent(r.items[e], e))))], 46, Ce))), 128))], 16)), [[r.vAcrylicBrush, r.backgroundStyle]]);
}
var w = /*#__PURE__*/ te(S, [
	["render", C],
	["__scopeId", "data-v-94efc830"],
	["__file", "ItemsRepeater.vue"]
]);
//#endregion
export { w as default };

//# sourceMappingURL=ItemsRepeater.vue.js.map