//#region src/components/iconFont.ts
var e = [
	"Segoe Fluent Icons",
	"WinUIOnWebIcons",
	"WinUIOnWebFontIcons",
	"WinUIOnWebNavigationIcons",
	"WinUIOnWebSymbolIcons"
];
async function t(t, n) {
	let r = n ?? (typeof document > "u" ? void 0 : document);
	if (!r || typeof FontFace > "u" || !r.fonts) throw Error("FontFace API is not available in this environment");
	let i = typeof t == "string" || t instanceof URL ? `url(${JSON.stringify(new URL(String(t), r.baseURI).href)})` : t instanceof Blob ? await t.arrayBuffer() : t, a = e.map((e) => new FontFace(e, i, { display: "block" }));
	await Promise.all(a.map((e) => e.load()));
	for (let e of a) r.fonts.add(e);
	return () => {
		for (let e of a) r.fonts.delete(e);
	};
}
//#endregion
export { t as loadWinUIIconFont };

//# sourceMappingURL=iconFont.js.map