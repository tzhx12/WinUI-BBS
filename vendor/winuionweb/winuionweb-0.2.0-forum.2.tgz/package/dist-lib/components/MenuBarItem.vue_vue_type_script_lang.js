import { materializeXamlVNode as e, normalizeXamlNodes as t, resolveXamlValue as n, updateXamlBinding as r } from "./xamlRuntime.js";
import { frameworkLayoutStyle as i } from "./frameworkLayout.js";
import { useI18n as a } from "./i18n/index.js";
import { getVNodeChildren as o } from "./CollectionProperties.js";
import { menuBarContextKey as s, menuBarFlyoutEnabledKey as c, menuBarFlyoutNavigationKey as l } from "./menuBarContext.js";
import u from "./MenuFlyout.vue.js";
import { computed as d, defineComponent as f, getCurrentInstance as p, h as m, inject as h, isVNode as g, onBeforeUnmount as _, onMounted as v, provide as y, ref as b, watch as x } from "vue";
//#region src/components/MenuBarItem.vue?vue&type=script&lang.ts
var S = f({
	name: "MenuBarItem.Items",
	__menuBarItemProperty: "Items",
	setup: () => () => null
}), C = f({
	name: "MenuBarItem",
	__menuBarItem: !0,
	inheritAttrs: !1,
	props: {
		Title: {
			type: [
				String,
				Number,
				Object
			],
			default: void 0
		},
		Items: {
			type: [
				Array,
				Object,
				String
			],
			default: void 0
		},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		IsTabStop: {
			type: [Boolean, String],
			default: !0
		},
		Visibility: {
			type: String,
			default: "Visible"
		}
	},
	emits: [
		"update:Title",
		"update:Items",
		"update:IsEnabled",
		"update:IsTabStop",
		"update:Visibility"
	],
	setup(f, { attrs: S, slots: C, expose: w, emit: T }) {
		let E = p(), { t: D } = a(), O = h(s, null), k = b(null), A = b(null), j = b(), M = b(), N = b(), P = b(), F = d(() => j.value ?? (f.Title === void 0 ? D("MenuBarItemDefaultTitle") : n(f.Title, E))), I = d(() => O?.isEnabled() !== !1 && (M.value ?? ![
			!1,
			"False",
			"false"
		].includes(n(f.IsEnabled, E)))), L = d(() => N.value ?? ![
			!1,
			"False",
			"false"
		].includes(n(f.IsTabStop, E))), R = d(() => P.value ?? String(n(f.Visibility, E))), z = d(() => O?.isVisible() !== !1 && R.value !== "Collapsed"), B = b(!1), V = b(!1), H = b(!1), U = null, W = !1, G = 0, K = -1, q = -1, J = !1, Y = !1, X = "first", Z = {
			get Title() {
				return F.value;
			},
			set Title(e) {
				j.value = e, r(f.Title, e, E), T("update:Title", e);
			},
			get IsEnabled() {
				return I.value;
			},
			set IsEnabled(e) {
				M.value = e, r(f.IsEnabled, e, E), T("update:IsEnabled", e);
			},
			get IsTabStop() {
				return L.value;
			},
			set IsTabStop(e) {
				N.value = e, r(f.IsTabStop, e, E), T("update:IsTabStop", e);
			},
			get Visibility() {
				return R.value;
			},
			set Visibility(e) {
				P.value = e, r(f.Visibility, e, E), T("update:Visibility", e);
			},
			get Name() {
				return S["x:Name"] ?? S.Name ?? "";
			},
			get Items() {
				return A.value?.Items;
			},
			set Items(e) {
				A.value && (A.value.Items = e);
			},
			get Element() {
				return k.value;
			},
			Focus() {
				return !I.value || !z.value || !k.value ? !1 : (k.value.focus({ preventScroll: !0 }), !0);
			}
		}, Q = {
			api: Z,
			element: () => k.value,
			isEnabled: () => I.value,
			isVisible: () => z.value,
			isTabStop: () => L.value,
			hasItems: () => !!A.value?.Items?.Count,
			async open(e) {
				if (!I.value || !z.value || !k.value || !A.value || !A.value.Items?.Count) return;
				let t = ++G;
				X = e;
				let n = k.value;
				e === "none" && await new Promise((e) => requestAnimationFrame(() => e())), !(W || G !== t || !I.value || !z.value) && (await A.value.ShowAt(n, {
					Placement: "Bottom",
					Position: {
						X: 0,
						Y: n.offsetHeight
					},
					ExclusionRect: {
						X: 0,
						Y: 0,
						Width: n.offsetWidth,
						Height: n.offsetHeight
					}
				}), !(W || G !== t) && (B.value = !0));
			},
			close(e) {
				G++, B.value = !1, $(), A.value?.Hide(e);
			}
		};
		w(Z), y(l, (e) => O?.onFlyoutKeyDown(Q, e)), y(c, () => I.value && z.value);
		let $ = () => {
			H.value = !1, U !== null && k.value?.hasPointerCapture(U) && k.value.releasePointerCapture(U), U = null;
		}, ee = (e) => {
			!I.value || e.button !== 0 || (H.value = !0, Y = !1, U = e.pointerId, J = !0, k.value?.setPointerCapture(e.pointerId), k.value?.focus({ preventScroll: !0 }), O ? O.toggle(Q, "none") : B.value ? Q.close(!0) : Q.open("none"));
		}, te = (e) => {
			if ($(), e.detail !== 0 && Y) {
				Y = !1;
				return;
			}
			if (Y = !1, e.detail !== 0 && J) {
				J = !1;
				return;
			}
			J = !1, I.value && (O ? O.toggle(Q) : B.value ? Q.close(!0) : Q.open("first"));
		}, ne = () => {
			K = G, B.value = !0;
		}, re = () => {
			if (!(W || K !== G)) if (B.value = !0, X === "last") {
				let e = A.value?.Items;
				(e?.GetAt?.((e?.Count ?? 1) - 1))?.Element?.focus?.({ preventScroll: !0 });
			} else X === "none" && k.value?.focus({ preventScroll: !0 });
		}, ie = () => {
			q = ++G, B.value = !1, H.value = !1, O?.onItemClosed(Q);
		}, ae = () => {
			q === G && (B.value = !1, H.value = !1);
		};
		x(I, (e) => {
			e || (Q.close(!1), $());
		}), x(z, (e) => {
			e || (Q.close(!1), $(), V.value = !1);
		}), x(() => n(f.Title, E), () => {
			j.value = void 0;
		}), x(() => n(f.IsEnabled, E), () => {
			M.value = void 0;
		}), x(() => n(f.IsTabStop, E), () => {
			N.value = void 0;
		}), x(() => n(f.Visibility, E), () => {
			P.value = void 0;
		}), v(() => O?.register(Q)), _(() => {
			W = !0, $(), Q.close(!1), O?.unregister(Q);
		});
		let oe = () => {
			let n = t(C.default?.() ?? [], E), r = n.find((e) => e.type?.__menuBarItemProperty === "Items");
			return (r ? o(r) : n).filter(g).map((t) => e(t, void 0, E));
		}, se = () => {
			$();
		}, ce = () => {
			$(), V.value = !1, Y = !0, J = !1, Q.close(!1), O?.onItemClosed(Q);
		}, le = () => {
			let e = i({
				...S,
				...f
			}, E);
			return {
				"--menu-bar-item-background": e.background,
				"--menu-bar-item-foreground": n(S.Foreground, E),
				"--menu-bar-item-border-thickness": e.borderWidth,
				"--menu-bar-item-border-brush": e.borderColor,
				"--menu-bar-item-corner-radius": e.borderRadius
			};
		}, ue = () => i(Object.fromEntries(Object.entries({
			...S,
			...f,
			Visibility: R.value
		}).filter(([e]) => ![
			"Background",
			"Foreground",
			"BorderThickness",
			"BorderBrush",
			"CornerRadius"
		].includes(e))), E);
		return () => [m("div", {
			class: [
				"win-menu-bar-item",
				{
					"is-pointer-over": V.value,
					"is-pressed": H.value,
					"is-open": B.value,
					"is-disabled": !I.value
				},
				S.class
			],
			style: [
				ue(),
				le(),
				S.style
			],
			id: S["x:Name"] ?? S.id,
			role: "none"
		}, [m("div", { class: "win-menu-bar-item-content-root" }, [m("span", {
			class: "win-menu-bar-item-background",
			"aria-hidden": "true"
		}), m("button", {
			ref: k,
			class: "win-menu-bar-button",
			type: "button",
			role: "menuitem",
			disabled: !I.value,
			tabindex: O?.tabIndex(Q) ?? (I.value && z.value && L.value ? 0 : -1),
			"aria-haspopup": "menu",
			"aria-expanded": B.value,
			"aria-disabled": !I.value || void 0,
			"aria-label": n(S["AutomationProperties.Name"], E) ?? F.value,
			onFocus: () => O?.onItemFocus(Q),
			onPointerenter: (e) => {
				V.value = e.pointerType !== "touch", O?.onItemPointerEnter(Q, e);
			},
			onPointerleave: () => {
				V.value = !1;
			},
			onPointerdown: ee,
			onPointerup: se,
			onPointercancel: ce,
			onLostpointercapture: () => {
				H.value = !1, U = null;
			},
			onClick: te,
			onKeydown: (e) => O?.onItemKeyDown(Q, e)
		}, [m("span", { class: "win-menu-bar-item-content" }, String(F.value ?? ""))])])]), m(u, {
			ref: A,
			Items: f.Items === void 0 ? void 0 : n(f.Items, E),
			Placement: "Bottom",
			OverlayInputPassThroughElement: O?.element(),
			onOpening: ne,
			onOpened: re,
			onClosing: ie,
			onClosed: ae,
			"onUpdate:Items": (e) => {
				r(f.Items, e, E), T("update:Items", e);
			}
		}, { default: oe })];
	}
}), w = Object.assign(C, { Items: S });
//#endregion
export { S as MenuBarItemItemsProperty, w as default };

//# sourceMappingURL=MenuBarItem.vue_vue_type_script_lang.js.map