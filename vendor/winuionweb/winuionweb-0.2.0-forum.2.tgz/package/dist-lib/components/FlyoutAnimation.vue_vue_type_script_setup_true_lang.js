import { useFlyoutAnimation as e } from "./useFlyoutAnimation.js";
import { defineComponent as t, nextTick as n, onMounted as r, ref as i, watch as a } from "vue";
//#region src/components/FlyoutAnimation.vue?vue&type=script&setup=true&lang.ts
var o = /*@__PURE__*/ t({
	__name: "FlyoutAnimation",
	props: {
		Open: {
			type: Boolean,
			default: void 0
		},
		Autoplay: {
			type: Boolean,
			default: !0
		},
		Origin: {
			type: String,
			default: "edge"
		},
		Direction: {
			type: String,
			default: "top"
		},
		OriginElement: {
			type: [
				String,
				Object,
				Function
			],
			default: null
		},
		StartRect: {
			type: [Object, Function],
			default: null
		},
		Duration: {
			type: Number,
			default: 750
		},
		Easing: {
			type: String,
			default: "cubic-bezier(0.102, 0.700, 0.000, 1.007)"
		},
		Margin: {
			type: Number,
			default: 15
		},
		StripSize: {
			type: Number,
			default: 36
		},
		RespectReducedMotion: {
			type: Boolean,
			default: !0
		}
	},
	setup(t, { expose: o }) {
		let s = t, c = i(null), { play: l, cancel: u, isPlaying: d } = e(c, s);
		r(async () => {
			await n(), s.Autoplay && (s.Open === void 0 || s.Open === !0) && l();
		}), a(() => s.Open, (e) => {
			e !== void 0 && (e ? l() : u());
		}), o({
			play: l,
			cancel: u,
			isPlaying: d
		});
		let f = {
			props: s,
			rootRef: c,
			play: l,
			cancel: u,
			isPlaying: d
		};
		return Object.defineProperty(f, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), f;
	}
});
//#endregion
export { o as default };

//# sourceMappingURL=FlyoutAnimation.vue_vue_type_script_setup_true_lang.js.map