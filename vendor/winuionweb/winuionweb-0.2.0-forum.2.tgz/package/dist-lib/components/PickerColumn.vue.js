import { useAcrylicBrushStyle as e } from "./AcrylicBrush.js";
import { resolveXamlHandler as t, resolveXamlValue as n, updateXamlBinding as r, xamlScopeKey as i } from "./xamlRuntime.js";
import { vAcrylicBrush as ee } from "./acrylicBrushVisual.js";
import te from "../_virtual/_plugin-vue_export-helper.js";
import { useI18n as ne } from "./i18n/index.js";
import re from "./RepeatButton.vue.js";
/* empty css                                                                 */
import { Fragment as ie, computed as a, createElementBlock as o, createElementVNode as s, createVNode as c, getCurrentInstance as ae, mergeProps as l, nextTick as oe, normalizeClass as u, normalizeStyle as d, onBeforeUnmount as se, onMounted as ce, openBlock as f, provide as le, ref as p, renderList as m, toDisplayString as h, useAttrs as ue, watch as g, withCtx as _, withDirectives as v } from "vue";
//#region src/components/PickerColumn.vue
var y = 40, de = 5, b = /*@__PURE__*/ Object.assign({ inheritAttrs: !1 }, {
	__name: "PickerColumn",
	props: {
		Items: {
			type: [Array, String],
			default: () => []
		},
		SelectedIndex: {
			type: [Number, String],
			default: 0
		},
		ShouldLoop: {
			type: [Boolean, String],
			default: !0
		},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		AutomationName: {
			type: String,
			default: ""
		},
		UpLabel: {
			type: String,
			default: ""
		},
		DownLabel: {
			type: String,
			default: ""
		}
	},
	emits: ["update:SelectedIndex", "SelectionChanged"],
	setup(te, { expose: ie, emit: o }) {
		let s = te, c = o, l = ae(), u = e("{ThemeResource LoopingSelectorUpDownButtonBackground}", l), d = ue(), { t: f } = ne(), m = (e) => n(e, l), h = (e) => e === !0 || e === "True" || e === "true", _ = a(() => {
			let e = m(s.Items);
			return Array.isArray(e) ? e : [];
		}), v = a(() => h(m(s.ShouldLoop))), b = a(() => h(m(s.IsEnabled))), x = a(() => {
			let e = Number(m(s.SelectedIndex));
			return Number.isFinite(e) ? Math.max(0, Math.min(_.value.length - 1, Math.trunc(e))) : 0;
		}), fe = a(() => String(m(s.AutomationName) || "")), S = a(() => String(m(s.UpLabel) || f("control.loopingselector.previous"))), C = a(() => String(m(s.DownLabel) || f("control.loopingselector.next"))), pe = a(() => {
			let { class: e, style: t, SelectionChanged: n, ...r } = d;
			return r;
		}), me = y * 7, w = p(null), T = p(!1), E = p(null), he = p(null), D = p(x.value), O = p(me), k = a(() => Math.max(0, (O.value - y) / 2)), A = p(!1), j = p(-1), M = p(-1), ge = p(-1), _e = `looping-selector-${l?.uid ?? 0}`, ve = `${_e}-monochrome`, ye = (e, t) => ({
			empty: e === null,
			selected: A.value && t === j.value,
			hovered: t === M.value,
			pressed: t === ge.value
		}), be = a(() => j.value >= 0 ? `${_e}-item-${j.value}` : void 0), xe = a(() => b.value && _.value.length > 1 && (v.value || D.value > 0)), Se = a(() => b.value && _.value.length > 1 && (v.value || D.value < _.value.length - 1)), Ce = a(() => v.value ? _.value.length * de : _.value.length), we = a(() => Ce.value * y + k.value * 2), Te = a(() => ({
			height: `${we.value}px`,
			padding: `${k.value}px 0`
		})), Ee = a(() => ({
			clipPath: `inset(${k.value}px 0 ${k.value}px)`,
			filter: `url("#${ve}")`
		})), De = a(() => _.value.length ? Array.from({ length: Ce.value }, (e, t) => _.value[t % _.value.length] ?? null) : []), Oe = (e) => e == null ? "" : String(typeof e == "string" || typeof e == "number" ? e : e.PrimaryText ?? e.Text ?? ""), N = (e) => {
			let t = _.value.length;
			return t ? v.value ? (e % t + t) % t : Math.max(0, Math.min(t - 1, e)) : 0;
		}, ke = (e) => (v.value ? _.value.length * 2 : 0) + N(e), P = () => Math.round((E.value?.scrollTop ?? 0) / y), F = () => _.value.length ? N(P()) : 0, I = 0, L = 0, R = !1, z = null, B = x.value, V = null, H = 0, Ae = !1, U = null, je = [], W = () => {
			E.value && he.value && (he.value.style.transform = `translate3d(0, ${-E.value.scrollTop}px, 0)`);
		}, Me = () => {
			window.clearTimeout(L), L = 0;
		}, Ne = () => {
			cancelAnimationFrame(I), I = 0, R = !1, z = null;
		}, G = () => {
			Me(), Ne();
		}, Pe = (e) => {
			if (D.value = e, e === B) return;
			let n = B;
			B = e;
			let i = {
				RemovedItems: n >= 0 && n < _.value.length ? [_.value[n]] : [],
				AddedItems: _.value.length ? [_.value[e]] : [],
				OldSelectedIndex: n,
				SelectedIndex: e
			};
			r(s.SelectedIndex, e, l), c("update:SelectedIndex", e), c("SelectionChanged", Xe, i), t(d.SelectionChanged, l)?.(Xe, i);
		}, K = () => {
			let e = E.value, t = _.value.length;
			if (!e || !v.value || !t) return;
			let n = t * y;
			if (e.scrollTop < n || e.scrollTop >= n * 4) {
				let n = (e.scrollTop / y % t + t) % t;
				e.scrollTop = (t * 2 + n) * y;
			}
		}, Fe = () => {
			R = !1, I = 0, z = null, K(), W(), j.value = P(), A.value = !0, Pe(F());
		}, Ie = (e) => v.value ? Math.max(0, Math.min(Ce.value - 1, e)) : N(e), q = (e, t = 150) => {
			let n = E.value;
			if (!n || !_.value.length || !b.value) return;
			Me(), cancelAnimationFrame(I), z = Ie(e);
			let r = n.scrollTop, i = z * y;
			if (Math.abs(i - r) < .5) {
				n.scrollTop = i, Fe();
				return;
			}
			A.value = !1, R = !0;
			let ee = performance.now(), te = (e) => {
				let ne = Math.min(1, (e - ee) / t);
				n.scrollTop = r + (i - r) * (1 - (1 - ne) ** 3), W(), ne < 1 ? I = requestAnimationFrame(te) : Fe();
			};
			I = requestAnimationFrame(te);
		}, Le = () => {
			!E.value || !_.value.length || V || q(P(), 120);
		}, J = () => {
			Me(), !V && !R && (L = window.setTimeout(Le, 100));
		}, Y = (e) => {
			if (!_.value.length || !b.value || e < 0 && !xe.value || e > 0 && !Se.value) return;
			let t = (z ?? P()) + e;
			v.value && (t < _.value.length || t >= _.value.length * 4) ? (K(), q(P() + e)) : q(t);
		}, Re = () => {
			W(), !R && (A.value = !1, D.value = F(), V || (K(), W(), J()));
		}, ze = (e) => {
			if (!b.value || !_.value.length || !e.deltaY) return;
			e.preventDefault();
			let t = e.deltaMode === 1 ? e.deltaY * 16 : e.deltaMode === 2 ? e.deltaY * O.value : e.deltaY;
			if (Math.abs(t) >= y) {
				Y(t > 0 ? 1 : -1);
				return;
			}
			G(), A.value = !1, E.value.scrollTop += t, K(), W(), J();
		}, Be = (e) => {
			if (!b.value || e.altKey) return;
			let t = 0;
			if (e.key === "ArrowUp" ? t = -1 : e.key === "ArrowDown" && (t = 1), t) e.preventDefault(), Y(t);
			else if (e.key === "PageUp" || e.key === "PageDown") {
				e.preventDefault();
				let t = Math.max(1, Math.floor(O.value / y));
				q((z ?? P()) + (e.key === "PageUp" ? -t : t), 200);
			} else (e.key === "Home" || e.key === "End") && (e.preventDefault(), q(ke(e.key === "Home" ? 0 : _.value.length - 1), 200));
		}, Ve = (e) => {
			if (performance.now() < H || !b.value) return;
			let t = e.target.closest(".picker-item-slot[data-slot]");
			if (!t || !E.value?.contains(t)) return;
			let n = Number(t.dataset.slot);
			!Number.isFinite(n) || De.value[n] === null || q(n, Math.min(300, 150 + Math.abs(n - P()) * 20));
		}, He = (e) => {
			!b.value || !_.value.length || e.button !== 0 || V || E.value?.contains(e.target) && (G(), E.value.focus({ preventScroll: !0 }), V = {
				id: e.pointerId,
				type: e.pointerType,
				startY: e.clientY,
				startScroll: E.value.scrollTop,
				lastY: e.clientY,
				lastTime: performance.now(),
				velocity: 0,
				moved: !1,
				slot: Number(e.target.closest(".picker-item-slot[data-slot]")?.dataset.slot)
			}, ge.value = Number.isFinite(V.slot) ? V.slot : -1, E.value.setPointerCapture(e.pointerId));
		}, Ue = (e) => {
			let t = e.target.closest(".picker-item-slot[data-slot]");
			if (M.value = e.pointerType === "mouse" && t && E.value?.contains(t) ? Number(t.dataset.slot) : -1, !V || V.id !== e.pointerId || !E.value) return;
			let n = V.startY - e.clientY;
			if (!V.moved && Math.abs(n) < 4) return;
			e.preventDefault(), V.moved = !0, A.value = !1;
			let r = performance.now();
			V.velocity = (V.lastY - e.clientY) / Math.max(1, r - V.lastTime), V.lastY = e.clientY, V.lastTime = r, E.value.scrollTop = V.startScroll + n, W();
		}, X = (e = !1) => {
			if (ge.value = -1, (e || V?.type !== "mouse") && (M.value = -1), !V) return;
			let t = V;
			if (V = null, E.value?.hasPointerCapture(t.id) && E.value.releasePointerCapture(t.id), t.moved) {
				H = performance.now() + 250;
				let n = !e && performance.now() - t.lastTime < 100 ? t.velocity : 0, r = (E.value?.scrollTop ?? 0) + Math.max(-320, Math.min(320, n * 180));
				q(Math.round(r / y), Math.min(350, 150 + Math.abs(n) * 80));
			} else !e && Number.isFinite(t.slot) ? (H = performance.now() + 250, q(t.slot, Math.min(300, 150 + Math.abs(t.slot - P()) * 20))) : J();
		}, We = (e) => {
			V?.id === e.pointerId && X();
		}, Ge = (e) => {
			V?.id === e.pointerId && X(!0);
		}, Z = async () => {
			await oe(), !(Ae || !E.value) && (G(), E.value.scrollTop = ke(x.value) * y, D.value = x.value, B = x.value, j.value = P(), A.value = !0, W());
		}, Ke = () => {
			if (!E.value || !_.value.length) return x.value;
			let e = z;
			return X(!0), G(), E.value.scrollTop = Ie(e ?? P()) * y, Fe(), F();
		}, qe = () => E.value?.focus({ preventScroll: !0 }), Je = () => !!w.value?.contains(document.activeElement), Ye = () => {
			T.value = !1, M.value = -1, X(!0), Ke(), Q();
		}, Q = () => {
			for (let e of w.value?.querySelectorAll(".picker-arrow") ?? []) e.dispatchEvent(new PointerEvent("pointercancel", { bubbles: !1 }));
		}, $ = (e, t, n, r) => {
			e?.addEventListener(t, n, r), je.push(() => e?.removeEventListener(t, n, r));
		}, Xe = {
			SelectedIndex: D,
			Flush: Ke,
			GetSelectedIndex: F,
			GetPendingIndex: () => N(z ?? P()),
			Focus: qe,
			ContainsFocus: Je
		};
		le(i, {
			canScrollUp: xe,
			canScrollDown: Se,
			upLabel: S,
			downLabel: C,
			OnUpButtonClicked: () => Y(-1),
			OnDownButtonClicked: () => Y(1)
		}), ie(Xe), g([_, v], Z, { deep: !0 }), g(O, Z), g(x, (e) => {
			e !== B && Z();
		}), g(b, (e) => {
			e || (T.value = !1, M.value = -1, X(!0), G());
		}), g([S, C], () => {
			for (let e of w.value?.querySelectorAll(".picker-arrow") ?? []) e.setAttribute("aria-label", e.closest(".picker-arrow-up") ? S.value : C.value);
		}), ce(() => {
			U = new ResizeObserver((e) => {
				let t = e[0]?.contentRect.height;
				t && Math.abs(O.value - t) > .5 && (O.value = t);
			}), U.observe(w.value), O.value = w.value.clientHeight || me, $(w.value, "pointerenter", (e) => {
				T.value = b.value && e.pointerType !== "touch";
			}), $(w.value, "pointerleave", () => {
				T.value = !1;
			}), $(w.value, "pointerdown", (e) => {
				e.pointerType === "touch" && (T.value = !1, M.value = -1);
			}), $(w.value, "pointercancel", () => {
				T.value = !1;
			}), $(E.value, "scroll", Re, { passive: !0 }), $(E.value, "wheel", ze, { passive: !1 }), $(E.value, "keydown", Be), $(E.value, "click", Ve), $(E.value, "pointerdown", He), $(E.value, "pointermove", Ue, { passive: !1 }), $(E.value, "pointerleave", () => {
				M.value = -1;
			}), $(E.value, "pointerup", We), $(E.value, "pointercancel", Ge), $(E.value, "lostpointercapture", Ge), $(window, "blur", Ye), $(window, "pointerup", Q, !0), $(window, "pointercancel", Q), Z();
			let e = w.value?.querySelectorAll(".picker-arrow") ?? [];
			for (let t of e) t.setAttribute("aria-label", t.closest(".picker-arrow-up") ? S.value : C.value), $(t, "lostpointercapture", Q);
		}), se(() => {
			Ae = !0, V && E.value?.hasPointerCapture(V.id) && E.value.releasePointerCapture(V.id), V = null, U?.disconnect(), G();
			for (let e of je) e();
		});
		let Ze = {
			props: s,
			emit: c,
			instance: l,
			NavigationBackgroundStyle: u,
			attrs: d,
			t: f,
			resolve: m,
			booleanValue: h,
			items: _,
			shouldLoop: v,
			isEnabled: b,
			boundIndex: x,
			automationName: fe,
			upLabel: S,
			downLabel: C,
			rootAttrs: pe,
			ITEM_HEIGHT: y,
			VIEWPORT_HEIGHT: me,
			REPEAT_COUNT: de,
			rootEl: w,
			columnPointerOver: T,
			scrollEl: E,
			maskEl: he,
			localIndex: D,
			viewportHeight: O,
			centerOffset: k,
			settled: A,
			settledSlot: j,
			hoveredSlot: M,
			pressedSlot: ge,
			columnId: _e,
			overlayFilterId: ve,
			itemClasses: ye,
			activeItemId: be,
			canScrollUp: xe,
			canScrollDown: Se,
			slotCount: Ce,
			contentHeight: we,
			listStyle: Te,
			maskStyle: Ee,
			listItems: De,
			itemText: Oe,
			normalizedIndex: N,
			canonicalSlot: ke,
			selectedSlot: P,
			getSelectedIndex: F,
			get frameId() {
				return I;
			},
			set frameId(e) {
				I = e;
			},
			get snapTimer() {
				return L;
			},
			set snapTimer(e) {
				L = e;
			},
			get animating() {
				return R;
			},
			set animating(e) {
				R = e;
			},
			get targetSlot() {
				return z;
			},
			set targetSlot(e) {
				z = e;
			},
			get lastNotifiedIndex() {
				return B;
			},
			set lastNotifiedIndex(e) {
				B = e;
			},
			get pointer() {
				return V;
			},
			set pointer(e) {
				V = e;
			},
			get suppressClickUntil() {
				return H;
			},
			set suppressClickUntil(e) {
				H = e;
			},
			get disposed() {
				return Ae;
			},
			set disposed(e) {
				Ae = e;
			},
			get resizeObserver() {
				return U;
			},
			set resizeObserver(e) {
				U = e;
			},
			nativeListeners: je,
			syncMask: W,
			resetSettleTimer: Me,
			cancelAnimation: Ne,
			cancelMotion: G,
			notifySelection: Pe,
			rebase: K,
			finishMotion: Fe,
			clampSlot: Ie,
			animateTo: q,
			snap: Le,
			scheduleSnap: J,
			stepBy: Y,
			onScroll: Re,
			onWheel: ze,
			onKeyDown: Be,
			onItemClick: Ve,
			onPointerDown: He,
			onPointerMove: Ue,
			releasePointer: X,
			onPointerUp: We,
			onPointerCancel: Ge,
			jumpToSelected: Z,
			flush: Ke,
			focus: qe,
			containsFocus: Je,
			onWindowBlur: Ye,
			cancelArrowPresses: Q,
			bind: $,
			exposedApi: Xe,
			computed: a,
			getCurrentInstance: ae,
			nextTick: oe,
			onBeforeUnmount: se,
			onMounted: ce,
			provide: le,
			ref: p,
			useAttrs: ue,
			watch: g,
			RepeatButton: re,
			get useAcrylicBrushStyle() {
				return e;
			},
			get vAcrylicBrush() {
				return ee;
			},
			get resolveXamlHandler() {
				return t;
			},
			get resolveXamlValue() {
				return n;
			},
			get updateXamlBinding() {
				return r;
			},
			get xamlScopeKey() {
				return i;
			},
			get useI18n() {
				return ne;
			}
		};
		return Object.defineProperty(Ze, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), Ze;
	}
}), x = ["aria-label", "aria-activedescendant"], fe = ["data-slot"], S = [
	"id",
	"aria-hidden",
	"aria-selected"
];
function C(e, t, n, r, i, ee) {
	return f(), o("div", l({ ref: "rootEl" }, r.rootAttrs, {
		class: ["picker-col-root", [r.attrs.class, { "column-pointer-over": r.columnPointerOver }]],
		style: r.attrs.style
	}), [
		s("div", {
			ref: "scrollEl",
			class: "picker-col-scroll",
			tabindex: "0",
			role: "listbox",
			"aria-label": r.automationName,
			"aria-activedescendant": r.activeItemId
		}, [s("div", {
			class: "picker-list",
			style: d(r.listStyle)
		}, [(f(!0), o(ie, null, m(r.listItems, (e, t) => (f(), o("div", {
			key: t,
			class: "picker-item-slot",
			"data-slot": t
		}, [s("div", {
			id: `${r.columnId}-item-${t}`,
			class: u(["picker-item", r.itemClasses(e, t)]),
			role: "option",
			"aria-hidden": e === null,
			"aria-selected": r.settled && t === r.settledSlot
		}, h(e === null ? "" : r.itemText(e)), 11, S)], 8, fe))), 128))], 4)], 8, x),
		s("div", {
			class: "picker-mask",
			style: d(r.maskStyle),
			"aria-hidden": "true"
		}, [s("div", {
			ref: "maskEl",
			class: "picker-list picker-mask-list",
			style: d(r.listStyle)
		}, [(f(!0), o(ie, null, m(r.listItems, (e, t) => (f(), o("div", {
			key: t,
			class: "picker-item-slot"
		}, [s("div", { class: u(["picker-item picker-mask-item", r.itemClasses(e, t)]) }, h(e === null ? "" : r.itemText(e)), 3)]))), 128))], 4)], 4),
		s("svg", {
			class: "picker-filter",
			width: "0",
			height: "0",
			"aria-hidden": "true",
			focusable: "false"
		}, [s("defs", null, [s("filter", {
			id: r.overlayFilterId,
			x: "0",
			y: "0",
			width: "100%",
			height: "100%",
			"color-interpolation-filters": "sRGB"
		}, [...t[0] ||= [s("feFlood", {
			style: { "flood-color": "var(--picker-selected-foreground)" },
			result: "replacement"
		}, null, -1), s("feComposite", {
			in: "replacement",
			in2: "SourceAlpha",
			operator: "in"
		}, null, -1)]])])]),
		v((f(), o("div", {
			class: u(["picker-arrow-host picker-arrow-up", { "picker-arrow-unavailable": !r.canScrollUp }]),
			"data-xaml-background": "{ThemeResource LoopingSelectorUpDownButtonBackground}",
			style: d(r.NavigationBackgroundStyle)
		}, [c(r.RepeatButton, {
			class: "picker-arrow",
			Background: "Transparent",
			Foreground: "{ThemeResource LoopingSelectorUpDownButtonForeground}",
			Style: "{StaticResource DateTimePickerFlyoutLoopingSelectorNavigationButtonStyle}",
			IsEnabled: "{x:Bind canScrollUp, Mode=OneWay}",
			Content: "",
			FontFamily: "{ThemeResource SymbolThemeFontFamily}",
			FontSize: "8",
			Height: "34",
			Padding: "0",
			Margin: "0",
			BorderThickness: "0",
			CornerRadius: "0",
			IsTabStop: "False",
			Click: "OnUpButtonClicked"
		}, {
			default: _(() => [...t[1] ||= [s("span", {
				class: "picker-arrow-glyph",
				"aria-hidden": "true"
			}, "", -1)]]),
			_: 1
		})], 6)), [[
			r.vAcrylicBrush,
			r.NavigationBackgroundStyle,
			void 0,
			{ "host-backdrop": !0 }
		]]),
		v((f(), o("div", {
			class: u(["picker-arrow-host picker-arrow-down", { "picker-arrow-unavailable": !r.canScrollDown }]),
			"data-xaml-background": "{ThemeResource LoopingSelectorUpDownButtonBackground}",
			style: d(r.NavigationBackgroundStyle)
		}, [c(r.RepeatButton, {
			class: "picker-arrow",
			Background: "Transparent",
			Foreground: "{ThemeResource LoopingSelectorUpDownButtonForeground}",
			Style: "{StaticResource DateTimePickerFlyoutLoopingSelectorNavigationButtonStyle}",
			IsEnabled: "{x:Bind canScrollDown, Mode=OneWay}",
			Content: "",
			FontFamily: "{ThemeResource SymbolThemeFontFamily}",
			FontSize: "8",
			Height: "34",
			Padding: "0",
			Margin: "0",
			BorderThickness: "0",
			CornerRadius: "0",
			IsTabStop: "False",
			Click: "OnDownButtonClicked"
		}, {
			default: _(() => [...t[2] ||= [s("span", {
				class: "picker-arrow-glyph",
				"aria-hidden": "true"
			}, "", -1)]]),
			_: 1
		})], 6)), [[
			r.vAcrylicBrush,
			r.NavigationBackgroundStyle,
			void 0,
			{ "host-backdrop": !0 }
		]])
	], 16);
}
var pe = /*#__PURE__*/ te(b, [
	["render", C],
	["__scopeId", "data-v-80616b70"],
	["__file", "PickerColumn.vue"]
]);
//#endregion
export { pe as default };

//# sourceMappingURL=PickerColumn.vue.js.map