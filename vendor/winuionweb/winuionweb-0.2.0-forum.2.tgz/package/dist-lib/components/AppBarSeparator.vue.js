import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./AppBarSeparator.vue_vue_type_script_setup_true_lang.js";
import { createCommentVNode as n, createElementBlock as r, createElementVNode as i, mergeProps as a, openBlock as o } from "vue";
//#region src/components/AppBarSeparator.vue
var s = [
	"aria-orientation",
	"tabindex",
	"data-application-view-state"
];
function c(e, t, c, l, u, d) {
	return l.visible ? (o(), r("div", a({
		key: 0,
		ref: "rootRef"
	}, l.attrs, {
		class: ["win-appbar-separator", {
			"is-compact": l.compact,
			"is-overflow": l.inOverflow
		}],
		style: l.separatorStyle,
		role: "separator",
		"aria-orientation": l.inOverflow ? "horizontal" : "vertical",
		tabindex: l.isTabStop ? 0 : void 0,
		"data-application-view-state": l.inOverflow ? "Overflow" : l.compact ? "Compact" : "FullSize"
	}), [...t[0] ||= [i("span", {
		class: "appbar-separator-rectangle",
		"aria-hidden": "true"
	}, null, -1)]], 16, s)) : n("", !0);
}
var l = /*#__PURE__*/ e(t, [["render", c], ["__file", "AppBarSeparator.vue"]]);
//#endregion
export { l as default };

//# sourceMappingURL=AppBarSeparator.vue.js.map