import { defineComponent as e } from "vue";
//#region src/components/appBarRuntime.ts
var t = Symbol("WinUI.CommandBar"), n = Symbol("WinUI.AppBarToggleButton"), r = (t, n) => e({
	name: `${t}.${n}`,
	__appBarButtonProperty: n,
	setup() {
		return () => null;
	}
}), i = (e) => e === !0 || e === "True";
//#endregion
export { i as appBarBoolean, r as appBarProperty, n as appBarToggleContextKey, t as commandBarContextKey };

//# sourceMappingURL=appBarRuntime.js.map