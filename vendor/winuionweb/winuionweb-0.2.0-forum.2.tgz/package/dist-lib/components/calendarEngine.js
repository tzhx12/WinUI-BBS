//#region src/components/calendarEngine.ts
var e = 864e5, t = (t) => {
	let n = /* @__PURE__ */ new Date(0);
	return n.setUTCFullYear(t.getFullYear(), t.getMonth(), t.getDate()), n.setUTCHours(0, 0, 0, 0), Math.floor(n.getTime() / e);
}, n = (t) => {
	let n = /* @__PURE__ */ new Date(t * e), r = /* @__PURE__ */ new Date(0);
	return r.setFullYear(n.getUTCFullYear(), n.getUTCMonth(), n.getUTCDate()), r.setHours(0, 0, 0, 0), r;
}, r = (e) => {
	if (e == null || e === "") return null;
	let t = e instanceof Date || typeof e == "number" ? new Date(e) : new Date(String(e));
	return Number.isNaN(t.getTime()) ? null : t;
}, i = {
	GregorianCalendar: "gregory",
	HebrewCalendar: "hebrew",
	HijriCalendar: "islamic-civil",
	JapaneseCalendar: "japanese",
	JulianCalendar: "gregory",
	KoreanCalendar: "gregory",
	PersianCalendar: "persian",
	TaiwanCalendar: "roc",
	ThaiCalendar: "buddhist",
	UmAlQuraCalendar: "islamic-umalqura"
}, a = (e) => {
	let t = e + 2440588 + 32082, n = Math.floor((4 * t + 3) / 1461), r = t - Math.floor(1461 * n / 4), i = Math.floor((5 * r + 2) / 153);
	return {
		year: n - 4800 + Math.floor(i / 10),
		month: i + 3 - 12 * Math.floor(i / 10),
		day: r - Math.floor((153 * i + 2) / 5) + 1
	};
}, o = (e, t) => {
	let n = 0, r = e.length;
	for (; n < r;) {
		let i = n + r >>> 1;
		e[i].start <= t ? n = i + 1 : r = i;
	}
	return Math.max(0, Math.min(e.length - 1, n - 1));
}, s = (t, n, r, s) => {
	let c = i[t] ?? "gregory", l = n;
	try {
		new Intl.DateTimeFormat(l).format();
	} catch {
		l = "en-US";
	}
	let u = (e, t = !1) => new Intl.DateTimeFormat(t ? "en-US" : l, {
		calendar: c,
		timeZone: "UTC",
		...t ? { numberingSystem: "latn" } : {},
		...e
	}), d = u({
		day: "numeric",
		month: "numeric",
		year: "numeric"
	}, !0), f = u({ month: "short" }), p = u({
		year: "numeric",
		...c === "japanese" ? { era: "short" } : {}
	}), m = u({
		era: "short",
		year: "numeric"
	}, !0), h = u({
		month: "long",
		year: "numeric",
		...c === "japanese" ? { era: "short" } : {}
	}), g = u({
		weekday: "long",
		year: "numeric",
		month: "long",
		day: "numeric"
	}), _ = u({ weekday: "long" }), v = /* @__PURE__ */ new Map(), y = new Intl.NumberFormat(l, { useGrouping: !1 }), b = t === "JulianCalendar", x = t === "KoreanCalendar", S = [
		"gregory",
		"japanese",
		"roc",
		"buddhist"
	].includes(c) && !b, C = /* @__PURE__ */ new Map(), w = (t) => {
		let n = C.get(t);
		if (n) return n;
		let r;
		if (b) {
			let e = a(t);
			r = {
				year: e.year,
				month: String(e.month),
				day: e.day
			};
		} else if (S) {
			let n = /* @__PURE__ */ new Date(t * e);
			r = {
				year: n.getUTCFullYear(),
				month: String(n.getUTCMonth() + 1),
				day: n.getUTCDate()
			};
		} else {
			let n = d.formatToParts(/* @__PURE__ */ new Date(t * e)), i = (e) => n.find((t) => t.type === e)?.value ?? "";
			r = {
				year: Number.parseInt(i("year") || i("relatedYear")),
				month: i("month"),
				day: Number.parseInt(i("day"))
			};
		}
		return C.set(t, r), r;
	}, T = (t) => {
		if (!b) return /* @__PURE__ */ new Date(t * e);
		let n = a(t), r = /* @__PURE__ */ new Date(0);
		return r.setUTCFullYear(n.year, n.month - 1, n.day), r.setUTCHours(0, 0, 0, 0), r;
	}, E = (e) => x ? y.format(w(e).year + 2333) : p.format(T(e)), D = (e) => f.format(T(e)), O = (e) => x ? h.formatToParts(T(e)).map((t) => t.type === "year" ? y.format(w(e).year + 2333) : t.value).join("") : h.format(T(e)), k = (t, n) => {
		let r = u(n);
		if (!x && !b) return r.format(T(t));
		let i = n.weekday ? u({ weekday: n.weekday }).format(/* @__PURE__ */ new Date(t * e)) : "";
		return r.formatToParts(T(t)).map((e) => e.type === "year" && x ? y.format(w(t).year + 2333) : e.type === "weekday" && b ? i : e.value).join("");
	}, A = [], j = [], M = "", N = r - w(r).day + 1;
	for (; N <= s;) {
		let t = w(N), n = N + 35, r = n - w(n).day + 1;
		if (r <= N) throw RangeError("The calendar does not provide increasing month boundaries.");
		let i = c === "japanese" ? m.format(/* @__PURE__ */ new Date(N * e)) : String(t.year);
		if (c === "japanese" && i !== m.format(/* @__PURE__ */ new Date((r - 1) * 864e5))) {
			let e = N + 1, t = r - 1;
			for (; e < t;) {
				let n = Math.floor((e + t) / 2);
				m.format(/* @__PURE__ */ new Date(n * 864e5)) === i ? e = n + 1 : t = n;
			}
			r = e;
		}
		let a = j[j.length - 1];
		(!a || M !== i) && (a = {
			index: j.length,
			start: N,
			end: r - 1,
			number: t.year,
			firstMonth: A.length,
			lastMonth: A.length,
			text: E(N)
		}, j.push(a), M = i);
		let o = {
			index: A.length,
			start: N,
			end: r - 1,
			year: t.year,
			yearIndex: a.index,
			month: t.month,
			text: D(N),
			label: E(N)
		};
		A.push(o), a.lastMonth = o.index, a.end = o.end, N = r;
	}
	return {
		identifier: t,
		language: l,
		minimum: r,
		maximum: s,
		months: A,
		years: j,
		monthAt: (e) => A[o(A, e)],
		yearAt: (e) => j[o(j, e)],
		dayNumber: (e) => y.format(w(e).day),
		day: (e) => w(e).day,
		headerText: O,
		yearText: E,
		monthText: D,
		formatSelectedDate: k,
		fullDateText: (t) => {
			let n = _.format(/* @__PURE__ */ new Date(t * e));
			return g.formatToParts(T(t)).map((e) => e.type === "weekday" ? n : e.type === "year" && x ? y.format(w(t).year + 2333) : e.value).join("");
		},
		weekdayText: (t, n) => {
			let r = n.match(/abbreviated\((\d+)\)/i), i = /abbreviated/i.test(n) ? "short" : "long", a = v.get(i);
			a || (a = u({ weekday: i }), v.set(i, a));
			let o = a.format(/* @__PURE__ */ new Date(t * e));
			return r ? [...o].slice(0, Number(r[1])).join("") : o;
		},
		displayYear: (e) => x ? e.number + 2333 : c === "buddhist" ? e.number + 543 : c === "roc" ? e.number - 1911 : Number.parseInt(d.formatToParts(/* @__PURE__ */ new Date(e.start * 864e5)).find((e) => e.type === "year")?.value ?? String(e.number)),
		formatNumber: (e) => y.format(e)
	};
};
//#endregion
export { n as calendarDateFromSerial, t as calendarDateSerial, s as createCalendarModel, r as parseCalendarDate };

//# sourceMappingURL=calendarEngine.js.map