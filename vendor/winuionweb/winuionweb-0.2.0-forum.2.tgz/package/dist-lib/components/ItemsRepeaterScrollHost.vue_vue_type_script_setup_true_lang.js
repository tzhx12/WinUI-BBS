import { alignment as e, cssLength as t, xamlThickness as n } from "./layout.js";
import { resolveXamlValue as r } from "./xamlRuntime.js";
import { computed as i, defineComponent as a, getCurrentInstance as o } from "vue";
//#region src/components/ItemsRepeaterScrollHost.vue?vue&type=script&setup=true&lang.ts
var s = /*@__PURE__*/ a({
	inheritAttrs: !1,
	__name: "ItemsRepeaterScrollHost",
	props: {
		HorizontalAnchorRatio: {
			type: [String, Number],
			default: NaN
		},
		VerticalAnchorRatio: {
			type: [String, Number],
			default: NaN
		},
		Width: {
			type: [String, Number],
			default: ""
		},
		Height: {
			type: [String, Number],
			default: ""
		},
		Margin: {
			type: [String, Number],
			default: ""
		},
		HorizontalAlignment: {
			type: String,
			default: "Stretch"
		},
		VerticalAlignment: {
			type: String,
			default: "Stretch"
		},
		Visibility: {
			type: String,
			default: "Visible"
		}
	},
	setup(a, { expose: s }) {
		s();
		let c = a, l = o(), u = {
			props: c,
			instance: l,
			hostStyle: i(() => {
				let i = t(r(c.Width, l)), a = t(r(c.Height, l)), o = {
					minWidth: "0",
					minHeight: "0",
					boxSizing: "border-box",
					width: i || void 0,
					height: a || void 0,
					margin: n(r(c.Margin, l)) || void 0
				}, s = r(c.HorizontalAlignment, l) ?? c.HorizontalAlignment, u = r(c.VerticalAlignment, l) ?? c.VerticalAlignment;
				s && (o.justifySelf = e(s, "horizontal")), u && (o.alignSelf = e(u, "vertical")), s === "Stretch" && !i && (o.flexGrow = "1", o.flexShrink = "1", o.flexBasis = "0%");
				let d = r(c.Visibility, l) ?? c.Visibility;
				return d === "Collapsed" ? o.display = "none" : d === "Hidden" && (o.visibility = "hidden"), o;
			})
		};
		return Object.defineProperty(u, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), u;
	}
});
//#endregion
export { s as default };

//# sourceMappingURL=ItemsRepeaterScrollHost.vue_vue_type_script_setup_true_lang.js.map