import { defineComponent as e } from "vue";
//#region src/components/inlineControlProperties.ts
var t = e({
	name: "ComboBoxItem",
	__xamlComboBoxItem: !0,
	setup() {
		return () => null;
	}
}), n = e({
	name: "x:String",
	__xamlString: !0,
	setup() {
		return () => null;
	}
}), r = e({
	name: "Slider.Header",
	__sliderHeaderProperty: !0,
	setup() {
		return () => null;
	}
});
//#endregion
export { t as ComboBoxItem, r as SliderHeaderProperty, n as XamlString };

//# sourceMappingURL=inlineControlProperties.js.map