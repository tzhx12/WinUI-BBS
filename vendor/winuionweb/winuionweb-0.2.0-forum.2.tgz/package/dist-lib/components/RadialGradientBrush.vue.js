import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./RadialGradientBrush.vue_vue_type_script_lang.js";
//#region src/components/RadialGradientBrush.vue
var n = /*#__PURE__*/ e(t, [["__file", "RadialGradientBrush.vue"]]);
//#endregion
export { n as default };

//# sourceMappingURL=RadialGradientBrush.vue.js.map