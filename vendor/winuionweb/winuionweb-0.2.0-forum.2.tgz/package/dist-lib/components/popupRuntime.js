//#region src/components/popupRuntime.ts
var e = (e) => {
	if (e instanceof HTMLElement) return e;
	if (!e || typeof e != "object") return null;
	let t = e, n = t.$el ?? t.Element ?? t.value;
	return n instanceof HTMLElement ? n : null;
}, t = (e, t, n, r) => ({
	left: e,
	top: t,
	right: Math.max(e, n),
	bottom: Math.max(t, r),
	width: Math.max(0, n - e),
	height: Math.max(0, r - t)
}), n = (e, n = !0) => {
	let r = window.visualViewport, i = r?.offsetLeft ?? 0, a = r?.offsetTop ?? 0, o = t(i, a, i + (r?.width ?? window.innerWidth), a + (r?.height ?? window.innerHeight)), s = document.fullscreenElement, c = s && e && s.contains(e) ? s : n ? e?.closest("[data-xaml-root]") : null;
	if (!c) return o;
	let l = c.getBoundingClientRect();
	return t(Math.max(o.left, l.left), Math.max(o.top, l.top), Math.min(o.right, l.right), Math.min(o.bottom, l.bottom));
}, r = (e, t, n) => ({
	left: Math.max(n.left, Math.min(e.left, n.right - t.width)),
	top: Math.max(n.top, Math.min(e.top, n.bottom - t.height))
}), i = (e) => e.startsWith("Top") ? "Top" : e.startsWith("Bottom") ? "Bottom" : e.startsWith("Left") ? "Left" : e.startsWith("Right") ? "Right" : "Auto", a = (e) => {
	let t = {
		Top: "Bottom",
		Bottom: "Top",
		Left: "Right",
		Right: "Left"
	}, n = i(e);
	return `${t[n] ?? "Bottom"}${e.slice(n.length)}`;
}, o = (e, t, n, r) => {
	let a = i(n), o = {
		left: e.left + (e.width - t.width) / 2,
		top: e.top + (e.height - t.height) / 2
	};
	return a === "Top" && (o.top = e.top - t.height - r), a === "Bottom" && (o.top = e.bottom + r), a === "Left" && (o.left = e.left - t.width - r), a === "Right" && (o.left = e.right + r), a === "Top" || a === "Bottom" ? (n.endsWith("Left") && (o.left = e.left), n.endsWith("Right") && (o.left = e.right - t.width)) : (a === "Left" || a === "Right") && (n.endsWith("Top") && (o.top = e.top), n.endsWith("Bottom") && (o.top = e.bottom - t.height)), o;
}, s = (e, t, n, s, c = 0, l = !1) => {
	let u = n === "Auto" ? "Bottom" : n;
	if (u === "Full") return {
		left: s.left,
		top: s.top,
		placement: u
	};
	l && (u = u.replace(/Left|Right/g, (e) => e === "Left" ? "Right" : "Left"));
	let d = i(u), f = o(e, t, u, c);
	if ((d === "Top" || d === "Bottom" ? f.top >= s.top && f.top + t.height <= s.bottom : f.left >= s.left && f.left + t.width <= s.right) && t.width <= s.width && t.height <= s.height) return {
		...r(f, t, s),
		placement: u
	};
	let p = d === "Top" || d === "Bottom" ? ["Left", "Right"] : ["Top", "Bottom"], m = [...new Set([
		u,
		a(u),
		...p
	])], h = {
		...o(e, t, u, c),
		placement: u
	}, g = -1;
	for (let n of m) {
		let r = o(e, t, n, c), i = Math.max(0, Math.min(r.left + t.width, s.right) - Math.max(r.left, s.left)), a = Math.max(0, Math.min(r.top + t.height, s.bottom) - Math.max(r.top, s.top)), l = i * a;
		if (l > g && (h = {
			...r,
			placement: n
		}, g = l), i >= t.width && a >= t.height) break;
	}
	return {
		...r(h, t, s),
		placement: h.placement
	};
};
//#endregion
export { r as fitPopupPosition, n as popupBoundsFor, s as popupPlacementPosition, e as resolvePopupElement };

//# sourceMappingURL=popupRuntime.js.map