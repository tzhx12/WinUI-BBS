import { normalizeXamlNodes as e, resolveXamlResourceObject as t, resolveXamlValue as n, xamlTemplateComponent as r } from "./xamlRuntime.js";
import { xamlResourceDictionaryKey as i } from "./Page.vue_vue_type_script_lang.js";
import { Comment as a, Fragment as o, Text as s, defineComponent as c, h as l, isVNode as u } from "vue";
//#region src/components/PivotProperties.ts
var d = (e, t) => c({
	name: `${e}.${t[0].toUpperCase()}${t.slice(1)}`,
	__pivotPropertyOwner: e,
	__pivotProperty: t,
	setup: () => () => null
}), f = d("Pivot", "items"), p = d("Pivot", "itemTemplate"), m = d("Pivot", "itemsPanel"), h = d("Pivot", "title"), g = d("Pivot", "titleTemplate"), _ = d("Pivot", "headerTemplate"), v = d("Pivot", "leftHeader"), y = d("Pivot", "leftHeaderTemplate"), b = d("Pivot", "rightHeader"), x = d("Pivot", "rightHeaderTemplate"), S = d("PivotItem", "header"), C = d("PivotItem", "content"), w = d("PivotItem", "contentTemplate"), T = {
	Items: f,
	ItemTemplate: p,
	ItemsPanel: m,
	Title: h,
	TitleTemplate: g,
	HeaderTemplate: _,
	LeftHeader: v,
	LeftHeaderTemplate: y,
	RightHeader: b,
	RightHeaderTemplate: x
}, E = {
	Header: S,
	Content: C,
	ContentTemplate: w
}, D = (e) => typeof e.type == "string" ? e.type : e.type.name ?? e.type.__name ?? "", O = (e) => e.flatMap((e) => e.type === a || e.type === s && !String(e.children ?? "").trim() ? [] : e.type === o && Array.isArray(e.children) ? O(e.children) : [e]), k = (e) => {
	if (Array.isArray(e.children)) return O(e.children);
	let t = e.children;
	return O(t?.default?.() ?? []);
}, A = (e, t) => {
	let n = e.type;
	return n?.__pivotPropertyOwner === t ? n.__pivotProperty : void 0;
}, j = (e, t, n) => {
	let r = e.find((e) => A(e, t) === n);
	return r ? k(r) : [];
}, M = (e) => typeof e == "string" || typeof e == "number" ? String(e) : "", N = (e, r) => {
	let a = typeof e == "string" ? e.match(/^\{(?:StaticResource|ThemeResource)\s+([^}]+)\}$/)?.[1] : void 0;
	return a ? r?.provides?.[i]?.[a.trim()] ?? t(a.trim(), r) : n(e, r);
}, P = (t, n, i, a) => {
	let o = N(n, a), s = i.length ? i : u(o) ? [o] : Array.isArray(o) ? o.filter(u) : [];
	return s.length ? r(s.flatMap((e) => D(e) === "DataTemplate" ? k(e) : [e]), t, a) : typeof o == "object" && o || typeof o == "function" ? l(o, {
		Content: t,
		DataContext: t
	}) : u(t) ? e([t], a) : M(t) || null;
}, F = (t, n, r, i, a) => n.length ? !r && !i.length ? l(o, e(n, a)) : P(n.length === 1 ? n[0] : l(o, n), r, i, a) : P(t, r, i, a), I = (e, t) => {
	let r = Object.fromEntries(Object.entries(e).filter(([e]) => !["class", "style"].includes(e) && (!/^[A-Z]|^x:/.test(e) || /^[A-Z]\w*\./.test(e))));
	return e["AutomationProperties.Name"] && (r["aria-label"] = n(e["AutomationProperties.Name"], t)), e["AutomationProperties.HeadingLevel"] && (r.role = "heading", r["aria-level"] = Number(String(n(e["AutomationProperties.HeadingLevel"], t)).replace("Level", ""))), r;
}, L = Symbol("WinUIonWeb.PivotItem"), R = Symbol("WinUIonWeb.PivotItemIdentity");
//#endregion
export { w as PivotItemContentTemplate, A as getPivotProperty, k as pivotChildren, L as pivotItemContextKey, R as pivotItemIdentityKey, E as pivotItemProperties, O as pivotNodes, T as pivotProperties, j as pivotPropertyChildren, I as pivotRootAttributes, N as pivotTemplate, M as pivotText, D as pivotTypeName, F as renderPivotPresenter };

//# sourceMappingURL=PivotProperties.js.map