import { boolValue as e, cssLength as t, xamlThickness as n } from "./layout.js";
import { xamlThemeKey as r } from "./brushCore.js";
import { useAcrylicBrushStyle as i } from "./AcrylicBrush.js";
import { normalizeXamlNodes as a, resolveXamlHandler as o, resolveXamlResourceObject as s, resolveXamlValue as c, updateXamlBinding as l, xamlColor as u, xamlScopeKey as d, xamlTemplateComponent as f } from "./xamlRuntime.js";
import { vAcrylicBrush as p } from "./acrylicBrushVisual.js";
import { vThemeShadow as m } from "./themeShadowVisual.js";
import { registerToolTip as h, toolTipOwnerContextKey as ee } from "./toolTipRuntime.js";
import { ToolTipContent as g, ToolTipContentTemplate as _, ToolTipContentTransitions as v, isToolTipContentProperty as y } from "./ToolTipServiceProperties.js";
import { xamlResourceDictionaryKey as te } from "./Page.vue_vue_type_script_lang.js";
import ne from "./TextBlock.vue.js";
import { Fragment as re, computed as b, defineComponent as ie, getCurrentInstance as ae, h as oe, inject as se, isVNode as ce, nextTick as le, onBeforeUnmount as ue, onMounted as de, provide as fe, ref as x, unref as pe, useAttrs as me, useSlots as he, watch as S } from "vue";
var C = /*@__PURE__*/ ie({
	Content: g,
	ContentTemplate: _,
	ContentTransitions: v,
	name: "ToolTip",
	inheritAttrs: !1,
	__name: "ToolTip",
	props: {
		Content: {
			type: [
				String,
				Number,
				Object
			],
			default: ""
		},
		ContentTemplate: {
			type: [
				String,
				Object,
				Function
			],
			default: null
		},
		ContentTransitions: {
			type: [
				String,
				Object,
				Array
			],
			default: null
		},
		IsOpen: {
			type: [Boolean, String],
			default: !1
		},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		Placement: {
			type: String,
			default: "Top"
		},
		PlacementTarget: {
			type: [Object, String],
			default: null
		},
		PlacementRect: {
			type: [Object, String],
			default: null
		},
		HorizontalOffset: {
			type: [String, Number],
			default: void 0
		},
		VerticalOffset: {
			type: [String, Number],
			default: void 0
		},
		Background: {
			type: [String, Object],
			default: "{ThemeResource ToolTipBackgroundBrush}"
		},
		Foreground: {
			type: [String, Object],
			default: "{ThemeResource ToolTipForegroundBrush}"
		},
		BorderBrush: {
			type: [String, Object],
			default: "{ThemeResource ToolTipBorderBrush}"
		},
		BorderThickness: {
			type: [String, Number],
			default: 1
		},
		Padding: {
			type: [String, Number],
			default: "9,6,9,8"
		},
		FontFamily: {
			type: String,
			default: "{ThemeResource ContentControlThemeFontFamily}"
		},
		FontSize: {
			type: [String, Number],
			default: 12
		},
		MaxWidth: {
			type: [String, Number],
			default: 320
		},
		MaxHeight: {
			type: [String, Number],
			default: ""
		},
		Width: {
			type: [String, Number],
			default: ""
		},
		Height: {
			type: [String, Number],
			default: ""
		},
		CornerRadius: {
			type: [String, Number],
			default: "{ThemeResource ControlCornerRadius}"
		},
		BackgroundSizing: {
			type: String,
			default: "InnerBorderEdge"
		},
		HorizontalContentAlignment: {
			type: String,
			default: "Left"
		},
		VerticalContentAlignment: {
			type: String,
			default: "Top"
		},
		RequestedTheme: {
			type: String,
			default: "Default"
		}
	},
	emits: [
		"update:IsOpen",
		"Opened",
		"Closed"
	],
	setup(g, { expose: _, emit: v }) {
		let C = g, ge = v, w = ae(), _e = me(), ve = he(), T = se(ee, null), ye = se(d, {}), be = se("winuiTheme", null), xe = se(te, null), Se = x(null), E = x(null), Ce = `tooltip-${w?.uid ?? Math.random().toString(36).slice(2)}`, D = x(!1), O = x(!1), k = x({
			top: 0,
			left: 0
		}), A = x({
			width: 320,
			height: 1e4
		}), we = x("Top"), Te = x(null), j = () => Se.value?.ownerDocument ?? T?.owner.value?.ownerDocument ?? document, M = () => j().defaultView ?? window, N = x(), Ee = x("none"), De = x(null), P = x(""), F = (e) => c(e, w), I = b(() => e(F(C.IsEnabled))), Oe = b(() => e(F(C.IsOpen))), L = b(() => I.value && (N.value ?? Oe.value)), R = b(() => F(C.Content)), z = b(() => {
			let e = R.value;
			return e == null ? "" : String(typeof e == "object" ? e.Content ?? "" : e);
		});
		fe(d, {
			...ye,
			ToolTipText: z
		});
		let ke = b(() => ve.default?.() ?? []), B = b(() => ke.value.flatMap((e) => e.type?.__toolTipProperty ? [] : y(e) ? e.children?.default?.() ?? [] : [e])), V = b(() => ke.value.flatMap((e) => e.type?.__toolTipProperty === "ContentTemplate" ? e.children?.default?.() ?? [] : [])), Ae = b(() => {
			let e = C.ContentTemplate, t = typeof e == "string" ? e.match(/^\{(?:StaticResource|ThemeResource)\s+([^\s}]+)\}$/)?.[1] ?? e.match(/^var\(--([^,)]+)\)$/)?.[1] : void 0;
			return t ? s(t, w) ?? xe?.[t] : F(e);
		}), H = b(() => !!(V.value.length || Ae.value)), U = (e) => e && typeof e == "object" && ("render" in e || "setup" in e), je = b(() => ce(R.value) || !!U(R.value)), Me = (e) => e.flatMap((e) => e.type?.name === "DataTemplate" ? e.children?.default?.() ?? [] : [e]), Ne = ie({ setup: () => () => {
			if (V.value.length) return f(Me(V.value), R.value, w);
			let e = Ae.value;
			return typeof e == "function" ? e(R.value) : ce(e) ? f(Me([e]), R.value, w) : U(e) ? oe(e, { Content: R.value }) : ce(R.value) ? oe(re, a([R.value], w)) : U(R.value) ? oe(R.value) : oe(re, a(B.value, w));
		} }), Pe = b(() => String(F(_e["AutomationProperties.FullDescription"]) ?? "")), W = b(() => {
			let e = String(F(C.RequestedTheme)).toLowerCase();
			return e === "light" || e === "dark" ? e : String(T?.theme.value || P.value || pe(be) || "").toLowerCase();
		}), Fe = b(() => ["light", "dark"].includes(W.value) ? `win-theme-scope theme-${W.value}` : "");
		fe(r, W), fe("winuiTheme", W);
		let Ie = (e) => {
			let t = F(e);
			return u(t && typeof t == "object" ? t.Color : t);
		}, Le = i(() => C.Background, w), Re = (e) => ({
			Left: "flex-start",
			Top: "flex-start",
			Center: "center",
			Right: "flex-end",
			Bottom: "flex-end",
			Stretch: "stretch"
		})[String(F(e))] ?? "flex-start", ze = b(() => ({
			position: "fixed",
			top: `${k.value.top}px`,
			left: `${k.value.left}px`,
			visibility: O.value ? "visible" : "hidden",
			...Le.value,
			color: Ie(C.Foreground),
			borderColor: Ie(C.BorderBrush),
			borderWidth: n(F(C.BorderThickness)),
			padding: n(F(C.Padding)),
			fontFamily: String(F(C.FontFamily)),
			fontSize: t(F(C.FontSize)),
			width: t(F(C.Width)) || void 0,
			height: t(F(C.Height)) || void 0,
			maxWidth: `min(${t(F(C.MaxWidth)) || "320px"}, ${A.value.width}px)`,
			maxHeight: C.MaxHeight ? `min(${t(F(C.MaxHeight))}, ${A.value.height}px)` : `${A.value.height}px`,
			borderRadius: t(F(C.CornerRadius)),
			alignItems: Re(C.VerticalContentAlignment),
			justifyContent: Re(C.HorizontalContentAlignment),
			backgroundClip: F(C.BackgroundSizing) === "InnerBorderEdge" ? "padding-box" : "border-box"
		}));
		function Be(e) {
			let t = pe(e);
			if (t && typeof t == "object" && t.nodeType === 1) return t;
			if (typeof t == "string") {
				let e = j(), n = e.querySelector(`[data-xaml-ref="${M().CSS.escape(t)}"]`);
				if (n) return n;
				try {
					return e.querySelector(t);
				} catch {
					return null;
				}
			}
			if (t && typeof t == "object") {
				let e = t;
				for (let n of [
					e.Element,
					e.$el,
					e.value
				]) if (n !== void 0 && n !== t) {
					let e = Be(n);
					if (e) return e;
				}
			}
			return null;
		}
		function Ve() {
			let e = T?.owner.value ?? null;
			return Be(e?.getAttribute("tooltipservice.placementtarget")) ?? Be(F(C.PlacementTarget)) ?? e;
		}
		function He(e) {
			let t = F(C.PlacementRect);
			if (!t) return null;
			let n = typeof t == "string" ? t.split(",").map(Number) : null, r = typeof t == "object" ? t : null;
			if (n && (n.length !== 4 || n.some((e) => !Number.isFinite(e)))) return null;
			let i = n ? n[0] : Number(r?.X ?? r?.x ?? 0), a = n ? n[1] : Number(r?.Y ?? r?.y ?? 0), o = n ? n[2] : Number(r?.Width ?? r?.width ?? 0), s = n ? n[3] : Number(r?.Height ?? r?.height ?? 0);
			if (!(o > 0 && s > 0)) return null;
			let c = e.getBoundingClientRect(), l = e.ownerDocument.defaultView ?? M(), u = new l.DOMMatrix(), d = e, f = !0;
			for (; d;) {
				let e = l.getComputedStyle(d), t = e.transform === "none" ? new l.DOMMatrix() : new l.DOMMatrix(e.transform);
				if (!t.is2D) {
					f = !1;
					break;
				}
				let n = Number(e.zoom) || 1;
				u = new l.DOMMatrix([
					t.a * n,
					t.b * n,
					t.c * n,
					t.d * n,
					0,
					0
				]).multiply(u), d = d.parentElement;
			}
			let p = (e, t, n, r) => [
				[e, t],
				[e + n, t],
				[e + n, t + r],
				[e, t + r]
			].map(([e, t]) => u.transformPoint(new l.DOMPoint(e, t)));
			if (f && e.offsetWidth > 0 && e.offsetHeight > 0) {
				let t = p(0, 0, e.offsetWidth, e.offsetHeight), n = c.left - Math.min(...t.map((e) => e.x)), r = c.top - Math.min(...t.map((e) => e.y)), l = p(i, a, o, s);
				return {
					left: n + Math.min(...l.map((e) => e.x)),
					top: r + Math.min(...l.map((e) => e.y)),
					right: n + Math.max(...l.map((e) => e.x)),
					bottom: r + Math.max(...l.map((e) => e.y))
				};
			}
			let m = e.offsetWidth > 0 ? c.width / e.offsetWidth : 1, h = e.offsetHeight > 0 ? c.height / e.offsetHeight : 1;
			return {
				left: c.left + i * m,
				top: c.top + a * h,
				right: c.left + (i + o) * m,
				bottom: c.top + (a + s) * h
			};
		}
		function Ue() {
			let e = M(), t = e.visualViewport;
			return {
				left: t?.offsetLeft ?? 0,
				top: t?.offsetTop ?? 0,
				right: (t?.offsetLeft ?? 0) + (t?.width ?? e.innerWidth),
				bottom: (t?.offsetTop ?? 0) + (t?.height ?? e.innerHeight)
			};
		}
		let We = (e, t, n) => Math.max(t, Math.min(Math.max(t, n), e));
		async function G() {
			await le();
			let e = E.value, t = Ve();
			if (!e || !t || !t.isConnected) return;
			Q();
			let n = Ue(), r = Math.max(0, n.right - n.left), i = Math.max(0, n.bottom - n.top);
			(A.value.width !== r || A.value.height !== i) && (A.value = {
				width: r,
				height: i
			}, await le());
			let a = e.getBoundingClientRect(), o = T?.inputMode.value ?? Ee.value, s = T?.point.value ?? De.value, c = T?.owner.value?.getAttribute("tooltipservice.placement") || String(F(C.Placement)), l = [
				"Top",
				"Bottom",
				"Left",
				"Right",
				"Mouse"
			].includes(c) ? c : "Top", u = s && (o === "mouse" || o === "touch") ? {
				left: s.x,
				right: s.x,
				top: s.y + (o === "touch" ? -5 : 0),
				bottom: s.y + (o === "touch" ? -5 : 0)
			} : null, d = He(t) ?? u ?? t.getBoundingClientRect(), f = o === "mouse" ? 20 : o === "touch" ? 44 : o === "keyboard" ? 12 : 0, p = C.HorizontalOffset === void 0 ? f : Number(F(C.HorizontalOffset)) || 0, m = C.VerticalOffset === void 0 ? f : Number(F(C.VerticalOffset)) || 0, h = (t.ownerDocument.defaultView ?? M()).getComputedStyle(t).direction === "rtl", ee = (d.left + d.right - a.width) / 2, g = (d.top + d.bottom - a.height) / 2, _ = {
				Top: {
					left: ee,
					top: d.top - m - a.height
				},
				Bottom: {
					left: ee,
					top: d.bottom + m
				},
				Left: {
					left: d.left - p - a.width,
					top: g
				},
				Right: {
					left: d.right + p,
					top: g
				}
			}, v = l === "Mouse" ? "Top" : l, y;
			l === "Mouse" && s && o !== "keyboard" ? y = {
				left: h ? s.x - a.width : s.x + (Number(F(C.HorizontalOffset)) || 0),
				top: s.y + 11 + (Number(F(C.VerticalOffset)) || 0)
			} : (h && (v === "Right" || v === "Left") && (v = v === "Right" ? "Left" : "Right"), v = {
				Top: [
					"Top",
					"Bottom",
					"Right",
					"Left"
				],
				Bottom: [
					"Bottom",
					"Top",
					"Right",
					"Left"
				],
				Left: [
					"Left",
					"Right",
					"Top",
					"Bottom"
				],
				Right: [
					"Right",
					"Left",
					"Top",
					"Bottom"
				]
			}[v].find((e) => {
				let t = _[e];
				return e === "Top" || e === "Bottom" ? a.width <= r && t.top >= n.top && t.top + a.height <= n.bottom : a.height <= i && t.left >= n.left && t.left + a.width <= n.right;
			}) ?? v, y = _[v]), k.value = {
				left: We(y.left, n.left, n.right - a.width),
				top: We(y.top, n.top, n.bottom - a.height)
			}, we.value = l === "Mouse" && o !== "keyboard" ? "Mouse" : v, O.value = !0;
		}
		let K = null, q = 0, J, Y = null, X;
		function Ge(e, t = !1) {
			if (typeof e.showPopover != "function") {
				e.removeAttribute("popover");
				return;
			}
			if (e.matches(":popover-open")) {
				if (!t) return;
				e.hidePopover();
			}
			e.setAttribute("popover", "manual");
			try {
				e.showPopover();
			} catch {
				e.removeAttribute("popover");
			}
		}
		function Ke(e) {
			e && typeof e.hidePopover == "function" && e.matches(":popover-open") && e.hidePopover();
		}
		function Z(e) {
			N.value = e, l(C.IsOpen, e, w), ge("update:IsOpen", e);
		}
		function qe(e = !0) {
			M().clearTimeout(J), !(!I.value || !z.value && !B.value.length && !H.value && !je.value) && (e ? Z(!0) : J = M().setTimeout(() => Z(!0), 800));
		}
		function Je() {
			M().clearTimeout(J), Z(!1);
		}
		function Ye(e) {
			let t = w?.exposeProxy ?? w?.proxy;
			ge(e, t, {}), o(_e[e], w)?.(t, {});
		}
		function Q() {
			let e = Ve()?.closest(".theme-light, .theme-dark");
			P.value = e?.classList.contains("theme-dark") ? "dark" : e?.classList.contains("theme-light") ? "light" : "", T && (T.theme.value = P.value);
		}
		async function Xe(e) {
			let t = ++q, n = D.value && E.value ? M().getComputedStyle(E.value).opacity : "0";
			if (K?.cancel(), K = null, e && (D.value = !0, O.value = !1, Q(), await le(), t !== q || !L.value || (E.value && Ge(E.value, !0), await G(), t !== q || !L.value))) return;
			let r = E.value;
			if (!r) return;
			let i = M().matchMedia("(prefers-reduced-motion: reduce)").matches ? 1 : 167;
			K = r.animate([{ opacity: n }, { opacity: +!!e }], {
				duration: i,
				easing: "linear",
				fill: "forwards"
			});
			try {
				await K.finished;
			} catch {
				return;
			}
			t === q && (r.style.opacity = e ? "1" : "0", K.cancel(), K = null, e || (Ke(r), D.value = !1, O.value = !1), Ye(e ? "Opened" : "Closed"));
		}
		S(Oe, () => {
			N.value = void 0;
		}), S(L, Xe, { immediate: !0 }), S([
			R,
			H,
			() => C.Placement,
			() => C.PlacementRect,
			() => C.PlacementTarget,
			() => C.HorizontalOffset,
			() => C.VerticalOffset
		], () => {
			D.value && G();
		}, { deep: !0 }), S([() => pe(be), () => F(C.RequestedTheme)], () => {
			D.value && G();
		}, { flush: "post" });
		let Ze = {
			Open(e, t) {
				Ee.value = e, De.value = t ?? null, T && (T.inputMode.value = e, T.point.value = t ?? null), Q(), qe();
			},
			Close: Je,
			IsOpen: () => L.value,
			IsEnabled: () => I.value && !!(z.value || B.value.length || H.value || je.value),
			Element: () => E.value,
			UpdatePosition: G
		};
		S(() => T?.owner.value, (e) => {
			X?.(), X = e && T?.attached !== !1 ? h(e, Ze) : void 0, e && Q();
		}, {
			immediate: !0,
			flush: "post"
		});
		function $() {
			D.value && (Q(), G());
		}
		function Qe() {
			let e = j();
			Te.value = e.fullscreenElement || e.body, le(() => {
				D.value && E.value && Ge(E.value, !0), $();
			});
		}
		function $e() {
			Y?.disconnect();
			let e = Ve();
			e && Y?.observe(e), E.value && Y?.observe(E.value);
		}
		S([
			E,
			() => T?.owner.value,
			() => C.PlacementTarget
		], $e, { flush: "post" }), de(() => {
			let e = j(), t = M();
			Te.value = e.fullscreenElement || e.body, t.addEventListener("resize", $), t.addEventListener("scroll", $, !0), t.visualViewport?.addEventListener("resize", $), t.visualViewport?.addEventListener("scroll", $), e.addEventListener("fullscreenchange", Qe), t.ResizeObserver && (Y = new t.ResizeObserver($), $e()), L.value && G();
		}), ue(() => {
			let e = j(), t = M();
			q += 1, t.clearTimeout(J), K?.cancel(), Ke(E.value), X?.(), Y?.disconnect(), t.removeEventListener("resize", $), t.removeEventListener("scroll", $, !0), t.visualViewport?.removeEventListener("resize", $), t.visualViewport?.removeEventListener("scroll", $), e.removeEventListener("fullscreenchange", Qe);
		}), _({
			Controller: Ze,
			IsOpen: b({
				get: () => L.value,
				set: Z
			}),
			TemplateSettings: {
				FromHorizontalOffset: 0,
				FromVerticalOffset: 0
			},
			show: qe,
			hide: Je,
			updatePosition: G
		});
		let et = {
			props: C,
			emit: ge,
			instance: w,
			attrs: _e,
			slots: ve,
			ownerContext: T,
			inheritedXamlScope: ye,
			inheritedTheme: be,
			pageResources: xe,
			hostRef: Se,
			tooltipRef: E,
			tooltipId: Ce,
			present: D,
			positioned: O,
			position: k,
			bounds: A,
			actualPlacement: we,
			teleportTarget: Te,
			ownerDocument: j,
			ownerWindow: M,
			localIsOpen: N,
			automaticInput: Ee,
			pointer: De,
			automaticTheme: P,
			value: F,
			isEnabled: I,
			boundIsOpen: Oe,
			isVisible: L,
			content: R,
			ToolTipText: z,
			propertyNodes: ke,
			contentNodes: B,
			templateNodes: V,
			contentTemplate: Ae,
			hasContentTemplate: H,
			isComponent: U,
			hasVisualContent: je,
			unwrapTemplate: Me,
			ContentOutlet: Ne,
			fullDescription: Pe,
			effectiveTheme: W,
			themeClass: Fe,
			brush: Ie,
			backgroundStyle: Le,
			contentAlignment: Re,
			tooltipStyle: ze,
			elementFrom: Be,
			targetElement: Ve,
			placementRect: He,
			viewportBounds: Ue,
			clamp: We,
			updatePosition: G,
			get animation() {
				return K;
			},
			set animation(e) {
				K = e;
			},
			get transitionSequence() {
				return q;
			},
			set transitionSequence(e) {
				q = e;
			},
			get openTimer() {
				return J;
			},
			set openTimer(e) {
				J = e;
			},
			get resizeObserver() {
				return Y;
			},
			set resizeObserver(e) {
				Y = e;
			},
			get unregister() {
				return X;
			},
			set unregister(e) {
				X = e;
			},
			enterTopLayer: Ge,
			leaveTopLayer: Ke,
			setOpen: Z,
			show: qe,
			hide: Je,
			raise: Ye,
			syncTheme: Q,
			changeVisibility: Xe,
			controller: Ze,
			onViewportChanged: $,
			onFullscreenChanged: Qe,
			observeLayout: $e,
			TextBlock: ne,
			get vAcrylicBrush() {
				return p;
			},
			get vThemeShadow() {
				return m;
			}
		};
		return Object.defineProperty(et, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), et;
	}
});
//#endregion
export { C as default };

//# sourceMappingURL=ToolTip.vue_vue_type_script_setup_true_lang.js.map