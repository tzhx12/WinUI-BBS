import e from "../_virtual/_plugin-vue_export-helper.js";
import "./RefreshProperties.js";
import t from "./RefreshVisualizer.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                                      */
import { createElementBlock as n, createVNode as r, mergeProps as i, openBlock as a } from "vue";
//#region src/components/RefreshVisualizer.vue
function o(e, t, o, s, c, l) {
	return a(), n("div", i({
		ref: "rootRef",
		class: "win-refresh-visualizer"
	}, s.rootAttrs, {
		style: s.rootStyle,
		"aria-hidden": "true"
	}), [r(s.ContentOutlet)], 16);
}
var s = /*#__PURE__*/ e(t, [
	["render", o],
	["__scopeId", "data-v-49fb03bc"],
	["__file", "RefreshVisualizer.vue"]
]);
//#endregion
export { s as default };

//# sourceMappingURL=RefreshVisualizer.vue.js.map