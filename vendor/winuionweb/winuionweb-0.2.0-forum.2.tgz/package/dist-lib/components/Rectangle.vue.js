import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./Rectangle.vue_vue_type_script_setup_true_lang.js";
/* empty css                                              */
import { createBlock as n, createCommentVNode as r, createElementBlock as i, mergeProps as a, openBlock as o, withDirectives as s } from "vue";
//#region src/components/Rectangle.vue
function c(e, t, c, l, u, d) {
	return s((o(), i("div", a({
		ref: "root",
		class: "win-rectangle",
		style: l.rectangleStyle
	}, l.forwardedAttrs), [l.usesOutline ? (o(), n(l.OutlineVisual, { key: 0 })) : l.radialFill ? (o(), n(l.RadialGradientVisual, {
		key: 1,
		Brush: l.radialFill
	}, null, 8, ["Brush"])) : r("", !0)], 16)), [[l.vAcrylicBrush, l.rectangleStyle]]);
}
var l = /*#__PURE__*/ e(t, [["render", c], ["__file", "Rectangle.vue"]]);
//#endregion
export { l as default };

//# sourceMappingURL=Rectangle.vue.js.map