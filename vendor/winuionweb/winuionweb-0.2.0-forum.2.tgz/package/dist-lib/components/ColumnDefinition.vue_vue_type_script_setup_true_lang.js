import { gridDefinitionContextKey as e } from "./layout.js";
import { resolveXamlValue as t } from "./xamlRuntime.js";
import { defineComponent as n, getCurrentInstance as r, inject as i, onBeforeUnmount as a, reactive as o, watchEffect as s } from "vue";
//#region src/components/ColumnDefinition.vue?vue&type=script&setup=true&lang.ts
var c = /*@__PURE__*/ n({
	__name: "ColumnDefinition",
	props: {
		Width: {
			type: [String, Number],
			default: "*"
		},
		MinWidth: {
			type: [String, Number],
			default: ""
		},
		MaxWidth: {
			type: [String, Number],
			default: ""
		}
	},
	setup(n, { expose: c }) {
		c();
		let l = n, u = i(e, null), d = r(), f = o({});
		s(() => {
			f.Width = t(l.Width, d) ?? "*", f.MinWidth = t(l.MinWidth, d), f.MaxWidth = t(l.MaxWidth, d);
		});
		let p = u?.registerDefinition("columns", f);
		a(() => p?.());
		let m = {
			props: l,
			context: u,
			instance: d,
			definition: f,
			unregister: p
		};
		return Object.defineProperty(m, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), m;
	}
});
//#endregion
export { c as default };

//# sourceMappingURL=ColumnDefinition.vue_vue_type_script_setup_true_lang.js.map