import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./MediaPlayerElement.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                       */
import { createBlock as n, createCommentVNode as r, createElementBlock as i, createElementVNode as a, createVNode as o, normalizeClass as s, normalizeStyle as c, openBlock as l, resolveComponent as u, withCtx as d } from "vue";
//#region src/components/MediaPlayerElement.vue
var f = ["src"], p = [
	"poster",
	"src",
	"autoplay"
];
function m(e, t, m, h, g, _) {
	let v = u("Setter"), y = u("Style");
	return l(), i("div", {
		ref: "rootRef",
		class: s(["win-media-player-element", {
			"is-full-window": h.isFullWindowActive,
			"is-disabled": !h.isEnabled
		}]),
		style: c(h.rootStyle),
		onPointermove: h.showControls,
		onPointerleave: h.onRootExited,
		onPointerdownCapture: h.onRootPressed,
		onPointerup: h.onRootReleased,
		onPointercancel: h.onRootReleased,
		onKeydown: h.onTransportKeyDown,
		onKeyup: h.onTransportKeyUp,
		onLostpointercapture: h.onRootCaptureLost
	}, [o(h.Grid, {
		class: "win-media-player-surface",
		"data-template-part": "LayoutRoot"
	}, {
		default: d(() => [
			o(h.Border, {
				class: "win-media-player-transparent-border",
				Background: "Transparent",
				"data-template-part": "BackgroundBorder"
			}),
			h.posterUri ? (l(), i("img", {
				key: 0,
				class: "win-media-player-poster-fallback",
				src: h.posterUri,
				style: c(h.videoStyle),
				"data-template-part": "PosterImage",
				alt: ""
			}, null, 12, f)) : r("", !0),
			a("video", {
				ref: h.setVideoElement,
				class: s(["win-media-player-video", { "is-media-error": h.mediaError }]),
				"data-template-part": "MediaPlayerPresenter",
				poster: h.posterUri,
				src: h.playbackUri || void 0,
				autoplay: h.autoPlayEnabled,
				crossorigin: "anonymous",
				preload: "metadata",
				style: c(h.videoStyle),
				playsinline: "",
				onLoadedmetadata: h.syncFromVideo,
				onTimeupdate: h.syncFromVideo,
				onDurationchange: h.syncFromVideo,
				onVolumechange: h.syncFromVideo,
				onRatechange: h.syncOptionalPlaybackState,
				onEmptied: h.onMediaEmptied,
				onLoadeddata: h.onMediaLoaded,
				onError: h.onMediaError,
				onWaiting: h.onBufferingStarted,
				onCanplay: h.onBufferingEnded,
				onPlaying: h.onBufferingEnded,
				onPlay: h.onPlay,
				onPause: h.onPause,
				onEnded: h.onEnded
			}, null, 46, p),
			o(h.TransportControls, null, {
				default: d(() => [h.areTransportControlsEnabled ? (l(), n(h.Grid, {
					key: 0,
					class: s(["win-media-transport-controls", {
						visible: h.controlsVisible,
						"is-media-loading": h.isMediaLoading,
						"is-media-error": h.mediaError,
						"is-media-buffering": h.isBuffering,
						"is-compact": h.isCompact
					}]),
					"data-template-part": "TransportControlsPresenter"
				}, {
					default: d(() => [o(h.Border, {
						ref: h.setControlPanelElement,
						class: "win-media-transport-panel",
						"data-template-part": "ControlPanel_ControlPanelVisibilityStates_Border",
						Background: "{ThemeResource MediaTransportControlsPanelBackground}",
						BorderBrush: "{ThemeResource MediaTransportControlsBorderBrush}",
						BorderThickness: "1",
						CornerRadius: "{ThemeResource OverlayCornerRadius}",
						Margin: "12",
						PointerEntered: "onControlPanelEntered",
						PointerExited: "onControlPanelExited",
						PointerPressed: "onControlPanelPressed",
						PointerReleased: "onControlPanelReleased",
						PointerCanceled: "onControlPanelReleased",
						PointerCaptureLost: "onControlPanelCaptureLost",
						GotFocus: "onControlPanelFocusEntered",
						LostFocus: "onControlPanelFocusExited"
					}, {
						default: d(() => [o(h.Grid, {
							class: "win-media-control-panel-grid",
							"data-template-part": "ControlPanelGrid",
							Height: "{x:Bind controlPanelHeight, Mode=OneWay}",
							Padding: "{x:Bind controlPanelPadding, Mode=OneWay}"
						}, {
							default: d(() => [
								o(h.Grid.ColumnDefinitions, null, {
									default: d(() => [
										o(h.ColumnDefinition, { Width: "Auto" }),
										o(h.ColumnDefinition, { Width: "*" }),
										o(h.ColumnDefinition, { Width: "Auto" })
									]),
									_: 1
								}),
								o(h.Grid.RowDefinitions, null, {
									default: d(() => [
										o(h.RowDefinition, { Height: "Auto" }),
										o(h.RowDefinition, { Height: "*" }),
										o(h.RowDefinition, { Height: "Auto" })
									]),
									_: 1
								}),
								o(h.Border, {
									class: s(["win-media-error", { visible: h.mediaError }]),
									"data-template-part": "ErrorBorder",
									"Grid.ColumnSpan": "3",
									Width: "320",
									Height: "96",
									HorizontalAlignment: "Center",
									Background: "{ThemeResource MediaTransportControlsPanelBackground}",
									role: "alert"
								}, {
									default: d(() => [o(h.TextBlock, {
										"data-template-part": "ErrorTextBlock",
										Text: "{x:Bind mediaErrorText, Mode=OneWay}",
										Style: "{StaticResource CaptionTextBlockStyle}",
										TextWrapping: "WrapWholeWords",
										Margin: "12"
									})]),
									_: 1
								}, 8, ["class"]),
								h.isSeekBarVisible ? (l(), n(h.Border, {
									key: 0,
									class: "win-media-timeline-border",
									"data-template-part": "MediaTransportControls_Timeline_Border",
									"Grid.Column": "1",
									"Grid.Row": "1"
								}, {
									default: d(() => [o(h.Grid, {
										class: "win-media-timeline-grid",
										"data-template-part": "MediaTransportControls_Timeline_Grid"
									}, {
										default: d(() => [
											o(h.Grid.ColumnDefinitions, null, {
												default: d(() => [o(h.ColumnDefinition, { Width: "*" })]),
												_: 1
											}),
											o(h.Grid.RowDefinitions, null, {
												default: d(() => [o(h.RowDefinition, { Height: "*" }), o(h.RowDefinition, { Height: "Auto" })]),
												_: 1
											}),
											o(h.Grid, { class: "win-media-progress-host" }, {
												default: d(() => [o(h.Border, {
													class: "win-media-progress-slider",
													Margin: "{x:Bind progressSliderMargin, Mode=OneWay}"
												}, {
													default: d(() => [o(h.Slider, {
														"data-template-part": "ProgressSlider",
														Value: "{x:Bind currentTime, Mode=OneWay}",
														Minimum: "0",
														Maximum: "{x:Bind seekMaximum, Mode=OneWay}",
														SmallChange: "1",
														StepFrequency: "0.01",
														IsThumbToolTipEnabled: "False",
														IsEnabled: "{x:Bind canSeek, Mode=OneWay}",
														MinWidth: "80",
														HorizontalAlignment: "Stretch",
														Height: "32",
														VerticalAlignment: "Center",
														ValueChanged: "seekTo"
													})]),
													_: 1
												}), h.isBuffering || h.isMediaLoading ? (l(), n(h.Border, {
													key: 0,
													class: "win-media-loading-progress"
												}, {
													default: d(() => [o(h.ProgressBar, {
														"data-template-part": "BufferingProgressBar",
														IsIndeterminate: "True",
														ShowPaused: "False",
														IsHitTestVisible: "False",
														HorizontalAlignment: "Stretch",
														Height: "4"
													})]),
													_: 1
												})) : r("", !0)]),
												_: 1
											}),
											o(h.Grid, {
												class: "win-media-time-text-grid",
												"data-template-part": "TimeTextGrid",
												"Grid.Row": "1",
												Height: "16",
												Margin: "7,0,7,2",
												Visibility: "{x:Bind timeTextVisibility, Mode=OneWay}"
											}, {
												default: d(() => [o(h.TextBlock, {
													"data-template-part": "TimeElapsedElement",
													Text: "{x:Bind elapsedTimeText, Mode=OneWay}",
													Style: "{StaticResource CaptionTextBlockStyle}",
													Margin: "0",
													HorizontalAlignment: "Left",
													VerticalAlignment: "Bottom"
												}), o(h.TextBlock, {
													"data-template-part": "TimeRemainingElement",
													Text: "{x:Bind remainingTimeText, Mode=OneWay}",
													Style: "{StaticResource CaptionTextBlockStyle}",
													HorizontalAlignment: "Right",
													VerticalAlignment: "Bottom"
												})]),
												_: 1
											})
										]),
										_: 1
									})]),
									_: 1
								})) : r("", !0),
								o(h.Border, {
									class: "win-media-left-side-play-border",
									"data-template-part": "LeftSidePlayBorder",
									"Grid.Column": "0",
									"Grid.Row": "1",
									Visibility: "{x:Bind compactPlayVisibility, Mode=OneWay}"
								}, {
									default: d(() => [o(h.AppBarButton, {
										class: "win-media-appbar-button",
										"data-template-part": "PlayPauseButtonOnLeft",
										Style: "{StaticResource AppBarButtonStyle}",
										Margin: "0",
										VerticalAlignment: "Center",
										IsEnabled: "{x:Bind canPlay, Mode=OneWay}",
										"AutomationProperties.Name": "{x:Bind playLabel, Mode=OneWay}",
										"ToolTipService.ToolTip": "{x:Bind playLabel, Mode=OneWay}",
										Click: "togglePlay",
										Width: "40",
										Height: "40",
										MinWidth: "40",
										MinHeight: "40",
										LabelPosition: "Collapsed",
										AllowFocusOnInteraction: "True"
									}, {
										default: d(() => [o(h.AppBarButton.Icon, null, {
											default: d(() => [o(h.FontIcon, {
												class: "win-media-glyph",
												Glyph: "{x:Bind playGlyph, Mode=OneWay}"
											})]),
											_: 1
										})]),
										_: 1
									})]),
									_: 1
								}),
								o(h.Border, {
									class: "win-media-command-border",
									"data-template-part": "MediaTransportControls_Command_Border",
									"Grid.Column": "{x:Bind commandColumn, Mode=OneWay}",
									"Grid.Row": "{x:Bind commandRow, Mode=OneWay}"
								}, {
									default: d(() => [o(h.Grid, {
										class: "win-media-command-bar",
										"data-template-part": "MediaControlsCommandBar",
										Margin: "{x:Bind commandBarMargin, Mode=OneWay}",
										role: "toolbar",
										"AutomationProperties.Name": "{x:Bind transportControlsLabel, Mode=OneWay}"
									}, {
										default: d(() => [
											o(h.Grid.ColumnDefinitions, null, {
												default: d(() => [
													o(h.ColumnDefinition, { Width: "Auto" }),
													o(h.ColumnDefinition, { Width: "*" }),
													o(h.ColumnDefinition, { Width: "Auto" })
												]),
												_: 1
											}),
											o(h.StackPanel, {
												class: "win-media-command-left",
												Orientation: "Horizontal"
											}, {
												default: d(() => [h.isVolumeButtonVisible ? (l(), n(h.AppBarButton, {
													key: 0,
													class: "win-media-appbar-button",
													"data-template-part": "VolumeMuteButton",
													Style: "{StaticResource AppBarButtonStyle}",
													IsEnabled: "{x:Bind canChangeVolume, Mode=OneWay}",
													"AutomationProperties.Name": "{x:Bind volumeLabel, Mode=OneWay}",
													"ToolTipService.ToolTip": "{x:Bind volumeLabel, Mode=OneWay}",
													Width: "40",
													Height: "40",
													MinWidth: "40",
													MinHeight: "40",
													LabelPosition: "Collapsed",
													AllowFocusOnInteraction: "True"
												}, {
													default: d(() => [o(h.AppBarButton.Icon, null, {
														default: d(() => [o(h.FontIcon, {
															class: "win-media-glyph",
															Glyph: "{x:Bind volumeGlyph, Mode=OneWay}"
														})]),
														_: 1
													}), o(h.AppBarButton.Flyout, null, {
														default: d(() => [o(h.Flyout, {
															ref: "volumeFlyoutRef",
															Placement: "Top",
															ShouldConstrainToRootBounds: "False",
															Opened: "onVolumeFlyoutOpened",
															Closed: "onVolumeFlyoutClosed"
														}, {
															default: d(() => [o(h.Flyout.FlyoutPresenterStyle, null, {
																default: d(() => [o(y, {
																	TargetType: "FlyoutPresenter",
																	BasedOn: "{StaticResource DefaultFlyoutPresenterStyle}"
																}, {
																	default: d(() => [
																		o(v, {
																			Property: "Background",
																			Value: "{ThemeResource MediaTransportControlsFlyoutBackground}"
																		}),
																		o(v, {
																			Property: "BorderBrush",
																			Value: "{ThemeResource MediaTransportControlsBorderBrush}"
																		}),
																		o(v, {
																			Property: "Padding",
																			Value: "0"
																		})
																	]),
																	_: 1
																})]),
																_: 1
															}), o(h.StackPanel, {
																class: "win-media-volume-panel",
																Orientation: "Horizontal"
															}, {
																default: d(() => [
																	o(h.AppBarButton, {
																		class: "win-media-appbar-button",
																		"data-template-part": "AudioMuteButton",
																		Style: "{StaticResource AppBarButtonStyle}",
																		HorizontalAlignment: "Center",
																		VerticalAlignment: "Center",
																		Margin: "12",
																		IsEnabled: "{x:Bind canChangeVolume, Mode=OneWay}",
																		"AutomationProperties.Name": "{x:Bind muteLabel, Mode=OneWay}",
																		"ToolTipService.ToolTip": "{x:Bind muteLabel, Mode=OneWay}",
																		Click: "toggleMute",
																		Width: "40",
																		Height: "40",
																		MinWidth: "40",
																		MinHeight: "40",
																		LabelPosition: "Collapsed",
																		AllowFocusOnInteraction: "True"
																	}, {
																		default: d(() => [o(h.AppBarButton.Icon, null, {
																			default: d(() => [o(h.FontIcon, {
																				class: "win-media-glyph",
																				Glyph: "{x:Bind volumeGlyph, Mode=OneWay}"
																			})]),
																			_: 1
																		})]),
																		_: 1
																	}),
																	o(h.Slider, {
																		class: "win-media-volume-slider",
																		"data-template-part": "VolumeSlider",
																		Value: "{x:Bind volumePercent, Mode=OneWay}",
																		Minimum: "0",
																		Maximum: "100",
																		SmallChange: "1",
																		StepFrequency: "1",
																		IsThumbToolTipEnabled: "False",
																		IsEnabled: "{x:Bind canChangeVolume, Mode=OneWay}",
																		Width: "{ThemeResource MTCHorizontalVolumeSliderWidth}",
																		Height: "32",
																		HorizontalAlignment: "Center",
																		VerticalAlignment: "Center",
																		Margin: "0",
																		ValueChanged: "setVolume"
																	}),
																	o(h.TextBlock, {
																		class: "win-media-volume-value",
																		"data-template-part": "VolumeValue",
																		Style: "{StaticResource MediaTextBlockStyle}",
																		Text: "{x:Bind volumePercent, Mode=OneWay}",
																		HorizontalAlignment: "Center",
																		VerticalAlignment: "Center",
																		Width: "24",
																		Margin: "12",
																		IsTextScaleFactorEnabled: "False"
																	})
																]),
																_: 1
															})]),
															_: 1
														}, 512)]),
														_: 1
													})]),
													_: 1
												})) : r("", !0)]),
												_: 1
											}),
											o(h.StackPanel, {
												class: "win-media-command-center",
												"Grid.Column": "0",
												"Grid.ColumnSpan": "3",
												Orientation: "Horizontal"
											}, {
												default: d(() => [
													h.isStopButtonVisible ? (l(), n(h.AppBarButton, {
														key: 0,
														class: "win-media-appbar-button",
														"data-template-part": "StopButton",
														Style: "{StaticResource AppBarButtonStyle}",
														IsEnabled: "{x:Bind canStop, Mode=OneWay}",
														"AutomationProperties.Name": "{x:Bind stopLabel, Mode=OneWay}",
														"ToolTipService.ToolTip": "{x:Bind stopLabel, Mode=OneWay}",
														Click: "stopPlayback",
														Width: "40",
														Height: "40",
														MinWidth: "40",
														MinHeight: "40",
														LabelPosition: "Collapsed",
														AllowFocusOnInteraction: "True"
													}, {
														default: d(() => [o(h.AppBarButton.Icon, null, {
															default: d(() => [o(h.FontIcon, {
																class: "win-media-glyph",
																Glyph: ""
															})]),
															_: 1
														})]),
														_: 1
													})) : r("", !0),
													h.isSkipBackwardButtonVisible ? (l(), n(h.AppBarButton, {
														key: 1,
														class: "win-media-appbar-button",
														"data-template-part": "SkipBackwardButton",
														Style: "{StaticResource AppBarButtonStyle}",
														IsEnabled: "{x:Bind canSkipBackward, Mode=OneWay}",
														"AutomationProperties.Name": "{x:Bind skipBackwardLabel, Mode=OneWay}",
														"ToolTipService.ToolTip": "{x:Bind skipBackwardLabel, Mode=OneWay}",
														Click: "skipBackward",
														Width: "40",
														Height: "40",
														MinWidth: "40",
														MinHeight: "40",
														LabelPosition: "Collapsed",
														AllowFocusOnInteraction: "True"
													}, {
														default: d(() => [o(h.AppBarButton.Icon, null, {
															default: d(() => [o(h.FontIcon, {
																class: "win-media-glyph",
																Glyph: ""
															})]),
															_: 1
														})]),
														_: 1
													})) : r("", !0),
													h.isPreviousTrackButtonVisible ? (l(), n(h.AppBarButton, {
														key: 2,
														class: "win-media-appbar-button",
														"data-template-part": "PreviousTrackButton",
														Style: "{StaticResource AppBarButtonStyle}",
														IsEnabled: "{x:Bind canMovePrevious, Mode=OneWay}",
														"AutomationProperties.Name": "{x:Bind previousTrackLabel, Mode=OneWay}",
														"ToolTipService.ToolTip": "{x:Bind previousTrackLabel, Mode=OneWay}",
														Click: "movePreviousTrack",
														Width: "40",
														Height: "40",
														MinWidth: "40",
														MinHeight: "40",
														LabelPosition: "Collapsed",
														AllowFocusOnInteraction: "True"
													}, {
														default: d(() => [o(h.AppBarButton.Icon, null, {
															default: d(() => [o(h.FontIcon, {
																class: "win-media-glyph",
																Glyph: ""
															})]),
															_: 1
														})]),
														_: 1
													})) : r("", !0),
													h.isFastRewindButtonVisible ? (l(), n(h.AppBarButton, {
														key: 3,
														class: "win-media-appbar-button",
														"data-template-part": "RewindButton",
														Style: "{StaticResource AppBarButtonStyle}",
														IsEnabled: "{x:Bind canFastRewind, Mode=OneWay}",
														"AutomationProperties.Name": "{x:Bind fastRewindLabel, Mode=OneWay}",
														"ToolTipService.ToolTip": "{x:Bind fastRewindLabel, Mode=OneWay}",
														Click: "fastRewind",
														Width: "40",
														Height: "40",
														MinWidth: "40",
														MinHeight: "40",
														LabelPosition: "Collapsed",
														AllowFocusOnInteraction: "True"
													}, {
														default: d(() => [o(h.AppBarButton.Icon, null, {
															default: d(() => [o(h.FontIcon, {
																class: "win-media-glyph",
																Glyph: ""
															})]),
															_: 1
														})]),
														_: 1
													})) : r("", !0),
													o(h.AppBarButton, {
														class: "win-media-appbar-button",
														"data-template-part": "PlayPauseButton",
														Visibility: "{x:Bind normalPlayVisibility, Mode=OneWay}",
														Style: "{StaticResource AppBarButtonStyle}",
														IsEnabled: "{x:Bind canPlay, Mode=OneWay}",
														"AutomationProperties.Name": "{x:Bind playLabel, Mode=OneWay}",
														"ToolTipService.ToolTip": "{x:Bind playLabel, Mode=OneWay}",
														Click: "togglePlay",
														Width: "40",
														Height: "40",
														MinWidth: "40",
														MinHeight: "40",
														LabelPosition: "Collapsed",
														AllowFocusOnInteraction: "True"
													}, {
														default: d(() => [o(h.AppBarButton.Icon, null, {
															default: d(() => [o(h.FontIcon, {
																class: "win-media-glyph",
																Glyph: "{x:Bind playGlyph, Mode=OneWay}"
															})]),
															_: 1
														})]),
														_: 1
													}),
													h.isFastForwardButtonVisible ? (l(), n(h.AppBarButton, {
														key: 4,
														class: "win-media-appbar-button",
														"data-template-part": "FastForwardButton",
														Style: "{StaticResource AppBarButtonStyle}",
														IsEnabled: "{x:Bind canFastForward, Mode=OneWay}",
														"AutomationProperties.Name": "{x:Bind fastForwardLabel, Mode=OneWay}",
														"ToolTipService.ToolTip": "{x:Bind fastForwardLabel, Mode=OneWay}",
														Click: "fastForward",
														Width: "40",
														Height: "40",
														MinWidth: "40",
														MinHeight: "40",
														LabelPosition: "Collapsed",
														AllowFocusOnInteraction: "True"
													}, {
														default: d(() => [o(h.AppBarButton.Icon, null, {
															default: d(() => [o(h.FontIcon, {
																class: "win-media-glyph",
																Glyph: ""
															})]),
															_: 1
														})]),
														_: 1
													})) : r("", !0),
													h.isNextTrackButtonVisible ? (l(), n(h.AppBarButton, {
														key: 5,
														class: "win-media-appbar-button",
														"data-template-part": "NextTrackButton",
														Style: "{StaticResource AppBarButtonStyle}",
														IsEnabled: "{x:Bind canMoveNext, Mode=OneWay}",
														"AutomationProperties.Name": "{x:Bind nextTrackLabel, Mode=OneWay}",
														"ToolTipService.ToolTip": "{x:Bind nextTrackLabel, Mode=OneWay}",
														Click: "moveNextTrack",
														Width: "40",
														Height: "40",
														MinWidth: "40",
														MinHeight: "40",
														LabelPosition: "Collapsed",
														AllowFocusOnInteraction: "True"
													}, {
														default: d(() => [o(h.AppBarButton.Icon, null, {
															default: d(() => [o(h.FontIcon, {
																class: "win-media-glyph",
																Glyph: ""
															})]),
															_: 1
														})]),
														_: 1
													})) : r("", !0),
													h.isSkipForwardButtonVisible ? (l(), n(h.AppBarButton, {
														key: 6,
														class: "win-media-appbar-button",
														"data-template-part": "SkipForwardButton",
														Style: "{StaticResource AppBarButtonStyle}",
														IsEnabled: "{x:Bind canSkipForward, Mode=OneWay}",
														"AutomationProperties.Name": "{x:Bind skipForwardLabel, Mode=OneWay}",
														"ToolTipService.ToolTip": "{x:Bind skipForwardLabel, Mode=OneWay}",
														Click: "skipForward",
														Width: "40",
														Height: "40",
														MinWidth: "40",
														MinHeight: "40",
														LabelPosition: "Collapsed",
														AllowFocusOnInteraction: "True"
													}, {
														default: d(() => [o(h.AppBarButton.Icon, null, {
															default: d(() => [o(h.FontIcon, {
																class: "win-media-glyph",
																Glyph: ""
															})]),
															_: 1
														})]),
														_: 1
													})) : r("", !0)
												]),
												_: 1
											}),
											o(h.StackPanel, {
												class: "win-media-command-right",
												"Grid.Column": "2",
												Orientation: "Horizontal"
											}, {
												default: d(() => [
													h.isRepeatButtonVisible ? (l(), n(h.AppBarToggleButton, {
														key: 0,
														class: "win-media-appbar-button",
														"data-template-part": "RepeatButton",
														Style: "{StaticResource AppBarToggleButtonStyle}",
														IsEnabled: "{x:Bind canRepeat, Mode=OneWay}",
														IsChecked: "{x:Bind isLooping, Mode=OneWay}",
														"AutomationProperties.Name": "{x:Bind repeatLabel, Mode=OneWay}",
														"ToolTipService.ToolTip": "{x:Bind repeatLabel, Mode=OneWay}",
														Click: "toggleRepeat",
														Width: "40",
														Height: "40",
														MinWidth: "40",
														MinHeight: "40",
														LabelPosition: "Collapsed",
														AllowFocusOnInteraction: "True"
													}, {
														default: d(() => [o(h.AppBarToggleButton.Icon, null, {
															default: d(() => [o(h.FontIcon, {
																class: "win-media-glyph",
																Glyph: "{x:Bind repeatGlyph, Mode=OneWay}"
															})]),
															_: 1
														})]),
														_: 1
													})) : r("", !0),
													h.isPlaybackRateButtonVisible ? (l(), n(h.AppBarButton, {
														key: 1,
														class: "win-media-appbar-button",
														"data-template-part": "PlaybackRateButton",
														Style: "{StaticResource AppBarButtonStyle}",
														IsEnabled: "{x:Bind canChangePlaybackRate, Mode=OneWay}",
														"AutomationProperties.Name": "{x:Bind playbackRateLabel, Mode=OneWay}",
														"ToolTipService.ToolTip": "{x:Bind playbackRateLabel, Mode=OneWay}",
														Width: "40",
														Height: "40",
														MinWidth: "40",
														MinHeight: "40",
														LabelPosition: "Collapsed",
														AllowFocusOnInteraction: "True"
													}, {
														default: d(() => [o(h.AppBarButton.Icon, null, {
															default: d(() => [o(h.FontIcon, {
																class: "win-media-glyph",
																Glyph: ""
															})]),
															_: 1
														}), o(h.AppBarButton.Flyout, null, {
															default: d(() => [o(h.Flyout, {
																ref: "rateFlyoutRef",
																Opened: "onRateFlyoutOpened",
																Closed: "onRateFlyoutClosed"
															}, {
																default: d(() => [o(h.StackPanel, {
																	"data-template-part": "PlaybackRateMenu",
																	Spacing: "0"
																}, {
																	default: d(() => [
																		o(h.RadioButton, {
																			Content: "{x:Bind quarterSpeedLabel, Mode=OneWay}",
																			IsChecked: "{x:Bind isQuarterSpeed, Mode=OneWay}",
																			GroupName: "PlaybackRate",
																			Checked: "setQuarterSpeed"
																		}),
																		o(h.RadioButton, {
																			Content: "{x:Bind halfSpeedLabel, Mode=OneWay}",
																			IsChecked: "{x:Bind isHalfSpeed, Mode=OneWay}",
																			GroupName: "PlaybackRate",
																			Checked: "setHalfSpeed"
																		}),
																		o(h.RadioButton, {
																			Content: "{x:Bind normalSpeedLabel, Mode=OneWay}",
																			IsChecked: "{x:Bind isNormalSpeed, Mode=OneWay}",
																			GroupName: "PlaybackRate",
																			Checked: "setNormalSpeed"
																		}),
																		o(h.RadioButton, {
																			Content: "{x:Bind oneAndHalfSpeedLabel, Mode=OneWay}",
																			IsChecked: "{x:Bind isOneAndHalfSpeed, Mode=OneWay}",
																			GroupName: "PlaybackRate",
																			Checked: "setOneAndHalfSpeed"
																		}),
																		o(h.RadioButton, {
																			Content: "{x:Bind doubleSpeedLabel, Mode=OneWay}",
																			IsChecked: "{x:Bind isDoubleSpeed, Mode=OneWay}",
																			GroupName: "PlaybackRate",
																			Checked: "setDoubleSpeed"
																		})
																	]),
																	_: 1
																})]),
																_: 1
															}, 512)]),
															_: 1
														})]),
														_: 1
													})) : r("", !0),
													h.isZoomButtonVisible ? (l(), n(h.AppBarButton, {
														key: 2,
														class: "win-media-appbar-button",
														"data-template-part": "ZoomButton",
														Style: "{StaticResource AppBarButtonStyle}",
														IsEnabled: "{x:Bind canZoom, Mode=OneWay}",
														"AutomationProperties.Name": "{x:Bind zoomLabel, Mode=OneWay}",
														"ToolTipService.ToolTip": "{x:Bind zoomLabel, Mode=OneWay}",
														Click: "toggleStretch",
														Width: "40",
														Height: "40",
														MinWidth: "40",
														MinHeight: "40",
														LabelPosition: "Collapsed",
														AllowFocusOnInteraction: "True"
													}, {
														default: d(() => [o(h.AppBarButton.Icon, null, {
															default: d(() => [o(h.FontIcon, {
																class: "win-media-glyph",
																Glyph: ""
															})]),
															_: 1
														})]),
														_: 1
													})) : r("", !0),
													h.isCastButtonVisible ? (l(), n(h.AppBarButton, {
														key: 3,
														class: "win-media-appbar-button",
														"data-template-part": "CastButton",
														Style: "{StaticResource AppBarButtonStyle}",
														IsEnabled: "{x:Bind canRequestCast, Mode=OneWay}",
														"AutomationProperties.Name": "{x:Bind castLabel, Mode=OneWay}",
														"ToolTipService.ToolTip": "{x:Bind castLabel, Mode=OneWay}",
														Click: "onCastRequested",
														Width: "40",
														Height: "40",
														MinWidth: "40",
														MinHeight: "40",
														LabelPosition: "Collapsed",
														AllowFocusOnInteraction: "True"
													}, {
														default: d(() => [o(h.AppBarButton.Icon, null, {
															default: d(() => [o(h.FontIcon, {
																class: "win-media-glyph",
																Glyph: ""
															})]),
															_: 1
														}), h.castFeedbackText ? (l(), n(h.AppBarButton.Flyout, { key: 0 }, {
															default: d(() => [o(h.Flyout, {
																ref: "castFeedbackFlyoutRef",
																Placement: "Top",
																Closed: "onCastFeedbackClosed"
															}, {
																default: d(() => [o(h.TextBlock, {
																	class: "win-media-cast-feedback",
																	"data-template-part": "CastFeedback",
																	Text: "{x:Bind castFeedbackText, Mode=OneWay}",
																	TextWrapping: "Wrap",
																	MaxWidth: "280"
																})]),
																_: 1
															}, 512)]),
															_: 1
														})) : r("", !0)]),
														_: 1
													})) : r("", !0),
													h.isFullWindowButtonVisible ? (l(), n(h.AppBarButton, {
														key: 4,
														class: "win-media-appbar-button",
														"data-template-part": "FullWindowButton",
														Style: "{StaticResource AppBarButtonStyle}",
														IsEnabled: "{x:Bind canChangeFullWindow, Mode=OneWay}",
														"AutomationProperties.Name": "{x:Bind fullWindowLabel, Mode=OneWay}",
														"ToolTipService.ToolTip": "{x:Bind fullWindowLabel, Mode=OneWay}",
														Click: "toggleFullWindow",
														Width: "40",
														Height: "40",
														MinWidth: "40",
														MinHeight: "40",
														LabelPosition: "Collapsed",
														AllowFocusOnInteraction: "True"
													}, {
														default: d(() => [o(h.AppBarButton.Icon, null, {
															default: d(() => [o(h.SymbolIcon, {
																class: "win-media-glyph",
																"data-template-part": "FullWindowSymbol",
																Symbol: "{x:Bind fullWindowSymbol, Mode=OneWay}",
																FontSize: "16"
															})]),
															_: 1
														})]),
														_: 1
													})) : r("", !0)
												]),
												_: 1
											})
										]),
										_: 1
									})]),
									_: 1
								})
							]),
							_: 1
						})]),
						_: 1
					})]),
					_: 1
				}, 8, ["class"])) : r("", !0)]),
				_: 1
			}),
			o(h.Grid, {
				class: "win-media-timed-text-source-presenter",
				"data-template-part": "TimedTextSourcePresenter"
			})
		]),
		_: 1
	})], 38);
}
var h = /*#__PURE__*/ e(t, [["render", m], ["__file", "MediaPlayerElement.vue"]]);
//#endregion
export { h as default };

//# sourceMappingURL=MediaPlayerElement.vue.js.map