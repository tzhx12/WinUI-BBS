import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./Button.vue_vue_type_script_setup_true_lang.js";
/* empty css                                           */
import { Fragment as n, createBlock as r, createCommentVNode as i, createElementBlock as a, createElementVNode as o, mergeProps as s, openBlock as c, withCtx as l } from "vue";
//#region src/components/Button.vue
var u = [
	"HorizontalAlignment",
	"VerticalAlignment",
	"disabled",
	"tabindex"
];
function d(e, t, d, f, p, m) {
	return c(), a(n, null, [o("button", s({
		ref: "buttonRef",
		type: "button"
	}, f.buttonAttrs, {
		class: ["win-btn", [
			f.styleClass,
			{
				"content-horizontal-stretch": f.PresenterHorizontalAlignment === "Stretch",
				"content-vertical-stretch": f.PresenterVerticalAlignment === "Stretch",
				"is-pressed": f.IsPressed,
				"win-theme-scope": f.RequestedTheme === "Light" || f.RequestedTheme === "Dark",
				"theme-light": f.RequestedTheme === "Light",
				"theme-dark": f.RequestedTheme === "Dark"
			},
			f.attrs.class
		]],
		HorizontalAlignment: f.resolveXamlValue(f.props.HorizontalAlignment, f.instance),
		VerticalAlignment: f.resolveXamlValue(f.props.VerticalAlignment, f.instance),
		style: f.buttonStyle,
		disabled: f.isDisabled,
		tabindex: f.boolValue(f.resolveXamlValue(f.props.IsTabStop, f.instance)) ? void 0 : -1,
		onClick: f.onNativeClick,
		onPointerenter: f.onPointerEntered,
		onPointerleave: f.onPointerExited,
		onPointerdown: f.onPointerPressed,
		onPointermove: f.onPointerMoved,
		onPointerup: f.onPointerReleased,
		onPointercancel: f.onPointerCanceled,
		onLostpointercapture: f.onPointerCaptureLost,
		onKeydown: f.onKeyDown,
		onKeyup: f.onKeyUp,
		onFocusout: f.onLostFocus,
		onContextmenu: f.onContextRequested,
		onFocus: f.onGotFocus
	}), [
		f.titleBarStylePrefix ? (c(), r(f.Grid, {
			key: 0,
			"x:Name": "RootGrid",
			class: "win-titlebar-button-root",
			Background: "{x:Bind PresenterBackground}",
			CornerRadius: "{x:Bind PresenterCornerRadius}"
		}, {
			default: l(() => [f.propertyNodes.content.length ? (c(), r(f.ContentOutlet, { key: 0 })) : (c(), r(f.ContentValueOutlet, { key: 1 }))]),
			_: 1
		})) : (c(), r(f.ContentPresenter, {
			key: 1,
			class: "win-button-content-presenter",
			Background: "{x:Bind PresenterBackground}",
			BackgroundSizing: "{x:Bind PresenterBackgroundSizing}",
			BorderBrush: "{x:Bind PresenterBorderBrush}",
			BorderThickness: "{x:Bind PresenterBorderThickness}",
			Padding: "{x:Bind PresenterPadding}",
			CornerRadius: "{x:Bind PresenterCornerRadius}",
			ContentTemplate: "{x:Bind ContentTemplate}",
			ContentTransitions: "{x:Bind ContentTransitions}",
			HorizontalContentAlignment: "{x:Bind PresenterHorizontalAlignment}",
			VerticalContentAlignment: "{x:Bind PresenterVerticalAlignment}"
		}, {
			default: l(() => [f.propertyNodes.content.length ? (c(), r(f.ContentOutlet, { key: 0 })) : (c(), r(f.ContentValueOutlet, { key: 1 }))]),
			_: 1
		})),
		f.propertyNodes.attached.length ? (c(), r(f.AttachedOutlet, { key: 2 })) : i("", !0),
		f.boolValue(f.resolveXamlValue(f.props.UseSystemFocusVisuals, f.instance)) ? (c(), r(f.FocusVisual, {
			key: 3,
			Margin: f.resolveLength(f.props.FocusVisualMargin) === "" ? -3 : f.resolveLength(f.props.FocusVisualMargin),
			CornerRadius: f.PresenterCornerRadius,
			TargetBorderThickness: f.PresenterBorderThickness
		}, null, 8, [
			"Margin",
			"CornerRadius",
			"TargetBorderThickness"
		])) : i("", !0)
	], 16, u), f.propertyNodes.flyout.length ? (c(), r(f.FlyoutOutlet, { key: 0 })) : i("", !0)], 64);
}
var f = /*#__PURE__*/ e(t, [["render", d], ["__file", "Button.vue"]]);
//#endregion
export { f as default };

//# sourceMappingURL=Button.vue.js.map