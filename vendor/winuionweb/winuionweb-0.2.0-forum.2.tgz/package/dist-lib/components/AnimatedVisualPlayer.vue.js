import e from "../_virtual/_plugin-vue_export-helper.js";
/* empty css                                                         */
import { computed as t, createCommentVNode as n, createElementBlock as r, createStaticVNode as i, normalizeClass as a, normalizeStyle as o, onBeforeUnmount as s, onMounted as c, openBlock as l, ref as u, renderSlot as d, watch as f } from "vue";
//#region src/components/AnimatedVisualPlayer.vue
var p = {
	__name: "AnimatedVisualPlayer",
	props: {
		Source: {
			type: [String, Object],
			default: null
		},
		FallbackContent: {
			type: [String, Object],
			default: null
		},
		AutoPlay: {
			type: Boolean,
			default: !0
		},
		AnimationOptimization: {
			type: String,
			default: "Latency"
		},
		PlaybackRate: {
			type: Number,
			default: 1
		},
		Stretch: {
			type: String,
			default: "Uniform"
		},
		Width: {
			type: [String, Number],
			default: ""
		},
		Height: {
			type: [String, Number],
			default: ""
		},
		MinWidth: {
			type: [String, Number],
			default: ""
		},
		MinHeight: {
			type: [String, Number],
			default: ""
		},
		MaxWidth: {
			type: [String, Number],
			default: ""
		},
		MaxHeight: {
			type: [String, Number],
			default: ""
		},
		HorizontalAlignment: {
			type: String,
			default: ""
		},
		VerticalAlignment: {
			type: String,
			default: ""
		}
	},
	setup(e, { expose: n }) {
		let r = e, i = u(null), a = u(!1), o = u(!1), l = u(0), d = u(5967), p = null, m = null, h = (e) => {
			if (!(e === "" || e == null)) return typeof e == "number" || /^-?\d+(\.\d+)?$/.test(String(e).trim()) ? `${e}px` : String(e);
		}, g = t(() => typeof r.Source == "string" ? r.Source : r.Source && typeof r.Source == "object" ? r.Source.UriSource || "" : typeof r.FallbackContent == "string" && /^(https?:|data:|\/)/.test(r.FallbackContent) ? r.FallbackContent : ""), _ = t(() => ({
			width: h(r.Width),
			height: h(r.Height),
			minWidth: h(r.MinWidth),
			minHeight: h(r.MinHeight),
			maxWidth: h(r.MaxWidth),
			maxHeight: h(r.MaxHeight),
			justifySelf: {
				Left: "start",
				Center: "center",
				Right: "end",
				Stretch: "stretch"
			}[r.HorizontalAlignment] || void 0,
			alignSelf: {
				Top: "start",
				Center: "center",
				Bottom: "end",
				Stretch: "stretch"
			}[r.VerticalAlignment] || void 0,
			"--win-avp-rate": String(Math.abs(r.PlaybackRate) || 1),
			"--win-avp-direction": r.PlaybackRate < 0 ? "reverse" : "normal",
			"--win-avp-progress": String(l.value)
		})), v = () => {
			p && window.clearTimeout(p), p = null, m &&= (m(), null);
		}, y = () => {
			a.value = !1, p &&= (window.clearTimeout(p), null);
		}, b = () => {
			r.PlaybackRate !== 0 && (a.value = !0);
		}, x = () => {
			v(), a.value = !1, l.value = 0;
		}, S = (e = 0, t = 1, n = !1) => (v(), l.value = Math.max(0, Math.min(1, Number(e))), a.value = r.PlaybackRate !== 0, a.value ? new Promise((e) => {
			m = e, !n && (p = window.setTimeout(() => {
				l.value = Math.max(0, Math.min(1, Number(t))), a.value = !1, p = null, m = null, e();
			}, d.value / Math.max(Math.abs(r.PlaybackRate), .01)));
		}) : Promise.resolve()), C = (e) => {
			l.value = Math.max(0, Math.min(1, Number(e)));
		};
		c(() => {
			o.value = !0, r.AutoPlay && S(0, 1, !0);
		}), f(() => r.AutoPlay, (e) => {
			e ? S(l.value, 1, !0) : y();
		}), f(() => r.PlaybackRate, (e) => {
			e === 0 && y();
		}), f(() => r.Source, () => {
			o.value = !1, requestAnimationFrame(() => {
				o.value = !0;
			});
		}), s(v), n({
			Diagnostics: null,
			Duration: d,
			IsAnimatedVisualLoaded: o,
			IsPlaying: a,
			ProgressObject: null,
			Pause: y,
			PlayAsync: S,
			Resume: b,
			SetProgress: C,
			Stop: x,
			rootRef: i
		});
		let w = {
			props: r,
			rootRef: i,
			IsPlaying: a,
			IsAnimatedVisualLoaded: o,
			progress: l,
			Duration: d,
			get playTimer() {
				return p;
			},
			set playTimer(e) {
				p = e;
			},
			get playResolve() {
				return m;
			},
			set playResolve(e) {
				m = e;
			},
			cssLength: h,
			fallbackSource: g,
			rootStyle: _,
			clearPlayTimer: v,
			Pause: y,
			Resume: b,
			Stop: x,
			PlayAsync: S,
			SetProgress: C,
			computed: t,
			onBeforeUnmount: s,
			onMounted: c,
			ref: u,
			watch: f
		};
		return Object.defineProperty(w, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), w;
	}
}, m = ["src"], h = {
	key: 1,
	class: "win-animated-visual",
	viewBox: "0 0 375 667",
	preserveAspectRatio: "xMidYMid meet",
	"aria-hidden": "true"
}, g = {
	key: 2,
	class: "win-animated-visual-fallback-content"
};
function _(e, t, s, c, u, f) {
	return l(), r("div", {
		ref: "rootRef",
		class: a(["win-animated-visual-player", {
			"is-playing": c.IsPlaying,
			"is-loaded": c.IsAnimatedVisualLoaded
		}]),
		style: o(c.rootStyle),
		role: "img"
	}, [c.fallbackSource ? (l(), r("img", {
		key: 0,
		class: "win-animated-visual-fallback",
		src: c.fallbackSource,
		alt: ""
	}, null, 8, m)) : (l(), r("svg", h, [...t[0] ||= [i("<rect class=\"lottie-background\" x=\"0\" y=\"0\" width=\"375\" height=\"667\"></rect><g class=\"lottie-mark\"><path class=\"mark-stroke mark-stroke-1\" d=\"M112 333h151\"></path><path class=\"mark-stroke mark-stroke-2\" d=\"M145 287v92\"></path><path class=\"mark-stroke mark-stroke-3\" d=\"M188 268v131\"></path><path class=\"mark-stroke mark-stroke-4\" d=\"M231 287v92\"></path><circle class=\"mark-dot mark-dot-1\" cx=\"112\" cy=\"333\" r=\"10\"></circle><circle class=\"mark-dot mark-dot-2\" cx=\"145\" cy=\"287\" r=\"10\"></circle><circle class=\"mark-dot mark-dot-3\" cx=\"188\" cy=\"268\" r=\"10\"></circle><circle class=\"mark-dot mark-dot-4\" cx=\"231\" cy=\"287\" r=\"10\"></circle><circle class=\"mark-dot mark-dot-5\" cx=\"263\" cy=\"333\" r=\"10\"></circle></g>", 2)]])), !c.IsAnimatedVisualLoaded && e.$slots.FallbackContent ? (l(), r("div", g, [d(e.$slots, "FallbackContent")])) : n("", !0)], 6);
}
var v = /*#__PURE__*/ e(p, [["render", _], ["__file", "AnimatedVisualPlayer.vue"]]);
//#endregion
export { v as default };

//# sourceMappingURL=AnimatedVisualPlayer.vue.js.map