//#region src/components/flyoutInput.ts
var e = Symbol("FlyoutInputContext"), t = /* @__PURE__ */ new Set(), n = (e) => [...t].find((t) => t !== e && t.IsOpen && e.Target && t.Presenter?.contains(e.Target)), r = (e, t) => {
	let r = /* @__PURE__ */ new Set();
	for (let i = n(e); i && !r.has(i); i = n(i)) {
		if (i === t) return !0;
		r.add(i);
	}
	return !1;
}, i = (e) => (t.add(e), () => {
	t.delete(e);
}), a = (e, n) => [...t].some((t) => t.Owner === e && r(t, n)), o = (e) => [...t].some((t) => t.IsOpen && r(t, e)), s = (e, n) => !!n && (e.Presenter?.contains(n) || [...t].some((t) => t.IsOpen && r(t, e) && (t.Presenter?.contains(n) || t.DismissLayer?.contains(n)))), c = (e) => {
	for (let n of t) n.IsOpen && r(n, e) && n.Hide(!1);
}, l = (e) => {
	let t = n(e);
	if (!t?.Presenter) return null;
	let r = Number(getComputedStyle(t.Presenter).zIndex) || 0, i = Math.min(2147483647, r + 1);
	return {
		overlay: i,
		presenter: Math.min(2147483647, i + 1)
	};
};
//#endregion
export { s as flyoutContainsNode, e as flyoutInputContextKey, o as hasOpenDescendantFlyout, c as hideDescendantFlyouts, a as isDescendantFlyoutOpening, l as nestedFlyoutLayers, i as registerFlyoutInputRegion };

//# sourceMappingURL=flyoutInput.js.map