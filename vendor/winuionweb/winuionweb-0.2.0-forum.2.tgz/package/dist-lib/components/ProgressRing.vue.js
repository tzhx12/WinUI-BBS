import { alignment as e, cssLength as t, xamlThickness as n } from "./layout.js";
import { resolveXamlHandler as r, resolveXamlValue as i } from "./xamlRuntime.js";
import a from "../_virtual/_plugin-vue_export-helper.js";
import { determinateRingTrim as o, progressBoolean as s, progressBrush as c, useProgressProperty as l, useProgressRange as u } from "./progressRuntime.js";
/* empty css                                                                 */
import { computed as d, createElementBlock as f, createElementVNode as p, getCurrentInstance as m, mergeProps as h, nextTick as ee, normalizeStyle as g, onBeforeUnmount as te, onMounted as ne, openBlock as _, ref as v, useAttrs as y, watch as b } from "vue";
//#region src/components/ProgressRing.vue
var x = /*@__PURE__*/ Object.assign({ inheritAttrs: !1 }, {
	__name: "ProgressRing",
	props: {
		IsActive: {
			type: [Boolean, String],
			default: !0
		},
		IsIndeterminate: {
			type: [Boolean, String],
			default: !0
		},
		DeterminateSource: {
			type: Object,
			default: null
		},
		IndeterminateSource: {
			type: Object,
			default: null
		},
		Value: {
			type: [Number, String],
			default: 0
		},
		Minimum: {
			type: [Number, String],
			default: 0
		},
		Maximum: {
			type: [Number, String],
			default: 100
		},
		Width: {
			type: [Number, String],
			default: 32
		},
		Height: {
			type: [Number, String],
			default: 32
		},
		MinWidth: {
			type: [Number, String],
			default: 16
		},
		MinHeight: {
			type: [Number, String],
			default: 16
		},
		MaxWidth: {
			type: [Number, String],
			default: ""
		},
		MaxHeight: {
			type: [Number, String],
			default: ""
		},
		Margin: {
			type: [Number, String],
			default: ""
		},
		Foreground: {
			type: [String, Object],
			default: "{ThemeResource ProgressRingForegroundThemeBrush}"
		},
		Background: {
			type: [String, Object],
			default: "{ThemeResource ProgressRingBackgroundThemeBrush}"
		},
		HorizontalAlignment: {
			type: String,
			default: "Center"
		},
		VerticalAlignment: {
			type: String,
			default: "Center"
		},
		IsHitTestVisible: {
			type: [Boolean, String],
			default: !1
		},
		IsTabStop: {
			type: [Boolean, String],
			default: !1
		},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		Visibility: {
			type: String,
			default: "Visible"
		}
	},
	emits: [
		"ValueChanged",
		"update:Value",
		"update:Minimum",
		"update:Maximum",
		"update:IsActive",
		"update:IsIndeterminate",
		"update:Background",
		"update:Foreground"
	],
	setup(a, { expose: f, emit: p }) {
		let h = a, g = p, _ = y(), x = m(), S = (e) => i(e, x), C = (e, t) => g("update:" + e, t), { Value: w, Minimum: T, Maximum: E, minimum: re, maximum: D, fraction: O, coercedValue: k } = u(h, x, C), A = l(h, "IsActive", x, C), j = l(h, "IsIndeterminate", x, C), M = l(h, "Background", x, C), N = l(h, "Foreground", x, C), P = d(() => s(A.value, !0)), F = d(() => s(j.value, !0)), I = d(() => S(h.Visibility)), ie = d(() => s(S(h.IsEnabled), !0)), ae = d(() => s(S(h.IsTabStop))), L = v(null), R = v(null), z = v(null), B = v({
			width: 0,
			height: 0
		}), V = v(O.value), H, U = 0, W = 0, G = 0, K = !1, oe = d(() => {
			let e = { ..._ };
			for (let t of [
				"class",
				"style",
				"role",
				"aria-valuenow",
				"aria-valuemin",
				"aria-valuemax",
				"aria-busy",
				"aria-hidden",
				"ValueChanged"
			]) delete e[t];
			return e["AutomationProperties.Name"] && (e["aria-label"] = S(e["AutomationProperties.Name"])), delete e["AutomationProperties.Name"], e;
		}), se = d(() => ({
			"is-active": P.value,
			"is-inactive": !P.value,
			"is-indeterminate": F.value,
			"is-determinate": !F.value,
			"is-disabled": !ie.value,
			"is-collapsed": I.value === "Collapsed"
		})), ce = d(() => [_.style, {
			width: t(S(h.Width)),
			height: t(S(h.Height)),
			flex: t(S(h.Width)) ? "0 0 auto" : void 0,
			minWidth: t(S(h.MinWidth)),
			minHeight: t(S(h.MinHeight)),
			maxWidth: t(S(h.MaxWidth)) || void 0,
			maxHeight: t(S(h.MaxHeight)) || void 0,
			margin: n(S(h.Margin)) || void 0,
			alignSelf: e(S(h.VerticalAlignment), "vertical"),
			justifySelf: e(S(h.HorizontalAlignment), "horizontal"),
			pointerEvents: s(S(h.IsHitTestVisible)) ? void 0 : "none",
			display: I.value === "Collapsed" ? "none" : void 0,
			"--progress-ring-foreground": c(N.value),
			"--progress-ring-background": c(M.value)
		}]), le = d(() => ({
			strokeDashoffset: String(100 - o(V.value) * 100),
			opacity: V.value < .00833333377 ? 0 : 1
		})), q = d(() => {
			let e = B.value.width, t = e > 0 ? e * .1 + +(e <= 40) : 0;
			return {
				EllipseDiameter: t,
				EllipseOffset: {
					Left: 0,
					Top: e * .5 - t,
					Right: 0,
					Bottom: 0
				},
				MaxSideLength: e
			};
		});
		f({
			Value: w,
			Minimum: T,
			Maximum: E,
			IsActive: A,
			IsIndeterminate: j,
			Background: M,
			Foreground: N,
			TemplateSettings: q
		});
		let J = () => {
			L.value && (B.value = {
				width: L.value.clientWidth,
				height: L.value.clientHeight
			});
		}, ue = (e) => e, Y = (e, t, n, r) => {
			if (!e) return;
			let i = Math.max(1e-4, (n - t) * 100), a = Math.max(1e-4, 100 - i);
			e.style.strokeDasharray = i + " " + a, e.style.strokeDashoffset = String(-t * 100), e.style.opacity = String(r);
		}, X = (e) => {
			W ||= e;
			let t = (e - W) % 2e3 / 2e3, n = t < .5, r = ue(n ? t * 2 : (t - .5) * 2), i = "rotate(" + ((n ? r * .5 : .5 + r * .5) * 900 - 90) + " 50 50)";
			R.value?.setAttribute("transform", i), z.value?.setAttribute("transform", i), n ? (Y(R.value, 0, .5, 0), Y(z.value, 0, 1e-4 + r * .5, 1)) : (Y(R.value, r * .5, .5, 1), Y(z.value, 0, .5, 0)), U = window.requestAnimationFrame(X);
		}, Z = () => {
			U && window.cancelAnimationFrame(U), U = 0, W = 0;
		}, Q = () => {
			Z(), K && P.value && F.value && I.value === "Visible" && (U = window.requestAnimationFrame(X));
		}, $ = () => {
			G && window.cancelAnimationFrame(G), G = 0;
		}, de = (e, t) => {
			if ($(), !K || F.value || !P.value || e <= t || !Number.isFinite(t)) {
				V.value = e;
				return;
			}
			let n = Math.max(0, Math.min(e, V.value)), r = Math.max(0, (e - t) * 2e3), i = 0, a = (t) => {
				i ||= t;
				let o = r > 0 ? Math.min(1, (t - i) / r) : 1;
				V.value = n + (e - n) * o, G = o < 1 ? window.requestAnimationFrame(a) : 0;
			};
			G = window.requestAnimationFrame(a);
		};
		b(O, de), b(k, (e, t) => {
			if (Object.is(e, t)) return;
			let n = {
				OldValue: t,
				NewValue: e
			};
			r(_.ValueChanged, x)?.(x?.exposed, n), g("ValueChanged", n);
		}), b([
			P,
			F,
			I
		], () => {
			Q(), $(), V.value = O.value;
		}), ne(async () => {
			await ee(), K = !0, J(), Q(), typeof ResizeObserver < "u" && L.value && (H = new ResizeObserver(J), H.observe(L.value));
		}), te(() => {
			K = !1, H?.disconnect(), Z(), $();
		});
		let fe = {
			props: h,
			emit: g,
			attrs: _,
			instance: x,
			resolve: S,
			publish: C,
			Value: w,
			Minimum: T,
			Maximum: E,
			minimum: re,
			maximum: D,
			progressFraction: O,
			progressValue: k,
			IsActive: A,
			IsIndeterminate: j,
			Background: M,
			Foreground: N,
			isActive: P,
			isIndeterminate: F,
			visibility: I,
			isEnabled: ie,
			isTabStop: ae,
			rootRef: L,
			indeterminateRef: R,
			indeterminateBRef: z,
			measuredSize: B,
			displayedProgress: V,
			get resizeObserver() {
				return H;
			},
			set resizeObserver(e) {
				H = e;
			},
			get animationFrame() {
				return U;
			},
			set animationFrame(e) {
				U = e;
			},
			get animationStart() {
				return W;
			},
			set animationStart(e) {
				W = e;
			},
			get determinateFrame() {
				return G;
			},
			set determinateFrame(e) {
				G = e;
			},
			get mounted() {
				return K;
			},
			set mounted(e) {
				K = e;
			},
			forwardedAttrs: oe,
			stateClasses: se,
			rootStyle: ce,
			determinateStyle: le,
			TemplateSettings: q,
			updateMeasuredSize: J,
			officialEasing: ue,
			setTrim: Y,
			renderIndeterminateFrame: X,
			stopIndeterminateAnimation: Z,
			syncIndeterminateAnimation: Q,
			stopDeterminateAnimation: $,
			updateDeterminateProgress: de,
			computed: d,
			getCurrentInstance: m,
			nextTick: ee,
			onBeforeUnmount: te,
			onMounted: ne,
			ref: v,
			useAttrs: y,
			watch: b,
			get resolveXamlHandler() {
				return r;
			},
			get resolveXamlValue() {
				return i;
			},
			get alignment() {
				return e;
			},
			get cssLength() {
				return t;
			},
			get xamlThickness() {
				return n;
			},
			get determinateRingTrim() {
				return o;
			},
			get progressBoolean() {
				return s;
			},
			get progressBrush() {
				return c;
			},
			get useProgressProperty() {
				return l;
			},
			get useProgressRange() {
				return u;
			}
		};
		return Object.defineProperty(fe, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), fe;
	}
}), S = [
	"tabindex",
	"aria-valuenow",
	"aria-valuemin",
	"aria-valuemax",
	"aria-busy",
	"aria-hidden",
	"aria-disabled"
], C = { class: "LayoutRoot" }, w = { class: "LottiePlayer" }, T = {
	class: "ProgressRingVisual",
	viewBox: "0 0 100 100",
	preserveAspectRatio: "none",
	role: "presentation",
	"aria-hidden": "true"
}, E = ["r"], re = {
	ref: "indeterminateRef",
	class: "ProgressRingIndeterminateIndicator ProgressRingIndeterminateIndicatorA",
	cx: "50",
	cy: "50",
	r: "42",
	pathLength: "100"
}, D = {
	ref: "indeterminateBRef",
	class: "ProgressRingIndeterminateIndicator ProgressRingIndeterminateIndicatorB",
	cx: "50",
	cy: "50",
	r: "42",
	pathLength: "100"
};
function O(e, t, n, r, i, a) {
	return _(), f("div", h({ ref: "rootRef" }, r.forwardedAttrs, {
		class: ["win-progress-ring", [r.attrs.class, r.stateClasses]],
		style: r.rootStyle,
		tabindex: r.isTabStop && r.isEnabled ? 0 : void 0,
		role: "progressbar",
		"aria-valuenow": r.isIndeterminate || !r.isActive ? void 0 : r.progressValue,
		"aria-valuemin": r.isIndeterminate || !r.isActive ? void 0 : r.minimum,
		"aria-valuemax": r.isIndeterminate || !r.isActive ? void 0 : r.maximum,
		"aria-busy": r.isIndeterminate && r.isActive ? "true" : void 0,
		"aria-hidden": r.isActive ? void 0 : "true",
		"aria-disabled": !r.isEnabled || void 0
	}), [p("div", C, [p("div", w, [(_(), f("svg", T, [
		p("circle", {
			class: "ProgressRingTrack",
			cx: "50",
			cy: "50",
			r: r.isIndeterminate ? 42 : 44.25
		}, null, 8, E),
		p("circle", {
			class: "ProgressRingDeterminateIndicator",
			cx: "50",
			cy: "50",
			r: "44.25",
			pathLength: "100",
			style: g(r.determinateStyle)
		}, null, 4),
		p("circle", re, null, 512),
		p("circle", D, null, 512)
	]))])])], 16, S);
}
var k = /*#__PURE__*/ a(x, [
	["render", O],
	["__scopeId", "data-v-b06f9aa2"],
	["__file", "ProgressRing.vue"]
]);
//#endregion
export { k as default };

//# sourceMappingURL=ProgressRing.vue.js.map