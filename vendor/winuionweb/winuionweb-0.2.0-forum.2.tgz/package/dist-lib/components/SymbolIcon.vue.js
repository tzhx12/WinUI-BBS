import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./SymbolIcon.vue_vue_type_script_setup_true_lang.js";
/* empty css                                               */
import { createElementBlock as n, createVNode as r, mergeProps as i, openBlock as a, withCtx as o } from "vue";
//#region src/components/SymbolIcon.vue
function s(e, t, s, c, l, u) {
	return a(), n("span", i({ ref: "Element" }, c.symbolAttrs, {
		class: ["win-icon-element win-symbol-icon", c.attrs.class],
		style: [c.attrs.style, c.layoutStyle]
	}), [r(c.Grid, {
		class: "win-icon-grid",
		"data-icon-part": "LayoutRoot",
		Background: "Transparent"
	}, {
		default: o(() => [r(c.TextBlock, {
			class: "win-icon-text-block win-symbol-icon-glyph",
			"data-icon-part": "TextBlock",
			Style: "{x:Null}",
			Text: "{x:Bind SymbolIconTemplateGlyph, Mode=OneWay}",
			FontFamily: "{x:Bind SymbolIconTemplateFontFamily, Mode=OneWay}",
			FontSize: "20",
			FontStyle: "Normal",
			FontWeight: "Normal",
			HorizontalAlignment: "Stretch",
			VerticalAlignment: "Center",
			TextAlignment: "Center",
			IsTextScaleFactorEnabled: "False",
			"AutomationProperties.AccessibilityView": "Raw",
			"aria-hidden": "true"
		})]),
		_: 1
	})], 16);
}
var c = /*#__PURE__*/ e(t, [["render", s], ["__file", "SymbolIcon.vue"]]);
//#endregion
export { c as default };

//# sourceMappingURL=SymbolIcon.vue.js.map