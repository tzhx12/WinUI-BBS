import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./RichTextBlockOverflow.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                          */
import { createElementBlock as n, mergeProps as r, openBlock as i } from "vue";
//#region src/components/RichTextBlockOverflow.vue
function a(e, t, a, o, s, c) {
	return i(), n("div", r({ ref: "element" }, o.forwardedAttrs, {
		class: "win-rich-text-overflow",
		style: [o.attrs.style, o.style]
	}), null, 16);
}
var o = /*#__PURE__*/ e(t, [["render", a], ["__file", "RichTextBlockOverflow.vue"]]);
//#endregion
export { o as default };

//# sourceMappingURL=RichTextBlockOverflow.vue.js.map