import { materializeXamlVNode as e, resolveXamlHandler as t, resolveXamlValue as n, updateXamlBinding as r, xamlItemContextKey as i, xamlScopeKey as a } from "./xamlRuntime.js";
import o from "../_virtual/_plugin-vue_export-helper.js";
import { xamlResourceDictionaryKey as s } from "./Page.vue_vue_type_script_lang.js";
import { CollectionItemTemplate as c, getCollectionProperty as l, getVNodeChildren as u } from "./CollectionProperties.js";
import d from "./TextBlock.vue.js";
import f from "./ScrollViewer.vue.js";
import { scrollViewerTemplateBindings as p } from "./scrollViewerTemplateBindings.js";
/* empty css                                                            */
import { Fragment as m, computed as h, createBlock as g, createElementBlock as _, createElementVNode as v, createVNode as y, defineComponent as b, getCurrentInstance as x, h as S, inject as C, normalizeClass as w, openBlock as T, provide as E, ref as D, renderList as O, toRaw as k, useAttrs as A, useSlots as j, watch as M, withCtx as N } from "vue";
//#region src/components/ListBox.vue
var P = /*@__PURE__*/ Object.assign({ ItemTemplate: c }, {
	__name: "ListBox",
	props: {
		ItemsSource: {
			type: [
				Array,
				String,
				Object
			],
			default: () => []
		},
		SelectedIndex: {
			type: [Number, String],
			default: void 0
		},
		SelectedItem: {
			type: null,
			default: void 0
		},
		SelectedItems: {
			type: [Array, String],
			default: void 0
		},
		ItemTemplate: {
			type: [
				String,
				Object,
				Function
			],
			default: void 0
		},
		SelectionMode: {
			type: String,
			default: "Single"
		},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		Padding: {
			type: [String, Number],
			default: 0
		},
		Width: {
			type: [String, Number],
			default: ""
		},
		Height: {
			type: [String, Number],
			default: ""
		}
	},
	emits: [
		"SelectionChanged",
		"update:SelectedIndex",
		"update:SelectedItem",
		"update:SelectedItems"
	],
	setup(o, { expose: g, emit: _ }) {
		let v = o, y = _, w = A(), T = j(), O = x(), N = C(a, {}), P = p((e) => w[e], O), F = h(() => {
			let e = n(v.IsEnabled, O);
			return e !== !1 && e !== "False";
		});
		E(a, {
			...N,
			ScrollSettings: P,
			get TemplateWidth() {
				return n(v.Width, O);
			},
			get TemplateHeight() {
				return n(v.Height, O);
			},
			get TemplatePadding() {
				return n(v.Padding, O);
			},
			get ScrollTemplateIsEnabled() {
				return F.value;
			}
		});
		let I = C(s, null), L = T.default?.() ?? [], R = h(() => {
			let e = n(v.ItemTemplate, O), t = typeof e == "string" ? I?.[e.match(/^\{StaticResource\s+([^}]+)\}$/)?.[1] ?? e] : e;
			if (t && typeof t == "object") return u(t);
			let r = L.find((e) => l(e) === "itemTemplate");
			return r ? u(r) : [];
		}), z = b({
			props: { Item: {
				type: null,
				default: null
			} },
			setup(t) {
				return E(i, h(() => t.Item)), () => R.value.length ? S(m, e(R.value, t.Item, O)) : S(d, { Text: String(t.Item ?? "") });
			}
		}), B = h(() => {
			let e = n(v.ItemsSource, O);
			return Array.isArray(e) ? e : [];
		}), V = h(() => String(n(v.SelectionMode, O) ?? "Single")), H = h(() => V.value === "Multiple" || V.value === "Extended"), U = Number(n(v.SelectedIndex, O)), W = n(v.SelectedItem, O), G = D(Number.isFinite(U) ? U : B.value.findIndex((e) => k(e) === k(W))), K = D(void 0), q = h(() => {
			let e = n(v.SelectedItems, O);
			return H.value ? K.value ?? (Array.isArray(e) ? e : []) : G.value >= 0 && G.value < B.value.length ? [B.value[G.value]] : [];
		}), J = (e, t) => e && typeof e == "object" ? e.Key ?? e.Id ?? t : t, Y = (e, t) => k(e) === k(t), ee = (e, t) => H.value ? q.value.some((t) => Y(t, e)) : t === G.value, X = {
			get SelectedIndex() {
				return G.value;
			},
			get SelectedItem() {
				return B.value[G.value] ?? null;
			},
			get SelectedItems() {
				return q.value;
			}
		}, Z = (e) => {
			y("SelectionChanged", X, e), O.vnode.props?.onSelectionChanged || t(w.SelectionChanged, O)?.(X, e);
		}, Q = (e) => {
			if (!F.value || V.value === "None" || !Number.isInteger(e) || e < -1 || e >= B.value.length || !H.value && e === G.value || H.value && e < 0) return;
			let t = e < 0 ? null : B.value[e];
			if (H.value) {
				let e = [...q.value], n = e.findIndex((e) => Y(e, t));
				n >= 0 ? e.splice(n, 1) : e.push(t), K.value = e, r(v.SelectedItems, e, O), y("update:SelectedItems", e), Z({
					AddedItems: n < 0 ? [t] : [],
					RemovedItems: n >= 0 ? [t] : [],
					SelectedItems: e
				});
				return;
			}
			let n = B.value[G.value];
			G.value = e, r(v.SelectedIndex, e, O), r(v.SelectedItem, t, O), y("update:SelectedIndex", e), y("update:SelectedItem", t), Z({
				AddedItems: e < 0 ? [] : [t],
				RemovedItems: n == null ? [] : [n],
				SelectedIndex: e,
				SelectedItem: t
			});
		}, te = (e, t) => {
			if (!F.value) return;
			if (e.key === "Enter" || e.key === " ") {
				e.preventDefault(), Q(t);
				return;
			}
			let n = e.key === "ArrowDown" ? Math.min(B.value.length - 1, t + 1) : e.key === "ArrowUp" ? Math.max(0, t - 1) : e.key === "Home" ? 0 : e.key === "End" ? B.value.length - 1 : -1;
			if (n < 0) return;
			e.preventDefault(), H.value || Q(n);
			let r = e.currentTarget?.parentElement?.children[n];
			r?.focus({ preventScroll: !0 }), r?.scrollIntoView({
				block: "nearest",
				inline: "nearest"
			});
		};
		M(() => n(v.SelectedIndex, O), (e) => {
			let t = Number(e);
			G.value = Number.isFinite(t) ? t : -1;
		}), M(() => n(v.SelectedItem, O), (e) => {
			e !== void 0 && (G.value = B.value.findIndex((t) => Y(t, e)));
		}), M(() => n(v.SelectedItems, O), () => {
			K.value = void 0;
		}), g({
			get SelectedIndex() {
				return G.value;
			},
			set SelectedIndex(e) {
				Q(Number(e));
			},
			get SelectedItem() {
				return B.value[G.value] ?? null;
			},
			set SelectedItem(e) {
				Q(B.value.findIndex((t) => Y(t, e)));
			},
			SelectedItems: q,
			Select: Q
		});
		let $ = {
			props: v,
			emit: y,
			attrs: w,
			slots: T,
			instance: O,
			inheritedScope: N,
			ScrollSettings: P,
			isEnabled: F,
			resources: I,
			propertyNodes: L,
			itemTemplate: R,
			ItemContent: z,
			items: B,
			mode: V,
			isMultiple: H,
			initialIndex: U,
			initialItem: W,
			localIndex: G,
			localItems: K,
			selectedItems: q,
			itemKey: J,
			same: Y,
			isSelected: ee,
			sender: X,
			raise: Z,
			select: Q,
			onItemKeyDown: te,
			get CollectionItemTemplate() {
				return c;
			},
			computed: h,
			defineComponent: b,
			Fragment: m,
			getCurrentInstance: x,
			h: S,
			inject: C,
			provide: E,
			ref: D,
			toRaw: k,
			useAttrs: A,
			useSlots: j,
			watch: M,
			ScrollViewer: f,
			TextBlock: d,
			get scrollViewerTemplateBindings() {
				return p;
			},
			get materializeXamlVNode() {
				return e;
			},
			get resolveXamlHandler() {
				return t;
			},
			get resolveXamlValue() {
				return n;
			},
			get updateXamlBinding() {
				return r;
			},
			get xamlItemContextKey() {
				return i;
			},
			get xamlScopeKey() {
				return a;
			},
			get getCollectionProperty() {
				return l;
			},
			get getVNodeChildren() {
				return u;
			},
			xamlResourceDictionaryKey: s
		};
		return Object.defineProperty($, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), $;
	}
}), F = ["aria-disabled", "aria-multiselectable"], I = [
	"aria-selected",
	"aria-disabled",
	"tabindex",
	"onClick",
	"onKeydown"
];
function L(e, t, n, r, i, a) {
	return T(), g(r.ScrollViewer, {
		class: "win-list-box",
		Width: "{x:Bind TemplateWidth, Mode=OneWay}",
		Height: "{x:Bind TemplateHeight, Mode=OneWay}",
		Padding: "{x:Bind TemplatePadding, Mode=OneWay}",
		VerticalScrollMode: "{x:Bind ScrollSettings.VerticalScrollMode, Mode=OneWay}",
		VerticalScrollBarVisibility: "{x:Bind ScrollSettings.VerticalScrollBarVisibility, Mode=OneWay}",
		HorizontalScrollMode: "{x:Bind ScrollSettings.HorizontalScrollMode, Mode=OneWay}",
		HorizontalScrollBarVisibility: "{x:Bind ScrollSettings.HorizontalScrollBarVisibility, Mode=OneWay}",
		IsHorizontalRailEnabled: "{x:Bind ScrollSettings.IsHorizontalRailEnabled, Mode=OneWay}",
		IsVerticalRailEnabled: "{x:Bind ScrollSettings.IsVerticalRailEnabled, Mode=OneWay}",
		IsHorizontalScrollChainingEnabled: "{x:Bind ScrollSettings.IsHorizontalScrollChainingEnabled, Mode=OneWay}",
		IsVerticalScrollChainingEnabled: "{x:Bind ScrollSettings.IsVerticalScrollChainingEnabled, Mode=OneWay}",
		ZoomMode: "{x:Bind ScrollSettings.ZoomMode, Mode=OneWay}",
		IsEnabled: "{x:Bind ScrollTemplateIsEnabled, Mode=OneWay}",
		IsTabStop: "False"
	}, {
		default: N(() => [v("div", {
			class: "win-list-box-items",
			role: "listbox",
			"aria-disabled": !r.isEnabled,
			"aria-multiselectable": r.isMultiple || void 0
		}, [(T(!0), _(m, null, O(r.items, (e, t) => (T(), _("div", {
			key: r.itemKey(e, t),
			class: w(["win-list-box-item", { selected: r.isSelected(e, t) }]),
			role: "option",
			"aria-selected": r.isSelected(e, t),
			"aria-disabled": !r.isEnabled,
			tabindex: r.isEnabled && r.isSelected(e, t) ? 0 : -1,
			onClick: (e) => r.select(t),
			onKeydown: (e) => r.onItemKeyDown(e, t)
		}, [y(r.ItemContent, { Item: e }, null, 8, ["Item"])], 42, I))), 128))], 8, F)]),
		_: 1
	});
}
var R = /*#__PURE__*/ o(P, [
	["render", L],
	["__scopeId", "data-v-1c91fab2"],
	["__file", "ListBox.vue"]
]);
//#endregion
export { R as default };

//# sourceMappingURL=ListBox.vue.js.map