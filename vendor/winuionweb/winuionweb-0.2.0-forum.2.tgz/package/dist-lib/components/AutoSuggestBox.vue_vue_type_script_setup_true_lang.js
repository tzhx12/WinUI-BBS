import { boolValue as e, cssLength as t } from "./layout.js";
import { useAcrylicBrushStyle as n } from "./AcrylicBrush.js";
import { normalizeXamlNodes as r, resolveXamlHandler as i, resolveXamlValue as a, updateXamlBinding as o, xamlItemContextKey as ee, xamlScopeKey as te, xamlTemplateComponent as s } from "./xamlRuntime.js";
import { collectXamlResources as ne } from "./xamlBrushResources.js";
import { vAcrylicBrush as c } from "./acrylicBrushVisual.js";
import { vThemeShadow as re } from "./themeShadowVisual.js";
import { useI18n as l } from "./i18n/index.js";
import { xamlResourceDictionaryKey as u } from "./Page.vue_vue_type_script_lang.js";
import { CollectionItemTemplate as d, CollectionItemTemplateSelector as ie, CollectionResources as ae, getCollectionProperty as oe, getVNodeChildren as f } from "./CollectionProperties.js";
import se from "./FontIcon.vue.js";
import ce from "./ScrollViewer.vue.js";
import { textInputTemplateKey as le } from "./textInputTemplate.js";
import ue from "./ContentPresenter.vue.js";
import de from "./TextBox.vue.js";
import { useAnimatedIconInput as fe } from "./animatedIconInput.js";
import { useFlyoutAnimation as pe } from "./useFlyoutAnimation.js";
import { Fragment as p, computed as m, defineComponent as h, getCurrentInstance as me, h as g, inject as he, isVNode as ge, nextTick as _, onBeforeUnmount as _e, onMounted as ve, provide as v, proxyRefs as ye, ref as y, useAttrs as be, useSlots as xe, watch as b, watchPostEffect as Se } from "vue";
//#region src/components/AutoSuggestBox.vue?vue&type=script&setup=true&lang.ts
var x = (e) => h({
	name: `AutoSuggestBox.${e}`,
	__autoSuggestBoxProperty: e,
	setup() {
		return () => null;
	}
}), Ce = x("QueryIcon"), we = x("Header"), Te = x("Description"), Ee = x("HeaderTemplate"), De = d, Oe = ie, ke = ae, S = /*@__PURE__*/ h({
	QueryIcon: Ce,
	Header: we,
	Description: Te,
	HeaderTemplate: Ee,
	ItemTemplate: De,
	ItemTemplateSelector: Oe,
	Resources: ke,
	__name: "AutoSuggestBox",
	props: {
		Text: { default: "" },
		PlaceholderText: { default: "" },
		Header: { default: () => "" },
		HeaderTemplate: { default: void 0 },
		Description: { default: "" },
		QueryIcon: { default: "" },
		ItemsSource: { default: () => [] },
		ItemTemplate: { default: void 0 },
		ItemTemplateSelector: { default: void 0 },
		DisplayMemberPath: { default: "" },
		TextMemberPath: { default: "" },
		UpdateTextOnSelect: {
			type: [Boolean, String],
			default: !0
		},
		IsSuggestionListOpen: {
			type: [Boolean, String],
			default: !1
		},
		MaxSuggestionListHeight: { default: 300 },
		AutoMaximizeSuggestionArea: {
			type: [Boolean, String],
			default: !1
		},
		DesiredCandidateWindowAlignment: { default: "BottomEdge" },
		LightDismissOverlayMode: { default: "Auto" },
		TextBoxStyle: { default: void 0 },
		KeepInteriorCornersSquare: {
			type: [Boolean, String],
			default: !1
		},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		Width: { default: "" }
	},
	emits: [
		"update:Text",
		"update:IsSuggestionListOpen",
		"TextChanged",
		"SuggestionChosen",
		"QuerySubmitted"
	],
	setup(d, { expose: ie, emit: ae }) {
		let { t: S } = l(), C = d, w = me(), Ae = be(), T = m(() => e(a(C.IsEnabled, w))), je = m(() => a(C.PlaceholderText, w)), E = (e, t) => {
			i(Ae[e], w)?.($, t);
		}, Me = he(u, {}), Ne = m(() => {
			let e = a(C.TextBoxStyle, w), t = typeof C.TextBoxStyle == "string" ? C.TextBoxStyle.match(/^\{StaticResource\s+([^}]+)\}$/)?.[1] : void 0, n = t ? O[t] : e;
			if (n && typeof n == "object" && "type" in n) {
				let e = f(n).find((e) => e.props?.Property === "Background");
				return e ? a(e.props?.Value, w) : void 0;
			}
			if (e && typeof e == "object" && "Background" in e) return e.Background;
		}), Pe = n("{ThemeResource AutoSuggestBoxSuggestionsListBackground}", w), Fe = xe(), D = m(() => {
			let e = {
				Header: [],
				Description: [],
				HeaderTemplate: [],
				QueryIcon: [],
				itemTemplate: [],
				itemTemplateSelector: [],
				resources: []
			}, t = (n) => {
				for (let r of n) {
					if (r.type === p) {
						t(f(r));
						continue;
					}
					let n = r.type, i = (typeof n == "string" ? n.match(/^AutoSuggestBox\.(Header|Description|HeaderTemplate|QueryIcon)$/)?.[1] : n?.__autoSuggestBoxProperty) ?? oe(r);
					i && i in e && e[i].push(...f(r));
				}
			};
			return t(Fe.default?.() ?? []), e;
		}), Ie = m(() => {
			let e = {}, t = (n) => {
				for (let r of n) {
					let n = typeof r.type == "string" ? r.type : r.type.name;
					r.type === p || n === "ResourceDictionary" ? t(f(r)) : ne([r], e);
				}
			};
			return t(D.value.resources), e;
		}), O = new Proxy(Me, { get: (e, t) => Ie.value[t] ?? e[t] });
		v(u, O);
		let k = (e) => {
			let t = typeof e == "string" ? e.match(/^\{(?:StaticResource|ThemeResource)\s+([^}]+)\}$/)?.[1] : void 0;
			return t && O[t] ? O[t] : a(e, w);
		}, Le = (e) => ge(e) ? f(e).length ? f(e) : [e] : Array.isArray(e) ? e : [], A = y({}), j = (e) => e in A.value ? A.value[e] : C[e], Re = m(() => D.value.itemTemplate.length ? D.value.itemTemplate : k(j("ItemTemplate"))), ze = m(() => D.value.HeaderTemplate.length ? D.value.HeaderTemplate : k(j("HeaderTemplate"))), Be = m(() => !!Re.value || !!j("ItemTemplateSelector") || D.value.itemTemplateSelector.length > 0), Ve = (e) => {
			let t = k(j("ItemTemplateSelector")) ?? D.value.itemTemplateSelector[0];
			if (t && typeof t == "object") {
				let n = t, r = n.SelectTemplate ?? n.SelectTemplateCore;
				if (r) return k(r.call(t, e, $));
			}
			return Re.value;
		}, He = h({
			name: "AutoSuggestBoxItemTemplate",
			props: {
				Item: { type: null },
				Index: {
					type: Number,
					default: 0
				}
			},
			setup(e) {
				return v(ee, m(() => e.Item)), v(le, {}), () => {
					let t = Ve(e.Item);
					return typeof t == "function" ? t(e.Item) : s(Le(t), e.Item, w);
				};
			}
		}), Ue = h({ setup() {
			return v(le, {}), () => D.value.Header.length ? g(p, r(D.value.Header, w)) : Array.isArray(ze.value) ? s(ze.value, N.value, w) : g(ue, {
				Content: N.value,
				ContentTemplate: ze.value
			});
		} }), We = h({ setup() {
			return () => D.value.Description.length ? g(p, r(D.value.Description, w)) : String(Ye.value ?? "");
		} }), Ge = m(() => {
			if (D.value.QueryIcon.length) return D.value.QueryIcon;
			let e = a(C.QueryIcon, w);
			return ge(e) ? [e] : [];
		}), Ke = m(() => Ge.value.length > 0 || !!a(C.QueryIcon, w)), qe = h({ setup() {
			return () => g(p, r(Ge.value, w));
		} }), Je = h({ setup(e, { slots: t }) {
			let n = me();
			return () => g(p, r(t.default?.() ?? [], n));
		} }), M = fe();
		b(() => C.IsEnabled, M.Refresh, { flush: "post" });
		let N = m(() => a(j("Header"), w)), Ye = m(() => a(j("Description"), w)), P = ae, F = y(null), I = y(null), L = y(null), R = y(String(a(C.Text, w) ?? "")), z = y(e(a(C.IsSuggestionListOpen, w))), B = y(!1), V = y(!1), H = y(-1), Xe = y(R.value), Ze = `autosuggestbox-${w?.uid ?? 0}-suggestions`, Qe = y({}), U = y("down"), W = y(!1), $e = pe(L, {
			Origin: "edge",
			Direction: () => U.value === "up" ? "bottom" : "top",
			StripSize: 32
		}), et = he("winuiTheme", null), tt = y(""), G = m(() => z.value && T.value), nt = m(() => {
			let e = a(C.ItemsSource, w);
			return Array.isArray(e) ? e : [];
		}), rt = y(), K = m(() => rt.value ?? nt.value);
		b(nt, () => {
			rt.value = void 0;
		});
		let q = m(() => R.value), it = m(() => C.QueryIcon === "Find" ? "" : C.QueryIcon);
		v(te, {
			AutoSuggestQueryIconGlyph: it,
			TextBoxBackground: Ne,
			AutoSuggestText: q,
			AutoSuggestPlaceholder: je,
			AutoSuggestEnabled: T,
			AutoSuggestCandidateAlignment: m(() => C.DesiredCandidateWindowAlignment),
			OnTextBoxTextChanged: (e) => dt(e.Text),
			OnTextBoxGotFocus: () => ft(),
			OnTextBoxLostFocus: () => pt(),
			OnTextCompositionStarted: () => _t(),
			OnTextCompositionEnded: () => vt()
		}), v(le, {
			KeyDown: (e) => ht(e),
			ActionsWidth: () => Ke.value ? 38 : 4,
			Actions: () => Ke.value ? g("button", {
				ref: M.Attach,
				class: "win-textbox-action-button win-textbox-action-query win-asb-query-button",
				type: "button",
				disabled: !T.value,
				"aria-label": S("text.submit-query"),
				"ToolTipService.ToolTip": S("text.submit-query"),
				onPointerenter: M.PointerEntered,
				onPointerleave: M.PointerExited,
				onPointerdown: (e) => {
					e.preventDefault(), M.PointerPressed(e);
				},
				onPointerup: M.PointerReleased,
				onPointercancel: M.PointerExited,
				onLostpointercapture: M.PointerReleased,
				onKeydown: M.KeyDown,
				onKeyup: M.KeyUp,
				onBlur: M.LostFocus,
				onClick: () => Z()
			}, g("span", { class: "win-asb-query-content" }, Ge.value.length ? g(qe) : g(se, {
				class: "win-asb-icon",
				Glyph: String(it.value ?? ""),
				FontSize: 12
			}))) : null
		});
		let at = m(() => S("text.no-results-found")), ot = m(() => {
			let e = et?.value || tt.value;
			return e === "light" || e === "dark" ? `theme-${e}` : "";
		}), st = m(() => ({
			width: t(a(C.Width, w)),
			"--asb-input-bottom-radius": G.value && U.value === "down" ? "0" : "4px"
		})), J = (e) => {
			if (e && typeof e == "object") {
				let t = String(a(C.TextMemberPath, w) ?? "");
				return String((t ? e[t] : void 0) ?? e.Title ?? e.title ?? e.text ?? e.name ?? "");
			}
			return String(e ?? "");
		}, ct = (e) => {
			let t = String(a(j("DisplayMemberPath"), w) ?? "");
			if (!t) return J(e);
			let n = t.split(".").reduce((e, t) => e && typeof e == "object" ? e[t] : void 0, e);
			return String(n ?? "");
		}, lt = (e) => {
			if (e && typeof e == "object" && e.noResults === !0) return !0;
			let t = J(e).trim();
			return t.toLowerCase() === "no results found" || t === at.value.trim();
		}, ut = m(() => K.value.map((e, t) => lt(e) ? -1 : t).filter((e) => e >= 0)), Y = async (e) => {
			let t = z.value;
			e && K.value.length > 0 ? (t || (H.value = -1), Q(), z.value = !0, P("update:IsSuggestionListOpen", !0), o(C.IsSuggestionListOpen, !0, w), await _(), Q(), await _(), t || $e.play()) : (z.value = !1, P("update:IsSuggestionListOpen", !1), o(C.IsSuggestionListOpen, !1, w), $e.cancel());
		}, dt = (e) => {
			e !== R.value && (R.value = e, Xe.value = e, H.value = -1, o(C.Text, e, w), P("update:Text", e), P("TextChanged", $, { Reason: "UserInput" }), E("TextChanged", { Reason: "UserInput" }), V.value = !0, _(() => {
				B.value && V.value && Y(K.value.length > 0);
			}));
		}, ft = () => {
			B.value = !0;
		}, pt = () => {
			B.value = !1, V.value = !1, W.value = !1, Y(!1);
		}, X = (t, n = !1) => {
			let r = K.value[t];
			if (r === void 0 || lt(r)) return;
			let i = J(r);
			e(a(C.UpdateTextOnSelect, w)) && (R.value = i, o(C.Text, i, w), P("update:Text", i), P("TextChanged", $, { Reason: "SuggestionChosen" }), E("TextChanged", { Reason: "SuggestionChosen" })), P("SuggestionChosen", $, { SelectedItem: r }), E("SuggestionChosen", { SelectedItem: r }), n && Z(r, q.value);
		}, mt = (e) => {
			H.value = e, X(e, !0), I.value?.querySelector("input, textarea")?.focus();
		}, Z = (e = null, t = q.value) => {
			V.value = !1, P("QuerySubmitted", $, {
				QueryText: t,
				ChosenSuggestion: e
			}), E("QuerySubmitted", {
				QueryText: t,
				ChosenSuggestion: e
			}), Y(!1);
		}, ht = (e) => {
			if (!(e.isComposing || e.keyCode === 229 || W.value || !T.value)) {
				if (!G.value || !K.value.length) {
					e.key === "Enter" && (e.preventDefault(), Z());
					return;
				}
				if (e.key === "ArrowDown") {
					e.preventDefault();
					let t = ut.value, n = t.indexOf(H.value), r = t[Math.min(n + 1, t.length - 1)] ?? -1;
					r !== H.value && (H.value = r, r >= 0 && X(r));
				} else if (e.key === "ArrowUp") {
					e.preventDefault();
					let t = ut.value, n = t.indexOf(H.value), r = t[Math.max(n - 1, 0)] ?? -1;
					r !== H.value && (H.value = r, r >= 0 && X(r));
				} else e.key === "Enter" ? (e.preventDefault(), Z(H.value >= 0 ? K.value[H.value] : null)) : e.key === "Escape" ? (e.preventDefault(), V.value = !1, bt(Xe.value), Y(!1)) : e.key === "Tab" && (V.value = !1, Y(!1));
			}
		}, gt = () => {
			let e = F.value?.closest(".theme-light, .theme-dark");
			return e?.classList.contains("theme-dark") ? "dark" : e?.classList.contains("theme-light") ? "light" : "";
		}, Q = () => {
			tt.value = gt();
			let t = (I.value?.querySelector(".win-textbox-border"))?.getBoundingClientRect() ?? I.value?.getBoundingClientRect() ?? F.value?.getBoundingClientRect();
			if (!t) return;
			let n = window.visualViewport, r = n?.offsetTop ?? 0, i = r + (n?.height ?? window.innerHeight), o = F.value?.closest(".example-display")?.getBoundingClientRect(), ee = Math.max(r, (o?.top ?? r) + +!!o), te = Math.min(i, (o?.bottom ?? i) - +!!o), s = o ? Math.max(t.left, o.left + 1) : t.left, ne = o ? Math.max(0, Math.min(t.width, o.right - 1 - s)) : t.width, c = Number(a(C.MaxSuggestionListHeight, w)) || 300, re = W.value && C.DesiredCandidateWindowAlignment === "BottomEdge", l = re ? 40 : 0, u = Math.max(0, te - t.bottom - l), d = Math.max(0, t.top - ee - l);
			if (U.value = re || u >= Math.min(c, 160) || u >= d ? "down" : "up", U.value === "up") {
				Qe.value = {
					left: `${s}px`,
					bottom: `${window.innerHeight - t.top + l}px`,
					width: `${ne}px`,
					maxHeight: `${e(a(C.AutoMaximizeSuggestionArea, w)) ? Math.max(0, d) : Math.min(c, Math.max(0, d))}px`,
					"--asb-input-bottom-radius": "4px",
					"--asb-popup-radius": "8px 8px 0 0"
				};
				return;
			}
			Qe.value = {
				left: `${s}px`,
				top: `${t.bottom + l}px`,
				width: `${ne}px`,
				maxHeight: `${e(a(C.AutoMaximizeSuggestionArea, w)) ? Math.max(0, u) : Math.min(c, Math.max(0, u))}px`,
				"--asb-input-bottom-radius": z.value ? "0" : "4px",
				"--asb-popup-radius": "0 0 8px 8px"
			};
		}, _t = () => {
			W.value = !0, G.value && Q();
		}, vt = () => {
			W.value = !1, G.value && requestAnimationFrame(Q);
		}, yt = (e) => {
			let t = e.target;
			F.value?.contains(t) || L.value?.contains(t) || (V.value = !1, Y(!1));
		}, bt = (e) => {
			e !== R.value && (R.value = e, P("update:Text", e), o(C.Text, e, w), P("TextChanged", $, { Reason: "ProgrammaticChange" }), E("TextChanged", { Reason: "ProgrammaticChange" }));
		};
		b(() => a(C.Text, w), (e) => bt(String(e ?? ""))), b(() => a(C.IsSuggestionListOpen, w), (t) => Y(e(t))), b(K, () => {
			(G.value || B.value && V.value) && (H.value >= K.value.length && (H.value = -1), Y(K.value.length > 0));
		}, { deep: !0 }), b(T, (e) => {
			e || (B.value = !1, V.value = !1, Y(!1));
		}), b(H, () => {
			_(() => L.value?.querySelector(".is-highlighted")?.scrollIntoView({ block: "nearest" }));
		}), Se(() => {
			let e = I.value?.querySelector("input");
			if (!e) return;
			e.setAttribute("role", "combobox"), e.setAttribute("aria-autocomplete", "list"), e.setAttribute("aria-expanded", String(G.value)), e.setAttribute("aria-controls", Ze);
			let t = a(Ae["AutomationProperties.Name"], w);
			t && e.setAttribute("aria-label", String(t)), H.value >= 0 ? e.setAttribute("aria-activedescendant", `${Ze}-${H.value}`) : e.removeAttribute("aria-activedescendant");
		}), ve(() => {
			document.addEventListener("pointerdown", yt), window.addEventListener("resize", Q), window.addEventListener("scroll", Q, !0), window.visualViewport?.addEventListener("resize", Q), window.visualViewport?.addEventListener("scroll", Q);
		}), _e(() => {
			$e.cancel(), document.removeEventListener("pointerdown", yt), window.removeEventListener("resize", Q), window.removeEventListener("scroll", Q, !0), window.visualViewport?.removeEventListener("resize", Q), window.visualViewport?.removeEventListener("scroll", Q);
		});
		let $ = ye({
			Text: m({
				get: () => q.value,
				set: (e) => bt(String(e))
			}),
			ItemsSource: m({
				get: () => K.value,
				set: (e) => {
					rt.value = e, o(C.ItemsSource, e, w);
				}
			}),
			IsSuggestionListOpen: m({
				get: () => G.value,
				set: (e) => {
					Y(e);
				}
			}),
			ItemTemplate: m({
				get: () => j("ItemTemplate"),
				set: (e) => {
					A.value.ItemTemplate = e, o(C.ItemTemplate, e, w);
				}
			}),
			ItemTemplateSelector: m({
				get: () => j("ItemTemplateSelector"),
				set: (e) => {
					A.value.ItemTemplateSelector = e, o(C.ItemTemplateSelector, e, w);
				}
			}),
			DisplayMemberPath: m({
				get: () => j("DisplayMemberPath"),
				set: (e) => {
					A.value.DisplayMemberPath = e, o(C.DisplayMemberPath, e, w);
				}
			}),
			Header: m({
				get: () => N.value,
				set: (e) => {
					A.value.Header = e, o(C.Header, e, w);
				}
			}),
			HeaderTemplate: m({
				get: () => j("HeaderTemplate"),
				set: (e) => {
					A.value.HeaderTemplate = e, o(C.HeaderTemplate, e, w);
				}
			}),
			Description: m({
				get: () => Ye.value,
				set: (e) => {
					A.value.Description = e, o(C.Description, e, w);
				}
			}),
			Element: F,
			Focus: () => (I.value?.querySelector("input")?.focus(), !0)
		});
		ie($);
		let xt = {
			property: x,
			AutoSuggestBoxQueryIcon: Ce,
			AutoSuggestBoxHeader: we,
			AutoSuggestBoxDescription: Te,
			AutoSuggestBoxHeaderTemplate: Ee,
			AutoSuggestBoxItemTemplate: De,
			AutoSuggestBoxItemTemplateSelector: Oe,
			AutoSuggestBoxResources: ke,
			t: S,
			props: C,
			instance: w,
			attrs: Ae,
			isEnabled: T,
			resolvedPlaceholder: je,
			dispatchXamlEvent: E,
			inheritedResources: Me,
			TextBoxBackground: Ne,
			suggestionsBackgroundStyle: Pe,
			slots: Fe,
			propertyNodes: D,
			localResources: Ie,
			resources: O,
			templateValue: k,
			templateNodes: Le,
			propertyOverrides: A,
			propertyValue: j,
			resolvedItemTemplate: Re,
			resolvedHeaderTemplate: ze,
			hasItemTemplate: Be,
			selectedItemTemplate: Ve,
			ItemRenderer: He,
			HeaderOutlet: Ue,
			DescriptionOutlet: We,
			queryIconNodes: Ge,
			hasQueryIcon: Ke,
			QueryIconOutlet: qe,
			TextBoxTemplate: Je,
			AnimatedQueryInput: M,
			resolvedHeader: N,
			resolvedDescription: Ye,
			emit: P,
			rootRef: F,
			anchorRef: I,
			popupRef: L,
			localText: R,
			localOpen: z,
			isTextBoxFocused: B,
			shouldOpenForUserInput: V,
			highlightedIndex: H,
			originalQuery: Xe,
			popupId: Ze,
			popupStyle: Qe,
			openDirection: U,
			isComposing: W,
			flyoutAnimation: $e,
			inheritedTheme: et,
			anchorTheme: tt,
			isOpen: G,
			sourceItems: nt,
			localItems: rt,
			suggestionItems: K,
			currentText: q,
			resolvedQueryIcon: it,
			localizedNoResultsText: at,
			popupThemeClass: ot,
			rootStyle: st,
			getItemText: J,
			getItemLabel: ct,
			isNoResultsItem: lt,
			selectableIndexes: ut,
			setOpen: Y,
			onTextInput: dt,
			onFocus: ft,
			onBlur: pt,
			chooseSuggestion: X,
			onSuggestionClick: mt,
			submitQuery: Z,
			onKeydown: ht,
			resolveAnchorTheme: gt,
			updatePopupPosition: Q,
			onCompositionStart: _t,
			onCompositionEnd: vt,
			onDocumentPointerDown: yt,
			setProgrammaticText: bt,
			api: $,
			ScrollViewer: ce,
			TextBox: de,
			get vAcrylicBrush() {
				return c;
			},
			get vThemeShadow() {
				return re;
			}
		};
		return Object.defineProperty(xt, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), xt;
	}
});
//#endregion
export { Te as AutoSuggestBoxDescription, we as AutoSuggestBoxHeader, Ee as AutoSuggestBoxHeaderTemplate, De as AutoSuggestBoxItemTemplate, Oe as AutoSuggestBoxItemTemplateSelector, Ce as AutoSuggestBoxQueryIcon, ke as AutoSuggestBoxResources, S as default };

//# sourceMappingURL=AutoSuggestBox.vue_vue_type_script_setup_true_lang.js.map