import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./RichTextBlock.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                  */
import { Fragment as n, createBlock as r, createCommentVNode as i, createElementBlock as a, createElementVNode as o, createVNode as s, mergeProps as c, normalizeClass as l, openBlock as u } from "vue";
//#region src/components/RichTextBlock.vue
var d = ["aria-hidden", "inert"], f = {
	key: 0,
	ref: "flow",
	class: "win-rich-text-flow"
};
function p(e, t, p, m, h, g) {
	return u(), a(n, null, [o("div", c({ ref: "element" }, m.forwardedAttrs, {
		class: ["win-rich-text-block", { "is-selectable": m.selectionEnabled }],
		style: [m.attrs.style, m.style],
		onContextmenu: m.onContextMenu,
		onCopy: m.onCopy
	}), [o("div", {
		ref: "source",
		class: l({ "win-rich-text-source": m.hasOverflow }),
		"aria-hidden": m.hasOverflow || void 0,
		inert: m.hasOverflow || void 0
	}, [s(m.ContentOutlet)], 10, d), m.hasOverflow ? (u(), a("div", f, null, 512)) : i("", !0)], 16), m.selectionEnabled ? (u(), r(m.ContextMenu, { key: 0 })) : i("", !0)], 64);
}
var m = /*#__PURE__*/ e(t, [["render", p], ["__file", "RichTextBlock.vue"]]);
//#endregion
export { m as default };

//# sourceMappingURL=RichTextBlock.vue.js.map