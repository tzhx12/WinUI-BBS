import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./ListView.vue_vue_type_script_setup_true_lang.js";
/* empty css                                             */
import { Fragment as n, createBlock as r, createCommentVNode as i, createElementBlock as a, createElementVNode as o, createVNode as s, normalizeClass as c, normalizeStyle as l, openBlock as u, renderList as d, resolveDynamicComponent as f, withCtx as p, withDirectives as m, withKeys as h, withModifiers as g } from "vue";
//#region src/components/ListView.vue
var _ = ["aria-disabled", "aria-multiselectable"], v = {
	key: 0,
	class: "win-list-header-presenter"
}, y = { class: "win-list-header-content" }, b = [
	"tabindex",
	"aria-selected",
	"onClick",
	"onContextmenu",
	"onPointerdown",
	"onPointermove",
	"onPointerleave",
	"onKeydown"
], x = { class: "win-list-item-visual" }, S = { class: "win-list-header-content" }, C = [
	"tabindex",
	"aria-selected",
	"onClick",
	"onContextmenu",
	"onPointerdown",
	"onPointermove",
	"onPointerleave",
	"onKeydown"
], w = { class: "win-list-item-visual" };
function T(e, t, T, E, D, O) {
	return m((u(), a("div", {
		ref: "containerRef",
		class: c(["win-list-view", { disabled: !E.resolvedIsEnabled }]),
		style: l(E.rootStyle),
		role: "listbox",
		"aria-disabled": !E.resolvedIsEnabled,
		onKeydown: E.onSemanticKeyDown,
		"aria-multiselectable": E.selectionMode === "Multiple" || E.selectionMode === "Extended"
	}, [s(E.ScrollViewer, {
		class: c(["win-list-viewport", { "items-bottom-host": E.itemsPanelBottom }]),
		VerticalScrollMode: "{x:Bind ScrollSettings.VerticalScrollMode, Mode=OneWay}",
		VerticalScrollBarVisibility: "{x:Bind ScrollSettings.VerticalScrollBarVisibility, Mode=OneWay}",
		HorizontalScrollMode: "{x:Bind ScrollSettings.HorizontalScrollMode, Mode=OneWay}",
		HorizontalScrollBarVisibility: "{x:Bind ScrollSettings.HorizontalScrollBarVisibility, Mode=OneWay}",
		IsHorizontalRailEnabled: "{x:Bind ScrollSettings.IsHorizontalRailEnabled, Mode=OneWay}",
		IsVerticalRailEnabled: "{x:Bind ScrollSettings.IsVerticalRailEnabled, Mode=OneWay}",
		IsVerticalScrollChainingEnabled: "{x:Bind ScrollSettings.IsVerticalScrollChainingEnabled, Mode=OneWay}",
		IsHorizontalScrollChainingEnabled: "{x:Bind ScrollSettings.IsHorizontalScrollChainingEnabled, Mode=OneWay}",
		IsEnabled: "{x:Bind ScrollTemplateIsEnabled, Mode=OneWay}",
		ZoomMode: "{x:Bind ScrollSettings.ZoomMode, Mode=OneWay}"
	}, {
		default: p(() => [o("div", {
			ref: "listRef",
			class: c([{
				"items-bottom": E.itemsPanelBottom,
				"drag-sinking": E.isDragging || E.isExternalDragOver
			}, "win-list-content"]),
			style: l(E.contentPaddingStyle),
			onDragover: E.onViewportDragOver,
			onDrop: E.onViewportDrop,
			onDragleave: E.onViewportDragLeave
		}, [E.propertyTemplateNodes.headerTemplate.length ? (u(), a("div", v, [s(E.HeaderOutlet)])) : i("", !0), E.isGrouped ? (u(!0), a(n, { key: 1 }, d(E.items, (e, p) => (u(), a("div", {
			key: E.getGroupKey(e, p),
			class: "win-list-group"
		}, [o("div", { class: c(["win-list-header", { sticky: E.stickyHeader }]) }, [o("div", y, [(u(), r(f(E.groupHeaderComponent(e))))]), t[8] ||= o("div", {
			class: "win-list-header-divider",
			"aria-hidden": "true"
		}, null, -1)], 2), (u(!0), a(n, null, d(E.getGroupItems(e), (n, d) => (u(), a("div", {
			key: E.groupItemKeys.get(e)?.[d],
			ref_for: !0,
			ref: E.itemContainerRef(E.groupItemKeys.get(e)?.[d], n, d, e),
			class: c(["win-list-item", E.itemClasses(n)]),
			style: l(E.itemContainerStyle),
			draggable: !1,
			tabindex: E.resolvedIsEnabled && (E.selectionMode !== "None" || E.semanticView.SemanticZoomOwner.value) ? 0 : -1,
			"aria-selected": E.selectionMode === "None" ? void 0 : E.isSelected(n),
			onClick: (e) => E.onItemClick(e, n),
			onContextmenu: (t) => E.onItemContextRequested(t, n, d, e),
			onPointerdown: (e) => E.onItemPointerDown(e, n),
			onPointermove: (e) => E.onItemPointerMove(e, d),
			onPointerup: t[0] ||= (e) => E.onItemPointerUp(e),
			onPointercancel: t[1] ||= (e) => E.onItemPointerCancel(e),
			onPointerleave: (e) => E.onItemPointerLeave(e, n),
			onLostpointercapture: t[2] ||= (e) => E.onItemLostPointerCapture(e),
			onKeydown: [h(g((e) => E.onItemClick(e, n), ["prevent"]), ["enter"]), h(g((e) => E.onItemClick(e, n), ["prevent"]), ["space"])],
			onDragstart: t[3] ||= g(() => {}, ["prevent"])
		}, [o("div", x, [
			s(E.SelectionCheck, {
				class: c(["list-selection-check", { "is-visible": E.selectionMode === "Multiple" }]),
				Item: n,
				"aria-hidden": "true"
			}, null, 8, ["class", "Item"]),
			o("div", {
				class: "win-list-item-content",
				style: l(E.itemContentStyle)
			}, [(u(), r(f(E.itemComponent(n, d, e))))], 4),
			E.selectionMode !== "None" && E.selectionMode !== "Multiple" ? (u(), a("div", {
				key: 0,
				class: c(["win-list-view-selection-indicator", { active: E.isSelected(n) }]),
				style: l(E.selectionIndicatorStyle()),
				"aria-hidden": "true"
			}, null, 6)) : i("", !0)
		])], 46, b))), 128))]))), 128)) : (u(), a(n, { key: 2 }, [E.propertyTemplateNodes.groupHeaderTemplate.length ? (u(), a("div", {
			key: 0,
			class: c(["win-list-header", { sticky: E.stickyHeader }])
		}, [o("div", S, [(u(), r(f(E.groupHeaderComponent(null))))]), t[9] ||= o("div", {
			class: "win-list-header-divider",
			"aria-hidden": "true"
		}, null, -1)], 2)) : i("", !0), (u(!0), a(n, null, d(E.internalItems, (e, n) => (u(), a("div", {
			key: E.itemKeys[n],
			ref_for: !0,
			ref: E.itemContainerRef(E.itemKeys[n], e, n),
			class: c(["win-list-item", E.itemClasses(e, n)]),
			style: l([E.itemContainerStyle, E.getItemStyle(n)]),
			draggable: !1,
			tabindex: E.resolvedIsEnabled && (E.selectionMode !== "None" || E.semanticView.SemanticZoomOwner.value) ? 0 : -1,
			"aria-selected": E.selectionMode === "None" ? void 0 : E.isSelected(e),
			onClick: (t) => E.onItemClick(t, e),
			onContextmenu: (t) => E.onItemContextRequested(t, e, n),
			onPointerdown: (t) => E.onItemPointerDown(t, e),
			onPointermove: (e) => E.onItemPointerMove(e, n),
			onPointerup: t[4] ||= (e) => E.onItemPointerUp(e),
			onPointercancel: t[5] ||= (e) => E.onItemPointerCancel(e),
			onPointerleave: (t) => E.onItemPointerLeave(t, e),
			onLostpointercapture: t[6] ||= (e) => E.onItemLostPointerCapture(e),
			onKeydown: [h(g((t) => E.onItemClick(t, e), ["prevent"]), ["enter"]), h(g((t) => E.onItemClick(t, e), ["prevent"]), ["space"])],
			onDragstart: t[7] ||= g(() => {}, ["prevent"])
		}, [o("div", w, [
			s(E.SelectionCheck, {
				class: c(["list-selection-check", { "is-visible": E.selectionMode === "Multiple" }]),
				Item: e,
				"aria-hidden": "true"
			}, null, 8, ["class", "Item"]),
			o("div", {
				class: "win-list-item-content",
				style: l(E.itemContentStyle)
			}, [(u(), r(f(E.itemComponent(e, n))))], 4),
			E.selectionMode !== "None" && E.selectionMode !== "Multiple" ? (u(), a("div", {
				key: 0,
				class: c(["win-list-view-selection-indicator", { active: E.isSelected(e) }]),
				style: l(E.selectionIndicatorStyle()),
				"aria-hidden": "true"
			}, null, 6)) : i("", !0)
		])], 46, C))), 128))], 64))], 38)]),
		_: 1
	}, 8, ["class"]), s(E.ContextFlyoutOutlet)], 46, _)), [[E.vAcrylicBrush, E.backgroundStyle]]);
}
var E = /*#__PURE__*/ e(t, [["render", T], ["__file", "ListView.vue"]]);
//#endregion
export { E as default };

//# sourceMappingURL=ListView.vue.js.map