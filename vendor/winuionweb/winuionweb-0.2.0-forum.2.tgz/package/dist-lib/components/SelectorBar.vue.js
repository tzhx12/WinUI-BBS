import { selectorBarStyleSetter as e } from "./selectorBarResources.js";
import { resolveXamlHandler as t, resolveXamlValue as n, updateXamlBinding as r } from "./xamlRuntime.js";
import { frameworkLayoutStyle as i } from "./frameworkLayout.js";
import a from "../_virtual/_plugin-vue_export-helper.js";
import { StackLayout as ee } from "./CollectionProperties.js";
import o from "./ItemsView.vue.js";
import { SelectorBarItems as s, createSelectorBarItem as c, selectorBarItemKey as l, selectorBarPointerFocusKey as u } from "./selectorBarRuntime.js";
import d from "./SelectorBarItem.vue.js";
/* empty css                                                                */
import { Comment as f, Fragment as p, Text as m, computed as h, createElementBlock as g, createVNode as _, defineComponent as v, getCurrentInstance as te, h as y, markRaw as b, mergeProps as x, openBlock as S, ref as C, shallowReactive as w, toRaw as T, useAttrs as E, useSlots as ne, watch as D } from "vue";
//#region src/components/SelectorBar.vue
var O = /*@__PURE__*/ Object.assign({ Items: s }, { inheritAttrs: !1 }, {
	__name: "SelectorBar",
	props: {
		Style: {
			type: [String, Object],
			default: null
		},
		Items: {
			type: [Array, String],
			default: void 0
		},
		SelectedItem: {
			type: null,
			default: void 0
		},
		Padding: {
			type: [String, Number],
			default: "{ThemeResource SelectorBarPadding}"
		},
		Background: {
			type: String,
			default: "Transparent"
		},
		BorderBrush: {
			type: String,
			default: "Transparent"
		},
		CornerRadius: {
			type: [String, Number],
			default: 0
		},
		Width: {
			type: [String, Number],
			default: ""
		},
		Height: {
			type: [String, Number],
			default: ""
		},
		MinWidth: {
			type: [String, Number],
			default: 0
		},
		MinHeight: {
			type: [String, Number],
			default: 0
		},
		MaxWidth: {
			type: [String, Number],
			default: ""
		},
		MaxHeight: {
			type: [String, Number],
			default: ""
		},
		Margin: {
			type: [String, Number],
			default: 0
		},
		HorizontalAlignment: {
			type: String,
			default: "Left"
		},
		VerticalAlignment: {
			type: String,
			default: "Top"
		},
		TabNavigation: {
			type: String,
			default: "Once"
		},
		IsTabStop: {
			type: [Boolean, String],
			default: !1
		},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		FlowDirection: {
			type: String,
			default: "LeftToRight"
		}
	},
	emits: ["SelectionChanged", "update:SelectedItem"],
	setup(a, { expose: g, emit: _ }) {
		let x = a, S = _, O = E(), k = ne(), A = te(), j = C(null), M = C(null), N = w([]), P = C(null), F = C(void 0), I = C(void 0), L = C(void 0), R = h(() => L.value ?? n(x.Style, A)), re = h(() => R.value?.Key === "TokenViewSelectorBarStyle"), z = (t) => n(A?.vnode.props?.[t] === void 0 ? e(R.value, t, "SelectorBar") ?? x[t] : x[t], A), B = h(() => F.value ?? n(x.IsEnabled, A) !== !1), V = h(() => I.value ?? n(x.FlowDirection, A)), ie = h(() => ({
			...i({
				...Object.fromEntries(Object.keys(x).map((e) => [e, z(e)])),
				Padding: void 0
			}, A),
			direction: V.value === "RightToLeft" ? "rtl" : "ltr"
		})), ae = h(() => {
			let { class: e, style: t, SelectionChanged: n, ...r } = O;
			return r;
		}), H = (e, t) => T(e) === T(t), U = !1, W = (e) => {
			if (H(P.value, e)) return;
			P.value?.SynchronizeSelection?.(!1), P.value = e;
			for (let t of N) t.SynchronizeSelection?.(H(t, e));
			r(x.SelectedItem, e, A), S("update:SelectedItem", e);
			let n = Object.freeze({});
			S("SelectionChanged", q, n), t(O.SelectionChanged, A)?.(q, n);
		}, G = (e) => {
			let t = e && typeof e == "object" ? X.get(T(e)) : null, n = e == null ? null : N.find((n) => H(n, e) || H(n, t));
			if (e != null && !n) throw TypeError("SelectedItem must be an element of Items.");
			H(P.value, n) || (M.value ? n === null ? M.value.DeselectAll() : M.value.Select(N.indexOf(n)) : W(n));
		}, K = (e, t) => {
			U && (t ? G(e) : H(P.value, e) && G(null));
		}, q = {
			get Style() {
				return R.value;
			},
			set Style(e) {
				L.value = n(e, A), r(x.Style, e, A);
			},
			get Items() {
				return N;
			},
			get SelectedItem() {
				return P.value;
			},
			set SelectedItem(e) {
				G(e);
			},
			get IsEnabled() {
				return B.value;
			},
			set IsEnabled(e) {
				F.value = e !== !1 && e !== "False";
			},
			get FlowDirection() {
				return V.value;
			},
			set FlowDirection(e) {
				I.value = e;
			}
		};
		Object.defineProperties(N, {
			Size: { get: () => N.length },
			Count: { get: () => N.length },
			GetAt: { value: (e) => N[e] },
			IndexOf: { value: (e) => N.findIndex((t) => H(t, e)) },
			Append: { value: (e) => N.push(e) },
			Add: { value: (e) => N.push(e) },
			InsertAt: { value: (e, t) => N.splice(e, 0, t) },
			RemoveAt: { value: (e) => N.splice(e, 1) },
			Clear: { value: () => N.splice(0) }
		});
		let J = (e) => (e ?? []).flatMap((e) => !e || e.type === f || e.type === m ? [] : e.type === p ? J(e.children) : e.type?.__selectorBarProperty === "Items" ? J(e.children?.default?.() ?? e.children) : [e]), Y = /* @__PURE__ */ new Map(), X = /* @__PURE__ */ new WeakMap(), Z = [], Q, oe = v({
			name: "SelectorBarTemplate",
			setup() {
				return () => {
					let e = n(x.Items, A), t = Array.isArray(e) ? e : null, r = t ? [] : J(k.default?.()).filter((e) => (e.type?.name || e.type?.__name) === "SelectorBarItem"), i = t ?? r.map((e, t) => e.key ?? e.props?.["data-xaml-ref"] ?? e.props?.["x:Name"] ?? t), a = t ? t.map((e) => {
						if (e?.[l]) return e;
						if (!e || typeof e != "object") throw TypeError("Items must contain SelectorBarItem elements.");
						let t = X.get(T(e));
						return t ? t.UpdateNode(y(d, e)) : (t = b(c(y(d, e), A, K)), X.set(T(e), t)), t;
					}) : r.map((e, t) => {
						let n = i[t], r = Y.get(n);
						return r ? r.UpdateNode(e) : (r = b(c(e, A, K)), Y.set(n, r)), r;
					});
					return (Q !== t || i.length !== Z.length || i.some((e, t) => !H(e, Z[t]))) && (N.splice(0, N.length, ...a), Z = [...i], Q = t), y(o, {
						ref: M,
						class: "win-selector-bar-items-view",
						"data-template-part": "PART_ItemsView",
						ItemsSource: N,
						IsEnabled: B.value,
						FlowDirection: V.value,
						TabNavigation: z("TabNavigation"),
						MaxWidth: n(x.MaxWidth, A),
						MaxHeight: n(x.MaxHeight, A),
						Padding: z("Padding"),
						onSelectionChanged: (e) => W(e.SelectedItems[0] ?? null),
						onVnodeMounted: () => {
							U = !0;
							let e = n(x.SelectedItem, A);
							if (e !== void 0) G(e);
							else {
								let e = N.find((e) => e.IsSelected === !0);
								e && G(e);
							}
						}
					}, { default: () => [y(o.Layout, null, { default: () => [y(ee, {
						Orientation: "Horizontal",
						...re.value ? { Spacing: 8 } : {}
					})] })] });
				};
			}
		});
		D(() => n(x.SelectedItem, A), (e) => {
			U && G(e);
		}, { flush: "post" }), D(() => n(x.IsEnabled, A), () => {
			F.value = void 0;
		}), D(() => n(x.FlowDirection, A), () => {
			I.value = void 0;
		}), D(() => n(x.Style, A), () => {
			L.value = void 0;
		});
		let $ = (e) => e.IsEnabled !== !1 && e.IsTabStop !== !1 && e.Visibility !== "Collapsed", se = (e) => {
			if (e.target?.[u] || !B.value || P.value && $(P.value)) return;
			let t = N[M.value?.CurrentItemIndex ?? -1], n = t && $(t) ? t : N.find($);
			n && G(n);
		};
		g(q);
		let ce = {
			props: x,
			emit: S,
			attrs: O,
			slots: k,
			instance: A,
			rootRef: j,
			itemsViewRef: M,
			items: N,
			selectedItem: P,
			localEnabled: F,
			localDirection: I,
			localStyle: L,
			appliedStyle: R,
			isTokenStyle: re,
			read: z,
			isEnabled: B,
			flowDirection: V,
			rootStyle: ie,
			rootAttrs: ae,
			same: H,
			get ready() {
				return U;
			},
			set ready(e) {
				U = e;
			},
			publishSelection: W,
			setSelectedItem: G,
			onItemSelected: K,
			publicApi: q,
			flatten: J,
			slotItems: Y,
			sourceItems: X,
			get lastKeys() {
				return Z;
			},
			set lastKeys(e) {
				Z = e;
			},
			get lastSource() {
				return Q;
			},
			set lastSource(e) {
				Q = e;
			},
			ItemsOutlet: oe,
			focusable: $,
			onGotFocus: se,
			get SelectorBarItems() {
				return s;
			},
			Comment: f,
			Fragment: p,
			Text: m,
			computed: h,
			defineComponent: v,
			getCurrentInstance: te,
			h: y,
			markRaw: b,
			ref: C,
			shallowReactive: w,
			toRaw: T,
			useAttrs: E,
			useSlots: ne,
			watch: D,
			ItemsView: o,
			SelectorBarItem: d,
			get StackLayout() {
				return ee;
			},
			get frameworkLayoutStyle() {
				return i;
			},
			get createSelectorBarItem() {
				return c;
			},
			get selectorBarItemKey() {
				return l;
			},
			get selectorBarPointerFocusKey() {
				return u;
			},
			get selectorBarStyleSetter() {
				return e;
			},
			get resolveXamlHandler() {
				return t;
			},
			get resolveXamlValue() {
				return n;
			},
			get updateXamlBinding() {
				return r;
			}
		};
		return Object.defineProperty(ce, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), ce;
	}
}), k = ["dir", "aria-disabled"];
function A(e, t, n, r, i, a) {
	return S(), g("div", x({ ref: "rootRef" }, r.rootAttrs, {
		class: ["win-selector-bar", r.attrs.class],
		style: [r.attrs.style, r.rootStyle],
		dir: r.flowDirection === "RightToLeft" ? "rtl" : "ltr",
		"aria-disabled": !r.isEnabled || void 0,
		onFocusin: r.onGotFocus
	}), [_(r.ItemsOutlet)], 16, k);
}
var j = /*#__PURE__*/ a(O, [
	["render", A],
	["__scopeId", "data-v-b2bf98c2"],
	["__file", "SelectorBar.vue"]
]);
//#endregion
export { j as default };

//# sourceMappingURL=SelectorBar.vue.js.map