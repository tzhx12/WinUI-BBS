//#region src/components/personPictureInitials.ts
var e = [
	[592, 687],
	[1536, 1791],
	[1872, 1919],
	[2208, 2303],
	[64336, 65023],
	[65136, 65279],
	[2304, 2431],
	[43232, 43263],
	[2432, 2559],
	[2560, 2687],
	[2688, 2815],
	[2816, 2943],
	[2944, 3071],
	[3072, 3199],
	[3200, 3327],
	[3328, 3455],
	[3456, 3583],
	[3584, 3711],
	[3712, 3839]
], t = [
	[19968, 40959],
	[13312, 19903],
	[131072, 173791],
	[173824, 177983],
	[177984, 178207],
	[11904, 12031],
	[12288, 12351],
	[12736, 12783],
	[12800, 13055],
	[13056, 13311],
	[63744, 64255],
	[65072, 65103],
	[194560, 195103],
	[880, 1023],
	[1424, 1535],
	[1328, 1423]
], n = [
	[1, 127],
	[128, 255],
	[256, 383],
	[384, 591],
	[11360, 11391],
	[42784, 43007],
	[43824, 43887],
	[7680, 7935],
	[1024, 1279],
	[1280, 1327],
	[768, 879]
];
function r(e, t) {
	return t.some(([t, n]) => e >= t && e <= n);
}
function i(i) {
	return r(i, e) ? 3 : r(i, t) ? 2 : +!!r(i, n);
}
function a(e) {
	let t = 0;
	for (let n = 0; n < Math.min(3, e.length); n++) {
		let r = e.charCodeAt(n);
		if (r === 0 || r === 65279) break;
		t = Math.max(t, i(r));
	}
	return t;
}
function o(e) {
	if (!e) return "";
	let t = 0;
	for (; t < e.length;) {
		let n = e.charCodeAt(t);
		if (n >= 33 && n <= 47 || n >= 58 && n <= 64 || n >= 123 && n <= 126) {
			t++;
			continue;
		}
		break;
	}
	t >= e.length && (t = 0);
	let n = t + 1;
	for (; n < e.length;) {
		let t = e.charCodeAt(n);
		if (t < 768 || t > 879) break;
		n++;
	}
	return e.slice(t, n);
}
function s(e) {
	let t = "";
	for (let n = 0; n < e.length; n++) {
		let r = e[n], i = r.toUpperCase();
		t += i.length === 1 ? i : r;
	}
	return t;
}
function c(e) {
	for (let [t, n] of [
		["{", "}"],
		["(", ")"],
		["[", "]"]
	]) {
		if (!e.endsWith(n)) continue;
		let r = e.lastIndexOf(t);
		if (r >= 0) return e.slice(0, r);
	}
	return e;
}
function l(e) {
	let t = e ?? "";
	if (a(t) !== 1) return "";
	let n = t.split("\0", 1)[0], r = c(n).split(" ").slice(0, 25).filter(Boolean);
	return r.length === 0 ? "" : s(o(r[0]) + (r.length > 1 ? o(r[r.length - 1]) : ""));
}
function u(e) {
	if (!e) return "";
	let t = e.FirstName ?? "", n = e.LastName ?? "";
	return t && n ? a(t) === 1 ? s(o(t) + o(n)) : "" : l(e.DisplayName);
}
//#endregion
export { u as initialsFromContactObject, l as initialsFromDisplayName };

//# sourceMappingURL=personPictureInitials.js.map