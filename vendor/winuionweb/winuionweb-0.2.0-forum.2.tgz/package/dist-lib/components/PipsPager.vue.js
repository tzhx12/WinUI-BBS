import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./PipsPager.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                              */
import { createElementBlock as n, createVNode as r, mergeProps as i, normalizeClass as a, openBlock as o, withCtx as s } from "vue";
//#region src/components/PipsPager.vue
var c = [
	"dir",
	"aria-label",
	"aria-disabled"
];
function l(e, t, l, u, d, f) {
	return o(), n("div", i({ ref: "rootRef" }, u.forwardedAttrs, {
		class: ["win-pips-pager", [u.orientationClass, { "is-disabled": !u.isEnabled }]],
		style: u.rootStyle,
		dir: u.flowDirection,
		role: "group",
		"aria-label": u.pagerLabel,
		"aria-disabled": !u.isEnabled,
		onPointerenter: u.OnPointerEntered,
		onPointerleave: u.OnPointerExited,
		onPointercancel: u.OnPointerCanceled,
		onPointerdown: u.OnPointerPressed,
		onFocusin: u.OnGotFocus,
		onFocusout: u.OnLostFocus,
		onKeydown: u.OnKeyDown
	}), [r(u.StackPanel, {
		class: "pips-root-panel",
		Orientation: "{x:Bind orientation, Mode=OneWay}"
	}, {
		default: s(() => [
			r(u.Button, {
				class: a(["navigation-button previous-page-button", { hidden: !u.previousVisible }]),
				Visibility: "{x:Bind previousVisibility, Mode=OneWay}",
				IsEnabled: "{x:Bind previousEnabled, Mode=OneWay}",
				Width: "{x:Bind previousStyle.Width, Mode=OneWay}",
				Height: "{x:Bind previousStyle.Height, Mode=OneWay}",
				Padding: "0",
				MinWidth: "0",
				MinHeight: "0",
				HorizontalAlignment: "Center",
				VerticalAlignment: "Center",
				Background: "{x:Bind previousStyle.Background, Mode=OneWay}",
				Foreground: "{x:Bind previousStyle.Foreground, Mode=OneWay}",
				BorderBrush: "{x:Bind previousStyle.BorderBrush, Mode=OneWay}",
				BorderThickness: "{x:Bind previousStyle.BorderThickness, Mode=OneWay}",
				CornerRadius: "{x:Bind previousStyle.CornerRadius, Mode=OneWay}",
				"ToolTipService.ToolTip": "{x:Bind previousLabel, Mode=OneWay}",
				"AutomationProperties.Name": "{x:Bind previousLabel, Mode=OneWay}",
				Click: "OnPreviousButtonClicked",
				"aria-hidden": "{x:Bind previousHidden, Mode=OneWay}"
			}, {
				default: s(() => [r(u.Border, { class: "navigation-scale-host" }, {
					default: s(() => [r(u.FontIcon, {
						class: "navigation-glyph",
						Glyph: "{x:Bind previousStyle.Content, Mode=OneWay}",
						FontFamily: "{x:Bind previousStyle.FontFamily, Mode=OneWay}",
						FontSize: "{x:Bind previousStyle.FontSize, Mode=OneWay}"
					})]),
					_: 1
				})]),
				_: 1
			}, 8, ["class"]),
			r(u.ScrollViewer, {
				ref: "scrollViewerRef",
				class: "pips-viewport",
				Width: "{x:Bind viewportWidth, Mode=OneWay}",
				Height: "{x:Bind viewportHeight, Mode=OneWay}",
				VerticalScrollBarVisibility: "Hidden",
				VerticalScrollMode: "Disabled",
				HorizontalScrollBarVisibility: "Hidden",
				HorizontalScrollMode: "Disabled",
				IsHorizontalScrollChainingEnabled: "False",
				IsVerticalScrollChainingEnabled: "False",
				ZoomMode: "Disabled",
				IsTabStop: "False",
				HorizontalAlignment: "Center",
				VerticalAlignment: "Center"
			}, {
				default: s(() => [r(u.ItemsRepeater, {
					ref: "repeaterRef",
					class: "pips-repeater",
					ItemsSource: "{x:Bind pipItems, Mode=OneWay}",
					HorizontalCacheLength: "1",
					VerticalCacheLength: "1"
				}, {
					default: s(() => [r(u.ItemsRepeater.Layout, null, {
						default: s(() => [r(u.StackLayout, { Orientation: "{x:Bind orientation, Mode=OneWay}" })]),
						_: 1
					}), r(u.ItemsRepeater.ItemTemplate, null, {
						default: s(() => [r(u.DataTemplate, null, {
							default: s(() => [r(u.Button, {
								class: "pip-button",
								Width: "{x:Bind Width}",
								Height: "{x:Bind Height}",
								Padding: "0",
								MinWidth: "0",
								MinHeight: "0",
								IsEnabled: "{x:Bind IsEnabled}",
								Background: "{x:Bind Background}",
								Foreground: "{x:Bind Foreground}",
								BorderBrush: "{x:Bind BorderBrush}",
								BorderThickness: "{x:Bind BorderThickness}",
								CornerRadius: "{x:Bind CornerRadius}",
								"AutomationProperties.Name": "{x:Bind Name}",
								"data-page-index": "{x:Bind Index}",
								"aria-pressed": "{x:Bind IsSelected}",
								"aria-posinset": "{x:Bind PositionInSet}",
								"aria-setsize": "{x:Bind SizeOfSet}",
								tabindex: "{x:Bind TabIndex}",
								Click: "OnPipClicked"
							}, {
								default: s(() => [r(u.FontIcon, {
									class: "pip-glyph",
									Glyph: "{x:Bind Content}",
									FontFamily: "{x:Bind FontFamily}",
									FontSize: "{x:Bind FontSize}"
								})]),
								_: 1
							})]),
							_: 1
						})]),
						_: 1
					})]),
					_: 1
				}, 512)]),
				_: 1
			}, 512),
			r(u.Button, {
				class: a(["navigation-button next-page-button", { hidden: !u.nextVisible }]),
				Visibility: "{x:Bind nextVisibility, Mode=OneWay}",
				IsEnabled: "{x:Bind nextEnabled, Mode=OneWay}",
				Width: "{x:Bind nextStyle.Width, Mode=OneWay}",
				Height: "{x:Bind nextStyle.Height, Mode=OneWay}",
				Padding: "0",
				MinWidth: "0",
				MinHeight: "0",
				HorizontalAlignment: "Center",
				VerticalAlignment: "Center",
				Background: "{x:Bind nextStyle.Background, Mode=OneWay}",
				Foreground: "{x:Bind nextStyle.Foreground, Mode=OneWay}",
				BorderBrush: "{x:Bind nextStyle.BorderBrush, Mode=OneWay}",
				BorderThickness: "{x:Bind nextStyle.BorderThickness, Mode=OneWay}",
				CornerRadius: "{x:Bind nextStyle.CornerRadius, Mode=OneWay}",
				"ToolTipService.ToolTip": "{x:Bind nextLabel, Mode=OneWay}",
				"AutomationProperties.Name": "{x:Bind nextLabel, Mode=OneWay}",
				Click: "OnNextButtonClicked",
				"aria-hidden": "{x:Bind nextHidden, Mode=OneWay}"
			}, {
				default: s(() => [r(u.Border, { class: "navigation-scale-host" }, {
					default: s(() => [r(u.FontIcon, {
						class: "navigation-glyph",
						Glyph: "{x:Bind nextStyle.Content, Mode=OneWay}",
						FontFamily: "{x:Bind nextStyle.FontFamily, Mode=OneWay}",
						FontSize: "{x:Bind nextStyle.FontSize, Mode=OneWay}"
					})]),
					_: 1
				})]),
				_: 1
			}, 8, ["class"])
		]),
		_: 1
	})], 16, c);
}
var u = /*#__PURE__*/ e(t, [
	["render", l],
	["__scopeId", "data-v-faadf2ec"],
	["__file", "PipsPager.vue"]
]);
//#endregion
export { u as default };

//# sourceMappingURL=PipsPager.vue.js.map