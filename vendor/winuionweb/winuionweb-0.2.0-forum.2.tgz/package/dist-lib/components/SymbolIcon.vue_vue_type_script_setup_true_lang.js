import { xamlScopeKey as e } from "./xamlRuntime.js";
import { iconElementProps as t, iconFontFamily as n, useIconElement as r } from "./iconElementRuntime.js";
import i from "./Grid.vue.js";
import { resolveSymbolGlyph as a } from "./symbolGlyphs.js";
import o from "./TextBlock.vue.js";
import { computed as s, defineComponent as c, getCurrentInstance as l, provide as u, useAttrs as d } from "vue";
//#region src/components/SymbolIcon.vue?vue&type=script&setup=true&lang.ts
var f = /*@__PURE__*/ c({
	inheritAttrs: !1,
	__name: "SymbolIcon",
	props: {
		Symbol: {
			type: [String, Number],
			default: "Emoji"
		},
		...t
	},
	setup(t, { expose: c }) {
		let f = t, p = d(), m = l(), { Element: h, read: g, layoutStyle: _, rootAttrs: v, api: y } = r(f, p, m, ["Symbol"]), b = s(() => Object.fromEntries(Object.entries(v.value).filter(([e]) => e !== "FontSize"))), x = s(() => a(g("Symbol")));
		u(e, {
			SymbolIconTemplateGlyph: x,
			SymbolIconTemplateFontFamily: n("")
		}), c(y);
		let S = {
			props: f,
			attrs: p,
			instance: m,
			Element: h,
			read: g,
			layoutStyle: _,
			rootAttrs: v,
			api: y,
			symbolAttrs: b,
			glyph: x,
			Grid: i,
			TextBlock: o
		};
		return Object.defineProperty(S, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), S;
	}
});
//#endregion
export { f as default };

//# sourceMappingURL=SymbolIcon.vue_vue_type_script_setup_true_lang.js.map