import e from "./mediaDecode.worker.ts_worker_inline.js";
//#region src/components/mediaSource.ts
var t = "WinUIonWeb.media.vc1-h264-aac.v1", n = 32 * 1024 * 1024, r = /* @__PURE__ */ new Map(), i = Promise.resolve(), a = null, o, s = 0, c = async (e) => {
	let t = [e], r = e.match(/^https:\/\/raw\.githubusercontent\.com\/microsoft\/WinUI-Gallery\/(main|[a-f0-9]{40})\/(.+)$/i);
	r && t.push(`https://cdn.jsdelivr.net/gh/microsoft/WinUI-Gallery@${r[1]}/${r[2]}`);
	for (let e of t) try {
		let t = await fetch(e, { signal: AbortSignal.timeout(3e4) });
		if (!t.ok) continue;
		if (Number(t.headers.get("Content-Length")) > n) throw Error("Media source is too large for software decoding.");
		let r = await t.arrayBuffer();
		if (r.byteLength > 0 && r.byteLength <= n) return r;
	} catch {}
	throw Error("Media source download failed.");
}, l = (t) => new Promise((n, r) => {
	o && clearTimeout(o);
	let i = a ||= new e(), c = ++s, l = (e, t) => {
		clearTimeout(f), i.removeEventListener("message", u), i.removeEventListener("error", d), e ? (i.terminate(), a === i && (a = null), r(e)) : (n(t), o = setTimeout(() => {
			i.terminate(), a === i && (a = null);
		}, 15e3));
	}, u = (e) => {
		e.data.id === c && (e.data.error || !e.data.bytes ? l(/* @__PURE__ */ Error("Media conversion failed.")) : l(void 0, new Blob([e.data.bytes], { type: "video/mp4" })));
	}, d = () => l(/* @__PURE__ */ Error("Media decoder failed.")), f = setTimeout(() => l(/* @__PURE__ */ Error("Media decoder timed out.")), 9e4);
	i.addEventListener("message", u), i.addEventListener("error", d), i.postMessage({
		id: c,
		bytes: t
	}, [t]);
}), u = (e, t) => /\.wmv(?:[?#]|$)/i.test(e) && !t.canPlayType("video/x-ms-wmv"), d = (e) => {
	let n = r.get(e);
	if (n) return n;
	let a = i.then(async () => {
		let n = null;
		try {
			n = await caches.open(t);
			let r = await n.match(e);
			if (r?.ok) return await r.blob();
		} catch {}
		let r = await l(await c(e));
		if (n) try {
			await n.put(e, new Response(r, { headers: { "Content-Type": "video/mp4" } }));
		} catch {}
		return r;
	});
	return i = a.catch(() => {}), r.set(e, a), a.catch(() => {
		r.get(e) === a && r.delete(e);
	}), a;
};
//#endregion
export { d as getBrowserMediaSource, u as needsSoftwareMediaDecoder };

//# sourceMappingURL=mediaSource.js.map