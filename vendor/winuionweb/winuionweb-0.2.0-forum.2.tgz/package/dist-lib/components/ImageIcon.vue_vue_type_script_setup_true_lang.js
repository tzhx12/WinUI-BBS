import { updateXamlBinding as e } from "./xamlRuntime.js";
import { iconElementProps as t, useIconElement as n } from "./iconElementRuntime.js";
import { ImageSourceProperty as r } from "./imageSource.js";
import i from "./Image.vue.js";
import { computed as a, defineComponent as o, getCurrentInstance as s, onMounted as c, onUpdated as l, ref as u, useAttrs as d, watch as f } from "vue";
var p = /*@__PURE__*/ o({
	Source: r,
	inheritAttrs: !1,
	__name: "ImageIcon",
	props: {
		...t,
		Source: {
			type: [String, Object],
			default: ""
		}
	},
	setup(r, { expose: o }) {
		let p = r, m = d(), h = s(), g = n(p, m, h), _ = u();
		f(() => g.resolve(p.Source), () => {
			_.value = void 0;
		});
		let v = u(null), y = a(() => ({
			...g.rootAttrs.value,
			...Object.fromEntries(Object.keys(t).filter((e) => ![
				"Foreground",
				"FlowDirection",
				"RequestedTheme"
			].includes(e)).map((e) => [e, g.read(e)])),
			Source: _.value === void 0 ? p.Source : _.value
		})), b = () => {
			let e = v.value?.$el ?? h?.subTree.el;
			g.Element.value = e ?? null;
		};
		c(b), l(b), Object.defineProperty(g.api, "Source", {
			enumerable: !0,
			configurable: !0,
			get: () => v.value?.Source ?? _.value ?? g.resolve(p.Source),
			set: (t) => {
				_.value = t, v.value && (v.value.Source = t), e(p.Source, t, h);
			}
		}), o(g.api);
		let x = {
			props: p,
			attrs: m,
			instance: h,
			icon: g,
			sourceOverride: _,
			imageRef: v,
			imageProps: y,
			bindElement: b,
			Image: i
		};
		return Object.defineProperty(x, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), x;
	}
});
//#endregion
export { p as default };

//# sourceMappingURL=ImageIcon.vue_vue_type_script_setup_true_lang.js.map