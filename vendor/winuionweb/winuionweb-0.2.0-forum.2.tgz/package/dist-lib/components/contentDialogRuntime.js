//#region src/components/contentDialogRuntime.ts
var e = /* @__PURE__ */ new Map(), t = (t, n, r = null, i) => {
	let a = e.get(t);
	a || (a = /* @__PURE__ */ new Map(), e.set(t, a));
	let o = r;
	if (r === null ? a.has(null) : a.has(r) || Array.from(a).some(([e, t]) => e !== null && t.element && o?.contains?.(t.element))) throw Error("Only one ContentDialog may be open in a XamlRoot at a time.");
	return a.set(r, {
		owner: n,
		element: i
	}), () => {
		a?.get(r)?.owner === n && a.delete(r), a?.size || e.delete(t);
	};
}, n = (e) => {
	let t = 0, n = !0, r = !1, i, a = new Promise((e) => {
		i = e;
	}), o = () => {
		!n && t === 0 && i();
	};
	return {
		args: {
			Cancel: !1,
			...e === void 0 ? {} : { Result: e },
			GetDeferral() {
				if (!n || r) throw Error("GetDeferral must be called while the ContentDialog event is being raised.");
				t += 1;
				let e = !1;
				return { Complete() {
					e || r || (e = !0, --t, o());
				} };
			}
		},
		completed: a,
		finishDispatch() {
			n = !1, o();
		},
		disconnect() {
			r = !0, n = !1, t = 0, i();
		}
	};
}, r = "button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), a[href], [tabindex], [contenteditable=\"true\"]", i = (e) => e ? Array.from(e.querySelectorAll(r)).filter((e) => e.tabIndex >= 0 && !e.closest("[inert], [hidden], [aria-hidden=\"true\"]") && e.getClientRects().length > 0) : [];
//#endregion
export { t as acquireContentDialog, i as contentDialogFocusableElements, n as createContentDialogEventArgs };

//# sourceMappingURL=contentDialogRuntime.js.map