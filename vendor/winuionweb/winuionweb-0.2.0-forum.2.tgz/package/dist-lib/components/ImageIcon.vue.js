import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./ImageIcon.vue_vue_type_script_setup_true_lang.js";
import { createBlock as n, createCommentVNode as r, mergeProps as i, openBlock as a, renderSlot as o, withCtx as s } from "vue";
//#region src/components/ImageIcon.vue
function c(e, t, c, l, u, d) {
	return a(), n(l.Image, i({ ref: "imageRef" }, l.imageProps, {
		class: ["win-icon-element win-image-icon", l.attrs.class],
		style: [l.attrs.style, l.icon.layoutStyle.value]
	}), {
		default: s(() => [l.sourceOverride === void 0 ? o(e.$slots, "default", { key: 0 }) : r("", !0)]),
		_: 3
	}, 16, ["class", "style"]);
}
var l = /*#__PURE__*/ e(t, [["render", c], ["__file", "ImageIcon.vue"]]);
//#endregion
export { l as default };

//# sourceMappingURL=ImageIcon.vue.js.map