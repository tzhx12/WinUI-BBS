import { attachedValue as e, boolValue as t, cssLength as n, xamlThickness as r } from "./layout.js";
//#region src/components/relativePanelLayout.ts
var i = [{
	start: "AlignLeftWith",
	end: "AlignRightWith",
	center: "AlignHorizontalCenterWith",
	after: "RightOf",
	before: "LeftOf",
	startPanel: "AlignLeftWithPanel",
	endPanel: "AlignRightWithPanel",
	centerPanel: "AlignHorizontalCenterWithPanel"
}, {
	start: "AlignTopWith",
	end: "AlignBottomWith",
	center: "AlignVerticalCenterWith",
	after: "Below",
	before: "Above",
	startPanel: "AlignTopWithPanel",
	endPanel: "AlignBottomWithPanel",
	centerPanel: "AlignVerticalCenterWithPanel"
}], a = [
	"LeftOf",
	"Above",
	"RightOf",
	"Below",
	"AlignLeftWith",
	"AlignTopWith",
	"AlignRightWith",
	"AlignBottomWith",
	"AlignHorizontalCenterWith",
	"AlignVerticalCenterWith"
], o = [
	"AlignLeftWithPanel",
	"AlignTopWithPanel",
	"AlignRightWithPanel",
	"AlignBottomWithPanel",
	"AlignHorizontalCenterWithPanel",
	"AlignVerticalCenterWithPanel"
], s = (e, t) => {
	let n = i[t], r = e.targets, a = e.panelRelations ?? {};
	return {
		start: !!(a[n.startPanel] || r[n.start] || r[n.after] && !r[n.center]),
		end: !!(a[n.endPanel] || r[n.end] || r[n.before] && !r[n.center]),
		center: !!(a[n.centerPanel] && !a[n.startPanel] && !a[n.endPanel] && !r[n.start] && !r[n.end] && !r[n.before] && !r[n.after] || r[n.center] && !a[n.startPanel] && !a[n.endPanel] && !r[n.start] && !r[n.end])
	};
}, c = (e, t, n) => {
	if (!Number.isFinite(n)) return {
		start: 0,
		size: n
	};
	let r = i[t], a = e.targets, o = e.panelRelations ?? {}, s = 0, c = n, l = !1, u = !1;
	if (!o[r.startPanel]) {
		let e = a[r.start], n = a[r.after];
		e ? s = e.rect[t].start : a[r.center] ? l = !0 : n && (s = n.rect[t].start + n.rect[t].size);
	}
	if (!o[r.endPanel]) {
		let e = a[r.end], n = a[r.before];
		e ? c = e.rect[t].start + e.rect[t].size : a[r.center] ? u = !0 : n && (c = n.rect[t].start);
	}
	if (l && u) {
		let e = a[r.center].rect[t], i = e.start + e.size / 2, o = Math.min(i, n - i) * 2;
		return {
			start: i - o / 2,
			size: o
		};
	}
	return {
		start: s,
		size: c - s
	};
}, l = (e, t, n) => {
	let r = c(e, t, n), i = Math.min(r.size, e.desiredSize[t]), a = s(e, t), o = r.start, l = i;
	a.start && a.end ? l = r.size : !a.start && a.end ? o += r.size - i : !a.start && a.center && (o += (r.size - i) / 2), e.rect[t] = {
		start: o,
		size: l
	};
}, u = (e, t) => {
	let n = i[t], r = new Set(e);
	for (let t of e) {
		let e = t.targets, i = t.panelRelations ?? {}, a = !1, o = !1;
		i[n.startPanel] || (e[n.start] ? r.delete(e[n.start]) : e[n.center] ? a = !0 : e[n.after] && r.delete(e[n.after])), i[n.endPanel] || (e[n.end] ? r.delete(e[n.end]) : e[n.center] ? o = !0 : e[n.before] && r.delete(e[n.before])), a && o && r.delete(e[n.center]);
	}
	let a = 0;
	for (let e of r) {
		let r = 0, i = 0, o = !1, c = !1, l = (e, a, u) => {
			let d = a, f = e.desiredSize[t], p = e.targets, m = e.panelRelations ?? {}, h = !1, g = !1;
			a += u ? f : -f, u ? i = Math.max(i, a) : r = Math.min(r, a);
			let _ = u ? n.startPanel : n.endPanel, v = u ? n.start : n.end, y = u ? n.end : n.start, b = u ? n.after : n.before, x = u ? n.before : n.after;
			if (m[_] ? u && !c ? (i = a, c = !0) : !u && !o && (r = a, o = !0) : p[v] ? p[v] !== p[y] && l(p[v], a, !u) : p[n.center] ? h = !0 : p[b] && l(p[b], a, u), m[u ? n.endPanel : n.startPanel] ? u ? (r = o ? Math.min(r, d) : d, o = !0) : (i = c ? Math.max(i, d) : d, c = !0) : p[y] ? l(p[y], d, u) : p[n.center] ? g = !0 : p[x] && l(p[x], d, !u), h && g) {
				let e = p[n.center], o = a + (u ? -f : f) / 2 + (u ? -e.desiredSize[t] : e.desiredSize[t]) / 2;
				u ? r = Math.min(r, o) : i = Math.max(i, o), l(e, o, u);
			} else if (s(e, t).center) {
				let e = a + (u ? -f : f) / 2;
				i = Math.max(i - e, e - r) * 2, r = 0;
			}
		};
		l(e, 0, !0), a = Math.max(a, i - r);
	}
	return a;
}, d = (e, t, n, r) => {
	let i = e.map((e) => ({
		...e,
		desiredSize: [...e.desiredSize],
		targets: {},
		rect: [{
			start: 0,
			size: 0
		}, {
			start: 0,
			size: 0
		}],
		state: "unresolved"
	})), o = new Map(i.filter((e) => e.name).map((e) => [e.name, e]));
	for (let e of i) for (let t of a) {
		let n = e.relations?.[t];
		if (!n) continue;
		let r = o.get(n);
		if (!r) throw Error(`RelativePanel: no child named '${n}' was found.`);
		e.targets[t] = r;
	}
	let s = (e) => {
		if (e.state === "pending") throw Error("RelativePanel: circular dependency detected.");
		if (e.state === "measured") return;
		e.state = "pending";
		for (let t of a) e.targets[t] && s(e.targets[t]);
		let n = [Math.max(0, c(e, 0, t[0]).size), Math.max(0, c(e, 1, t[1]).size)];
		r && (e.desiredSize = r(i.indexOf(e), n)), e.desiredSize = e.desiredSize.map((e, t) => Math.max(0, Math.min(e, n[t]))), e.state = "measured";
		for (let n of [0, 1]) Number.isFinite(t[n]) && l(e, n, t[n]);
	};
	i.forEach(s);
	let d = [u(i, 0), u(i, 1)], f = n ?? t.map((e, t) => Number.isFinite(e) ? e : d[t]);
	for (let e of [0, 1]) {
		let t = /* @__PURE__ */ new Set(), n = (r) => {
			if (!t.has(r)) {
				for (let e of a) r.targets[e] && n(r.targets[e]);
				l(r, e, f[e]), t.add(r);
			}
		};
		i.forEach(n);
	}
	return {
		desiredSize: d,
		measuredSizes: i.map((e) => e.desiredSize),
		rectangles: i.map((e) => ({
			x: Math.max(0, e.rect[0].start),
			y: Math.max(0, e.rect[1].start),
			width: Math.max(0, e.rect[0].size),
			height: Math.max(0, e.rect[1].size)
		}))
	};
}, f = [
	"position",
	"left",
	"top",
	"right",
	"bottom",
	"width",
	"height",
	"margin",
	"maxWidth",
	"maxHeight",
	"boxSizing",
	"display"
], p = /* @__PURE__ */ new WeakMap(), m = (e) => Number.parseFloat(e) || 0, h = (e) => Object.fromEntries(f.map((t) => [t, e.style[t]])), g = (e) => {
	let t = p.get(e);
	return !t || e.style.cssText !== t.outputCssText;
}, _ = (e) => {
	let t = p.get(e), n = h(e), r = { ...n };
	if (t) for (let e of f) n[e] === t.output[e] && (r[e] = t.input[e]);
	for (let t of f) e.style[t] = r[t];
	return r;
}, v = (t, n, r) => {
	let i = e(t, n);
	return i !== void 0 && Number.isFinite(Number(i)) ? Math.max(0, Number(i)) : r;
}, y = (e, t, n) => Math.max(m(t), n === "none" ? e : Math.min(e, m(n))), b = (i, s) => {
	let c = getComputedStyle(i), l = [
		m(c.paddingLeft),
		m(c.paddingTop),
		m(c.paddingRight),
		m(c.paddingBottom)
	], u = [l[0] + l[2] + m(c.borderLeftWidth) + m(c.borderRightWidth), l[1] + l[3] + m(c.borderTopWidth) + m(c.borderBottomWidth)], f = Array.from(i.children).filter((e) => e instanceof HTMLElement && !e.classList.contains("win-acrylic-visual")), g = f.map((t) => {
		_(t);
		for (let r of [
			"Width",
			"Height",
			"MinWidth",
			"MinHeight",
			"MaxWidth",
			"MaxHeight"
		]) {
			let i = e(t, r), a = {
				Width: "width",
				Height: "height",
				MinWidth: "minWidth",
				MinHeight: "minHeight",
				MaxWidth: "maxWidth",
				MaxHeight: "maxHeight"
			}[r];
			i !== void 0 && (t.style[a] = n(i));
		}
		let i = e(t, "Margin"), a = e(t, "Padding"), o = e(t, "Visibility");
		return i !== void 0 && (t.style.margin = r(i)), a !== void 0 && (t.style.padding = r(a)), o === "Collapsed" ? t.style.display = "none" : o === "Visible" && (t.style.display = ""), h(t);
	}), b = f.map((e) => {
		let t = getComputedStyle(e);
		return [t.maxWidth === "none" ? Infinity : m(t.maxWidth), t.maxHeight === "none" ? Infinity : m(t.maxHeight)];
	}), x = f.map((e) => {
		let t = getComputedStyle(e);
		return [
			m(t.marginLeft),
			m(t.marginTop),
			m(t.marginRight),
			m(t.marginBottom)
		];
	}), S = f.map((t) => (t.style.position = "absolute", t.style.left = "0px", t.style.top = "0px", t.style.right = "auto", t.style.bottom = "auto", getComputedStyle(t).display === "none" || e(t, "Visibility") === "Collapsed" ? [0, 0] : [t.offsetWidth, t.offsetHeight])), C = f.map((n, r) => ({
		name: e(n, "data-xaml-ref") ?? e(n, "x:Name") ?? e(n, "Name"),
		desiredSize: [S[r][0], S[r][1]],
		relations: Object.fromEntries(a.map((t) => [t, e(n, `RelativePanel.${t}`)])),
		panelRelations: Object.fromEntries(o.map((r) => [r, t(e(n, `RelativePanel.${r}`))]))
	})), w = [s.autoWidth ? Infinity : Math.max(0, i.clientWidth - l[0] - l[2]), s.autoHeight ? Infinity : Math.max(0, i.clientHeight - l[1] - l[3])], T = d(C, w, void 0, (t, n) => {
		let r = f[t], i = x[t];
		return S[t][0] === 0 && S[t][1] === 0 && (getComputedStyle(r).display === "none" || e(r, "Visibility") === "Collapsed") ? [0, 0] : (Number.isFinite(n[0]) && (r.style.maxWidth = `${Math.max(0, Math.min(b[t][0], n[0] - i[0] - i[2]))}px`), Number.isFinite(n[1]) && (r.style.maxHeight = `${Math.max(0, Math.min(b[t][1], n[1] - i[1] - i[3]))}px`), [Math.max(0, r.offsetWidth + i[0] + i[2]), Math.max(0, r.offsetHeight + i[1] + i[3])]);
	}), E = s.autoWidth ? y(T.desiredSize[0] + u[0], c.minWidth, c.maxWidth) : i.offsetWidth, D = y(T.desiredSize[1] + u[1], `${s.minimumHeight ?? 0}px`, c.maxHeight), O = s.autoHeight ? Math.max(D, i.offsetHeight) : i.offsetHeight, k = [Math.max(0, E - u[0]), Math.max(0, O - u[1])], A = d(C.map((e, t) => ({
		...e,
		desiredSize: T.measuredSizes[t]
	})), w, k);
	return f.forEach((t, n) => {
		let r = A.rectangles[n], i = x[n], a = g[n], o = e(t, "HorizontalAlignment") ?? "Stretch", s = e(t, "VerticalAlignment") ?? "Stretch", c = Math.max(0, r.width - i[0] - i[2]), u = Math.max(0, r.height - i[1] - i[3]), d = a.width !== "" && a.width !== "auto", f = a.height !== "" && a.height !== "auto", m = o === "Stretch" && !d ? c : Math.min(c, v(t, "Width", S[n][0])), _ = s === "Stretch" && !f ? u : Math.min(u, v(t, "Height", S[n][1])), y = o === "Right" ? c - m : o === "Center" || o === "Stretch" && d ? (c - m) / 2 : 0, b = s === "Bottom" ? u - _ : s === "Center" || s === "Stretch" && f ? (u - _) / 2 : 0;
		t.style.margin = "0px", t.style.boxSizing = "border-box", t.style.left = `${l[0] + r.x + i[0] + y}px`, t.style.top = `${l[1] + r.y + i[1] + b}px`, t.style.width = `${m}px`, t.style.height = `${_}px`, t.style.maxWidth = a.maxWidth, t.style.maxHeight = a.maxHeight, p.set(t, {
			input: a,
			output: h(t),
			outputCssText: t.style.cssText
		});
	}), {
		width: E,
		height: s.autoHeight ? D : O
	};
};
//#endregion
export { b as arrangeRelativePanel, g as relativePanelStyleChanged };

//# sourceMappingURL=relativePanelLayout.js.map