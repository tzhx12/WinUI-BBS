import { alignment as e, cssLength as t, xamlThickness as n } from "./layout.js";
import { normalizeXamlNodes as r, resolveXamlHandler as i, resolveXamlResourceObject as a, resolveXamlValue as o } from "./xamlRuntime.js";
import { ImageSourceProperty as s, createImageSourceModel as c, imageBoolean as l, imageDecodeSize as u, imageNumber as d, imageSourceContextKey as f, imageStretchSize as ee, imageUri as p } from "./imageSource.js";
import { xamlResourceDictionaryKey as m } from "./Page.vue_vue_type_script_lang.js";
import { decodeGif as h } from "./gifDecoder.js";
import { parallaxChildLayoutKey as g } from "./parallaxRuntime.js";
import { Fragment as _, cloneVNode as te, computed as v, defineComponent as ne, getCurrentInstance as re, h as ie, inject as ae, isVNode as oe, nextTick as se, onBeforeUnmount as ce, onMounted as le, provide as ue, reactive as de, ref as y, shallowRef as fe, useAttrs as pe, useSlots as me, watch as b } from "vue";
var he = /*@__PURE__*/ ne({
	Source: s,
	inheritAttrs: !1,
	__name: "Image",
	props: {
		Source: {
			type: [String, Object],
			default: ""
		},
		Stretch: {
			type: String,
			default: "Uniform"
		},
		NineGrid: {
			type: [
				String,
				Number,
				Object
			],
			default: "0"
		},
		Width: {
			type: [String, Number],
			default: ""
		},
		Height: {
			type: [String, Number],
			default: ""
		},
		MinWidth: {
			type: [String, Number],
			default: 0
		},
		MinHeight: {
			type: [String, Number],
			default: 0
		},
		MaxWidth: {
			type: [String, Number],
			default: ""
		},
		MaxHeight: {
			type: [String, Number],
			default: ""
		},
		HorizontalAlignment: {
			type: String,
			default: "Stretch"
		},
		VerticalAlignment: {
			type: String,
			default: "Stretch"
		},
		Margin: {
			type: [String, Number],
			default: 0
		},
		Opacity: {
			type: [String, Number],
			default: 1
		},
		Visibility: {
			type: String,
			default: "Visible"
		},
		IsHitTestVisible: {
			type: [Boolean, String],
			default: !0
		}
	},
	emits: ["ImageOpened", "ImageFailed"],
	setup(s, { expose: he, emit: ge }) {
		let x = s, _e = ge, S = re(), ve = ae(g, null), C = ve?.isDirectChild(S) ? ve : null, w = pe(), ye = me(), T = (e) => o(e, S), E = y(null), be = y(null), D = c(), O = fe(null);
		ue(f, (e) => {
			O.value = e;
		});
		let k = y(), xe = ae(m, null), A = v(() => {
			let e = k.value === void 0 ? x.Source : k.value;
			if (typeof e != "string") return;
			let t = e.match(/^\{(?:StaticResource|ThemeResource)\s+([^\s}]+)\}$/)?.[1];
			return t ? a(t, S) ?? xe?.[t] : void 0;
		}), Se = ne({ setup: () => () => oe(A.value) ? ie(_, r([te(A.value)], S)) : k.value === void 0 ? ie(_, ye.default?.()) : null }), j = v(() => {
			if (A.value !== void 0) {
				if (oe(A.value)) {
					let e = A.value;
					return typeof e.children == "string" ? e.children : "";
				}
				return A.value;
			}
			let e = k.value === void 0 ? x.Source : k.value;
			return typeof e == "string" && /^\{(?:StaticResource|ThemeResource)\s/.test(e) ? "" : T(e);
		});
		b(j, (e) => {
			if (e && typeof e == "object" && "__kind" in e) return;
			let t = e && typeof e == "object" ? e : {};
			D.UriSource = typeof e == "string" ? e : p(t.UriSource, S, xe), D.AutoPlay = t.AutoPlay === void 0 ? !0 : l(T(t.AutoPlay)), D.DecodePixelWidth = Math.floor(d(T(t.DecodePixelWidth))), D.DecodePixelHeight = Math.floor(d(T(t.DecodePixelHeight))), D.DecodePixelType = t.DecodePixelType === "Logical" ? "Logical" : "Physical", D.RasterizePixelWidth = d(T(t.RasterizePixelWidth)), D.RasterizePixelHeight = d(T(t.RasterizePixelHeight));
		}, {
			immediate: !0,
			deep: !0
		});
		let M = v(() => O.value?.model ?? (j.value && typeof j.value == "object" && "__kind" in j.value ? j.value : D)), Ce = v(() => M.value.UriSource), we = y(), N = v(() => {
			let e = we.value ?? T(x.Stretch);
			return [
				"None",
				"Fill",
				"Uniform",
				"UniformToFill"
			].includes(String(e)) ? String(e) : "Uniform";
		});
		b(() => x.Stretch, () => {
			we.value = void 0;
		}), b(() => x.Source, () => {
			k.value = void 0;
		});
		let Te = v(() => String(T(w["AutomationProperties.Name"]) ?? "")), Ee = v(() => ({
			...Object.fromEntries(Object.entries(w).filter(([e]) => ![
				"class",
				"style",
				"ImageOpened",
				"ImageFailed",
				"AutomationProperties.Name"
			].includes(e))),
			HorizontalAlignment: T(x.HorizontalAlignment),
			VerticalAlignment: T(x.VerticalAlignment)
		})), P = y({
			width: 0,
			height: 0
		}), F = y({
			width: 0,
			height: 0
		}), I = y({
			width: Infinity,
			height: Infinity
		}), De = y(!1), L = fe(null), R = fe(null), z = 0, B = null, V = null, H = null, U = null, W = 0, G = 0, K = 0, q = 0, J = !1, Y = null, X = (e) => {
			let t = T(e);
			if (t === "" || t == null || t === "Auto") return Infinity;
			let n = Number(t);
			return Number.isFinite(n) && n >= 0 ? n : Infinity;
		}, Oe = v(() => {
			let e = T(x.NineGrid);
			if (e && typeof e == "object") {
				let t = e;
				return [
					"Left",
					"Top",
					"Right",
					"Bottom"
				].map((e) => Math.max(0, Number(t[e]) || 0));
			}
			let t = String(e ?? "0").split(",").map((e) => Math.max(0, Number(e.trim()) || 0));
			return t.length === 1 ? [
				t[0],
				t[0],
				t[0],
				t[0]
			] : t.length === 2 ? [
				t[0],
				t[1],
				t[0],
				t[1]
			] : t.length === 4 ? t : [
				0,
				0,
				0,
				0
			];
		}), ke = v(() => Oe.value.some((e) => e > 0)), Ae = v(() => !!(L.value || ke.value || M.value.DecodePixelWidth || M.value.DecodePixelHeight || M.value.RasterizePixelWidth || M.value.RasterizePixelHeight)), Z = v(() => {
			let e = X(x.Width), t = X(x.Height), n = Number.isFinite(I.value.width) ? I.value.width : Infinity, r = Number.isFinite(I.value.height) ? I.value.height : Infinity, i = C?.availableSize.value, a = ee(P.value.width, P.value.height, Math.min(e, X(x.MaxWidth), i?.width ?? n), Math.min(t, X(x.MaxHeight), i?.height ?? r), N.value);
			return {
				width: Number.isFinite(e) ? e : Math.min(X(x.MaxWidth), Math.max(d(T(x.MinWidth)), a.width)),
				height: Number.isFinite(t) ? t : Math.min(X(x.MaxHeight), Math.max(d(T(x.MinHeight)), a.height))
			};
		}), je = v(() => [w.style, {
			flex: "0 0 auto",
			width: `${C?.arrangedSize.value?.width ?? Z.value.width}px`,
			height: `${C?.arrangedSize.value?.height ?? Z.value.height}px`,
			minWidth: t(T(x.MinWidth)),
			minHeight: t(T(x.MinHeight)),
			maxWidth: t(T(x.MaxWidth)) || void 0,
			maxHeight: t(T(x.MaxHeight)) || void 0,
			margin: n(T(x.Margin)),
			opacity: Number(T(x.Opacity)),
			justifySelf: T(x.HorizontalAlignment) === "Stretch" && !Number.isFinite(X(x.Width)) ? "center" : e(T(x.HorizontalAlignment), "horizontal"),
			alignSelf: T(x.VerticalAlignment) === "Stretch" && !Number.isFinite(X(x.Height)) ? "center" : e(T(x.VerticalAlignment), "vertical"),
			display: T(x.Visibility) === "Collapsed" ? "none" : void 0,
			pointerEvents: l(T(x.IsHitTestVisible)) ? void 0 : "none"
		}]);
		C && b(Z, (e) => C.reportDesiredSize(e), { immediate: !0 });
		let Me = v(() => ({ objectFit: {
			None: "none",
			Fill: "fill",
			Uniform: "contain",
			UniformToFill: "cover"
		}[N.value] }));
		function Ne() {
			U !== null && cancelAnimationFrame(U), U = null, q = 0;
		}
		function Pe() {
			let e = be.value, t = L.value?.frames[W]?.image ?? R.value;
			if (!e || !t || !De.value) return;
			let n = F.value.width || Z.value.width, r = F.value.height || Z.value.height, i = window.devicePixelRatio || 1;
			e.width = Math.max(1, Math.round(n * i)), e.height = Math.max(1, Math.round(r * i));
			let a = e.getContext("2d");
			if (!a) return;
			a.scale(i, i), a.clearRect(0, 0, n, r);
			let o = M.value.PixelWidth, s = M.value.PixelHeight, c = ee(P.value.width, P.value.height, n, r, N.value), l = (n - c.width) / 2, u = (r - c.height) / 2;
			if (!ke.value) {
				a.drawImage(t, l, u, c.width, c.height);
				return;
			}
			let [d, f, p, m] = Oe.value, h = Math.min(1, o / Math.max(1, d + p), s / Math.max(1, f + m)), g = Math.min(1, c.width / Math.max(1, d + p), c.height / Math.max(1, f + m)), _ = [
				0,
				d * h,
				o - p * h,
				o
			], te = [
				0,
				f * h,
				s - m * h,
				s
			], v = [
				l,
				l + d * g,
				l + c.width - p * g,
				l + c.width
			], ne = [
				u,
				u + f * g,
				u + c.height - m * g,
				u + c.height
			];
			for (let e = 0; e < 3; e += 1) for (let n = 0; n < 3; n += 1) {
				let r = _[n + 1] - _[n], i = te[e + 1] - te[e], o = v[n + 1] - v[n], s = ne[e + 1] - ne[e];
				r > 0 && i > 0 && o > 0 && s > 0 && a.drawImage(t, _[n], te[e], r, i, v[n], ne[e], o, s);
			}
		}
		function Fe() {
			if (!L.value || L.value.frames.length < 2 || M.value.IsPlaying) return;
			M.value.__state.playing = !0, G >= L.value.repetitions && (G = 0, W = 0, K = 0);
			let e = (t) => {
				if (!L.value || !M.value.IsPlaying || J) return;
				q && (K += Math.max(0, t - q)), q = t;
				let n = !1;
				for (; K >= (L.value.frames[W]?.duration ?? 100);) {
					if (K -= L.value.frames[W]?.duration ?? 100, W + 1 === L.value.frames.length && (G += 1, G >= L.value.repetitions)) {
						Q();
						break;
					}
					W = (W + 1) % L.value.frames.length, n = !0;
				}
				n && Pe(), M.value.IsPlaying && (U = requestAnimationFrame(e));
			};
			U = requestAnimationFrame(e);
		}
		function Q() {
			Ne(), M.value.__state.playing = !1;
		}
		let $ = de({
			Element: v(() => E.value),
			Source: v({
				get: () => M.value,
				set: (e) => {
					k.value = e;
				}
			}),
			Stretch: v({
				get: () => N.value,
				set: (e) => {
					we.value = e;
				}
			}),
			NineGrid: v(() => T(x.NineGrid)),
			ActualWidth: v(() => F.value.width),
			ActualHeight: v(() => F.value.height)
		});
		he($);
		let Ie = (e) => {
			let t = {
				OriginalSource: $,
				PixelWidth: e.PixelWidth,
				PixelHeight: e.PixelHeight
			};
			O.value?.model === e && O.value.opened({
				...t,
				OriginalSource: e
			}), _e("ImageOpened", $, t), i(w.ImageOpened, S)?.($, t);
		}, Le = (e, t) => {
			let n = {
				OriginalSource: $,
				ErrorMessage: t instanceof Error ? t.message : t instanceof Event ? "ImageFailed" : String(t ?? ""),
				BrowserEvent: t instanceof Event ? t : void 0
			};
			O.value?.model === e && O.value.failed({
				...n,
				OriginalSource: e
			}), _e("ImageFailed", $, n), i(w.ImageFailed, S)?.($, n);
		};
		async function Re() {
			let e = ++z;
			Q(), Y && Y !== M.value && (Y.__state.playing = !1, Y.__play = void 0, Y.__stop = void 0), B?.abort(), B = new AbortController(), V && (V.onload = null, V.onerror = null, V.src = ""), L.value?.dispose(), L.value = null, R.value = null, De.value = !1, W = 0, K = 0, G = 0;
			let t = M.value;
			if (Y = t, t.__state.pixelWidth = t.__state.pixelHeight = 0, t.__state.animated = !1, t.__play = Fe, t.__stop = Q, !t.UriSource) {
				P.value = {
					width: 0,
					height: 0
				};
				return;
			}
			try {
				let n = new window.Image();
				V = n, (Ae.value || /\.gif(?:$|[?#])/i.test(t.UriSource)) && (n.crossOrigin = "anonymous");
				let r = await new Promise((e, r) => {
					n.onload = () => e(n), n.onerror = r, n.src = t.UriSource;
				});
				if (e !== z || J) return;
				let i = {
					width: r.naturalWidth,
					height: r.naturalHeight
				}, a = t.__kind === "SvgImageSource" ? t.RasterizePixelWidth : t.DecodePixelWidth, o = t.__kind === "SvgImageSource" ? t.RasterizePixelHeight : t.DecodePixelHeight, s = t.DecodePixelType === "Logical" && window.devicePixelRatio || 1, c = u(i.width, i.height, a * s, o * s);
				if (t.__state.pixelWidth = c.width, t.__state.pixelHeight = c.height, P.value = i, /\.gif(?:$|[?#])/i.test(t.UriSource)) {
					let n = await fetch(t.UriSource, {
						signal: B.signal,
						mode: "cors"
					});
					if (!n.ok) throw Error(String(n.status));
					let r = await h(await n.arrayBuffer());
					if (e !== z || J) {
						r.dispose();
						return;
					}
					if (a || o) {
						for (let e of r.frames) {
							let t = document.createElement("canvas");
							t.width = c.width, t.height = c.height, t.getContext("2d")?.drawImage(e.image, 0, 0, c.width, c.height), e.image = t;
						}
						r.width = c.width, r.height = c.height;
					}
					L.value = r, t.__state.animated = r.frames.length > 1, t.__state.pixelWidth = r.width, t.__state.pixelHeight = r.height;
				} else if (a || o) {
					let e = document.createElement("canvas");
					e.width = c.width, e.height = c.height, e.getContext("2d")?.drawImage(r, 0, 0, c.width, c.height), R.value = e;
				} else R.value = r;
				De.value = !0, await se(), Pe(), t.AutoPlay && Fe(), Ie(t);
			} catch (n) {
				if (e !== z || J) return;
				Le(t, n);
			}
		}
		b(() => [
			M.value,
			M.value.UriSource,
			M.value.DecodePixelWidth,
			M.value.DecodePixelHeight,
			M.value.DecodePixelType,
			M.value.RasterizePixelWidth,
			M.value.RasterizePixelHeight
		], () => {
			Re();
		}, { immediate: !0 }), b(() => M.value.AutoPlay, (e) => {
			e ? Fe() : Q();
		}), b([
			N,
			Oe,
			Z,
			Ae
		], () => {
			se(Pe);
		}, { deep: !0 }), le(() => {
			let e = E.value?.parentElement, t = (t) => {
				let n = 0;
				for (let r = e; r; r = r.parentElement) {
					if (r.classList.contains("win-viewbox-container")) return Infinity;
					let e = r.style[t], i = getComputedStyle(r);
					n += t === "width" ? (parseFloat(i.paddingLeft) || 0) + (parseFloat(i.paddingRight) || 0) + (parseFloat(i.borderLeftWidth) || 0) + (parseFloat(i.borderRightWidth) || 0) : (parseFloat(i.paddingTop) || 0) + (parseFloat(i.paddingBottom) || 0) + (parseFloat(i.borderTopWidth) || 0) + (parseFloat(i.borderBottomWidth) || 0);
					let a = i[t === "width" ? "maxWidth" : "maxHeight"], o = Math.min(e.endsWith("px") ? r.getBoundingClientRect()[t] : Infinity, a.endsWith("px") ? parseFloat(a) : Infinity);
					if (Number.isFinite(o)) return Math.max(0, o - n);
					if (i.display === "flex" && (t === "height" ? i.flexDirection.startsWith("column") : i.flexDirection.startsWith("row"))) return Infinity;
				}
				return Infinity;
			}, n = () => {
				e && (I.value = {
					width: t("width"),
					height: t("height")
				});
			}, r = () => {
				if (!E.value) return;
				n();
				let e = E.value.getBoundingClientRect();
				F.value = {
					width: e.width,
					height: e.height
				}, Pe();
			};
			r(), typeof ResizeObserver < "u" && E.value && (H = new ResizeObserver(r), H.observe(E.value), e && H.observe(e)), n();
		}), ce(() => {
			J = !0, z += 1, Q(), B?.abort(), H?.disconnect(), L.value?.dispose(), V && (V.onload = null, V.onerror = null, V.src = ""), M.value.__play = void 0, M.value.__stop = void 0;
		});
		let ze = {
			props: x,
			emit: _e,
			instance: S,
			inheritedParallaxLayout: ve,
			parallaxLayout: C,
			attrs: w,
			slots: ye,
			value: T,
			rootRef: E,
			canvasRef: be,
			directSource: D,
			registeredSource: O,
			sourceOverride: k,
			resources: xe,
			sourceResource: A,
			SourceOutlet: Se,
			sourceInput: j,
			source: M,
			uri: Ce,
			stretchOverride: we,
			stretch: N,
			automationName: Te,
			rootAttrs: Ee,
			naturalSize: P,
			actualSize: F,
			parentAvailableSize: I,
			loaded: De,
			gif: L,
			rasterSource: R,
			get loadGeneration() {
				return z;
			},
			set loadGeneration(e) {
				z = e;
			},
			get request() {
				return B;
			},
			set request(e) {
				B = e;
			},
			get imageLoader() {
				return V;
			},
			set imageLoader(e) {
				V = e;
			},
			get observer() {
				return H;
			},
			set observer(e) {
				H = e;
			},
			get animationFrame() {
				return U;
			},
			set animationFrame(e) {
				U = e;
			},
			get frameIndex() {
				return W;
			},
			set frameIndex(e) {
				W = e;
			},
			get completedLoops() {
				return G;
			},
			set completedLoops(e) {
				G = e;
			},
			get frameElapsed() {
				return K;
			},
			set frameElapsed(e) {
				K = e;
			},
			get lastFrameTime() {
				return q;
			},
			set lastFrameTime(e) {
				q = e;
			},
			get disposed() {
				return J;
			},
			set disposed(e) {
				J = e;
			},
			get attachedModel() {
				return Y;
			},
			set attachedModel(e) {
				Y = e;
			},
			finiteSize: X,
			nineGrid: Oe,
			hasNineGrid: ke,
			usesCanvas: Ae,
			desiredSize: Z,
			hostStyle: je,
			surfaceStyle: Me,
			cancelPlayback: Ne,
			draw: Pe,
			play: Fe,
			stop: Q,
			publicApi: $,
			raiseOpened: Ie,
			raiseFailed: Le,
			load: Re
		};
		return Object.defineProperty(ze, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), ze;
	}
});
//#endregion
export { he as default };

//# sourceMappingURL=Image.vue_vue_type_script_setup_true_lang.js.map