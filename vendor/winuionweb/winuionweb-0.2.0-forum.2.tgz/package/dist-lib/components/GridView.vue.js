import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./GridView.vue_vue_type_script_setup_true_lang.js";
/* empty css                                             */
import { Fragment as n, createBlock as r, createCommentVNode as i, createElementBlock as a, createElementVNode as o, createVNode as s, normalizeClass as c, normalizeStyle as l, openBlock as u, renderList as d, resolveDynamicComponent as f, toDisplayString as p, withCtx as m, withDirectives as h, withKeys as g, withModifiers as _ } from "vue";
//#region src/components/GridView.vue
var v = ["aria-disabled", "aria-multiselectable"], y = { class: "win-grid-border" }, b = {
	key: 0,
	class: "win-grid-groups"
}, x = [
	"role",
	"tabindex",
	"onKeydown",
	"onClick"
], S = { class: "win-grid-group-header-content" }, C = [
	"aria-selected",
	"aria-disabled",
	"tabindex",
	"onClick",
	"onKeydown",
	"onFocus"
], w = { class: "grid-item-presenter" }, T = { class: "grid-item-inner" }, E = [
	"role",
	"aria-selected",
	"aria-disabled",
	"tabindex",
	"onClick",
	"onKeydown",
	"onFocus",
	"onDragstart",
	"onDragenter",
	"onDragover",
	"onPointerdown",
	"onPointermove",
	"onPointerup",
	"onPointercancel",
	"onLostpointercapture",
	"onDragend"
], D = {
	key: 0,
	class: "grid-item-presenter"
}, O = { class: "grid-item-inner" }, k = {
	key: 1,
	class: "drag-count-badge"
};
function A(e, t, A, j, M, N) {
	return h((u(), a("div", {
		ref: "containerRef",
		class: c(["win-grid-view", {
			disabled: !j.isEnabled,
			"drag-over": j.isExternalDragOver
		}]),
		style: l(j.rootStyle),
		role: "grid",
		"aria-disabled": !j.isEnabled,
		"aria-multiselectable": j.selectionMode === "Multiple" || j.selectionMode === "Extended",
		onDragover: j.onContainerDragOver,
		onDragenter: j.onContainerDragEnter,
		onDrop: j.onContainerDrop,
		onDragleave: j.onContainerDragLeave
	}, [o("div", y, [s(j.ScrollViewer, {
		class: "win-grid-scroll-viewer",
		VerticalScrollMode: "{x:Bind ScrollSettings.VerticalScrollMode, Mode=OneWay}",
		VerticalScrollBarVisibility: "{x:Bind ScrollSettings.VerticalScrollBarVisibility, Mode=OneWay}",
		HorizontalScrollMode: "{x:Bind ScrollSettings.HorizontalScrollMode, Mode=OneWay}",
		HorizontalScrollBarVisibility: "{x:Bind ScrollSettings.HorizontalScrollBarVisibility, Mode=OneWay}",
		IsHorizontalScrollChainingEnabled: "{x:Bind ScrollSettings.IsHorizontalScrollChainingEnabled, Mode=OneWay}",
		BringIntoViewOnFocusChange: "True",
		IsTabStop: "False",
		IsHorizontalRailEnabled: "{x:Bind ScrollSettings.IsHorizontalRailEnabled, Mode=OneWay}",
		IsVerticalRailEnabled: "{x:Bind ScrollSettings.IsVerticalRailEnabled, Mode=OneWay}",
		IsVerticalScrollChainingEnabled: "{x:Bind ScrollSettings.IsVerticalScrollChainingEnabled, Mode=OneWay}",
		IsEnabled: "{x:Bind ScrollTemplateIsEnabled, Mode=OneWay}",
		ZoomMode: "{x:Bind ScrollSettings.ZoomMode, Mode=OneWay}"
	}, {
		default: m(() => [o("div", {
			ref: "innerRef",
			class: "win-grid-view-content",
			style: l(j.contentPaddingStyle)
		}, [j.isGrouped ? (u(), a("div", b, [(u(!0), a(n, null, d(j.items, (e, s) => (u(), a("section", {
			key: j.getGroupKey(e, s),
			ref_for: !0,
			ref: (t) => j.setGroupElement(e, t),
			class: "win-grid-group"
		}, [o("div", {
			class: "win-grid-group-header",
			role: j.semanticView.SemanticZoomOwner.value ? "button" : void 0,
			tabindex: j.semanticView.SemanticZoomOwner.value && j.isEnabled ? 0 : void 0,
			onKeydown: [g(_((t) => j.onGroupHeaderClick(t, e), ["prevent"]), ["enter"]), g(_((t) => j.onGroupHeaderClick(t, e), ["prevent"]), ["space"])],
			onClick: (t) => j.onGroupHeaderClick(t, e)
		}, [o("div", S, [(u(), r(f(j.groupHeaderComponent(e))))]), t[0] ||= o("span", {
			class: "win-grid-group-divider",
			"aria-hidden": "true"
		}, null, -1)], 40, x), o("div", {
			class: "win-grid-view-inner win-grid-group-items",
			style: l(j.itemsPanelStyle)
		}, [(u(!0), a(n, null, d(j.getGroupItems(e), (t, n) => (u(), a("div", {
			key: "group-" + s + "-" + j.getItemKey(t, n),
			class: c(["win-grid-item", {
				selected: j.isSelected(t),
				clickEnabled: j.isItemClickEnabled
			}]),
			style: l(j.itemStyle),
			role: "gridcell",
			"aria-selected": j.selectionMode === "None" ? void 0 : j.isSelected(t),
			"aria-disabled": !j.isEnabled,
			tabindex: j.itemTabIndex(j.getFlatIndex(t, e, n)),
			onClick: (r) => j.onItemClick(r, t, j.getFlatIndex(t, e, n)),
			onKeydown: (r) => j.onItemKeyDown(r, t, j.getFlatIndex(t, e, n)),
			onFocus: (r) => j.onItemFocus(j.getFlatIndex(t, e, n))
		}, [o("div", w, [j.selectionMode === "Multiple" || j.selectionMode === "Extended" ? (u(), r(j.SelectionCheck, {
			key: 0,
			class: "grid-checkbox",
			Item: t
		}, null, 8, ["Item"])) : i("", !0), o("div", T, [(u(), r(f(j.itemComponent(t, n, e))))])])], 46, C))), 128))], 4)]))), 128))])) : (u(), a("div", {
			key: 1,
			class: "win-grid-view-inner",
			style: l(j.itemsPanelStyle)
		}, [(u(!0), a(n, null, d(j.flatList, (e) => (u(), a("div", {
			key: e.key,
			class: c(e.type === "placeholder" ? "win-grid-drop-placeholder" : {
				"win-grid-item": !0,
				selected: j.isSelected(e.item),
				clickEnabled: j.isItemClickEnabled && !j.dragVisualActive,
				"can-drag": j.canStartPointerDrag && !j.dragVisualActive,
				"drag-shrink": j.dragVisualActive && !j.dragIndices.includes(e.index) && !j.isReorderTarget(e.index),
				"dragging-source": j.isDragging && j.dragIndices.includes(e.index),
				"reorder-target": j.isReorderTarget(e.index)
			}),
			style: l(e.type === "placeholder" ? {
				...j.itemStyle,
				width: j.dragItemWidth + "px",
				height: j.dragItemHeight + "px"
			} : {
				...j.itemStyle,
				transform: j.reorderTransform(e.index),
				zIndex: j.isReorderTarget(e.index) ? 2 : void 0,
				...j.reorderHintStyle(e.index)
			}),
			draggable: !1,
			role: e.type === "item" ? "gridcell" : void 0,
			"aria-selected": e.type === "item" && j.selectionMode !== "None" ? j.isSelected(e.item) : void 0,
			"aria-disabled": e.type === "item" ? !j.isEnabled : void 0,
			tabindex: e.type === "item" ? j.itemTabIndex(e.index) : -1,
			onClick: (t) => e.type === "item" ? j.onItemClick(t, e.item, e.index) : null,
			onKeydown: (t) => e.type === "item" ? j.onItemKeyDown(t, e.item, e.index) : null,
			onFocus: (t) => e.type === "item" ? j.onItemFocus(e.index) : null,
			onDragstart: (t) => e.type === "item" ? j.onDragStart(t, e.index) : null,
			onDragenter: (t) => e.type === "item" ? j.onItemDragEnter(t, e.index) : null,
			onDragover: (t) => e.type === "item" ? j.onItemDragOver(t, e.index) : null,
			onPointerdown: (t) => e.type === "item" ? j.onItemPointerDown(t, e.index) : null,
			onPointermove: (t) => e.type === "item" ? j.onItemPointerMove(t, e.index) : null,
			onPointerup: (t) => e.type === "item" ? j.onItemPointerUp(t) : null,
			onPointercancel: (t) => e.type === "item" ? j.onItemPointerCancel(t) : null,
			onLostpointercapture: (t) => e.type === "item" ? j.onItemLostPointerCapture(t) : null,
			onDragend: (t) => e.type === "item" ? j.onDragEnd(t) : null
		}, [e.type === "item" ? (u(), a("div", D, [
			j.selectionMode === "Multiple" || j.selectionMode === "Extended" ? (u(), r(j.SelectionCheck, {
				key: 0,
				class: "grid-checkbox",
				Item: e.item
			}, null, 8, ["Item"])) : i("", !0),
			o("div", O, [(u(), r(f(j.itemComponent(e.item, e.index))))]),
			j.isDragging && e.index === j.dragOriginIndex && j.dragIndices.length > 1 ? (u(), a("div", k, p(j.dragIndices.length), 1)) : i("", !0)
		])) : i("", !0)], 46, E))), 128))], 4))], 4)]),
		_: 1
	})])], 46, v)), [[j.vAcrylicBrush, j.backgroundStyle]]);
}
var j = /*#__PURE__*/ e(t, [["render", A], ["__file", "GridView.vue"]]);
//#endregion
export { j as default };

//# sourceMappingURL=GridView.vue.js.map