import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./BreadcrumbBarItem.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                                      */
import { createBlock as n, createCommentVNode as r, createElementBlock as i, createVNode as a, mergeProps as o, normalizeClass as s, openBlock as c, withCtx as l } from "vue";
//#region src/components/BreadcrumbBarItem.vue
var u = [
	"dir",
	"tabindex",
	"aria-label",
	"aria-disabled",
	"aria-hidden",
	"aria-current",
	"inert"
];
function d(e, t, d, f, p, m) {
	return c(), i("div", o({ ref: "rootRef" }, f.rootAttrs, {
		class: [
			"win-breadcrumb-layout-root",
			f.attrs.class,
			{
				"is-current": f.isCurrent,
				"win-breadcrumb-ellipsis-item": f.isEllipsis,
				"win-breadcrumb-flyout-item": f.isDropDown,
				"is-crumbled": f.isHidden,
				"is-disabled": !f.isEnabled,
				"is-pointer-over": f.isPointerOver,
				"is-pressed": f.isPressed
			}
		],
		style: [f.attrs.style, f.layoutStyle],
		role: "button",
		dir: f.flowDirection,
		tabindex: f.tabIndex,
		"aria-label": f.automationName || void 0,
		"aria-disabled": f.isEnabled ? void 0 : "true",
		"aria-hidden": f.isHidden ? "true" : void 0,
		"aria-current": f.isCurrent ? "page" : void 0,
		inert: f.isHidden ? !0 : void 0,
		onFocusin: f.onGotFocus,
		onKeydown: f.onKeyDown,
		onPointerenter: f.onPointerEnter,
		onPointermove: f.onPointerEnter,
		onPointerleave: f.clearPointer,
		onPointerdown: f.onPointerDown,
		onPointerup: f.onPointerUp,
		onPointercancel: f.clearPointer,
		onLostpointercapture: f.clearPointer,
		onClick: f.onAccessibleClick
	}), [
		a(f.Button, {
			Visibility: "{x:Bind BreadcrumbButtonVisibility, Mode=OneWay}",
			class: "win-breadcrumb-item-button",
			IsEnabled: "{x:Bind BreadcrumbTemplate.IsEnabled, Mode=OneWay}",
			BorderThickness: "{x:Bind BreadcrumbTemplate.BorderThickness, Mode=OneWay}",
			BorderBrush: "{x:Bind BreadcrumbTemplate.BorderBrush, Mode=OneWay}",
			MinHeight: "0",
			MinWidth: "0",
			Padding: "{x:Bind BreadcrumbTemplate.ContentPadding, Mode=OneWay}",
			FontFamily: "{x:Bind BreadcrumbTemplate.FontFamily, Mode=OneWay}",
			FontSize: "{x:Bind BreadcrumbTemplate.FontSize, Mode=OneWay}",
			FontWeight: "{x:Bind BreadcrumbTemplate.FontWeight, Mode=OneWay}",
			CornerRadius: "{x:Bind BreadcrumbTemplate.CornerRadius, Mode=OneWay}",
			HorizontalAlignment: "Left",
			VerticalAlignment: "Center",
			tabindex: "-1",
			Click: "BreadcrumbTemplate.OnClick"
		}, {
			default: l(() => [f.isEllipsis ? (c(), n(f.TextBlock, {
				key: 0,
				class: "win-breadcrumb-ellipsis-glyph icon",
				Text: "",
				Padding: "3",
				FontFamily: "{ThemeResource SymbolThemeFontFamily}",
				IsTextScaleFactorEnabled: "False"
			})) : (c(), n(f.ContentPresenter, {
				key: 1,
				class: "win-breadcrumb-item-content-presenter",
				HorizontalContentAlignment: "{x:Bind BreadcrumbTemplate.HorizontalContentAlignment, Mode=OneWay}",
				VerticalContentAlignment: "{x:Bind BreadcrumbTemplate.VerticalContentAlignment, Mode=OneWay}"
			}, {
				default: l(() => [a(f.ContentOutlet)]),
				_: 1
			}))]),
			_: 1
		}),
		f.isCurrent || f.isDropDown ? (c(), n(f.ContentPresenter, {
			key: 0,
			class: s(f.isDropDown ? "win-breadcrumb-dropdown-content-presenter" : "win-breadcrumb-current-item"),
			Padding: "{x:Bind BreadcrumbTemplate.ContentPadding, Mode=OneWay}",
			CornerRadius: "{x:Bind BreadcrumbTemplate.CornerRadius, Mode=OneWay}",
			HorizontalContentAlignment: "{x:Bind BreadcrumbTemplate.HorizontalContentAlignment, Mode=OneWay}",
			VerticalContentAlignment: "{x:Bind BreadcrumbTemplate.VerticalContentAlignment, Mode=OneWay}"
		}, {
			default: l(() => [a(f.ContentOutlet)]),
			_: 1
		}, 8, ["class"])) : r("", !0),
		!f.isCurrent && !f.isDropDown ? (c(), n(f.TextBlock, {
			key: 1,
			class: "win-breadcrumb-chevron icon",
			Text: "{x:Bind BreadcrumbTemplate.ChevronGlyph, Mode=OneWay}",
			Padding: "{ThemeResource BreadcrumbBarChevronPadding}",
			FontFamily: "{ThemeResource SymbolThemeFontFamily}",
			FontSize: "{ThemeResource BreadcrumbBarChevronFontSize}",
			IsTextScaleFactorEnabled: "False",
			"aria-hidden": "true"
		})) : r("", !0)
	], 16, u);
}
var f = /*#__PURE__*/ e(t, [
	["render", d],
	["__scopeId", "data-v-21e46165"],
	["__file", "BreadcrumbBarItem.vue"]
]);
//#endregion
export { f as default };

//# sourceMappingURL=BreadcrumbBarItem.vue.js.map