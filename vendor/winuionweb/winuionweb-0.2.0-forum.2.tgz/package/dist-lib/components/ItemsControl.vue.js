import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./ItemsControl.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                                 */
import { createElementBlock as n, createElementVNode as r, createVNode as i, mergeProps as a, openBlock as o } from "vue";
//#region src/components/ItemsControl.vue
var s = [
	"tabindex",
	"inert",
	"aria-disabled"
], c = { class: "win-items-presenter" };
function l(e, t, l, u, d, f) {
	return o(), n("div", a({ ref: "element" }, u.attrs, {
		class: "win-items-control",
		style: u.hostStyle,
		tabindex: u.IsEnabled && u.IsTabStop ? 0 : void 0,
		inert: u.IsEnabled ? void 0 : !0,
		"aria-disabled": u.IsEnabled ? void 0 : !0
	}), [r("div", c, [i(u.PanelOutlet)])], 16, s);
}
var u = /*#__PURE__*/ e(t, [
	["render", l],
	["__scopeId", "data-v-e4853382"],
	["__file", "ItemsControl.vue"]
]);
//#endregion
export { u as default };

//# sourceMappingURL=ItemsControl.vue.js.map