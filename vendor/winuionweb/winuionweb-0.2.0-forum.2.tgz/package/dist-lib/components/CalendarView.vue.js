import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./CalendarView.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                                 */
import { Fragment as n, createCommentVNode as r, createElementBlock as i, createElementVNode as a, createVNode as o, mergeProps as s, openBlock as c, renderList as l, toDisplayString as u, withCtx as d } from "vue";
//#region src/components/CalendarView.vue
var f = { class: "calendar-header" }, p = {
	ref: "views",
	class: "calendar-views"
}, m = {
	class: "calendar-view-panel",
	"data-panel": "Month"
}, h = { class: "calendar-weekday-names" }, g = {
	key: 0,
	class: "calendar-label month-label"
}, _ = { class: "calendar-text" }, v = {
	key: 1,
	class: "calendar-density"
}, y = {
	class: "calendar-view-panel",
	"data-panel": "Year"
}, b = {
	key: 0,
	class: "calendar-label year-label"
}, x = { class: "calendar-text" }, S = {
	class: "calendar-view-panel",
	"data-panel": "Decade"
}, C = { class: "calendar-text" };
function w(e, t, w, T, E, D) {
	return c(), i("div", s({
		ref: "root",
		class: "win-calendar-view"
	}, T.rootAttrs), [
		a("div", f, [
			a("button", s({
				type: "button",
				class: "calendar-header-button",
				"data-cmd": "header"
			}, T.headerAttrs), [a("span", null, u(T.headerText), 1)], 16),
			a("button", s({
				type: "button",
				class: "calendar-nav-button",
				"data-cmd": "previous"
			}, T.previousAttrs), "", 16),
			a("button", s({
				type: "button",
				class: "calendar-nav-button",
				"data-cmd": "next"
			}, T.nextAttrs), "", 16)
		]),
		t[1] ||= a("div", {
			class: "calendar-separator",
			"aria-hidden": "true"
		}, null, -1),
		a("div", p, [
			t[0] ||= a("div", {
				class: "calendar-background-layer",
				"aria-hidden": "true"
			}, null, -1),
			a("div", m, [a("div", h, [(c(!0), i(n, null, l(T.weekdayNames, (e, t) => (c(), i("span", s({ ref_for: !0 }, { key: t }), u(e), 17))), 256))]), o(T.ScrollViewer, {
				ref: "monthViewer",
				class: "calendar-scroll",
				Template: "{StaticResource ScrollViewerScrollBarlessTemplate}",
				HorizontalScrollMode: "Disabled",
				VerticalScrollMode: "Enabled",
				HorizontalScrollBarVisibility: "Disabled",
				VerticalScrollBarVisibility: "Hidden",
				IsVerticalScrollChainingEnabled: "False",
				IsTabStop: "False"
			}, {
				default: d(() => [a("div", s({ class: "calendar-extent" }, { style: { height: T.dayExtent + "px" } }), [a("div", s({ class: "calendar-day-grid" }, { style: { top: T.dayRenderTop + "px" } }), [(c(!0), i(n, null, l(T.dayCells, (e) => (c(), i("div", s({ class: "calendar-slot" }, { ref_for: !0 }, {
					key: e.serial,
					style: { height: T.rowHeight + "px" }
				}), [a("button", s({
					type: "button",
					class: "calendar-item calendar-day-item"
				}, { ref_for: !0 }, T.dayAttrs(e)), [
					e.showLabel && T.groupLabels ? (c(), i("span", g, u(e.month.text), 1)) : r("", !0),
					a("span", _, u(T.model.dayNumber(e.serial)), 1),
					e.state.DensityColors.length ? (c(), i("span", v, [(c(!0), i(n, null, l(e.state.DensityColors, (e, t) => (c(), i("span", s({ ref_for: !0 }, {
						key: t,
						style: { background: e }
					}), null, 16))), 256))])) : r("", !0)
				], 16)], 16))), 256))], 16)], 16)]),
				_: 1
			}, 512)]),
			a("div", y, [o(T.ScrollViewer, {
				ref: "yearViewer",
				class: "calendar-scroll",
				Template: "{StaticResource ScrollViewerScrollBarlessTemplate}",
				HorizontalScrollMode: "Disabled",
				VerticalScrollMode: "Enabled",
				HorizontalScrollBarVisibility: "Disabled",
				VerticalScrollBarVisibility: "Hidden",
				IsVerticalScrollChainingEnabled: "False",
				IsTabStop: "False"
			}, {
				default: d(() => [a("div", s({ class: "calendar-extent" }, { style: { height: T.yearExtent + "px" } }), [a("div", s({ class: "calendar-large-grid" }, { style: {
					top: T.monthRenderTop + "px",
					gridTemplateColumns: "repeat(" + T.columns + ", minmax(0, 1fr))"
				} }), [(c(!0), i(n, null, l(T.monthCells, (e) => (c(), i("div", s({ class: "calendar-slot" }, { ref_for: !0 }, {
					key: e.index,
					style: { height: T.largeRowHeight + "px" }
				}), [a("button", s({
					type: "button",
					class: "calendar-item calendar-large-item"
				}, { ref_for: !0 }, T.monthAttrs(e)), [e.index === T.model.years[e.yearIndex].firstMonth && T.groupLabels ? (c(), i("span", b, u(e.label), 1)) : r("", !0), a("span", x, u(e.text), 1)], 16)], 16))), 256))], 16)], 16)]),
				_: 1
			}, 512)]),
			a("div", S, [o(T.ScrollViewer, {
				ref: "decadeViewer",
				class: "calendar-scroll",
				Template: "{StaticResource ScrollViewerScrollBarlessTemplate}",
				HorizontalScrollMode: "Disabled",
				VerticalScrollMode: "Enabled",
				HorizontalScrollBarVisibility: "Disabled",
				VerticalScrollBarVisibility: "Hidden",
				IsVerticalScrollChainingEnabled: "False",
				IsTabStop: "False"
			}, {
				default: d(() => [a("div", s({ class: "calendar-extent" }, { style: { height: T.decadeExtent + "px" } }), [a("div", s({ class: "calendar-large-grid" }, { style: {
					top: T.yearRenderTop + "px",
					gridTemplateColumns: "repeat(" + T.columns + ", minmax(0, 1fr))"
				} }), [(c(!0), i(n, null, l(T.yearCells, (e) => (c(), i("div", s({ class: "calendar-slot" }, { ref_for: !0 }, {
					key: e.index,
					style: { height: T.largeRowHeight + "px" }
				}), [a("button", s({
					type: "button",
					class: "calendar-item calendar-large-item"
				}, { ref_for: !0 }, T.yearAttrs(e)), [a("span", C, u(e.text), 1)], 16)], 16))), 256))], 16)], 16)]),
				_: 1
			}, 512)])
		], 512)
	], 16);
}
var T = /*#__PURE__*/ e(t, [
	["render", w],
	["__scopeId", "data-v-e45801ba"],
	["__file", "CalendarView.vue"]
]);
//#endregion
export { T as default };

//# sourceMappingURL=CalendarView.vue.js.map