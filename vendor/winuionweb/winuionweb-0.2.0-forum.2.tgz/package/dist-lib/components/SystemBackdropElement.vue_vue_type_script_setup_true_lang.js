import { xamlBrushResourceKey as e, xamlThemeKey as t } from "./brushCore.js";
import { normalizeXamlNodes as n, resolveXamlValue as r, updateXamlBinding as i } from "./xamlRuntime.js";
import { frameworkLayoutStyle as ee } from "./frameworkLayout.js";
import { SystemBackdrop as te, toSystemBackdropConfig as a } from "./systemBackdrop.js";
import { createSystemBackdropSurface as ne, systemBackdropHostAdapterKey as o } from "./systemBackdropHostAdapter.js";
import { SystemBackdropElementSystemBackdrop as s } from "./systemBackdropXaml.js";
import { Comment as c, Fragment as l, cloneVNode as u, computed as d, defineComponent as f, getCurrentInstance as p, inject as m, markRaw as re, onBeforeUnmount as ie, onMounted as ae, ref as h, shallowRef as g, unref as _, useAttrs as oe, useSlots as se, watch as v } from "vue";
var y = /*@__PURE__*/ f({
	SystemBackdrop: s,
	name: "SystemBackdropElement",
	inheritAttrs: !1,
	__name: "SystemBackdropElement",
	props: {
		SystemBackdrop: {
			type: [String, Object],
			default: null
		},
		CornerRadius: {
			type: [String, Number],
			default: 0
		},
		Width: {
			type: [String, Number],
			default: ""
		},
		Height: {
			type: [String, Number],
			default: ""
		},
		MinWidth: {
			type: [String, Number],
			default: 0
		},
		MinHeight: {
			type: [String, Number],
			default: 0
		},
		MaxWidth: {
			type: [String, Number],
			default: ""
		},
		MaxHeight: {
			type: [String, Number],
			default: ""
		},
		Margin: {
			type: [String, Number],
			default: 0
		},
		HorizontalAlignment: {
			type: String,
			default: "Stretch"
		},
		VerticalAlignment: {
			type: String,
			default: "Stretch"
		},
		Visibility: {
			type: String,
			default: "Visible"
		},
		Opacity: {
			type: [String, Number],
			default: 1
		},
		RequestedTheme: {
			type: String,
			default: "Default"
		},
		IsHitTestVisible: {
			type: [Boolean, String],
			default: !0
		}
	},
	emits: ["update:SystemBackdrop", "update:CornerRadius"],
	setup(s, { expose: y, emit: ce }) {
		let b = s, x = ce, S = p(), C = oe(), w = se(), T = h(null), E = g(null), D = g(void 0), O = m(t, null) ?? m("winuiTheme", null), k = m(e, {}), A = m(o, void 0), j = (e) => r(e, S), M = d(() => {
			let e = j(b.RequestedTheme), t = _(O);
			return e === "Light" || e === "Dark" ? e : t === "Light" || t === "light" ? "Light" : t === "Dark" || t === "dark" ? "Dark" : "Default";
		}), N = () => {
			let e = b.SystemBackdrop, t = typeof e == "string" ? e.match(/^\{(?:StaticResource|ThemeResource)\s+([^}]+)\}$/)?.[1]?.trim() : void 0;
			if (t) {
				let e = _(k)?.[t];
				if (e && typeof e == "object" && "__xamlThemeResource" in e) {
					let t = e;
					return t[M.value] ?? t.Default;
				}
				if (e) return e;
			}
			return j(e);
		}, P = d({
			get: () => D.value === void 0 ? N() ?? E.value : D.value,
			set: (e) => {
				if (e !== null && !a(e)) throw TypeError("SystemBackdropElement.SystemBackdrop must be a SystemBackdrop or null.");
				D.value = typeof e == "object" && e ? re(e) : e, i(b.SystemBackdrop, e, S), x("update:SystemBackdrop", e);
			}
		});
		v(() => j(b.SystemBackdrop), () => {
			D.value = void 0;
		});
		let F = g(void 0), I = d({
			get: () => F.value === void 0 ? j(b.CornerRadius) : F.value,
			set: (e) => {
				F.value = e, i(b.CornerRadius, e, S), x("update:CornerRadius", e);
			}
		});
		v(() => j(b.CornerRadius), () => {
			F.value = void 0;
		});
		let L = d(() => ({ ...ee({
			...b,
			CornerRadius: I.value
		}, S) })), le = d(() => Object.fromEntries(Object.entries(C).filter(([e]) => e !== "style" && e !== "class"))), R = (e) => Array.isArray(e.children) ? e.children : e.children?.default?.() ?? [], z = (e) => e.flatMap((e) => e.type === l ? z(R(e)) : e.type === c ? [] : [e]), ue = f({ setup: () => () => {
			let e = z(w.default?.() ?? []).filter((e) => e.type.__systemBackdropProperty).flatMap((e) => z(R(e))).filter((e) => e.type.__systemBackdropDeclaration);
			if (e.length > 1) throw TypeError("SystemBackdropElement.SystemBackdrop accepts one SystemBackdrop.");
			return e.length ? u(n(e, S)[0], { ref: (e) => {
				E.value = e;
			} }, !0) : null;
		} }), B = g(null), V = h(0), H;
		v(P, (e) => {
			H?.(), H = e instanceof te ? e.Subscribe(() => {
				V.value += 1;
			}) : void 0;
		}, { immediate: !0 });
		let U = d(() => (V.value, a(P.value))), W, G, K, q = 0, J = !1, Y = !1, X, Z = () => {
			q += 1, K?.abort(), K = void 0;
			let e = W;
			W = void 0, G?.(), G = void 0, B.value = null, e?.Close().catch((e) => {
				console.error(e);
			});
		}, Q = async () => {
			if (J || W || Y || !T.value?.isConnected) return;
			let e = ++q;
			Y = !0, K = new AbortController();
			try {
				let t = await ne(T.value, {
					theme: M.value,
					backdrop: U.value,
					adapter: A,
					signal: K.signal
				});
				if (J || e !== q || !T.value?.isConnected) {
					await t.Close();
					return;
				}
				W = t, G = t.Subscribe((e) => {
					B.value = e;
				}), await t.SetTheme(M.value), await t.SetSystemBackdrop(U.value);
			} catch (t) {
				if (!J && e === q) throw t;
			} finally {
				Y = !1, !J && !W && T.value?.isConnected && e !== q && Q().catch((e) => {
					console.error(e);
				});
			}
		};
		v(U, (e) => {
			W && W.SetSystemBackdrop(e);
		}, { deep: !0 }), v(M, (e) => {
			W && W.SetTheme(e);
		}), ae(() => {
			Q().catch((e) => {
				console.error(e);
			}), X = new MutationObserver(() => {
				T.value?.isConnected ? W || Q().catch((e) => {
					console.error(e);
				}) : Z();
			}), X.observe(T.value.ownerDocument, {
				childList: !0,
				subtree: !0
			});
		}), ie(() => {
			J = !0, X?.disconnect(), H?.(), Z();
		}), y({
			SystemBackdrop: P,
			CornerRadius: I,
			Element: T,
			State: B
		});
		let $ = {
			props: b,
			emit: x,
			instance: S,
			attrs: C,
			slots: w,
			element: T,
			declaration: E,
			assigned: D,
			inheritedTheme: O,
			resourceScope: k,
			adapter: A,
			resolve: j,
			theme: M,
			providedBackdrop: N,
			SystemBackdropProperty: P,
			localCornerRadius: F,
			CornerRadius: I,
			layoutStyle: L,
			forwardedAttrs: le,
			children: R,
			flatten: z,
			BackdropDeclarationOutlet: ue,
			State: B,
			revision: V,
			get unsubscribeBackdrop() {
				return H;
			},
			set unsubscribeBackdrop(e) {
				H = e;
			},
			config: U,
			get handle() {
				return W;
			},
			set handle(e) {
				W = e;
			},
			get unsubscribeState() {
				return G;
			},
			set unsubscribeState(e) {
				G = e;
			},
			get connectionAbort() {
				return K;
			},
			set connectionAbort(e) {
				K = e;
			},
			get version() {
				return q;
			},
			set version(e) {
				q = e;
			},
			get disposed() {
				return J;
			},
			set disposed(e) {
				J = e;
			},
			get connecting() {
				return Y;
			},
			set connecting(e) {
				Y = e;
			},
			get observer() {
				return X;
			},
			set observer(e) {
				X = e;
			},
			disconnect: Z,
			connect: Q
		};
		return Object.defineProperty($, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), $;
	}
});
//#endregion
export { y as default };

//# sourceMappingURL=SystemBackdropElement.vue_vue_type_script_setup_true_lang.js.map