import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./SemanticZoom.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                                 */
import { createElementBlock as n, createElementVNode as r, createVNode as i, mergeProps as a, normalizeClass as o, normalizeStyle as s, openBlock as c, withCtx as l } from "vue";
//#region src/components/SemanticZoom.vue
var u = ["tabindex", "aria-disabled"], d = ["aria-hidden", "inert"], f = ["aria-hidden", "inert"];
function p(e, t, p, m, h, g) {
	return c(), n("div", a({ ref: "rootRef" }, m.forwardedAttrs, {
		class: ["win-semantic-zoom", {
			"zoomed-in": m.isZoomedIn,
			"zoomed-out": !m.isZoomedIn,
			"is-changing-view": m.isChangingView,
			"is-disabled": !m.isEnabled
		}],
		style: m.rootStyle,
		tabindex: m.isEnabled && m.isTabStop ? 0 : -1,
		"aria-disabled": !m.isEnabled,
		onKeydown: m.onKeyDown,
		onWheelCapture: m.onWheel,
		onSemanticzoomrequest: m.onSemanticZoomRequest,
		onTouchstartCapture: m.onLegacyTouch,
		onTouchmoveCapture: m.onLegacyTouch,
		onTouchendCapture: m.onLegacyTouch,
		onTouchcancelCapture: m.onLegacyTouch,
		onPointerdown: m.onPointerDown,
		onPointermove: m.onPointerMove,
		onPointerup: m.onPointerEnd,
		onPointercancel: m.onPointerEnd,
		onLostpointercapture: m.onPointerEnd
	}), [i(m.ScrollViewer, {
		class: "semantic-zoom-scroll-viewer",
		HorizontalScrollMode: "{x:Bind templateHorizontalScrollMode, Mode=OneWay}",
		HorizontalScrollBarVisibility: "Hidden",
		VerticalScrollMode: "{x:Bind templateVerticalScrollMode, Mode=OneWay}",
		VerticalScrollBarVisibility: "Hidden",
		ZoomMode: "{x:Bind templateZoomMode, Mode=OneWay}",
		IsHorizontalRailEnabled: "{x:Bind templateHorizontalRailEnabled, Mode=OneWay}",
		IsVerticalRailEnabled: "{x:Bind templateVerticalRailEnabled, Mode=OneWay}",
		IsZoomChainingEnabled: "True",
		IsZoomInertiaEnabled: "False",
		IsScrollInertiaEnabled: "True",
		HorizontalContentAlignment: "Center",
		VerticalContentAlignment: "Center",
		MinZoomFactor: "0.5",
		MaxZoomFactor: "1.0",
		"AutomationProperties.AccessibilityView": "Raw"
	}, {
		default: l(() => [i(m.ScrollViewer.Template, null, {
			default: l(() => [i(m.ControlTemplate, { TargetType: "ScrollViewer" }, {
				default: l(() => [i(m.ScrollContentPresenter, { "x:Name": "ScrollContentPresenter" })]),
				_: 1
			})]),
			_: 1
		}), r("div", {
			class: "semantic-zoom-surface",
			style: s(m.surfaceStyle)
		}, [r("div", {
			ref: "zoomedInPresenterRef",
			class: "semantic-zoom-presenter zoomed-in-presenter",
			"data-template-part": "ZoomedInPresenter",
			style: s(m.zoomedInPresenterStyle),
			"aria-hidden": !m.isZoomedIn,
			inert: !m.isZoomedIn || !m.isEnabled ? !0 : void 0
		}, [i(m.ZoomedInOutlet)], 12, d), r("div", {
			ref: "zoomedOutPresenterRef",
			class: "semantic-zoom-presenter zoomed-out-presenter",
			"data-template-part": "ZoomedOutPresenter",
			style: s(m.zoomedOutPresenterStyle),
			"aria-hidden": m.isZoomedIn,
			inert: m.isZoomedIn || !m.isEnabled ? !0 : void 0
		}, [i(m.ZoomedOutOutlet)], 12, f)], 4)]),
		_: 1
	}), i(m.Button, {
		class: o(["zoom-out-button", { visible: m.isZoomOutButtonVisible }]),
		Width: "12",
		Height: "12",
		MinWidth: "0",
		MinHeight: "0",
		Padding: "0",
		Margin: "0,0,19,19",
		IsTabStop: "False",
		HorizontalAlignment: "Right",
		VerticalAlignment: "Bottom",
		FontFamily: "{ThemeResource SymbolThemeFontFamily}",
		FontSize: "4",
		Content: "",
		Click: "ZoomOutButton_Click",
		IsEnabled: "{x:Bind templateIsEnabled, Mode=OneWay}",
		"AutomationProperties.Name": "{x:Bind zoomOutLabel, Mode=OneWay}"
	}, null, 8, ["class"])], 16, u);
}
var m = /*#__PURE__*/ e(t, [
	["render", p],
	["__scopeId", "data-v-cc585f77"],
	["__file", "SemanticZoom.vue"]
]);
//#endregion
export { m as default };

//# sourceMappingURL=SemanticZoom.vue.js.map