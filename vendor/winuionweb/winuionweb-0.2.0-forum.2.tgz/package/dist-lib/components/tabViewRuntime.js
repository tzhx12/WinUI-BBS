import { shallowRef as e } from "vue";
//#region src/components/tabViewRuntime.ts
var t = () => {
	let e = /* @__PURE__ */ new Map(), t = {};
	return {
		Properties: t,
		RequestedOperation: "Move",
		SetText: (t) => {
			e.set("Text", t);
		},
		SetData: (t, n) => {
			e.set(t, n);
		},
		GetView: () => ({
			Properties: t,
			AvailableFormats: [...e.keys()],
			Contains: (t) => e.has(t),
			GetTextAsync: async () => String(e.get("Text") ?? ""),
			GetDataAsync: async (t) => e.get(t)
		})
	};
}, n = /* @__PURE__ */ new Set(), r = e(null), i = !1, a = (e) => (n.add(e), () => {
	(r.value?.Source === e || r.value?.Target === e) && u(), n.delete(e);
}), o = (e) => {
	u(), i = !1, r.value = e;
}, s = (e, t, a = null) => {
	let o = r.value;
	if (!o || i) return;
	o.X = e, o.Y = t, o.Ghost && (o.Ghost.style.transform = `translate3d(${e + 12}px,${t + 12}px,0)`);
	let s = [...n].find((n) => {
		let r = n.Element()?.getBoundingClientRect();
		return r && e >= r.left && e <= r.right && t >= r.top && t <= r.bottom && n.CanAccept(o);
	}) ?? null;
	o.Target !== s && (o.Target?.Leave(), o.Target = s), s && !s.Over(o, a) && (s.Leave(), o.Target = null);
}, c = (e) => {
	e.Target?.Leave(), e.Ghost?.remove(), r.value === e && (r.value = null), i = !1;
}, l = async (e = null, t) => {
	let n = r.value;
	if (!n || i) return;
	i = !0;
	let a = t ?? "None", o = !1;
	try {
		try {
			t === void 0 && n.Target && (a = await n.Target.Drop(n, e), a === "None" && (o = !0, n.Controller.abort()));
		} catch {
			a = "None", o = !0, n.Controller.abort();
		}
		r.value === n && n.Source.Complete(n, a, o || n.Controller.signal.aborted);
	} finally {
		r.value === n && c(n);
	}
}, u = () => {
	let e = r.value;
	e && (e.Controller.abort(), c(e), e.Source.Complete(e, "None", !0));
};
//#endregion
export { r as activeTabViewDrag, u as cancelTabViewDrag, t as createTabViewDataPackage, l as endTabViewDrag, s as moveTabViewDrag, a as registerTabViewDragEndpoint, o as startTabViewDrag };

//# sourceMappingURL=tabViewRuntime.js.map