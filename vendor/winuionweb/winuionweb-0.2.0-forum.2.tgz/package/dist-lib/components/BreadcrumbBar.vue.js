import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./BreadcrumbBar.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                                  */
import { Fragment as n, createBlock as r, createElementBlock as i, createElementVNode as a, createVNode as o, mergeProps as s, normalizeStyle as c, openBlock as l, renderList as u, withCtx as d } from "vue";
//#region src/components/BreadcrumbBar.vue
var f = ["aria-disabled", "dir"], p = ["dir"];
function m(e, t, m, h, g, _) {
	return l(), i(n, null, [a("nav", s({ ref: "rootRef" }, h.rootAttrs, {
		class: ["win-breadcrumb-bar", h.attrs.class],
		style: [h.attrs.style, h.rootStyle],
		role: "navigation",
		"aria-disabled": h.IsEnabled ? void 0 : "true",
		dir: h.effectiveFlowDirection,
		onFocusout: h.onFocusOut
	}), [a("div", {
		class: "win-breadcrumb-items-repeater",
		style: c(h.repeaterStyle)
	}, [o(h.ItemOutlet, { index: "-1" }), (l(!0), i(n, null, u(h.Items, (e, t) => (l(), r(h.ItemOutlet, s({ key: h.getItemKey(e, t) }, { ref_for: !0 }, {
		item: e,
		index: t
	}), null, 16))), 128))], 4)], 16, f), o(h.Flyout, {
		ref: "flyoutRef",
		Placement: "Bottom",
		ShouldConstrainToRootBounds: "False",
		FlyoutPresenterStyle: "{x:Bind BreadcrumbBarTemplate.FlyoutPresenterStyle, Mode=OneWay}"
	}, {
		default: d(() => [a("div", {
			class: "win-breadcrumb-flyout-items",
			dir: h.effectiveFlowDirection,
			"data-breadcrumb-owner": h.instanceId
		}, [(l(!0), i(n, null, u(h.flyoutItems, ({ Item: e, Index: t }, n) => (l(), r(h.ItemOutlet, s({ key: h.getItemKey(e, t) }, { ref_for: !0 }, {
			item: e,
			index: t,
			flyoutIndex: n,
			dropDown: !0
		}), null, 16))), 128))], 8, p)]),
		_: 1
	}, 512)], 64);
}
var h = /*#__PURE__*/ e(t, [
	["render", m],
	["__scopeId", "data-v-16b0d318"],
	["__file", "BreadcrumbBar.vue"]
]);
//#endregion
export { h as default };

//# sourceMappingURL=BreadcrumbBar.vue.js.map