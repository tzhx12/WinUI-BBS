import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./TreeView.vue_vue_type_script_setup_true_lang.js";
/* empty css                                             */
import { Fragment as n, createBlock as r, createCommentVNode as i, createElementBlock as a, createElementVNode as o, createVNode as s, normalizeClass as c, normalizeStyle as l, openBlock as u, renderList as d, resolveDynamicComponent as f, toDisplayString as p, withCtx as m, withDirectives as h, withModifiers as g } from "vue";
//#region src/components/TreeView.vue
var _ = ["aria-disabled", "aria-multiselectable"], v = [
	"id",
	"tabindex",
	"aria-level",
	"aria-posinset",
	"aria-setsize",
	"aria-expanded",
	"aria-selected",
	"aria-checked",
	"onFocus",
	"onClick",
	"onPointerdown",
	"onPointermove",
	"onPointerleave",
	"onKeydown",
	"onDragstart"
], y = ["aria-checked", "onClick"], b = {
	key: 0,
	class: "win-tree-drag-count",
	"aria-hidden": "true"
}, x = ["onPointerdown"];
function S(e, t, S, C, w, T) {
	return h((u(), a("div", {
		ref: "containerRef",
		class: c(["win-tree-view", {
			disabled: !C.isEnabled,
			"pointer-dragging": C.pointerDragActive,
			"tree-content-transitions": C.transitionState.content,
			"tree-reorder-transitions": C.transitionState.reorder,
			"tree-entrance-transitions": C.transitionState.entrance
		}]),
		style: l(C.rootStyle),
		role: "tree",
		"aria-disabled": !C.isEnabled,
		"aria-multiselectable": C.selectionMode === "Multiple",
		onDragover: C.onRootDragOver,
		onDrop: C.onRootDrop
	}, [s(C.ScrollViewer, {
		class: "win-tree-viewport",
		VerticalScrollMode: "{x:Bind ScrollSettings.VerticalScrollMode, Mode=OneWay}",
		VerticalScrollBarVisibility: "{x:Bind ScrollSettings.VerticalScrollBarVisibility, Mode=OneWay}",
		HorizontalScrollMode: "{x:Bind ScrollSettings.HorizontalScrollMode, Mode=OneWay}",
		HorizontalScrollBarVisibility: "{x:Bind ScrollSettings.HorizontalScrollBarVisibility, Mode=OneWay}",
		IsHorizontalRailEnabled: "{x:Bind ScrollSettings.IsHorizontalRailEnabled, Mode=OneWay}",
		IsVerticalRailEnabled: "{x:Bind ScrollSettings.IsVerticalRailEnabled, Mode=OneWay}",
		IsVerticalScrollChainingEnabled: "{x:Bind ScrollSettings.IsVerticalScrollChainingEnabled, Mode=OneWay}",
		IsHorizontalScrollChainingEnabled: "{x:Bind ScrollSettings.IsHorizontalScrollChainingEnabled, Mode=OneWay}",
		IsEnabled: "{x:Bind ScrollTemplateIsEnabled, Mode=OneWay}",
		ZoomMode: "{x:Bind ScrollSettings.ZoomMode, Mode=OneWay}"
	}, {
		default: m(() => [o("div", {
			ref: "listRef",
			class: c(["win-tree-content", { "drag-sinking": C.isDragging || C.isExternalDragOver }]),
			style: l(C.contentPaddingStyle),
			onDragover: C.onViewportDragOver,
			onDrop: C.onViewportDrop,
			onDragleave: C.onViewportDragLeave
		}, [(u(!0), a(n, null, d(C.rows, (e) => (u(), a("div", {
			key: e.node.Key,
			id: C.rowId(e),
			class: c(["win-tree-item", C.rowClasses(e)]),
			style: l(C.rowStyle(e)),
			tabindex: C.isEnabled && e.node === C.activeNode ? 0 : -1,
			"aria-level": e.depth + 1,
			"aria-posinset": e.positionInSet,
			"aria-setsize": e.setSize,
			"aria-expanded": e.hasChildren ? e.isExpanded : void 0,
			"aria-selected": C.selectionMode === "None" ? void 0 : e.isSelected,
			"aria-checked": C.selectionMode === "Multiple" ? C.checkboxAriaValue(e) : void 0,
			role: "treeitem",
			onFocus: (t) => C.onRowFocus(e),
			onClick: (t) => C.onRowClick(t, e),
			onPointerdown: (t) => C.onRowPointerDown(t, e),
			onPointermove: (t) => C.onRowPointerMove(t, e),
			onPointerup: t[1] ||= (e) => C.onRowPointerUp(e),
			onPointercancel: t[2] ||= (e) => C.onRowPointerCancel(e),
			onPointerleave: (t) => C.onRowPointerLeave(t, e),
			onLostpointercapture: t[3] ||= (e) => C.onRowLostPointerCapture(e),
			onKeydown: (t) => C.onRowKeyDown(t, e),
			draggable: !1,
			onDragstart: (t) => C.onNativeDragStart(t, e),
			onDragend: t[4] ||= (e) => C.onNativeDragEnd(e)
		}, [o("div", {
			class: c(["win-tree-presenter", { "grid-padding-none": C.selectionMode === "Multiple" }]),
			style: l(C.presenterStyle(e))
		}, [C.selectionMode !== "None" && C.selectionMode !== "Multiple" ? (u(), a("div", {
			key: 0,
			class: c(["win-tree-selection-indicator", { active: e.isSelected }]),
			"aria-hidden": "true"
		}, null, 2)) : i("", !0), o("div", {
			class: c(["win-tree-multiselect-grid", { "multi-selected": C.selectionMode === "Multiple" && e.selectionState === "Selected" }]),
			style: l({ paddingInlineStart: `${e.depth * 16}px` })
		}, [
			C.selectionMode === "Multiple" ? (u(), a("div", {
				key: 0,
				class: "win-tree-multiselect-slot",
				role: "checkbox",
				"aria-checked": C.checkboxAriaValue(e),
				onPointerdown: t[0] ||= g(() => {}, ["stop"]),
				onClick: g((t) => C.onMultiSelectClick(e), ["stop", "prevent"])
			}, [s(C.TreeViewItemScope, { Node: e.node }, {
				default: m(() => [s(C.CheckBox, {
					class: "tree-selection-check",
					IsChecked: "{x:Bind IsChecked, Mode=OneWay}",
					IsThreeState: "True",
					IsTabStop: "False",
					"aria-hidden": "true"
				})]),
				_: 1
			}, 8, ["Node"]), C.isPrimaryMultiDragRow(e) ? (u(), a("span", b, p(C.dragItemCount), 1)) : i("", !0)], 40, y)) : i("", !0),
			o("div", {
				class: c(["win-tree-chevron", { "multi-select": C.selectionMode === "Multiple" }]),
				style: l({ opacity: +!!e.hasChildren }),
				onPointerdown: g((t) => C.onChevronPointerDown(t, e), ["stop"])
			}, [o("span", {
				class: c(["win-tree-glyph", { hidden: e.isExpanded }]),
				style: l(C.glyphStyle(e))
			}, p(C.collapsedGlyph(e)), 7), o("span", {
				class: c(["win-tree-glyph", { hidden: !e.isExpanded }]),
				style: l(C.glyphStyle(e))
			}, p(C.expandedGlyph(e)), 7)], 46, x),
			o("div", {
				class: "win-tree-item-content",
				style: l(C.contentStyle(e))
			}, [(u(), r(f(C.itemComponent(e))))], 4)
		], 6)], 6)], 46, v))), 128))], 38)]),
		_: 1
	})], 46, _)), [[C.vAcrylicBrush, C.backgroundStyle]]);
}
var C = /*#__PURE__*/ e(t, [["render", S], ["__file", "TreeView.vue"]]);
//#endregion
export { C as default };

//# sourceMappingURL=TreeView.vue.js.map