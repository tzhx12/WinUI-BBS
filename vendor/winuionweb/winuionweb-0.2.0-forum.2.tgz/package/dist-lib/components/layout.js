import { nextTick as e, onBeforeUnmount as t, onMounted as n, onUpdated as r } from "vue";
//#region src/components/layout.ts
var i = Symbol("winui-grid-definitions"), a = Symbol("winui-grid-definition-target"), o = (e) => {
	if (e === "" || e == null) return "";
	if (typeof e == "number" && Number.isFinite(e)) return `${e}px`;
	let t = String(e).trim();
	return t ? Number.isFinite(Number(t)) ? `${Number(t)}px` : t : "";
}, s = (e) => {
	if (e === "" || e == null) return "";
	let t = String(e).split(",").map((e) => o(e.trim()));
	return t.length === 1 ? t[0] : t.length === 2 ? `${t[1]} ${t[0]}` : t.length === 4 ? `${t[1]} ${t[2]} ${t[3]} ${t[0]}` : String(e);
}, c = (e, t) => {
	let n = String(e ?? "");
	return t === "horizontal" ? {
		Left: "start",
		Center: "center",
		Right: "end",
		Stretch: "stretch"
	}[n] ?? "" : {
		Top: "start",
		Center: "center",
		Bottom: "end",
		Stretch: "stretch"
	}[n] ?? "";
}, l = (e) => typeof e == "boolean" ? e : /^(true|1|yes)$/i.test(String(e ?? "").trim()), u = (e, t) => {
	let n = t.toLowerCase();
	return e.getAttributeNames().find((e) => e.toLowerCase() === n);
}, d = (e, t) => {
	let n = u(e, t);
	return n === void 0 ? void 0 : e.getAttribute(n) ?? "";
}, f = (e, t, n) => {
	let r = Number(d(e, t));
	return Number.isFinite(r) ? Math.max(0, Math.floor(r)) : n;
}, p = (e, t, n = 1) => Math.max(1, f(e, t, n)), m = (e, t, n) => {
	e.style[t] = n === null || n === "" ? "" : String(n);
}, h = (e) => {
	let t = d(e, "Width"), n = d(e, "Height"), r = d(e, "MinWidth"), i = d(e, "MaxWidth"), a = d(e, "MinHeight"), c = d(e, "MaxHeight"), l = d(e, "Margin"), u = d(e, "Padding");
	t !== void 0 && m(e, "width", o(t)), n !== void 0 && m(e, "height", o(n)), r !== void 0 && m(e, "minWidth", o(r)), i !== void 0 && m(e, "maxWidth", o(i)), a !== void 0 && m(e, "minHeight", o(a)), c !== void 0 && m(e, "maxHeight", o(c)), l !== void 0 && m(e, "margin", s(l)), u !== void 0 && m(e, "padding", s(u));
}, g = /* @__PURE__ */ new WeakMap(), _ = /* @__PURE__ */ new WeakMap(), v = (e, t, n) => {
	for (let r of Array.from(e.children)) {
		let e = r;
		if (e.classList.contains("win-acrylic-visual") || e.classList.contains("win-radial-gradient-background") || e.classList.contains("win-theme-shadow-visual")) continue;
		let i = _.get(e);
		for (let t of Object.keys(i ?? {})) {
			let n = i?.[t];
			n && e.style[t] === n.applied && (e.style[t] = n.previous);
		}
		let a = {}, o = (t, n) => {
			a[t] = {
				previous: e.style[t],
				applied: n
			}, e.style[t] = n;
		};
		h(e);
		for (let [r, i, a, s, l] of [[
			"horizontal",
			t,
			"justifySelf",
			"width",
			"MaxWidth"
		], [
			"vertical",
			n,
			"alignSelf",
			"height",
			"MaxHeight"
		]]) {
			let t = d(e, r === "horizontal" ? "HorizontalAlignment" : "VerticalAlignment"), n = t ? c(t, r) : e.style[a] || "stretch", u = c(i, r);
			if (o(a, u === "stretch" ? n : u), u === "stretch" && n === "stretch") {
				let t = e.style[s], n = d(e, l) ?? e.style[r === "horizontal" ? "maxWidth" : "maxHeight"];
				t && t !== "100%" && t !== "auto" ? o(a, "center") : n && n !== "none" && n !== "100%" && n !== "Infinity" && (o(s, "100%"), o(a, "center"));
			}
		}
		_.set(e, a);
	}
}, y = (e) => {
	Array.from(e.children).forEach((e) => {
		let t = e;
		if (t.classList.contains("win-acrylic-visual") || t.classList.contains("win-radial-gradient-background") || t.classList.contains("win-theme-shadow-visual")) return;
		h(t);
		let n = d(t, "Canvas.ZIndex"), r = g.get(t);
		if (n !== void 0) {
			let e = Number(n), i = String(Number.isFinite(e) ? Math.trunc(e) : 0);
			g.set(t, {
				previousInline: r?.previousInline ?? t.style.zIndex,
				lastApplied: i
			}), t.style.zIndex !== i && (t.style.zIndex = i);
		} else r && (t.style.zIndex === r.lastApplied && (t.style.zIndex = r.previousInline), g.delete(t));
		let i = d(t, "Grid.Row"), a = d(t, "Grid.Column"), o = d(t, "Grid.RowSpan"), s = d(t, "Grid.ColumnSpan");
		i !== void 0 || o !== void 0 ? m(t, "gridRow", `${f(t, "Grid.Row", 0) + 1} / span ${p(t, "Grid.RowSpan")}`) : m(t, "gridRow", `1 / span ${p(t, "Grid.RowSpan")}`), a !== void 0 || s !== void 0 ? m(t, "gridColumn", `${f(t, "Grid.Column", 0) + 1} / span ${p(t, "Grid.ColumnSpan")}`) : m(t, "gridColumn", `1 / span ${p(t, "Grid.ColumnSpan")}`);
		let l = d(t, "HorizontalAlignment"), u = d(t, "VerticalAlignment");
		l !== void 0 && m(t, "justifySelf", c(l, "horizontal")), u !== void 0 && m(t, "alignSelf", c(u, "vertical"));
	});
}, b = (e, t) => {
	let n = t === "Horizontal";
	Array.from(e.children).forEach((e) => {
		let t = e;
		if (t.classList.contains("win-acrylic-visual") || t.classList.contains("win-radial-gradient-background") || t.classList.contains("win-theme-shadow-visual")) return;
		h(t);
		let r = d(t, n ? "data-stack-panel-vertical-alignment" : "data-stack-panel-horizontal-alignment") ?? d(t, n ? "VerticalAlignment" : "HorizontalAlignment");
		if (r === void 0) {
			t.removeAttribute("data-stack-panel-cross-alignment");
			return;
		}
		let i = d(t, n ? "data-stack-panel-height" : "data-stack-panel-width") ?? d(t, n ? "Height" : "Width"), a = n ? t.style.height : t.style.width, o = i !== void 0 && i !== "" ? !/^(Auto|NaN|Infinity)$/i.test(i) : /^\d+(?:\.\d+)?px$/.test(a), s = r === "Stretch" && o ? "center" : c(r, n ? "vertical" : "horizontal");
		m(t, "alignSelf", s), t.setAttribute("data-stack-panel-cross-alignment", s);
	});
}, x = (i, a) => {
	let o, s, c = () => void e(a);
	n(() => {
		c(), i.value && (o = new MutationObserver(c), o.observe(i.value, {
			childList: !0,
			subtree: !0,
			attributes: !0,
			attributeFilter: (/* @__PURE__ */ "Grid.Row,Grid.Column,Grid.RowSpan,Grid.ColumnSpan,Canvas.Left,Canvas.Top,Canvas.ZIndex,VariableSizedWrapGrid.RowSpan,VariableSizedWrapGrid.ColumnSpan,RelativePanel.LeftOf,RelativePanel.RightOf,RelativePanel.Above,RelativePanel.Below,RelativePanel.AlignHorizontalCenterWith,RelativePanel.AlignVerticalCenterWith,RelativePanel.AlignLeftWith,RelativePanel.AlignTopWith,RelativePanel.AlignRightWith,RelativePanel.AlignBottomWith,RelativePanel.AlignLeftWithPanel,RelativePanel.AlignTopWithPanel,RelativePanel.AlignRightWithPanel,RelativePanel.AlignBottomWithPanel,RelativePanel.AlignHorizontalCenterWithPanel,RelativePanel.AlignVerticalCenterWithPanel,HorizontalAlignment,VerticalAlignment,Width,Height,MinWidth,MaxWidth,MinHeight,MaxHeight,Margin,Padding,data-stack-panel-horizontal-alignment,data-stack-panel-vertical-alignment,data-stack-panel-width,data-stack-panel-height,data-xaml-ref,x:name,x:Name".split(",")).flatMap((e) => [e, e.toLowerCase()])
		}), typeof ResizeObserver < "u" && (s = new ResizeObserver(c), s.observe(i.value)));
	}), r(c), t(() => {
		o?.disconnect(), s?.disconnect();
	});
};
//#endregion
export { c as alignment, v as applyContentPresenterChildren, y as applyGridChildren, b as applyStackChildren, d as attachedValue, l as boolValue, o as cssLength, i as gridDefinitionContextKey, a as gridDefinitionTargetKey, x as useLayoutObserver, s as xamlThickness };

//# sourceMappingURL=layout.js.map