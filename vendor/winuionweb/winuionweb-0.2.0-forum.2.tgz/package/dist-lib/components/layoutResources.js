import { cloneXamlVNodeWithDefaults as e } from "./xamlRuntime.js";
import { Fragment as t } from "vue";
//#region src/components/layoutResources.ts
var n = (e) => Array.isArray(e.children) ? e.children : e.children?.default?.() ?? [], r = (r, i) => {
	let a = [], o = [], s = (e) => {
		for (let r of e) r.type === t ? s(n(r)) : r.type?.[i] ? a.push(...n(r)) : o.push(r);
	};
	return s(r), o.map((t) => {
		let r = t.type, i = r.name ?? r.__name, o = {};
		for (let e of a) if (!(e.props?.["x:Key"] || e.props?.TargetType !== i)) for (let t of n(e)) {
			let e = t.props?.Property;
			typeof e == "string" && (o[e] = t.props?.Value);
		}
		return Object.keys(o).length ? e(t, o) : t;
	});
};
//#endregion
export { r as layoutResourceChildren };

//# sourceMappingURL=layoutResources.js.map