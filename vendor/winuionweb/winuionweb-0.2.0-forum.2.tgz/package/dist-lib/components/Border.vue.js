import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./Border.vue_vue_type_script_setup_true_lang.js";
/* empty css                                           */
import { createBlock as n, createCommentVNode as r, createElementBlock as i, createVNode as a, mergeProps as o, normalizeStyle as s, openBlock as c, withDirectives as l } from "vue";
//#region src/components/Border.vue
var u = {
	key: 1,
	class: "win-border-content"
};
function d(e, t, d, f, p, m) {
	return l((c(), i("div", o({ ref: "root" }, f.attrs, {
		class: ["win-border", { "has-theme-shadow": f.hasThemeShadow }],
		style: [f.attrs.style, f.resolveBorderStyle()]
	}), [
		a(f.ShadowOutlet),
		f.hasThemeShadow ? (c(), i("div", {
			key: 0,
			class: "win-theme-shadow-visual",
			"aria-hidden": "true",
			style: s(f.shadowVisualStyle)
		}, null, 4)) : r("", !0),
		f.hasThemeShadow ? (c(), i("div", u, [a(f.ChildOutlet)])) : (c(), n(f.ChildOutlet, { key: 2 }))
	], 16)), [[f.vAcrylicBrush, f.resolveBorderStyle()], [f.vRadialGradientBrush, f.backgroundBrush.value.value]]);
}
var f = /*#__PURE__*/ e(t, [["render", d], ["__file", "Border.vue"]]);
//#endregion
export { f as default };

//# sourceMappingURL=Border.vue.js.map