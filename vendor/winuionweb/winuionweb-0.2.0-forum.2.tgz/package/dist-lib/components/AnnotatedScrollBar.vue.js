import { useAcrylicBrushStyle as e } from "./AcrylicBrush.js";
import { vAcrylicBrush as t } from "./acrylicBrushVisual.js";
import { vThemeShadow as n } from "./themeShadowVisual.js";
import r from "../_virtual/_plugin-vue_export-helper.js";
import { isHoverPointer as i } from "./pointerInput.js";
/* empty css                                                                       */
import { Fragment as a, Transition as o, computed as s, createCommentVNode as c, createElementBlock as l, createElementVNode as u, createVNode as d, getCurrentInstance as f, normalizeClass as p, normalizeStyle as m, onBeforeUnmount as h, onMounted as g, openBlock as _, ref as v, renderList as y, toDisplayString as b, watch as x, withCtx as S, withDirectives as C, withModifiers as w } from "vue";
//#region src/components/AnnotatedScrollBar.vue
var T = {
	__name: "AnnotatedScrollBar",
	props: {
		Labels: {
			type: Array,
			default: () => []
		},
		ScrollController: {
			type: Object,
			default: null
		},
		MaxHeight: {
			type: Number,
			default: NaN
		},
		HorizontalAlignment: {
			type: String,
			default: "Stretch",
			validator: (e) => [
				"Left",
				"Center",
				"Right",
				"Stretch"
			].includes(e)
		},
		disabled: {
			type: Boolean,
			default: !1
		}
	},
	emits: ["DetailLabelRequested", "scrollOffsetChanged"],
	setup(r, { expose: a, emit: o }) {
		let c = e("{ThemeResource ToolTipBackgroundBrush}", f()), l = r, u = o, d = v(null), p = v(null), m = v(null), _ = v(null), y = v(!1), b = v(!1), S = v(!1), C = v(""), w = v(0), T = v({
			isDragging: !1,
			startY: 0,
			startScrollOffset: 0
		}), E = s(() => ({
			"is-disabled": l.disabled,
			"is-pointer-over": y.value && !l.disabled,
			"is-pressed": b.value && !l.disabled
		})), D = s(() => {
			let e = {};
			switch (isNaN(l.MaxHeight) || (e.maxHeight = `${l.MaxHeight}px`), l.HorizontalAlignment) {
				case "Left":
					e.alignSelf = "flex-start";
					break;
				case "Center":
					e.alignSelf = "center";
					break;
				case "Right":
					e.alignSelf = "flex-end";
					break;
				default:
					e.alignSelf = "stretch";
					break;
			}
			return e;
		}), O = s(() => {
			if (!l.ScrollController) return 0;
			let { scrollOffset: e = 0, maxScrollOffset: t = 1 } = l.ScrollController;
			return t === 0 ? 0 : Math.max(0, Math.min(1, e / t));
		}), k = s(() => {
			if (!l.ScrollController || !p.value) return {
				height: "0px",
				transform: "translateY(0px)"
			};
			let { viewport: e = 100, maxScrollOffset: t = 0 } = l.ScrollController, n = e + t, r = p.value.clientHeight, i = Math.max(40, e / n * r), a = r - i, o = O.value * a;
			return {
				height: `${i}px`,
				transform: `translateY(${o}px)`
			};
		}), A = s(() => {
			if (!l.Labels || l.Labels.length === 0) return [];
			let e = p.value?.clientHeight || 0;
			return e === 0 ? l.Labels : !isNaN(l.MaxHeight) && e < l.MaxHeight ? j(l.Labels, e) : l.Labels;
		}), j = (e, t) => {
			let n = [...e].sort((e, t) => e.offset - t.offset), r = [], i = -20;
			for (let e of n) {
				let n = e.offset / 100 * t;
				n - i >= 24 && (r.push(e), i = n);
			}
			return r;
		}, M = (e) => {
			let t = p.value?.clientHeight || 0;
			return { top: `${e.offset / 100 * t}px` };
		}, N = s(() => {
			let e = p.value?.clientHeight || 0, t = w.value / 100 * e;
			return { top: `${Math.max(10, Math.min(e - 30, t))}px` };
		}), P = (e) => {
			i(e) && (l.disabled || (y.value = !0));
		}, F = (e) => {
			i(e) || (y.value = !1);
		}, I = () => {
			y.value = !1, S.value = !1;
		}, L = (e) => {
			if (!i(e)) {
				S.value = !1;
				return;
			}
			if (l.disabled || !p.value) return;
			let t = p.value.getBoundingClientRect(), n = t.height, r = e.clientY - t.top, a = Math.max(0, Math.min(1, r / n)), o = {
				ScrollOffset: a * (l.ScrollController?.maxScrollOffset || 0),
				Content: null
			};
			u("DetailLabelRequested", o), o.Content ? (C.value = o.Content, w.value = a * 100, S.value = !0) : S.value = !1;
		}, R = (e) => {
			if (l.disabled || !p.value || !l.ScrollController) return;
			let t = p.value.getBoundingClientRect(), n = t.height, r = e.clientY - t.top;
			u("scrollOffsetChanged", Math.max(0, Math.min(1, r / n)) * (l.ScrollController.maxScrollOffset || 0));
		}, z = (e) => {
			if (l.disabled || !l.ScrollController) return;
			let t = l.ScrollController.maxScrollOffset || 0;
			u("scrollOffsetChanged", e.offset / 100 * t);
		}, B = (e) => {
			l.disabled || !l.ScrollController || (e.preventDefault(), b.value = !0, T.value = {
				isDragging: !0,
				startY: e.clientY,
				startScrollOffset: l.ScrollController.scrollOffset || 0
			}, document.addEventListener("mousemove", V), document.addEventListener("mouseup", H));
		}, V = (e) => {
			if (!T.value.isDragging || !p.value || !l.ScrollController) return;
			let t = e.clientY - T.value.startY, n = p.value.clientHeight - (_.value?.clientHeight || 0), r = l.ScrollController.maxScrollOffset || 0, i = t / n * r;
			u("scrollOffsetChanged", Math.max(0, Math.min(r, T.value.startScrollOffset + i)));
		}, H = () => {
			b.value = !1, T.value.isDragging = !1, document.removeEventListener("mousemove", V), document.removeEventListener("mouseup", H);
		};
		h(() => {
			document.removeEventListener("mousemove", V), document.removeEventListener("mouseup", H);
		}), a({
			scrollTo: (e) => {
				u("scrollOffsetChanged", e);
			},
			getScrollOffset: () => l.ScrollController?.scrollOffset || 0,
			getMaxScrollOffset: () => l.ScrollController?.maxScrollOffset || 0
		});
		let U = {
			detailBackgroundStyle: c,
			props: l,
			emit: u,
			containerRef: d,
			railRef: p,
			labelsRef: m,
			thumbRef: _,
			isPointerOver: y,
			isPressed: b,
			showDetailLabel: S,
			detailLabelContent: C,
			detailLabelOffset: w,
			dragState: T,
			stateClasses: E,
			containerStyle: D,
			scrollRatio: O,
			thumbStyle: k,
			visibleLabels: A,
			calculateVisibleLabels: j,
			getLabelStyle: M,
			detailLabelStyle: N,
			handlePointerEnter: P,
			handlePointerDown: F,
			handleMouseLeave: I,
			handleRailMove: L,
			handleRailClick: R,
			handleLabelClick: z,
			handleThumbMouseDown: B,
			handleThumbMouseMove: V,
			handleThumbMouseUp: H,
			ref: v,
			computed: s,
			getCurrentInstance: f,
			watch: x,
			onMounted: g,
			onBeforeUnmount: h,
			get useAcrylicBrushStyle() {
				return e;
			},
			get vAcrylicBrush() {
				return t;
			},
			get vThemeShadow() {
				return n;
			},
			get isHoverPointer() {
				return i;
			}
		};
		return Object.defineProperty(U, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), U;
	}
}, E = {
	class: "scrollbar-labels",
	ref: "labelsRef"
}, D = ["onClick"], O = { class: "detail-label-content" };
function k(e, t, n, r, i, s) {
	return _(), l("div", {
		class: p(["win-annotated-scrollbar", r.stateClasses]),
		style: m(r.containerStyle),
		ref: "containerRef",
		onPointerenter: r.handlePointerEnter,
		onPointerleave: r.handleMouseLeave,
		onPointerdown: r.handlePointerDown
	}, [u("div", {
		class: "scrollbar-rail",
		ref: "railRef",
		onClick: r.handleRailClick,
		onPointermove: r.handleRailMove
	}, [u("div", E, [(_(!0), l(a, null, y(r.visibleLabels, (e, t) => (_(), l("div", {
		key: t,
		class: "scrollbar-label",
		style: m(r.getLabelStyle(e)),
		onClick: w((t) => r.handleLabelClick(e), ["stop"])
	}, b(e.text), 13, D))), 128))], 512), u("div", {
		class: "scrollbar-thumb",
		style: m(r.thumbStyle),
		ref: "thumbRef",
		onMousedown: r.handleThumbMouseDown
	}, null, 36)], 544), d(o, { name: "detail-fade" }, {
		default: S(() => [r.showDetailLabel && r.detailLabelContent ? C((_(), l("div", {
			key: 0,
			class: "detail-label",
			style: m([r.detailLabelStyle, r.detailBackgroundStyle])
		}, [u("span", O, b(r.detailLabelContent), 1)], 4)), [[
			r.vAcrylicBrush,
			r.detailBackgroundStyle,
			void 0,
			{ "host-backdrop": !0 }
		], [r.vThemeShadow, { Translation: 16 }]]) : c("", !0)]),
		_: 1
	})], 38);
}
var A = /*#__PURE__*/ r(T, [
	["render", k],
	["__scopeId", "data-v-c6edfcb4"],
	["__file", "AnnotatedScrollBar.vue"]
]);
//#endregion
export { A as default };

//# sourceMappingURL=AnnotatedScrollBar.vue.js.map