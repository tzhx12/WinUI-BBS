import { alignment as e, cssLength as t, xamlThickness as n } from "./layout.js";
import { primitiveResourceScope as r, xamlPrimitiveResourceKey as i } from "./xamlPrimitives.js";
import { normalizeXamlNodes as a, resolveXamlValue as o } from "./xamlRuntime.js";
import { layoutResourceChildren as s } from "./layoutResources.js";
import { getVNodeChildren as c } from "./CollectionProperties.js";
import { arrangeRelativePanel as l, relativePanelStyleChanged as u } from "./relativePanelLayout.js";
import { Fragment as d, computed as f, defineComponent as p, getCurrentInstance as m, h, inject as g, nextTick as _, onBeforeUnmount as v, onMounted as y, onUpdated as b, provide as x, ref as S, useSlots as C } from "vue";
//#region src/components/RelativePanel.vue?vue&type=script&setup=true&lang.ts
var w = p({
	name: "RelativePanel.Resources",
	__relativePanelResources: !0,
	setup: () => () => null
}), T = /*@__PURE__*/ p({
	Resources: w,
	__name: "RelativePanel",
	props: {
		Width: {
			type: [String, Number],
			default: ""
		},
		Height: {
			type: [String, Number],
			default: ""
		},
		MinWidth: {
			type: [String, Number],
			default: ""
		},
		MinHeight: {
			type: [String, Number],
			default: ""
		},
		MaxWidth: {
			type: [String, Number],
			default: ""
		},
		MaxHeight: {
			type: [String, Number],
			default: ""
		},
		Background: {
			type: String,
			default: ""
		},
		BackgroundSizing: {
			type: String,
			default: "InnerBorderEdge"
		},
		BorderBrush: {
			type: String,
			default: ""
		},
		BorderThickness: {
			type: [String, Number],
			default: 0
		},
		CornerRadius: {
			type: [String, Number],
			default: 0
		},
		Padding: {
			type: [String, Number],
			default: 0
		},
		Margin: {
			type: [String, Number],
			default: 0
		},
		HorizontalAlignment: {
			type: String,
			default: "Stretch"
		},
		VerticalAlignment: {
			type: String,
			default: "Stretch"
		},
		Visibility: {
			type: String,
			default: "Visible"
		}
	},
	setup(T, { expose: E }) {
		E();
		let D = T, O = m(), k = C();
		x(i, r(() => k.default?.() ?? [], g(i, null)));
		let A = () => (k.default?.() ?? []).map((e) => {
			if (!e.type?.__relativePanelResources) return e;
			let t = (e) => e.flatMap((e) => e.type?.__xamlResourceDictionary ? t(c(e)) : [e]);
			return h(w, null, { default: () => t(c(e)) });
		}), j = p({
			name: "RelativePanelChildrenOutlet",
			setup() {
				return () => h(d, a(s(A(), "__relativePanelResources"), O));
			}
		}), M = f(() => Object.fromEntries(Object.entries(D).map(([e, t]) => [e, o(t, O)]))), N = S(null), P = S({
			width: 0,
			height: 0
		}), F = (e) => e !== "" && e !== void 0 && !/^(auto|nan)$/i.test(String(e)), I = (e) => {
			let n = String(e).split(",").map((e) => t(e.trim()));
			return n.length === 4 ? n.join(" ") : t(e);
		}, L = f(() => {
			let r = {}, i = M.value;
			F(i.Width) && (r.flex = "0 0 auto");
			for (let [e, n] of Object.entries({
				Width: i.Width,
				Height: i.Height,
				MinWidth: i.MinWidth,
				MinHeight: i.MinHeight,
				MaxWidth: i.MaxWidth,
				MaxHeight: i.MaxHeight
			})) F(n) && (r[e.charAt(0).toLowerCase() + e.slice(1)] = t(n));
			return F(i.Height) || (r.minHeight = `${Math.max(Number(i.MinHeight) || 0, P.value.height)}px`), !F(i.Width) && i.HorizontalAlignment !== "Stretch" && (r.width = `${P.value.width}px`), r.background = i.Background || "transparent", r.backgroundClip = i.BackgroundSizing === "OuterBorderEdge" ? "border-box" : "padding-box", r.borderColor = i.BorderBrush || "transparent", r.borderWidth = n(i.BorderThickness), r.borderStyle = "solid", r.borderRadius = I(i.CornerRadius), r.padding = n(i.Padding), r.margin = n(i.Margin), r.justifySelf = e(i.HorizontalAlignment, "horizontal"), r.alignSelf = e(i.VerticalAlignment, "vertical"), i.HorizontalAlignment === "Center" ? r.marginInline = "auto" : i.HorizontalAlignment === "Right" && (r.marginLeft = "auto"), i.Visibility === "Collapsed" && (r.display = "none"), r;
		}), R, z, B = !1, V = !1, H = () => {
			B || V || (B = !0, _(() => {
				if (B = !1, !N.value || V) return;
				if (z) for (let e of Array.from(N.value.children)) z.observe(e);
				let e = l(N.value, {
					autoWidth: !F(M.value.Width) && M.value.HorizontalAlignment !== "Stretch",
					autoHeight: !F(M.value.Height),
					minimumHeight: Math.max(0, Number(M.value.MinHeight) || 0)
				});
				(Math.abs(e.width - P.value.width) > .01 || Math.abs(e.height - P.value.height) > .01) && (P.value = e);
			}));
		};
		y(() => {
			if (N.value) {
				R = new MutationObserver((e) => {
					e.some((e) => e.type !== "attributes" || e.attributeName !== "style" || e.target !== N.value && u(e.target)) && H();
				}), R.observe(N.value, {
					childList: !0,
					subtree: !0,
					attributes: !0,
					characterData: !0
				}), z = new ResizeObserver(H), z.observe(N.value);
				for (let e of Array.from(N.value.children)) z.observe(e);
				H();
			}
		}), b(() => {
			if (N.value && z) for (let e of Array.from(N.value.children)) z.observe(e);
			H();
		}), v(() => {
			V = !0, R?.disconnect(), z?.disconnect();
		});
		let U = {
			RelativePanelResources: w,
			rawProps: D,
			instance: O,
			slots: k,
			resourceChildren: A,
			ChildrenOutlet: j,
			props: M,
			root: N,
			desiredSize: P,
			hasLength: F,
			cornerRadius: I,
			rootStyle: L,
			get mutationObserver() {
				return R;
			},
			set mutationObserver(e) {
				R = e;
			},
			get resizeObserver() {
				return z;
			},
			set resizeObserver(e) {
				z = e;
			},
			get queued() {
				return B;
			},
			set queued(e) {
				B = e;
			},
			get disposed() {
				return V;
			},
			set disposed(e) {
				V = e;
			},
			update: H
		};
		return Object.defineProperty(U, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), U;
	}
});
//#endregion
export { w as RelativePanelResources, T as default };

//# sourceMappingURL=RelativePanel.vue_vue_type_script_setup_true_lang.js.map