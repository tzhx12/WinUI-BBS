import { Comment as e, Fragment as t, Text as n, defineComponent as r, h as i } from "vue";
//#region src/components/RefreshProperties.ts
var a = (e) => r({
	name: `RefreshContainer.${e[0].toUpperCase()}${e.slice(1)}`,
	__refreshContainerProperty: e,
	setup(e, { slots: n }) {
		return () => i(t, n.default?.());
	}
}), o = (e) => r({
	name: `RefreshVisualizer.${e[0].toUpperCase()}${e.slice(1)}`,
	__refreshVisualizerProperty: e,
	setup(e, { slots: n }) {
		return () => i(t, n.default?.());
	}
}), s = a("visualizer"), c = a("content"), l = o("content"), u = (r) => r.flatMap((r) => r.type === e || r.type === n && !String(r.children ?? "").trim() ? [] : r.type === t && Array.isArray(r.children) ? u(r.children) : [r]), d = (e) => {
	if (Array.isArray(e.children)) return u(e.children);
	let t = e.children;
	return u(t?.default?.() ?? []);
}, f = (e) => e.type?.__refreshContainerProperty, p = (e) => e.type?.__refreshVisualizerProperty;
//#endregion
export { c as RefreshContainerContent, s as RefreshContainerVisualizer, l as RefreshVisualizerContent, f as getRefreshContainerProperty, p as getRefreshVisualizerProperty, d as refreshChildren, u as refreshNodes };

//# sourceMappingURL=RefreshProperties.js.map