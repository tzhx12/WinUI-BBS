//#region src/components/appBarResources.ts
var e = (e) => `var(--${e})`, t = {
	AppBarThemeMinHeight: 64,
	AppBarThemeCompactHeight: 48,
	AppBarButtonContentHeight: 16,
	AppBarButtonContentViewboxMargin: "12,16,0,10",
	AppBarButtonContentViewboxCompactMargin: "0,12,0,12",
	AppBarButtonContentViewboxCollapsedMargin: "0,16,0,2",
	AppBarButtonOverflowTextTouchMargin: "0,9,0,12",
	AppBarButtonOverflowTextLabelPadding: "0,5,0,8",
	AppBarButtonTextLabelMargin: "2,0,2,8",
	AppBarButtonTextLabelOnRightMargin: "8,16,12,10",
	AppBarButtonInnerBorderMargin: "2,6,2,6",
	AppBarButtonInnerBorderCompactMargin: "2,6,2,22",
	AppBarButtonInnerBorderOverflowMargin: "4,0,4,0",
	AppBarButtonHasFlyoutChevronVisibility: "Visible",
	AppBarButtonFlyoutGlyph: "",
	AppBarButtonOverflowFlyoutGlyph: "",
	AppBarButtonSubItemChevronFontSize: 8,
	AppBarButtonSecondarySubItemChevronFontSize: 12,
	AppBarButtonSubItemChevronMargin: "-23,20,12,0",
	AppBarButtonSubItemChevronLabelOnRightMargin: "-7,20,12,0",
	AppBarButtonSecondarySubItemChevronMargin: "0,0,16,0",
	AppBarToggleButtonBorderThemeThickness: "1",
	AppBarToggleButtonOverflowTextTouchMargin: "0,9,0,12",
	AppBarToggleButtonOverflowCheckTouchMargin: "12,10,12,10",
	AppBarToggleButtonOverflowCheckMargin: "12,4,12,4",
	AppBarToggleButtonTextLabelMargin: "2,0,2,8",
	AppBarToggleButtonTextLabelOnRightMargin: "8,16,12,10",
	AppBarToggleButtonOverflowTextLabelPadding: "0,5,0,8",
	AppBarSeparatorMargin: "2,8,2,8",
	AppBarOverflowSeparatorMargin: "0,4,0,4",
	AppBarSeparatorWidth: 1,
	AppBarOverflowSeparatorHeight: 1,
	AppBarSeparatorCornerRadius: .5,
	AppBarSeparatorForeground: e("DividerStrokeColorDefaultBrush")
};
for (let n of ["AppBarButton", "AppBarToggleButton"]) for (let [r, i, a] of [
	[
		"",
		"SubtleFillColorTransparentBrush",
		"TextFillColorPrimaryBrush"
	],
	[
		"PointerOver",
		"SubtleFillColorSecondaryBrush",
		"TextFillColorPrimaryBrush"
	],
	[
		"Pressed",
		"SubtleFillColorTertiaryBrush",
		"TextFillColorSecondaryBrush"
	],
	[
		"Disabled",
		"SubtleFillColorDisabledBrush",
		"TextFillColorDisabledBrush"
	]
]) t[`${n}Background${r}`] = e(i), t[`${n}Foreground${r}`] = e(a), t[`${n}BorderBrush${r}`] = e("ControlFillColorTransparentBrush"), t[`${n}KeyboardAcceleratorTextForeground${r}`] = e(r === "Disabled" ? "TextFillColorDisabledBrush" : r === "Pressed" ? "TextFillColorTertiaryBrush" : "TextFillColorSecondaryBrush");
for (let [n, r, i] of [
	[
		"",
		"AccentFillColorDefaultBrush",
		"TextOnAccentFillColorPrimaryBrush"
	],
	[
		"PointerOver",
		"AccentFillColorSecondaryBrush",
		"TextOnAccentFillColorPrimaryBrush"
	],
	[
		"Pressed",
		"AccentFillColorTertiaryBrush",
		"TextOnAccentFillColorSecondaryBrush"
	],
	[
		"Disabled",
		"AccentFillColorDisabledBrush",
		"TextOnAccentFillColorDisabled"
	]
]) t[`AppBarToggleButtonBackgroundChecked${n}`] = e(r), t[`AppBarToggleButtonForegroundChecked${n}`] = e(i), t[`AppBarToggleButtonBorderBrushChecked${n}`] = e(n === "Pressed" || n === "Disabled" ? "ControlFillColorTransparentBrush" : "AccentControlElevationBorderBrush"), t[`AppBarToggleButtonCheckGlyphForegroundChecked${n}`] = e(i), t[`AppBarToggleButtonKeyboardAcceleratorTextForegroundChecked${n}`] = e(n === "Disabled" ? "TextFillColorDisabledBrush" : n === "Pressed" ? "TextFillColorTertiaryBrush" : "TextFillColorSecondaryBrush");
for (let n of [
	"",
	"PointerOver",
	"Pressed",
	"Disabled",
	"SubMenuOpened"
]) t[`AppBarButtonSubItemChevronForeground${n}`] = e(n === "Disabled" ? "TextFillColorDisabledBrush" : n === "Pressed" ? "TextFillColorTertiaryBrush" : "TextFillColorSecondaryBrush");
for (let n of [
	"PointerOver",
	"Pressed",
	"Disabled"
]) {
	let r = n === "Disabled" ? "TextFillColorDisabledBrush" : n === "Pressed" ? "TextFillColorSecondaryBrush" : "TextFillColorPrimaryBrush";
	t[`AppBarToggleButtonOverflowLabelForeground${n}`] = e(r), t[`AppBarToggleButtonOverflowLabelForegroundChecked${n}`] = e(r), t[`AppBarToggleButtonCheckGlyphForeground${n}`] = e(r);
}
t.AppBarToggleButtonCheckGlyphForeground = e("TextFillColorPrimaryBrush");
for (let n of [
	"",
	"PointerOver",
	"Pressed",
	"CheckedPointerOver",
	"CheckedPressed"
]) t[`AppBarToggleButtonBackgroundHighLightOverlay${n}`] = e(n.endsWith("Pressed") ? "SubtleFillColorTertiaryBrush" : n.endsWith("PointerOver") ? "SubtleFillColorSecondaryBrush" : "SubtleFillColorTransparentBrush");
t.AppBarButtonBackgroundSubMenuOpened = e("SubtleFillColorSecondaryBrush"), t.AppBarButtonForegroundSubMenuOpened = e("TextFillColorPrimaryBrush"), t.AppBarButtonKeyboardAcceleratorTextForegroundSubMenuOpened = e("TextFillColorSecondaryBrush"), t.AppBarButtonBorderBrushSubMenuOpened = e("ControlFillColorTransparentBrush");
var n = Object.freeze(t);
//#endregion
export { n as appBarResources };

//# sourceMappingURL=appBarResources.js.map