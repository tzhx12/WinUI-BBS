import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./FlyoutAnimation.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                    */
import { createElementBlock as n, normalizeClass as r, openBlock as i, renderSlot as a } from "vue";
//#region src/components/FlyoutAnimation.vue
function o(e, t, o, s, c, l) {
	return i(), n("div", {
		ref: "rootRef",
		class: r(["win-flyout-animation", { "is-playing": s.isPlaying }])
	}, [a(e.$slots, "default")], 2);
}
var s = /*#__PURE__*/ e(t, [["render", o], ["__file", "FlyoutAnimation.vue"]]);
//#endregion
export { s as default };

//# sourceMappingURL=FlyoutAnimation.vue.js.map