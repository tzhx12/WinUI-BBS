import { alignment as e, cssLength as t, xamlThickness as n } from "./layout.js";
import { normalizeXamlNodes as r, resolveXamlHandler as i, resolveXamlValue as ee, updateXamlBinding as a, xamlScopeKey as o, xamlTemplateComponent as s } from "./xamlRuntime.js";
import te from "./Grid.vue.js";
import { useI18n as ne } from "./i18n/index.js";
import { xamlResourceDictionaryKey as re } from "./Page.vue_vue_type_script_lang.js";
import { getVNodeChildren as c } from "./CollectionProperties.js";
import ie from "./TextBlock.vue.js";
import ae from "./ContentPresenter.vue.js";
import oe from "./Button.vue.js";
import { calendarDateFromSerial as se, calendarDateSerial as l, parseCalendarDate as ce } from "./calendarEngine.js";
import le from "./ColumnDefinition.vue.js";
import ue from "./RowDefinition.vue.js";
import de from "./Rectangle.vue.js";
import fe from "./DateTimePickerFlyout.vue.js";
import { createDatePickerModel as pe } from "./datePickerEngine.js";
import { Fragment as u, computed as d, defineComponent as f, getCurrentInstance as me, h as p, inject as he, isVNode as m, nextTick as ge, onBeforeUnmount as _e, provide as ve, ref as h, unref as ye, useAttrs as be, useSlots as xe, watch as g } from "vue";
//#region src/components/DatePicker.vue?vue&type=script&setup=true&lang.ts
var _ = (e) => f({
	name: `DatePicker.${e}`,
	__datePickerProperty: e,
	setup(e, { slots: t }) {
		return () => p(u, t.default?.());
	}
}), v = /*@__PURE__*/ f({
	Header: _("Header"),
	HeaderTemplate: _("HeaderTemplate"),
	inheritAttrs: !1,
	__name: "DatePicker",
	props: {
		CalendarIdentifier: {
			type: String,
			default: "GregorianCalendar"
		},
		Date: {
			type: [globalThis.Date, String],
			default: void 0
		},
		SelectedDate: {
			type: [globalThis.Date, String],
			default: void 0
		},
		DayFormat: {
			type: String,
			default: "day.integer"
		},
		DayVisible: {
			type: [Boolean, String],
			default: !0
		},
		MonthFormat: {
			type: String,
			default: "month.full"
		},
		MonthVisible: {
			type: [Boolean, String],
			default: !0
		},
		YearFormat: {
			type: String,
			default: "year.full"
		},
		YearVisible: {
			type: [Boolean, String],
			default: !0
		},
		MinYear: {
			type: [globalThis.Date, String],
			default: () => new globalThis.Date(new globalThis.Date().getFullYear() - 100, 0, 1)
		},
		MaxYear: {
			type: [globalThis.Date, String],
			default: () => new globalThis.Date(new globalThis.Date().getFullYear() + 100, 11, 31)
		},
		Header: {
			type: null,
			default: null
		},
		HeaderTemplate: {
			type: null,
			default: null
		},
		Orientation: {
			type: String,
			default: "Horizontal"
		},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		Language: {
			type: String,
			default: ""
		},
		LightDismissOverlayMode: {
			type: String,
			default: "Auto"
		},
		RequestedTheme: {
			type: String,
			default: "Default"
		},
		Width: {
			type: [String, Number],
			default: ""
		},
		Height: {
			type: [String, Number],
			default: ""
		},
		MinWidth: {
			type: [String, Number],
			default: ""
		},
		MinHeight: {
			type: [String, Number],
			default: ""
		},
		MaxWidth: {
			type: [String, Number],
			default: ""
		},
		MaxHeight: {
			type: [String, Number],
			default: ""
		},
		Margin: {
			type: [String, Number],
			default: ""
		},
		Padding: {
			type: [String, Number],
			default: ""
		},
		HorizontalAlignment: {
			type: String,
			default: "Left"
		},
		VerticalAlignment: {
			type: String,
			default: "Center"
		},
		Visibility: {
			type: String,
			default: "Visible"
		},
		FontSize: {
			type: [String, Number],
			default: ""
		},
		FontFamily: {
			type: String,
			default: ""
		},
		FontWeight: {
			type: [String, Number],
			default: "Normal"
		},
		Background: {
			type: String,
			default: "{ThemeResource DatePickerButtonBackground}"
		},
		Foreground: {
			type: String,
			default: "{ThemeResource DatePickerButtonForeground}"
		},
		BorderBrush: {
			type: String,
			default: "{ThemeResource DatePickerButtonBorderBrush}"
		},
		BorderThickness: {
			type: [String, Number],
			default: 1
		},
		CornerRadius: {
			type: [String, Number],
			default: "{ThemeResource ControlCornerRadius}"
		}
	},
	emits: [
		"DateChanged",
		"SelectedDateChanged",
		"update:Date",
		"update:SelectedDate"
	],
	setup(v, { expose: Se, emit: Ce }) {
		let y = v, b = Ce, x = me(), S = be(), C = xe(), { t: w, locale: we } = ne(), Te = he("winuiTheme", null), T = he(re, null), E = h(null), Ee = h(null), D = h(null), O = h(null), k = () => new globalThis.Date(-0xa9730b66800), A = h(l(new globalThis.Date())), j = h(new globalThis.Date()), M = (e) => ee(e, x), N = d(() => M(y.IsEnabled) !== !1), P = d(() => String(M(y.Language) || we)), F = (e, t) => {
			let n = e instanceof globalThis.Date ? e : new globalThis.Date(String(e));
			return Number.isFinite(n.getTime()) ? n : t;
		}, I = d(() => pe(String(M(y.CalendarIdentifier)), P.value, F(M(y.MinYear), new globalThis.Date(new globalThis.Date().getFullYear() - 100, 0, 1)), F(M(y.MaxYear), new globalThis.Date(new globalThis.Date().getFullYear() + 100, 11, 31)))), L = d(() => ({
			day: String(M(y.DayFormat)),
			month: String(M(y.MonthFormat)),
			year: String(M(y.YearFormat))
		})), R = d(() => I.value.order.filter((e) => M(y[e === "day" ? "DayVisible" : e === "month" ? "MonthVisible" : "YearVisible"]) !== !1)), z = d(() => I.value.calendar.yearAt(A.value)), B = d(() => I.value.calendar.months.slice(z.value.firstMonth, z.value.lastMonth + 1)), V = d(() => I.value.calendar.monthAt(A.value)), H = d(() => Array.from({ length: V.value.end - V.value.start + 1 }, (e, t) => V.value.start + t)), U = d(() => ({
			year: I.value.years.map((e) => I.value.format(e.start, L.value.year, "year")),
			month: B.value.map((e) => I.value.format(e.start, L.value.month, "month")),
			day: H.value.map((e) => I.value.format(e, L.value.day, "day"))
		})), W = d(() => ({
			year: I.value.years.findIndex((e) => e.index === z.value.index),
			month: B.value.findIndex((e) => e.index === V.value.index),
			day: A.value - V.value.start
		})), G = d(() => R.value.map((e) => ({
			key: e,
			items: U.value[e],
			index: W.value[e],
			loop: e !== "year",
			weight: e === "month" ? 132 : 78,
			align: e === "month" ? "Left" : "Center",
			label: w(`datePicker.${e}`)
		}))), K = (e) => e ? O.value ? I.value.format(l(O.value), L.value[e], e) : w(`datePicker.${e}`) : "", De = d(() => ({ gridTemplateColumns: G.value.flatMap((e, t) => [t ? "1px" : "", `minmax(0, ${e.weight}fr)`]).filter(Boolean).join(" ") })), q = (e) => ({
			textAlign: R.value[e] === "month" ? "left" : "center",
			padding: R.value[e] === "month" ? "var(--DatePickerHostMonthPadding, 3px 0 6px 9px)" : "var(--DatePickerHostPadding, 3px 0 6px)",
			marginLeft: R.value[e] === "month" ? "1px" : "0"
		}), Oe = d(() => q(0)), ke = d(() => q(1)), Ae = d(() => q(2)), J = d(() => {
			let e = String(M(y.RequestedTheme)).toLowerCase();
			return e === "dark" || e === "light" ? e : String(ye(Te) || "Default").toLowerCase();
		}), Y = (e) => {
			let t = (n) => n.flatMap((n) => n.type === u && Array.isArray(n.children) ? t(n.children) : n.type?.__datePickerProperty === e ? c(n) : []);
			return t(C.default?.() ?? []);
		}, X = d(() => M(y.Header)), je = d(() => X.value !== null && X.value !== void 0 && X.value !== "" || Y("Header").length > 0 || Y("HeaderTemplate").length > 0 || !!y.HeaderTemplate), Me = f({ setup() {
			return () => {
				let e = Y("HeaderTemplate"), t = Y("Header"), n = typeof y.HeaderTemplate == "string" ? y.HeaderTemplate.match(/^\{StaticResource\s+([^\s}]+)\}$/)?.[1] : null;
				if (e.length) return s(e, X.value, x);
				if (n && T?.[n]) return s(c(T[n]), X.value, x);
				if (t.length) return p(u, r(t, x));
				let i = M(y.HeaderTemplate);
				return m(i) ? s([i], X.value, x) : m(X.value) ? X.value : String(X.value ?? "");
			};
		} }), Ne = d(() => ({
			"has-no-date": !O.value,
			"is-disabled": !N.value,
			"win-theme-scope": ["dark", "light"].includes(J.value),
			"theme-dark": J.value === "dark",
			"theme-light": J.value === "light"
		})), Pe = d(() => Object.fromEntries(Object.entries(S).filter(([e]) => ![
			"class",
			"style",
			"DateChanged",
			"SelectedDateChanged"
		].includes(e)))), Fe = d(() => {
			let r = {
				"--picker-background": M(y.Background),
				"--picker-foreground": M(y.Foreground),
				"--picker-border-thickness": n(M(y.BorderThickness)),
				"--picker-radius": t(M(y.CornerRadius)),
				margin: n(M(y.Margin)),
				padding: n(M(y.Padding)),
				alignSelf: e(M(y.VerticalAlignment), "vertical"),
				justifySelf: e(M(y.HorizontalAlignment), "horizontal"),
				fontSize: t(M(y.FontSize)),
				fontFamily: M(y.FontFamily) || void 0,
				fontWeight: M(y.FontWeight) === "Normal" ? 400 : M(y.FontWeight)
			};
			for (let e of [
				"Width",
				"Height",
				"MinWidth",
				"MinHeight",
				"MaxWidth",
				"MaxHeight"
			]) M(y[e]) !== "" && (r[e[0].toLowerCase() + e.slice(1)] = t(M(y[e])));
			return M(y.Visibility) === "Collapsed" && (r.display = "none"), M(y.Visibility) === "Hidden" && (r.visibility = "hidden"), [S.style, r];
		}), Z = (e, t) => {
			b(e, $, t), i(S[e], x)?.($, t);
		}, Q = (e, t = !0) => {
			let n = ce(e), r = n?.getTime() === k().getTime() ? null : I.value.coerce(n), i = O.value;
			r?.getTime() !== i?.getTime() && (O.value = r, a(y.Date, r ?? k(), x), a(y.SelectedDate, r, x), b("update:Date", r ?? k()), b("update:SelectedDate", r), t && (Z("DateChanged", {
				OldDate: i ?? k(),
				NewDate: r ?? k()
			}), Z("SelectedDateChanged", {
				OldDate: i,
				NewDate: r
			})));
		}, Ie = async () => {
			if (!N.value || !I.value.years.length) return;
			if (D.value?.IsOpen) {
				D.value.Hide();
				return;
			}
			j.value = I.value.coerce(O.value ?? new globalThis.Date()), A.value = l(j.value), await ge();
			let e = E.value?.querySelector(".picker-button");
			e && N.value && D.value?.ShowAt(e);
		}, Le = (e, t) => {
			if (t.Indices) {
				let e = t.Indices, n = e.year === void 0 ? z.value : I.value.years[e.year] ?? z.value, r = I.value.calendar.months.slice(n.firstMonth, n.lastMonth + 1), i = e.month === void 0 ? V.value : B.value[e.month] ?? V.value, ee = i.index - z.value.firstMonth, a = r.find((e) => e.month === i.month) ?? r[Math.min(ee, r.length - 1)], o = e.day === void 0 ? I.value.calendar.day(A.value) : I.value.calendar.day(H.value[e.day] ?? A.value);
				A.value = Math.min(a.end, a.start + Math.max(0, o - I.value.calendar.day(a.start)));
				return;
			}
			let n = t.SelectedIndex;
			if (t.Key === "day") {
				A.value = H.value[n] ?? A.value;
				return;
			}
			let r = I.value.calendar.day(A.value), i = V.value;
			if (t.Key === "month" && (i = B.value[n] ?? i), t.Key === "year") {
				let e = I.value.years[n];
				if (!e) return;
				let t = V.value.index - z.value.firstMonth, r = I.value.calendar.months.slice(e.firstMonth, e.lastMonth + 1);
				i = r.find((e) => e.month === V.value.month) ?? r[Math.min(t, r.length - 1)];
			}
			A.value = Math.min(i.end, i.start + r - I.value.calendar.day(i.start));
		}, Re = (e, t) => {
			if (!t.Accepted) return;
			let n = se(A.value), r = j.value;
			n.setHours(r.getHours(), r.getMinutes(), r.getSeconds(), r.getMilliseconds()), Q(n);
		};
		ve(o, {
			PickerEnabled: N,
			PickerColumns: G,
			PickerTheme: J,
			PickerOverlayMode: d(() => M(y.LightDismissOverlayMode)),
			PickerBorderBrush: d(() => M(y.BorderBrush)),
			PickerBorderThickness: d(() => M(y.BorderThickness)),
			PickerCornerRadius: d(() => M(y.CornerRadius)),
			PickerAutomationName: d(() => String(X.value || w("datePicker.name")) + " " + R.value.map(K).join(" ")),
			FirstText: d(() => K(R.value[0])),
			SecondText: d(() => K(R.value[1])),
			ThirdText: d(() => K(R.value[2])),
			OnFlyoutButtonClick: Ie,
			OnFlyoutSelectionChanged: Le,
			OnFlyoutClosed: Re
		});
		let $ = {
			Date: d({
				get: () => O.value ?? k(),
				set: (e) => Q(e)
			}),
			SelectedDate: d({
				get: () => O.value,
				set: (e) => Q(e)
			}),
			Focus: () => E.value?.querySelector(".picker-button")?.focus()
		};
		g([() => M(y.Date), () => M(y.SelectedDate)], ([e, t], n) => {
			Q(n.length ? t === n[1] ? e : t : t === void 0 ? e : t, n.length > 0);
		}, { immediate: !0 }), g(I, () => {
			Q(O.value), D.value?.IsOpen && (A.value = Math.max(I.value.minimum, Math.min(I.value.maximum, A.value)));
		}), g(N, (e) => {
			e || D.value?.Hide();
		}), _e(() => {
			D.value?.Hide();
		}), Se($);
		let ze = {
			property: _,
			props: y,
			emit: b,
			instance: x,
			attrs: S,
			slots: C,
			t: w,
			locale: we,
			inheritedTheme: Te,
			resources: T,
			rootRef: E,
			buttonRef: Ee,
			flyoutRef: D,
			localDate: O,
			nullDate: k,
			draft: A,
			draftBaseDate: j,
			value: M,
			enabled: N,
			language: P,
			asDate: F,
			model: I,
			formats: L,
			fields: R,
			currentYear: z,
			months: B,
			currentMonth: V,
			days: H,
			fieldItems: U,
			fieldIndices: W,
			columns: G,
			textFor: K,
			columnStyle: De,
			fieldStyle: q,
			firstStyle: Oe,
			secondStyle: ke,
			thirdStyle: Ae,
			theme: J,
			propertyNodes: Y,
			header: X,
			hasHeader: je,
			HeaderContent: Me,
			rootClasses: Ne,
			rootAttrs: Pe,
			rootStyle: Fe,
			raise: Z,
			setDate: Q,
			OnFlyoutButtonClick: Ie,
			OnFlyoutSelectionChanged: Le,
			OnFlyoutClosed: Re,
			publicApi: $,
			Button: oe,
			ColumnDefinition: le,
			ContentPresenter: ae,
			DateTimePickerFlyout: fe,
			Grid: te,
			Rectangle: de,
			RowDefinition: ue,
			TextBlock: ie
		};
		return Object.defineProperty(ze, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), ze;
	}
});
//#endregion
export { v as default };

//# sourceMappingURL=DatePicker.vue_vue_type_script_setup_true_lang.js.map