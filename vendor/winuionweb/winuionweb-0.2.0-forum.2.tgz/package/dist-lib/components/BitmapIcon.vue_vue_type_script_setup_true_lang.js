import { isSolidColorBrush as e } from "./brushCore.js";
import { iconBoolean as t, iconElementProps as n, useIconElement as r } from "./iconElementRuntime.js";
import { imageStretchSize as i } from "./imageSource.js";
import a from "./Grid.vue.js";
import { computed as o, defineComponent as s, getCurrentInstance as c, onBeforeUnmount as l, onMounted as u, ref as d, useAttrs as f, watch as p } from "vue";
//#region src/components/BitmapIcon.vue?vue&type=script&setup=true&lang.ts
var m = /*@__PURE__*/ s({
	inheritAttrs: !1,
	__name: "BitmapIcon",
	props: {
		UriSource: {
			type: String,
			default: null
		},
		ShowAsMonochrome: {
			type: [Boolean, String],
			default: !0
		},
		...n
	},
	setup(n, { expose: s }) {
		let m = n, h = f(), g = c(), { Element: _, read: v, layoutStyle: y, rootAttrs: b, api: x } = r(m, h, g, ["UriSource", "ShowAsMonochrome"]);
		s(x);
		let S = o(() => {
			let e = v("UriSource");
			return typeof e == "string" ? e : "";
		}), C = o(() => t(v("ShowAsMonochrome"), !0)), w = d(!1), T = d({
			width: 0,
			height: 0
		}), E = null, D = 0, O = !1, k = () => {
			++D, E &&= (E.onload = null, E.onerror = null, E.src = "", null);
		}, A = () => {
			if (k(), w.value = !1, T.value = {
				width: 0,
				height: 0
			}, !O || !S.value) return;
			let e = D, t = new window.Image();
			E = t, t.onload = () => {
				e === D && (T.value = {
					width: t.naturalWidth,
					height: t.naturalHeight
				}, w.value = t.naturalWidth > 0 && t.naturalHeight > 0, t.onload = null, t.onerror = null, E = null);
			}, t.onerror = () => {
				e === D && (w.value = !1, T.value = {
					width: 0,
					height: 0
				}, t.onload = null, t.onerror = null, E = null);
			}, t.src = S.value;
		};
		p(S, A), u(() => {
			O = !0, A();
		}), l(() => {
			O = !1, k();
		});
		let j = o(() => {
			let e = (e) => {
				let t = v(e);
				if (t === "" || t == null || t === "Auto") return Infinity;
				let n = Number(t);
				return Number.isFinite(n) && n >= 0 ? n : Infinity;
			}, t = T.value;
			return i(t.width, t.height, Math.min(e("Width"), e("MaxWidth")), Math.min(e("Height"), e("MaxHeight")), "Uniform");
		}), M = {
			props: m,
			attrs: h,
			instance: g,
			Element: _,
			read: v,
			layoutStyle: y,
			rootAttrs: b,
			api: x,
			source: S,
			monochrome: C,
			loaded: w,
			naturalSize: T,
			get loader() {
				return E;
			},
			set loader(e) {
				E = e;
			},
			get loadGeneration() {
				return D;
			},
			set loadGeneration(e) {
				D = e;
			},
			get mounted() {
				return O;
			},
			set mounted(e) {
				O = e;
			},
			cancelLoad: k,
			loadSource: A,
			desiredSize: j,
			iconStyle: o(() => ({
				width: `${j.value.width}px`,
				height: `${j.value.height}px`,
				...y.value
			})),
			maskStyle: o(() => ({
				backgroundColor: v("Foreground") && typeof v("Foreground") == "object" && !e(v("Foreground")) ? "white" : "currentColor",
				maskImage: `url(${JSON.stringify(S.value)})`,
				WebkitMaskImage: `url(${JSON.stringify(S.value)})`
			})),
			Grid: a
		};
		return Object.defineProperty(M, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), M;
	}
});
//#endregion
export { m as default };

//# sourceMappingURL=BitmapIcon.vue_vue_type_script_setup_true_lang.js.map