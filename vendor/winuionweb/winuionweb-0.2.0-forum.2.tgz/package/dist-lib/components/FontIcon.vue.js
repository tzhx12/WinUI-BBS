import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./FontIcon.vue_vue_type_script_setup_true_lang.js";
import { createElementBlock as n, createVNode as r, mergeProps as i, openBlock as a, withCtx as o } from "vue";
//#region src/components/FontIcon.vue
function s(e, t, s, c, l, u) {
	return a(), n("span", i({ ref: "Element" }, c.rootAttrs, {
		class: ["win-icon-element win-font-icon", c.attrs.class],
		style: [c.attrs.style, c.layoutStyle]
	}), [r(c.Grid, {
		class: "win-icon-grid",
		"data-icon-part": "LayoutRoot",
		Background: "Transparent"
	}, {
		default: o(() => [r(c.TextBlock, {
			class: "win-icon-text-block win-font-icon-glyph",
			"data-icon-part": "TextBlock",
			Style: "{x:Null}",
			Text: "{x:Bind FontIconTemplateGlyph, Mode=OneWay}",
			FontFamily: "{x:Bind FontIconTemplateFontFamily, Mode=OneWay}",
			FontSize: "{x:Bind FontIconTemplateFontSize, Mode=OneWay}",
			FontStyle: "{x:Bind FontIconTemplateFontStyle, Mode=OneWay}",
			FontWeight: "{x:Bind FontIconTemplateFontWeight, Mode=OneWay}",
			HorizontalAlignment: "Stretch",
			VerticalAlignment: "Center",
			TextAlignment: "Center",
			IsTextScaleFactorEnabled: "False",
			"AutomationProperties.AccessibilityView": "Raw",
			"aria-hidden": "true"
		})]),
		_: 1
	})], 16);
}
var c = /*#__PURE__*/ e(t, [["render", s], ["__file", "FontIcon.vue"]]);
//#endregion
export { c as default };

//# sourceMappingURL=FontIcon.vue.js.map