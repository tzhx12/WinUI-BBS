import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./Flyout.vue_vue_type_script_setup_true_lang.js";
/* empty css                                           */
import { Fragment as n, Teleport as r, createBlock as i, createCommentVNode as a, createElementBlock as o, createElementVNode as s, createVNode as c, normalizeClass as l, normalizeStyle as u, openBlock as d, withCtx as f, withDirectives as p, withModifiers as m } from "vue";
//#region src/components/Flyout.vue
var h = {
	ref: "anchorRef",
	class: "flyout-anchor",
	"aria-hidden": "true"
}, g = ["aria-label"], _ = {
	ref: "contentMountRef",
	class: "flyout-content-mount"
};
function v(e, t, v, y, b, x) {
	return d(), o(n, null, [
		s("span", h, null, 512),
		(d(), i(r, { to: y.teleportTarget }, [y.isOpen && y.showMode === "Standard" ? (d(), o("div", {
			key: 0,
			ref: "dismissLayerRef",
			class: l(["flyout-dismiss-layer", { "overlay-visible": y.overlayVisible }]),
			style: u(y.boundsStyle),
			onPointerdown: y.onLightDismiss
		}, null, 38)) : a("", !0), y.isPresent ? p((d(), o("div", {
			key: 1,
			ref: "presenterRef",
			class: l(["flyout-presenter", [y.themeClass, {
				"is-positioning": !y.isPositioned,
				"is-closing": !y.isOpen
			}]]),
			style: u(y.presenterStyle),
			role: "dialog",
			"aria-label": y.automationName || void 0,
			tabindex: "-1",
			onPointerdown: t[0] ||= m(() => {}, ["stop"])
		}, [c(y.PresenterOutlet, null, {
			default: f(() => [c(y.ScrollViewer, {
				class: "flyout-scroll-viewer",
				ZoomMode: "Disabled",
				HorizontalScrollMode: "{x:Bind ScrollSettings.HorizontalScrollMode, Mode=OneWay}",
				HorizontalScrollBarVisibility: "{x:Bind ScrollSettings.HorizontalScrollBarVisibility, Mode=OneWay}",
				VerticalScrollMode: "{x:Bind ScrollSettings.VerticalScrollMode, Mode=OneWay}",
				VerticalScrollBarVisibility: "{x:Bind ScrollSettings.VerticalScrollBarVisibility, Mode=OneWay}",
				IsTabStop: "False"
			}, {
				default: f(() => [s("div", _, null, 512)]),
				_: 1
			})]),
			_: 1
		})], 46, g)), [[
			y.vAcrylicBrush,
			y.presenterBackgroundStyle,
			void 0,
			{ "host-backdrop": !0 }
		], [y.vThemeShadow, {
			Translation: 32,
			Theme: y.effectiveTheme,
			Enabled: y.enabled(y.presenterSetters.IsDefaultShadowEnabled)
		}]]) : a("", !0)], 8, ["to"])),
		(d(), i(r, { to: y.contentHost }, [s("div", {
			class: "flyout-content-presenter",
			style: u(y.contentStyle)
		}, [c(y.ContentOutlet)], 4)], 8, ["to"]))
	], 64);
}
var y = /*#__PURE__*/ e(t, [["render", v], ["__file", "Flyout.vue"]]);
//#endregion
export { y as default };

//# sourceMappingURL=Flyout.vue.js.map