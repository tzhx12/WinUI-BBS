import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./ContentPresenter.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                                     */
import { createBlock as n, createVNode as r, mergeProps as i, openBlock as a, withCtx as o } from "vue";
//#region src/components/ContentPresenter.vue
function s(e, t, s, c, l, u) {
	return a(), n(c.Border, i({ ref: c.registerRoot }, e.$attrs, {
		class: "win-content-presenter",
		style: c.contentStyle
	}), {
		default: o(() => [r(c.ContentOutlet)]),
		_: 1
	}, 16, ["style"]);
}
var c = /*#__PURE__*/ e(t, [
	["render", s],
	["__scopeId", "data-v-d51e0e22"],
	["__file", "ContentPresenter.vue"]
]);
//#endregion
export { c as default };

//# sourceMappingURL=ContentPresenter.vue.js.map