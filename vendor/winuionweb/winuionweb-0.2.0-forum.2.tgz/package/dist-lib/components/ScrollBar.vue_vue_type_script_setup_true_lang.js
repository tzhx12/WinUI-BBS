import { boolValue as e } from "./layout.js";
import { uiSettings as t } from "./uiSettings.js";
import { useAcrylicBrushStyle as n } from "./AcrylicBrush.js";
import { resolveXamlHandler as r, resolveXamlValue as i, updateXamlBinding as a, xamlScopeKey as ee } from "./xamlRuntime.js";
import { frameworkLayoutStyle as te } from "./frameworkLayout.js";
import { vAcrylicBrush as ne } from "./acrylicBrushVisual.js";
import re from "./FontIcon.vue.js";
import { scrollBarOwnerKey as ie } from "./scrollBarOwner.js";
import { computed as o, defineComponent as ae, getCurrentInstance as oe, inject as se, onBeforeUnmount as ce, onMounted as le, provide as ue, ref as s, useAttrs as de, watch as c } from "vue";
//#region src/components/ScrollBar.vue?vue&type=script&setup=true&lang.ts
var fe = /*@__PURE__*/ ae({
	inheritAttrs: !1,
	__name: "ScrollBar",
	props: {
		Value: { default: 0 },
		Minimum: { default: 0 },
		Maximum: { default: 1 },
		ViewportSize: { default: 0 },
		SmallChange: { default: 1 },
		LargeChange: { default: 10 },
		Orientation: { default: "Vertical" },
		IndicatorMode: { default: "None" },
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		Width: {},
		Height: {},
		Margin: {},
		HorizontalAlignment: {},
		VerticalAlignment: {}
	},
	emits: ["Scroll", "ValueChanged"],
	setup(ae, { expose: fe, emit: pe }) {
		let l = ae, me = pe, u = oe(), d = de(), f = se(ie, {}), p = s(), he = s(), ge = s(), _e = s(), m = (e) => i(e, u), h = (e, t = 0) => Number.isFinite(Number(m(e))) ? Number(m(e)) : t, g = o(() => m(l.Orientation) !== "Horizontal"), _ = o(() => g.value ? "Vertical" : "Horizontal"), v = o(() => h(l.Minimum)), y = o(() => Math.max(v.value, h(l.Maximum, 1))), b = o(() => Math.max(0, h(l.ViewportSize))), x = o(() => e(m(l.IsEnabled))), S = o(() => {
			let e = String(m(l.IndicatorMode) || "None");
			return e === "None" && j.value ? "MouseIndicator" : e;
		}), C = s(0), w = s(!1), T = s(0), E = s(0), D = s(!1), O = s(!1), ve = n(() => `{ThemeResource ScrollBarTrackFill${x.value ? O.value || D.value ? "Pressed" : w.value ? "PointerOver" : "" : "Disabled"}}`, u), k = null, A = null, j = o(() => !(f.autoHide?.() ?? t.AutoHideScrollBars)), ye = o(() => x.value && S.value === "MouseIndicator" && (j.value || w.value || D.value)), be = o(() => te(l, u)), xe = o(() => Object.fromEntries(Object.entries(d).filter(([e]) => !["Scroll", "ValueChanged"].includes(e)))), M = o(() => g.value ? "" : ""), N = o(() => g.value ? "" : "");
		ue(ee, {
			...se(ee, {}),
			DecreaseGlyph: M,
			IncreaseGlyph: N
		});
		let P = (e) => Math.max(v.value, Math.min(y.value, e));
		c(() => [
			h(l.Value),
			v.value,
			y.value
		], ([e]) => {
			A || (C.value = P(e));
		}, { immediate: !0 });
		let F = o(() => Math.max(0, E.value - 24)), I = o(() => Math.min(F.value, Math.max(30, b.value / Math.max(1, y.value - v.value + b.value) * F.value))), L = o(() => Math.max(0, F.value - I.value)), R = o(() => y.value > v.value ? (P(C.value) - v.value) / (y.value - v.value) : 0), z = o(() => 12 + R.value * L.value), Se = o(() => g.value ? {
			top: `${z.value}px`,
			height: `${I.value}px`
		} : {
			left: `${z.value}px`,
			width: `${I.value}px`
		}), B = o(() => Math.min(E.value, Math.max(32, b.value / Math.max(1, y.value - v.value + b.value) * E.value))), Ce = o(() => g.value ? {
			top: `${R.value * (E.value - B.value)}px`,
			height: `${B.value}px`
		} : {
			left: `${R.value * (E.value - B.value)}px`,
			width: `${B.value}px`
		}), V = o({
			get: () => C.value,
			set: (e) => {
				C.value = P(Number(e)), a(l.Value, C.value, u);
			}
		}), H = {
			get Value() {
				return C.value;
			},
			get Minimum() {
				return v.value;
			},
			get Maximum() {
				return y.value;
			},
			get ViewportSize() {
				return b.value;
			},
			get Orientation() {
				return _.value;
			}
		};
		function U(e, t) {
			me(e, H, t), u?.vnode.props?.[`on${e}`] || r(d[e], u)?.(H, t);
		}
		let W = (e, t) => {
			let n = C.value, r = P(e);
			return C.value = r, a(l.Value, r, u), n !== r && U("ValueChanged", {
				OldValue: n,
				NewValue: r
			}), U("Scroll", {
				ScrollEventType: t,
				NewValue: r
			}), n !== r;
		}, G, K, q = (e) => {
			x.value && f.onPointerActivity?.(e.pointerType || "mouse");
		}, we = (e) => {
			e.pointerType !== "touch" && (w.value = !0, f.onHover?.(_.value, !0), q(e));
		}, J = () => {
			w.value = !1, f.onHover?.(_.value, !1);
		}, Y = (e) => {
			if (!x.value || e.button !== 0) return !1;
			e.pointerType === "touch" && J(), Z(), q(e), D.value = !0, k = {
				id: e.pointerId,
				node: e.currentTarget
			};
			try {
				k.node.setPointerCapture(e.pointerId);
			} catch {}
			return document.addEventListener("pointermove", X), document.addEventListener("pointerup", Z), document.addEventListener("pointercancel", Z), k.node.addEventListener("lostpointercapture", Z), f.onInteraction?.(_.value, !0), e.preventDefault(), !0;
		}, Te = (e, t) => {
			if (!Y(t)) return;
			T.value = e;
			let n = () => W(C.value + e * Math.max(0, h(l.SmallChange, 16)), e < 0 ? "SmallDecrement" : "SmallIncrement");
			n();
			let r = () => {
				k && (n(), G = setTimeout(r, 50));
			};
			G = setTimeout(r, 250);
		}, Ee = (e) => {
			if (!Y(e)) return;
			let t = p.value.getBoundingClientRect(), n = g.value ? e.clientY - t.top : e.clientX - t.left, r = n < z.value ? -1 : 1, i = () => r < 0 && n >= z.value || r > 0 && n <= z.value + I.value ? !1 : W(C.value + r * Math.max(1, h(l.LargeChange) || b.value), r < 0 ? "LargeDecrement" : "LargeIncrement");
			i();
			let a = () => {
				k && i() && (G = setTimeout(a, 50));
			};
			G = setTimeout(a, 250);
		}, De = (e) => {
			Y(e) && (O.value = !0, A = {
				start: g.value ? e.clientY : e.clientX,
				value: C.value,
				travel: L.value,
				range: y.value - v.value
			});
		}, X = (e) => {
			!k || k.id !== e.pointerId || !A || (W(A.value + ((g.value ? e.clientY : e.clientX) - A.start) / Math.max(1, A.travel) * A.range, "ThumbTrack"), e.preventDefault());
		};
		function Z(e) {
			if (e && "pointerId" in e && k && e.pointerId !== k.id) return;
			let t = k, n = !!A;
			if (k = null, A = null, T.value = 0, D.value = !1, O.value = !1, G && clearTimeout(G), G = void 0, document.removeEventListener("pointermove", X), document.removeEventListener("pointerup", Z), document.removeEventListener("pointercancel", Z), t) {
				t.node.removeEventListener("lostpointercapture", Z);
				try {
					t.node.hasPointerCapture(t.id) && t.node.releasePointerCapture(t.id);
				} catch {}
			}
			t && (n && U("Scroll", {
				ScrollEventType: "ThumbPosition",
				NewValue: C.value
			}), U("Scroll", {
				ScrollEventType: "EndScroll",
				NewValue: C.value
			}), f.onInteraction?.(_.value, !1));
		}
		let Oe = (e) => {
			if (!x.value) return;
			let t = g.value ? e.deltaY : e.deltaX || e.deltaY;
			W(C.value + t, t < 0 ? "SmallDecrement" : "SmallIncrement") && (e.preventDefault(), e.stopPropagation());
		}, Q = () => {
			J(), Z();
		};
		le(() => {
			K = new ResizeObserver(([e]) => {
				E.value = g.value ? e?.contentRect.height ?? 0 : e?.contentRect.width ?? 0;
			}), K.observe(p.value), window.addEventListener("blur", Q);
		}), c(x, (e) => {
			e || Z();
		}), ce(() => {
			Z(), K?.disconnect(), window.removeEventListener("blur", Q);
		}), fe({
			Value: V,
			Minimum: v,
			Maximum: y,
			ViewportSize: b,
			Orientation: _
		});
		let $ = {
			props: l,
			emit: me,
			instance: u,
			attrs: d,
			owner: f,
			root: p,
			thumb: he,
			decrease: ge,
			increase: _e,
			resolve: m,
			number: h,
			vertical: g,
			orientation: _,
			minimum: v,
			maximum: y,
			viewportSize: b,
			enabled: x,
			indicator: S,
			value: C,
			over: w,
			pressed: T,
			length: E,
			interacting: D,
			dragging: O,
			trackBackgroundStyle: ve,
			get capture() {
				return k;
			},
			set capture(e) {
				k = e;
			},
			get drag() {
				return A;
			},
			set drag(e) {
				A = e;
			},
			noAutoHide: j,
			expanded: ye,
			layoutStyle: be,
			forwardedAttrs: xe,
			DecreaseGlyph: M,
			IncreaseGlyph: N,
			clamp: P,
			trackLength: F,
			thumbLength: I,
			travel: L,
			ratio: R,
			position: z,
			thumbStyle: Se,
			panningLength: B,
			panningStyle: Ce,
			publicValue: V,
			sender: H,
			dispatch: U,
			change: W,
			get repeat() {
				return G;
			},
			set repeat(e) {
				G = e;
			},
			get observer() {
				return K;
			},
			set observer(e) {
				K = e;
			},
			activity: q,
			enter: we,
			leave: J,
			begin: Y,
			startArrow: Te,
			startTrack: Ee,
			startDrag: De,
			move: X,
			stop: Z,
			wheel: Oe,
			onWindowBlur: Q,
			FontIcon: re,
			get vAcrylicBrush() {
				return ne;
			}
		};
		return Object.defineProperty($, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), $;
	}
});
//#endregion
export { fe as default };

//# sourceMappingURL=ScrollBar.vue_vue_type_script_setup_true_lang.js.map