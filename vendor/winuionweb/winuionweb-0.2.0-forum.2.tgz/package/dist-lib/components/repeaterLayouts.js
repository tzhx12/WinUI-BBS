//#region src/components/repeaterLayouts.ts
var e = (e, t) => {
	if (e == null || e === "") return t;
	let n = Number(e);
	return Number.isFinite(n) ? n : t;
}, t = 1e6, n = (e) => !Number.isFinite(e) || e < 0 ? 0 : Math.min(e, t), r = (e) => {
	if (typeof e != "string") return null;
	let t = e.split(",").map((e) => Number(e.trim()));
	return t.length < 2 || !Number.isFinite(t[0]) || !Number.isFinite(t[1]) ? null : {
		width: t[0],
		height: t[1]
	};
}, i = (e) => {
	let t = String(e ?? "").trim();
	return /uniformgrid/i.test(t) ? "UniformGridLayout" : /activityfeed/i.test(t) ? "ActivityFeedLayout" : /variedimagesize/i.test(t) ? "VariedImageSizeLayout" : /linedflow/i.test(t) ? "LinedFlowLayout" : "StackLayout";
}, a = (e, t) => {
	let n = 0, r = 0;
	for (let i of e) i && (n += t === "width" ? i.width : i.height, r += 1);
	return r > 0 ? n / r : 0;
}, o = (e, t, n) => {
	if (!e) return n;
	let r = t === "width" ? e.width : e.height;
	return Number.isFinite(r) && r >= 0 ? r : n;
}, s = (e, t) => Math.trunc(e / t), c = (t) => {
	let n = String(t.props.Orientation ?? "Vertical").toLowerCase() === "horizontal", r = e(t.props.Spacing, 0), i = 0, s = 0, c = [], l = a(t.naturals, n ? "width" : "height"), u = a(t.naturals, n ? "height" : "width");
	for (let e = 0; e < t.count; e += 1) {
		let a = t.naturals[e], d = o(a, n ? "width" : "height", l), f = o(a, n ? "height" : "width", u);
		i = Math.max(i, f), c.push(n ? {
			x: s,
			y: 0,
			width: d,
			height: f
		} : {
			x: 0,
			y: s,
			width: f,
			height: d
		}), s += d + r;
	}
	let d = n ? t.available.height : t.available.width, f = Number.isFinite(d) && d > 0 ? Math.max(i, d) : i;
	for (let e of c) n ? e.height = Math.max(e.height, f) : e.width = Math.max(e.width, f);
	let p = t.count > 0 ? s - r : 0;
	return {
		rects: c,
		extent: n ? {
			width: p,
			height: f
		} : {
			width: f,
			height: p
		},
		horizontal: n
	};
}, l = (t) => {
	let n = String(t.props.Orientation ?? "Horizontal").toLowerCase() === "vertical" ? "Vertical" : "Horizontal", r = n === "Horizontal", i = e(t.props.MinRowSpacing, 0), c = e(t.props.MinColumnSpacing, 0), l = n === "Horizontal" ? c : i, u = n === "Horizontal" ? i : c, d = n === "Horizontal" ? t.available.width : t.available.height, f = t.props.MinItemWidth === void 0 || t.props.MinItemWidth === null || t.props.MinItemWidth === "" ? NaN : e(t.props.MinItemWidth, NaN), p = t.props.MinItemHeight === void 0 || t.props.MinItemHeight === null || t.props.MinItemHeight === "" ? NaN : e(t.props.MinItemHeight, NaN), m = t.naturals[0], h = Number.isFinite(f) ? f : o(m, "width", a(t.naturals, "width")), g = Number.isFinite(p) ? p : o(m, "height", a(t.naturals, "height")), _ = e(t.props.MaximumRowsOrColumns, -1), v = Math.max(1, _ < 0 ? Infinity : _), y = (n === "Horizontal" ? h : g) + l, b = Math.min(Number.isFinite(d) && y > 0 ? Math.max(1, Math.floor((d + l) / y)) : Math.max(1, t.count), v), x = String(t.props.ItemsStretch ?? "None"), S = n === "Horizontal" ? h : g, C = 0;
	if (Number.isFinite(d) && S > 0) {
		let e = Math.min(v, Math.max(1, Math.trunc(d / (S + l))));
		C = s(s(d - (e * (S + l) - l), 1), e);
	}
	if (x === "Fill") n === "Horizontal" ? h += C : g += C;
	else if (x === "Uniform" && S > 0) {
		let e = C / S * (n === "Horizontal" ? g : h);
		n === "Horizontal" ? (h += C, g += e) : (g += C, h += e);
	}
	let w = (n === "Horizontal" ? h : g) + l, T = (n === "Horizontal" ? g : h) + u, E = t.count > 0 ? Math.ceil(t.count / b) : 0, D = [];
	for (let e = 0; e < t.count; e += 1) {
		let t = s(e, b), n = e - t * b;
		D.push(r ? {
			x: n * w,
			y: t * T,
			width: h,
			height: g
		} : {
			x: t * T,
			y: n * w,
			width: h,
			height: g
		});
	}
	let O = String(t.props.ItemsJustification ?? "Start"), k = n === "Horizontal" ? t.available.width : t.available.height;
	if (O !== "Start" && Number.isFinite(k) && D.length) for (let e = 0; e < E; e += 1) {
		let t = e * b, n = Math.min(t + b, D.length);
		if (n - t < 1) continue;
		let i = D[t], a = D[n - 1], o = (e) => r ? e.x : e.y, s = (e) => r ? e.width : e.height, c = o(i), l = k - o(a) - s(a);
		if (c === 0 && l === 0) continue;
		let u = c + l, d = n - t;
		for (let e = 0; e < d; e += 1) {
			let n = D[t + e], i = -c;
			O === "End" ? i += l : O === "Center" ? i += u / 2 : O === "SpaceAround" ? i += u / (d * 2) * ((e + 1) * 2 - 1) : O === "SpaceBetween" ? i += (d > 1 ? u / (d - 1) : 0) * e : O === "SpaceEvenly" && (i += u / (d + 1) * (e + 1)), r ? n.x += i : n.y += i;
		}
	}
	let A = E > 0 ? E * T - u : 0, j = Number.isFinite(d) && x === "Fill" ? d : Math.max(0, b * w - l);
	return {
		rects: D,
		extent: r ? {
			width: j,
			height: A
		} : {
			width: A,
			height: j
		},
		horizontal: !r,
		itemSize: {
			width: h,
			height: g
		}
	};
}, u = (t) => {
	let n = e(t.props.RowSpacing, 0), i = e(t.props.ColumnSpacing, 0), c = r(t.props.MinItemSize), l = t.naturals[0], u = c?.width || o(l, "width", a(t.naturals, "width")) || 0, d = c?.height || o(l, "height", a(t.naturals, "height")) || 0, f = Number.isFinite(t.available.width) && t.available.width > 0 ? t.available.width : u * 4 + i * 3, p = Math.max(u, (f - i * 3) / 4), m = p * 2 + i, h = [];
	for (let e = 0; e < t.count; e += 1) {
		let t = s(e, 3), r = e - t * 3, a = t * (d + n), o, c;
		t % 2 == 0 ? r === 0 ? (o = 0, c = p) : r === 1 ? (o = p + i, c = p) : (o = p * 2 + i * 2, c = m) : r === 0 ? (o = 0, c = m) : r === 1 ? (o = m + i, c = p) : (o = m + i * 2 + p, c = p), h.push({
			x: o,
			y: a,
			width: c,
			height: d
		});
	}
	let g = Math.ceil(t.count / 3), _ = g > 0 ? g * (d + n) - n : 0;
	return {
		rects: h,
		extent: {
			width: p * 4 + i * 2,
			height: _
		},
		horizontal: !1,
		itemSize: {
			width: p,
			height: d
		}
	};
}, d = (t) => {
	let n = e(t.props.Width, 150), r = Number.isFinite(t.available.width) && t.available.width > 0 ? t.available.width : n, i = Math.max(1, Math.min(64, s(r, n))), c = Array(i).fill(0), l = [], u = a(t.naturals, "height");
	for (let e = 0; e < t.count; e += 1) {
		let r = t.naturals[e], a = o(r, "height", u), s = 0;
		for (let e = 1; e < i; e += 1) c[e] < c[s] && (s = e);
		let d = c[s];
		l.push({
			x: s * n,
			y: d,
			width: n,
			height: a
		}), c[s] = d + a;
	}
	let d = c.reduce((e, t) => Math.max(e, t), 0);
	return {
		rects: l,
		extent: {
			width: i * n,
			height: d
		},
		horizontal: !1
	};
}, f = (e) => {
	let t = (() => {
		switch (i(e.props.Type)) {
			case "UniformGridLayout": return l(e);
			case "ActivityFeedLayout": return u(e);
			case "VariedImageSizeLayout": return d(e);
			default: return c(e);
		}
	})();
	return {
		...t,
		rects: t.rects.map((e) => ({
			x: n(e.x),
			y: n(e.y),
			width: n(e.width),
			height: n(e.height)
		})),
		extent: {
			width: n(t.extent.width),
			height: n(t.extent.height)
		}
	};
}, p = (t, n, r, i) => {
	let a = (e) => Number.isFinite(e) && e > 0 ? e : null;
	switch (t) {
		case "VariedImageSizeLayout": return {
			width: e(n.Width, 150),
			height: NaN
		};
		case "UniformGridLayout":
		case "ActivityFeedLayout":
		case "LinedFlowLayout": return !i || !a(i.width) && !a(i.height) ? {
			width: NaN,
			height: NaN
		} : i;
		default: return String(n.Orientation ?? "Vertical").toLowerCase() === "horizontal" ? {
			width: NaN,
			height: a(r.height) ?? NaN
		} : {
			width: a(r.width) ?? NaN,
			height: NaN
		};
	}
}, m = i;
//#endregion
export { f as computeRepeaterLayout, p as measureBoxFor, m as normalizeLayoutKind };

//# sourceMappingURL=repeaterLayouts.js.map