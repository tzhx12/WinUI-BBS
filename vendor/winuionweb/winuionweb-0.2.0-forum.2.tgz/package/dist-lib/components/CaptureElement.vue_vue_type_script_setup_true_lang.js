import { alignment as e, cssLength as t, xamlThickness as n } from "./layout.js";
import { resolveXamlValue as r } from "./xamlRuntime.js";
import { computed as i, defineComponent as a, getCurrentInstance as o, onBeforeUnmount as s, onMounted as c, ref as l, watch as u } from "vue";
//#region src/components/CaptureElement.vue?vue&type=script&setup=true&lang.ts
var d = /*@__PURE__*/ a({
	__name: "CaptureElement",
	props: {
		Source: {
			type: [String, Object],
			default: null
		},
		Stretch: {
			type: String,
			default: "Uniform"
		},
		Width: {
			type: [String, Number],
			default: ""
		},
		Height: {
			type: [String, Number],
			default: ""
		},
		MinWidth: {
			type: [String, Number],
			default: ""
		},
		MinHeight: {
			type: [String, Number],
			default: ""
		},
		MaxWidth: {
			type: [String, Number],
			default: ""
		},
		MaxHeight: {
			type: [String, Number],
			default: ""
		},
		Margin: {
			type: [String, Number],
			default: ""
		},
		HorizontalAlignment: {
			type: String,
			default: "Stretch"
		},
		VerticalAlignment: {
			type: String,
			default: "Stretch"
		},
		Visibility: {
			type: String,
			default: "Visible"
		},
		Opacity: {
			type: [String, Number],
			default: 1
		}
	},
	emits: ["PreviewFailed"],
	setup(a, { expose: d, emit: f }) {
		let p = a, m = f, h = o(), g = l(null), _ = i(() => r(p.Source, h)), v = i(() => {
			let i = {};
			for (let e of [
				"Width",
				"Height",
				"MinWidth",
				"MinHeight",
				"MaxWidth",
				"MaxHeight"
			]) {
				let n = r(p[e], h);
				n !== "" && n != null && (i[e[0].toLowerCase() + e.slice(1)] = t(n));
			}
			i.margin = n(r(p.Margin, h)), i.justifySelf = e(String(r(p.HorizontalAlignment, h)), "horizontal"), i.alignSelf = e(String(r(p.VerticalAlignment, h)), "vertical"), i.opacity = String(r(p.Opacity, h));
			let a = r(p.Visibility, h);
			return a === "Collapsed" ? i.display = "none" : a === "Hidden" && (i.visibility = "hidden"), i;
		}), y = i(() => ({ objectFit: {
			None: "none",
			Fill: "fill",
			Uniform: "contain",
			UniformToFill: "cover"
		}[String(r(p.Stretch, h))] || "contain" })), b = 0, x = async () => {
			let e = g.value;
			if (!e) return;
			let t = ++b;
			try {
				if (e.pause(), _.value && typeof _.value.getVideoTracks != "function") throw TypeError("InvalidCaptureSource");
				if (e.srcObject = _.value || null, !_.value) return;
				await e.play();
			} catch (n) {
				if (t !== b) return;
				e.srcObject = null, m("PreviewFailed", {
					Code: n instanceof DOMException ? n.name : "PreviewFailed",
					Message: n instanceof Error ? n.message : "",
					Handled: !1
				});
			}
		};
		u(_, x, { flush: "post" }), c(x), s(() => {
			++b, g.value && (g.value.pause(), g.value.srcObject = null);
		}), d({ Source: _ });
		let S = {
			props: p,
			emit: m,
			instance: h,
			video: g,
			source: _,
			elementStyle: v,
			videoStyle: y,
			get sourceVersion() {
				return b;
			},
			set sourceVersion(e) {
				b = e;
			},
			attachSource: x
		};
		return Object.defineProperty(S, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), S;
	}
});
//#endregion
export { d as default };

//# sourceMappingURL=CaptureElement.vue_vue_type_script_setup_true_lang.js.map