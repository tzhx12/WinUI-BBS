import { resolveXamlHandler as e, resolveXamlValue as t, updateXamlBinding as n, xamlScopeKey as r } from "./xamlRuntime.js";
import i from "../_virtual/_plugin-vue_export-helper.js";
import a from "./TextBlock.vue.js";
import { isHoverPointer as o } from "./pointerInput.js";
/* empty css                                           */
import { Fragment as s, computed as c, createBlock as l, createCommentVNode as u, createElementBlock as d, createElementVNode as f, getCurrentInstance as p, normalizeClass as m, normalizeStyle as h, openBlock as g, provide as _, ref as v, renderList as y, useAttrs as b, watch as x } from "vue";
//#region src/components/Rating.vue
var S = -1, C = {
	__name: "Rating",
	props: {
		Value: {
			type: [Number, String],
			default: S
		},
		MaxRating: {
			type: [Number, String],
			default: 5
		},
		PlaceholderValue: {
			type: [Number, String],
			default: S
		},
		Caption: {
			type: String,
			default: ""
		},
		InitialSetValue: {
			type: [Number, String],
			default: 1
		},
		IsClearEnabled: {
			type: [Boolean, String],
			default: !0
		},
		IsReadOnly: {
			type: [Boolean, String],
			default: !1
		},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		Width: {
			type: [String, Number],
			default: ""
		},
		modelValue: {
			type: Number,
			default: void 0
		},
		max: {
			type: Number,
			default: void 0
		},
		disabled: {
			type: Boolean,
			default: !1
		}
	},
	emits: [
		"update:Value",
		"ValueChanged",
		"update:modelValue"
	],
	setup(i, { expose: s, emit: l }) {
		let u = i, d = p(), f = b(), m = v(null), h = v(void 0), g = v(void 0), y = c(() => t(u.Caption, d));
		x(y, () => {
			h.value = void 0;
		});
		let C = c(() => h.value ?? y.value), w = c(() => t(f["AutomationProperties.Name"], d)), T = c(() => C.value), E = c(() => t(u.Value, d)), D = c(() => t(u.MaxRating, d)), O = c(() => t(u.PlaceholderValue, d));
		x(O, () => {
			g.value = void 0;
		});
		let k = c(() => g.value ?? O.value), A = c(() => t(u.InitialSetValue, d)), j = c(() => t(u.IsClearEnabled, d) !== !1), M = c(() => t(u.IsReadOnly, d) === !0), N = c(() => t(u.IsEnabled, d) !== !1), P = l, F = v(null), I = v(!1), L = v(!1), R = v(0), z = v(S), B = (e, t = 0) => {
			let n = Number(e);
			return Number.isFinite(n) ? n : t;
		}, V = (e) => e === "" || e == null ? "" : typeof e == "string" && e.trim() !== "" && !Number.isNaN(Number(e.trim())) ? `${Number(e.trim())}px` : typeof e == "number" ? `${e}px` : e, H = (e) => {
			let t = B(e, S);
			return t < 0 ? S : t <= 1 ? 1 : t > U.value ? U.value : t;
		}, U = c(() => Math.max(1, Math.trunc(B(u.max ?? D.value, 5)))), W = c(() => N.value && !u.disabled), G = c(() => z.value), K = c(() => H(k.value)), q = c(() => {
			let e = String(u.PlaceholderValue ?? "").match(/^\{(?:x:Bind|Binding)\s+([A-Za-z_$][\w$]*)\./);
			return e && t(`{x:Bind ${e[1]}}`, d) || null;
		}), J = c(() => !!q.value?.IsDragging), ee = c(() => Math.max(1, Math.min(U.value, Math.trunc(B(A.value, 1))))), te = c(() => Array.from({ length: U.value }, (e, t) => t + 1));
		x(() => [
			u.modelValue,
			E.value,
			U.value
		], () => {
			z.value = H(u.modelValue ?? E.value);
		}, { immediate: !0 }), x([
			K,
			k,
			J
		], ([e, t, r]) => {
			!r && e > S && e !== t && n(u.PlaceholderValue, e, d);
		}, { immediate: !0 });
		let ne = c(() => I.value && !M.value && W.value ? Math.max(0, Math.min(U.value, R.value)) : G.value > S ? G.value : K.value > S ? K.value : 0), re = c(() => W.value ? I.value && !M.value ? G.value > S ? "pointer-over-set" : "pointer-over-placeholder" : G.value > S ? "set" : K.value > S ? "placeholder" : "unset" : "disabled"), ie = c(() => ({
			"is-readonly": M.value,
			"is-disabled": !W.value,
			[`state-${re.value}`]: !0
		})), ae = c(() => Math.max(0, G.value)), oe = c(() => u.Width === "" ? {} : { width: V(u.Width) }), se = (e) => ({ clipPath: `inset(0 ${100 - Math.max(0, Math.min(1, ne.value - (e - 1))) * 100}% 0 0)` }), Y = (e) => {
			let t = F.value?.getBoundingClientRect();
			if (!t || t.width <= 0) return 0;
			let n = (e.clientX - t.left) / t.width;
			return Math.max(0, Math.min(U.value, Math.ceil(n * U.value)));
		}, X = (e) => {
			R.value = Y(e);
		}, Z = (t, r = !1) => {
			let i = G.value, a = Math.max(0, Math.min(U.value, t)), o = i;
			if ((i > S || a !== 0) && (o = !j.value && a <= 0 ? 1 : a === i && j.value && (a !== U.value || r) ? S : a > 0 ? a : S), o !== i) {
				z.value = o, n(u.Value, o, d), P("update:Value", o), P("update:modelValue", o);
				let t = {
					OldValue: i,
					NewValue: o
				};
				P("ValueChanged", Q, t), d?.vnode.props?.onValueChanged || e(f.ValueChanged, d)?.(Q, t);
			}
		}, Q = {
			get Value() {
				return z.value;
			},
			set Value(t) {
				let r = z.value, i = H(t);
				if (r === i) return;
				z.value = i, n(u.Value, z.value, d), P("update:Value", z.value);
				let a = {
					OldValue: r,
					NewValue: i
				};
				P("ValueChanged", Q, a), d?.vnode.props?.onValueChanged || e(f.ValueChanged, d)?.(Q, a);
			},
			get Caption() {
				return C.value;
			},
			set Caption(e) {
				h.value = String(e ?? ""), n(u.Caption, h.value, d);
			},
			get PlaceholderValue() {
				return K.value;
			},
			set PlaceholderValue(e) {
				g.value = H(e), n(u.PlaceholderValue, g.value, d);
			},
			get IsReadOnly() {
				return M.value;
			},
			get IsClearEnabled() {
				return j.value;
			},
			get IsEnabled() {
				return W.value;
			},
			get Element() {
				return m.value;
			}
		};
		s(Q), _(r, { RatingCaption: T });
		let $ = (e, t = !1) => {
			if (e === 0) return;
			let n;
			n = G.value === S ? ee.value : Math.trunc(G.value) === G.value ? G.value + e : e === -1 ? Math.trunc(G.value) : Math.trunc(G.value) + e, Z(n, t);
		}, ce = {
			noValueSetSentinel: S,
			props: u,
			instance: d,
			attrs: f,
			rootRef: m,
			captionOverride: h,
			placeholderOverride: g,
			captionSource: y,
			resolvedCaption: C,
			automationName: w,
			RatingCaption: T,
			resolvedValue: E,
			resolvedMaxRating: D,
			placeholderSourceValue: O,
			resolvedPlaceholderValue: k,
			resolvedInitialSetValue: A,
			resolvedIsClearEnabled: j,
			resolvedIsReadOnly: M,
			resolvedIsEnabled: N,
			emit: P,
			itemsRef: F,
			isPointerOver: I,
			isPointerDown: L,
			pointerRating: R,
			internalValue: z,
			toNumber: B,
			cssLength: V,
			coerceRatingValue: H,
			effectiveMax: U,
			isEnabled: W,
			actualValue: G,
			placeholderValue: K,
			placeholderSource: q,
			placeholderSourceIsDragging: J,
			initialSetValue: ee,
			itemIndexes: te,
			displayedValue: ne,
			visualState: re,
			stateClasses: ie,
			ariaValue: ae,
			rootStyle: oe,
			foregroundItemStyle: se,
			pointerRatingFromEvent: Y,
			updatePointerRating: X,
			commitRating: Z,
			publicApi: Q,
			changeRatingBy: $,
			onPointerEnter: (e) => {
				!W.value || M.value || (I.value = o(e), X(e));
			},
			onPointerMove: (e) => {
				!W.value || M.value || X(e);
			},
			onPointerLeave: () => {
				L.value || (I.value = !1);
			},
			onPointerCancel: (e) => {
				L.value = !1, F.value?.hasPointerCapture?.(e.pointerId) && F.value.releasePointerCapture(e.pointerId), I.value = !1;
			},
			onPointerCaptureLost: () => {
				L.value = !1;
			},
			onPointerDown: (e) => {
				!W.value || M.value || (o(e) || (I.value = !1), L.value = !0, F.value?.setPointerCapture?.(e.pointerId));
			},
			onPointerUp: (e) => {
				!W.value || M.value || (Z(Y(e), !0), L.value = !1, F.value?.hasPointerCapture?.(e.pointerId) && F.value.releasePointerCapture(e.pointerId), I.value = o(e) && (F.value?.matches(":hover") ?? !1), I.value && X(e));
			},
			onKeyDown: (e) => {
				if (!W.value || M.value) return;
				let t = !0;
				switch (e.key) {
					case "ArrowLeft":
					case "ArrowDown":
						$(-1);
						break;
					case "ArrowRight":
					case "ArrowUp":
						$(1);
						break;
					case "Home":
						Z(0);
						break;
					case "End":
						Z(U.value);
						break;
					default:
						t = !1;
						break;
				}
				t && e.preventDefault();
			},
			computed: c,
			getCurrentInstance: p,
			provide: _,
			ref: v,
			useAttrs: b,
			watch: x,
			TextBlock: a,
			get resolveXamlHandler() {
				return e;
			},
			get resolveXamlValue() {
				return t;
			},
			get updateXamlBinding() {
				return n;
			},
			get xamlScopeKey() {
				return r;
			},
			get isHoverPointer() {
				return o;
			}
		};
		return Object.defineProperty(ce, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), ce;
	}
}, w = [
	"aria-valuemax",
	"aria-valuenow",
	"aria-readonly",
	"aria-disabled",
	"aria-label",
	"tabindex"
], T = { class: "win-rating-caption-stack" }, E = {
	class: "win-rating-foreground-presenter",
	"aria-hidden": "true"
}, D = { class: "win-rating-foreground-outer" }, O = { class: "win-rating-foreground-stack" };
function k(e, t, n, r, i, a) {
	return g(), d("div", {
		ref: "rootRef",
		class: m(["win-rating-control", r.stateClasses]),
		style: h(r.rootStyle),
		role: "slider",
		"aria-valuemin": 0,
		"aria-valuemax": r.effectiveMax,
		"aria-valuenow": r.ariaValue,
		"aria-readonly": r.resolvedIsReadOnly,
		"aria-disabled": !r.isEnabled,
		"aria-label": r.automationName,
		tabindex: r.isEnabled ? 0 : -1,
		onKeydown: r.onKeyDown
	}, [f("div", T, [f("div", {
		ref: "itemsRef",
		class: "win-rating-background-stack",
		onPointerenter: r.onPointerEnter,
		onPointermove: r.onPointerMove,
		onPointerleave: r.onPointerLeave,
		onPointercancel: r.onPointerCancel,
		onLostpointercapture: r.onPointerCaptureLost,
		onPointerdown: r.onPointerDown,
		onPointerup: r.onPointerUp
	}, [(g(!0), d(s, null, y(r.itemIndexes, (e) => (g(), d("span", {
		key: `background-${e}`,
		class: "win-rating-item win-rating-background-item",
		"aria-hidden": "true"
	}, [...t[0] ||= [f("span", { class: "win-rating-glyph" }, "", -1)]]))), 128))], 544), r.resolvedCaption ? (g(), l(r.TextBlock, {
		key: 0,
		class: "win-rating-caption",
		Text: "{x:Bind RatingCaption}"
	})) : u("", !0)]), f("div", E, [f("div", D, [f("div", O, [(g(!0), d(s, null, y(r.itemIndexes, (e) => (g(), d("span", {
		key: `foreground-${e}`,
		class: "win-rating-item win-rating-foreground-item",
		style: h(r.foregroundItemStyle(e))
	}, [...t[1] ||= [f("span", { class: "win-rating-glyph" }, "", -1)]], 4))), 128))])])])], 46, w);
}
var A = /*#__PURE__*/ i(C, [["render", k], ["__file", "Rating.vue"]]);
//#endregion
export { A as default };

//# sourceMappingURL=Rating.vue.js.map