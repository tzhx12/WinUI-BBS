import { useAcrylicBrushStyle as e } from "./AcrylicBrush.js";
import { materializeXamlVNode as t, resolveXamlHandler as n, resolveXamlValue as r, updateXamlBinding as i, xamlScopeKey as a } from "./xamlRuntime.js";
import { vAcrylicBrush as o } from "./acrylicBrushVisual.js";
import { xamlResourceDictionaryKey as s } from "./Page.vue_vue_type_script_lang.js";
import { CollectionGroupStyle as c, CollectionItemContainerStyle as l, CollectionItemTemplate as ee, CollectionItemTemplateSelector as u, CollectionItems as d, CollectionItemsPanel as f, CollectionResources as te, getCollectionProperty as p, getVNodeChildren as m } from "./CollectionProperties.js";
import ne from "./ScrollViewer.vue.js";
import { scrollViewerTemplateBindings as re } from "./scrollViewerTemplateBindings.js";
import ie from "./CheckBox.vue.js";
import { createSemanticZoomView as ae } from "./semanticZoomView.js";
import { attachSecondaryTouchScrollDuringDrag as oe } from "./pointerDragTouchScroll.js";
import { Fragment as se, cloneVNode as ce, computed as h, defineComponent as le, getCurrentInstance as ue, h as de, inject as fe, nextTick as pe, onBeforeUnmount as me, onMounted as he, provide as ge, ref as g, shallowRef as _e, toRaw as ve, useAttrs as ye, useCssVars as be, useSlots as xe, watch as Se } from "vue";
var _ = /*@__PURE__*/ le({
	GroupStyle: c,
	ItemTemplate: ee,
	ItemTemplateSelector: u,
	ItemsPanel: f,
	Items: d,
	Resources: te,
	ItemContainerStyle: l,
	__name: "GridView",
	props: {
		ItemsSource: {
			type: [
				String,
				Array,
				Object
			],
			default: null
		},
		IsGrouped: {
			type: [Boolean, String],
			default: void 0
		},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		IsItemClickEnabled: {
			type: [Boolean, String],
			default: void 0
		},
		CanDragItems: {
			type: [Boolean, String],
			default: void 0
		},
		CanReorderItems: {
			type: [Boolean, String],
			default: void 0
		},
		AllowDrop: {
			type: [Boolean, String],
			default: void 0
		},
		FlowDirection: {
			type: String,
			default: "LeftToRight"
		},
		SelectionMode: {
			type: String,
			default: void 0
		},
		SelectedItems: {
			type: [String, Array],
			default: void 0
		},
		SelectedItem: {
			type: null,
			default: void 0
		},
		SelectedIndex: {
			type: [Number, String],
			default: void 0
		},
		ItemTemplate: {
			type: [String, Object],
			default: ""
		},
		Width: {
			type: [String, Number],
			default: ""
		},
		Height: {
			type: [String, Number],
			default: ""
		},
		MinWidth: {
			type: [String, Number],
			default: ""
		},
		MinHeight: {
			type: [String, Number],
			default: ""
		},
		MaxWidth: {
			type: [String, Number],
			default: ""
		},
		MaxHeight: {
			type: [String, Number],
			default: ""
		},
		Margin: {
			type: [String, Number],
			default: ""
		},
		Padding: {
			type: [String, Number],
			default: ""
		},
		Background: {
			type: [String, Object],
			default: ""
		},
		BorderBrush: {
			type: String,
			default: ""
		},
		BorderThickness: {
			type: [String, Number],
			default: ""
		},
		CornerRadius: {
			type: [String, Number],
			default: ""
		},
		"ScrollViewer.IsHorizontalScrollChainingEnabled": {
			type: [Boolean, String],
			default: !0
		}
	},
	emits: [
		"ItemClick",
		"SelectionChanged",
		"DragItemsStarting",
		"DragItemsCompleted",
		"DragOver",
		"Drop",
		"update:SelectedItems",
		"update:SelectedItem",
		"update:SelectedIndex",
		"update:ItemsSource"
	],
	setup(c, { expose: l, emit: ee }) {
		be((e) => ({ v98515200: Ze.value }));
		let u = c, d = ee, f = g(null), te = g(null), _ = g(!1), v = g(!1), y = g([]), Ce = g(-1), b = g(-1), we = g(-1), x = g(0), S = g(0), C = g([]), w = g(!1), Te = g(""), Ee = g(""), De = null, T = null, E = g(null), D = g(!1), Oe = /* @__PURE__ */ new Set(), ke = 0, O = null, k = [], A = g(0), j = null, Ae = 0, je = 0, Me = 1500, Ne, M, Pe = 0, Fe = 0, N = null, P = null, F = /* @__PURE__ */ new Map(), Ie = g(-1), Le = -1, Re = [], I, ze = Symbol("winuionweb-gridview-drag-owner"), Be = "winuionweb-gridview-pointer-drag-over", Ve = "winuionweb-gridview-pointer-drag-leave", He = "winuionweb-gridview-pointer-drop", L = null, R = null, Ue = /* @__PURE__ */ new Map(), We = (() => {
			let e = typeof globalThis < "u" ? globalThis : {};
			return e.__winuionwebGridDragRegistry ||= /* @__PURE__ */ new Map(), e.__winuionwebGridDragRegistry;
		})(), Ge = xe(), Ke = ye(), z = ue(), B = (e, t) => {
			let r = z?.exposeProxy ?? z?.proxy;
			d(e, r, t), n(Ke[e], z)?.(r, t);
		}, qe = fe(a, {}), Je = re((e) => Ke[e] ?? u[e], z);
		ge(a, {
			...qe,
			ScrollSettings: Je,
			get ScrollTemplateIsEnabled() {
				return U.value;
			}
		});
		let Ye = le({
			name: "GridViewSelectionCheck",
			props: { Item: { default: void 0 } },
			setup(e) {
				return ge(a, {
					...qe,
					Selected: h(() => At(e.Item)),
					Enabled: h(() => U.value),
					SelectionChecked: () => Ut(!0, e.Item),
					SelectionUnchecked: () => Ut(!1, e.Item),
					SelectionClick: (e, t) => t.OriginalEvent?.stopPropagation()
				}), () => de(ie, {
					IsChecked: "{x:Bind Selected, Mode=OneWay}",
					IsEnabled: "{x:Bind Enabled, Mode=OneWay}",
					Checked: "SelectionChecked",
					Unchecked: "SelectionUnchecked",
					Click: "SelectionClick",
					onPointerdown: (e) => e.stopPropagation()
				});
			}
		}), Xe = _e(Ge.default?.() ?? []), Ze = h(() => r(u.FlowDirection, z) === "RightToLeft" ? "rtl" : "ltr"), Qe = fe(s, null), $e = (e) => {
			if (!e) return [];
			if (Array.isArray(e.children)) return e.children;
			if (e.children && typeof e.children == "object") {
				let t = e.children.default;
				return typeof t == "function" ? t() : [];
			}
			return [];
		}, et = (e) => {
			let t = e?.type;
			return typeof t == "string" ? t : t?.name || t?.__name || "";
		}, tt = (e) => e.flatMap((e) => {
			if (!e) return [];
			let t = et(e);
			return e.type === se || /DataTemplateSelector$/i.test(t) ? tt($e(e)) : [e];
		}), nt = (e) => {
			let t = e?.props ?? {}, n = t["x:Key"] ?? t["x:key"] ?? t.Key ?? t.key;
			return typeof n == "string" ? n : "";
		}, rt = h(() => {
			let e = r(u.ItemTemplate, z);
			if (typeof e != "string") return "";
			let t = e.match(/^\{\s*StaticResource\s+([^\s}]+)\s*\}$/i);
			return t ? t[1] : e.match(/^var\(--([^,)]+)\)$/)?.[1] ?? e;
		}), it = h(() => {
			let e = rt.value;
			if (e && Qe?.[e]) return m(Qe[e]);
			for (let t of Xe.value) {
				let n = p(t);
				if (n !== "itemTemplate" && n !== "itemTemplateSelector") continue;
				let r = tt($e(t)).filter((e) => /DataTemplate$/i.test(et(e)));
				return r.length ? m((e ? r.find((t) => nt(t) === e) : r[0]) ?? r[0]) : m(t);
			}
			return [];
		}), at = h(() => {
			let e = Xe.value.find((e) => p(e) === "itemContainerStyle"), t = e ? m(e)[0] : null;
			if (!t) return;
			let n = {};
			for (let e of m(t)) {
				let t = e?.props?.Property;
				if (!t) continue;
				let i = r(e?.props?.Value, z);
				i != null && (t === "Margin" ? n.margin = lt(i) : t === "Padding" ? n.padding = lt(i) : t === "Width" ? n.width = V(i) : t === "Height" ? n.height = V(i) : t === "MinWidth" ? n.minWidth = V(i) : t === "MinHeight" ? n.minHeight = V(i) : t === "Background" ? n.background = String(i) : t === "BorderBrush" ? n.borderColor = String(i) : t === "BorderThickness" ? (n.borderWidth = lt(i), n.borderStyle = "solid") : t === "CornerRadius" ? n.borderRadius = V(i) : t === "HorizontalContentAlignment" && (n["--GridViewItemHorizontalContentAlignment"] = {
					Left: "start",
					Center: "center",
					Right: "end",
					Stretch: "stretch"
				}[i] ?? "center", n["--GridViewItemContentDisplay"] = i === "Stretch" ? "grid" : "flex"));
			}
			return n;
		}), ot = h(() => ({
			margin: "0 4px 4px 0",
			...at.value
		})), st = (e) => {
			let t = r(e, z);
			if (t === "" || t == null) return;
			let n = Number(t);
			return Number.isFinite(n) && n >= 0 ? n : void 0;
		}, ct = h(() => {
			let e = Xe.value.find((e) => p(e) === "itemsPanel"), t = e ? m(e)[0] : null, n = Number(r(t?.props?.MaximumRowsOrColumns, z)), i = st(t?.props?.ItemWidth), a = st(t?.props?.ItemHeight), o = i === void 0 ? "max-content" : `${i}px`, s = a === void 0 ? "max-content" : `${a}px`, c = r(t?.props?.Orientation, z) || "Horizontal", l = {
				columnGap: "0px",
				rowGap: "0px",
				"--GridViewItemWidth": i === void 0 ? void 0 : `${i}px`,
				"--GridViewItemHeight": a === void 0 ? void 0 : `${a}px`
			};
			return n > 0 ? (l.display = "grid", c === "Horizontal" ? (l.gridAutoFlow = "row", l.gridTemplateColumns = `repeat(${n}, ${o})`, l.gridAutoRows = s) : (l.gridAutoFlow = "column", l.gridTemplateRows = `repeat(${n}, ${s})`, l.gridAutoColumns = o)) : (l.display = "flex", l.flexWrap = "wrap", l.alignItems = "flex-start", l.alignContent = "flex-start", l.gridAutoFlow = c === "Horizontal" ? "row" : "column", c === "Horizontal" ? l.flexDirection = "row" : l.flexDirection = "column"), l;
		}), V = (e) => {
			if (!(e === "" || e == null)) return typeof e == "number" || /^-?\d+(?:\.\d+)?$/.test(String(e).trim()) ? `${e}px` : String(e);
		}, lt = (e) => {
			if (e === "" || e == null) return;
			let t = String(e).split(",").map((e) => V(e.trim()));
			return t.length === 1 ? t[0] : t.length === 2 ? `${t[1]} ${t[0]}` : t.length === 4 ? `${t[1]} ${t[2]} ${t[3]} ${t[0]}` : String(e);
		}, ut = e(() => u.Background || void 0, z), dt = h(() => ({
			width: V(r(u.Width, z)),
			height: V(r(u.Height, z)),
			minWidth: V(r(u.MinWidth, z)),
			minHeight: V(r(u.MinHeight, z)),
			maxWidth: V(r(u.MaxWidth, z)),
			maxHeight: V(r(u.MaxHeight, z)),
			margin: lt(r(u.Margin, z)),
			...ut.value,
			"--GridViewBorderBrush": r(u.BorderBrush, z) || void 0,
			"--GridViewBorderThickness": lt(r(u.BorderThickness, z)) || "0",
			"--GridViewCornerRadius": V(r(u.CornerRadius, z)) || "0"
		})), ft = h(() => ({ padding: lt(r(u.Padding, z)) || "0 0 10px" })), pt = h(() => {
			let e = r(u.ItemsSource, z);
			if (Array.isArray(e?.Groups) && e.Groups.length) return e.Groups;
			if (Array.isArray(e)) return e;
			let t = tt(Xe.value), n = t.find((e) => p(e) === "items");
			return n ? tt($e(n)) : t.filter((e) => !p(e));
		}), mt = h(() => r(u.IsGrouped, z)), H = h(() => mt.value === !0 ? !0 : mt.value === !1 && typeof u.IsGrouped == "string" ? !1 : pt.value.length > 0 && pt.value.every((e) => Array.isArray(e?.Items) || Array.isArray(e?.items))), U = h(() => r(u.IsEnabled, z) !== !1), ht = h(() => U.value && r(u.IsItemClickEnabled, z) === !0), gt = h(() => U.value && r(u.CanDragItems, z) === !0), W = h(() => U.value && r(u.CanReorderItems, z) === !0), G = h(() => U.value && r(u.AllowDrop, z) === !0), _t = h(() => U.value && !H.value && (gt.value || W.value)), K = h(() => _.value || v.value), q = h(() => r(u.SelectionMode, z) ?? "Single"), vt = g([]), J = null, yt = [], bt = (e, t) => e.length === t.length && e.every((e, n) => ve(e) === ve(t[n]));
		Se(() => pt.value.slice(), (e) => {
			(J && bt(e, J) || !J || !bt(e, yt)) && (J = null, vt.value = [...e]), yt = [...e];
		}, { immediate: !0 });
		let Y = h(() => H.value ? pt.value.flatMap((e) => Et(e)) : vt.value), xt = g([]), St = h(() => {
			let e = r(u.SelectedItems, z), t = r(u.SelectedItem, z);
			if (Array.isArray(e)) return e;
			if (t !== void 0) return t === null ? [] : [t];
			let n = r(u.SelectedIndex, z);
			return n != null && n !== "" ? Number(n) >= 0 && Y.value[Number(n)] !== void 0 ? [Y.value[Number(n)]] : [] : xt.value;
		}), X = h(() => q.value === "None" ? [] : St.value), Ct = Number(r(u.SelectedIndex, z)), wt = g(Ct >= 0 ? Ct : 0), Tt = (e, t) => e && typeof e == "object" ? e.id ?? e.Id ?? e.key ?? e.Key ?? e.title ?? e.Title ?? t : e ?? t, Et = (e) => e?.Items ?? e?.items ?? [], Dt = (e, t) => e?.id ?? e?.Id ?? e?.key ?? e?.Key ?? e?.title ?? e?.Title ?? t, Ot = (e) => e?.title ?? e?.Title ?? e?.key ?? e?.Key ?? "", kt = (e, t) => ve(e) === ve(t), At = (e) => X.value.some((t) => kt(t, e)), jt = (e, t, n) => {
			if (!H.value) return Y.value.findIndex((t) => kt(t, e));
			let r = 0;
			for (let i of pt.value) {
				let a = Et(i);
				if (i === t) return r + n;
				let o = a.findIndex((t) => kt(t, e));
				if (o >= 0) return r + o;
				r += a.length;
			}
			return -1;
		}, Mt = (e) => U.value && e === wt.value ? 0 : -1, Nt = (e) => {
			e >= 0 && (wt.value = e);
		}, Pt = /* @__PURE__ */ new Map(), Ft = h(() => {
			let e = Xe.value.find((e) => p(e) === "groupStyle"), t = e ? $e(e)[0] : null, n = t?.props?.HeaderTemplate, r = typeof n == "string" ? n.match(/^\{StaticResource\s+([^}]+)\}$/)?.[1] : void 0;
			if (r && Qe?.[r]) return m(Qe[r]);
			let i = t ? $e(t).find((e) => p(e) === "groupStyleHeaderTemplate") : null;
			return i ? m(i) : [];
		}), It = /* @__PURE__ */ new Map(), Lt = (e) => (It.has(e) || It.set(e, le({ setup() {
			return () => Ft.value.length ? de(se, t(Ft.value, e, z)) : de("span", Ot(e));
		} })), It.get(e)), Rt = (e, n, i) => {
			let a = e && typeof e == "object" ? e : `primitive:${i ? Dt(i, 0) : ""}:${n}:${String(e)}`, o = Pt.get(a);
			return o || (o = le({
				name: "GridViewItemTemplate",
				setup() {
					return () => {
						if (it.value.length) return de(se, t(it.value, e, z));
						if (e && typeof e == "object" && "type" in e && "__v_isVNode" in e) {
							let t = {};
							for (let n of tt(Xe.value).filter((e) => p(e) === "resources")) for (let i of tt($e(n))) if (!(et(i) !== "Style" || i.props?.["x:Key"] || String(i.props?.TargetType ?? "").split(":").pop() !== et(e))) for (let e of $e(i)) et(e) === "Setter" && e.props?.Property && (t[e.props.Property] = r(e.props.Value, z));
							return de(se, [ce(e, {
								...t,
								...e.props
							})]);
						}
						return de(se, [de("span", String(e ?? ""))]);
					};
				}
			}), Pt.set(a, o)), o;
		}, zt = (e, t) => {
			t ? Ue.set(e, t) : Ue.delete(e);
		}, Bt = (e) => {
			let t = Ue.get(e);
			if (!t) return !1;
			let n = t.closest(".win-scroll-viewer-viewport");
			if (n instanceof HTMLElement) {
				let e = t.getBoundingClientRect(), r = n.getBoundingClientRect(), i = n.scrollTop + e.top - r.top, a = Math.max(0, n.scrollHeight - n.clientHeight);
				return n.scrollTop = Math.max(0, Math.min(a, i)), !0;
			}
			return !1;
		}, Vt = (e, t) => {
			e.currentTarget.dispatchEvent(new CustomEvent("semanticzoomrequest", {
				bubbles: !0,
				detail: {
					Item: t,
					OriginalSource: e.currentTarget
				}
			}));
		}, Ht = (e, t = null) => {
			let r = [...X.value], a = e.filter((e) => !r.some((t) => kt(t, e))), o = r.filter((t) => !e.some((e) => kt(e, t)));
			if (!a.length && !o.length) return;
			let s = e[0] ?? null, c = s === null ? -1 : Y.value.findIndex((e) => kt(e, s));
			xt.value = [...e], d("update:SelectedItems", e), d("update:SelectedItem", s), d("update:SelectedIndex", c), i(u.SelectedItems, e, z), i(u.SelectedItem, s, z), i(u.SelectedIndex, c, z);
			let l = {
				AddedItems: a,
				RemovedItems: o,
				SelectedItems: e,
				SelectedItem: s,
				SelectedIndex: c,
				OriginalSource: t
			}, ee = z?.exposeProxy ?? z?.proxy;
			d("SelectionChanged", ee, l), n(Ke.SelectionChanged, z)?.(ee, l);
		}, Ut = (e, t) => {
			if (!U.value) return;
			let n = [...X.value], r = n.findIndex((e) => kt(e, t));
			e && r === -1 ? n.push(t) : !e && r > -1 && n.splice(r, 1), Ht(n, t);
		}, Wt = (e, t) => {
			if (!ht.value) return;
			let r = {
				ClickedItem: t,
				OriginalSource: e?.currentTarget ?? e?.target ?? null
			}, i = z?.exposeProxy ?? z?.proxy;
			d("ItemClick", i, r), n(Ke.ItemClick, z)?.(i, r);
		}, Gt = (e, t, n) => {
			if (!(!U.value || _.value || Date.now() < ke)) {
				if (wt.value = n, q.value === "None") {
					Wt(e, t);
					return;
				}
				if (q.value === "Single") {
					Wt(e, t), Ht([t], e?.currentTarget ?? e?.target), O = n;
					return;
				}
				if (q.value === "Multiple") {
					let n = [...X.value], r = n.indexOf(t);
					r > -1 ? n.splice(r, 1) : n.push(t), Ht(n, e?.currentTarget ?? e?.target), Wt(e, t);
					return;
				}
				if (q.value === "Extended") {
					let r = [...X.value];
					if (e.ctrlKey || e.metaKey) {
						let e = r.indexOf(t);
						e > -1 ? r.splice(e, 1) : r.push(t), O = n;
					} else if (e.shiftKey && O !== null) {
						let e = Math.min(O, n), t = Math.max(O, n);
						r = Y.value.slice(e, t + 1);
					} else r = [t], O = n;
					Ht(r, e?.currentTarget ?? e?.target), Wt(e, t);
				}
			}
		}, Kt = () => {
			let e = Xe.value.find((e) => p(e) === "itemsPanel"), t = e ? m(e)[0] : null;
			return {
				orientation: r(t?.props?.Orientation, z) || "Horizontal",
				maximum: Number(r(t?.props?.MaximumRowsOrColumns, z)) || 0
			};
		}, qt = (e, t) => {
			let n = (te.value?.$el || te.value || f.value)?.querySelectorAll?.("[role=\"gridcell\"]") ?? [], r = n[e];
			if (!r) return e;
			let i = r.getBoundingClientRect(), a = t === "ArrowLeft" || t === "ArrowRight", o = t === (Ze.value === "rtl" ? "ArrowRight" : "ArrowLeft") || t === "ArrowUp" ? -1 : 1, s = -1, c = Infinity;
			return n.forEach((t, n) => {
				if (n === e) return;
				let r = t.getBoundingClientRect(), l = a ? r.left - i.left : r.top - i.top, ee = Math.abs(a ? r.top - i.top : r.left - i.left);
				if (o < 0 && l >= -1 || o > 0 && l <= 1) return;
				let u = Math.abs(l) * 1e3 + ee;
				u < c && (c = u, s = n);
			}), s < 0 ? e : s;
		}, Jt = (e, t) => {
			let n = Y.value.length;
			if (!n) return -1;
			if (t === "Home") return 0;
			if (t === "End") return n - 1;
			let { orientation: r, maximum: i } = Kt();
			if (!i) return qt(e, t);
			let a = r === "Horizontal", o = a ? 1 : i, s = a ? i : 1, c = e, l = Ze.value === "rtl";
			return t === (l ? "ArrowRight" : "ArrowLeft") ? c -= o : t === (l ? "ArrowLeft" : "ArrowRight") ? c += o : t === "ArrowUp" ? c -= s : t === "ArrowDown" && (c += s), Math.max(0, Math.min(n - 1, c));
		}, Yt = (e, t) => {
			let n = Y.value[e];
			if (n === void 0 || q.value === "None") return;
			let r = [...X.value];
			if (!(q.value === "Multiple" && (t.ctrlKey || t.metaKey))) {
				if (q.value === "Extended" && t.shiftKey && O !== null) {
					let t = Math.min(O, e), n = Math.max(O, e);
					r = Y.value.slice(t, n + 1);
				} else r = [n], O = e;
				Ht(r, t.currentTarget);
			}
		}, Xt = (e, t, n) => {
			if (!U.value) return;
			let r = e.key;
			if (r === "Enter" || r === " ") {
				e.preventDefault(), Gt(e, t, n);
				return;
			}
			if (![
				"Home",
				"End",
				"ArrowLeft",
				"ArrowRight",
				"ArrowUp",
				"ArrowDown"
			].includes(r)) return;
			e.preventDefault();
			let i = Jt(n, r);
			i < 0 || (wt.value = i, (q.value === "Single" || q.value === "Extended") && Yt(i, e), pe(() => {
				((te.value?.$el || te.value || f.value)?.querySelectorAll?.("[role=\"gridcell\"]")?.[i])?.focus?.();
			}));
		}, Zt = () => {
			let e = te.value?.$el || te.value;
			if (!e) return;
			let t = Array.from(e.querySelectorAll(".win-grid-item")), n = [];
			for (let e = 0; e < Math.min(Y.value.length, t.length); e++) {
				let r = t[e].getBoundingClientRect();
				n.push({
					itemIndex: e,
					rect: r,
					left: r.left,
					right: r.right,
					top: r.top,
					bottom: r.bottom,
					midX: r.left + r.width / 2,
					midY: r.top + r.height / 2,
					width: r.width,
					height: r.height,
					slotSizeX: r.width,
					slotSizeY: r.height
				});
			}
			k = n, F.clear(), A.value++, j = f.value?.querySelector?.(".win-scroll-viewer-viewport") ?? null, Ae = j?.scrollLeft ?? 0, je = j?.scrollTop ?? 0;
		}, Qt = () => {
			let e = j;
			if (!e || !k.length) return;
			let t = e.scrollLeft ?? 0, n = e.scrollTop ?? 0, r = t - Ae, i = n - je;
			if (!(Math.abs(r) < .01 && Math.abs(i) < .01)) {
				for (let e of k) e.left -= r, e.right -= r, e.midX -= r, e.top -= i, e.bottom -= i, e.midY -= i, e.rect = {
					...e.rect,
					left: e.left,
					right: e.right,
					top: e.top,
					bottom: e.bottom
				};
				Ae = t, je = n, A.value++;
			}
		}, $t = (e) => {
			let t = e?.dataTransfer;
			if (!t) return null;
			let n = "";
			try {
				n = t.getData("application/x-winuionweb-gridview") || t.getData("text/plain") || "";
			} catch {
				n = "";
			}
			return n ? We.get(n) ?? null : null;
		}, en = (e) => K.value && we.value === e && !y.value.includes(e), tn = (e) => {
			if (!K.value || y.value.includes(e)) return;
			A.value;
			let t = F.get(e);
			return t && (t.x || t.y) ? `translate3d(${t.x}px, ${t.y}px, 0)` : void 0;
		}, nn = (e) => {
			if (!en(e) || b.value < 0) return {
				"--grid-reorder-hint-x": "0px",
				"--grid-reorder-hint-y": "0px"
			};
			let t = cn(), n = b.value > e ? 1 : -1;
			return t === "Horizontal" && Ze.value === "rtl" && (n *= -1), t === "Horizontal" ? {
				"--grid-reorder-hint-x": `${n * 16}px`,
				"--grid-reorder-hint-y": "0px"
			} : {
				"--grid-reorder-hint-x": "0px",
				"--grid-reorder-hint-y": `${n * 16}px`
			};
		}, rn = () => {
			De?.parentNode && De.parentNode.removeChild(De), De = null;
		}, an = () => {
			T?.parentNode && T.parentNode.removeChild(T), T = null;
		}, on = (e, t) => {
			if (!e || typeof document > "u") return null;
			an();
			let n = e.cloneNode(!0);
			n.querySelectorAll?.("[id]").forEach((e) => e.removeAttribute("id")), n.removeAttribute?.("id"), n.classList?.remove("dragging-source", "reorder-target"), n.classList?.add("win-grid-pointer-drag-preview");
			let r = e.getBoundingClientRect();
			if (Object.assign(n.style, {
				position: "fixed",
				left: "0",
				top: "0",
				width: `${Math.max(1, r.width)}px`,
				height: `${Math.max(1, r.height)}px`,
				margin: "0",
				pointerEvents: "none",
				transform: "translate3d(-10000px, -10000px, 0)"
			}), t > 1) {
				let e = document.createElement("span");
				e.className = "drag-count-badge", e.textContent = String(t), n.appendChild(e);
			}
			return document.body.appendChild(n), T = n, n;
		}, sn = (e, t, n) => {
			if (!e || typeof document > "u") return;
			rn();
			let r = e.cloneNode(!0);
			r.querySelectorAll?.("[id]").forEach((e) => e.removeAttribute("id")), r.removeAttribute?.("id"), r.classList?.remove("dragging-source", "reorder-target"), r.classList?.add("win-grid-drag-image");
			let i = e.getBoundingClientRect();
			if (Object.assign(r.style, {
				position: "fixed",
				left: "-10000px",
				top: "-10000px",
				width: `${Math.max(1, i.width)}px`,
				height: `${Math.max(1, i.height)}px`,
				margin: "0",
				pointerEvents: "none",
				transform: "none"
			}), t > 1) {
				let e = document.createElement("span");
				e.className = "drag-count-badge", e.textContent = String(t), r.appendChild(e);
			}
			document.body.appendChild(r), De = r;
			let a = Number.isFinite(n?.clientX) ? n.clientX - i.left : i.width / 2, o = Number.isFinite(n?.clientY) ? n.clientY - i.top : i.height / 2;
			try {
				n?.dataTransfer?.setDragImage(r, Math.max(0, Math.min(i.width, a)), Math.max(0, Math.min(i.height, o)));
			} catch {}
		}, cn = () => Kt().orientation === "Vertical" ? "Vertical" : "Horizontal", ln = (e, t) => {
			let n = [], r = [...e].sort((e, t) => e.itemIndex - t.itemIndex);
			for (let e of r) {
				let r = t === "Horizontal" ? e.top : e.left, i = t === "Horizontal" ? e.bottom : e.right, a = n[n.length - 1];
				(!a || r > a.end + 1) && (a = {
					entries: [],
					start: r,
					end: i,
					center: (r + i) / 2
				}, n.push(a)), a.entries.push(e), a.start = Math.min(a.start, r), a.end = Math.max(a.end, i), a.center = (a.start + a.end) / 2;
			}
			for (let e of n) e.entries.sort((e, n) => t === "Horizontal" ? Ze.value === "rtl" ? n.left - e.left : e.left - n.left : e.top - n.top);
			return n;
		}, un = (e, t, n = y.value) => {
			if (k.length === 0) return -1;
			let r = k.filter((e) => !n.includes(e.itemIndex));
			if (!r.length) return Y.value.length;
			let i = cn(), a = ln(k, i), o = i === "Horizontal" ? t : e, s = a[0];
			if (o < a[0].start) s = a[0];
			else if (o > a[a.length - 1].end) s = a[a.length - 1];
			else for (let e = 0; e < a.length - 1; e++) {
				if (o < (a[e].center + a[e + 1].center) / 2) {
					s = a[e];
					break;
				}
				s = a[e + 1];
			}
			let c = i === "Horizontal" ? e : t, l = s.entries.filter((e) => !n.includes(e.itemIndex));
			for (let e of l) {
				let t = i === "Horizontal" ? e.midX : e.midY;
				if (i === "Horizontal" && Ze.value === "rtl" ? c > t : c < t) return e.itemIndex;
			}
			let ee = Math.max(...s.entries.map((e) => e.itemIndex));
			return r.find((e) => e.itemIndex > ee)?.itemIndex ?? Y.value.length;
		}, dn = (e, t, n = y.value) => {
			if (!k.length) return -1;
			let r = cn(), i = ln(k, r);
			if (!i.length) return -1;
			let a = r === "Horizontal" ? t : e, o = r === "Horizontal" ? e : t, s = i[0];
			if (a < i[0].start) s = i[0];
			else if (a > i[i.length - 1].end) s = i[i.length - 1];
			else for (let e = 0; e < i.length - 1; e++) {
				if (a < (i[e].center + i[e + 1].center) / 2) {
					s = i[e];
					break;
				}
				s = i[e + 1];
			}
			let c = s.entries.filter((e) => !n.includes(e.itemIndex)), l = null, ee = Infinity;
			for (let e of c) {
				let t = F.get(e.itemIndex) || {
					x: 0,
					y: 0
				}, n = e.left + t.x, i = e.top + t.y, s = Math.max(1, e.width), c = Math.max(1, e.height), u = r === "Horizontal" ? (o - n) / s : (o - i) / c;
				if (u > .3 && u < .7) return e.itemIndex;
				let d = r === "Horizontal" ? n + s / 2 : i + c / 2, f = Math.abs(o - d) + Math.abs(a - (r === "Horizontal" ? e.midY : e.midX));
				f < ee && (ee = f, l = e.itemIndex);
			}
			return l ?? -1;
		}, fn = h(() => Y.value.map((e, t) => ({
			type: "item",
			key: "item-" + Tt(e, t),
			item: e,
			index: t
		}))), Z = () => {
			!v.value && !Ee.value && !C.value.length || (gn(), v.value = !1, _.value = !1, Ee.value = "", b.value = -1, we.value = -1, x.value = 0, S.value = 0, k = [], On(), A.value++, C.value = [], w.value = !1, P = null, N = null);
		}, pn = (e, t = y.value) => {
			let n = [...new Set(t)].sort((e, t) => e - t);
			if (!n.length || e < 0) return e;
			let r = new Set(n), i = Y.value.map((e, t) => t).filter((e) => !r.has(e)), a = e >= Y.value.length ? i.length : i.filter((t) => t < e).length, o = [
				...i.slice(0, a),
				...n,
				...i.slice(a)
			];
			return o.length === Y.value.length && o.every((e, t) => e === t) ? -1 : Math.min(Y.value.length, e);
		}, mn = (e, t = y.value) => {
			let n = new Set(t), r = Y.value.filter((e, t) => !n.has(t));
			return e >= Y.value.length ? r.length : Math.max(0, Y.value.slice(0, e).filter((e, t) => !n.has(t)).length);
		}, hn = (e, t = null, n = null, r = null) => {
			if ((!_.value && !v.value || !k.length) && pe(Zt), !_.value && !v.value || k.length === 0) return;
			Qt();
			let i = Array.isArray(t) ? t : _.value && !v.value ? y.value : [], a = n === null ? _.value && !v.value : n, o = Array.isArray(r) ? r : y.value, s = un(e.clientX, e.clientY, i);
			if (s < 0) return;
			let c = a ? pn(s, o) : s;
			b.value = c, we.value = dn(e.clientX, e.clientY, i), a ? En(c, o) : En(c, o, !0);
		}, gn = () => {
			Ne !== void 0 && (window.clearTimeout(Ne), Ne = void 0), M !== void 0 && (window.cancelAnimationFrame(M), M = void 0), Pe = 0, Fe = 0, N = null;
		}, _n = () => P ? (document.elementFromPoint(P.x, P.y)?.closest?.(".win-grid-view"))?.querySelector?.(".win-scroll-viewer-viewport") ?? null : null, vn = (e) => {
			let t = _n() || j || f.value?.querySelector?.(".win-scroll-viewer-viewport");
			if (!t) return 0;
			N = t;
			let n = t.getBoundingClientRect(), r = Math.max(0, t.scrollHeight - t.clientHeight);
			if (r <= 0 || e < n.top - 100 || e > n.bottom + 100) return 0;
			let i = e - n.top, a = n.bottom - e;
			if (i >= 100 && a >= 100) return 0;
			let o = Math.max(0, Math.min(i, a)), s = i < 100 ? -1 : 1;
			if (s < 0 && t.scrollTop <= 0 || s > 0 && t.scrollTop >= r) return 0;
			let c = Math.max(0, Math.min(1, o / 100));
			return s * (Me - (Me - 150) * c);
		}, yn = () => {
			!K.value || !P || hn({
				clientX: P.x,
				clientY: P.y
			}, v.value ? [] : y.value, !v.value, v.value ? [] : y.value);
		}, bn = (e) => {
			if (!K.value || !Pe || !N) {
				M = void 0;
				return;
			}
			let t = Fe > 0 ? Math.min(50, e - Fe) : 16;
			Fe = e;
			let n = N.scrollTop, r = Math.max(0, N.scrollHeight - N.clientHeight);
			if (N.scrollTop = Math.max(0, Math.min(r, n + Pe * t / 1e3)), Math.abs(N.scrollTop - n) > .01) N === j ? (Qt(), yn()) : R && L && (L.clientX = P?.x ?? L.clientX, L.clientY = P?.y ?? L.clientY, L.accepted = !1, R.dispatchEvent(new CustomEvent(Be, { detail: L })), L.accepted || (R = null));
			else {
				gn();
				return;
			}
			M = window.requestAnimationFrame(bn);
		}, xn = (e) => {
			let t = vn(e);
			if (!t) {
				gn();
				return;
			}
			Pe = t, M === void 0 && Ne === void 0 && (Ne = window.setTimeout(() => {
				Ne = void 0, !(!Pe || !K.value) && (Fe = 0, M = window.requestAnimationFrame(bn));
			}, 50));
		}, Sn = () => {
			K.value && (Qt(), yn());
		}, Cn = (e, t = y.value) => {
			if (F.clear(), !K.value || e < 0 || !k.length) {
				A.value++;
				return;
			}
			let n = [...t].sort((e, t) => e - t);
			if (!n.length) {
				let t = Math.max(1, C.value.length || 1), n = k.slice().sort((e, t) => e.itemIndex - t.itemIndex), r = e >= Y.value.length ? n.length : n.findIndex((t) => t.itemIndex >= e), i = r < 0 ? n.length : r;
				for (let e = i; e < n.length; e++) {
					let r = n[e], i = n[e + t];
					i && F.set(r.itemIndex, {
						x: i.left - r.left,
						y: i.top - r.top
					});
				}
				A.value++;
				return;
			}
			let r = new Set(n), i = k.slice().sort((e, t) => e.itemIndex - t.itemIndex), a = i.filter((e) => !r.has(e.itemIndex)), o = e >= Y.value.length ? a.length : a.filter((t) => t.itemIndex < e).length, s = [
				...a.slice(0, o).map((e) => e.itemIndex),
				...n,
				...a.slice(o).map((e) => e.itemIndex)
			], c = i.map((e) => e), l = new Map(i.map((e) => [e.itemIndex, e]));
			s.forEach((e, t) => {
				if (r.has(e)) return;
				let n = l.get(e), i = c[t];
				if (!n || !i) return;
				let a = i.left - n.left, o = i.top - n.top;
				(Math.abs(a) > .1 || Math.abs(o) > .1) && F.set(e, {
					x: a,
					y: o
				});
			}), A.value++;
		}, wn = () => {
			I !== void 0 && (window.clearTimeout(I), I = void 0);
		}, Tn = (e, t = y.value) => {
			wn();
			let n = pn(e, t);
			Ie.value = n, Cn(n, t);
		}, En = (e, t = y.value, n = !1) => {
			let r = pn(e, t), i = [...t].sort((e, t) => e - t), a = r === Le && i.length === Re.length && i.every((e, t) => e === Re[t]);
			if (Le = r, Re = i, n) {
				Tn(r, i);
				return;
			}
			if (r === Ie.value) {
				wn();
				return;
			}
			a && I !== void 0 || (wn(), I = window.setTimeout(() => {
				I = void 0, K.value && Tn(Le, Re);
			}, 300));
		}, Dn = () => {
			let e = I !== void 0 || Le !== Ie.value;
			wn(), !(!K.value || !e) && Tn(Le, Re);
		}, On = () => {
			wn(), Le = -1, Re = [], Ie.value = -1, F.clear(), A.value++;
		}, kn = (e, t) => {
			if (!_t.value || H.value) {
				e.preventDefault?.();
				return;
			}
			let n = e.currentTarget;
			n && (x.value = n.offsetWidth, S.value = n.offsetHeight), At(Y.value[t]) && X.value.length > 1 ? y.value = Y.value.map((e, t) => At(e) ? t : -1).filter((e) => e !== -1) : y.value = [t], Ce.value = t, b.value = -1, we.value = -1, On();
			let r = {
				Items: y.value.map((e) => Y.value[e]),
				OriginalSource: e.target ?? e.currentTarget,
				Cancel: !1
			};
			if (C.value = [...r.Items], B("DragItemsStarting", r), r.Cancel) {
				e.preventDefault?.(), $(r.OriginalSource);
				return;
			}
			let i = `grid-${z?.uid ?? "view"}-${Date.now()}-${Math.random().toString(36).slice(2)}`;
			if (Te.value = i, We.set(i, {
				token: i,
				source: z,
				items: [...r.Items],
				indices: [...y.value],
				width: x.value,
				height: S.value,
				complete: (e) => Zn(i, e)
			}), e.dataTransfer) {
				e.dataTransfer.effectAllowed = "move";
				try {
					e.dataTransfer.setData("application/x-winuionweb-gridview", i), e.dataTransfer.setData("text/plain", i);
				} catch {}
				sn(n, r.Items.length, e);
			}
			_.value = !0, v.value = !1, w.value = !1, pe(Zt);
		}, An = () => {
			let e = E.value;
			if (e?.source) try {
				e.source.hasPointerCapture?.(e.pointerId) && (Oe.add(e.pointerId), e.source.releasePointerCapture?.(e.pointerId));
			} catch {
				Oe.delete(e.pointerId);
			}
		}, jn = (e, t) => {
			let n = E.value;
			if (!n || D.value || n.pointerId !== e.pointerId || Math.hypot(e.clientX - n.startX, e.clientY - n.startY) < 8) return;
			D.value = !0;
			let r = n.index >= 0 ? n.index : t;
			At(Y.value[r]) && X.value.length > 1 ? y.value = Y.value.map((e, t) => At(e) ? t : -1).filter((e) => e >= 0) : y.value = [r], Ce.value = r, C.value = [...y.value].sort((e, t) => e - t).map((e) => Y.value[e]);
			let i = n.source.getBoundingClientRect();
			x.value = i.width, S.value = i.height;
			let a = {
				Items: [...C.value],
				OriginalSource: e.target ?? n.source,
				Cancel: !1
			};
			if (B("DragItemsStarting", a), a.Cancel) {
				D.value = !1, E.value = null, $n();
				return;
			}
			L = {
				owner: ze,
				source: z,
				indices: [...y.value],
				items: [...C.value],
				dragWidth: i.width,
				dragHeight: i.height,
				clientX: e.clientX,
				clientY: e.clientY,
				accepted: !1,
				dropResult: "None"
			}, _.value = !0, v.value = !1, w.value = !0, b.value = -1, we.value = -1, On(), on(n.source, C.value.length), pe(Zt), e.preventDefault();
		}, Mn = (e, t) => {
			if (!U.value || !_t.value || H.value || !e.isPrimary || e.button !== 0) return;
			let n = e.currentTarget;
			if (!n) return;
			let r = n.getBoundingClientRect();
			E.value = {
				pointerId: e.pointerId,
				index: t,
				startX: e.clientX,
				startY: e.clientY,
				grabX: e.clientX - r.left,
				grabY: e.clientY - r.top,
				source: n
			};
			try {
				n.setPointerCapture?.(e.pointerId);
			} catch {}
		}, Nn = (e, t) => {
			let n = E.value;
			!n || n.pointerId !== e.pointerId || !_t.value || (jn(e, t), D.value && (P = {
				x: e.clientX,
				y: e.clientY
			}, T && (T.style.transform = `translate3d(${e.clientX - n.grabX}px, ${e.clientY - n.grabY}px, 0)`), xn(e.clientY), Pn(e.clientX, e.clientY), e.preventDefault()));
		}, Pn = (e, t) => {
			if (!L) return;
			L.clientX = e, L.clientY = t;
			let n = document.elementFromPoint(e, t)?.closest?.(".win-grid-view") ?? null;
			R && R !== n && (R.dispatchEvent(new CustomEvent(Ve, { detail: L })), R = null), n && (L.accepted = !1, n.dispatchEvent(new CustomEvent(Be, { detail: L })), R = L.accepted ? n : null);
		}, Q = () => {
			gn(), b.value = -1, we.value = -1, On();
		}, Fn = (e) => {
			let t = e.detail;
			if (!t || !U.value || H.value) return;
			let n = t.source === z;
			if (n && (!W.value || !G.value)) {
				t.accepted = !1, Q();
				return;
			}
			if (!n && !G.value) {
				t.accepted = !1, Q();
				return;
			}
			_.value = !0, v.value = !n, P = {
				x: t.clientX,
				y: t.clientY
			}, n || (C.value = Array.isArray(t.items) ? [...t.items] : [], x.value = Math.max(1, Number(t.dragWidth) || 44), S.value = Math.max(1, Number(t.dragHeight) || 44));
			let r = Array.isArray(t.items) ? [...t.items] : [...C.value], i = {
				DataTransfer: null,
				AcceptedOperation: "Move",
				OriginalSource: document.elementFromPoint(t.clientX, t.clientY),
				Items: r
			};
			if (B("DragOver", i), i.AcceptedOperation === "None") {
				t.accepted = !1, w.value = !1, v.value ? Z() : Q();
				return;
			}
			t.accepted = !0, k.length || Zt(), hn({
				clientX: t.clientX,
				clientY: t.clientY
			}, n ? t.indices : [], n, n ? t.indices : []), w.value = !0;
		}, In = (e) => {
			e?.detail && (e.detail.accepted = !1), !(!_.value && !v.value) && (Q(), v.value && Z());
		}, Ln = (e) => {
			let t = e.detail;
			if (!t || !t.accepted || H.value) {
				t && (t.accepted = !1), v.value ? Z() : t && Q();
				return;
			}
			let n = t.source === z;
			if (n && (!W.value || !G.value) || !n && !G.value) {
				t.accepted = !1, v.value ? Z() : Q();
				return;
			}
			n && Dn();
			let r = Array.isArray(t.items) ? [...t.items] : [];
			if (!r.length || b.value < 0) {
				t.accepted = !1, v.value ? Z() : Q();
				return;
			}
			let a = n ? new Set(t.indices ?? []) : /* @__PURE__ */ new Set(), o = Y.value.filter((e, t) => !a.has(t)), s = n ? mn(b.value, [...a]) : Math.min(b.value, o.length), c = [...o];
			c.splice(s, 0, ...r), vt.value = c, J = c, i(u.ItemsSource, c, z), d("update:ItemsSource", c), B("Drop", {
				DataTransfer: null,
				AcceptedOperation: "Move",
				InsertIndex: s,
				Items: r,
				OriginalSource: document.elementFromPoint(t.clientX, t.clientY)
			}), t.dropResult = "Move", $n();
		}, Rn = (e) => {
			let t = E.value;
			if (!(!t || t.pointerId !== e.pointerId)) {
				if (D.value) {
					ke = Date.now() + 300, Pn(e.clientX, e.clientY);
					let t = L;
					if (An(), R && t ? R.dispatchEvent(new CustomEvent(He, { detail: t })) : $(e.target ?? e.currentTarget ?? null), t?.dropResult === "Move" && t.source === z && R && R !== f.value) {
						let e = new Set(t.indices ?? []), n = Y.value.filter((t, n) => !e.has(n));
						vt.value = n, J = n, i(u.ItemsSource, n, z), d("update:ItemsSource", n);
					}
					t && t.dropResult === "Move" && B("DragItemsCompleted", {
						Items: [...t.items ?? []],
						DropResult: "Move",
						OriginalSource: e.target ?? e.currentTarget ?? null
					}), R = null, $n(), E.value = null, D.value = !1, e.preventDefault();
					return;
				}
				An(), E.value = null;
			}
		}, zn = (e) => {
			let t = E.value;
			!t || t.pointerId !== e.pointerId || (An(), D.value && $(e.target ?? e.currentTarget ?? null), E.value = null, D.value = !1);
		}, Bn = (e) => {
			Oe.delete(e.pointerId) || E.value?.pointerId === e.pointerId && (D.value ||= (E.value = null, !1));
		}, Vn = (e) => {
			E.value?.pointerId === e.pointerId && Nn(e, E.value.index);
		}, Hn = (e) => {
			E.value?.pointerId === e.pointerId && Rn(e);
		}, Un = (e) => {
			E.value?.pointerId === e.pointerId && zn(e);
		}, Wn = (e) => {
			let t = $t(e), n = !!(t && t.source !== z), r = _.value || !!(t && t.source === z);
			(n ? G.value : r ? W.value && G.value : G.value) && (e.preventDefault(), n && (v.value = !0, Ee.value = t.token, C.value = [...t.items], x.value = t.width || x.value || 44, S.value = t.height || S.value || 44, pe(Zt)), Gn(e));
		}, Gn = (e) => {
			let t = $t(e), n = !!(t && t.source !== z), r = _.value || !!(t && t.source === z);
			if (!(n ? G.value : r ? W.value && G.value : G.value)) return;
			e.preventDefault(), P = {
				x: e.clientX,
				y: e.clientY
			}, xn(e.clientY), e.dataTransfer && (e.dataTransfer.dropEffect = "move"), n && !v.value && (v.value = !0, Ee.value = t.token, C.value = [...t.items], x.value = t.width || 44, S.value = t.height || 44, pe(Zt));
			let i = {
				DataTransfer: e.dataTransfer ?? null,
				AcceptedOperation: "Move",
				OriginalSource: e.target ?? e.currentTarget,
				Items: n ? [...t.items] : [...C.value]
			};
			if (B("DragOver", i), w.value = i.AcceptedOperation !== "None", !w.value) {
				n ? Z() : Q();
				return;
			}
			(_.value && W.value && G.value || n) && hn(e);
		}, Kn = (e, t) => {
			e.stopPropagation?.(), Wn(e, t);
		}, qn = (e, t) => {
			e.stopPropagation?.(), Gn(e, t);
		}, Jn = (e) => {
			if (!f.value) return;
			let t = e.relatedTarget;
			t && f.value.contains(t) || (gn(), w.value = !1, v.value ? Z() : Q());
		}, Yn = (e) => {
			let t = $t(e), n = !!(t && t.source !== z);
			if (n ? G.value : _.value ? W.value && G.value : G.value) {
				if (e.preventDefault(), !w.value && (_.value || n)) {
					n ? Z() : $(e.target ?? e.currentTarget);
					return;
				}
				if (n) {
					Qn(e, t);
					return;
				}
				if (_.value && W.value && G.value) {
					Dn(), Xn(e);
					return;
				}
				B("Drop", {
					DataTransfer: e.dataTransfer ?? null,
					AcceptedOperation: "Move",
					InsertIndex: Y.value.length,
					OriginalSource: e.target ?? e.currentTarget
				});
			}
		}, Xn = (e = null) => {
			if (y.value.length === 0 || b.value === -1) {
				$(e?.target ?? e?.currentTarget ?? null);
				return;
			}
			let t = [...y.value].sort((e, t) => e - t).map((e) => Y.value[e]), n = Y.value.filter((e, t) => !y.value.includes(t)), r = mn(b.value, y.value), a = [...n];
			a.splice(r, 0, ...t), vt.value = a, J = a, i(u.ItemsSource, a, z), d("update:ItemsSource", a), B("Drop", {
				DataTransfer: e?.dataTransfer ?? null,
				AcceptedOperation: "Move",
				InsertIndex: r,
				Items: t,
				OriginalSource: e?.target ?? e?.currentTarget ?? null
			}), B("DragItemsCompleted", {
				Items: t,
				DropResult: "Move",
				OriginalSource: e?.target ?? e?.currentTarget ?? null
			}), $n();
		}, Zn = (e, t = null) => {
			if (!_.value || Te.value !== e) return;
			let n = [...C.value], r = new Set(y.value), a = Y.value.filter((e, t) => !r.has(t));
			vt.value = a, J = a, i(u.ItemsSource, a, z), d("update:ItemsSource", a), B("DragItemsCompleted", {
				Items: n,
				DropResult: "Move",
				OriginalSource: t
			}), $n();
		}, Qn = (e, t) => {
			let n = Array.isArray(t?.items) ? [...t.items] : [];
			if (!n.length || b.value < 0) {
				Z();
				return;
			}
			let r = b.value >= Y.value.length ? Y.value.length : Math.max(0, Math.min(Y.value.length, b.value)), a = [...Y.value];
			a.splice(r, 0, ...n), vt.value = a, J = a, i(u.ItemsSource, a, z), d("update:ItemsSource", a), B("Drop", {
				DataTransfer: e?.dataTransfer ?? null,
				AcceptedOperation: "Move",
				InsertIndex: r,
				Items: n,
				OriginalSource: e?.target ?? e?.currentTarget ?? null
			}), typeof t.complete == "function" && t.complete(e?.target ?? e?.currentTarget ?? null), Z();
		}, $n = () => {
			gn(), On();
			let e = R, t = L;
			R = null, L = null, e && t && e.dispatchEvent(new CustomEvent(Ve, { detail: t }));
			let n = Te.value;
			n && We.delete(n), rn(), an(), E.value = null, D.value = !1, Oe.clear(), _.value = !1, v.value = !1, y.value = [], Ce.value = -1, b.value = -1, we.value = -1, k = [], F.clear(), C.value = [], w.value = !1, Te.value = "", Ee.value = "", x.value = 0, S.value = 0, P = null, j = null, N = null, Ae = 0, je = 0;
		}, $ = (e = null) => {
			if (!C.value.length) {
				$n();
				return;
			}
			B("DragItemsCompleted", {
				Items: [...C.value],
				DropResult: "None",
				OriginalSource: e
			}), $n();
		}, er = (e) => $(e?.target ?? e?.currentTarget ?? null), tr = (e) => {
			_.value ? er(e) : v.value && Z();
		}, nr;
		he(() => {
			let e = f.value;
			e?.addEventListener(Be, Fn), e?.addEventListener(Ve, In), e?.addEventListener(He, Ln), j = e?.querySelector?.(".win-scroll-viewer-viewport") ?? null, j?.addEventListener?.("scroll", Sn, { passive: !0 }), document.addEventListener("pointermove", Vn), document.addEventListener("pointerup", Hn), document.addEventListener("pointercancel", Un), typeof window < "u" && (window.addEventListener("blur", $), window.addEventListener("dragend", tr)), nr = oe(() => D.value, () => E.value?.pointerId);
		}), me(() => {
			nr?.(), nr = void 0;
			let e = f.value;
			e?.removeEventListener(Be, Fn), e?.removeEventListener(Ve, In), e?.removeEventListener(He, Ln), j?.removeEventListener?.("scroll", Sn), document.removeEventListener("pointermove", Vn), document.removeEventListener("pointerup", Hn), document.removeEventListener("pointercancel", Un), typeof window < "u" && (window.removeEventListener("blur", $), window.removeEventListener("dragend", tr)), $(), Z();
		});
		let rr = ae(f, () => Y.value, () => H.value ? pt.value : [], !0);
		l({
			ScrollIntoGroup: Bt,
			...rr
		});
		let ir = {
			props: u,
			emit: d,
			containerRef: f,
			innerRef: te,
			isDragging: _,
			isExternalDragOver: v,
			dragIndices: y,
			dragOriginIndex: Ce,
			insertSlotIndex: b,
			dragOverIndex: we,
			dragItemWidth: x,
			dragItemHeight: S,
			activeDragItems: C,
			dragDropAccepted: w,
			dragToken: Te,
			externalDragToken: Ee,
			get dragImageElement() {
				return De;
			},
			set dragImageElement(e) {
				De = e;
			},
			get pointerPreviewElement() {
				return T;
			},
			set pointerPreviewElement(e) {
				T = e;
			},
			pointerDrag: E,
			pointerDragActive: D,
			intentionallyReleasedPointerCaptures: Oe,
			get suppressClickUntil() {
				return ke;
			},
			set suppressClickUntil(e) {
				ke = e;
			},
			get anchorIndex() {
				return O;
			},
			set anchorIndex(e) {
				O = e;
			},
			get cachedRects() {
				return k;
			},
			set cachedRects(e) {
				k = e;
			},
			dragLayoutVersion: A,
			get dragScrollViewport() {
				return j;
			},
			set dragScrollViewport(e) {
				j = e;
			},
			get dragLayoutScrollLeft() {
				return Ae;
			},
			set dragLayoutScrollLeft(e) {
				Ae = e;
			},
			get dragLayoutScrollTop() {
				return je;
			},
			set dragLayoutScrollTop(e) {
				je = e;
			},
			DRAG_THRESHOLD: 8,
			EDGE_SCROLL_SIZE: 100,
			EDGE_SCROLL_DELAY: 50,
			EDGE_SCROLL_MIN_SPEED: 150,
			EDGE_SCROLL_MAX_SPEED: Me,
			LIVE_REORDER_DELAY: 300,
			GRID_REORDER_HINT_OFFSET: 16,
			get edgeScrollStartTimer() {
				return Ne;
			},
			set edgeScrollStartTimer(e) {
				Ne = e;
			},
			get edgeScrollFrame() {
				return M;
			},
			set edgeScrollFrame(e) {
				M = e;
			},
			get edgeScrollVelocity() {
				return Pe;
			},
			set edgeScrollVelocity(e) {
				Pe = e;
			},
			get edgeScrollLastTime() {
				return Fe;
			},
			set edgeScrollLastTime(e) {
				Fe = e;
			},
			get edgeScrollViewport() {
				return N;
			},
			set edgeScrollViewport(e) {
				N = e;
			},
			get latestPointerPosition() {
				return P;
			},
			set latestPointerPosition(e) {
				P = e;
			},
			reorderOffsets: F,
			liveInsertSlotIndex: Ie,
			get pendingLiveInsertIndex() {
				return Le;
			},
			set pendingLiveInsertIndex(e) {
				Le = e;
			},
			get pendingLiveSourceIndices() {
				return Re;
			},
			set pendingLiveSourceIndices(e) {
				Re = e;
			},
			get liveReorderTimer() {
				return I;
			},
			set liveReorderTimer(e) {
				I = e;
			},
			pointerDragOwner: ze,
			pointerDragOverEvent: Be,
			pointerDragLeaveEvent: Ve,
			pointerDropEvent: He,
			get pointerDragDetail() {
				return L;
			},
			set pointerDragDetail(e) {
				L = e;
			},
			get pointerDropTarget() {
				return R;
			},
			set pointerDropTarget(e) {
				R = e;
			},
			groupElements: Ue,
			gridDragRegistry: We,
			slots: Ge,
			attrs: Ke,
			instance: z,
			raiseDragEvent: B,
			inheritedScrollTemplateScope: qe,
			ScrollSettings: Je,
			SelectionCheck: Ye,
			slotNodes: Xe,
			flowDirectionStyle: Ze,
			pageResources: Qe,
			directChildren: $e,
			typeName: et,
			flattenTemplateNodes: tt,
			templateKey: nt,
			selectedTemplateKey: rt,
			itemTemplateNodes: it,
			itemContainerStyle: at,
			itemStyle: ot,
			panelDimension: st,
			itemsPanelStyle: ct,
			cssLength: V,
			xamlThickness: lt,
			backgroundStyle: ut,
			rootStyle: dt,
			contentPaddingStyle: ft,
			items: pt,
			configuredIsGrouped: mt,
			isGrouped: H,
			isEnabled: U,
			isItemClickEnabled: ht,
			canDragItems: gt,
			canReorderItems: W,
			allowDrop: G,
			canStartPointerDrag: _t,
			dragVisualActive: K,
			selectionMode: q,
			internalItems: vt,
			get pendingItemsSource() {
				return J;
			},
			set pendingItemsSource(e) {
				J = e;
			},
			get lastItemsSource() {
				return yt;
			},
			set lastItemsSource(e) {
				yt = e;
			},
			sameItems: bt,
			flatItems: Y,
			internalSelectedItems: xt,
			configuredSelectedItems: St,
			selectedItems: X,
			initialSelectedIndex: Ct,
			focusedIndex: wt,
			getItemKey: Tt,
			getGroupItems: Et,
			getGroupKey: Dt,
			getGroupTitle: Ot,
			isSameItem: kt,
			isSelected: At,
			getFlatIndex: jt,
			itemTabIndex: Mt,
			onItemFocus: Nt,
			itemComponentCache: Pt,
			groupHeaderTemplateNodes: Ft,
			groupHeaderComponentCache: It,
			groupHeaderComponent: Lt,
			itemComponent: Rt,
			setGroupElement: zt,
			ScrollIntoGroup: Bt,
			onGroupHeaderClick: Vt,
			emitSelection: Ht,
			onCheckboxToggle: Ut,
			invokeItemClick: Wt,
			onItemClick: Gt,
			itemsPanelDefinition: Kt,
			geometryNavigationIndex: qt,
			navigationIndex: Jt,
			selectFromKeyboard: Yt,
			onItemKeyDown: Xt,
			cacheNonDragRects: Zt,
			shiftCachedLayoutForScroll: Qt,
			readGridDragPayload: $t,
			isReorderTarget: en,
			reorderTransform: tn,
			reorderHintStyle: nn,
			removeDragImage: rn,
			removePointerPreview: an,
			createPointerPreview: on,
			createDragImage: sn,
			gridOrientation: cn,
			gridRowsOrColumns: ln,
			calcInsertSlot: un,
			pointerGridOverIndex: dn,
			flatList: fn,
			clearExternalDropVisual: Z,
			normalizeOwnInsertIndex: pn,
			collectionInsertIndex: mn,
			updateInsertSlot: hn,
			stopEdgeAutoScroll: gn,
			findPointerViewport: _n,
			computeEdgeScrollVelocity: vn,
			recalculateGridDragTarget: yn,
			runEdgeAutoScroll: bn,
			updateEdgeAutoScroll: xn,
			onDragViewportScroll: Sn,
			updateReorderOffsets: Cn,
			clearLiveReorderTimer: wn,
			applyLiveReorder: Tn,
			scheduleLiveReorder: En,
			flushLiveReorder: Dn,
			clearLiveReorder: On,
			onDragStart: kn,
			releasePointerCapture: An,
			startPointerDrag: jn,
			onItemPointerDown: Mn,
			onItemPointerMove: Nn,
			updatePointerDropTarget: Pn,
			clearPointerGridVisual: Q,
			onPointerGridDragOver: Fn,
			onPointerGridDragLeave: In,
			onPointerGridDrop: Ln,
			onItemPointerUp: Rn,
			onItemPointerCancel: zn,
			onItemLostPointerCapture: Bn,
			onGlobalPointerMove: Vn,
			onGlobalPointerUp: Hn,
			onGlobalPointerCancel: Un,
			onContainerDragEnter: Wn,
			onContainerDragOver: Gn,
			onItemDragEnter: Kn,
			onItemDragOver: qn,
			onContainerDragLeave: Jn,
			onContainerDrop: Yn,
			performReorder: Xn,
			completeExternalSourceDrop: Zn,
			performExternalDrop: Qn,
			resetDrag: $n,
			cancelDrag: $,
			onDragEnd: er,
			onWindowDragEnd: tr,
			get detachSecondaryTouchScroll() {
				return nr;
			},
			set detachSecondaryTouchScroll(e) {
				nr = e;
			},
			semanticView: rr,
			ScrollViewer: ne,
			get vAcrylicBrush() {
				return o;
			}
		};
		return Object.defineProperty(ir, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), ir;
	}
});
//#endregion
export { _ as default };

//# sourceMappingURL=GridView.vue_vue_type_script_setup_true_lang.js.map