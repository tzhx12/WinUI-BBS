import { useAcrylicBrushStyle as e } from "./AcrylicBrush.js";
import { materializeXamlVNode as t, resolveXamlHandler as n, resolveXamlValue as r, updateXamlBinding as i, xamlItemContextKey as a, xamlScopeKey as o } from "./xamlRuntime.js";
import { vAcrylicBrush as s } from "./acrylicBrushVisual.js";
import c from "../_virtual/_plugin-vue_export-helper.js";
import { xamlResourceDictionaryKey as l } from "./Page.vue_vue_type_script_lang.js";
import { CollectionItemTemplate as u, CollectionLayout as d, getCollectionProperty as f, getLayoutDescriptor as p, getVNodeChildren as m } from "./CollectionProperties.js";
import ee from "./TextBlock.vue.js";
import { itemContainerControllerKey as te, itemsViewElementKey as ne, itemsViewItemContextKey as re } from "./ItemsViewState.js";
import ie from "./ScrollView.vue.js";
/* empty css                                                              */
import { Fragment as ae, computed as h, createElementBlock as oe, createElementVNode as se, createVNode as g, defineComponent as ce, getCurrentInstance as le, h as _, inject as ue, isVNode as de, nextTick as fe, normalizeClass as v, normalizeStyle as y, onBeforeUnmount as pe, onMounted as me, openBlock as he, provide as b, ref as x, shallowRef as ge, toRaw as S, useAttrs as _e, useSlots as ve, watch as C, withCtx as w, withDirectives as ye } from "vue";
//#region src/components/ItemsView.vue
var be = /*@__PURE__*/ Object.assign({
	ItemTemplate: u,
	Layout: d
}, {
	__name: "ItemsView",
	props: {
		ItemsSource: {
			type: [
				String,
				Array,
				Object
			],
			default: () => []
		},
		ItemTemplate: {
			type: [
				String,
				Object,
				Function
			],
			default: void 0
		},
		ItemTemplateSelector: {
			type: [
				String,
				Object,
				Function
			],
			default: void 0
		},
		Layout: {
			type: [String, Object],
			default: "StackLayout"
		},
		SelectionMode: {
			type: String,
			default: "Single",
			validator: (e) => typeof e == "string" && (e.startsWith("{") || [
				"None",
				"Single",
				"Multiple",
				"Extended"
			].includes(e))
		},
		SelectedItem: {
			type: null,
			default: void 0
		},
		SelectedItems: {
			type: [String, Array],
			default: () => []
		},
		IsItemInvokedEnabled: {
			type: [Boolean, String],
			default: !1
		},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		IsTabStop: {
			type: [Boolean, String],
			default: !0
		},
		TabNavigation: {
			type: String,
			default: "Once"
		},
		FlowDirection: {
			type: String,
			default: "LeftToRight"
		},
		Width: {
			type: [String, Number],
			default: void 0
		},
		Height: {
			type: [String, Number],
			default: void 0
		},
		MinWidth: {
			type: [String, Number],
			default: void 0
		},
		MinHeight: {
			type: [String, Number],
			default: void 0
		},
		MaxWidth: {
			type: [String, Number],
			default: void 0
		},
		MaxHeight: {
			type: [String, Number],
			default: void 0
		},
		Margin: {
			type: [String, Number],
			default: ""
		},
		Padding: {
			type: [String, Number],
			default: ""
		},
		Background: {
			type: [String, Object],
			default: "Transparent"
		},
		BorderBrush: {
			type: String,
			default: ""
		},
		BorderThickness: {
			type: [String, Number],
			default: ""
		},
		CornerRadius: {
			type: [String, Number],
			default: "4"
		},
		HorizontalAlignment: {
			type: String,
			default: "Stretch"
		},
		VerticalAlignment: {
			type: String,
			default: "Stretch"
		}
	},
	emits: [
		"ItemInvoked",
		"SelectionChanged",
		"update:SelectedItem",
		"update:SelectedItems"
	],
	setup(c, { expose: oe, emit: se }) {
		let g = c, v = se, y = _e(), he = ve(), w = le(), ye = x(null), be = x(null);
		b(o, {
			...ue(o, {}),
			get ScrollContentOrientation() {
				return j.value && k.value.Orientation === "Horizontal" ? "Horizontal" : "Vertical";
			},
			get ScrollTemplateHeight() {
				return Fe.value;
			},
			get ScrollTemplateIsEnabled() {
				return F.value;
			}
		});
		let xe = x(null), Se = h(() => r(g.FlowDirection, w)), T = ge([]), Ce = () => (T.value = he.default?.() ?? [], { disabled: !F.value }), E = ue(l, null), D = (e) => {
			let t = e?.type;
			return typeof t == "string" ? t : t?.name || t?.__name || "";
		}, we = (e) => {
			if (!e) return [];
			if (Array.isArray(e.children)) return e.children;
			if (e.children && typeof e.children == "object") {
				let t = e.children.default;
				return typeof t == "function" ? t() : [];
			}
			return [];
		}, Te = (e) => {
			let t = e?.props ?? {}, n = t["x:Key"] ?? t["x:key"] ?? t.Key ?? t.key;
			return typeof n == "string" ? n : "";
		}, Ee = h(() => {
			let e = r(g.ItemTemplate, w);
			if (typeof e != "string") return "";
			let t = e.match(/^\{\s*StaticResource\s+([^\s}]+)\s*\}$/i);
			if (t) return t[1];
			let n = e.match(/^var\(--([^,)]+)\)$/);
			return n ? n[1] : E?.[e] ? e : "";
		}), De = h(() => {
			for (let e of T.value) if (f(e) === "itemTemplate") {
				let t = m(e), n = Ee.value, r = t.filter((e) => /DataTemplate$/i.test(D(e)));
				return r.length ? m((n ? r.find((e) => Te(e) === n) : r[0]) ?? r[0]) : t;
			}
			return [];
		}), O = h(() => {
			for (let e of T.value) if (f(e) === "layout") return m(e);
			return [];
		}), k = h(() => {
			let e = r(g.Layout, w), t = typeof e == "object" && e ? e : null, n = O.value.find((t) => D(t) === e), i = t ?? (n ? p([n]) : O.value.length ? p([O.value[0]]) : e), a = typeof i == "object" && i ? Object.fromEntries(Object.entries(i).map(([e, t]) => [e, r(t, w)])) : { Type: i };
			return {
				Type: a.Type ?? "StackLayout",
				Orientation: a.Orientation ?? (a.Type === "UniformGridLayout" ? "Horizontal" : "Vertical"),
				Spacing: Number(a.Spacing ?? 0),
				MinItemWidth: a.MinItemWidth === void 0 ? NaN : Number(a.MinItemWidth),
				MinItemHeight: a.MinItemHeight === void 0 ? NaN : Number(a.MinItemHeight),
				MinRowSpacing: Number(a.MinRowSpacing ?? 0),
				MinColumnSpacing: Number(a.MinColumnSpacing ?? 0),
				ItemsStretch: a.ItemsStretch ?? "None",
				ItemsJustification: a.ItemsJustification ?? "Start",
				MaximumRowsOrColumns: a.MaximumRowsOrColumns === void 0 ? -1 : Number(a.MaximumRowsOrColumns),
				LineHeight: a.LineHeight === void 0 ? NaN : Number(a.LineHeight),
				LineSpacing: Number(a.LineSpacing ?? 0),
				MinItemSpacing: Number(a.MinItemSpacing ?? 0)
			};
		}), A = h(() => k.value.Type), j = h(() => A.value === "StackLayout"), Oe = h(() => A.value === "UniformGridLayout"), ke = h(() => A.value === "LinedFlowLayout"), Ae = h(() => [
			`layout-${A.value.toLowerCase()}`,
			k.value.Orientation === "Horizontal" ? "orientation-horizontal" : "orientation-vertical",
			k.value.ItemsStretch === "Fill" ? "items-stretch-fill" : ""
		]), je = h(() => {
			let e = k.value, t = {
				"--items-view-spacing": `${e.Spacing}px`,
				"--items-view-min-item-width": Number.isNaN(e.MinItemWidth) ? "0px" : `${e.MinItemWidth}px`,
				"--items-view-min-item-height": Number.isNaN(e.MinItemHeight) ? "0px" : `${e.MinItemHeight}px`,
				"--items-view-row-spacing": `${e.MinRowSpacing}px`,
				"--items-view-column-spacing": `${e.MinColumnSpacing}px`,
				"--items-view-line-height": Number.isNaN(e.LineHeight) ? "auto" : `${e.LineHeight}px`,
				"--items-view-line-spacing": `${e.LineSpacing}px`,
				"--items-view-min-item-spacing": `${e.MinItemSpacing}px`
			};
			return t.margin = Pe(r(g.Padding, w)), Oe.value && Object.assign(t, Ze.value), t;
		}), M = h(() => r(g.SelectionMode, w) ?? "Single"), N = h(() => M.value !== "None"), Me = h(() => M.value === "Multiple" || M.value === "Extended"), P = h(() => r(g.IsItemInvokedEnabled, w) === !0), F = h(() => r(g.IsEnabled, w) !== !1), Ne = ge(void 0), I = h(() => {
			let e = Ne.value ?? r(g.ItemsSource, w);
			return Array.isArray(e) ? e : [];
		});
		C(() => r(g.ItemsSource, w), () => {
			Ne.value = void 0;
		});
		let L = (e) => {
			if (!(e == null || e === "")) return typeof e == "number" || /^-?\d+(?:\.\d+)?$/.test(String(e)) ? `${e}px` : String(e);
		}, Pe = (e) => {
			let t = String(e ?? "").split(",").map((e) => L(e.trim())).filter(Boolean);
			if (t.length === 1) return t[0];
			if (t.length === 2) return `${t[1]} ${t[0]}`;
			if (t.length === 4) return `${t[1]} ${t[2]} ${t[3]} ${t[0]}`;
		}, Fe = h(() => {
			let e = r(g.Height, w);
			if (!(e == null || e === "" || e === "Auto") || !j.value || k.value.Orientation !== "Horizontal") return "100%";
			let t = Math.max(0, Number(r(g.MinHeight, w)) || 0), n = Number(r(g.MaxHeight, w)), i = Math.max(t, qe.value);
			return Number.isFinite(n) && n > 0 ? Math.max(t, Math.min(n, i)) : i;
		}), Ie = e(() => g.Background === "Transparent" ? void 0 : g.Background || void 0, w), Le = h(() => {
			let e = Pe(r(g.BorderThickness, w));
			return {
				width: L(r(g.Width, w)),
				height: L(r(g.Height, w)),
				minWidth: L(r(g.MinWidth, w)),
				minHeight: L(j.value && k.value.Orientation === "Horizontal" && typeof Fe.value == "number" ? Fe.value : r(g.MinHeight, w)),
				maxWidth: L(r(g.MaxWidth, w)),
				maxHeight: L(r(g.MaxHeight, w)),
				margin: Pe(r(g.Margin, w)),
				borderColor: r(g.BorderBrush, w) || void 0,
				borderWidth: e,
				borderStyle: e ? "solid" : void 0,
				borderRadius: L(r(g.CornerRadius, w)),
				...Ie.value
			};
		}), Re = 0, ze = (e) => ({
			item: e,
			key: ++Re
		}), R = ge(I.value.map(ze)), z = x([]), Be = h(() => z.value.map((e) => R.value[e]?.item));
		function Ve(e, t) {
			return S(e) === S(t);
		}
		let He = (e) => {
			let t = /* @__PURE__ */ new Set();
			return e.flatMap((e) => {
				let n = R.value.findIndex((n, r) => !t.has(r) && Ve(n.item, e));
				return n < 0 ? [] : (t.add(n), [n]);
			});
		}, Ue = h(() => {
			let e = r(g.SelectedItems, w), t = Array.isArray(e) ? e : [];
			if (M.value === "Single") {
				let e = r(g.SelectedItem, w);
				return e === void 0 ? t : [e];
			}
			return t;
		});
		C(Ue, (e) => {
			let t = He(e.filter((e) => e != null));
			z.value = M.value === "Single" ? t.slice(0, 1) : t;
		}, { immediate: !0 });
		let B = (e) => z.value.includes(e), V = /* @__PURE__ */ new Map(), We = x(0), H = /* @__PURE__ */ new Map(), Ge = (e) => {
			We.value;
			let t = H.get(e);
			if (t) return t;
			let n = NaN, i = 0, a = Infinity, o = NaN, s = e && typeof e == "object" ? {
				item: e,
				Item: e,
				...e
			} : { item: e }, c = (e) => {
				if (e == null || e === "") return NaN;
				let t = Number(r(e, w, s));
				return Number.isFinite(t) ? t : NaN;
			}, l = (e) => {
				for (let t of e) {
					if (!t || typeof t != "object") continue;
					let e = t.props ?? {}, u = c(e.Width);
					c(e.Height);
					let d = c(e.MinWidth), f = c(e.MaxWidth);
					if (Number.isFinite(u) && (n = Number.isFinite(n) ? Math.max(n, u) : u), Number.isFinite(d) && (i = Math.max(i, d)), Number.isFinite(f) && (a = Math.min(a, f)), !Number.isFinite(u) && /image/i.test(D(t))) {
						let t = e.Source ? r(e.Source, w, s) : "", n = typeof t == "string" ? V.get(t) : null;
						if (n?.height) {
							let e = n.width / n.height;
							Number.isFinite(e) && e > 0 && !Number.isFinite(o) && (o = e);
						}
					}
					l(we(t));
				}
			};
			l(ft.value);
			let u = {
				width: n,
				minWidth: i,
				maxWidth: a,
				aspectRatio: o
			};
			return H.set(e, u), u;
		}, Ke = x(0), qe = x(0), U, W, Je = () => {
			let e = /* @__PURE__ */ new Set();
			for (let t of I.value) t && typeof t == "object" && typeof t.ImageLocation == "string" && t.ImageLocation && e.add(t.ImageLocation);
			for (let t of e) {
				if (V.has(t)) continue;
				V.set(t, null);
				let e = new Image();
				e.onload = () => {
					V.set(t, {
						width: e.naturalWidth,
						height: e.naturalHeight
					}), H.clear(), We.value += 1;
				}, e.src = t;
			}
		}, Ye = h(() => {
			let e = k.value, t = Ke.value, n = e.MinItemSpacing, r = Number.isNaN(e.LineHeight) ? 0 : e.LineHeight;
			if (!t || !r || !I.value.length) return [];
			let i = I.value.map((e) => Ge(e)), a = i.map((e) => Number.isFinite(e.width) && e.width > 0 ? Math.max(e.width, e.minWidth) : Number.isFinite(e.aspectRatio) && e.aspectRatio > 0 ? e.aspectRatio * r : r), o = (e, t) => {
				let n = Math.max(t.minWidth, e);
				return Number.isFinite(t.maxWidth) && (n = Math.min(t.maxWidth, n)), n;
			}, s = [], c = [], l = 0;
			a.forEach((e, r) => {
				c.length && l + n + e > t && (s.push({
					start: c[0],
					count: c.length,
					width: l
				}), c = [], l = 0), l += (c.length ? n : 0) + e, c.push(r);
			}), c.length && s.push({
				start: c[0],
				count: c.length,
				width: l
			});
			let u = e.ItemsStretch === "Fill";
			return s.map((e, c) => {
				let l = Array.from({ length: e.count }, (t, n) => e.start + n), d = e.count > 1 ? (e.count - 1) * n : 0, f = e.width - d, p = c === s.length - 1, m = 1;
				if (f > 0 && e.width > t) {
					let e = (t - d) / f;
					l.every((t) => o(a[t] * e, i[t]) === a[t] * e) && (m = e);
				} else if (f > 0 && u && !p && e.width < t) {
					let e = /* @__PURE__ */ new Set(), n = t - d, r = f, o = 1;
					for (let t = 0; t <= l.length && !(r <= 0); t += 1) {
						o = n / r;
						let t = !1;
						for (let s of l) {
							if (e.has(s)) continue;
							let c = a[s] * o;
							Number.isFinite(i[s].maxWidth) && i[s].maxWidth < c && (n -= i[s].maxWidth, r -= a[s], e.add(s), t = !0);
						}
						if (!t) break;
					}
					o > 1 && (m = o);
				}
				let ee = l.map((e) => o(a[e] * m, i[e]));
				return {
					start: e.start,
					count: e.count,
					itemWidths: ee,
					lineHeight: r
				};
			});
		}), Xe = (e) => {
			let t = Ye.value.find((t) => e >= t.start && e < t.start + t.count);
			if (!t) return;
			let n = t.itemWidths[e - t.start];
			return {
				width: `${n}px`,
				height: `${t.lineHeight}px`,
				flex: `0 0 ${n}px`
			};
		}, Ze = h(() => {
			let e = k.value, t = Ke.value, n = e.MinColumnSpacing, r = Number.isNaN(e.MinItemWidth) ? 0 : e.MinItemWidth, i = I.value.length ? Ge(I.value[0]) : {
				width: NaN,
				minWidth: 0
			}, a = r > 0 ? r : i.width;
			(!Number.isFinite(a) || a <= 0) && (a = 150);
			let o = Math.max(1, e.MaximumRowsOrColumns > 0 ? e.MaximumRowsOrColumns : 2 ** 53 - 1);
			if (t > 0) {
				let e = Math.floor((t + n) / (a + n));
				o = Math.min(o, Math.max(1, e));
			}
			o === 2 ** 53 - 1 && (o = 1);
			let s = a;
			if (e.ItemsStretch === "Fill" && t > 0) {
				let e = o * (a + n) - n, r = Math.trunc(t - e);
				s = a + Math.trunc(r / o);
			}
			let c = { "--items-view-uniform-column": `${s}px` };
			return e.ItemsStretch === "Fill" && t > 0 ? c.gridTemplateColumns = `repeat(${o}, ${s}px)` : c.gridTemplateColumns = `repeat(${o}, minmax(${a}px, max-content))`, c;
		}), Qe = (e) => ke.value ? Xe(e) : void 0, G = x(-1), K = x(-1), q = {
			ctrl: !1,
			shift: !1
		}, J = (e) => {
			q.ctrl = !!(e.ctrlKey || e.metaKey), q.shift = !!e.shiftKey;
		}, $e = () => {
			q.ctrl = !1, q.shift = !1;
		}, Y = (e) => {
			let t = R.value[e]?.item;
			return !F.value || t == null ? !1 : typeof t != "object" || t.IsEnabled !== !1 && t.IsEnabled !== "False";
		}, X = (e) => {
			let t = R.value[e]?.item;
			return Y(e) ? typeof t != "object" || t.IsTabStop !== !1 && t.IsTabStop !== "False" && t.Visibility !== "Collapsed" && t.Visibility !== "Hidden" : !1;
		}, et = (e) => !X(e) || r(g.IsTabStop, w) === !1 || !N.value && !P.value ? -1 : e === (X(G.value) ? G.value : R.value.findIndex((e, t) => X(t))) ? 0 : -1, tt = (e) => [...new Set(e.filter((e) => Number.isInteger(e) && e >= 0 && e < R.value.length))].sort((e, t) => e - t), Z = (e, t, r = null) => {
			let a = r?.records ?? R.value, o = r?.indices ?? z.value, s = tt(e), c = o.map((e) => a[e]).filter(Boolean), l = s.map((e) => R.value[e]), u = l.filter((e) => !c.includes(e)), d = c.filter((e) => !l.includes(e));
			if (z.value = s, !u.length && !d.length) return;
			let f = l.map((e) => e.item), p = {
				AddedItems: u.map((e) => e.item),
				RemovedItems: d.map((e) => e.item),
				SelectedItems: f,
				OriginalSource: t
			};
			v("update:SelectedItems", f), v("update:SelectedItem", f[0] ?? null), i(g.SelectedItem, f[0] ?? null, w), i(g.SelectedItems, f, w);
			let m = w?.exposeProxy ?? w?.proxy;
			v("SelectionChanged", m, p), n(y.SelectionChanged, w)?.(m, p);
		}, Q = (e, t) => Array.from({ length: Math.abs(t - e) + 1 }, (n, r) => Math.min(e, t) + r), nt = (e, t) => {
			Z(t && B(e) ? [] : [e], R.value[e].item), K.value = e;
		}, rt = (e, t) => {
			let n = z.value, r = R.value[e].item;
			if (t) {
				let t = K.value;
				if (t >= 0 && B(t) !== B(e)) {
					let i = Q(t, e);
					Z(B(t) ? [...n, ...i] : n.filter((e) => !i.includes(e)), r);
				}
				return;
			}
			Z(B(e) ? n.filter((t) => t !== e) : [...n, e], r), K.value = e;
		}, it = (e, t, n) => {
			let r = R.value[e].item;
			if (n) {
				let t = K.value;
				t >= 0 && Z(Q(t, e), r);
				return;
			}
			t ? Z(B(e) ? z.value.filter((t) => t !== e) : [...z.value, e], r) : B(e) || Z([e], r), K.value = e;
		}, at = (e, { ctrl: t = !1, shift: n = !1 } = {}) => {
			!N.value || !Y(e) || (M.value === "Single" ? nt(e, t) : M.value === "Multiple" ? rt(e, n) : it(e, t, n));
		}, ot = (e, { ctrl: t = !1, shift: n = !1 } = q) => {
			if (!X(e) || (G.value = e, !N.value)) return;
			let r = R.value[e].item;
			if (M.value === "Single") t || Z([e], r);
			else if (M.value === "Multiple") {
				let t = K.value;
				if (n && t >= 0) {
					let n = Q(t, e);
					Z(B(t) ? [...z.value, ...n] : z.value.filter((e) => !n.includes(e)), r);
				}
			} else if (n) {
				let n = K.value;
				n >= 0 && Z(t ? [...z.value, ...Q(n, e)] : Q(n, e), r);
			} else t || (Z([e], r), K.value = e);
		}, $ = (e) => {
			!Number.isInteger(e) || e < 0 || e >= R.value.length || (Z(M.value === "Single" ? [e] : [...z.value, e], R.value[e].item), K.value = e);
		}, st = (e) => !(!F.value || !P.value || !N.value && e === "DoubleTap" || N.value && (e === "Tap" || e === "SpaceKey")), ct = (e, t, r) => {
			if (!st(t)) return;
			let i = {
				InvokedItem: e,
				OriginalSource: r,
				InteractionTrigger: t
			}, a = w?.exposeProxy ?? w?.proxy;
			v("ItemInvoked", a, i), n(y.ItemInvoked, w)?.(a, i);
		}, lt = (e, t, n) => {
			if (!Y(e)) return;
			let r = R.value[e].item;
			if ([
				"PointerReleased",
				"EnterKey",
				"SpaceKey"
			].includes(t)) G.value = e, at(e, {
				ctrl: !!(n?.ctrlKey || n?.metaKey),
				shift: !!n?.shiftKey
			});
			else if (t !== "Tap" && t !== "DoubleTap") return;
			t !== "PointerReleased" && st(t) && ct(r, t, n?.target);
		}, ut = ce({
			name: "ItemsViewItemTemplate",
			props: { Entry: {
				type: Object,
				required: !0
			} },
			setup(e) {
				let n = () => R.value.findIndex((t) => t.key === e.Entry.key), i = !1, o = (t) => {
					if (i || !N.value) return;
					i = !0;
					let a = e.Entry.item, o = a && typeof a == "object" ? {
						item: a,
						Item: a,
						...a
					} : {
						item: a,
						Item: a
					}, s = a && typeof a == "object" ? a.IsSelected : void 0;
					(s === !0 || s === "True" || t?.props?.IsSelected !== void 0 && r(t.props.IsSelected, w, o) === !0) && $(n());
				};
				return b(a, e.Entry.item), b(re, {
					get index() {
						return n();
					},
					geometry: () => Qe(n()),
					tabIndex: () => et(n())
				}), b(te, {
					isEnabled: () => Y(n()),
					isSelected: () => B(n()),
					selectionMode: () => M.value,
					multiSelectMode: () => M.value,
					canUserInvoke: () => P.value,
					canUserSelect: () => N.value,
					isCurrent: () => n() === G.value,
					setCurrent: (e, t) => {
						G.value = n(), t?.preserveSelection || ot(n());
					},
					itemInvoked: (e, t, r) => lt(n(), t, r)
				}), () => {
					let n = e.Entry.item, r = ft.value;
					if (r.length) {
						let e = t(r, n, w);
						if (!i) {
							let t = e[0];
							if (t) {
								let e = t.props?.onVnodeMounted;
								t.props = {
									...t.props,
									onVnodeMounted: (t) => {
										e?.(t), o(t);
									}
								};
							}
						}
						return _(ae, e);
					}
					if (typeof n?.[ne] == "function") {
						let e = n[ne]();
						if (!i) {
							let t = e.props?.onVnodeMounted;
							e.props = {
								...e.props,
								onVnodeMounted: (e) => {
									t?.(e), o(e);
								}
							};
						}
						return e;
					}
					return de(n) ? n : _(ee, { Text: String(n ?? "") });
				};
			}
		}), dt = ce({
			name: "ItemsViewItemsOutlet",
			setup() {
				return () => _(ae, R.value.map((e) => _(ut, {
					Entry: e,
					key: e.key
				})));
			}
		}), ft = h(() => {
			let e = Ee.value;
			if (e && E?.[e]) return m(E[e]);
			if (e) {
				let e = E?.[`${A.value}ItemTemplate`];
				if (e) return m(e);
			}
			return De.value;
		});
		C(M, () => {
			K.value = -1;
		}), C(I, () => {
			H.clear(), Je();
		}, { immediate: !0 }), me(() => {
			window.addEventListener("keydown", J), window.addEventListener("keyup", J), window.addEventListener("blur", $e);
			let e = xe.value;
			if (!e) return;
			let t = () => {
				Ke.value = e.clientWidth;
				let t = getComputedStyle(e);
				qe.value = e.offsetHeight + (parseFloat(t.marginTop) || 0) + (parseFloat(t.marginBottom) || 0);
			};
			t(), U = new ResizeObserver(() => {
				W === void 0 && (W = requestAnimationFrame(() => {
					W = void 0, t();
				}));
			}), U.observe(e);
		}), pe(() => {
			U?.disconnect(), W !== void 0 && cancelAnimationFrame(W), window.removeEventListener("keydown", J), window.removeEventListener("keyup", J), window.removeEventListener("blur", $e);
		});
		let pt = (e) => {
			let t = R.value;
			if (e.length === t.length && e.every((e, n) => Ve(e, t[n].item))) return;
			let n = [...z.value], r = t[G.value], i = t[K.value], a = /* @__PURE__ */ new Map();
			for (let e of t) {
				let t = S(e.item), n = a.get(t) ?? [];
				n.push(e), a.set(t, n);
			}
			let o = e.map((e) => a.get(S(e))?.shift() ?? ze(e));
			R.value = o, Z(n.map((e) => o.indexOf(t[e])).filter((e) => e >= 0), null, {
				records: t,
				indices: n
			}), G.value = r ? o.indexOf(r) : -1, K.value = i ? o.indexOf(i) : -1;
		};
		C(() => [...I.value], pt);
		let mt = async (e) => {
			G.value = e, await fe();
			let t = xe.value?.children[e];
			t?.focus?.({ preventScroll: !0 }), t?.scrollIntoView?.({
				block: "nearest",
				inline: "nearest"
			});
		}, ht = (e) => {
			if (e.defaultPrevented || !F.value || ![
				"ArrowLeft",
				"ArrowRight",
				"ArrowUp",
				"ArrowDown",
				"Home",
				"End"
			].includes(e.key)) return;
			let t = k.value.Orientation === "Horizontal";
			if (j.value && (t ? ["ArrowUp", "ArrowDown"].includes(e.key) : ["ArrowLeft", "ArrowRight"].includes(e.key))) return;
			let n = R.value.map((e, t) => t).filter(X);
			if (!n.length) return;
			let r = n.indexOf(G.value);
			if (e.key === "Home") r = 0;
			else if (e.key === "End") r = n.length - 1;
			else {
				let i = e.key === "ArrowRight" || e.key === "ArrowDown" ? 1 : -1;
				t && Se.value === "RightToLeft" && (i *= -1), r = Math.max(0, Math.min(n.length - 1, r + i));
			}
			let i = n[r];
			e.preventDefault(), ot(i, {
				ctrl: !!(e.ctrlKey || e.metaKey),
				shift: !!e.shiftKey
			}), mt(i);
		};
		oe({
			get ItemsSource() {
				return I.value;
			},
			set ItemsSource(e) {
				let t = Array.isArray(e) ? e : [];
				pt(t), Ne.value = t;
			},
			get SelectedItem() {
				return Be.value[0] ?? null;
			},
			set SelectedItem(e) {
				if (e == null) Z([], null);
				else {
					let t = R.value.findIndex((t) => Ve(t.item, e));
					t >= 0 && $(t);
				}
			},
			SelectedItems: Be,
			CurrentItemIndex: G,
			ScrollView: be,
			Select: $,
			Deselect: (e) => {
				B(e) && Z(z.value.filter((t) => t !== e), R.value[e]?.item);
			},
			IsSelected: B,
			SelectAll: () => Z(R.value.map((e, t) => t), null),
			DeselectAll: () => Z([], null)
		});
		let gt = {
			props: g,
			emit: v,
			attrs: y,
			slots: he,
			instance: w,
			rootRef: ye,
			scrollViewRef: be,
			repeaterRef: xe,
			flowDirection: Se,
			slotNodes: T,
			prepareRender: Ce,
			pageResources: E,
			typeNameOf: D,
			directChildren: we,
			templateKeyOf: Te,
			selectedTemplateKey: Ee,
			itemTemplateNodes: De,
			layoutNodes: O,
			normalizedLayout: k,
			layoutType: A,
			isStackLayout: j,
			isUniformGridLayout: Oe,
			isLinedFlowLayout: ke,
			layoutClass: Ae,
			repeaterStyle: je,
			resolvedSelectionMode: M,
			isSelectionEnabled: N,
			isMultiSelectMode: Me,
			resolvedIsItemInvokedEnabled: P,
			isEnabled: F,
			localItemsSource: Ne,
			items: I,
			cssLength: L,
			xamlThickness: Pe,
			scrollTemplateHeight: Fe,
			backgroundStyle: Ie,
			rootStyle: Le,
			get realizationKey() {
				return Re;
			},
			set realizationKey(e) {
				Re = e;
			},
			createRecord: ze,
			realizedItems: R,
			selectedIndices: z,
			selectedItemsValue: Be,
			isSameItem: Ve,
			indicesFromValues: He,
			boundSelection: Ue,
			isSelectedIndex: B,
			naturalImageSizes: V,
			imageMetricsVersion: We,
			itemWidthCache: H,
			templateMetricsFor: Ge,
			repeaterWidth: Ke,
			repeaterDesiredHeight: qe,
			get repeaterObserver() {
				return U;
			},
			set repeaterObserver(e) {
				U = e;
			},
			get repeaterMeasureFrame() {
				return W;
			},
			set repeaterMeasureFrame(e) {
				W = e;
			},
			measureImageRatios: Je,
			linedFlowLines: Ye,
			linedFlowStyleFor: Xe,
			uniformGridStyle: Ze,
			containerGeometry: Qe,
			currentItemIndex: G,
			selectionAnchorIndex: K,
			modifierState: q,
			captureModifiers: J,
			clearModifiers: $e,
			itemEnabled: Y,
			focusable: X,
			itemTabIndex: et,
			normalizedIndices: tt,
			raiseSelectionChanged: Z,
			indexRange: Q,
			selectSingle: nt,
			selectMultiple: rt,
			selectExtended: it,
			selectItem: at,
			onFocusedAction: ot,
			selectProgrammatically: $,
			canRaiseItemInvoked: st,
			raiseItemInvoked: ct,
			handleContainerItemInvoked: lt,
			RealizedItem: ut,
			ItemsOutlet: dt,
			activeTemplateNodes: ft,
			reconcileItems: pt,
			focusItem: mt,
			onNavigationKeyDown: ht,
			get CollectionItemTemplate() {
				return u;
			},
			get CollectionLayout() {
				return d;
			},
			computed: h,
			defineComponent: ce,
			Fragment: ae,
			getCurrentInstance: le,
			h: _,
			inject: ue,
			isVNode: de,
			nextTick: fe,
			onBeforeUnmount: pe,
			onMounted: me,
			provide: b,
			ref: x,
			shallowRef: ge,
			toRaw: S,
			useAttrs: _e,
			useSlots: ve,
			watch: C,
			ScrollView: ie,
			TextBlock: ee,
			get useAcrylicBrushStyle() {
				return e;
			},
			get vAcrylicBrush() {
				return s;
			},
			get getCollectionProperty() {
				return f;
			},
			get getLayoutDescriptor() {
				return p;
			},
			get getVNodeChildren() {
				return m;
			},
			get itemsViewItemContextKey() {
				return re;
			},
			get itemContainerControllerKey() {
				return te;
			},
			get itemsViewElementKey() {
				return ne;
			},
			xamlResourceDictionaryKey: l,
			get materializeXamlVNode() {
				return t;
			},
			get resolveXamlHandler() {
				return n;
			},
			get resolveXamlValue() {
				return r;
			},
			get updateXamlBinding() {
				return i;
			},
			get xamlItemContextKey() {
				return a;
			},
			get xamlScopeKey() {
				return o;
			}
		};
		return Object.defineProperty(gt, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), gt;
	}
}), xe = [
	"dir",
	"aria-disabled",
	"aria-multiselectable"
];
function Se(e, t, n, r, i, a) {
	return ye((he(), oe("div", {
		ref: "rootRef",
		class: v(["win-items-view", r.prepareRender()]),
		style: y(r.rootStyle),
		dir: r.flowDirection === "RightToLeft" ? "rtl" : "ltr",
		role: "listbox",
		"aria-disabled": !r.isEnabled,
		"aria-multiselectable": r.isMultiSelectMode || void 0,
		onPointerdownCapture: r.captureModifiers,
		onKeydownCapture: r.captureModifiers,
		onKeyupCapture: r.captureModifiers,
		onKeydown: r.onNavigationKeyDown
	}, [g(r.ScrollView, {
		ref: "scrollViewRef",
		class: "win-items-view-scroll",
		HorizontalAnchorRatio: "NaN",
		VerticalScrollMode: "Auto",
		VerticalScrollBarVisibility: "Auto",
		HorizontalScrollMode: "Auto",
		HorizontalScrollBarVisibility: "Auto",
		ContentOrientation: "{x:Bind ScrollContentOrientation, Mode=OneWay}",
		Height: "{x:Bind ScrollTemplateHeight, Mode=OneWay}",
		IsEnabled: "{x:Bind ScrollTemplateIsEnabled, Mode=OneWay}",
		IsTabStop: "False"
	}, {
		default: w(() => [se("div", {
			ref: "repeaterRef",
			class: v(["win-items-view-repeater", r.layoutClass]),
			style: y(r.repeaterStyle)
		}, [g(r.ItemsOutlet)], 6)]),
		_: 1
	}, 512)], 46, xe)), [[r.vAcrylicBrush, r.backgroundStyle]]);
}
var T = /*#__PURE__*/ c(be, [
	["render", Se],
	["__scopeId", "data-v-3a49b688"],
	["__file", "ItemsView.vue"]
]);
//#endregion
export { T as default };

//# sourceMappingURL=ItemsView.vue.js.map