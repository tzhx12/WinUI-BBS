import { calendarDateFromSerial as e, calendarDateSerial as t, createCalendarModel as n, parseCalendarDate as r } from "./calendarEngine.js";
//#region src/components/datePickerEngine.ts
var i = (i, a, o, s) => {
	let c = t(o), l = t(s), u = n(i, a, Math.min(c, l) - 400, Math.max(c, l) + 400), d = u.yearAt(c).start, f = u.yearAt(l).end, p = o.getTime() <= s.getTime() ? u.years.filter((e) => e.end >= d && e.start <= f) : [], m = (n) => {
		let i = r(n);
		if (!i || !p.length) return null;
		let a = e(Math.max(d, Math.min(f, t(i))));
		return a.setHours(i.getHours(), i.getMinutes(), i.getSeconds(), i.getMilliseconds()), a;
	}, h = (e, t = 1) => new Intl.NumberFormat(a, {
		useGrouping: !1,
		minimumIntegerDigits: t
	}).format(e);
	return {
		calendar: u,
		minimum: d,
		maximum: f,
		years: p,
		coerce: m,
		format: (e, t, n) => {
			let r = (t) => {
				let n = Number(t.match(/\((\d+)\)/)?.[1] ?? 1);
				if (t.startsWith("dayofweek.")) return u.weekdayText(e, t);
				if (t.startsWith("day.")) return h(u.day(e), n);
				if (t.startsWith("month.integer")) {
					let t = u.monthAt(e), r = Number(t.month);
					return h(Number.isFinite(r) ? r : t.index - u.yearAt(e).firstMonth + 1, n);
				}
				if (t.startsWith("month.")) return u.formatSelectedDate(e, { month: t.includes("abbreviated") ? "short" : "long" });
				if (t.startsWith("year.")) {
					let r = u.displayYear(u.yearAt(e));
					return h(t.includes("abbreviated") ? r % 100 : r, t.includes("abbreviated") ? 2 : n);
				}
				return t;
			}, i = t.replace(/^\{\}/, "");
			return i.includes("{") ? i.replace(/\{([^}]+)\}/g, (e, t) => r(t)) : /^(dayofweek|day|month|year)\./.test(i) ? r(i) : r(`${n}.${n === "day" ? "integer" : "full"}`);
		},
		order: new Intl.DateTimeFormat(a, {
			year: "numeric",
			month: "long",
			day: "numeric"
		}).formatToParts(new Date(2026, 9, 4)).filter((e) => [
			"year",
			"month",
			"day"
		].includes(e.type)).map((e) => e.type)
	};
};
//#endregion
export { i as createDatePickerModel };

//# sourceMappingURL=datePickerEngine.js.map