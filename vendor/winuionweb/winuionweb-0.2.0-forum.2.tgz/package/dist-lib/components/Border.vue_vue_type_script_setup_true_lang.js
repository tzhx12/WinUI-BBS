import { xamlThemeKey as e } from "./brushCore.js";
import { normalizeXamlNodes as t, resolveXamlValue as n, updateXamlBinding as r } from "./xamlRuntime.js";
import { frameworkLayoutStyle as i } from "./frameworkLayout.js";
import { collectXamlResources as a, useXamlBrushResources as o } from "./xamlBrushResources.js";
import { brushProperty as s, isBrushProperty as c, useBrushProperty as ee } from "./brushProperties.js";
import { vAcrylicBrush as te } from "./acrylicBrushVisual.js";
import { vRadialGradientBrush as ne } from "./RadialGradientVisual.js";
import { getThemeShadowRecipe as re, isThemeShadow as l, shadowCornerRadius as ie, themeShadowVisualStyle as ae } from "./themeShadowRuntime.js";
import { xamlResourceDictionaryKey as u } from "./Page.vue_vue_type_script_lang.js";
import { Comment as d, Fragment as f, Text as p, cloneVNode as m, computed as h, defineComponent as g, getCurrentInstance as _, h as oe, inject as v, nextTick as y, onBeforeUnmount as se, onMounted as b, provide as x, ref as S, shallowRef as ce, unref as C, useAttrs as w, useSlots as le, watch as T } from "vue";
//#region src/components/Border.vue?vue&type=script&setup=true&lang.ts
var E = g({
	name: "Border.Child",
	__borderChildProperty: !0,
	setup() {
		return () => null;
	}
}), D = g({
	name: "Border.Resources",
	__xamlResourceProperty: "resources",
	setup() {
		return () => null;
	}
}), O = g({
	name: "Border.Shadow",
	__borderShadowProperty: !0,
	setup() {
		return () => null;
	}
}), k = /*@__PURE__*/ g({
	Child: E,
	Resources: D,
	Background: s("Border", "Background"),
	Shadow: O,
	inheritAttrs: !1,
	__name: "Border",
	props: {
		Background: {
			type: [String, Object],
			default: ""
		},
		BackgroundSizing: {
			type: String,
			default: "InnerBorderEdge"
		},
		BorderBrush: {
			type: [String, Object],
			default: ""
		},
		BorderThickness: {
			type: [String, Number],
			default: 0
		},
		CornerRadius: {
			type: [String, Number],
			default: 0
		},
		Padding: {
			type: [String, Number],
			default: 0
		},
		Width: {
			type: [String, Number],
			default: ""
		},
		Height: {
			type: [String, Number],
			default: ""
		},
		MinWidth: {
			type: [String, Number],
			default: 0
		},
		MinHeight: {
			type: [String, Number],
			default: 0
		},
		MaxWidth: {
			type: [String, Number],
			default: ""
		},
		MaxHeight: {
			type: [String, Number],
			default: ""
		},
		Margin: {
			type: [String, Number],
			default: 0
		},
		HorizontalAlignment: {
			type: String,
			default: "Stretch"
		},
		VerticalAlignment: {
			type: String,
			default: "Stretch"
		},
		Visibility: {
			type: String,
			default: "Visible"
		},
		IsHitTestVisible: {
			type: [String, Boolean],
			default: !0
		},
		Opacity: {
			type: [String, Number],
			default: 1
		},
		Translation: {
			type: [String, Object],
			default: () => ({
				X: 0,
				Y: 0,
				Z: 0
			})
		},
		Shadow: {
			type: [String, Object],
			default: null
		}
	},
	emits: [
		"Loaded",
		"update:Translation",
		"update:Shadow"
	],
	setup(s, { expose: k, emit: ue }) {
		let A = s, j = ue, M = w(), N = le(), P = _(), F = S(), I = S(n(A.Translation, P));
		T(() => n(A.Translation, P), (e) => {
			I.value = e;
		});
		let L = h({
			get: () => I.value,
			set: (e) => {
				I.value = e, r(A.Translation, e, P), j("update:Translation", e);
			}
		}), R = ce(), z = h({
			get: () => R.value === void 0 ? n(A.Shadow, P) : R.value,
			set: (e) => {
				R.value = e, r(A.Shadow, e, P), j("update:Shadow", e);
			}
		}), B = v(e, null) ?? v("winuiTheme", null), V = h(() => F.value), H = h(() => l(z.value) && !z.value.IsDisposed), U;
		T([z, F], ([e, t]) => {
			U?.(), U = void 0, t && l(e) && !e.IsDisposed && (U = e.AttachCaster(t));
		}, { flush: "post" }), se(() => U?.()), k({
			Translation: L,
			Shadow: z,
			Element: V
		}), b(async () => {
			await y(), j("Loaded", P?.exposeProxy ?? P?.proxy, { OriginalSource: F.value });
		});
		let W = v(u, {}), G = () => {
			let e = {}, t = (n) => {
				for (let r of n) r.type === f && Array.isArray(r.children) ? t(r.children) : a([r], e);
			};
			for (let e of N.default?.() ?? []) e.type?.__xamlResourceProperty && t(e.children?.default?.() ?? []);
			return e;
		}, K = h(G);
		x(u, new Proxy(W, { get: (e, t) => K.value[t] ?? e[t] }));
		let q = o(P), J = ee("Background", () => A.Background, () => N.default?.() ?? [], P), Y = h(() => {
			let e = L.value, t = e && typeof e == "object" ? e : void 0, n = typeof e == "string" ? e.split(",").map(Number) : [
				t?.X ?? 0,
				t?.Y ?? 0,
				t?.Z ?? 0
			];
			return { transform: Number(n[0]) || Number(n[1]) ? `translate(${Number(n[0]) || 0}px, ${Number(n[1]) || 0}px)` : void 0 };
		}), X = S(0), Z = () => {
			let e = F.value;
			for (; e;) {
				let t = getComputedStyle(e), n = Math.max(...[
					"borderTopLeftRadius",
					"borderTopRightRadius",
					"borderBottomRightRadius",
					"borderBottomLeftRadius"
				].map((e) => Number.parseFloat(t[e]) || 0));
				if (n > 0) {
					X.value = n;
					return;
				}
				e = e.parentElement ?? void 0;
			}
			X.value = 0;
		};
		b(Z), T([() => n(A.CornerRadius, P), () => C(B)], () => {
			y(Z);
		});
		let de = h(() => {
			let e = L.value, t = typeof e == "string" ? e.split(",")[2] : e && typeof e == "object" && "Z" in e ? e.Z : 0, r = ie(n(A.CornerRadius, P)) || X.value;
			return ae(re(t, C(B)), r);
		}), Q = h(() => ({
			...i(A, P),
			...J.style.value,
			...Y.value
		})), $ = {
			BorderChild: E,
			BorderResources: D,
			BorderShadow: O,
			props: A,
			emit: j,
			attrs: M,
			slots: N,
			instance: P,
			root: F,
			currentTranslation: I,
			Translation: L,
			shadow: R,
			Shadow: z,
			theme: B,
			Element: V,
			hasThemeShadow: H,
			get detachCaster() {
				return U;
			},
			set detachCaster(e) {
				U = e;
			},
			inheritedResources: W,
			collectResources: G,
			resourceNodes: K,
			brushResources: q,
			backgroundBrush: J,
			shadowStyle: Y,
			inheritedCornerRadius: X,
			measureCornerRadius: Z,
			shadowVisualStyle: de,
			borderStyle: Q,
			resolveBorderStyle: () => (q.sync(G()), Q.value),
			ShadowOutlet: g({ setup() {
				return () => {
					let e = (N.default?.() ?? []).find((e) => e.type?.__borderShadowProperty);
					return oe(f, t(e ? e.children?.default?.() ?? [] : [], P).map((e) => m(e, { ref: (e) => {
						R.value = e;
					} }, !0)));
				};
			} }),
			ChildOutlet: g({ setup() {
				return () => {
					let e = [], n = (t) => {
						for (let r of t) r.type === d || r.type === p && !String(r.children ?? "").trim() || r.type?.__xamlResourceProperty || r.type?.__borderShadowProperty || c(r) || (r.type === f && Array.isArray(r.children) ? n(r.children) : r.type?.__borderChildProperty ? n(r.children?.default?.() ?? []) : e.push(r));
					};
					if (n(N.default?.() ?? []), e.length > 1) throw Error("Border.Child must contain a single UIElement.");
					return e.length ? t(e, P)[0] : null;
				};
			} }),
			get vAcrylicBrush() {
				return te;
			},
			get vRadialGradientBrush() {
				return ne;
			}
		};
		return Object.defineProperty($, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), $;
	}
});
//#endregion
export { E as BorderChild, D as BorderResources, O as BorderShadow, k as default };

//# sourceMappingURL=Border.vue_vue_type_script_setup_true_lang.js.map