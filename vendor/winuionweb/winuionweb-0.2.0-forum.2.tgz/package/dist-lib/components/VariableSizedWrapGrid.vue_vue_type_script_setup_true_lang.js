import { alignment as e, attachedValue as t, cssLength as n, useLayoutObserver as r, xamlThickness as i } from "./layout.js";
import { normalizeXamlNodes as a, resolveXamlValue as o, updateXamlBinding as s } from "./xamlRuntime.js";
import { Fragment as c, cloneVNode as l, computed as u, defineComponent as d, getCurrentInstance as f, nextTick as p, onBeforeUnmount as m, onMounted as h, ref as g, useSlots as _, watch as v } from "vue";
//#region src/components/VariableSizedWrapGrid.vue?vue&type=script&setup=true&lang.ts
var y = d({
	name: "VariableSizedWrapGrid.Resources",
	setup() {
		return () => null;
	}
}), b = /*@__PURE__*/ d({
	Resources: y,
	__name: "VariableSizedWrapGrid",
	props: {
		Orientation: {
			type: String,
			default: "Vertical"
		},
		ItemWidth: {
			type: [String, Number],
			default: NaN
		},
		ItemHeight: {
			type: [String, Number],
			default: NaN
		},
		MaximumRowsOrColumns: {
			type: [String, Number],
			default: -1
		},
		HorizontalChildrenAlignment: {
			type: String,
			default: "Left"
		},
		VerticalChildrenAlignment: {
			type: String,
			default: "Top"
		},
		Width: {
			type: [String, Number],
			default: ""
		},
		Height: {
			type: [String, Number],
			default: ""
		},
		MinWidth: {
			type: [String, Number],
			default: 0
		},
		MinHeight: {
			type: [String, Number],
			default: 0
		},
		MaxWidth: {
			type: [String, Number],
			default: ""
		},
		MaxHeight: {
			type: [String, Number],
			default: ""
		},
		Background: {
			type: [String, Object],
			default: ""
		},
		Margin: {
			type: [String, Number],
			default: ""
		},
		HorizontalAlignment: {
			type: String,
			default: "Stretch"
		},
		VerticalAlignment: {
			type: String,
			default: "Stretch"
		}
	},
	emits: ["update:Orientation"],
	setup(d, { expose: b, emit: x }) {
		let S = d, C = f(), w = x, T = _(), E = g(null), D = (e) => o(e, C), O = g(null), k = u({
			get: () => O.value ?? String(D(S.Orientation) ?? "Vertical"),
			set: (e) => {
				e !== "Vertical" && e !== "Horizontal" || (O.value = e, s(S.Orientation, e, C), w("update:Orientation", e));
			}
		});
		v(() => D(S.Orientation), () => {
			O.value = null;
		}), b({ Orientation: k });
		let A = (e) => {
			let t = e.type;
			return typeof t == "string" ? t : t?.name ?? t?.__name ?? "";
		}, j = (e) => Array.isArray(e.children) ? e.children : e.children?.default?.() ?? [], M = (e) => e.flatMap((e) => e.type === c ? M(j(e)) : [e]), N = () => {
			let e = M(T.default?.() ?? []), t = {};
			for (let n of e.filter((e) => A(e) === "VariableSizedWrapGrid.Resources")) for (let e of M(j(n))) {
				if (A(e) !== "Style" || e.props?.["x:Key"]) continue;
				let n = String(e.props?.TargetType ?? "").split(":").pop() ?? "", r = {};
				for (let t of M(j(e))) A(t) === "Setter" && typeof t.props?.Property == "string" && (r[t.props.Property] = D(t.props.Value));
				t[n] = r;
			}
			let n = (e) => {
				let r = l(e, {
					...t[A(e)],
					...e.props
				});
				if (Array.isArray(e.children)) r.children = e.children.map((e) => e && typeof e == "object" && "type" in e ? n(e) : e);
				else if (e.children && typeof e.children == "object") {
					let t = { ...e.children };
					for (let [e, r] of Object.entries(t)) typeof r == "function" && (t[e] = (...e) => r(...e).map(n));
					r.children = t;
				}
				return r;
			};
			return a(e.filter((e) => A(e) !== "VariableSizedWrapGrid.Resources").map(n), C);
		}, P = u(() => {
			let t = {};
			for (let [e, r] of Object.entries({
				Width: S.Width,
				Height: S.Height,
				MinWidth: S.MinWidth,
				MinHeight: S.MinHeight,
				MaxWidth: S.MaxWidth,
				MaxHeight: S.MaxHeight
			})) {
				let i = D(r);
				i !== "" && i != null && !Number.isNaN(Number(i)) && (t[e[0].toLowerCase() + e.slice(1)] = n(i));
			}
			let r = D(S.Background);
			r && (t.background = String(r));
			let a = D(S.Margin);
			return a !== "" && a != null && (t.margin = i(a)), t.justifySelf = e(D(S.HorizontalAlignment), "horizontal"), t.alignSelf = e(D(S.VerticalAlignment), "vertical"), t;
		}), F = /* @__PURE__ */ new Set(), I, L = (e, n) => {
			let r = Number(t(e, `VariableSizedWrapGrid.${n}`));
			return Number.isFinite(r) ? Math.max(1, Math.floor(r)) : 1;
		}, R = (e) => {
			let t = D(e);
			if (t === "" || t == null) return NaN;
			let n = Number(t);
			return Number.isFinite(n) ? Math.max(0, n) : NaN;
		}, z = (e, t, n, r) => {
			let i = /* @__PURE__ */ new Set(), a = [], o = 0, s = 0, c = 0, l = 0;
			for (let u of e) {
				let e = Math.min(r ? u.columnSpan : u.rowSpan, t), d = Math.min(r ? u.rowSpan : u.columnSpan, n), f = !1;
				for (; s < n;) {
					o === t && (o = 0, s += 1);
					let r = !0;
					for (let a = 0; a < d; a += 1) {
						if (s + a >= n) {
							d = n - s;
							break;
						}
						for (let n = 0; n < e && (r = o + n >= t || i.has(`${o + n}:${s + a}`), !r); n += 1);
						if (r) break;
					}
					if (!r) {
						f = !0;
						break;
					}
					o += 1, (o === t || o + e > t) && (o = 0, s += 1);
				}
				if (!f || s >= n) break;
				for (let t = 0; t < d; t += 1) for (let n = 0; n < e; n += 1) i.add(`${o + n}:${s + t}`);
				a.push({
					tile: u,
					row: o,
					column: s,
					rows: e,
					columns: d
				}), c = Math.max(c, o + e), l = Math.max(l, s + d);
			}
			return {
				placements: a,
				usedRows: c,
				usedColumns: l
			};
		}, B = (e, t, n, r) => {
			let i = Number.isFinite(t) ? Math.max(0, t - n) : 0;
			return e === "Center" ? {
				start: i / 2,
				gap: 0
			} : e === "Right" || e === "Bottom" ? {
				start: i,
				gap: 0
			} : e === "Stretch" ? {
				start: 0,
				gap: i / (r + 1)
			} : {
				start: 0,
				gap: 0
			};
		}, V = (e, t, n) => {
			let r = {
				position: e.style.position,
				width: e.style.width,
				height: e.style.height
			};
			e.style.position = "absolute", (!r.width || r.width === "auto") && (e.style.width = Number.isNaN(t) ? "max-content" : `${t}px`), (!r.height || r.height === "auto") && (e.style.height = Number.isNaN(n) ? "max-content" : `${n}px`);
			let i = e.getBoundingClientRect(), a = getComputedStyle(e), o = i.width + (parseFloat(a.marginLeft) || 0) + (parseFloat(a.marginRight) || 0), s = i.height + (parseFloat(a.marginTop) || 0) + (parseFloat(a.marginBottom) || 0);
			return Object.assign(e.style, r), {
				width: o,
				height: s
			};
		}, H = (e, t, n) => {
			let r = e.style;
			r[t] !== n && (r[t] = n);
		}, U = (e) => {
			if (!getComputedStyle(e).getPropertyValue("--flyout-available-width").trim()) return e.clientWidth;
			let t = 0;
			for (let n = e; n; n = n.parentElement) {
				let r = getComputedStyle(n), i = (parseFloat(r.paddingLeft) || 0) + (parseFloat(r.paddingRight) || 0), a = (parseFloat(r.borderLeftWidth) || 0) + (parseFloat(r.borderRightWidth) || 0), o = r.maxWidth.endsWith("px") ? parseFloat(r.maxWidth) : NaN, s = n.style.width;
				if (n !== e && s.endsWith("px")) return Math.max(0, n.clientWidth - i - t);
				if (Number.isFinite(o)) return Math.max(0, o - i - a - t);
				t += i + a + (parseFloat(r.marginLeft) || 0) + (parseFloat(r.marginRight) || 0);
			}
			return e.clientWidth;
		}, W = () => {
			let n = E.value;
			if (!n) return;
			let r = new Set(Array.from(n.children));
			for (let e of F) r.has(e) || (I?.unobserve(e), F.delete(e));
			let i = Array.from(n.children).map((e) => {
				let t = e;
				return !F.has(t) && I && (I.observe(t), F.add(t)), t.removeAttribute("data-vsg-unarranged"), {
					element: t,
					rowSpan: L(t, "RowSpan"),
					columnSpan: L(t, "ColumnSpan")
				};
			});
			if (!i.length) {
				H(n, "gridTemplateRows", "none"), H(n, "gridTemplateColumns", "none");
				return;
			}
			let a = k.value === "Horizontal", o = R(S.ItemWidth), s = R(S.ItemHeight), c = V(i[0].element, o * i[0].columnSpan, s * i[0].rowSpan), l = Number.isNaN(o) ? c.width : o, u = Number.isNaN(s) ? c.height : s, d = R(S.Width), f = R(S.Height), p = R(S.MaxWidth), m = R(S.MaxHeight), h = Math.min(Number.isNaN(d) ? U(n) : d, Number.isNaN(p) ? Infinity : p), g = Math.min(Number.isNaN(f) ? Infinity : f, Number.isNaN(m) ? Infinity : m), _ = a ? h : g, v = a ? g : h, y = a ? l : u, b = a ? u : l, x = i.reduce((e, t) => e + (a ? t.columnSpan : t.rowSpan), 0), C = i.reduce((e, t) => e + (a ? t.rowSpan : t.columnSpan), 0), w = R(S.MaximumRowsOrColumns), T = Math.max(1, Number.isFinite(_) && y > 0 ? Math.floor(_ / y) : x);
			w > 0 && (T = Math.min(T, Math.floor(w)));
			let O = Math.max(1, Number.isFinite(v) && b > 0 ? Math.min(Math.floor(v / b), C) : C), A = z(i, T, O, a), j = a ? A.usedRows : A.usedColumns, M = a ? A.usedColumns : A.usedRows, N = j * l, P = M * u;
			H(n, "gridTemplateColumns", j ? `repeat(${j}, ${l}px)` : "none"), H(n, "gridTemplateRows", M ? `repeat(${M}, ${u}px)` : "none");
			let W = B(D(S.HorizontalChildrenAlignment), h, N, j), G = B(D(S.VerticalChildrenAlignment), g, P, M), K = /* @__PURE__ */ new Set();
			for (let [n, r] of A.placements.entries()) {
				let i = r.tile.element;
				K.add(i);
				let o = a ? r.column : r.row, s = a ? r.row : r.column, c = a ? r.columns : r.rows, d = a ? r.rows : r.columns;
				H(i, "gridRow", `${o + 1} / span ${c}`), H(i, "gridColumn", `${s + 1} / span ${d}`);
				let f = a && s === 0 && r.tile.columnSpan >= A.usedRows ? Math.max(d * l, Math.min(r.tile.columnSpan * l, h)) : d * l, p = !a && o === 0 && r.tile.rowSpan >= A.usedRows ? Math.max(c * u, Math.min(r.tile.rowSpan * u, g)) : c * u, m = t(i, "HorizontalAlignment"), _ = t(i, "VerticalAlignment"), v = !!(i.style.width && i.style.width !== "auto"), y = !!(i.style.height && i.style.height !== "auto"), b = m && m !== "Stretch" ? e(m, "horizontal") : v ? "center" : "stretch", x = _ && _ !== "Stretch" ? e(_, "vertical") : y ? "center" : "stretch";
				H(i, "justifySelf", b), H(i, "alignSelf", x);
				let S = f - d * l, C = p - c * u;
				i.toggleAttribute("data-vsg-expanded-width", b === "stretch" && S > 0), i.toggleAttribute("data-vsg-expanded-height", x === "stretch" && C > 0), i.style.setProperty("--vsg-arranged-min-width", `${f}px`), i.style.setProperty("--vsg-arranged-min-height", `${p}px`);
				let w = b === "center" ? S / 2 : b === "end" ? S : 0, T = x === "center" ? C / 2 : x === "end" ? C : 0, E = W.start + W.gap * (a ? n % A.usedRows + 1 : Math.floor(n / A.usedRows) + 1) + w, D = G.start + G.gap * (a ? Math.floor(n / A.usedRows) + 1 : n % A.usedRows + 1) + T;
				H(i, "position", "relative"), H(i, "left", `${E}px`), H(i, "top", `${D}px`);
			}
			for (let e of i) K.has(e.element) || e.element.setAttribute("data-vsg-unarranged", "");
		};
		r(E, W), v(() => [k.value, ...[
			S.ItemWidth,
			S.ItemHeight,
			S.MaximumRowsOrColumns,
			S.HorizontalChildrenAlignment,
			S.VerticalChildrenAlignment,
			S.Width,
			S.Height,
			S.MinWidth,
			S.MinHeight,
			S.MaxWidth,
			S.MaxHeight
		].map(D)], () => {
			p(W);
		}), h(() => {
			typeof ResizeObserver < "u" && (I = new ResizeObserver(() => {
				p(W);
			})), W();
		}), m(() => {
			I?.disconnect();
		});
		let G = {
			VariableSizedWrapGridResources: y,
			props: S,
			instance: C,
			emit: w,
			slots: T,
			root: E,
			resolve: D,
			orientationOverride: O,
			Orientation: k,
			nodeName: A,
			childrenOf: j,
			flatten: M,
			XamlChildren: N,
			rootStyle: P,
			observedChildren: F,
			get childResizeObserver() {
				return I;
			},
			set childResizeObserver(e) {
				I = e;
			},
			span: L,
			dimension: R,
			createOccupancyMap: z,
			alignmentOffsets: B,
			firstDesiredSize: V,
			setStyle: H,
			measureAvailableWidth: U,
			arrangeChildren: W
		};
		return Object.defineProperty(G, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), G;
	}
});
//#endregion
export { y as VariableSizedWrapGridResources, b as default };

//# sourceMappingURL=VariableSizedWrapGrid.vue_vue_type_script_setup_true_lang.js.map