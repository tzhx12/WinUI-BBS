import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./DatePicker.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                               */
import { createBlock as n, createCommentVNode as r, createElementBlock as i, createVNode as a, mergeProps as o, normalizeStyle as s, openBlock as c, withCtx as l } from "vue";
//#region src/components/DatePicker.vue
function u(e, t, u, d, f, p) {
	return c(), i("div", o({ ref: "rootRef" }, d.rootAttrs, {
		class: ["win-date-picker", [d.rootClasses, d.attrs.class]],
		style: d.rootStyle
	}), [a(d.Grid, { class: "picker-layout-root" }, {
		default: l(() => [
			a(d.Grid.RowDefinitions, null, {
				default: l(() => [a(d.RowDefinition, { Height: "Auto" }), a(d.RowDefinition, { Height: "*" })]),
				_: 1
			}),
			d.hasHeader ? (c(), n(d.ContentPresenter, {
				key: 0,
				class: "picker-header",
				"Grid.Row": "0"
			}, {
				default: l(() => [a(d.HeaderContent)]),
				_: 1
			})) : r("", !0),
			a(d.Button, {
				ref: "buttonRef",
				class: "picker-button",
				"Grid.Row": "1",
				Style: "{StaticResource DatePickerFlyoutButtonStyle}",
				Padding: "0",
				MinHeight: "{ThemeResource TextControlThemeMinHeight}",
				MinWidth: "0",
				BorderBrush: "{x:Bind PickerBorderBrush}",
				BorderThickness: "{x:Bind PickerBorderThickness}",
				CornerRadius: "{x:Bind PickerCornerRadius}",
				HorizontalAlignment: "Stretch",
				VerticalAlignment: "Top",
				HorizontalContentAlignment: "Stretch",
				VerticalContentAlignment: "Stretch",
				IsEnabled: "{x:Bind PickerEnabled}",
				"AutomationProperties.Name": "{x:Bind PickerAutomationName}",
				Click: "OnFlyoutButtonClick"
			}, {
				default: l(() => [a(d.Grid, {
					class: "picker-button-content",
					style: s(d.columnStyle)
				}, {
					default: l(() => [
						a(d.Grid.ColumnDefinitions, null, {
							default: l(() => [
								a(d.ColumnDefinition, { Width: "78*" }),
								a(d.ColumnDefinition, { Width: "Auto" }),
								a(d.ColumnDefinition, { Width: "132*" }),
								a(d.ColumnDefinition, { Width: "Auto" }),
								a(d.ColumnDefinition, { Width: "78*" })
							]),
							_: 1
						}),
						d.fields.length ? (c(), n(d.TextBlock, {
							key: 0,
							class: "picker-host-text",
							"Grid.Column": "0",
							Text: "{x:Bind FirstText}",
							style: s(d.firstStyle),
							TextTrimming: "CharacterEllipsis"
						}, null, 8, ["style"])) : r("", !0),
						d.fields.length > 1 ? (c(), n(d.Rectangle, {
							key: 1,
							class: "picker-host-divider",
							"Grid.Column": "1",
							Width: "1",
							Fill: "{ThemeResource DatePickerSpacerFill}"
						})) : r("", !0),
						d.fields.length > 1 ? (c(), n(d.TextBlock, {
							key: 2,
							class: "picker-host-text",
							"Grid.Column": "2",
							Text: "{x:Bind SecondText}",
							style: s(d.secondStyle),
							TextTrimming: "CharacterEllipsis"
						}, null, 8, ["style"])) : r("", !0),
						d.fields.length > 2 ? (c(), n(d.Rectangle, {
							key: 3,
							class: "picker-host-divider",
							"Grid.Column": "3",
							Width: "1",
							Fill: "{ThemeResource DatePickerSpacerFill}"
						})) : r("", !0),
						d.fields.length > 2 ? (c(), n(d.TextBlock, {
							key: 4,
							class: "picker-host-text",
							"Grid.Column": "4",
							Text: "{x:Bind ThirdText}",
							style: s(d.thirdStyle),
							TextTrimming: "CharacterEllipsis"
						}, null, 8, ["style"])) : r("", !0)
					]),
					_: 1
				}, 8, ["style"])]),
				_: 1
			}, 512)
		]),
		_: 1
	}), a(d.DateTimePickerFlyout, {
		ref: "flyoutRef",
		Kind: "DatePicker",
		Columns: "{x:Bind PickerColumns}",
		RequestedTheme: "{x:Bind PickerTheme}",
		LightDismissOverlayMode: "{x:Bind PickerOverlayMode}",
		SelectionChanged: "OnFlyoutSelectionChanged",
		Closed: "OnFlyoutClosed"
	}, null, 512)], 16);
}
var d = /*#__PURE__*/ e(t, [
	["render", u],
	["__scopeId", "data-v-b7f00ede"],
	["__file", "DatePicker.vue"]
]);
//#endregion
export { d as default };

//# sourceMappingURL=DatePicker.vue.js.map