import { shallowRef as e, unref as t } from "vue";
//#region src/components/themeShadowRuntime.ts
var n = (e) => {
	if (typeof HTMLElement > "u") return null;
	if (e instanceof HTMLElement) return e;
	if (!e || typeof e != "object") return null;
	let n = e, r = t(n.Element) ?? n.$el;
	return r instanceof HTMLElement ? r : null;
}, r = (e) => !!(e && typeof e == "object" && e.__xamlShadow === "ThemeShadow"), i = () => {
	let t = e([]), r = /* @__PURE__ */ new Set(), i = e(!1), a = (e, n = !1) => {
		if (!Number.isInteger(e) || e < 0 || e >= t.value.length + +!!n) throw RangeError("UIElementWeakCollection index is out of bounds.");
	}, o = (e, t) => {
		if (i.value) throw Error("ThemeShadow has been disposed.");
		let a = n(e);
		if (!a) throw TypeError("ThemeShadow.Receivers requires a UIElement.");
		let o = (e) => {
			if (e && (a === e || a.contains(e))) throw TypeError("An ancestor element cannot be a ThemeShadow receiver.");
		};
		t && o(t);
		for (let e of r) {
			let t = e.deref();
			t ? o(t) : r.delete(e);
		}
		return new WeakRef(e);
	}, s = (e) => (a(e), t.value[e].deref() ?? null), c = (e, n) => {
		a(e, !0);
		let r = o(n), i = [...t.value];
		i.splice(e, 0, r), t.value = i;
	}, l = (e) => {
		let r = n(e);
		return t.value.findIndex((t) => {
			let i = t.deref();
			return i === e || !!(r && n(i) === r);
		});
	}, u = (e) => {
		a(e);
		let n = [...t.value];
		n.splice(e, 1), t.value = n;
	}, d = {
		get Count() {
			return t.value.length;
		},
		get Size() {
			return t.value.length;
		},
		Add: (e) => c(t.value.length, e),
		Append: (e) => c(t.value.length, e),
		Insert: c,
		InsertAt: c,
		GetAt: s,
		SetAt(e, n) {
			a(e);
			let r = o(n), i = [...t.value];
			i[e] = r, t.value = i;
		},
		IndexOf: l,
		Remove(e) {
			let t = l(e);
			return t < 0 ? !1 : (u(t), !0);
		},
		RemoveAt: u,
		RemoveAtEnd: () => u(t.value.length - 1),
		Clear: () => {
			t.value = [];
		},
		*[Symbol.iterator]() {
			for (let e of t.value) yield e.deref() ?? null;
		}
	};
	return Object.freeze({
		__xamlShadow: "ThemeShadow",
		Receivers: Object.freeze(d),
		get IsDisposed() {
			return i.value;
		},
		AttachCaster(e) {
			if (i.value) throw Error("ThemeShadow has been disposed.");
			for (let t of d) t && o(t, e);
			let t = new WeakRef(e);
			return r.add(t), () => {
				r.delete(t);
			};
		},
		Dispose() {
			i.value = !0, t.value = [], r.clear();
		}
	});
}, a = (e, t) => {
	let n = Number(e), r = Math.min(64, Number.isFinite(n) ? n / 2 : 0), i = String(t).toLowerCase() === "dark", a = r > 16 ? r / 3 : 2, o = r > 16 ? 2 : 0, s = r > 16 ? i ? .37 : .15 : 0, c = r < 2 ? 0 : r <= 16 ? i ? .26 : Math.min(r / 100 + .06, .14) : i ? .37 : .19, l = r * .5, u = Math.ceil(Math.max(a, r));
	return {
		Elevation: r,
		AmbientBlurRadius: a,
		DirectionalBlurRadius: r,
		AmbientYOffset: o,
		DirectionalYOffset: l,
		AmbientOpacity: s,
		DirectionalOpacity: c,
		AmbientAlpha: Math.trunc(s * 255) / 255,
		DirectionalAlpha: Math.trunc(c * 255) / 255,
		Insets: {
			Left: u,
			Right: u,
			Top: Math.ceil(Math.max(a - o, r - l)),
			Bottom: Math.ceil(Math.max(a + o, r + l))
		}
	};
}, o = (e) => {
	let t = typeof e == "number" ? [e] : String(e ?? 0).split(/[\s,]+/).map(Number);
	return Math.max(0, ...t.filter(Number.isFinite));
}, s = (e, t) => {
	if (e.DirectionalOpacity === 0) return { display: "none" };
	let n = Math.max(0, t), r = Math.max(64, Math.round(n * 2)), { Left: i, Top: a, Right: o, Bottom: s } = e.Insets, c = r + i + o, l = r + a + s, u = `x="${i + 1}" y="${a + 1}" width="${r - 2}" height="${r - 2}" rx="${n}"`, d = (e, t, n, r) => r <= 0 ? "" : `<filter id="${e}" x="0" y="0" width="${c}" height="${l}" filterUnits="userSpaceOnUse"><feGaussianBlur stdDeviation="${(t + 1) / 3}"/><feOffset dy="${n}"/></filter>`, f = d("a", e.AmbientBlurRadius, e.AmbientYOffset, e.AmbientAlpha), p = `<svg xmlns="http://www.w3.org/2000/svg" width="${c}" height="${l}"><defs>${f}${d("d", e.DirectionalBlurRadius, e.DirectionalYOffset, e.DirectionalAlpha)}<mask id="h" maskUnits="userSpaceOnUse" x="0" y="0" width="${c}" height="${l}"><rect width="${c}" height="${l}" fill="white"/><rect ${u} fill="black"/></mask></defs><g mask="url(#h)">${f ? `<rect ${u} fill="black" fill-opacity="${e.AmbientAlpha}" filter="url(#a)"/>` : ""}<rect ${u} fill="black" fill-opacity="${e.DirectionalAlpha}" filter="url(#d)"/></g></svg>`, m = [
		a,
		o,
		s,
		i
	].map((e) => e + n + 1);
	return {
		position: "absolute",
		pointerEvents: "none",
		boxSizing: "border-box",
		left: `${-i}px`,
		top: `${-a}px`,
		width: `calc(100% + ${i + o}px)`,
		height: `calc(100% + ${a + s}px)`,
		borderStyle: "solid",
		borderColor: "transparent",
		borderWidth: m.map((e) => `${e}px`).join(" "),
		borderImageSource: `url("data:image/svg+xml,${encodeURIComponent(p)}")`,
		borderImageSlice: m.join(" "),
		borderImageWidth: "1",
		borderImageRepeat: "stretch"
	};
};
//#endregion
export { i as createThemeShadow, a as getThemeShadowRecipe, r as isThemeShadow, o as shadowCornerRadius, s as themeShadowVisualStyle };

//# sourceMappingURL=themeShadowRuntime.js.map