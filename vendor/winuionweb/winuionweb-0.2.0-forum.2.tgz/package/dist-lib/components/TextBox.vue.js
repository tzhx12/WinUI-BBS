import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./TextBox.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                            */
import { Fragment as n, createBlock as r, createCommentVNode as i, createElementBlock as a, createElementVNode as o, createTextVNode as s, createVNode as c, mergeProps as l, normalizeStyle as u, openBlock as d, toDisplayString as f, withCtx as p, withDirectives as m, withModifiers as h } from "vue";
//#region src/components/TextBox.vue
var g = {
	key: 0,
	class: "win-textbox-header"
}, _ = { class: "win-textbox-content" }, v = [
	"value",
	"placeholder",
	"readonly",
	"disabled",
	"maxlength",
	"spellcheck",
	"inputmode",
	"autocomplete",
	"autocapitalize",
	"autocorrect",
	"aria-label"
], y = [
	"value",
	"placeholder",
	"readonly",
	"disabled",
	"maxlength",
	"spellcheck",
	"inputmode",
	"autocomplete",
	"autocapitalize",
	"autocorrect",
	"aria-label"
], b = ["aria-label"], x = {
	key: 1,
	class: "win-textbox-description"
};
function S(e, t, S, C, w, T) {
	return d(), a("div", l({
		ref: "rootRef",
		class: "win-textbox"
	}, C.forwardedAttrs, {
		class: {
			"is-readonly": C.props.IsReadOnly,
			"is-disabled": C.isDisabled,
			"is-focused": C.isFocused,
			"is-hovered": C.isHovered,
			"candidate-window-bottom-edge": C.props.DesiredCandidateWindowAlignment === "BottomEdge"
		},
		style: C.rootStyle
	}), [
		C.resolvedHeader || C.headerNodes.length ? (d(), a("div", g, [c(C.HeaderOutlet)])) : i("", !0),
		m((d(), a("div", {
			class: "win-textbox-border",
			style: u(C.backgroundStyle),
			onPointerenter: C.onPointerEnter,
			onPointerleave: C.onPointerLeave
		}, [t[2] ||= o("div", {
			class: "win-textbox-focus-border",
			"aria-hidden": "true"
		}, null, -1), o("div", _, [
			C.inputTemplate?.Field ? (d(), r(C.FieldOutlet, { key: 0 })) : (d(), r(C.ScrollViewer, {
				key: 1,
				class: "win-textbox-content-element",
				HorizontalScrollMode: "{x:Bind ScrollSettings.HorizontalScrollMode, Mode=OneWay}",
				VerticalScrollMode: "{x:Bind ScrollSettings.VerticalScrollMode, Mode=OneWay}",
				HorizontalScrollBarVisibility: "{x:Bind ScrollSettings.HorizontalScrollBarVisibility, Mode=OneWay}",
				VerticalScrollBarVisibility: "{x:Bind ScrollSettings.VerticalScrollBarVisibility, Mode=OneWay}",
				IsHorizontalRailEnabled: "{x:Bind ScrollSettings.IsHorizontalRailEnabled, Mode=OneWay}",
				IsVerticalRailEnabled: "{x:Bind ScrollSettings.IsVerticalRailEnabled, Mode=OneWay}",
				IsHorizontalScrollChainingEnabled: "{x:Bind ScrollSettings.IsHorizontalScrollChainingEnabled, Mode=OneWay}",
				IsVerticalScrollChainingEnabled: "{x:Bind ScrollSettings.IsVerticalScrollChainingEnabled, Mode=OneWay}",
				IsDeferredScrollingEnabled: "{x:Bind ScrollSettings.IsDeferredScrollingEnabled, Mode=OneWay}",
				IsEnabled: "{x:Bind TextBoxScrollEnabled, Mode=OneWay}",
				ZoomMode: "Disabled",
				IsTabStop: "False"
			}, {
				default: p(() => [C.props.AcceptsReturn ? (d(), a("textarea", {
					key: 0,
					rows: "1",
					ref: "fieldRef",
					class: "win-textbox-field win-textbox-textarea",
					value: C.currentText,
					placeholder: C.props.PlaceholderText,
					readonly: C.props.IsReadOnly,
					disabled: C.isDisabled,
					maxlength: C.props.MaxLength > 0 ? C.props.MaxLength : void 0,
					spellcheck: C.props.IsSpellCheckEnabled,
					inputmode: C.inputMode,
					autocomplete: C.props.IsTextPredictionEnabled ? "on" : "off",
					autocapitalize: C.textPredictionAttr,
					autocorrect: C.textPredictionAttr,
					style: u(C.fieldStyle),
					"aria-label": C.automationName,
					onInput: C.onInput,
					onFocus: C.onFocus,
					onBlur: C.onBlur,
					onKeydown: C.onKeydown,
					onKeyup: C.onKeyup,
					onPaste: C.onPaste,
					onContextmenu: C.onContextMenu,
					onSelect: C.onSelect,
					onPointerup: C.onSelectionPointerUp,
					onCut: C.onCuttingToClipboard,
					onCopy: C.onCopyingToClipboard,
					onCompositionstart: C.onCompositionStart,
					onCompositionupdate: C.onCompositionChanged,
					onCompositionend: C.onCompositionEnd,
					onPointerenter: C.onPointerEnter,
					onPointerleave: C.onPointerLeave
				}, null, 44, v)) : (d(), a("input", {
					key: 1,
					ref: "fieldRef",
					class: "win-textbox-field",
					type: "text",
					value: C.currentText,
					placeholder: C.props.PlaceholderText,
					readonly: C.props.IsReadOnly,
					disabled: C.isDisabled,
					maxlength: C.props.MaxLength > 0 ? C.props.MaxLength : void 0,
					spellcheck: C.props.IsSpellCheckEnabled,
					inputmode: C.inputMode,
					autocomplete: C.props.IsTextPredictionEnabled ? "on" : "off",
					autocapitalize: C.textPredictionAttr,
					autocorrect: C.textPredictionAttr,
					style: u(C.fieldStyle),
					"aria-label": C.automationName,
					onInput: C.onInput,
					onFocus: C.onFocus,
					onBlur: C.onBlur,
					onKeydown: C.onKeydown,
					onKeyup: C.onKeyup,
					onPaste: C.onPaste,
					onContextmenu: C.onContextMenu,
					onSelect: C.onSelect,
					onPointerup: C.onSelectionPointerUp,
					onCut: C.onCuttingToClipboard,
					onCopy: C.onCopyingToClipboard,
					onCompositionstart: C.onCompositionStart,
					onCompositionupdate: C.onCompositionChanged,
					onCompositionend: C.onCompositionEnd,
					onPointerenter: C.onPointerEnter,
					onPointerleave: C.onPointerLeave
				}, null, 44, y))]),
				_: 1
			})),
			C.showDeleteButton ? (d(), a("button", l({
				key: 2,
				class: "win-textbox-delete-button",
				type: "button",
				"aria-label": C.t("text.clear-text")
			}, { "tooltipservice.tooltip": C.t("text.clear-text") }, {
				onPointerdown: t[0] ||= h(() => {}, ["prevent"]),
				onClick: C.clearText
			}), [...t[1] ||= [o("span", { class: "win-textbox-delete-button-layout" }, [o("span", { class: "win-textbox-delete-glyph" }, "")], -1)]], 16, b)) : i("", !0),
			C.inputTemplate?.Actions ? (d(), r(C.ActionsOutlet, { key: 3 })) : i("", !0)
		])], 36)), [[C.vAcrylicBrush, C.backgroundStyle]]),
		C.resolvedDescription || C.descriptionNodes.length ? (d(), a("div", x, [C.descriptionNodes.length ? (d(), r(C.DescriptionOutlet, { key: 0 })) : (d(), a(n, { key: 1 }, [s(f(C.resolvedDescription), 1)], 64))])) : i("", !0),
		c(C.ContextMenu),
		c(C.CustomFlyouts)
	], 16);
}
var C = /*#__PURE__*/ e(t, [
	["render", S],
	["__scopeId", "data-v-b36c0a63"],
	["__file", "TextBox.vue"]
]);
//#endregion
export { C as default };

//# sourceMappingURL=TextBox.vue.js.map