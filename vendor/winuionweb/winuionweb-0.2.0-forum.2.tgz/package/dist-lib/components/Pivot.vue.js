import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./Pivot.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                          */
import { Fragment as n, createCommentVNode as r, createElementBlock as i, createElementVNode as a, createVNode as o, mergeProps as s, normalizeClass as c, normalizeStyle as l, openBlock as u, renderList as d } from "vue";
//#region src/components/Pivot.vue
var f = [
	"dir",
	"data-theme",
	"aria-disabled"
], p = {
	class: "win-pivot-root-element",
	"data-part": "RootElement"
}, m = {
	key: 0,
	class: "win-pivot-title-content-control",
	"data-part": "TitleContentControl"
}, h = {
	class: "win-pivot-scroll-viewer",
	"data-part": "ScrollViewer"
}, g = {
	class: "win-pivot-panel",
	"data-part": "Panel"
}, _ = {
	class: "win-pivot-layout-element",
	"data-part": "LayoutElement"
}, v = {
	class: "win-pivot-left-header-presenter",
	"data-part": "LeftHeaderPresenter"
}, y = { class: "win-pivot-header-grid" }, b = ["data-part"], x = [
	"data-pivot-index",
	"id",
	"disabled",
	"tabindex",
	"accesskey",
	"aria-selected",
	"aria-controls",
	"onFocus",
	"onPointerdown",
	"onPointerenter"
], S = { class: "win-pivot-header-grid-content" }, C = { class: "win-pivot-header-content-presenter" }, w = ["disabled"], T = ["disabled"], E = {
	class: "win-pivot-right-header-presenter",
	"data-part": "RightHeaderPresenter"
};
function D(e, t, D, O, k, A) {
	return u(), i("div", s({ ref: "rootRef" }, O.rootAttrs, {
		class: ["win-pivot", [
			O.attrs.class,
			O.requestedTheme ? `theme-${O.requestedTheme}` : "",
			{
				"is-locked": O.locked,
				"is-disabled": !O.enabled,
				"win-theme-scope": O.requestedTheme
			}
		]],
		style: [O.attrs.style, O.rootStyle],
		dir: O.flowDirection,
		"data-theme": O.requestedTheme,
		"aria-disabled": O.enabled ? void 0 : "true",
		onKeydown: O.onKeyDown,
		onFocusin: O.onFocusChanged,
		onFocusout: O.onFocusChanged,
		onPointerdown: O.onPointerDown,
		onPointermove: O.onPointerMove,
		onPointerup: O.onPointerUp,
		onPointercancel: O.cancelGesture,
		onLostpointercapture: O.onLostPointerCapture
	}), [a("div", p, [O.hasTitle ? (u(), i("div", m, [o(O.TitleOutlet)])) : r("", !0), a("div", {
		class: "win-pivot-template-grid",
		style: l(O.templateGridStyle)
	}, [a("div", h, [a("div", g, [a("div", _, [
		a("div", v, [o(O.LeftHeaderOutlet)]),
		a("div", {
			ref: "headerClipperRef",
			class: "win-pivot-header-clipper",
			"data-part": "HeaderClipper",
			onPointerenter: O.onHeaderPointerEnter,
			onPointerleave: O.onHeaderPointerLeave,
			onScrollPassive: O.updateNavigationButtons
		}, [a("div", y, [a("div", {
			ref: "headerPanelRef",
			class: "win-pivot-header-panel",
			"data-part": O.usingStaticHeaders ? "StaticHeader" : "Header",
			role: "tablist"
		}, [(u(!0), i(n, null, d(O.orderedItems, (e) => (u(), i("button", {
			key: e.key,
			ref_for: !0,
			ref: (t) => O.setHeaderRef(e.key, t),
			"data-pivot-index": e.index,
			class: c(["win-pivot-header-item", O.headerClass(e)]),
			id: O.headerId(e),
			type: "button",
			role: "tab",
			disabled: !O.enabled || !e.enabled,
			tabindex: e.key === O.selectedKey ? 0 : -1,
			accesskey: O.pivotText(e.accessKey) || void 0,
			"aria-selected": e.key === O.selectedKey,
			"aria-controls": O.panelId(e),
			onFocus: (t) => O.focusedKey = e.key,
			onKeydown: t[0] ||= (e) => O.onHeaderKeyDown(e),
			onPointerdown: (t) => O.onHeaderPressed(t, e.key),
			onPointerup: O.clearPressedHeader,
			onPointercancel: O.clearPressedHeader,
			onLostpointercapture: O.clearPressedHeader,
			onPointerenter: (t) => O.hoveredKey = O.isHoverPointer(t) ? e.key : null,
			onPointerleave: t[1] ||= (e) => O.hoveredKey = null
		}, [a("div", S, [a("div", C, [o(O.HeaderOutlet, { item: e }, null, 8, ["item"])]), t[2] ||= a("div", {
			class: "win-pivot-selected-pipe",
			"aria-hidden": "true"
		}, null, -1)])], 42, x))), 128))], 8, b), a("div", {
			class: c(["win-pivot-focus-follower", { "is-visible": O.showFocusFollower }]),
			style: l(O.focusFollowerStyle),
			"data-part": "FocusFollower",
			"aria-hidden": "true"
		}, null, 6)])], 544),
		a("button", {
			class: c(["win-pivot-nav-button win-pivot-previous-button", { "is-visible": O.showPreviousButton }]),
			type: "button",
			"data-part": "PreviousButton",
			tabindex: "-1",
			"aria-hidden": "true",
			disabled: !O.showPreviousButton || !O.enabled || O.locked,
			onPointerenter: O.onHeaderPointerEnter,
			onPointerleave: O.onHeaderPointerLeave
		}, [...t[3] ||= [a("span", { class: "win-pivot-nav-glyph" }, "", -1)]], 42, w),
		a("button", {
			class: c(["win-pivot-nav-button win-pivot-next-button", { "is-visible": O.showNextButton }]),
			type: "button",
			"data-part": "NextButton",
			tabindex: "-1",
			"aria-hidden": "true",
			disabled: !O.showNextButton || !O.enabled || O.locked,
			onPointerenter: O.onHeaderPointerEnter,
			onPointerleave: O.onHeaderPointerLeave
		}, [...t[4] ||= [a("span", { class: "win-pivot-nav-glyph" }, "", -1)]], 42, T),
		a("div", E, [o(O.RightHeaderOutlet)]),
		a("div", {
			ref: "itemPresenterRef",
			class: "win-pivot-item-presenter",
			"data-part": "PivotItemPresenter",
			style: l(O.itemPresenterStyle)
		}, [o(O.ItemsOutlet)], 4)
	])])])], 4)])], 16, f);
}
var O = /*#__PURE__*/ e(t, [
	["render", D],
	["__scopeId", "data-v-0627985e"],
	["__file", "Pivot.vue"]
]);
//#endregion
export { O as default };

//# sourceMappingURL=Pivot.vue.js.map