import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./Viewbox.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                            */
import { createElementBlock as n, createElementVNode as r, createVNode as i, mergeProps as a, normalizeStyle as o, openBlock as s } from "vue";
//#region src/components/Viewbox.vue
function c(e, t, c, l, u, d) {
	return s(), n("div", a({ ref: "rootRef" }, l.forwardedAttrs, {
		class: ["win-viewbox", l.attrs.class],
		style: l.rootStyle
	}), [r("div", {
		ref: "contentRef",
		class: "win-viewbox-container",
		style: o(l.containerStyle)
	}, [i(l.ChildPresenter)], 4)], 16);
}
var l = /*#__PURE__*/ e(t, [
	["render", c],
	["__scopeId", "data-v-51a6cbdd"],
	["__file", "Viewbox.vue"]
]);
//#endregion
export { l as default };

//# sourceMappingURL=Viewbox.vue.js.map