import { normalizeXamlNodes as e, resolveXamlValue as t, updateXamlBinding as n } from "./xamlRuntime.js";
import { TextBlockInlines as r, TextBlockTextHighlighters as i, createTextHighlights as a, readTextHighlighters as ee, textBrush as o, textContentNodes as te, textFontWeight as ne, textPosition as s } from "./TextInline.js";
import { brushProperty as re, isBrushProperty as ie, useBrushProperty as ae } from "./brushProperties.js";
import { isRadialGradientBrush as oe } from "./RadialGradientVisual.js";
import se from "../_virtual/_plugin-vue_export-helper.js";
import { useI18n as ce } from "./i18n/index.js";
import { textCommandFlyout as le } from "./textCommandFlyout.js";
import { getToolTipServiceProperty as ue } from "./ToolTipServiceProperties.js";
import { xamlResourceDictionaryKey as de } from "./Page.vue_vue_type_script_lang.js";
import { getVNodeChildren as fe } from "./CollectionProperties.js";
import { vRadialGradientForeground as pe } from "./radialGradientForeground.js";
/* empty css                                              */
import { Comment as me, Fragment as c, Text as he, computed as l, createBlock as ge, createCommentVNode as u, createElementBlock as d, createVNode as f, defineComponent as _e, getCurrentInstance as ve, h as ye, inject as be, mergeProps as p, normalizeClass as m, onBeforeUnmount as xe, onMounted as Se, onUpdated as Ce, openBlock as h, reactive as g, ref as _, shallowRef as we, toDisplayString as v, useAttrs as Te, useSlots as Ee, watch as y, withDirectives as De } from "vue";
//#region src/components/TextBlock.vue
var b = {
	Inlines: r,
	TextHighlighters: i,
	Foreground: re("TextBlock", "Foreground")
}, Oe = /*@__PURE__*/ Object.assign(b, { inheritAttrs: !1 }, {
	__name: "TextBlock",
	props: {
		Text: {
			type: [String, Number],
			default: ""
		},
		Style: {
			type: String,
			default: ""
		},
		CharacterSpacing: {
			type: [String, Number],
			default: ""
		},
		FontFamily: {
			type: String,
			default: ""
		},
		FontSize: {
			type: [String, Number],
			default: ""
		},
		FontStretch: {
			type: String,
			default: ""
		},
		FontStyle: {
			type: String,
			default: ""
		},
		FontWeight: {
			type: [String, Number],
			default: ""
		},
		Foreground: {
			type: [String, Object],
			default: ""
		},
		HorizontalTextAlignment: {
			type: String,
			default: ""
		},
		IsColorFontEnabled: {
			type: Boolean,
			default: !0
		},
		IsTextSelectionEnabled: {
			type: [Boolean, String],
			default: !1
		},
		IsTextScaleFactorEnabled: {
			type: [Boolean, String],
			default: !0
		},
		LineHeight: {
			type: [String, Number],
			default: ""
		},
		LineStackingStrategy: {
			type: String,
			default: ""
		},
		Margin: {
			type: String,
			default: ""
		},
		MaxLines: {
			type: [String, Number],
			default: ""
		},
		OpticalMarginAlignment: {
			type: String,
			default: ""
		},
		Padding: {
			type: String,
			default: ""
		},
		SelectionFlyout: {
			type: [String, Object],
			default: ""
		},
		SelectionHighlightColor: {
			type: [String, Object],
			default: ""
		},
		TextAlignment: {
			type: String,
			default: ""
		},
		TextDecorations: {
			type: String,
			default: ""
		},
		TextLineBounds: {
			type: String,
			default: ""
		},
		TextReadingOrder: {
			type: String,
			default: ""
		},
		TextTrimming: {
			type: String,
			default: ""
		},
		TextWrapping: {
			type: String,
			default: ""
		},
		FlowDirection: {
			type: String,
			default: "LeftToRight"
		},
		Width: {
			type: [String, Number],
			default: ""
		},
		Height: {
			type: [String, Number],
			default: ""
		},
		MinWidth: {
			type: [String, Number],
			default: ""
		},
		MinHeight: {
			type: [String, Number],
			default: ""
		},
		MaxWidth: {
			type: [String, Number],
			default: ""
		},
		MaxHeight: {
			type: [String, Number],
			default: ""
		},
		HorizontalAlignment: {
			type: String,
			default: ""
		},
		VerticalAlignment: {
			type: String,
			default: ""
		},
		Visibility: {
			type: String,
			default: "Visible"
		},
		Opacity: {
			type: [String, Number],
			default: ""
		}
	},
	emits: [
		"SelectionChanged",
		"ContextMenuOpening",
		"IsTextTrimmedChanged",
		"update:Foreground"
	],
	setup(se, { expose: ge, emit: u }) {
		let { t: d } = ce(), f = u, p = se, m = Te(), h = Ee(), v = () => te(h.default?.() ?? [], "Inlines").filter((e) => !ie(e)), De = l(() => {
			let e = (t) => t.some((t) => ue(t) || t.type === me ? !1 : t.type === he ? String(t.children ?? "").trim() !== "" : t.type === c && Array.isArray(t.children) ? e(t.children) : !0);
			return e(v());
		}), b = ve(), Oe = _e({ setup: () => () => ye(c, e(v(), b)) }), x = be(de, {}), S = l(() => t(p.Text, b, void 0, !0)), C = l(() => t(p.IsTextSelectionEnabled, b) === !0), w = l(() => t(p.Visibility, b)), T = l(() => {
			let e = t(p.Style, b);
			return typeof e == "string" ? e.match(/^\{(?:StaticResource|ThemeResource)\s+([^\s}]+)\}$/)?.[1] ?? e.match(/^var\(--([^,)]+)\)$/)?.[1] ?? e : "";
		}), ke = new Set([
			"BaseTextBlockStyle",
			"CaptionTextBlockStyle",
			"BodyTextBlockStyle",
			"BodyStrongTextBlockStyle",
			"BodyLargeTextBlockStyle",
			"BodyLargeStrongTextBlockStyle",
			"SubtitleTextBlockStyle",
			"TitleTextBlockStyle",
			"TitleLargeTextBlockStyle",
			"DisplayTextBlockStyle"
		]), E = l(() => {
			let e = (n, r = /* @__PURE__ */ new Set()) => {
				if (!n || r.has(n)) return {};
				r.add(n);
				let i = x[n], a = String(i?.props?.BasedOn ?? "").match(/^\{(?:StaticResource|ThemeResource)\s+([^\s}]+)\}$/)?.[1];
				return {
					...ke.has(n) ? {
						TextWrapping: "Wrap",
						TextTrimming: "CharacterEllipsis",
						LineStackingStrategy: "MaxHeight",
						TextLineBounds: "Full"
					} : {},
					...e(a, r),
					...Object.fromEntries(i ? fe(i).filter((e) => e.props?.Property).map((e) => [e.props.Property, t(e.props.Value, b)]) : [])
				};
			};
			return e(T.value);
		}), D = ae("Foreground", () => p.Foreground || E.value.Foreground, () => h.default?.() ?? [], b), O = we(), k = l({
			get: () => O.value === void 0 ? D.value.value : O.value,
			set: (e) => {
				O.value = t(e, b), n(p.Foreground, e, b), f("update:Foreground", e);
			}
		}), A = l(() => t(p.TextWrapping || E.value.TextWrapping || "NoWrap", b));
		y(D.value, () => {
			O.value = void 0;
		});
		let j = _(null), M = _(!1), N = _(null), Ae = _(null), P = _(""), F = l(() => {
			let e = j.value?.textContent?.length > 0, t = [];
			return P.value && t.push({
				Text: d("text.copy"),
				Icon: "Copy",
				Value: "copy"
			}), e && t.push({
				Text: d("text.select-all"),
				Icon: "SelectAll",
				Value: "selectAll"
			}), t;
		}), I = _(""), L = _(!1), R = g([]), z = a(`win-text-block-${b?.uid}`), B = {
			get Foreground() {
				return k.value;
			},
			set Foreground(e) {
				k.value = e;
			},
			Element: j,
			get SelectedText() {
				return I.value;
			},
			get IsTextTrimmed() {
				return L.value;
			},
			get ContentStart() {
				return { Offset: 0 };
			},
			get ContentEnd() {
				return { Offset: j.value?.textContent?.length ?? 0 };
			},
			SelectAll: () => Y(),
			Select: (e, t) => Ie(e, t),
			CopySelectionToClipboard: () => J(),
			TextHighlighters: {
				Add: (e) => R.push(e),
				Clear: () => R.splice(0),
				Remove: (e) => {
					let t = R.indexOf(e);
					t >= 0 && R.splice(t, 1);
				},
				RemoveAt: (e) => R.splice(e, 1),
				GetAt: (e) => R[e],
				get Count() {
					return R.length;
				}
			}
		};
		ge(B);
		let je = l(() => {
			let { class: e, style: n, ...r } = m, i = t(r["AutomationProperties.LiveSetting"], b);
			return i !== void 0 && (delete r["AutomationProperties.LiveSetting"], r["aria-live"] = {
				Off: "off",
				Polite: "polite",
				Assertive: "assertive"
			}[String(i)] ?? "off"), r;
		}), V = (e) => e === "" || e == null ? "" : typeof e == "string" && e.trim() !== "" && !Number.isNaN(Number(e.trim())) ? `${Number(e.trim())}px` : typeof e == "number" ? `${e}px` : e, H = (e) => {
			if (e === "" || e == null) return "";
			let t = String(e).split(",").map((e) => V(Number.isNaN(Number(e.trim())) ? e.trim() : Number(e.trim())));
			return t.length === 1 ? t[0] : t.length === 2 ? `${t[1]} ${t[0]}` : t.length === 4 ? `${t[1]} ${t[2]} ${t[3]} ${t[0]}` : e;
		}, U = l(() => {
			switch (A.value) {
				case "Wrap":
				case "WrapWholeWords": return "normal";
				case "NoWrap": return "nowrap";
				default: return "";
			}
		}), W = l(() => {
			switch (A.value) {
				case "Wrap": return "anywhere";
				case "WrapWholeWords": return "normal";
				default: return "";
			}
		}), Me = l(() => {
			let e = {}, n = E.value, r = Object.fromEntries((/* @__PURE__ */ "Width.Height.MinWidth.MinHeight.MaxWidth.MaxHeight.HorizontalAlignment.VerticalAlignment.Opacity.CharacterSpacing.FontFamily.FontSize.FontStretch.FontStyle.FontWeight.Foreground.HorizontalTextAlignment.LineHeight.Margin.Padding.SelectionHighlightColor.TextAlignment.TextDecorations.TextTrimming.TextLineBounds.IsTextScaleFactorEnabled.MaxLines.TextReadingOrder.FlowDirection.LineStackingStrategy".split(".")).map((e) => [e, t(p[e] === "" ? n[e] ?? p[e] : p[e], b)])), i = (e) => e !== "" && e != null;
			for (let [t, n] of Object.entries({
				width: r.Width,
				height: r.Height,
				minWidth: r.MinWidth,
				minHeight: r.MinHeight,
				maxWidth: r.MaxWidth,
				maxHeight: r.MaxHeight
			})) i(n) && (e[t] = n === "Auto" ? "auto" : V(n));
			if (r.HorizontalAlignment && (e.justifySelf = {
				Left: "start",
				Center: "center",
				Right: "end",
				Stretch: "stretch"
			}[r.HorizontalAlignment]), r.VerticalAlignment && (e.alignSelf = {
				Top: "start",
				Center: "center",
				Bottom: "end",
				Stretch: "stretch"
			}[r.VerticalAlignment]), i(r.Opacity) && (e.opacity = r.Opacity), i(r.CharacterSpacing)) {
				let t = Number(r.CharacterSpacing);
				e.letterSpacing = Number.isFinite(t) ? `${t / 1e3}em` : `calc(${r.CharacterSpacing} * .001em)`;
			}
			r.FontFamily && (e.fontFamily = r.FontFamily === "XamlAutoFontFamily" ? "var(--ContentControlThemeFontFamily)" : r.FontFamily), i(r.FontSize) && (e.fontSize = V(r.FontSize)), r.FontStretch && (e.fontStretch = String(r.FontStretch).replace(/([a-z])([A-Z])/g, "$1-$2").toLowerCase()), r.FontStyle && (e.fontStyle = String(r.FontStyle).toLowerCase()), i(r.FontWeight) && (e.fontWeight = ne(r.FontWeight));
			let a = k.value;
			if (a && !oe(a) && (e.color = o(a)), r.HorizontalTextAlignment && (e.textAlign = String(r.HorizontalTextAlignment).toLowerCase()), i(r.LineHeight) && Number(r.LineHeight) > 0 ? e.lineHeight = V(r.LineHeight) : r.TextLineBounds === "Tight" ? e.lineHeight = "1" : i(r.FontSize) && (e.lineHeight = "normal"), r.TextLineBounds === "TrimToCapHeight" && (e.textBoxTrim = "trim-start", e.textBoxEdge = "cap alphabetic"), i(r.Margin) && (e.margin = H(r.Margin)), i(r.Padding) && (e.padding = H(r.Padding)), r.SelectionHighlightColor && (e["--TextBlockSelectionHighlightColor"] = o(r.SelectionHighlightColor)), r.TextAlignment && (e.textAlign = String(r.TextAlignment).toLowerCase()), r.TextDecorations && (e.textDecorationLine = String(r.TextDecorations).split(/[\s,]+/).map((e) => e === "Strikethrough" ? "line-through" : e.toLowerCase()).join(" ")), r.IsTextScaleFactorEnabled === !1 && (e.textSizeAdjust = "none", e.webkitTextSizeAdjust = "none"), U.value && (e.whiteSpace = U.value), String(S.value ?? "").includes("\n") && (e.whiteSpace = A.value === "NoWrap" ? "pre" : "pre-line"), W.value && (e.overflowWrap = W.value), e.direction = r.FlowDirection === "RightToLeft" ? "rtl" : "ltr", r.TextReadingOrder === "DetectFromContent" && (e.unicodeBidi = "plaintext"), C.value && (e.userSelect = "text", e.webkitUserSelect = "text", e.cursor = "text"), r.TextTrimming && r.TextTrimming !== "None") {
				if (e.overflow = "hidden", e.textOverflow = r.TextTrimming === "Clip" ? "clip" : "ellipsis", !(A.value === "Wrap" || A.value === "WrapWholeWords")) e.whiteSpace = "nowrap";
				else if (!i(r.MaxLines) || Number(r.MaxLines) === 0) {
					let t = Number.parseFloat(String(r.MaxHeight)), n = Number.parseFloat(String(r.LineHeight)), i = Number.isFinite(n) && n > 0 ? n : T.value === "CaptionTextBlockStyle" ? 16 : T.value === "BodyLargeTextBlockStyle" || T.value === "BodyLargeStrongTextBlockStyle" ? 24 : T.value === "SubtitleTextBlockStyle" ? 28 : T.value === "TitleTextBlockStyle" ? 36 : T.value === "TitleLargeTextBlockStyle" ? 52 : T.value === "DisplayTextBlockStyle" ? 92 : 20;
					Number.isFinite(t) && t > 0 && (e.display = "-webkit-box", e.WebkitLineClamp = String(Math.max(1, Math.floor(t / i))), e.WebkitBoxOrient = "vertical");
				}
			}
			return i(r.MaxLines) && Number(r.MaxLines) > 0 && (e.display = "-webkit-box", e.overflow = "hidden", e.WebkitLineClamp = String(r.MaxLines), e.WebkitBoxOrient = "vertical"), r.TextLineBounds === "TrimToCapHeight" && A.value === "NoWrap" && (!i(r.MaxLines) || Number(r.MaxLines) === 0) && (e.overflow = "visible", e.overflowX = "clip", e.overflowY = "visible"), (w.value === "Collapsed" || w.value === !1) && (e.display = "none"), [m.style, e];
		}), Ne = l(() => ({
			OutputTextBlockStyle: T.value === "OutputTextBlockStyle",
			BaseTextBlockStyle: T.value === "BaseTextBlockStyle",
			CaptionTextBlockStyle: T.value === "CaptionTextBlockStyle",
			BodyTextBlockStyle: T.value === "BodyTextBlockStyle",
			BodyStrongTextBlockStyle: T.value === "BodyStrongTextBlockStyle",
			BodyLargeTextBlockStyle: T.value === "BodyLargeTextBlockStyle",
			BodyLargeStrongTextBlockStyle: T.value === "BodyLargeStrongTextBlockStyle",
			SubtitleTextBlockStyle: T.value === "SubtitleTextBlockStyle",
			TitleTextBlockStyle: T.value === "TitleTextBlockStyle",
			TitleLargeTextBlockStyle: T.value === "TitleLargeTextBlockStyle",
			DisplayTextBlockStyle: T.value === "DisplayTextBlockStyle",
			"text-selection-enabled": C.value
		})), G = () => {
			let e = j.value, t = window.getSelection?.();
			if (!e || !t || t.rangeCount === 0) return "";
			let n = t.getRangeAt(0), r = e.contains(n.startContainer), i = e.contains(n.endContainer);
			return r && i ? t.toString() : "";
		}, K = () => {
			let e = C.value ? G() : "";
			I.value !== e && (I.value = e, f("SelectionChanged", B, {
				OriginalSource: j.value,
				Handled: !1
			}));
		}, Pe = (e) => {
			let t = G();
			t && (e.clipboardData?.setData("text/plain", t), e.preventDefault());
		}, Fe = (e) => {
			if (!C.value) return;
			let n = {
				OriginalSource: e.target,
				CursorLeft: e.clientX,
				CursorTop: e.clientY,
				Handled: !1
			};
			if (f("ContextMenuOpening", B, n), n.Handled) {
				e.preventDefault();
				return;
			}
			if (e.preventDefault(), M.value = !1, P.value = G(), !F.value.length) return;
			let r = e.clientX, i = e.clientY;
			Ae.value = {
				x: r,
				y: i,
				top: i,
				bottom: i,
				left: r,
				right: r,
				width: 0,
				height: 0
			}, M.value = !0;
			let a = t(p.SelectionFlyout, b);
			(a?.ShowAt ? a : N.value)?.ShowAt?.(j.value, { Position: {
				X: e.clientX - j.value.getBoundingClientRect().left,
				Y: e.clientY - j.value.getBoundingClientRect().top
			} });
		}, q = () => {
			M.value = !1, N.value?.Hide?.();
		}, J = () => {
			let e = P.value || G();
			e && navigator.clipboard?.writeText(e);
		}, Y = () => {
			let e = j.value;
			if (!e || !C.value) return;
			let t = document.createRange();
			t.selectNodeContents(e);
			let n = window.getSelection?.();
			n?.removeAllRanges(), n?.addRange(t), P.value = e.textContent ?? "", K();
		}, Ie = (e, t) => {
			if (!j.value || !C.value) return;
			let n = document.createRange();
			n.setStart(...s(j.value, e.Offset)), n.setEnd(...s(j.value, t.Offset));
			let r = window.getSelection();
			r?.removeAllRanges(), r?.addRange(n), K();
		}, Le = (e) => {
			e.Value && (q(), e.Value === "copy" && J(), e.Value === "selectAll" && Y());
		}, Re = le(N, () => F.value, Le, q), X, Z = 0, Q = !0, $ = () => {
			Q && (cancelAnimationFrame(Z), Z = requestAnimationFrame(() => {
				let e = j.value;
				if (!e) return;
				let n = (t(p.TextTrimming || E.value.TextTrimming, b) ?? "None") !== "None" && (e.scrollWidth > e.clientWidth || e.scrollHeight > e.clientHeight);
				n !== L.value && (L.value = n, f("IsTextTrimmedChanged", B, { IsTextTrimmed: n })), z.Update([{
					Element: e,
					Start: 0
				}], [...ee(h.default?.() ?? [], b), ...R]);
			}));
		};
		Se(() => {
			document.addEventListener("selectionchange", K), X = new ResizeObserver($), j.value && X.observe(j.value), $();
		}), Ce($), y(R, $, { deep: !0 }), y(C, (e) => {
			e || (G() && window.getSelection()?.removeAllRanges(), K(), q());
		}), xe(() => {
			Q = !1, cancelAnimationFrame(Z), X?.disconnect(), z.Clear(), document.removeEventListener("selectionchange", K), M.value = !1;
		});
		let ze = {
			t: d,
			emit: f,
			props: p,
			attrs: m,
			slots: h,
			contentNodes: v,
			hasInlineContent: De,
			instance: b,
			InlineOutlet: Oe,
			resources: x,
			resolvedText: S,
			resolvedIsTextSelectionEnabled: C,
			resolvedVisibility: w,
			resolvedStyleName: T,
			typographyStyles: ke,
			styleSetters: E,
			foregroundBrush: D,
			localForeground: O,
			Foreground: k,
			resolvedTextWrapping: A,
			rootRef: j,
			contextMenuOpen: M,
			contextMenuRef: N,
			contextMenuAnchor: Ae,
			contextSelection: P,
			contextMenuItems: F,
			selectedText: I,
			isTextTrimmed: L,
			highlighters: R,
			textHighlights: z,
			api: B,
			textBlockAttrs: je,
			cssLength: V,
			xamlThickness: H,
			textWrapping: U,
			overflowWrap: W,
			textBlockStyle: Me,
			styleClass: Ne,
			selectionTextInBlock: G,
			onSelectionChanged: K,
			onCopyingToClipboard: Pe,
			onContextMenu: Fe,
			closeContextMenu: q,
			copySelectionToClipboard: J,
			selectAll: Y,
			select: Ie,
			onContextMenuSelect: Le,
			ContextMenu: Re,
			get resizeObserver() {
				return X;
			},
			set resizeObserver(e) {
				X = e;
			},
			get frame() {
				return Z;
			},
			set frame(e) {
				Z = e;
			},
			get active() {
				return Q;
			},
			set active(e) {
				Q = e;
			},
			measureText: $,
			get TextBlockInlines() {
				return r;
			},
			get TextBlockTextHighlighters() {
				return i;
			},
			get brushProperty() {
				return re;
			},
			Comment: me,
			computed: l,
			defineComponent: _e,
			Fragment: c,
			getCurrentInstance: ve,
			h: ye,
			inject: be,
			onBeforeUnmount: xe,
			onMounted: Se,
			onUpdated: Ce,
			reactive: g,
			ref: _,
			shallowRef: we,
			Text: he,
			useAttrs: Te,
			useSlots: Ee,
			watch: y,
			get textCommandFlyout() {
				return le;
			},
			get useI18n() {
				return ce;
			},
			get normalizeXamlNodes() {
				return e;
			},
			get resolveXamlValue() {
				return t;
			},
			get updateXamlBinding() {
				return n;
			},
			get getToolTipServiceProperty() {
				return ue;
			},
			xamlResourceDictionaryKey: de,
			get getVNodeChildren() {
				return fe;
			},
			get createTextHighlights() {
				return a;
			},
			get readTextHighlighters() {
				return ee;
			},
			get textBrush() {
				return o;
			},
			get textContentNodes() {
				return te;
			},
			get textFontWeight() {
				return ne;
			},
			get textPosition() {
				return s;
			},
			get isBrushProperty() {
				return ie;
			},
			get useBrushProperty() {
				return ae;
			},
			get isRadialGradientBrush() {
				return oe;
			},
			get vRadialGradientForeground() {
				return pe;
			}
		};
		return Object.defineProperty(ze, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), ze;
	}
});
function x(e, t, n, r, i, a) {
	return h(), d(c, null, [De((h(), d("span", p({ ref: "rootRef" }, r.textBlockAttrs, {
		class: ["win-text-block", [r.styleClass, r.attrs.class]],
		style: r.textBlockStyle,
		onContextmenu: r.onContextMenu,
		onCopy: r.onCopyingToClipboard
	}), [r.hasInlineContent ? u("", !0) : (h(), d("span", {
		key: 0,
		class: m({ "win-text-block-empty-line": String(r.resolvedText ?? "") === "" })
	}, v(r.resolvedText), 3)), f(r.InlineOutlet)], 16)), [[r.vRadialGradientForeground, r.Foreground]]), r.resolvedIsTextSelectionEnabled ? (h(), ge(r.ContextMenu, { key: 0 })) : u("", !0)], 64);
}
var S = /*#__PURE__*/ se(Oe, [["render", x], ["__file", "TextBlock.vue"]]);
//#endregion
export { S as default };

//# sourceMappingURL=TextBlock.vue.js.map