import { alignment as e, cssLength as t, xamlThickness as n } from "./layout.js";
import { resolveBrushStyle as r } from "./AcrylicBrush.js";
import { resolveXamlResourceObject as i, resolveXamlValue as a, xamlScopeKey as o } from "./xamlRuntime.js";
import { vAcrylicBrush as s } from "./acrylicBrushVisual.js";
import c from "./Image.vue.js";
import { computed as l, defineComponent as u, getCurrentInstance as d, onBeforeUnmount as f, onMounted as p, provide as m, reactive as h, ref as g, useAttrs as _, watch as v } from "vue";
//#region src/components/Ellipse.vue?vue&type=script&setup=true&lang.ts
var y = /*@__PURE__*/ u({
	inheritAttrs: !1,
	__name: "Ellipse",
	props: {
		Fill: {
			type: [String, Object],
			default: ""
		},
		Stroke: {
			type: [String, Object],
			default: ""
		},
		StrokeThickness: {
			type: [String, Number],
			default: ""
		},
		StrokeDashArray: {
			type: [String, Array],
			default: ""
		},
		Width: {
			type: [String, Number],
			default: ""
		},
		Height: {
			type: [String, Number],
			default: ""
		},
		MinWidth: {
			type: [String, Number],
			default: ""
		},
		MinHeight: {
			type: [String, Number],
			default: ""
		},
		MaxWidth: {
			type: [String, Number],
			default: ""
		},
		MaxHeight: {
			type: [String, Number],
			default: ""
		},
		Margin: {
			type: [String, Number],
			default: ""
		},
		Opacity: {
			type: [String, Number],
			default: ""
		},
		HorizontalAlignment: {
			type: String,
			default: ""
		},
		VerticalAlignment: {
			type: String,
			default: ""
		},
		Visibility: {
			type: String,
			default: "Visible"
		}
	},
	setup(u, { expose: y }) {
		y();
		let b = u, x = _(), S = d(), C = g(null), w = l(() => {
			let e = typeof b.Fill == "string" ? b.Fill.match(/^\{(?:StaticResource|ThemeResource)\s+([^\s}]+)\}$/)?.[1] : void 0;
			return e && i(e, S) !== void 0 ? i(e, S) : a(b.Fill, S);
		}), T = l(() => w.value && typeof w.value == "object" && "ImageSource" in w.value ? w.value : null), E = g(null), D = l(() => a(b.Stroke, S)), O = (e) => {
			let t = a(e, S), n = Number(t);
			return Number.isFinite(n) && n >= 0 ? n : 0;
		}, k = l(() => {
			if (!D.value) return 0;
			let e = a(b.StrokeThickness, S);
			return e === "" || e == null ? 1 : O(e);
		}), A = h({
			Source: l(() => a(T.value?.ImageSource, S)),
			Stretch: l(() => {
				let e = String(a(T.value?.Stretch, S) ?? "Fill");
				return [
					"None",
					"Fill",
					"Uniform",
					"UniformToFill"
				].includes(e) ? e : "Fill";
			}),
			Width: l(() => E.value?.width ?? Math.max(0, O(b.Width) - 2 * k.value)),
			Height: l(() => E.value?.height ?? Math.max(0, O(b.Height) - 2 * k.value))
		});
		m(o, { EllipseFill: A });
		let j = null;
		function M() {
			let e = C.value;
			if (!e) return;
			let t = getComputedStyle(e), n = (e) => Number.parseFloat(t.getPropertyValue(e)) || 0, r = Math.max(0, (Number.parseFloat(t.width) || e.clientWidth) - n("border-left-width") - n("border-right-width")), i = Math.max(0, (Number.parseFloat(t.height) || e.clientHeight) - n("border-top-width") - n("border-bottom-width"));
			(E.value?.width !== r || E.value?.height !== i) && (E.value = {
				width: r,
				height: i
			});
		}
		v(() => [
			b.Width,
			b.Height,
			b.Stroke,
			b.StrokeThickness
		].map((e) => a(e, S)), M, { flush: "post" }), p(() => {
			M(), typeof ResizeObserver < "u" && C.value && (j = new ResizeObserver(M), j.observe(C.value));
		}), f(() => j?.disconnect());
		let N = {
			props: b,
			attrs: x,
			instance: S,
			root: C,
			fill: w,
			imageBrush: T,
			fillSize: E,
			stroke: D,
			numericDimension: O,
			strokeInset: k,
			EllipseFill: A,
			get observer() {
				return j;
			},
			set observer(e) {
				j = e;
			},
			measureFill: M,
			forwardedAttrs: l(() => {
				let { class: e, style: t, ...n } = x;
				return n;
			}),
			ellipseStyle: l(() => {
				let i = t(a(b.StrokeThickness, S));
				T.value || (w.value && typeof w.value == "object" && "Color" in w.value ? a(w.value.Color, S) : w.value);
				let o = D.value && typeof D.value == "object" && "Color" in D.value ? a(D.value.Color, S) : D.value, s = {
					width: t(a(b.Width, S)) || void 0,
					height: t(a(b.Height, S)) || void 0,
					minWidth: t(a(b.MinWidth, S)) || void 0,
					minHeight: t(a(b.MinHeight, S)) || void 0,
					maxWidth: t(a(b.MaxWidth, S)) || void 0,
					maxHeight: t(a(b.MaxHeight, S)) || void 0,
					margin: n(a(b.Margin, S)) || void 0,
					...r(w.value, S),
					boxSizing: "border-box",
					borderRadius: "50%"
				};
				o && (s.borderStyle = "solid", s.borderColor = String(o), s.borderWidth = i || "1px"), b.Opacity !== "" && (s.opacity = String(a(b.Opacity, S))), b.HorizontalAlignment && (s.justifySelf = e(b.HorizontalAlignment, "horizontal")), b.VerticalAlignment && (s.alignSelf = e(b.VerticalAlignment, "vertical"));
				let c = a(b.Visibility, S) ?? b.Visibility;
				return c === "Collapsed" ? s.display = "none" : c === "Hidden" && (s.visibility = "hidden"), [x.style, s];
			}),
			Image: c,
			get vAcrylicBrush() {
				return s;
			}
		};
		return Object.defineProperty(N, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), N;
	}
});
//#endregion
export { y as default };

//# sourceMappingURL=Ellipse.vue_vue_type_script_setup_true_lang.js.map