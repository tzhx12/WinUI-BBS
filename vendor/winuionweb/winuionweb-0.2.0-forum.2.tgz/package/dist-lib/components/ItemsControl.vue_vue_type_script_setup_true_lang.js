import { boolValue as e } from "./layout.js";
import { normalizeXamlNodes as t, resolveXamlResourceObject as n, resolveXamlValue as r, updateXamlBinding as i, xamlItemContextKey as a, xamlTemplateComponent as o } from "./xamlRuntime.js";
import { frameworkLayoutStyle as s } from "./frameworkLayout.js";
import { xamlResourceDictionaryKey as c } from "./Page.vue_vue_type_script_lang.js";
import { CollectionItemTemplate as l, CollectionItemTemplateSelector as u, CollectionItems as d, CollectionItemsPanel as f, CollectionResources as p, getCollectionProperty as m, getVNodeChildren as h } from "./CollectionProperties.js";
import ee from "./ContentPresenter.vue.js";
import g from "./StackPanel.vue.js";
import { Comment as _, Fragment as v, Text as y, cloneVNode as b, computed as x, defineComponent as S, getCurrentInstance as C, h as w, inject as te, isVNode as T, onScopeDispose as ne, provide as E, proxyRefs as re, ref as D, shallowRef as ie, useAttrs as ae, useSlots as O, watch as k } from "vue";
var A = /*@__PURE__*/ S({
	Items: d,
	Resources: p,
	ItemTemplate: l,
	ItemTemplateSelector: u,
	ItemsPanel: f,
	name: "ItemsControl",
	inheritAttrs: !1,
	__name: "ItemsControl",
	props: {
		ItemsSource: {
			type: [
				String,
				Array,
				Object
			],
			default: null
		},
		ItemTemplate: {
			type: null,
			default: void 0
		},
		ItemTemplateSelector: {
			type: null,
			default: void 0
		},
		ItemsPanel: {
			type: null,
			default: void 0
		},
		IsEnabled: {
			type: [String, Boolean],
			default: !0
		},
		IsTabStop: {
			type: [String, Boolean],
			default: !0
		},
		Width: {
			type: [String, Number],
			default: ""
		},
		Height: {
			type: [String, Number],
			default: ""
		},
		MinWidth: {
			type: [String, Number],
			default: 0
		},
		MinHeight: {
			type: [String, Number],
			default: 0
		},
		MaxWidth: {
			type: [String, Number],
			default: ""
		},
		MaxHeight: {
			type: [String, Number],
			default: ""
		},
		Margin: {
			type: [String, Number],
			default: ""
		},
		Padding: {
			type: [String, Number],
			default: ""
		},
		Background: {
			type: [String, Object],
			default: ""
		},
		BorderBrush: {
			type: String,
			default: ""
		},
		BorderThickness: {
			type: [String, Number],
			default: ""
		},
		HorizontalAlignment: {
			type: String,
			default: "Stretch"
		},
		VerticalAlignment: {
			type: String,
			default: "Stretch"
		},
		Visibility: {
			type: String,
			default: "Visible"
		}
	},
	setup(l, { expose: u }) {
		let d = l, f = ae(), p = O(), A = C(), j = D(null), M = ie({}), N = (e) => r(e, A), P = (e) => e in M.value ? M.value[e] : N(d[e]), F = (e) => Array.isArray(e.children) ? e.children : e.children?.default?.() ?? [], I = (e) => typeof e.type == "string" ? e.type : e.type?.name ?? e.type?.__name ?? "", L = (e) => e.flatMap((e) => e.type === v ? L(F(e)) : e.type === _ || e.type === y && !String(e.children ?? "").trim() ? [] : [e]), R = x(() => L(p.default?.() ?? [])), z = (e) => R.value.filter((t) => m(t) === e), B = x(() => R.value.flatMap((e) => m(e) === "items" ? F(e) : m(e) ? [] : [e])), V = te(c, {}), H = x(() => {
			let e = { ...V }, t = (n) => {
				for (let r of L(n)) I(r) === "ResourceDictionary" ? t(F(r)) : r.props?.["x:Key"] && (e[String(r.props["x:Key"])] = r);
			};
			for (let e of z("resources")) t(F(e));
			return e;
		});
		E(c, new Proxy({}, {
			get: (e, t) => H.value[String(t)],
			ownKeys: () => Object.keys(H.value),
			getOwnPropertyDescriptor: () => ({
				configurable: !0,
				enumerable: !0
			})
		}));
		let U = (e, t) => {
			let r = e in M.value ? M.value[e] : d[e], i = typeof r == "string" ? r.match(/^\{(?:StaticResource|ThemeResource)\s+([^}]+)\}$/)?.[1] : void 0;
			return i ? H.value[i] ?? n(i, A) : N(r) ?? F(z(t)[0] ?? {})[0];
		}, W = D(0), G = x(() => P("ItemsSource")), K = () => {};
		k(G, (e) => {
			K();
			let t = e, n = () => {
				W.value += 1;
			};
			for (let e of ["CollectionChanged", "VectorChanged"]) t?.addEventListener?.(e, n);
			K = () => {
				for (let e of ["CollectionChanged", "VectorChanged"]) t?.removeEventListener?.(e, n);
			};
		}, {
			immediate: !0,
			flush: "sync"
		}), ne(() => K());
		let q = x(() => {
			W.value;
			let e = G.value;
			if (e == null) return B.value;
			if (Array.isArray(e)) return e;
			if (typeof e[Symbol.iterator] == "function") return Array.from(e);
			let t = Number(e.Count ?? e.Size ?? e.length ?? 0);
			return Array.from({ length: Number.isFinite(t) ? Math.max(0, t) : 0 }, (t, n) => e.GetAt?.(n) ?? e[n]);
		}), J = (e) => {
			let t = e.type, n = b(e, t?.props?.IsEnabled ? { IsEnabled: !1 } : {});
			return Array.isArray(e.children) ? n.children = e.children.map((e) => T(e) ? J(e) : e) : e.children && typeof e.children == "object" && (n.children = Object.fromEntries(Object.entries(e.children).map(([e, t]) => [e, typeof t == "function" ? (...e) => t(...e).map(J) : t]))), n;
		}, Y = S({
			props: ["item", "index"],
			setup: (e) => (E(a, x(() => e.item)), () => {
				let n = U("ItemTemplateSelector", "itemTemplateSelector"), r = n?.SelectTemplate?.(e.item, Q) ?? n?.SelectTemplateCore?.(e.item, Q) ?? U("ItemTemplate", "itemTemplate");
				if (!r && T(e.item)) return w(v, t([X.value ? e.item : J(e.item)], A));
				let i = !X.value && T(r) ? (e) => J(o(h(r), e, A)) : r;
				return w(ee, {
					Content: e.item,
					ContentTemplate: i,
					HorizontalContentAlignment: "Stretch",
					VerticalContentAlignment: "Stretch",
					"data-index": e.index
				});
			})
		}), oe = S({ setup: () => () => {
			let e = U("ItemsPanel", "itemsPanel"), t = T(e) && I(e) === "ItemsPanelTemplate" ? h(e)[0] : T(e) ? e : void 0, n = () => q.value.map((e, t) => w(Y, {
				key: T(e) ? e.key ?? t : t,
				item: e,
				index: t
			}));
			return t ? w(t.type, t.props, { default: n }) : w(g, { Orientation: "Vertical" }, { default: n });
		} }), X = x(() => e(P("IsEnabled"))), se = x(() => e(P("IsTabStop"))), ce = x(() => ({
			...s({
				...d,
				...M.value
			}, A),
			borderStyle: P("BorderThickness") === "" ? void 0 : "solid"
		})), Z = (e) => x({
			get: () => P(e),
			set: (t) => {
				M.value = {
					...M.value,
					[e]: t
				}, i(d[e], t, A);
			}
		}), Q = re({
			Element: j,
			Name: x(() => f["data-xaml-ref"] ?? f["x:Name"] ?? ""),
			Items: q,
			ItemsSource: Z("ItemsSource"),
			ItemTemplate: Z("ItemTemplate"),
			ItemTemplateSelector: Z("ItemTemplateSelector"),
			ItemsPanel: Z("ItemsPanel"),
			IsEnabled: Z("IsEnabled"),
			IsTabStop: Z("IsTabStop")
		});
		u(Q);
		let $ = {
			props: d,
			attrs: f,
			slots: p,
			instance: A,
			element: j,
			overrides: M,
			resolve: N,
			value: P,
			childrenOf: F,
			nameOf: I,
			flatten: L,
			declarations: R,
			propertyNodes: z,
			directItems: B,
			inheritedResources: V,
			resources: H,
			objectProperty: U,
			revision: W,
			source: G,
			get detachSource() {
				return K;
			},
			set detachSource(e) {
				K = e;
			},
			items: q,
			disabledNodes: J,
			ItemOutlet: Y,
			PanelOutlet: oe,
			IsEnabled: X,
			IsTabStop: se,
			hostStyle: ce,
			writable: Z,
			api: Q
		};
		return Object.defineProperty($, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), $;
	}
});
//#endregion
export { A as default };

//# sourceMappingURL=ItemsControl.vue_vue_type_script_setup_true_lang.js.map