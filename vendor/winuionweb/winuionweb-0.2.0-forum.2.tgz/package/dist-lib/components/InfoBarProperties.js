import { defineComponent as e } from "vue";
//#region src/components/InfoBarProperties.ts
var t = (t) => e({
	name: `InfoBar.${t}`,
	__infoBarProperty: t,
	setup() {
		return () => null;
	}
}), n = t("ActionButton"), r = t("Content"), i = t("ContentTemplate"), a = t("IconSource"), o = (e) => e.type?.__infoBarProperty;
//#endregion
export { n as InfoBarActionButton, r as InfoBarContent, i as InfoBarContentTemplate, a as InfoBarIconSource, o as getInfoBarProperty };

//# sourceMappingURL=InfoBarProperties.js.map