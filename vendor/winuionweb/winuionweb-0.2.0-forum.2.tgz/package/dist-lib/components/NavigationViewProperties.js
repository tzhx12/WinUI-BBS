import { __exportAll as e } from "../_virtual/_rolldown/runtime.js";
import { Fragment as t, defineComponent as n, getCurrentInstance as r, inject as i } from "vue";
//#region src/components/NavigationViewProperties.ts
var a = /* @__PURE__ */ e({
	MenuItemTemplateSelector: () => M,
	MenuItemTemplateSelectorItemTemplate: () => j,
	NavigationViewAutoSuggestBox: () => x,
	NavigationViewContent: () => _,
	NavigationViewContentOverlay: () => S,
	NavigationViewFooterMenuItems: () => u,
	NavigationViewFooterMenuItemsSource: () => m,
	NavigationViewHeader: () => h,
	NavigationViewHeaderTemplate: () => g,
	NavigationViewItem: () => N,
	NavigationViewItemContent: () => k,
	NavigationViewItemHeader: () => P,
	NavigationViewItemIcon: () => O,
	NavigationViewItemInfoBadge: () => d,
	NavigationViewItemMenuItems: () => f,
	NavigationViewItemMenuItemsSource: () => A,
	NavigationViewItemSeparator: () => F,
	NavigationViewMenuItemContainerStyle: () => T,
	NavigationViewMenuItemContainerStyleSelector: () => E,
	NavigationViewMenuItemTemplate: () => C,
	NavigationViewMenuItemTemplateSelector: () => w,
	NavigationViewMenuItems: () => l,
	NavigationViewMenuItemsSource: () => p,
	NavigationViewPaneCustomContent: () => b,
	NavigationViewPaneFooter: () => y,
	NavigationViewPaneHeader: () => v,
	NavigationViewPaneToggleButtonStyle: () => D,
	getNavigationViewProperty: () => I,
	navigationItemType: () => z,
	navigationVNodeChildren: () => R,
	navigationViewItemRendererKey: () => o
}), o = Symbol.for("winui.navigationViewItemRenderer"), s = () => {
	let e = r(), t = i(o, null);
	return () => t && e ? t(e.vnode) : null;
}, c = (e, t, r) => n({
	name: `${t}.${r}`,
	__navigationProperty: e,
	setup() {
		return () => null;
	}
}), l = c("menuItems", "NavigationView", "MenuItems"), u = c("footerMenuItems", "NavigationView", "FooterMenuItems"), d = c("infoBadge", "NavigationViewItem", "InfoBadge"), f = c("menuItems", "NavigationViewItem", "MenuItems"), p = c("menuItemsSource", "NavigationView", "MenuItemsSource"), m = c("footerMenuItemsSource", "NavigationView", "FooterMenuItemsSource"), h = c("header", "NavigationView", "Header"), g = c("headerTemplate", "NavigationView", "HeaderTemplate"), _ = c("content", "NavigationView", "Content"), v = c("paneHeader", "NavigationView", "PaneHeader"), y = c("paneFooter", "NavigationView", "PaneFooter"), b = c("paneCustomContent", "NavigationView", "PaneCustomContent"), x = c("autoSuggestBox", "NavigationView", "AutoSuggestBox"), S = c("contentOverlay", "NavigationView", "ContentOverlay"), C = c("menuItemTemplate", "NavigationView", "MenuItemTemplate"), w = c("menuItemTemplateSelector", "NavigationView", "MenuItemTemplateSelector"), T = c("menuItemContainerStyle", "NavigationView", "MenuItemContainerStyle"), E = c("menuItemContainerStyleSelector", "NavigationView", "MenuItemContainerStyleSelector"), D = c("paneToggleButtonStyle", "NavigationView", "PaneToggleButtonStyle"), O = c("icon", "NavigationViewItem", "Icon"), k = c("content", "NavigationViewItem", "Content"), A = c("menuItemsSource", "NavigationViewItem", "MenuItemsSource"), j = c("itemTemplate", "MenuItemTemplateSelector", "ItemTemplate"), M = n({
	name: "MenuItemTemplateSelector",
	ItemTemplate: j,
	setup() {
		return () => null;
	}
}), N = n({
	name: "NavigationViewItem",
	__navigationItemType: "Item",
	InfoBadge: d,
	Icon: O,
	Content: k,
	MenuItems: f,
	MenuItemsSource: A,
	setup: s
}), P = n({
	name: "NavigationViewItemHeader",
	__navigationItemType: "Header",
	setup: s
}), F = n({
	name: "NavigationViewItemSeparator",
	__navigationItemType: "Separator",
	setup: s
}), I = (e) => {
	let t = e.type;
	if (t?.__navigationProperty) return t.__navigationProperty;
	if (typeof e.type == "string") {
		let t = e.type.match(/^(NavigationView|NavigationViewItem|MenuItemTemplateSelector)\.([A-Z][A-Za-z]+)$/);
		if (t) {
			let e = t[2], n = `${e[0].toLowerCase()}${e.slice(1)}`;
			if (L.has(n)) return n;
		}
	}
}, L = new Set([
	"menuItems",
	"menuItemsSource",
	"footerMenuItems",
	"footerMenuItemsSource",
	"infoBadge",
	"icon",
	"content",
	"header",
	"headerTemplate",
	"paneHeader",
	"paneFooter",
	"paneCustomContent",
	"autoSuggestBox",
	"contentOverlay",
	"menuItemTemplate",
	"menuItemTemplateSelector",
	"menuItemContainerStyle",
	"menuItemContainerStyleSelector",
	"paneToggleButtonStyle",
	"itemTemplate"
]), R = (e) => {
	let n = Array.isArray(e.children) ? e.children : e.children?.default?.() ?? [];
	return (Array.isArray(n) ? n : [n]).flatMap((e) => e?.type === t ? R(e) : e ? [e] : []);
}, z = (e) => {
	let t = e.type;
	if (typeof t != "string" && t?.__navigationItemType) return t.__navigationItemType;
	let n = typeof t == "string" ? t : t?.name ?? t?.__name;
	return n === "NavigationViewItem" ? "Item" : n === "NavigationViewItemHeader" ? "Header" : n === "NavigationViewItemSeparator" ? "Separator" : "";
};
//#endregion
export { x as NavigationViewAutoSuggestBox, _ as NavigationViewContent, S as NavigationViewContentOverlay, u as NavigationViewFooterMenuItems, m as NavigationViewFooterMenuItemsSource, h as NavigationViewHeader, g as NavigationViewHeaderTemplate, T as NavigationViewMenuItemContainerStyle, E as NavigationViewMenuItemContainerStyleSelector, C as NavigationViewMenuItemTemplate, w as NavigationViewMenuItemTemplateSelector, l as NavigationViewMenuItems, p as NavigationViewMenuItemsSource, b as NavigationViewPaneCustomContent, y as NavigationViewPaneFooter, v as NavigationViewPaneHeader, D as NavigationViewPaneToggleButtonStyle, a as NavigationViewProperties_exports, I as getNavigationViewProperty, z as navigationItemType, R as navigationVNodeChildren, o as navigationViewItemRendererKey };

//# sourceMappingURL=NavigationViewProperties.js.map