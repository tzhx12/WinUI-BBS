import { markRaw as e, reactive as t } from "vue";
//#region src/components/SwipeItemsCollection.ts
var n = /* @__PURE__ */ new WeakMap(), r = (e, t, r) => {
	let i = n.get(e);
	return i || (i = /* @__PURE__ */ new Map(), n.set(e, i)), i.set(t, r), () => i.delete(t);
}, i = class {
	#e = t({
		mode: "Reveal",
		entries: []
	});
	constructor() {
		e(this);
	}
	get Mode() {
		return this.#e.mode;
	}
	set Mode(e) {
		if (e !== "Reveal" && e !== "Execute") throw TypeError("Invalid SwipeMode.");
		this.#t(this.Size, e), this.#e.mode = e;
	}
	get Size() {
		return this.#e.entries.length;
	}
	get Count() {
		return this.Size;
	}
	GetAt(e) {
		return this.#n(e), this.#e.entries[e];
	}
	SetAt(e, t) {
		this.#n(e);
		let n = [...this.#e.entries];
		n[e] = t, this.ReplaceAll(n);
	}
	InsertAt(e, t) {
		this.#n(e, !0);
		let n = [...this.#e.entries];
		n.splice(e, 0, t), this.ReplaceAll(n);
	}
	RemoveAt(e) {
		this.#n(e);
		let t = [...this.#e.entries];
		t.splice(e, 1), this.ReplaceAll(t);
	}
	Append(e) {
		this.InsertAt(this.Size, e);
	}
	RemoveAtEnd() {
		this.RemoveAt(this.Size - 1);
	}
	Clear() {
		this.ReplaceAll([]);
	}
	ReplaceAll(e) {
		let t = Array.from(e);
		if (this.#t(t.length, this.Mode), t.some((e) => !e || typeof e != "object")) throw TypeError("SwipeItems can only contain SwipeItem values.");
		this.#e.entries = t;
	}
	IndexOf(e) {
		let t = this.#e.entries.indexOf(e);
		return {
			found: t >= 0,
			index: Math.max(0, t)
		};
	}
	GetView() {
		return Object.freeze([...this.#e.entries]);
	}
	[Symbol.iterator]() {
		return this.#e.entries[Symbol.iterator]();
	}
	#t(e, t) {
		if (t === "Execute" && e > 1) throw RangeError("SwipeItems in Execute mode cannot contain more than one SwipeItem.");
		for (let r of n.get(this)?.values() ?? []) r(e, t);
	}
	#n(e, t = !1) {
		if (!Number.isInteger(e) || e < 0 || e >= this.Size + Number(t)) throw RangeError("SwipeItems index is out of bounds.");
	}
};
//#endregion
export { i as SwipeItemsCollection, r as observeSwipeItemsChanging };

//# sourceMappingURL=SwipeItemsCollection.js.map