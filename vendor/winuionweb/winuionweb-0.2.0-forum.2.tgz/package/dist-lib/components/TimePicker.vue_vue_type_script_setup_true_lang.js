import { alignment as e, cssLength as t, xamlThickness as n } from "./layout.js";
import { normalizeXamlNodes as r, resolveXamlHandler as i, resolveXamlValue as a, updateXamlBinding as ee, xamlScopeKey as o, xamlTemplateComponent as s } from "./xamlRuntime.js";
import te from "./Grid.vue.js";
import { useI18n as c } from "./i18n/index.js";
import { xamlResourceDictionaryKey as ne } from "./Page.vue_vue_type_script_lang.js";
import { getVNodeChildren as l } from "./CollectionProperties.js";
import re from "./TextBlock.vue.js";
import ie from "./Border.vue.js";
import ae from "./ContentPresenter.vue.js";
import oe from "./Button.vue.js";
import se from "./ColumnDefinition.vue.js";
import ce from "./RowDefinition.vue.js";
import le from "./Rectangle.vue.js";
import ue from "./DateTimePickerFlyout.vue.js";
import { Fragment as de, computed as u, defineComponent as fe, getCurrentInstance as pe, h as me, inject as he, isVNode as ge, nextTick as _e, onBeforeUnmount as ve, provide as ye, ref as d, unref as be, useAttrs as xe, useSlots as Se, watch as f } from "vue";
//#region src/components/TimePicker.vue?vue&type=script&setup=true&lang.ts
var p = (e) => fe({
	name: `TimePicker.${e}`,
	__timePickerProperty: e,
	setup(e, { slots: t }) {
		return () => me(de, t.default?.());
	}
}), Ce = /*@__PURE__*/ fe({
	Header: p("Header"),
	HeaderTemplate: p("HeaderTemplate"),
	inheritAttrs: !1,
	__name: "TimePicker",
	props: {
		ClockIdentifier: {
			type: String,
			default: void 0
		},
		Header: {
			type: null,
			default: null
		},
		HeaderTemplate: {
			type: null,
			default: null
		},
		HeaderPlacement: {
			type: String,
			default: "Top"
		},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		Language: {
			type: String,
			default: ""
		},
		LightDismissOverlayMode: {
			type: String,
			default: "Auto"
		},
		MinuteIncrement: {
			type: [Number, String],
			default: 1
		},
		SelectedTime: {
			type: [Number, String],
			default: void 0
		},
		Time: {
			type: [Number, String],
			default: void 0
		},
		RequestedTheme: {
			type: String,
			default: "Default"
		},
		Width: {
			type: [String, Number],
			default: ""
		},
		Height: {
			type: [String, Number],
			default: ""
		},
		MinWidth: {
			type: [String, Number],
			default: ""
		},
		MinHeight: {
			type: [String, Number],
			default: ""
		},
		MaxWidth: {
			type: [String, Number],
			default: ""
		},
		MaxHeight: {
			type: [String, Number],
			default: ""
		},
		Margin: {
			type: [String, Number],
			default: ""
		},
		Padding: {
			type: [String, Number],
			default: ""
		},
		HorizontalAlignment: {
			type: String,
			default: "Left"
		},
		VerticalAlignment: {
			type: String,
			default: "Center"
		},
		Visibility: {
			type: String,
			default: "Visible"
		},
		FontSize: {
			type: [String, Number],
			default: ""
		},
		FontFamily: {
			type: String,
			default: ""
		},
		FontWeight: {
			type: [String, Number],
			default: "Normal"
		},
		Background: {
			type: String,
			default: "{ThemeResource TimePickerButtonBackground}"
		},
		Foreground: {
			type: String,
			default: "{ThemeResource TimePickerButtonForeground}"
		},
		BorderBrush: {
			type: String,
			default: "{ThemeResource TimePickerButtonBorderBrush}"
		},
		BorderThickness: {
			type: [String, Number],
			default: 1
		},
		CornerRadius: {
			type: [String, Number],
			default: "{ThemeResource ControlCornerRadius}"
		}
	},
	emits: [
		"TimeChanged",
		"SelectedTimeChanged",
		"update:Time",
		"update:SelectedTime"
	],
	setup(Ce, { expose: we, emit: Te }) {
		let m = Ce, h = Te, g = pe(), _ = xe(), Ee = Se(), { t: v, locale: De } = c(), Oe = he("winuiTheme", null), y = he(ne, null), ke = d(null), Ae = d(null), b = d(null), x = d(null), S = d(0), C = d("number"), je = d(1), w = d(""), T = (e) => a(e, g), E = u(() => ![
			!1,
			"False",
			"false"
		].includes(T(m.IsEnabled))), D = u(() => String(T(m.Language) || De)), O = 864e5, k = 36e5, A = 6e4, j = (e) => {
			if (e == null || e === "") return null;
			if (typeof e == "number") {
				if (e === -1) return null;
				if (e < 0) throw RangeError("Time must be non-negative or the -1 null sentinel.");
				return Number.isFinite(e) ? {
					milliseconds: e,
					kind: "number"
				} : null;
			}
			if (typeof e != "string") return null;
			let t = e.trim();
			if (t.startsWith("-")) throw RangeError("Time must be non-negative or the -1 null sentinel.");
			let n = t.match(/^(\d+):([0-5]\d):([0-5]\d)(?:\.(\d{1,7}))?$/);
			if (!n) return null;
			let r = n[4] ? Number(`0.${n[4].slice(0, 3).padEnd(3, "0")}`) * 1e3 : 0, i = Number(n[1]) * k + Number(n[2]) * A + Number(n[3]) * 1e3 + r;
			return Number.isFinite(i) ? {
				milliseconds: i,
				kind: "string"
			} : null;
		}, Me = (e) => {
			if (e == null || e === "") return 1;
			let t = Number(e);
			if (!Number.isInteger(t) || t < 0 || t > 59) throw RangeError("MinuteIncrement must be an integer from 0 through 59.");
			return t;
		}, Ne = (e) => {
			if (e == null) return "";
			let t = String(e);
			if (t !== "12HourClock" && t !== "24HourClock") throw RangeError("ClockIdentifier must be 12HourClock or 24HourClock.");
			return t;
		}, M = u(() => je.value), N = u(() => M.value === 0 ? 60 : M.value), P = (e) => {
			let t = j(e);
			if (!t) return null;
			let n = (Math.trunc(t.milliseconds) % O + O) % O, r = Math.floor(n / k), i = Math.floor(n % k / A);
			return r * k + (i - i % N.value) * A;
		}, Pe = (e) => {
			let t = (Math.trunc(e) % O + O) % O;
			return `${String(Math.floor(t / k)).padStart(2, "0")}:${String(Math.floor(t % k / A)).padStart(2, "0")}:00`;
		}, F = (e, t = C.value) => e === null ? null : t === "string" ? Pe(e) : e, I = (e, t = C.value) => e === null ? -1 : F(e, t), L = u(() => {
			let e = w.value;
			if (e === "12HourClock" || e === "24HourClock") return e;
			let t = new Intl.DateTimeFormat(D.value, { hour: "numeric" }).resolvedOptions().hourCycle;
			return t === "h11" || t === "h12" ? "12HourClock" : "24HourClock";
		}), R = u(() => L.value === "12HourClock" ? [
			12,
			1,
			2,
			3,
			4,
			5,
			6,
			7,
			8,
			9,
			10,
			11
		] : Array.from({ length: 24 }, (e, t) => t)), z = u(() => Array.from({ length: Math.ceil(60 / N.value) }, (e, t) => t * N.value).filter((e) => e < 60)), B = (e) => new Intl.DateTimeFormat(D.value, {
			...e,
			timeZone: "UTC"
		}), V = u(() => L.value === "12HourClock" ? "h12" : "h23"), H = (e, t, n) => B({
			...t,
			hourCycle: V.value
		}).formatToParts(new globalThis.Date(Date.UTC(2024, 0, 1, e))).find((e) => e.type === n)?.value || "", U = u(() => R.value.map((e) => H(L.value === "12HourClock" && e === 12 ? 0 : e, { hour: "numeric" }, "hour"))), W = u(() => z.value.map((e) => B({
			hour: "numeric",
			minute: "2-digit",
			hourCycle: "h23"
		}).formatToParts(new globalThis.Date(Date.UTC(2024, 0, 1, 0, e))).find((e) => e.type === "minute")?.value || String(e).padStart(2, "0"))), G = u(() => [H(9, { hour: "numeric" }, "dayPeriod") || v("timePicker.am"), H(15, { hour: "numeric" }, "dayPeriod") || v("timePicker.pm")]), K = (e) => new globalThis.Date((Math.trunc(e) % O + O) % O), Fe = u(() => {
			let e = B({
				hour: "numeric",
				minute: "2-digit",
				hourCycle: V.value
			}).formatToParts(new globalThis.Date(Date.UTC(2024, 0, 1, 13, 5))).filter((e) => e.type === "hour" || e.type === "minute" || e.type === "dayPeriod").map((e) => e.type === "dayPeriod" ? "period" : e.type), t = e.filter((t, n) => e.indexOf(t) === n);
			return t.includes("hour") || t.push("hour"), t.includes("minute") || t.push("minute"), L.value === "12HourClock" && !t.includes("period") && t.push("period"), t.slice(0, L.value === "12HourClock" ? 3 : 2);
		}), q = u(() => Fe.value.map((e) => {
			let t = K(S.value), n = t.getUTCHours() % 12 || 12, r = e === "hour" ? R.value.indexOf(L.value === "12HourClock" ? n : t.getUTCHours()) : e === "minute" ? z.value.indexOf(t.getUTCMinutes()) : +(t.getUTCHours() >= 12);
			return {
				key: e,
				items: e === "hour" ? U.value : e === "minute" ? W.value : G.value,
				index: Math.max(0, r),
				loop: e === "hour" || e === "minute" && M.value !== 0,
				weight: 1,
				align: "Center",
				label: v(`timePicker.${e}`)
			};
		})), J = (e) => {
			if (!e) return "";
			if (x.value === null) return e === "hour" ? v("timePicker.hour") : e === "minute" ? v("timePicker.minute") : G.value[0];
			let t = K(x.value);
			return e === "hour" ? U.value[R.value.indexOf(L.value === "12HourClock" ? t.getUTCHours() % 12 || 12 : t.getUTCHours())] ?? "" : e === "minute" ? W.value[z.value.indexOf(t.getUTCMinutes())] ?? String(t.getUTCMinutes()).padStart(2, "0") : G.value[+(t.getUTCHours() >= 12)];
		}, Ie = u(() => ({ gridTemplateColumns: q.value.flatMap((e, t) => [t ? "1px" : "", "minmax(0, 1fr)"]).filter(Boolean).join(" ") })), Le = u(() => ({ textAlign: "center" })), Re = u(() => ({ textAlign: "center" })), ze = u(() => ({ textAlign: "center" })), Y = u(() => {
			let e = String(T(m.RequestedTheme)).toLowerCase();
			return e === "dark" || e === "light" ? e : String(be(Oe) || "Default").toLowerCase();
		}), X = (e) => {
			let t = (n) => n.flatMap((n) => n.type === de && Array.isArray(n.children) ? t(n.children) : n.type?.__timePickerProperty === e ? l(n) : []);
			return t(Ee.default?.() ?? []);
		}, Z = u(() => T(m.Header)), Be = u(() => Z.value !== null && Z.value !== void 0 && Z.value !== "" || X("Header").length > 0 || X("HeaderTemplate").length > 0 || !!m.HeaderTemplate), Ve = fe({ setup() {
			return () => {
				let e = X("HeaderTemplate"), t = X("Header"), n = typeof m.HeaderTemplate == "string" ? m.HeaderTemplate.match(/^\{StaticResource\s+([^\s}]+)\}$/)?.[1] : null;
				if (e.length) return s(e, Z.value, g);
				if (n && y?.[n]) return s(l(y[n]), Z.value, g);
				if (t.length) return me(de, r(t, g));
				let i = T(m.HeaderTemplate);
				return ge(i) ? s([i], Z.value, g) : ge(Z.value) ? Z.value : String(Z.value ?? "");
			};
		} }), He = u(() => ({
			"win-time-picker": !0,
			"has-no-time": x.value === null,
			"is-disabled": !E.value,
			"header-left": String(T(m.HeaderPlacement)) === "Left",
			"win-theme-scope": ["dark", "light"].includes(Y.value),
			"theme-dark": Y.value === "dark",
			"theme-light": Y.value === "light"
		})), Ue = u(() => Object.fromEntries(Object.entries(_).filter(([e]) => ![
			"class",
			"style",
			"TimeChanged",
			"SelectedTimeChanged"
		].includes(e)))), We = u(() => {
			let r = {
				"--picker-background": T(m.Background),
				"--picker-foreground": T(m.Foreground),
				"--picker-border-thickness": n(T(m.BorderThickness)),
				"--picker-radius": t(T(m.CornerRadius)),
				margin: n(T(m.Margin)),
				padding: n(T(m.Padding)),
				alignSelf: e(T(m.VerticalAlignment), "vertical"),
				justifySelf: e(T(m.HorizontalAlignment), "horizontal"),
				fontSize: t(T(m.FontSize)),
				fontFamily: T(m.FontFamily) || void 0,
				fontWeight: T(m.FontWeight) === "Normal" ? 400 : T(m.FontWeight)
			};
			for (let e of [
				"Width",
				"Height",
				"MinWidth",
				"MinHeight",
				"MaxWidth",
				"MaxHeight"
			]) T(m[e]) !== "" && (r[e[0].toLowerCase() + e.slice(1)] = t(T(m[e])));
			return T(m.Visibility) === "Collapsed" && (r.display = "none"), T(m.Visibility) === "Hidden" && (r.visibility = "hidden"), [_.style, r];
		}), Ge = (e, t) => {
			h(e, $, t), i(_[e], g)?.($, t);
		}, Q = (e, t = !0, n) => {
			let r = j(e), i = r ? P(e) : null, a = n ?? r?.kind ?? C.value, o = x.value, s = C.value;
			if (C.value = a, o === i) return;
			x.value = i;
			let te = I(o, s), c = I(i, a), ne = F(o, s), l = F(i, a);
			ee(m.Time, c, g), ee(m.SelectedTime, l, g), h("update:Time", c), h("update:SelectedTime", l), t && (Ge("TimeChanged", {
				OldTime: te,
				NewTime: c
			}), Ge("SelectedTimeChanged", {
				OldTime: ne,
				NewTime: l
			}));
		}, Ke = async () => {
			if (!E.value) return;
			if (b.value?.IsOpen) {
				b.value.Hide();
				return;
			}
			let e = new globalThis.Date();
			S.value = x.value ?? P(e.getHours() * k + e.getMinutes() * A) ?? 0, await _e();
			let t = ke.value?.querySelector(".picker-button");
			t && b.value?.ShowAt(t);
		}, qe = (e, t) => {
			if (t.Indices) {
				let e = K(S.value), n = t.Indices.hour === void 0 ? L.value === "12HourClock" ? e.getUTCHours() % 12 || 12 : e.getUTCHours() : R.value[t.Indices.hour], r = t.Indices.minute === void 0 ? e.getUTCMinutes() : z.value[t.Indices.minute], i = t.Indices.period === void 0 ? +(e.getUTCHours() >= 12) : t.Indices.period;
				if (n === void 0 || r === void 0) return;
				S.value = (L.value === "12HourClock" ? n % 12 + (i === 1 ? 12 : 0) : n) * k + r * A;
				return;
			}
			if (t.Key === void 0 || t.SelectedIndex === void 0 || !q.value.some((e) => e.key === t.Key)) return;
			let n = K(S.value);
			if (t.Key === "hour") {
				let e = R.value[t.SelectedIndex] ?? R.value[0], r = L.value === "12HourClock" && n.getUTCHours() >= 12 ? 12 : 0;
				n.setUTCHours(L.value === "12HourClock" ? e % 12 + r : e);
			} else t.Key === "minute" ? n.setUTCMinutes(z.value[t.SelectedIndex] ?? 0) : n.setUTCHours(n.getUTCHours() % 12 + (t.SelectedIndex === 1 ? 12 : 0));
			S.value = n.getUTCHours() * k + n.getUTCMinutes() * A;
		}, Je = (e, t) => {
			t.Accepted && Q(S.value, !0, C.value);
		}, $ = {
			Time: u({
				get: () => I(x.value),
				set: (e) => Q(e)
			}),
			SelectedTime: u({
				get: () => F(x.value),
				set: (e) => Q(e)
			}),
			Focus: () => ke.value?.querySelector(".picker-button")?.focus()
		};
		ye(o, {
			PickerEnabled: E,
			PickerColumns: q,
			PickerTheme: Y,
			PickerOverlayMode: u(() => T(m.LightDismissOverlayMode)),
			PickerBorderBrush: u(() => T(m.BorderBrush)),
			PickerBorderThickness: u(() => T(m.BorderThickness)),
			PickerCornerRadius: u(() => T(m.CornerRadius)),
			PickerAutomationName: u(() => [String(Z.value || v("timePicker.name")), q.value.map((e) => J(e.key)).join(" ")].filter(Boolean).join(" ")),
			FirstText: u(() => J(q.value[0]?.key)),
			SecondText: u(() => J(q.value[1]?.key)),
			ThirdText: u(() => J(q.value[2]?.key)),
			OnFlyoutButtonClick: Ke,
			OnFlyoutSelectionChanged: qe,
			OnFlyoutClosed: Je
		}), f(() => T(m.MinuteIncrement), (e) => {
			je.value = Me(e);
		}, { immediate: !0 }), f(() => T(m.ClockIdentifier), (e) => {
			w.value = Ne(e);
		}, { immediate: !0 }), f([() => T(m.SelectedTime), () => T(m.Time)], ([e, t], n) => {
			let r = n?.length ? e === n[0] ? t : e : e === void 0 ? t : e, i = j(r);
			Q(r, (n?.length ?? 0) > 0, i?.kind);
		}, { immediate: !0 }), f(N, () => {
			x.value !== null && Q(x.value, !0, C.value), b.value?.IsOpen && (S.value = P(S.value) ?? 0);
		}), f(E, (e) => {
			e || b.value?.Hide();
		}), ve(() => {
			b.value?.Hide();
		}), we($);
		let Ye = {
			property: p,
			props: m,
			emit: h,
			instance: g,
			attrs: _,
			slots: Ee,
			t: v,
			locale: De,
			inheritedTheme: Oe,
			resources: y,
			rootRef: ke,
			buttonRef: Ae,
			flyoutRef: b,
			localTime: x,
			draft: S,
			representation: C,
			minuteIncrement: je,
			clockIdentifier: w,
			value: T,
			enabled: E,
			language: D,
			DAY: O,
			HOUR: k,
			MINUTE: A,
			parseTime: j,
			validateMinuteIncrement: Me,
			validateClockIdentifier: Ne,
			normalizedIncrement: M,
			adjustedIncrement: N,
			coerceMilliseconds: P,
			formatTimeSpan: Pe,
			encodeSelectedTime: F,
			encodeTime: I,
			effectiveClock: L,
			hourValues: R,
			minutes: z,
			formatter: B,
			clockCycle: V,
			formatPart: H,
			hourItems: U,
			minuteItems: W,
			periodItems: G,
			currentDate: K,
			order: Fe,
			fields: q,
			textFor: J,
			columnStyle: Ie,
			firstStyle: Le,
			secondStyle: Re,
			thirdStyle: ze,
			theme: Y,
			propertyNodes: X,
			header: Z,
			hasHeader: Be,
			HeaderContent: Ve,
			rootClasses: He,
			rootAttrs: Ue,
			rootStyle: We,
			raise: Ge,
			setTime: Q,
			OnFlyoutButtonClick: Ke,
			OnFlyoutSelectionChanged: qe,
			OnFlyoutClosed: Je,
			publicApi: $,
			Border: ie,
			Button: oe,
			ColumnDefinition: se,
			ContentPresenter: ae,
			DateTimePickerFlyout: ue,
			Grid: te,
			Rectangle: le,
			RowDefinition: ce,
			TextBlock: re
		};
		return Object.defineProperty(Ye, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), Ye;
	}
});
//#endregion
export { Ce as default };

//# sourceMappingURL=TimePicker.vue_vue_type_script_setup_true_lang.js.map