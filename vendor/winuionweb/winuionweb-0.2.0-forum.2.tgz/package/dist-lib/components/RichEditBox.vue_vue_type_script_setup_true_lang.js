import { cssLength as e } from "./layout.js";
import { eventNames as t, normalizeXamlNodes as n, resolveXamlHandler as r, resolveXamlValue as i, updateXamlBinding as a, xamlControlIdentityKey as o, xamlScopeKey as s } from "./xamlRuntime.js";
import { brushProperty as c } from "./brushProperties.js";
import l from "./AppBarButton.vue.js";
import { commandChildren as ee, flattenCommandNodes as te } from "./commandBarRuntime.js";
import { useI18n as ne } from "./i18n/index.js";
import re from "./CommandBarFlyout.vue.js";
import ie from "./AppBarToggleButton.vue.js";
import ae from "./ScrollViewer.vue.js";
import { textInputTemplateKey as oe } from "./textInputTemplate.js";
import { scrollViewerTemplateBindings as se } from "./scrollViewerTemplateBindings.js";
import ce from "./TextBox.vue.js";
import { linearMathToElement as le, loadRtf as ue, parseMathML as de, saveRtf as fe } from "./richEditDocument.js";
import { Fragment as pe, computed as u, defineComponent as d, getCurrentInstance as me, h as f, inject as he, nextTick as ge, onBeforeUnmount as _e, onMounted as ve, provide as p, ref as m, shallowReactive as ye, useAttrs as be, useSlots as xe, watch as Se } from "vue";
//#region src/components/RichEditBox.vue?vue&type=script&setup=true&lang.ts
var Ce = (e) => d({
	name: `RichEditBox.${e}`,
	__richEditBoxProperty: e,
	__textInputProperty: e,
	setup: () => () => null
}), we = /*@__PURE__*/ d({
	Background: c("RichEditBox", "Background"),
	Header: Ce("Header"),
	HeaderTemplate: Ce("HeaderTemplate"),
	Description: Ce("Description"),
	ContextFlyout: Ce("ContextFlyout"),
	SelectionFlyout: Ce("SelectionFlyout"),
	inheritAttrs: !1,
	__name: "RichEditBox",
	props: {
		AcceptsReturn: {
			type: Boolean,
			default: !0
		},
		CharacterCasing: { default: "Normal" },
		ClipboardCopyFormat: { default: "AllFormats" },
		Description: { default: "" },
		DesiredCandidateWindowAlignment: { default: "Default" },
		DisabledFormattingAccelerators: { default: "None" },
		FontFamily: { default: "" },
		FontSize: { default: "" },
		FontWeight: { default: "" },
		FontStyle: { default: "Normal" },
		Header: { default: "" },
		HeaderPlacement: { default: "Top" },
		HeaderTemplate: { default: void 0 },
		HorizontalTextAlignment: { default: "Left" },
		InputScope: { default: "Default" },
		IsColorFontEnabled: {
			type: Boolean,
			default: !0
		},
		IsReadOnly: {
			type: Boolean,
			default: !1
		},
		IsEnabled: {
			type: Boolean,
			default: !0
		},
		IsSpellCheckEnabled: {
			type: Boolean,
			default: !0
		},
		IsTextPredictionEnabled: {
			type: Boolean,
			default: !0
		},
		MaxLength: { default: 0 },
		PlaceholderText: { default: "" },
		PreventKeyboardDisplayOnProgrammaticFocus: {
			type: Boolean,
			default: !1
		},
		ProofingMenuFlyout: { default: void 0 },
		SelectionFlyout: { default: void 0 },
		ContextFlyout: { default: void 0 },
		SelectionHighlightColor: { default: "" },
		SelectionHighlightColorWhenNotFocused: { default: "" },
		TextAlignment: { default: "Left" },
		TextReadingOrder: { default: "DetectFromContent" },
		TextWrapping: { default: "Wrap" },
		Width: { default: "" },
		Height: { default: "" },
		MinHeight: { default: "" }
	},
	emits: [
		"TextChanged",
		"SelectionChanged",
		"SelectionChanging",
		"ContextMenuOpening",
		"Paste",
		"CopyingToClipboard",
		"CuttingToClipboard",
		"TextChanging",
		"TextCompositionStarted",
		"TextCompositionChanged",
		"TextCompositionEnded",
		"CandidateWindowBoundsChanged",
		"GotFocus",
		"LostFocus",
		"Loaded",
		"Unloaded"
	],
	setup(c, { expose: we, emit: Te }) {
		let { t: h } = ne(), g = me(), _ = be(), Ee = xe(), De = u(() => i(_["AutomationProperties.Name"] ?? _["aria-label"], g)), Oe = (e) => {
			let t = te(Ee.default?.() ?? []).find((t) => t.type.__richEditBoxProperty === e);
			return n(t ? ee(t) : [], g);
		}, ke = u(() => Oe("Header")), Ae = u(() => Oe("HeaderTemplate")), je = u(() => Oe("Description")), Me = u(() => {
			let e = te(Ee.default?.() ?? []).find((e) => e.type.__xamlBrushProperty === "Background");
			return e ? ee(e) : [];
		}), Ne = d({ setup: () => () => f(pe, ke.value) }), Pe = d({ setup: () => () => f(pe, je.value) }), Fe = d({ setup: () => () => f(pe, Me.value) }), Ie = u(() => ({
			...Object.fromEntries(Object.entries(_).filter(([e]) => !e.startsWith("ScrollViewer.") && e !== "AutomationProperties.Name" && !e.startsWith("on") && !t.has(e))),
			"aria-label": De.value,
			style: [_.style, dt.value]
		})), Le = se((e) => _[e], g, {
			HorizontalScrollMode: "Auto",
			VerticalScrollMode: "Auto",
			HorizontalScrollBarVisibility: "Auto",
			VerticalScrollBarVisibility: "Auto",
			IsDeferredScrollingEnabled: !1
		}), Re = c, ze = ye({}), v = new Proxy(Re, { get: (e, t) => i(typeof t == "string" && t in ze ? ze[t] : Reflect.get(e, t), g) }), Be = v, Ve = u(() => Ae.value[0] ?? v.HeaderTemplate);
		p(s, {
			...he(s, {}),
			RichInput: Be,
			RichInputHeaderTemplate: Ve,
			RichEditBoxScrollSettings: Le
		});
		let He = u(() => i(v.Header, g)), Ue = u(() => i(v.Description, g)), We = u(() => i(v.Width, g)), Ge = u(() => i(v.Height, g)), Ke = u(() => i(v.MinHeight, g)), qe = Te, y = (e, t) => {
			let n = g?.exposeProxy ?? g?.exposed ?? g?.proxy, i = t ?? {
				OriginalSource: b.value,
				Handled: !1
			}, a = g?.vnode.props?.[`on${e}`];
			if (a) for (let e of Array.isArray(a) ? a : [a]) e(n, i);
			else qe(e, n, i);
			a || r(_[e], g)?.(n, i);
		}, b = m(null), Je = m(null), Ye = m(!1), x = m(null), Xe = m(!1);
		p("buttonFlyoutAnchor", b), p("buttonFlyoutController", Je);
		let Ze = d({
			name: "RichEditBoxContextFlyoutOutlet",
			setup() {
				return () => {
					let e = te(Ee.default?.() ?? []).find((e) => e.type.__richEditBoxProperty === "ContextFlyout"), t = e ? ee(e) : [];
					return Ye.value = t.length > 0 || v.ContextFlyout !== void 0, f(pe, n(t, g));
				};
			}
		}), Qe = d({
			name: "RichEditBoxSelectionFlyoutOutlet",
			setup() {
				return p("buttonFlyoutAnchor", b), p("buttonFlyoutController", x), () => {
					let e = Oe("SelectionFlyout");
					return Xe.value = e.length > 0 || v.SelectionFlyout !== void 0, f(pe, e);
				};
			}
		}), $e = m(!1), S = m(!1), C = m("Selection"), w = m(null), T = m(null), E = m(""), D = m(null), et = m([]), tt = m([]), O = {
			Selection: /* @__PURE__ */ new Set(),
			Context: /* @__PURE__ */ new Set()
		}, nt = (e, t, n) => {
			let r = e.trim();
			!r || et.value.some((e) => e.Command === r) || et.value.push({
				Command: r,
				Label: t,
				Execute: n
			});
		}, rt = {
			get PrimaryCommands() {
				return tt.value;
			},
			get Target() {
				return g?.exposed ?? g?.proxy;
			},
			addEventListener: (e, t) => {
				e.toLowerCase() === "opening" && O.Selection.add(t);
			},
			removeEventListener: (e, t) => {
				e.toLowerCase() === "opening" && O.Selection.delete(t);
			},
			ShowAt: (e, t) => w.value?.ShowAt(e, t),
			Hide: () => w.value?.Hide()
		}, it = {
			get PrimaryCommands() {
				return tt.value;
			},
			get Target() {
				return g?.exposed ?? g?.proxy;
			},
			addEventListener: (e, t) => {
				e.toLowerCase() === "opening" && O.Context.add(t);
			},
			removeEventListener: (e, t) => {
				e.toLowerCase() === "opening" && O.Context.delete(t);
			},
			ShowAt: (e, t) => w.value?.ShowAt(e, t),
			Hide: () => w.value?.Hide()
		}, k = m("NoMath"), at = m(""), A = m([]), j = m([]), M = "", N = !1, P = !1, F = !1, I = null, L = null, R = !1, z = !1, B = ye({}), ot = u(() => v.DisabledFormattingAccelerators.toLowerCase()), V = (e) => ot.value.includes("all") || ot.value.includes(e), st = u(() => {
			let e = [];
			return v.IsReadOnly || (V("bold") || e.push(f(ie, {
				key: "BoldButton",
				Label: h("sample.richeditbox.bold"),
				LabelPosition: "Collapsed",
				Icon: "Bold",
				"ToolTipService.ToolTip": h("sample.richeditbox.bold"),
				Click: () => void J("bold"),
				IsChecked: At("bold")
			})), V("italic") || e.push(f(ie, {
				key: "ItalicButton",
				Label: h("sample.richeditbox.italic"),
				LabelPosition: "Collapsed",
				Icon: "Italic",
				"ToolTipService.ToolTip": h("sample.richeditbox.italic"),
				Click: () => void J("italic"),
				IsChecked: At("italic")
			})), V("underline") || e.push(f(ie, {
				key: "UnderlineButton",
				Label: h("sample.richeditbox.underline"),
				LabelPosition: "Collapsed",
				Icon: "Underline",
				"ToolTipService.ToolTip": h("sample.richeditbox.underline"),
				Click: () => void J("underline"),
				IsChecked: At("underline")
			}))), e.push(...tt.value), e.push(...et.value.map((e) => f(l, {
				key: e.Command,
				Label: e.Label,
				LabelPosition: "Collapsed",
				Icon: e.Command,
				"ToolTipService.ToolTip": e.Label,
				Click: () => e.Execute ? e.Execute() : void J(e.Command.toLowerCase())
			}))), e;
		}), ct = u(() => {
			let e = D.value?.toString() ?? "", t = !v.IsReadOnly && v.IsEnabled, n = [];
			return e && t && n.push(f(l, {
				key: "CutButton",
				Label: h("sample.menubar.cut"),
				Icon: "Cut",
				Click: () => void J("cut")
			})), e && n.push(f(l, {
				key: "CopyButton",
				Label: h("sample.copy"),
				Icon: "Copy",
				Click: () => void J("copy")
			})), t && n.push(f(l, {
				key: "PasteButton",
				Label: h("sample.menubar.paste"),
				Icon: "Paste",
				Click: () => void J("paste")
			})), t && A.value.length && n.push(f(l, {
				key: "UndoButton",
				Label: h("sample.menubar.undo"),
				Icon: "Undo",
				Click: () => void J("undo")
			})), t && j.value.length && n.push(f(l, {
				key: "RedoButton",
				Label: h("sample.menubar.redo"),
				Icon: "Redo",
				Click: () => void J("redo")
			})), E.value && U().length > 0 && n.push(f(l, {
				key: "SelectAllButton",
				Label: h("sample.select-all"),
				Icon: "SelectAll",
				Click: () => void J("selectAll")
			})), n;
		}), lt = d({
			name: "RichEditBoxTextCommandFlyoutOutlet",
			setup() {
				return () => f(re, {
					ref: w,
					Placement: C.value === "Selection" ? "TopEdgeAlignedLeft" : "BottomEdgeAlignedLeft",
					ShowMode: C.value === "Selection" ? "Transient" : "Standard",
					onOpening: () => {
						let e = C.value;
						O[e].forEach((t) => t(e === "Selection" ? rt : it, {}));
					},
					onClosed: () => {
						S.value = !1;
					}
				}, { default: () => [f(re.PrimaryCommands, null, { default: () => st.value }), f(re.SecondaryCommands, null, { default: () => ct.value })] });
			}
		});
		Se([S, T], async () => {
			if (await ge(), !S.value || !b.value || !T.value) {
				w.value?.Hide();
				return;
			}
			let e = b.value.getBoundingClientRect(), t = T.value;
			await w.value?.ShowAt(b.value, {
				ShowMode: C.value === "Selection" ? "Transient" : "Standard",
				Position: {
					X: t.left - e.left,
					Y: (C.value === "Selection" ? t.top : t.bottom) - e.top
				}
			});
		});
		let H = (t) => t === "" ? void 0 : e(t), ut = (e, t) => {
			let n = H(e ?? "");
			return n ? `max(0px, calc(${n} - 2px))` : t;
		}, dt = u(() => ({
			width: H(We.value ?? ""),
			height: H(Ge.value ?? ""),
			minHeight: H(Ke.value ?? ""),
			"--rich-edit-box-min-height": H(Ke.value || 32),
			"--reb-editor-min-height": ut(Ke.value, "30px"),
			"--reb-font-size": H(v.FontSize),
			"--reb-font-family": v.FontFamily || void 0,
			"--reb-font-weight": v.FontWeight === "" ? void 0 : String({
				Normal: 400,
				SemiBold: 600,
				Bold: 700,
				Light: 300
			}[String(v.FontWeight)] ?? v.FontWeight),
			"--reb-font-style": v.FontStyle.toLowerCase(),
			"--reb-selection-background-blur": v.SelectionHighlightColorWhenNotFocused || void 0
		})), ft = u(() => ({
			height: ut(Ge.value),
			minHeight: ut(Ke.value, "30px")
		})), pt = u(() => ({
			textAlign: (v.TextAlignment || v.HorizontalTextAlignment || "Left").toLowerCase(),
			whiteSpace: v.TextWrapping === "NoWrap" ? "pre" : "pre-wrap",
			overflowWrap: v.TextWrapping === "WrapWholeWords" ? "normal" : "break-word",
			direction: v.TextReadingOrder === "UseFlowDirection" ? "inherit" : void 0,
			fontFamily: k.value === "MathOnly" ? "Cambria Math, serif" : v.FontFamily || void 0,
			fontSize: H(v.FontSize),
			fontStyle: v.FontStyle.toLowerCase(),
			fontWeight: v.FontWeight === "" ? void 0 : {
				Normal: 400,
				SemiBold: 600,
				Bold: 700,
				Light: 300
			}[String(v.FontWeight)] ?? v.FontWeight,
			color: i(_.Foreground, g) || void 0
		}));
		p(oe, {
			HideDeleteButton: !0,
			Field: (e) => f(ae, {
				class: "win-reb-editor-scroll",
				style: ft.value,
				VerticalScrollMode: "{x:Bind RichEditBoxScrollSettings.VerticalScrollMode, Mode=OneWay}",
				VerticalScrollBarVisibility: "{x:Bind RichEditBoxScrollSettings.VerticalScrollBarVisibility, Mode=OneWay}",
				HorizontalScrollMode: "{x:Bind RichEditBoxScrollSettings.HorizontalScrollMode, Mode=OneWay}",
				HorizontalScrollBarVisibility: "{x:Bind RichEditBoxScrollSettings.HorizontalScrollBarVisibility, Mode=OneWay}",
				IsHorizontalRailEnabled: "{x:Bind RichEditBoxScrollSettings.IsHorizontalRailEnabled, Mode=OneWay}",
				IsVerticalRailEnabled: "{x:Bind RichEditBoxScrollSettings.IsVerticalRailEnabled, Mode=OneWay}",
				IsDeferredScrollingEnabled: "{x:Bind RichEditBoxScrollSettings.IsDeferredScrollingEnabled, Mode=OneWay}",
				IsTabStop: "False",
				ZoomMode: "Disabled"
			}, { default: () => f("div", {
				ref: b,
				class: "win-reb-editor",
				style: pt.value,
				contenteditable: v.IsEnabled && !v.IsReadOnly,
				tabindex: v.IsEnabled ? 0 : -1,
				"data-placeholder": v.PlaceholderText,
				spellcheck: v.IsSpellCheckEnabled,
				autocomplete: v.IsTextPredictionEnabled ? "on" : "off",
				role: "textbox",
				"aria-label": De.value,
				"aria-multiline": v.AcceptsReturn,
				"aria-readonly": v.IsReadOnly,
				"aria-disabled": !v.IsEnabled,
				onBeforeinput: jt,
				onInput: K,
				onFocus: () => Gt(e.Focused),
				onBlur: () => Kt(e.Blurred),
				onKeydown: zt,
				onPaste: Vt,
				onCopy: Ht,
				onCut: Ut,
				onContextmenu: Wt,
				onPointerup: Nt,
				onKeyup: Nt,
				onPointerenter: e.PointerEntered,
				onPointerleave: e.PointerExited
			}) })
		});
		function mt(e) {
			let t = document.createElement("div");
			return t.innerText = e ?? "", t.innerHTML;
		}
		let U = () => b.value?.innerText.replace(/\n$/, "") ?? "", ht = () => {
			!b.value || $e.value || N || F || (b.value.innerHTML = E.value);
		}, gt = (e) => {
			let t = e;
			return v.CharacterCasing === "Upper" && (t = t.toUpperCase()), v.CharacterCasing === "Lower" && (t = t.toLowerCase()), v.MaxLength > 0 && t.length > v.MaxLength && (t = t.slice(0, v.MaxLength)), t;
		}, W = () => {
			let e = window.getSelection();
			if (!N && !F && e && e.rangeCount > 0 && b.value?.contains(e.anchorNode) && b.value.contains(e.focusNode)) {
				D.value = e.getRangeAt(0).cloneRange();
				for (let e of [
					"bold",
					"italic",
					"underline",
					"strikeThrough",
					"insertOrderedList",
					"insertUnorderedList"
				]) B[e] = document.queryCommandState(e);
				for (let e of ["foreColor", "backColor"]) B[e] = document.queryCommandValue(e);
			}
		}, _t = () => {
			if (N || F) return;
			let e = D.value, t = window.getSelection();
			!e || !t || !b.value?.contains(e.startContainer) || !b.value?.contains(e.endContainer) || (t.removeAllRanges(), t.addRange(e));
		}, vt = () => {
			let e = window.getSelection();
			return !e || e.rangeCount === 0 || !b.value?.contains(e.anchorNode) ? "" : e.toString();
		}, yt = () => {
			let e = window.getSelection();
			return e?.rangeCount && b.value?.contains(e.anchorNode) && b.value.contains(e.focusNode) ? e.getRangeAt(0) : D.value;
		}, G = (e, t, n) => {
			if (v.IsReadOnly || !v.IsEnabled || N || F) return;
			Y(), _t();
			let r = q();
			if (n && n !== "Toggle" && document.queryCommandState(e) === (n === "On")) return;
			document.execCommand(e, !1, t), W(), K();
			let i = Z(r.StartPosition, r.EndPosition);
			if (i) {
				let e = window.getSelection();
				e?.removeAllRanges(), e?.addRange(i), D.value = i;
			}
		}, bt = {
			get Bold() {
				return X("bold") ? "On" : "Off";
			},
			set Bold(e) {
				G("bold", void 0, e);
			},
			get Italic() {
				return X("italic") ? "On" : "Off";
			},
			set Italic(e) {
				G("italic", void 0, e);
			},
			get Underline() {
				return X("underline") ? "On" : "Off";
			},
			set Underline(e) {
				G("underline", void 0, e);
			},
			get Strikethrough() {
				return X("strikeThrough") ? "On" : "Off";
			},
			set Strikethrough(e) {
				G("strikeThrough", void 0, e);
			},
			get ForegroundColor() {
				return Jt("foreColor");
			},
			set ForegroundColor(e) {
				Xt(String(e), !1);
			},
			get BackgroundColor() {
				return Jt("backColor");
			},
			set BackgroundColor(e) {
				e && G("backColor", e);
			}
		}, xt = () => {
			if (k.value !== "MathOnly") throw TypeError("MathOnly mode is required");
			if ((b.value?.querySelectorAll("math").length ?? 0) !== 1 || b.value?.querySelector("br")) return "";
			let e = b.value?.querySelector("math");
			if (!e) return "";
			let t = e.cloneNode(!0);
			return t.removeAttribute("data-linear-math"), new XMLSerializer().serializeToString(t);
		}, St = (e) => {
			if (k.value !== "MathOnly") throw TypeError("MathOnly mode is required");
			if (!Q(() => St(e))) try {
				let t = de(e);
				b.value ? b.value.replaceChildren(t) : at.value = new XMLSerializer().serializeToString(t), D.value = null, K();
			} catch (e) {
				throw Qt(""), e;
			}
		}, Ct = () => {
			let e = b.value;
			if (!e || k.value !== "MathOnly") return;
			let t = yt();
			if (!t || !t.collapsed || !e.contains(t.startContainer)) return;
			if (t.startContainer.nodeType !== Node.TEXT_NODE) return !1;
			let n = t.startContainer, r = n.data.slice(0, t.startOffset).trim();
			if (!(!r || !/[=+\-*/^\\]|\d/.test(r))) {
				try {
					let e = le(r);
					if (e.querySelector("merror")) return !1;
					let i = document.createTextNode(` ${n.data.slice(t.startOffset)}`);
					n.replaceWith(e, i), t.setStart(i, 1), t.collapse(!0);
					let a = window.getSelection();
					return a?.removeAllRanges(), a?.addRange(t), W(), K(), !0;
				} catch {}
				return !1;
			}
		}, wt = (e) => {
			let t = e === "Normal" ? "NoMath" : e;
			t !== k.value && (k.value = t, Qt(""), A.value = [], j.value = []);
		}, Tt = () => {
			if (Q(Tt)) return;
			let e = b.value, t = A.value.pop();
			!e || t === void 0 || (j.value.push(e.innerHTML), P = !0, e.innerHTML = t, P = !1, M = t, E.value = t, y("TextChanging", { IsContentChanging: !0 }), y("TextChanged"));
		}, Et = () => {
			if (Q(Et)) return;
			let e = b.value, t = j.value.pop();
			!e || t === void 0 || (A.value.push(e.innerHTML), P = !0, e.innerHTML = t, P = !1, M = t, E.value = t, y("TextChanging", { IsContentChanging: !0 }), y("TextChanged"));
		}, Dt = async (e) => {
			let t = await ue(e);
			if (!b.value) return;
			let n = () => {
				b.value && (P = !0, b.value.replaceChildren(...t.map((e) => e.cloneNode(!0))), P = !1, K());
			};
			Q(n) || n();
		}, Ot = (e) => {
			if (e?.toLowerCase().includes("rtf")) return b.value ? fe(b.value) : "{\\rtf1\\ansi }";
			if (k.value === "MathOnly") throw TypeError("FormatRtf is required for a math document");
			return e?.includes("UseCrlf") ? U().replace(/\n/g, "\r\n") : U();
		}, kt = (e) => {
			if (!b.value) return;
			let t = e.trim();
			if (b.value.querySelectorAll("[data-rich-highlight=\"true\"]").forEach((e) => {
				let t = e.parentNode;
				for (; e.firstChild;) t?.insertBefore(e.firstChild, e);
				t?.removeChild(e);
			}), !t) {
				K();
				return;
			}
			let n = document.createTreeWalker(b.value, NodeFilter.SHOW_TEXT), r = [];
			for (; n.nextNode();) n.currentNode.textContent?.toLocaleLowerCase().includes(t.toLocaleLowerCase()) && r.push(n.currentNode);
			r.forEach((e) => {
				let n = e.nodeValue || "", r = n.toLocaleLowerCase(), i = 0, a = document.createDocumentFragment();
				for (; i < n.length;) {
					let e = r.indexOf(t.toLocaleLowerCase(), i);
					if (e < 0) {
						a.append(n.slice(i));
						break;
					}
					a.append(n.slice(i, e));
					let o = document.createElement("mark");
					o.dataset.richHighlight = "true", o.textContent = n.slice(e, e + t.length), a.append(o), i = e + t.length;
				}
				e.parentNode?.replaceChild(a, e);
			}), K();
		};
		function At(e) {
			return X(e);
		}
		let K = (e) => {
			let t = b.value;
			if (!t || P || N || F || e?.isComposing) return;
			let n = gt(U());
			if (n !== U()) {
				let e = q();
				t.innerText = n;
				let r = Z(Math.min(e.StartPosition, n.length), Math.min(e.EndPosition, n.length));
				if (r) {
					let e = window.getSelection();
					e?.removeAllRanges(), e?.addRange(r);
				}
			}
			W(), E.value = t.innerHTML, M !== E.value && (A.value.push(M), j.value = [], M = E.value, y("TextChanging", { IsContentChanging: !0 }), y("TextChanged"));
		}, jt = (e) => {
			if (v.IsReadOnly || !v.IsEnabled) {
				e.preventDefault();
				return;
			}
			!v.AcceptsReturn && ["insertParagraph", "insertLineBreak"].includes(e.inputType) && e.preventDefault(), !N && v.MaxLength > 0 && e.data && U().length - vt().length + e.data.length > v.MaxLength && e.preventDefault();
		}, q = (e = yt()) => {
			if (!e || !b.value?.contains(e.startContainer)) return {
				StartPosition: 0,
				EndPosition: 0
			};
			let t = e.cloneRange();
			return t.selectNodeContents(b.value), t.setEnd(e.startContainer, e.startOffset), {
				StartPosition: t.toString().length,
				EndPosition: t.toString().length + e.toString().length
			};
		}, Mt = () => {
			let e = q(), t = {
				SelectionStart: e.StartPosition,
				SelectionLength: e.EndPosition - e.StartPosition,
				Cancel: !1
			};
			return y("SelectionChanging", t), t.Cancel ? (_t(), !1) : (W(), y("SelectionChanged"), !0);
		}, Nt = async () => {
			N || F || Mt() && (await ge(), Rt());
		}, Pt = (e) => e instanceof Element ? !!e.closest(".scrollbar, .scrollbar-button, .scrollbar-thumb, .scrollbar-track") : !1, Ft = (e) => e instanceof Node && !!b.value?.contains(e), It = (e) => !(e instanceof Element) || Pt(e) || Ft(e) || e.closest(".win-textbox-header, .win-textbox-description") || e.closest("button, a, input, textarea, select, [role=\"button\"]") ? !1 : !!e.closest(".win-textbox-border, .win-textbox-content, .win-reb-editor-scroll, .win-scroll-viewer-viewport, .scroll-content"), Lt = (e) => {
			e.button !== 0 || !It(e.target) || Y();
		}, Rt = () => {
			if (!v.IsEnabled || v.SelectionFlyout === null) return;
			let e = window.getSelection();
			if (!e || e.rangeCount === 0 || !vt()) {
				S.value = !1;
				return;
			}
			let t = e.getRangeAt(0).getBoundingClientRect();
			if (Xe.value && b.value) {
				let e = x.value || v.SelectionFlyout, n = b.value.getBoundingClientRect();
				e?.ShowAt?.(b.value, {
					ShowMode: "Transient",
					Position: {
						X: t.left - n.left,
						Y: t.top - n.top
					}
				});
				return;
			}
			C.value = "Selection", T.value = t, S.value = st.value.length > 0 || ct.value.length > 0;
		}, zt = (e) => {
			if (N || F || e.isComposing || e.keyCode === 229) return;
			if (e.key === "Escape") {
				S.value = !1;
				return;
			}
			if (k.value === "MathOnly" && !N && (e.key === " " || e.key === "Enter") && Ct() && e.preventDefault(), e.key === "Enter" && !v.AcceptsReturn && e.preventDefault(), !(e.ctrlKey || e.metaKey)) return;
			let t = e.key.toLowerCase();
			if (t === "z") {
				e.preventDefault(), e.shiftKey ? Et() : Tt();
				return;
			}
			if (t === "y") {
				e.preventDefault(), Et();
				return;
			}
			t === "b" && (e.preventDefault(), V("bold") || J("bold")), t === "i" && (e.preventDefault(), V("italic") || J("italic")), t === "u" && (e.preventDefault(), V("underline") || J("underline"));
		}, Bt = (e) => {
			It(e.target) && (e.stopPropagation(), Y(), Wt(e));
		}, Vt = (e) => {
			let t = { Handled: !1 };
			y("Paste", t), t.Handled && e.preventDefault();
		}, Ht = (e) => {
			let t = { Handled: !1 };
			if (y("CopyingToClipboard", t), t.Handled) {
				e.preventDefault();
				return;
			}
			let n = vt();
			v.ClipboardCopyFormat === "PlainText" && n && (e.clipboardData?.setData("text/plain", n), e.preventDefault());
		}, Ut = (e) => {
			let t = { Handled: !1 };
			y("CuttingToClipboard", t), t.Handled && e.preventDefault();
		}, Wt = (e) => {
			let t = {
				Handled: !1,
				CursorLeft: e.clientX,
				CursorTop: e.clientY
			};
			if (y("ContextMenuOpening", t), t.Handled) {
				e.preventDefault();
				return;
			}
			if (v.ContextFlyout !== null) {
				if (e.preventDefault(), W(), Ye.value && b.value) {
					let t = Je.value || i(v.ContextFlyout, g), n = b.value.getBoundingClientRect();
					t?.ShowAt?.(b.value, {
						ShowMode: "Standard",
						Position: {
							X: e.clientX - n.left,
							Y: e.clientY - n.top
						}
					});
					return;
				}
				T.value = {
					x: e.clientX,
					y: e.clientY,
					top: e.clientY,
					bottom: e.clientY,
					left: e.clientX,
					right: e.clientX,
					width: 0,
					height: 0
				}, C.value = "Context", S.value = st.value.length > 0 || ct.value.length > 0;
			}
		}, J = async (e) => {
			if (!(!v.IsEnabled || N || F)) {
				if (Y(), _t(), e === "copy") document.execCommand("copy");
				else if (e === "cut" && !v.IsReadOnly) document.execCommand("cut");
				else if (e === "paste" && !v.IsReadOnly) {
					let e = { Handled: !1 };
					if (y("Paste", e), e.Handled) {
						S.value = !1;
						return;
					}
					let t = await navigator.clipboard?.readText().catch(() => "");
					t && document.execCommand("insertText", !1, t);
				} else if (e === "selectAll") {
					let e = document.createRange();
					if (b.value) {
						e.selectNodeContents(b.value);
						let t = window.getSelection();
						t?.removeAllRanges(), t?.addRange(e), W();
					}
				} else e === "undo" ? Tt() : e === "redo" ? Et() : v.IsReadOnly || G(e);
				S.value = !1, K(), Rt();
			}
		}, Gt = (e) => {
			e?.(), $e.value = !0, y("GotFocus");
		}, Kt = (e) => {
			e?.(), $e.value = !1, y("LostFocus");
		}, Y = () => {
			v.IsEnabled && b.value?.focus({ preventScroll: v.PreventKeyboardDisplayOnProgrammaticFocus });
		}, qt = () => {
			let e = window.getSelection();
			return e?.rangeCount && b.value?.contains(e.anchorNode) ? !e.getRangeAt(0).collapsed : !!(D.value && !D.value.collapsed);
		}, X = (e) => {
			try {
				let t = window.getSelection();
				return !N && !F && t?.rangeCount && b.value?.contains(t.anchorNode) && b.value.contains(t.focusNode) ? document.queryCommandState(e) : !!B[e];
			} catch {
				return !1;
			}
		}, Jt = (e) => {
			let t = window.getSelection();
			return !N && !F && t?.rangeCount && b.value?.contains(t.anchorNode) && b.value.contains(t.focusNode) ? document.queryCommandValue(e) : String(B[e] ?? "");
		}, Yt = (e, t) => {
			!v.IsEnabled || v.IsReadOnly || N || F || (Y(), _t(), document.execCommand(e, !1, t), W(), K());
		}, Xt = (e, t = !0) => {
			if (!b.value || v.IsReadOnly || !v.IsEnabled || N || F) return;
			Y(), _t();
			let n = window.getSelection();
			if (!(n?.rangeCount && b.value.contains(n.anchorNode) && n && !n.getRangeAt(0).collapsed) && t) {
				let e = document.createRange();
				e.selectNodeContents(b.value), n?.removeAllRanges(), n?.addRange(e);
			}
			let r = q();
			document.execCommand("foreColor", !1, e), W(), K();
			let i = Z(r.StartPosition, r.EndPosition);
			i && (n?.removeAllRanges(), n?.addRange(i), D.value = i);
		}, Zt = (e) => {
			let t = b.value;
			if (!t || v.IsReadOnly || !v.IsEnabled) return;
			let n = window.getSelection(), r = n?.rangeCount ? n.getRangeAt(0) : null, i = (e) => !!(e && t.contains(e.startContainer) && t.contains(e.endContainer)), a = i(r) ? r : i(D.value) ? D.value : null;
			if (!a) return;
			let o = /* @__PURE__ */ new Set(), s = (e) => {
				let n = (e instanceof Element ? e : e.parentElement)?.closest("ol, ul");
				n instanceof HTMLElement && t.contains(n) && o.add(n);
			};
			if (a.collapsed) s(a.startContainer);
			else {
				let e = document.createTreeWalker(t, NodeFilter.SHOW_TEXT);
				for (; e.nextNode();) a.intersectsNode(e.currentNode) && s(e.currentNode);
				t.querySelectorAll("li:empty").forEach((e) => {
					a.intersectsNode(e) && s(e);
				});
			}
			o.size && (o.forEach((t) => {
				t.style.listStyleType = e, t instanceof HTMLOListElement && (e === "upper-roman" ? t.type = "I" : e === "decimal" && (t.type = "1"));
			}), K());
		}, Qt = (e) => {
			Q(() => Qt(e)) || (E.value = mt(e), b.value && (b.value.innerText = e), K());
		}, $t = (e) => {
			Q(() => $t(e)) || (E.value = e, b.value && (b.value.innerHTML = e), K());
		}, Z = (e, t) => {
			let n = b.value;
			if (!n) return null;
			let r = document.createRange();
			r.selectNodeContents(n);
			let i = document.createTreeWalker(n, NodeFilter.SHOW_TEXT), a = [];
			for (; i.nextNode();) a.push(i.currentNode);
			let o = (e) => {
				let t = Math.max(0, e);
				for (let e of a) {
					if (t <= e.length) return [e, t];
					t -= e.length;
				}
				return [n, n.childNodes.length];
			}, [s, c] = o(e), [l, ee] = o(Math.max(e, t));
			return r.setStart(s, c), r.setEnd(l, ee), r;
		}, en = (e, t) => {
			let n = Math.max(0, e), r = Math.max(e, t), i = n, a = (e, t) => {
				if (N || F) return;
				let i = Z(n, r);
				if (!i) return;
				let a = q(), o = window.getSelection();
				o?.removeAllRanges(), o?.addRange(i), P = !0, document.execCommand(e, !1, t), P = !1;
				let s = Z(a.StartPosition, a.EndPosition);
				s && (o?.removeAllRanges(), o?.addRange(s), D.value = s), K();
			};
			return {
				get StartPosition() {
					return n;
				},
				get EndPosition() {
					return r;
				},
				SetRange: (e, t) => {
					n = Math.max(0, e), r = Math.max(n, t), i = n;
				},
				GetText: () => Z(n, r)?.toString() ?? "",
				FindText: (e, t, a) => {
					if (!e) return 0;
					let o = b.value?.textContent ?? "", s = a?.includes("Case"), c = (s ? o : o.toLocaleLowerCase()).indexOf(s ? e : e.toLocaleLowerCase(), i);
					return c < 0 || c >= i + t ? 0 : (n = c, r = c + e.length, i = r, e.length);
				},
				CharacterFormat: {
					set ForegroundColor(e) {
						a("foreColor", e);
					},
					set BackgroundColor(e) {
						a("backColor", e);
					}
				}
			};
		}, tn = {
			get ListType() {
				return X("insertOrderedList") ? "UpperRoman" : X("insertUnorderedList") ? "Bullet" : "None";
			},
			set ListType(e) {
				let t = X("insertOrderedList"), n = X("insertUnorderedList");
				if (e === "None") {
					t && Yt("insertOrderedList"), n && Yt("insertUnorderedList");
					return;
				}
				let r = e === "Bullet" ? "insertUnorderedList" : "insertOrderedList";
				X(r) || Yt(r), Zt(e === "Bullet" ? "disc" : e === "UpperRoman" ? "upper-roman" : "decimal");
			}
		}, nn = {
			GetText: Ot,
			SetText: (e, t) => e?.includes("Rtf") ? Dt(t) : Qt(t),
			LoadFromStream: async (e, t) => {
				let n = t instanceof Blob ? await t.arrayBuffer() : t;
				e?.includes("Rtf") ? await Dt(n) : Qt(typeof n == "string" ? n : new TextDecoder().decode(n));
			},
			SaveToStream: (e) => new Blob([Ot(e)], { type: e?.includes("Rtf") ? "application/rtf" : "text/plain;charset=utf-8" }),
			GetRange: en,
			Selection: {
				get StartPosition() {
					return q().StartPosition;
				},
				get EndPosition() {
					return q().EndPosition;
				},
				CharacterFormat: bt,
				ParagraphFormat: tn,
				SetRange: (e, t) => {
					let n = Z(e, t);
					if (!n) return;
					let r = window.getSelection();
					r?.removeAllRanges(), r?.addRange(n), W(), Mt();
				}
			},
			GetMathMode: () => k.value,
			SetMathMode: wt,
			GetMathML: xt,
			SetMathML: St,
			get CanUndo() {
				return A.value.length > 0;
			},
			get CanRedo() {
				return j.value.length > 0;
			},
			Undo: Tt,
			Redo: Et
		};
		function Q(e) {
			return !N && !F ? !1 : (L = e, !0);
		}
		let rn = () => {
			I = null, F = !1, K();
			let e = L;
			L = null, e?.(), z && (z = !1, ln());
		}, an = () => {
			I !== null && (clearTimeout(I), rn()), W(), N = !0, S.value = !1, x.value?.Hide?.(), y("TextCompositionStarted");
		}, on = () => y("TextCompositionChanged"), sn = () => {
			N = !1, F = !0, y("TextCompositionEnded"), I = setTimeout(rn, 0);
		}, cn = (e) => {
			if (!(e instanceof Element)) return !1;
			if (S.value && e.closest(".win-commandbar-flyout")) return !0;
			let t = $?.closest(".win-relative-panel, [role=\"toolbar\"]"), n = e.closest("button, [role=\"button\"]");
			return t?.contains(e) && n && !n.closest(".win-textbox") ? !0 : R && !!e.closest(".flyout-presenter, .win-commandbar-flyout");
		}, ln = () => {
			let e = window.getSelection(), t = yt(), n = !!(t && !t.collapsed);
			t && b.value?.contains(t.startContainer) && b.value.contains(t.endContainer) && (D.value = t.cloneRange(), D.value.collapse(!1)), e?.rangeCount && b.value?.contains(e.anchorNode) && b.value.contains(e.focusNode) && e.removeAllRanges(), S.value = !1, x.value?.Hide?.();
			for (let e of Object.keys(B)) B[e] = typeof B[e] == "boolean" ? !1 : "";
			n && y("SelectionChanged");
		}, un = (e) => {
			if (Ft(e.target) || $?.contains(e.target)) {
				R = !1, z = !1;
				return;
			}
			if (cn(e.target)) {
				R = !0, z = !1;
				return;
			}
			R = !1, N || F ? z = !0 : ln();
		}, dn = (e) => {
			Ft(e.target) || cn(e.target) || (R = !1, N || F ? z = !0 : ln());
		}, fn = () => {
			R = !1, N || F ? z = !0 : ln();
		}, $ = null;
		ve(() => {
			ht(), M = b.value?.innerHTML ?? "", at.value && b.value && (b.value.innerHTML = at.value, at.value = "", K()), b.value?.addEventListener("compositionstart", an), b.value?.addEventListener("compositionupdate", on), b.value?.addEventListener("compositionend", sn), $ = b.value?.closest(".win-rich-edit-box"), $?.addEventListener("pointerdown", Lt, !0), $?.addEventListener("contextmenu", Bt, !0), document.addEventListener("pointerdown", un, !0), document.addEventListener("focusin", dn, !0), window.addEventListener("blur", fn), y("Loaded");
		}), _e(() => {
			y("Unloaded"), b.value?.removeEventListener("compositionstart", an), b.value?.removeEventListener("compositionupdate", on), b.value?.removeEventListener("compositionend", sn), $?.removeEventListener("pointerdown", Lt, !0), $?.removeEventListener("contextmenu", Bt, !0), document.removeEventListener("pointerdown", un, !0), document.removeEventListener("focusin", dn, !0), window.removeEventListener("blur", fn), I !== null && clearTimeout(I), L = null, O.Selection.clear(), O.Context.clear(), w.value?.Hide();
		});
		let pn = {
			[o]: !0,
			Focus: Y,
			Document: nn,
			TextDocument: nn,
			get SelectionFlyout() {
				return v.SelectionFlyout === void 0 ? Xe.value ? x.value : rt : v.SelectionFlyout;
			},
			get ContextFlyout() {
				return v.ContextFlyout === void 0 ? Ye.value ? Je.value : it : v.ContextFlyout;
			},
			get Foreground() {
				return b.value ? getComputedStyle(b.value).color : "";
			},
			get Background() {
				let e = b.value?.closest(".win-textbox-border");
				return e ? getComputedStyle(e).backgroundColor : "";
			}
		};
		for (let e of Object.keys(Re)) e in pn || (Object.defineProperty(pn, e, {
			enumerable: !0,
			get: () => v[e],
			set: (t) => {
				ze[e] = t, a(Re[e], t, g);
			}
		}), Se(() => Re[e], () => {
			delete ze[e];
		}));
		we(pn);
		let mn = {
			richEditProperty: Ce,
			t: h,
			instance: g,
			attrs: _,
			slots: Ee,
			editorAutomationName: De,
			propertyChildren: Oe,
			headerPropertyNodes: ke,
			headerTemplatePropertyNodes: Ae,
			descriptionPropertyNodes: je,
			backgroundPropertyNodes: Me,
			HeaderPropertyOutlet: Ne,
			DescriptionPropertyOutlet: Pe,
			BackgroundPropertyOutlet: Fe,
			forwardedAttrs: Ie,
			RichEditBoxScrollSettings: Le,
			rawProps: Re,
			propertyOverrides: ze,
			props: v,
			RichInput: Be,
			RichInputHeaderTemplate: Ve,
			resolvedHeader: He,
			resolvedDescription: Ue,
			resolvedWidth: We,
			resolvedHeight: Ge,
			resolvedMinHeight: Ke,
			emit: qe,
			dispatch: y,
			editorRef: b,
			customContextController: Je,
			hasCustomContextFlyout: Ye,
			customSelectionController: x,
			hasCustomSelectionFlyout: Xe,
			ContextFlyoutOutlet: Ze,
			SelectionFlyoutOutlet: Qe,
			isFocused: $e,
			commandBarOpen: S,
			currentFlyoutKind: C,
			commandBarFlyout: w,
			commandBarAnchor: T,
			internalHtml: E,
			savedSelection: D,
			customFormattingCommands: et,
			customPrimaryCommands: tt,
			flyoutOpeningHandlers: O,
			addFormattingCommand: nt,
			selectionFlyoutApi: rt,
			contextFlyoutApi: it,
			mathMode: k,
			pendingMathMarkup: at,
			undoStack: A,
			redoStack: j,
			get lastCommittedHtml() {
				return M;
			},
			set lastCommittedHtml(e) {
				M = e;
			},
			get composing() {
				return N;
			},
			set composing(e) {
				N = e;
			},
			get formatting() {
				return P;
			},
			set formatting(e) {
				P = e;
			},
			get compositionCommitPending() {
				return F;
			},
			set compositionCommitPending(e) {
				F = e;
			},
			get compositionCommitTimer() {
				return I;
			},
			set compositionCommitTimer(e) {
				I = e;
			},
			get pendingDocumentMutation() {
				return L;
			},
			set pendingDocumentMutation(e) {
				L = e;
			},
			get preservingCommandSelection() {
				return R;
			},
			set preservingCommandSelection(e) {
				R = e;
			},
			get selectionReleasePending() {
				return z;
			},
			set selectionReleasePending(e) {
				z = e;
			},
			selectionFormatState: B,
			disabledFormatting: ot,
			isFormattingDisabled: V,
			commandBarPrimaryCommands: st,
			commandBarSecondaryCommands: ct,
			TextCommandFlyoutOutlet: lt,
			cssSize: H,
			editorContentSize: ut,
			rootStyle: dt,
			editorScrollStyle: ft,
			editorStyle: pt,
			escapeText: mt,
			plainText: U,
			syncDom: ht,
			normalizeText: gt,
			saveSelection: W,
			restoreSelection: _t,
			getSelectionText: vt,
			getSelectionRange: yt,
			formatEffect: G,
			selectionCharacterFormat: bt,
			serializeMathML: xt,
			setMathML: St,
			convertLinearMath: Ct,
			setMathMode: wt,
			undo: Tt,
			redo: Et,
			loadRtfDocument: Dt,
			getText: Ot,
			highlightText: kt,
			isCommandActive: At,
			onInput: K,
			onBeforeInput: jt,
			selectionOffsets: q,
			emitSelection: Mt,
			onSelectionGesture: Nt,
			isEditorSurfaceChrome: Pt,
			isInsideEditor: Ft,
			isEditorTextBoxSurface: It,
			onRootPointerDown: Lt,
			updateSelectionFlyout: Rt,
			onKeydown: zt,
			onRootContextMenu: Bt,
			onPaste: Vt,
			onCopy: Ht,
			onCut: Ut,
			onContextMenu: Wt,
			runTextCommand: J,
			onEditorFocus: Gt,
			onEditorBlur: Kt,
			focus: Y,
			hasSelection: qt,
			queryCommandState: X,
			queryCommandValue: Jt,
			execCommand: Yt,
			applyForegroundColor: Xt,
			setListStyleType: Zt,
			setText: Qt,
			setHtml: $t,
			domRange: Z,
			textRange: en,
			selectionParagraphFormat: tn,
			Document: nn,
			deferDocumentMutation: Q,
			finishComposition: rn,
			onCompositionStart: an,
			onCompositionUpdate: on,
			onCompositionEnd: sn,
			isSelectionCommandTarget: cn,
			releaseSelection: ln,
			onDocumentPointerDown: un,
			onDocumentFocusIn: dn,
			onWindowBlur: fn,
			get rootSurface() {
				return $;
			},
			set rootSurface(e) {
				$ = e;
			},
			api: pn,
			TextBox: ce
		};
		return Object.defineProperty(mn, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), mn;
	}
});
//#endregion
export { we as default };

//# sourceMappingURL=RichEditBox.vue_vue_type_script_setup_true_lang.js.map