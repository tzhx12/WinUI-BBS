import { resolveXamlValue as e } from "./xamlRuntime.js";
import t from "../_virtual/_plugin-vue_export-helper.js";
import n from "./TextBlock.vue.js";
/* empty css                                                 */
import { Fragment as r, computed as i, createBlock as a, createCommentVNode as o, createElementBlock as s, createElementVNode as c, createTextVNode as l, getCurrentInstance as u, mergeProps as d, openBlock as f, renderSlot as p, resolveDynamicComponent as m, toDisplayString as h, useSlots as g, withCtx as _ } from "vue";
//#region src/components/SettingsCard.vue
var v = {
	__name: "SettingsCard",
	props: {
		Header: {
			type: [String, Number],
			default: ""
		},
		Description: {
			type: [String, Number],
			default: ""
		},
		HeaderIcon: {
			type: String,
			default: ""
		},
		ActionIcon: {
			type: String,
			default: ""
		},
		ActionIconToolTip: {
			type: String,
			default: ""
		},
		IsClickEnabled: {
			type: Boolean,
			default: !1
		},
		ContentAlignment: {
			type: String,
			default: "Right"
		},
		IsActionIconVisible: {
			type: Boolean,
			default: !0
		},
		Height: {
			type: [String, Number],
			default: ""
		},
		Width: {
			type: [String, Number],
			default: ""
		}
	},
	emits: ["Click"],
	setup(t, { expose: r, emit: a }) {
		r();
		let o = t, s = a, c = g(), l = u(), d = i(() => e(o.Header, l)), f = i(() => e(o.Description, l)), p = i(() => e(o.HeaderIcon, l)), m = i(() => e(o.ActionIcon, l)), h = i(() => !!p.value || !!c.HeaderIcon), _ = i(() => !!d.value || !!f.value || h.value || !!c.Header || !!c.Description), v = i(() => String(p.value || "").trim().startsWith("<")), y = i(() => String(m.value || "").trim().startsWith("<")), b = (e) => e === "" || e == null ? "" : typeof e == "string" && e.trim() !== "" && !Number.isNaN(Number(e.trim())) ? `${Number(e.trim())}px` : typeof e == "number" ? `${e}px` : e, x = {
			props: o,
			emit: s,
			slots: c,
			instance: l,
			resolvedHeader: d,
			resolvedDescription: f,
			resolvedHeaderIcon: p,
			resolvedActionIcon: m,
			hasHeaderIcon: h,
			hasHeaderContent: _,
			isHeaderIconMarkup: v,
			isActionIconMarkup: y,
			cssLength: b,
			rootStyle: i(() => {
				let e = {};
				return o.Height !== "" && (e.minHeight = b(o.Height)), o.Width !== "" && (e.width = b(o.Width)), e;
			}),
			handleClick: (e) => {
				o.IsClickEnabled && s("Click", e);
			},
			computed: i,
			getCurrentInstance: u,
			useSlots: g,
			TextBlock: n,
			get resolveXamlValue() {
				return e;
			}
		};
		return Object.defineProperty(x, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), x;
	}
}, y = { class: "win-settings-card-surface" }, b = {
	key: 0,
	class: "win-settings-card-header"
}, x = {
	key: 0,
	class: "win-settings-card-icon icon",
	"aria-hidden": "true"
}, S = ["innerHTML"], C = { class: "win-settings-card-text" }, w = { class: "win-settings-card-content" }, T = {
	key: 1,
	class: "win-settings-card-action-icon icon",
	"aria-hidden": "true"
}, E = ["innerHTML"];
function D(e, t, n, i, u, g) {
	return f(), a(m(n.IsClickEnabled ? "button" : "div"), d({
		class: ["win-settings-card", {
			clickable: n.IsClickEnabled,
			"content-left": n.ContentAlignment === "Left",
			"content-vertical": n.ContentAlignment === "Vertical",
			"has-header-content": i.hasHeaderContent
		}],
		style: i.rootStyle,
		onClick: i.handleClick,
		type: n.IsClickEnabled ? "button" : void 0,
		role: n.IsClickEnabled ? void 0 : "group"
	}, n.ActionIconToolTip ? { "tooltipservice.tooltip": n.ActionIconToolTip } : {}), {
		default: _(() => [c("div", y, [
			n.ContentAlignment === "Left" ? o("", !0) : (f(), s("div", b, [i.hasHeaderIcon ? (f(), s("span", x, [p(e.$slots, "HeaderIcon", {}, () => [i.isHeaderIconMarkup ? (f(), s("span", {
				key: 0,
				innerHTML: i.resolvedHeaderIcon
			}, null, 8, S)) : (f(), s(r, { key: 1 }, [l(h(i.resolvedHeaderIcon), 1)], 64))])])) : o("", !0), c("div", C, [p(e.$slots, "Header", {}, () => [i.resolvedHeader ? (f(), a(i.TextBlock, {
				key: 0,
				class: "win-settings-card-title",
				Text: i.resolvedHeader,
				FontSize: "14",
				LineHeight: "20",
				TextWrapping: "Wrap"
			}, null, 8, ["Text"])) : o("", !0)]), p(e.$slots, "Description", {}, () => [i.resolvedDescription ? (f(), a(i.TextBlock, {
				key: 0,
				class: "win-settings-card-desc",
				Text: i.resolvedDescription,
				FontSize: "var(--SettingsCardDescriptionFontSize, 12px)",
				LineHeight: "16",
				Foreground: "var(--TextFillColorSecondaryBrush, var(--text-secondary))",
				TextWrapping: "Wrap"
			}, null, 8, ["Text"])) : o("", !0)])])])),
			c("div", w, [p(e.$slots, "default")]),
			n.IsClickEnabled && n.IsActionIconVisible ? (f(), s("span", T, [p(e.$slots, "ActionIcon", {}, () => [i.isActionIconMarkup ? (f(), s("span", {
				key: 0,
				innerHTML: i.resolvedActionIcon
			}, null, 8, E)) : (f(), s(r, { key: 1 }, [l(h(i.resolvedActionIcon), 1)], 64))])])) : o("", !0)
		])]),
		_: 3
	}, 16, [
		"class",
		"style",
		"type",
		"role"
	]);
}
var O = /*#__PURE__*/ t(v, [["render", D], ["__file", "SettingsCard.vue"]]);
//#endregion
export { O as default };

//# sourceMappingURL=SettingsCard.vue.js.map