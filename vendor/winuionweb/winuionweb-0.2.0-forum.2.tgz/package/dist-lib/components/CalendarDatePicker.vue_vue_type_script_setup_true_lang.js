import { alignment as e, cssLength as t, xamlThickness as n } from "./layout.js";
import { normalizeXamlNodes as r, resolveXamlHandler as i, resolveXamlValue as ee, updateXamlBinding as a, xamlScopeKey as o, xamlTemplateComponent as s } from "./xamlRuntime.js";
import { vThemeShadow as te } from "./themeShadowVisual.js";
import ne from "./Grid.vue.js";
import { useI18n as re } from "./i18n/index.js";
import { xamlResourceDictionaryKey as ie } from "./Page.vue_vue_type_script_lang.js";
import { getVNodeChildren as ae } from "./CollectionProperties.js";
import oe from "./TextBlock.vue.js";
import se from "./FontIcon.vue.js";
import ce from "./Border.vue.js";
import le from "./ContentPresenter.vue.js";
import { calendarDateSerial as ue, createCalendarModel as de } from "./calendarEngine.js";
import fe from "./CalendarView.vue.js";
import pe from "./ColumnDefinition.vue.js";
import me from "./RowDefinition.vue.js";
import { Fragment as he, Teleport as ge, computed as c, defineComponent as l, getCurrentInstance as _e, h as u, inject as ve, isVNode as ye, nextTick as be, onBeforeUnmount as xe, onMounted as Se, provide as Ce, ref as d, unref as we, useAttrs as Te, useSlots as Ee, watch as f, withDirectives as De } from "vue";
//#region src/components/CalendarDatePicker.vue?vue&type=script&setup=true&lang.ts
var p = (e) => l({
	name: `CalendarDatePicker.${e}`,
	__calendarPickerProperty: e,
	setup(e, { slots: t }) {
		return () => u(he, t.default?.());
	}
}), Oe = /*@__PURE__*/ l({
	Header: p("Header"),
	HeaderTemplate: p("HeaderTemplate"),
	Description: p("Description"),
	inheritAttrs: !1,
	__name: "CalendarDatePicker",
	props: {
		CalendarIdentifier: {
			type: String,
			default: "GregorianCalendar"
		},
		CalendarViewStyle: {
			type: [String, Object],
			default: null
		},
		Date: {
			type: [globalThis.Date, String],
			default: void 0
		},
		DateFormat: {
			type: String,
			default: "shortdate"
		},
		DayOfWeekFormat: {
			type: String,
			default: "{dayofweek.abbreviated(2)}"
		},
		Description: {
			type: null,
			default: ""
		},
		DisplayMode: {
			type: String,
			default: "Month"
		},
		FirstDayOfWeek: {
			type: String,
			default: "Sunday"
		},
		Header: {
			type: null,
			default: ""
		},
		HeaderPlacement: {
			type: String,
			default: "Top"
		},
		HeaderTemplate: {
			type: null,
			default: null
		},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		IsCalendarOpen: {
			type: [Boolean, String],
			default: void 0
		},
		IsGroupLabelVisible: {
			type: [Boolean, String],
			default: !1
		},
		IsOutOfScopeEnabled: {
			type: [Boolean, String],
			default: !0
		},
		IsTodayHighlighted: {
			type: [Boolean, String],
			default: !0
		},
		LightDismissOverlayMode: {
			type: String,
			default: "Auto"
		},
		MaxDate: {
			type: [globalThis.Date, String],
			default: () => new globalThis.Date(new globalThis.Date().getFullYear() + 100, 11, 31)
		},
		MinDate: {
			type: [globalThis.Date, String],
			default: () => new globalThis.Date(new globalThis.Date().getFullYear() - 100, 0, 1)
		},
		PlaceholderText: {
			type: String,
			default: ""
		},
		Language: {
			type: String,
			default: ""
		},
		Width: {
			type: [String, Number],
			default: ""
		},
		Height: {
			type: [String, Number],
			default: ""
		},
		MinWidth: {
			type: [String, Number],
			default: ""
		},
		MinHeight: {
			type: [String, Number],
			default: ""
		},
		MaxWidth: {
			type: [String, Number],
			default: ""
		},
		MaxHeight: {
			type: [String, Number],
			default: ""
		},
		Margin: {
			type: [String, Number],
			default: ""
		},
		Visibility: {
			type: String,
			default: "Visible"
		},
		HorizontalAlignment: {
			type: String,
			default: "Left"
		},
		VerticalAlignment: {
			type: String,
			default: "Center"
		},
		Background: {
			type: String,
			default: "{ThemeResource CalendarDatePickerBackground}"
		},
		Foreground: {
			type: String,
			default: "{ThemeResource CalendarDatePickerTextForeground}"
		},
		BorderBrush: {
			type: String,
			default: "{ThemeResource CalendarDatePickerBorderBrush}"
		},
		BorderThickness: {
			type: [String, Number],
			default: 1
		},
		CornerRadius: {
			type: [String, Number],
			default: "{ThemeResource ControlCornerRadius}"
		},
		RequestedTheme: {
			type: String,
			default: "Default"
		}
	},
	emits: [
		"update:Date",
		"update:IsCalendarOpen",
		"DateChanged",
		"Opened",
		"Closed",
		"CalendarViewDayItemChanging"
	],
	setup(Oe, { expose: ke, emit: Ae }) {
		let m = Oe, h = Ae, g = _e(), _ = Te(), je = Ee(), { t: Me, locale: Ne } = re(), Pe = ve("winuiTheme", null), Fe = ve(ie, null), v = d(null), y = d(null), b = d(null), x = d(null), S = (e) => ee(e, g), C = c(() => S(m.IsEnabled) !== !1), w = d(null), T = d(!1), E = d(!1), D = d(!1), O = d(!1), k = d({
			top: 0,
			left: 0,
			up: !1
		}), Ie = d(""), A = d(null), j = null, M = null, N = 0, P = !1, F = null, I = null, L = (e) => {
			if (e == null || e === "") return null;
			let t = e instanceof globalThis.Date ? e : new globalThis.Date(String(e));
			return Number.isFinite(t.getTime()) ? new globalThis.Date(t) : null;
		}, R = c(() => L(S(m.MinDate)) ?? new globalThis.Date(new globalThis.Date().getFullYear() - 100, 0, 1)), z = c(() => L(S(m.MaxDate)) ?? new globalThis.Date(new globalThis.Date().getFullYear() + 100, 11, 31)), B = (e) => {
			let t = L(e);
			return t ? new globalThis.Date(Math.min(z.value.getTime(), Math.max(R.value.getTime(), t.getTime()))) : null;
		}, V = (e, t) => e?.getTime() === t?.getTime(), Le = c(() => String(S(m.Language) || Ne)), H = c(() => {
			if (!w.value) return String(S(m.PlaceholderText) || Me("calendarDatePicker.placeholder"));
			let e = String(S(m.DateFormat)), t = e === "longdate" ? { dateStyle: "long" } : {
				year: "numeric",
				month: "numeric",
				day: "numeric"
			};
			e !== "shortdate" && e !== "longdate" && (delete t.dateStyle, /year/.test(e) && (t.year = "numeric"), /month/.test(e) && (t.month = /month\.full/.test(e) ? "long" : /month\.abbreviated/.test(e) ? "short" : "numeric"), /dayofweek/.test(e) && (t.weekday = /dayofweek\.full/.test(e) ? "long" : "short"), /\bday\b/.test(e) && (t.day = "numeric"));
			try {
				let e = ue(w.value);
				return de(String(S(m.CalendarIdentifier)), Le.value, e, e).formatSelectedDate(e, t);
			} catch {
				return new Intl.DateTimeFormat(Ne, {
					year: "numeric",
					month: "numeric",
					day: "numeric"
				}).format(w.value);
			}
		}), U = (e) => {
			let t = (n) => n.flatMap((n) => n.type === he && Array.isArray(n.children) ? t(n.children) : n.type?.__calendarPickerProperty === e ? Array.isArray(n.children) ? n.children : n.children?.default?.() ?? [] : []);
			return t(je.default?.() ?? []);
		}, W = c(() => S(m.Header)), G = c(() => S(m.Description)), Re = c(() => !!(W.value || m.HeaderTemplate || U("Header").length || U("HeaderTemplate").length)), ze = c(() => !!(G.value || U("Description").length)), Be = l({ setup() {
			return () => {
				let e = U("HeaderTemplate"), t = U("Header"), n = S(m.HeaderTemplate);
				if (e.length) return s(e, W.value, g);
				let i = typeof m.HeaderTemplate == "string" ? m.HeaderTemplate.match(/^\{StaticResource\s+([^\s}]+)\}$/)?.[1] : null;
				return i && Fe?.[i] ? s(ae(Fe[i]), W.value, g) : ye(n) ? s([n], W.value, g) : t.length ? u(he, r(t, g)) : ye(W.value) ? W.value : String(W.value ?? "");
			};
		} }), Ve = l({ setup() {
			return () => {
				let e = U("Description");
				return e.length ? u(he, r(e, g)) : ye(G.value) ? G.value : String(G.value ?? "");
			};
		} }), K = c(() => {
			let e = String(S(m.RequestedTheme)).toLowerCase(), t = String(we(Pe) || Ie.value).toLowerCase();
			return e === "dark" || e === "light" ? e : t;
		}), He = c(() => ({
			"is-disabled": !C.value,
			"has-date": !!w.value,
			"header-left": S(m.HeaderPlacement) === "Left",
			"theme-light": K.value === "light",
			"theme-dark": K.value === "dark",
			"win-theme-scope": K.value === "light" || K.value === "dark"
		})), Ue = c(() => Object.fromEntries(Object.entries(_).filter(([e]) => ![
			"DateChanged",
			"Opened",
			"Closed",
			"CalendarViewDayItemChanging",
			"class",
			"style"
		].includes(e)))), We = c(() => {
			let r = {
				"--picker-background": S(m.Background),
				"--picker-foreground": S(m.Foreground),
				"--picker-border": S(m.BorderBrush),
				"--picker-border-thickness": n(S(m.BorderThickness)),
				"--picker-corner-radius": t(S(m.CornerRadius)),
				margin: n(S(m.Margin)),
				justifySelf: e(S(m.HorizontalAlignment), "horizontal"),
				alignSelf: e(S(m.VerticalAlignment), "vertical")
			};
			for (let e of [
				"Width",
				"Height",
				"MinWidth",
				"MinHeight",
				"MaxWidth",
				"MaxHeight"
			]) {
				let n = t(S(m[e]));
				n && (r[e[0].toLowerCase() + e.slice(1)] = n);
			}
			return S(m.Visibility) === "Collapsed" && (r.display = "none"), S(m.Visibility) === "Hidden" && (r.visibility = "hidden"), [_.style, r];
		}), q = (e, t = {}) => {
			h(e, $, t), i(_[e], g)?.($, t);
		}, J = (e) => {
			let t = B(e);
			if (V(w.value, t)) return;
			let n = w.value;
			w.value = t, a(m.Date, t, g), h("update:Date", t), q("DateChanged", {
				OldDate: n,
				NewDate: t
			});
		}, Ge = (e) => {
			T.value = e, a(m.IsCalendarOpen, e, g), h("update:IsCalendarOpen", e);
		}, Y = () => {
			M?.cancel(), M = null;
		}, X = () => {
			if (!E.value || !v.value || !b.value) return;
			let e = v.value.getBoundingClientRect(), t = b.value.offsetWidth, n = b.value.offsetHeight, r = window.visualViewport, i = (r?.offsetLeft ?? 0) + 4, ee = (r?.offsetTop ?? 0) + 4, a = i + (r?.width ?? window.innerWidth) - 8, o = ee + (r?.height ?? window.innerHeight) - 8, s = e.bottom + 4 + n > o && e.top - ee > o - e.bottom;
			k.value = {
				left: Math.max(i, Math.min(a - t, e.left + (e.width - t) / 2)),
				top: Math.max(ee, Math.min(o - n, s ? e.top - 4 - n : e.bottom + 4)),
				up: s
			}, D.value = !0;
		}, Z = async (e = !0) => {
			if (!T.value || O.value) return;
			let t = ++N;
			Ge(!1), O.value = !0, Y();
			let n = b.value;
			if (n && !window.matchMedia("(prefers-reduced-motion: reduce)").matches && typeof n.animate == "function") {
				M = n.animate([{ opacity: 1 }, { opacity: 0 }], {
					duration: 100,
					fill: "forwards"
				});
				try {
					await M.finished;
				} catch {}
			}
			P || t !== N || (Y(), E.value = !1, O.value = !1, D.value = !1, await be(), !(P || t !== N) && (q("Closed"), e && C.value && y.value?.focus({ preventScroll: !0 })));
		}, Q = async () => {
			if (!C.value || T.value && !O.value) return;
			window.dispatchEvent(new Event("winui-flyout-hide"));
			let e = ++N;
			if (Y(), O.value = !1, D.value = !1, Ge(!0), E.value = !0, await be(), P || e !== N || !T.value || (j && x.value?.SetYearDecadeDisplayDimensions(...j), x.value?.SetDisplayDate(A.value ?? w.value ?? new globalThis.Date()), await be(), P || e !== N || !T.value)) return;
			X();
			let t = b.value;
			if (t && !window.matchMedia("(prefers-reduced-motion: reduce)").matches && typeof t.animate == "function") {
				let n = k.value.up ? 50 : -50;
				M = t.animate([{
					opacity: 0,
					transform: `translateY(${n}px)`
				}, {
					opacity: 1,
					transform: "translateY(0)"
				}], {
					duration: 300,
					easing: "cubic-bezier(0.1,0.9,0.2,1)"
				}), M.finished.then(() => {
					e === N && (M = null);
				}).catch(() => {});
			}
			q("Opened"), x.value?.FocusDate?.(A.value ?? w.value ?? new globalThis.Date());
		}, Ke = (e, t) => {
			if (!(e.SelectionMode && e.SelectionMode !== "Single")) if (t.AddedDates.length) {
				if (V(w.value, L(t.AddedDates[0]))) return;
				Z(), J(t.AddedDates[0]);
			} else t.RemovedDates.some((e) => V(w.value, L(e))) && J(null);
		}, qe = (e, t) => q("CalendarViewDayItemChanging", t);
		Ce(o, {
			PickerText: H,
			PickerEnabled: C,
			PickerLanguage: Le,
			PickerCalendarViewStyle: c(() => S(m.CalendarViewStyle)),
			PickerSelectedDates: c(() => w.value ? [w.value] : []),
			PickerCalendarIdentifier: c(() => S(m.CalendarIdentifier)),
			PickerDayOfWeekFormat: c(() => S(m.DayOfWeekFormat)),
			PickerDisplayMode: c(() => S(m.DisplayMode)),
			PickerFirstDayOfWeek: c(() => S(m.FirstDayOfWeek)),
			PickerGroupLabelVisible: c(() => S(m.IsGroupLabelVisible)),
			PickerOutOfScopeEnabled: c(() => S(m.IsOutOfScopeEnabled)),
			PickerTodayHighlighted: c(() => S(m.IsTodayHighlighted)),
			PickerMinDate: R,
			PickerMaxDate: z,
			OnSelectedDatesChanged: Ke,
			OnCalendarViewDayItemChanging: qe
		});
		let Je = l({
			name: "CalendarDatePicker.Flyout",
			inheritAttrs: !1,
			props: {
				Placement: String,
				ShouldConstrainToRootBounds: String
			},
			setup(e, { slots: t }) {
				let n = _e();
				return () => E.value ? u(ge, { to: "body" }, [u("div", {
					class: ["calendar-picker-dismiss-layer", { "overlay-on": S(m.LightDismissOverlayMode) === "On" }],
					onPointerdown: () => {
						Z();
					}
				}), De(u("div", {
					ref: b,
					role: "dialog",
					"aria-modal": "true",
					"aria-label": String(W.value || Me("calendarDatePicker.calendar")),
					class: [
						"calendar-picker-flyout",
						"win-theme-scope",
						K.value ? `theme-${K.value}` : "",
						{ "is-closing": O.value }
					],
					style: {
						top: `${k.value.top}px`,
						left: `${k.value.left}px`,
						visibility: D.value ? "visible" : "hidden"
					},
					onKeydown: Ye
				}, r(t.default?.() ?? [], n)), [[te, { Translation: 32 }]])]) : null;
			}
		}), Ye = (e) => {
			if (e.key === "Escape" && (e.preventDefault(), e.stopPropagation(), Z()), e.key !== "Tab") return;
			let t = Array.from(b.value?.querySelectorAll("button:not(:disabled):not([tabindex=\"-1\"]),[tabindex=\"0\"]") ?? []).filter((e) => e.getClientRects().length);
			if (!t.length) return;
			let n = (t.indexOf(document.activeElement) + (e.shiftKey ? -1 : 1) + t.length) % t.length;
			e.preventDefault(), t[n]?.focus({ preventScroll: !0 });
		}, Xe = () => {
			T.value ? Z() : Q();
		}, Ze = () => {
			Z(!1);
		}, Qe = () => {
			Z(!1);
		}, $e = (e) => {
			e.key === "Escape" && T.value && (e.preventDefault(), Z()), e.key === "ArrowDown" && e.altKey && (e.preventDefault(), Q());
		}, et = () => {
			y.value && (y.value.disabled = !C.value, y.value.setAttribute("aria-haspopup", "dialog"), y.value.setAttribute("aria-expanded", String(T.value)), y.value.setAttribute("aria-label", [String(W.value ?? ""), H.value].filter(Boolean).join(": ")));
		}, tt = () => {
			let e = v.value?.parentElement?.closest(".theme-light,.theme-dark,[data-theme]");
			Ie.value = e?.getAttribute("data-theme") || (e?.classList.contains("theme-dark") ? "dark" : e?.classList.contains("theme-light") ? "light" : document.documentElement.classList.contains("theme-dark") ? "dark" : "light");
		};
		f(() => S(m.Date), (e) => J(e)), f([R, z], () => J(w.value)), f(() => S(m.IsCalendarOpen), (e) => {
			e !== void 0 && (e === !0 ? Q() : Z());
		}), f(C, (e) => {
			e || Z(!1);
		}), f([
			C,
			T,
			H,
			W
		], et, { flush: "post" });
		let $ = {
			get Date() {
				return w.value;
			},
			set Date(e) {
				J(e);
			},
			get IsCalendarOpen() {
				return T.value;
			},
			set IsCalendarOpen(e) {
				e ? Q() : Z();
			},
			SetDisplayDate(e) {
				A.value = B(e), A.value && x.value?.SetDisplayDate(A.value);
			},
			SetYearDecadeDisplayDimensions(e, t) {
				j = [e, t], x.value?.SetYearDecadeDisplayDimensions(e, t);
			},
			Focus: () => (y.value?.focus({ preventScroll: !0 }), C.value)
		};
		ke($), Se(() => {
			w.value = B(S(m.Date)), V(L(S(m.Date)), w.value) || (a(m.Date, w.value, g), h("update:Date", w.value)), et(), tt(), y.value?.addEventListener("click", Xe), y.value?.addEventListener("keydown", $e), window.addEventListener("resize", X), window.addEventListener("blur", Ze), window.addEventListener("winui-flyout-hide", Qe), window.addEventListener("scroll", X, !0), window.visualViewport?.addEventListener("resize", X), window.visualViewport?.addEventListener("scroll", X), F = new ResizeObserver(X), v.value && F.observe(v.value), I = new MutationObserver(tt);
			for (let e = v.value?.parentElement; e; e = e.parentElement) I.observe(e, {
				attributes: !0,
				attributeFilter: ["class", "data-theme"]
			});
			S(m.IsCalendarOpen) === !0 && Q();
		}), xe(() => {
			P = !0, N++, Y(), F?.disconnect(), I?.disconnect(), y.value?.removeEventListener("click", Xe), y.value?.removeEventListener("keydown", $e), window.removeEventListener("resize", X), window.removeEventListener("blur", Ze), window.removeEventListener("winui-flyout-hide", Qe), window.removeEventListener("scroll", X, !0), window.visualViewport?.removeEventListener("resize", X), window.visualViewport?.removeEventListener("scroll", X);
		});
		let nt = {
			property: p,
			props: m,
			emit: h,
			instance: g,
			attrs: _,
			slots: je,
			t: Me,
			locale: Ne,
			inheritedTheme: Pe,
			resources: Fe,
			rootRef: v,
			buttonRef: y,
			flyoutRef: b,
			calendarRef: x,
			value: S,
			enabled: C,
			localDate: w,
			open: T,
			visible: E,
			positioned: D,
			closing: O,
			flyoutPosition: k,
			inheritedThemeName: Ie,
			requestedDisplayDate: A,
			get displayDimensions() {
				return j;
			},
			set displayDimensions(e) {
				j = e;
			},
			get animation() {
				return M;
			},
			set animation(e) {
				M = e;
			},
			get transitionVersion() {
				return N;
			},
			set transitionVersion(e) {
				N = e;
			},
			get disposed() {
				return P;
			},
			set disposed(e) {
				P = e;
			},
			get resizeObserver() {
				return F;
			},
			set resizeObserver(e) {
				F = e;
			},
			get themeObserver() {
				return I;
			},
			set themeObserver(e) {
				I = e;
			},
			asDate: L,
			minDate: R,
			maxDate: z,
			coerceDate: B,
			sameDate: V,
			language: Le,
			dateText: H,
			propertyNodes: U,
			header: W,
			description: G,
			hasHeader: Re,
			hasDescription: ze,
			HeaderContent: Be,
			DescriptionContent: Ve,
			theme: K,
			rootClasses: He,
			rootAttrs: Ue,
			rootStyle: We,
			raise: q,
			setDate: J,
			syncOpen: Ge,
			cancelAnimation: Y,
			updatePosition: X,
			closeCalendar: Z,
			showCalendar: Q,
			onSelectedDatesChanged: Ke,
			onDayItemChanging: qe,
			Flyout: Je,
			onFlyoutKeyDown: Ye,
			onButtonClick: Xe,
			onWindowBlur: Ze,
			onGlobalDismiss: Qe,
			onButtonKeyDown: $e,
			syncButton: et,
			updateInheritedTheme: tt,
			publicApi: $,
			Border: ce,
			CalendarView: fe,
			ColumnDefinition: pe,
			ContentPresenter: le,
			FontIcon: se,
			Grid: ne,
			RowDefinition: me,
			TextBlock: oe
		};
		return Object.defineProperty(nt, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), nt;
	}
});
//#endregion
export { Oe as default };

//# sourceMappingURL=CalendarDatePicker.vue_vue_type_script_setup_true_lang.js.map