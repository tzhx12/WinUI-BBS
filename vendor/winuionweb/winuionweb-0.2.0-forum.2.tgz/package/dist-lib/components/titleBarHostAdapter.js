//#region src/components/titleBarHostAdapter.ts
var e = Symbol.for("WinUI.TitleBarHostAdapter"), t, n = /* @__PURE__ */ new WeakMap();
function r(e) {
	let n = t;
	return t = e, () => {
		t === e && (t = n);
	};
}
function i(e, t) {
	return n.set(e, t), () => {
		n.get(e) === t && n.delete(e);
	};
}
function a(e) {
	let t = e.PhysicalPixelsPerCssPixel;
	if (!Number.isFinite(t) || t <= 0 || !Number.isFinite(e.LeftInset) || !Number.isFinite(e.RightInset) || e.LeftInset < 0 || e.RightInset < 0) return null;
	let n = e.TitleBarArea;
	return n && (![
		n.X,
		n.Y,
		n.Width,
		n.Height
	].every(Number.isFinite) || n.Width < 0 || n.Height < 0) ? null : {
		LeftInset: e.LeftInset / t,
		RightInset: e.RightInset / t,
		...n ? { TitleBarArea: {
			X: n.X / t,
			Y: n.Y / t,
			Width: n.Width / t,
			Height: n.Height / t
		} } : {}
	};
}
async function o(e, t, n) {
	n?.throwIfAborted(), t.ExtendsContentIntoTitleBar !== void 0 && await e?.SetExtendsContentIntoTitleBar?.(t.ExtendsContentIntoTitleBar), n?.throwIfAborted(), t.PreferredHeightOption !== void 0 && await e?.SetPreferredHeightOption?.(t.PreferredHeightOption), n?.throwIfAborted();
}
function s(e, t, n) {
	if (!n || !Number.isFinite(t) || t <= 0 || !Number.isFinite(n.LeftInset) || !Number.isFinite(n.RightInset)) return null;
	let r = n.TitleBarArea;
	if (r && (![
		r.X,
		r.Y,
		r.Width,
		r.Height
	].every(Number.isFinite) || r.Width < 0 || r.Height < 0) || r && (e.Y >= r.Y + r.Height || e.Y + e.Height <= r.Y)) return null;
	let i = Math.max(0, e.Width), a = Math.min(i, Math.max(0, n.LeftInset - e.X));
	return {
		LeftInset: a,
		RightInset: Math.min(i - a, Math.max(0, e.X + i - (t - Math.max(0, n.RightInset))))
	};
}
function c(e, t) {
	let n = e.navigator?.windowControlsOverlay, r = t ?? e.winUIonWebWindowControls;
	return {
		GetTitle: () => e.document.title,
		SetTitle: (t) => {
			e.document.title = t;
		},
		IsInputActive: () => e.document.hasFocus(),
		SubscribeActivation(t) {
			let n = () => t(!0), r = () => t(!1);
			return e.addEventListener("focus", n), e.addEventListener("blur", r), () => {
				e.removeEventListener("focus", n), e.removeEventListener("blur", r);
			};
		},
		GetTitleBarInsets() {
			if (r?.GetTitleBarInsets) return r.GetTitleBarInsets();
			if (!n?.visible) return null;
			let t = n.getTitlebarAreaRect();
			return ![
				t.x,
				t.y,
				t.width,
				t.height
			].every(Number.isFinite) || t.width <= 0 || t.height <= 0 ? null : {
				LeftInset: Math.max(0, t.x),
				RightInset: Math.max(0, e.innerWidth - t.x - t.width),
				TitleBarArea: {
					X: t.x,
					Y: t.y,
					Width: t.width,
					Height: t.height
				}
			};
		},
		SubscribeTitleBarInsets(t) {
			let i = r?.SubscribeTitleBarInsets?.(t);
			return n?.addEventListener("geometrychange", t), e.addEventListener("resize", t), () => {
				i && Promise.resolve(i).then((e) => e()), n?.removeEventListener("geometrychange", t), e.removeEventListener("resize", t);
			};
		},
		...r ? {
			Minimize: () => r.Minimize(),
			ToggleMaximize: () => r.ToggleMaximize(),
			Close: () => r.Close(),
			IsMaximized: () => r.IsMaximized(),
			SubscribeStateChanged: (e) => r.SubscribeStateChanged?.(e) ?? (() => {}),
			...r.SubscribeCaptionButtonAction ? { SubscribeCaptionButtonAction: (e) => r.SubscribeCaptionButtonAction(e) } : {},
			...r.SetCaptionButtonHitTestMode ? { SetCaptionButtonHitTestMode: (e) => r.SetCaptionButtonHitTestMode(e) } : {},
			get UsesNativeCaptionHitTest() {
				return r.UsesNativeCaptionHitTest === !0;
			},
			...r.SubscribeCaptionButtonState ? { SubscribeCaptionButtonState: (e) => r.SubscribeCaptionButtonState(e) } : {}
		} : {}
	};
}
function l(e, t, n) {
	let r = (e) => !!(e?.Minimize && e.ToggleMaximize && e.Close && e.IsMaximized);
	if (t === "Tauri") return r(n) ? n : null;
	let i = e.electronAPI?.windowControls;
	return i ? c(e, i) : null;
}
function u(e, r) {
	let i = r ?? t;
	if (i) {
		let t = i.Connect(e);
		return t && t.IsTitleBarOwner?.(e) === !1 ? null : t;
	}
	for (let t = e; t; t = t.parentElement) {
		let r = n.get(t);
		if (r) return r.IsTitleBarOwner?.(e) === !1 ? null : r;
	}
	let a = e.closest(".win-system-backdrop-window-content");
	if (!e.matches(".gallery-titlebar") && (!a || a.querySelector(".win-titlebar") !== e)) return null;
	let o = e.ownerDocument.defaultView;
	return o ? c(o) : null;
}
//#endregion
export { o as configureTitleBarWindowHost, u as connectTitleBarWindowHost, c as createBrowserTitleBarWindowHost, l as createFrameworkTitleBarWindowHost, s as getTitleBarHostPadding, a as nativeTitleBarMetricsToCssPixels, i as registerTitleBarWindowHost, r as setTitleBarHostAdapter, e as titleBarHostAdapterKey };

//# sourceMappingURL=titleBarHostAdapter.js.map