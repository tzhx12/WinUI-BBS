import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./SplitButton.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                */
import { createBlock as n, createCommentVNode as r, createElementBlock as i, createVNode as a, mergeProps as o, openBlock as s, resolveComponent as c, withCtx as l } from "vue";
//#region src/components/SplitButton.vue
var u = [
	"tabindex",
	"aria-disabled",
	"aria-expanded"
];
function d(e, t, d, f, p, m) {
	let h = c("ColumnDefinition");
	return s(), i("div", o({ ref: "root" }, f.hostAttrs, {
		class: ["win-split-button", [f.attrs.class, {
			"is-open": f.isOpen,
			"is-disabled": !f.IsEnabled,
			"keyboard-pressed": f.keyPressed,
			"system-focus": f.boolValue(f.resolve(f.props.UseSystemFocusVisuals)),
			"win-theme-scope": f.RequestedTheme === "Light" || f.RequestedTheme === "Dark",
			"theme-light": f.RequestedTheme === "Light",
			"theme-dark": f.RequestedTheme === "Dark"
		}]],
		style: f.hostStyle,
		role: "button",
		tabindex: f.IsEnabled && f.IsTabStop ? 0 : -1,
		"aria-disabled": !f.IsEnabled || void 0,
		"aria-expanded": f.isOpen,
		onKeydown: f.onKeyDown,
		onKeyup: f.onKeyUp,
		onBlur: f.clearKey
	}), [a(f.Grid, {
		class: "win-split-root-grid",
		Background: "Transparent",
		CornerRadius: "{x:Bind CornerRadius}"
	}, {
		default: l(() => [
			a(f.Grid.ColumnDefinitions, null, {
				default: l(() => [
					a(h, {
						Width: "*",
						MinWidth: "35"
					}),
					a(h, { Width: "1" }),
					a(h, { Width: "35" })
				]),
				_: 1
			}),
			a(f.Grid, {
				class: "win-split-primary-background",
				"Grid.ColumnSpan": "2",
				Background: "{x:Bind PrimaryBackground}"
			}),
			a(f.Grid, {
				class: "win-split-divider",
				"Grid.Column": "1",
				Background: "{x:Bind DividerBackground}"
			}),
			a(f.Grid, {
				class: "win-split-secondary-background",
				"Grid.Column": "2",
				Background: "{x:Bind SecondaryBackground}"
			}),
			a(f.Button, {
				ref: "primaryButton",
				class: "win-split-main-button",
				"Grid.Column": "0",
				IsEnabled: "{x:Bind IsEnabled}",
				IsTabStop: "False",
				Background: "Transparent",
				BorderBrush: "Transparent",
				BorderThickness: "0",
				Foreground: "{x:Bind PrimaryForeground}",
				HorizontalAlignment: "Stretch",
				VerticalAlignment: "Stretch",
				HorizontalContentAlignment: "{x:Bind HorizontalContentAlignment}",
				VerticalContentAlignment: "{x:Bind VerticalContentAlignment}",
				Padding: "{x:Bind Padding}",
				FontFamily: "{x:Bind FontFamily}",
				FontSize: "{x:Bind FontSize}",
				FontWeight: "{x:Bind FontWeight}",
				Content: "{x:Bind Content}",
				ContentTemplate: "{x:Bind ContentTemplate}",
				ContentTransitions: "{x:Bind ContentTransitions}",
				Click: "OnPrimaryClick",
				PointerEntered: "OnPrimaryEntered",
				PointerExited: "OnPrimaryExited",
				PointerMoved: "OnPrimaryMoved",
				PointerPressed: "OnPrimaryPressed",
				PointerReleased: "OnPrimaryReleased",
				PointerCanceled: "OnPrimaryReleased",
				PointerCaptureLost: "OnPrimaryReleased"
			}, {
				default: l(() => [a(f.MainOutlet)]),
				_: 1
			}, 512),
			a(f.Button, {
				ref: "secondaryButton",
				class: "win-split-secondary-button",
				"Grid.Column": "2",
				IsEnabled: "{x:Bind IsEnabled}",
				IsTabStop: "False",
				Background: "Transparent",
				BorderBrush: "Transparent",
				BorderThickness: "0",
				Foreground: "{x:Bind SecondaryForeground}",
				HorizontalAlignment: "Stretch",
				VerticalAlignment: "Stretch",
				HorizontalContentAlignment: "Stretch",
				VerticalContentAlignment: "Stretch",
				Padding: "0,0,12,0",
				Click: "OnSecondaryClick",
				PointerEntered: "OnSecondaryEntered",
				PointerExited: "OnSecondaryExited",
				PointerMoved: "OnSecondaryMoved",
				PointerPressed: "OnSecondaryPressed",
				PointerReleased: "OnSecondaryReleased",
				PointerCanceled: "OnSecondaryReleased",
				PointerCaptureLost: "OnSecondaryReleased"
			}, {
				default: l(() => [a(f.Button.Content, null, {
					default: l(() => [a(f.AnimatedIcon, {
						Height: "12",
						Width: "12",
						VerticalAlignment: "Center",
						HorizontalAlignment: "Right",
						"AutomationProperties.AccessibilityView": "Raw"
					}, {
						default: l(() => [a(f.AnimatedChevronDownSmallVisualSource), a(f.AnimatedIcon.FallbackIconSource, null, {
							default: l(() => [a(f.FontIconSource, {
								FontFamily: "{ThemeResource SymbolThemeFontFamily}",
								FontSize: "8",
								Glyph: "",
								IsTextScaleFactorEnabled: "False"
							})]),
							_: 1
						})]),
						_: 1
					})]),
					_: 1
				})]),
				_: 1
			}, 512),
			a(f.Grid, {
				class: "win-split-primary-border",
				"Grid.Column": "0",
				BorderBrush: "{x:Bind PrimaryBorderBrush}",
				BorderThickness: "1,1,0,1",
				CornerRadius: "4,0,0,4"
			}),
			a(f.Grid, {
				class: "win-split-secondary-border",
				"Grid.Column": "2",
				BorderBrush: "{x:Bind SecondaryBorderBrush}",
				BorderThickness: "0,1,1,1",
				CornerRadius: "0,4,4,0"
			})
		]),
		_: 1
	}), f.flyoutNodes.length ? (s(), n(f.FlyoutOutlet, { key: 0 })) : r("", !0)], 16, u);
}
var f = /*#__PURE__*/ e(t, [["render", d], ["__file", "SplitButton.vue"]]);
//#endregion
export { f as default };

//# sourceMappingURL=SplitButton.vue.js.map