import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./SwipeControl.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                                 */
import { Fragment as n, createCommentVNode as r, createElementBlock as i, createElementVNode as a, createVNode as o, mergeProps as s, normalizeClass as c, normalizeStyle as l, openBlock as u, renderList as d, toDisplayString as f, withModifiers as p } from "vue";
//#region src/components/SwipeControl.vue
var m = [
	"aria-label",
	"aria-disabled",
	"tabindex"
], h = [
	"disabled",
	"tabindex",
	"aria-label",
	"tooltipservice",
	"onClick"
], g = {
	class: "swipe-item-content",
	"data-part": "ContentRoot"
}, _ = { class: "swipe-item-viewbox" }, v = {
	class: "swipe-item-text",
	"data-part": "TextLabel"
}, y = ["inert"];
function b(e, t, b, x, S, C) {
	return u(), i("div", s({ ref: "root" }, x.attrs, {
		class: ["win-swipe-control", {
			interacting: x.interacting,
			open: x.open,
			"threshold-reached": x.thresholdReached
		}],
		"data-part": "RootGrid",
		style: x.rootStyle,
		"aria-label": x.automationName || void 0,
		"aria-disabled": !x.enabled || void 0,
		tabindex: x.tabStop ? 0 : -1,
		onPointerdown: x.pointerDown,
		onPointermove: x.pointerMove,
		onPointerup: x.pointerUp,
		onPointercancel: x.pointerCancel,
		onLostpointercapture: x.captureLost,
		onClickCapture: x.suppressClick,
		onContextmenu: x.contextRequested,
		onPointerenter: t[0] ||= (e) => x.emit("PointerEntered", x.exposed, e),
		onPointerleave: t[1] ||= (e) => x.emit("PointerExited", x.exposed, e)
	}), [a("div", {
		class: c(["swipe-content-root", [`side-${x.side?.toLowerCase()}`, `mode-${x.mode.toLowerCase()}`]]),
		"data-part": "SwipeContentRoot",
		style: l(x.underlayStyle)
	}, [a("div", {
		ref: "panel",
		class: "swipe-items-panel",
		"data-part": "SwipeContentStackPanel",
		style: l(x.panelStyle)
	}, [(u(!0), i(n, null, d(x.currentItems, (e, t) => (u(), i("button", {
		key: t,
		class: "swipe-item",
		"data-control": "AppBarButton",
		"data-style": "SwipeItemStyle",
		"data-part": "Root",
		type: "button",
		style: l(x.itemStyle(e)),
		disabled: !x.itemEnabled(e),
		tabindex: x.open ? 0 : -1,
		"aria-label": x.itemLabel(e) || void 0,
		tooltipservice: x.itemDescription(e) || void 0,
		onPointerdown: p(x.itemPointerDown, ["stop"]),
		onPointermove: x.itemPointerMove,
		onPointerup: x.itemPointerUp,
		onPointercancel: x.itemPointerCancel,
		onLostpointercapture: x.itemPointerCaptureLost,
		onClick: p((t) => x.itemClicked(e, t), ["stop"])
	}, [a("div", g, [a("div", _, [x.iconUri(e) ? (u(), i("span", {
		key: 0,
		class: "swipe-item-bitmap",
		style: l(x.bitmapStyle(e)),
		"aria-hidden": "true"
	}, null, 4)) : x.iconGlyph(e) ? (u(), i("span", {
		key: 1,
		class: "swipe-item-icon",
		style: l(x.iconStyle(e)),
		"aria-hidden": "true"
	}, f(x.iconGlyph(e)), 5)) : r("", !0)]), a("span", v, f(x.itemLabel(e)), 1)])], 44, h))), 128))], 4)], 6), a("div", {
		ref: "contentRoot",
		class: "swipe-control-content",
		"data-part": "ContentRoot",
		style: l(x.contentTransform)
	}, [a("div", {
		class: "swipe-content-presenter",
		"data-part": "ContentPresenter",
		style: l(x.presenterStyle),
		inert: !x.enabled
	}, [o(x.ContentOutlet)], 12, y), a("div", {
		class: "swipe-input-eater",
		"data-part": "InputEater",
		style: l(x.inputEaterStyle),
		"aria-hidden": "true",
		onClick: p(x.dismiss, ["stop"])
	}, null, 4)], 4)], 16, m);
}
var x = /*#__PURE__*/ e(t, [
	["render", b],
	["__scopeId", "data-v-7ba36daf"],
	["__file", "SwipeControl.vue"]
]);
//#endregion
export { x as default };

//# sourceMappingURL=SwipeControl.vue.js.map