import { normalizeXamlNodes as e, resolveXamlHandler as t, resolveXamlValue as n } from "./xamlRuntime.js";
import r from "./ExpanderBase.vue.js";
import { ExpanderContent as i, ExpanderDescription as a, ExpanderHeader as o, ExpanderHeaderControls as s, ExpanderHeaderIcon as c, getExpanderProperty as l } from "./ExpanderProperties.js";
import { Fragment as u, computed as d, defineComponent as f, getCurrentInstance as p, h as m, ref as h, useSlots as g } from "vue";
var _ = /*@__PURE__*/ f({
	Header: o,
	Content: i,
	Description: a,
	HeaderIcon: c,
	HeaderControls: s,
	inheritAttrs: !1,
	__name: "Expander",
	props: {
		Header: {
			type: [String, Number],
			default: ""
		},
		Content: {
			type: [String, Number],
			default: ""
		},
		Description: {
			type: [String, Number],
			default: ""
		},
		HeaderIcon: {
			type: String,
			default: ""
		},
		IsExpanded: {
			type: [Boolean, String],
			default: !1
		},
		ExpandDirection: {
			type: [String, Number],
			default: "Down"
		},
		Padding: {
			type: [String, Number],
			default: "16"
		},
		Background: {
			type: [String, Object],
			default: "{ThemeResource ExpanderContentBackground}"
		},
		BorderBrush: {
			type: [String, Object],
			default: "{ThemeResource ExpanderContentBorderBrush}"
		},
		BorderThickness: {
			type: [String, Number],
			default: ""
		},
		CornerRadius: {
			type: [String, Number],
			default: "{ThemeResource ControlCornerRadius}"
		},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		HorizontalContentAlignment: {
			type: String,
			default: "Stretch"
		},
		VerticalContentAlignment: {
			type: String,
			default: "Stretch"
		},
		Width: {
			type: [String, Number],
			default: ""
		},
		MinWidth: {
			type: [String, Number],
			default: ""
		},
		Height: {
			type: [String, Number],
			default: ""
		},
		MaxWidth: {
			type: [String, Number],
			default: ""
		},
		HorizontalAlignment: {
			type: String,
			default: ""
		},
		VerticalAlignment: {
			type: String,
			default: ""
		}
	},
	emits: [
		"update:IsExpanded",
		"Expanding",
		"Collapsed"
	],
	setup(i, { expose: a }) {
		let o = r, s = p(), c = h(null), _ = (e, n, r) => {
			let i = s?.exposeProxy ?? s?.exposed ?? s?.proxy, a = s?.vnode.props?.[`on${e}`];
			for (let e of Array.isArray(a) ? a : [a]) typeof e == "function" && e(i, r);
			t(s?.attrs[e], s)?.(i, r);
		}, v = (e, t) => _("Expanding", e, t), y = (e, t) => _("Collapsed", e, t), b = i;
		a({
			get IsExpanded() {
				return c.value?.IsExpanded ?? n(b.IsExpanded, s) === !0;
			},
			set IsExpanded(e) {
				c.value && (c.value.IsExpanded = e);
			}
		});
		let x = g(), S = d(() => {
			let t = {
				header: [],
				content: [],
				description: [],
				headerIcon: [],
				headerControls: []
			}, n = [], r = (i) => {
				for (let a of i) {
					if (a.type === u && Array.isArray(a.children)) {
						r(a.children);
						continue;
					}
					let i = l(a);
					if (!i || !a.children || typeof a.children != "object") {
						n.push(a);
						continue;
					}
					let o = a.children.default;
					o && (t[i] = e(o(), s));
				}
			};
			return r(x.default?.() ?? []), t.content.length || (t.content = e(n, s)), t;
		}), C = (e) => f({
			name: `Expander${e[0].toUpperCase()}${e.slice(1)}Outlet`,
			setup() {
				return () => m(u, S.value[e]);
			}
		}), w = {
			ExpanderBase: o,
			instance: s,
			expanderBase: c,
			forwardLifecycleEvent: _,
			forwardExpanding: v,
			forwardCollapsed: y,
			props: b,
			slots: x,
			propertyNodes: S,
			outlet: C,
			HeaderOutlet: C("header"),
			DescriptionOutlet: C("description"),
			HeaderIconOutlet: C("headerIcon"),
			HeaderControlsOutlet: C("headerControls"),
			ContentOutlet: C("content"),
			headerNodes: d(() => S.value.header),
			descriptionNodes: d(() => S.value.description),
			headerIconNodes: d(() => S.value.headerIcon),
			headerControlsNodes: d(() => S.value.headerControls),
			contentNodes: d(() => S.value.content)
		};
		return Object.defineProperty(w, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), w;
	}
});
//#endregion
export { _ as default };

//# sourceMappingURL=Expander.vue_vue_type_script_setup_true_lang.js.map