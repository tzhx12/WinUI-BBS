import { getCollectionProperty as e } from "./CollectionProperties.js";
import { defineComponent as t } from "vue";
//#region src/components/ComboBoxProperties.ts
var n = (e) => t({
	name: `ComboBox.${e}`,
	__comboBoxProperty: e,
	setup() {
		return () => null;
	}
}), r = n("Header"), i = n("HeaderTemplate"), a = n("Description"), o = (e) => {
	let t = e.type;
	return typeof t != "string" && t?.__comboBoxProperty ? t.__comboBoxProperty : (typeof t == "string" ? t : t?.name)?.match(/^ComboBox\.(Header|HeaderTemplate|Description)$/)?.[1];
}, s = (t) => o(t) || e(t);
//#endregion
export { a as ComboBoxDescription, r as ComboBoxHeader, i as ComboBoxHeaderTemplate, o as getComboBoxProperty, s as isComboBoxProperty };

//# sourceMappingURL=ComboBoxProperties.js.map