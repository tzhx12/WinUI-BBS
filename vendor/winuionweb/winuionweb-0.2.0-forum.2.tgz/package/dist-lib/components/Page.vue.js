import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./Page.vue_vue_type_script_lang.js";
//#region src/components/Page.vue
var n = /*#__PURE__*/ e(t, [["__file", "Page.vue"]]);
//#endregion
export { n as default };

//# sourceMappingURL=Page.vue.js.map