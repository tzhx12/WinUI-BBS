import e from "../Strings/en-US/Resources.js";
import t from "../Strings/zh-CN/Resources.js";
import { inject as n } from "vue";
//#region src/components/i18n/index.ts
var r = Symbol.for("WinUIonWeb.i18n"), i = {
	"en-US": e,
	"zh-CN": t
}, a = (e) => (e || "en-US").toLowerCase().startsWith("zh") ? "zh-CN" : "en-US", o = (e, t) => t ? e.replace(/\{(\w+)\}/g, (e, n) => String(t[n] ?? "")) : e, s = (e = navigator.language, t) => {
	let n = a(e), r = {
		...i[n],
		...t?.[n]
	}, s = {
		...i["en-US"],
		...t?.["en-US"]
	};
	return {
		locale: n,
		t: (e, t) => o(r[e] ?? s[e] ?? e, t)
	};
}, c = () => n(r, s("en-US"));
//#endregion
export { s as createI18n, r as i18nKey, a as normalizeLocale, c as useI18n };

//# sourceMappingURL=index.js.map