import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./AppBarButton.vue_vue_type_script_setup_true_lang.js";
import { Fragment as n, createCommentVNode as r, createElementBlock as i, createElementVNode as a, createVNode as o, mergeProps as s, openBlock as c, toDisplayString as l, withCtx as u } from "vue";
//#region src/components/AppBarButton.vue
var d = [
	"disabled",
	"tabindex",
	"aria-label",
	"aria-pressed",
	"aria-haspopup",
	"aria-expanded",
	"role",
	"aria-checked",
	"data-application-view-state",
	"data-visual-state",
	"data-label-position"
], f = { class: "appbar-button-content-root" }, p = {
	key: 0,
	class: "appbar-toggle-check-glyph",
	"aria-hidden": "true"
}, m = { class: "appbar-button-label" }, h = { class: "appbar-button-overflow-label" }, g = { class: "appbar-button-accelerator-label" }, _ = {
	key: 1,
	class: "appbar-button-chevron",
	"aria-hidden": "true"
}, v = {
	key: 2,
	class: "appbar-button-overflow-chevron",
	"aria-hidden": "true"
};
function y(e, t, y, b, x, S) {
	return c(), i(n, null, [b.visible ? (c(), i("button", s({
		key: 0,
		ref: "buttonRef"
	}, b.buttonAttrs, {
		class: ["win-appbar-button", b.buttonClasses],
		style: b.buttonStyle,
		type: "button",
		disabled: !b.enabled,
		tabindex: b.isTabStop ? void 0 : -1,
		"aria-label": b.automationName || b.label || void 0,
		"aria-pressed": b.toggleContext ? b.checked === null ? "mixed" : b.checked : void 0,
		"aria-haspopup": b.hasFlyout ? b.flyoutIsMenu ? "menu" : "dialog" : void 0,
		"aria-expanded": b.hasFlyout ? b.flyoutOpen : void 0,
		role: b.inOverflow ? b.toggleContext ? "menuitemcheckbox" : "menuitem" : void 0,
		"aria-checked": b.inOverflow && b.toggleContext ? b.checked === null ? "mixed" : b.checked : void 0,
		"data-application-view-state": b.applicationViewState,
		"data-visual-state": b.commonState,
		"data-label-position": b.value("LabelPosition"),
		onClick: b.onClick,
		onPointerenter: b.onPointerEnter,
		onPointerleave: b.onPointerLeave,
		onPointerdown: b.onPointerDown,
		onPointermove: b.onPointerMove,
		onPointerup: b.onPointerUp,
		onPointercancel: b.onPointerCancel,
		onLostpointercapture: b.onCaptureLost,
		onKeydown: b.onButtonKeyDown,
		onKeyup: b.onButtonKeyUp,
		onFocus: b.onFocus,
		onBlur: b.onBlur
	}), [t[0] ||= a("span", {
		class: "appbar-button-inner-border",
		"aria-hidden": "true"
	}, null, -1), a("span", f, [
		b.toggleContext ? (c(), i("span", p, "")) : r("", !0),
		o(b.Viewbox, {
			class: "appbar-button-content-viewbox",
			Width: "{x:Bind TemplateSettings.ContentWidth, Mode=OneWay}",
			Height: "{ThemeResource AppBarButtonContentHeight}",
			Stretch: "Uniform",
			HorizontalAlignment: "{x:Bind TemplateSettings.ContentHorizontalAlignment, Mode=OneWay}",
			VerticalAlignment: "{x:Bind TemplateSettings.ContentVerticalAlignment, Mode=OneWay}",
			Margin: "{x:Bind TemplateSettings.ContentMargin, Mode=OneWay}"
		}, {
			default: u(() => [o(b.ContentOutlet)]),
			_: 1
		}),
		a("span", m, l(b.label), 1),
		a("span", h, l(b.label), 1),
		a("span", g, l(b.acceleratorText), 1),
		b.hasFlyout ? (c(), i("span", _, "")) : r("", !0),
		b.hasFlyout ? (c(), i("span", v, "")) : r("", !0)
	])], 16, d)) : r("", !0), o(b.FlyoutOutlet)], 64);
}
var b = /*#__PURE__*/ e(t, [["render", y], ["__file", "AppBarButton.vue"]]);
//#endregion
export { b as default };

//# sourceMappingURL=AppBarButton.vue.js.map