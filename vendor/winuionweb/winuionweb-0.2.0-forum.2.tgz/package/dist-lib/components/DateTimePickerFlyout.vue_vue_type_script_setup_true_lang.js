import { xamlThemeKey as e } from "./brushCore.js";
import { useAcrylicBrushStyle as t } from "./AcrylicBrush.js";
import { resolveXamlHandler as n, resolveXamlValue as r, xamlScopeKey as i } from "./xamlRuntime.js";
import { vAcrylicBrush as ee } from "./acrylicBrushVisual.js";
import { vThemeShadow as te } from "./themeShadowVisual.js";
import ne from "./Grid.vue.js";
import { useI18n as re } from "./i18n/index.js";
import ie from "./FontIcon.vue.js";
import ae from "./Button.vue.js";
import oe from "./ColumnDefinition.vue.js";
import se from "./RowDefinition.vue.js";
import ce from "./PickerColumn.vue.js";
import le from "./Rectangle.vue.js";
import { computed as a, defineComponent as o, getCurrentInstance as ue, nextTick as de, onBeforeUnmount as fe, provide as s, ref as c, watch as pe } from "vue";
//#region src/components/DateTimePickerFlyout.vue?vue&type=script&setup=true&lang.ts
var l = /*@__PURE__*/ o({
	inheritAttrs: !1,
	__name: "DateTimePickerFlyout",
	props: {
		Kind: {
			type: String,
			default: "DatePicker"
		},
		Columns: {
			type: [Array, String],
			default: () => []
		},
		RequestedTheme: {
			type: String,
			default: "Default"
		},
		LightDismissOverlayMode: {
			type: String,
			default: "Auto"
		}
	},
	emits: ["Closed", "SelectionChanged"],
	setup(o, { expose: l, emit: me }) {
		let u = o, d = me, f = ue(), { t: p } = re(), m = c(null), h = c(null), g = c(null), _ = c(null), v = c(!1), y = c(!1), b = c({
			left: 0,
			top: 0,
			width: 296,
			height: 322
		}), x = c(""), S = c({}), C = null, w = null, T = null, E = null, D = null, O = 0, k = !1, A = !1, j = (e) => r(e, f), M = a(() => j(u.Columns) ?? []), N = a(() => String(j(u.Kind))), P = a(() => {
			let e = String(j(u.RequestedTheme)).toLowerCase();
			return e === "dark" || e === "light" ? e : x.value;
		});
		s(e, P);
		let he = a(() => ({
			"win-theme-scope": !0,
			"theme-dark": P.value === "dark",
			"theme-light": P.value === "light"
		})), ge = a(() => ({ background: j(u.LightDismissOverlayMode) === "On" ? `var(--${N.value}LightDismissOverlayBackground)` : "transparent" })), F = t(() => `{ThemeResource ${N.value}FlyoutPresenterBackground}`, f), _e = a(() => ({
			...S.value,
			...F.value,
			"--presenter-border": `var(--${N.value}FlyoutPresenterBorderBrush)`,
			"--presenter-highlight": `var(--${N.value}FlyoutPresenterHighlightFill)`,
			"--picker-selected-foreground": `var(--${N.value}FlyoutPresenterHighlightForegroundColor)`,
			left: `${b.value.left}px`,
			top: `${b.value.top}px`,
			width: `${b.value.width}px`,
			"--picker-columns-height": `${b.value.height - 43}px`
		})), ve = a(() => ({ gridTemplateColumns: M.value.flatMap((e, t) => [t ? "1px" : "", `minmax(0, ${e.weight}fr)`]).filter(Boolean).join(" ") })), I = (e) => ({
			"--picker-item-justify": M.value[e]?.align === "Left" ? "flex-start" : "center",
			"--picker-item-padding-left": M.value[e]?.key === "month" ? "9px" : "0px"
		}), ye = a(() => I(0)), be = a(() => I(1)), xe = a(() => I(2)), Se = a(() => p(N.value === "DatePicker" ? "datePicker.name" : "timePicker.name")), L = (e, t) => {
			d(e, $, t), n(f?.attrs[e], f)?.($, t);
		}, R = (e, t, n) => {
			let r = M.value[e];
			r && y.value && !A && L("SelectionChanged", {
				Key: r.key,
				SelectedIndex: n.SelectedIndex
			});
		}, z = (e, t) => R(0, e, t), B = (e, t) => R(1, e, t), V = (e, t) => R(2, e, t), H = () => {
			let e = [
				h.value,
				g.value,
				_.value
			], t = {};
			for (let [n, r] of M.value.entries()) t[r.key] = e[n]?.GetPendingIndex() ?? r.index;
			A = !0;
			try {
				for (let t of e) t?.Flush();
			} finally {
				A = !1;
			}
			L("SelectionChanged", { Indices: t });
		}, U = () => {
			if (!C) return;
			x.value = C.closest(".theme-light, .theme-dark")?.classList.contains("theme-dark") ? "dark" : "light";
			let e = getComputedStyle(C), t = {};
			for (let n = 0; n < e.length; n += 1) {
				let r = e[n];
				r.startsWith("--") && (t[r] = e.getPropertyValue(r));
			}
			S.value = t;
		}, W = () => {
			if (!C || !v.value) return;
			if (!C.isConnected) {
				q(!1, !1);
				return;
			}
			let e = C.getBoundingClientRect();
			if (e.bottom < 0 || e.top > window.innerHeight) {
				q(!1, !1);
				return;
			}
			let t = Math.min(N.value === "DatePicker" ? 296 : 242, Math.max(0, window.innerWidth - 16)), n = Math.min(398, Math.max(83, window.innerHeight - 16)), r = 1 + (n - 43) / 2;
			b.value = {
				width: t,
				height: n,
				left: Math.max(8, Math.min(e.left + (e.width - t) / 2, window.innerWidth - t - 8)),
				top: Math.max(8, Math.min(e.top + e.height / 2 - r, window.innerHeight - n - 8))
			};
		}, G = () => {
			w?.cancel(), T?.cancel(), w = null, T = null;
		}, K = () => {
			E?.disconnect(), E = null, D?.disconnect(), D = null, window.removeEventListener("resize", W), window.removeEventListener("scroll", W, !0), window.removeEventListener("blur", Z), window.visualViewport?.removeEventListener("resize", W), window.visualViewport?.removeEventListener("scroll", W);
		}, q = async (e, t = !0) => {
			if (!y.value) return;
			e && H(), y.value = !1;
			let n = ++O;
			K(), G(), L("Closed", { Accepted: e });
			let r = m.value, i = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
			if (r?.animate && !i) {
				let e = b.value.height;
				w = r.animate([{ clipPath: "inset(0)" }, { clipPath: `inset(${e * .425}px 0)` }], {
					duration: 167,
					easing: "cubic-bezier(0,0,0,1)",
					fill: "forwards"
				}), T = r.animate([{ opacity: 1 }, { opacity: 0 }], {
					delay: 84,
					duration: 83,
					easing: "linear",
					fill: "forwards"
				}), await w.finished.catch(() => {});
			}
			k || n !== O || (G(), v.value = !1, t && C?.isConnected && !C.hasAttribute("disabled") && C.focus({ preventScroll: !0 }));
		}, J = () => q(!1), Y = () => q(!0), X = () => q(!1), Ce = () => q(!1), Z = () => q(!1, !1), we = (e) => {
			if (e.key === "Escape" || e.key === "Enter") {
				e.preventDefault(), e.stopPropagation(), q(e.key === "Enter");
				return;
			}
			let t = [
				h.value,
				g.value,
				_.value
			].filter(Boolean);
			if (e.key === "ArrowLeft" || e.key === "ArrowRight") {
				let n = t.findIndex((e) => e.ContainsFocus?.());
				if (n >= 0) {
					e.preventDefault();
					let r = (e.key === "ArrowRight" ? 1 : -1) * (getComputedStyle(m.value).direction === "rtl" ? -1 : 1);
					t[Math.max(0, Math.min(t.length - 1, n + r))]?.Focus();
				}
			}
			if (e.key === "Tab") {
				let t = Array.from(m.value.querySelectorAll("[tabindex=\"0\"],button:not([disabled])")).filter((e) => e.getClientRects().length && e.tabIndex >= 0), n = t[0], r = t.at(-1);
				(e.shiftKey && document.activeElement === n || !e.shiftKey && document.activeElement === r) && (e.preventDefault(), (e.shiftKey ? r : n)?.focus({ preventScroll: !0 }));
			}
		}, Te = async (e) => {
			if (k || y.value) return;
			let t = ++O;
			if (C = e, v.value = !0, y.value = !0, U(), W(), await de(), k || t !== O || !y.value) return;
			let n = m.value;
			if (G(), n.animate && !window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
				let e = b.value.height;
				w = n.animate([{ clipPath: `inset(${e * .25}px 0)` }, { clipPath: "inset(-16px)" }], {
					duration: 250,
					easing: "cubic-bezier(0,0,0,1)"
				});
				let t = w;
				t.finished.catch(() => {}).then(() => {
					w === t && (w = null);
				});
			}
			h.value ? h.value.Focus() : n.querySelector(".picker-accept")?.focus({ preventScroll: !0 }), E = new MutationObserver(U);
			for (let t = e; t; t = t.parentElement) E.observe(t, {
				attributes: !0,
				attributeFilter: ["class", "style"]
			});
			D = new ResizeObserver(W), D.observe(e), window.addEventListener("resize", W), window.addEventListener("scroll", W, !0), window.addEventListener("blur", Z), window.visualViewport?.addEventListener("resize", W), window.visualViewport?.addEventListener("scroll", W);
		}, Q = {
			OnAccept: Y,
			OnDismiss: X,
			OnFirstSelectionChanged: z,
			OnSecondSelectionChanged: B,
			OnThirdSelectionChanged: V,
			SpacerFill: a(() => `var(--${N.value}FlyoutPresenterSpacerFill)`),
			AcceptLabel: p("text.accept"),
			DismissLabel: p("text.cancel")
		};
		for (let [e, t] of [
			["First", 0],
			["Second", 1],
			["Third", 2]
		]) for (let [n, r, i] of [
			[
				"Items",
				"items",
				[]
			],
			[
				"Index",
				"index",
				0
			],
			[
				"Loop",
				"loop",
				!0
			],
			[
				"Label",
				"label",
				""
			]
		]) Q[e + n] = a(() => M.value[t]?.[r] ?? i);
		s(i, Q), pe(() => j(u.RequestedTheme), () => {
			y.value && U();
		}), fe(() => {
			k = !0, O += 1, K(), G();
		});
		let $ = {
			ShowAt: Te,
			Hide: J,
			Flush: H,
			IsOpen: y
		};
		l($);
		let Ee = {
			props: u,
			emit: d,
			instance: f,
			t: p,
			presenterRef: m,
			firstRef: h,
			secondRef: g,
			thirdRef: _,
			visible: v,
			isOpen: y,
			position: b,
			inheritedTheme: x,
			resourceOverrides: S,
			get anchor() {
				return C;
			},
			set anchor(e) {
				C = e;
			},
			get animation() {
				return w;
			},
			set animation(e) {
				w = e;
			},
			get fadeAnimation() {
				return T;
			},
			set fadeAnimation(e) {
				T = e;
			},
			get observer() {
				return E;
			},
			set observer(e) {
				E = e;
			},
			get resizeObserver() {
				return D;
			},
			set resizeObserver(e) {
				D = e;
			},
			get revision() {
				return O;
			},
			set revision(e) {
				O = e;
			},
			get disposed() {
				return k;
			},
			set disposed(e) {
				k = e;
			},
			get committing() {
				return A;
			},
			set committing(e) {
				A = e;
			},
			value: j,
			columns: M,
			kind: N,
			theme: P,
			themeClasses: he,
			overlayStyle: ge,
			presenterBackgroundStyle: F,
			presenterStyle: _e,
			columnStyle: ve,
			fieldStyle: I,
			firstStyle: ye,
			secondStyle: be,
			thirdStyle: xe,
			dialogLabel: Se,
			raise: L,
			changed: R,
			OnFirstSelectionChanged: z,
			OnSecondSelectionChanged: B,
			OnThirdSelectionChanged: V,
			Flush: H,
			syncTheme: U,
			reposition: W,
			stopAnimation: G,
			disconnect: K,
			close: q,
			Hide: J,
			OnAccept: Y,
			OnDismiss: X,
			OnLightDismiss: Ce,
			OnWindowBlur: Z,
			OnKeyDown: we,
			ShowAt: Te,
			scope: Q,
			publicApi: $,
			Button: ae,
			ColumnDefinition: oe,
			FontIcon: ie,
			Grid: ne,
			PickerColumn: ce,
			Rectangle: le,
			RowDefinition: se,
			get vAcrylicBrush() {
				return ee;
			},
			get vThemeShadow() {
				return te;
			}
		};
		return Object.defineProperty(Ee, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), Ee;
	}
});
//#endregion
export { l as default };

//# sourceMappingURL=DateTimePickerFlyout.vue_vue_type_script_setup_true_lang.js.map