import { xamlThemeKey as e } from "./brushCore.js";
import { primitiveResourceScope as t, primitiveResourceStyles as n, xamlPrimitiveResourceKey as r } from "./xamlPrimitives.js";
import { normalizeXamlNodes as i, resolveXamlValue as a, xamlNameScopeKey as o } from "./xamlRuntime.js";
import { frameworkLayoutStyle as s } from "./frameworkLayout.js";
import { collectXamlResources as c, useXamlBrushResources as l, xamlResourceKey as u, xamlResourceNodesEqual as d } from "./xamlBrushResources.js";
import { Fragment as f, computed as p, defineComponent as m, getCurrentInstance as h, h as g, inject as _, onBeforeUnmount as v, provide as y, shallowReactive as b, shallowRef as x, unref as S } from "vue";
//#region src/components/Page.vue?vue&type=script&lang.ts
var C = Symbol("WinUIonWeb.xamlResourceDictionary"), w = m({
	name: "Page.Resources",
	__xamlResourceProperty: "resources",
	setup() {
		return () => null;
	}
}), T = (e) => {
	if (Array.isArray(e.children)) return e.children;
	if (e.children && typeof e.children == "object") {
		let t = e.children.default;
		return typeof t == "function" ? t() : [];
	}
	return [];
}, E = (e) => !!e.type?.__xamlResourceProperty, D = new Set([
	"class",
	"style",
	"RequestedTheme",
	"Width",
	"Height",
	"MinWidth",
	"MinHeight",
	"MaxWidth",
	"MaxHeight",
	"Margin",
	"Padding",
	"HorizontalAlignment",
	"VerticalAlignment",
	"Background",
	"BorderBrush",
	"BorderThickness",
	"CornerRadius",
	"Visibility",
	"IsHitTestVisible",
	"Opacity"
]), O = m({
	name: "Page",
	inheritAttrs: !1,
	Resources: w,
	setup(m, { slots: w, attrs: O }) {
		let k = h(), A = _(e, null) ?? _("winuiTheme", null), j = p(() => a(O.RequestedTheme, k));
		y(e, p(() => {
			let e = j.value;
			return e === "Light" || e === "Dark" ? e : S(A);
		}));
		let M = {}, N = t(() => w.default?.() ?? [], _(r, null)), P = t(() => w.default?.() ?? []);
		y(r, N);
		let F = _(o, null) ?? b({}), I = l(k, F), L = /* @__PURE__ */ new Map(), R = (e, t) => {
			let n = t.node.value, r = n.props?.__xamlResourceTheme, i = u(n);
			r ? F[i] === t.value && delete F[i] : F[e] === t.value && delete F[e];
		};
		return v(() => {
			L.forEach((e, t) => {
				e.dispose(), R(t, e);
			}), L.clear();
		}), y(C, M), y(o, F), () => {
			let e = w.default?.() ?? [], t = {};
			for (let n of e) !n || typeof n != "object" || !E(n) || c(T(n), t);
			for (let e of Object.keys(M)) e in t || delete M[e];
			for (let [e, n] of Object.entries(t)) d(M[e], n) || (M[e] = n);
			for (let e of Object.values(t)) if (e.props?.__xamlResourceTheme === "Default") {
				let t = u(e);
				d(M[t], e) || (M[t] = e);
			}
			I.sync(t);
			for (let [e, n] of Object.entries(t)) {
				if (n.type.__xamlBrush || n.type.__xamlDependencyObject) {
					let t = L.get(e);
					t && (t.dispose(), R(e, t), L.delete(e));
					continue;
				}
				let t = n.type.__createXamlResource, r = L.get(e);
				if (r && (r.type !== n.type || r.factory !== t) && (r.dispose(), R(e, r), L.delete(e), r = void 0), !t) continue;
				if (!r) {
					let i = x(n), o = [];
					r = {
						type: n.type,
						factory: t,
						node: i,
						value: t((e) => a(i.value.props?.[e], k), {
							instance: k,
							Node: () => i.value,
							Dispose: (e) => o.push(e)
						}),
						dispose: () => o.forEach((e) => e())
					}, L.set(e, r);
				}
				d(r.node.value, n) || (r.node.value = n);
				let i = n.props?.__xamlResourceTheme, o = u(n);
				i ? i === "Default" && F[o] !== r.value && (F[o] = r.value) : F[e] !== r.value && (F[e] = r.value);
			}
			for (let e of L.keys()) if (!(e in t)) {
				let t = L.get(e);
				t?.dispose(), t && R(e, t), L.delete(e);
			}
			let r = [...i(Object.values(t).filter((e) => ["CommandBarFlyout", "MenuFlyout"].includes(e.type.name ?? "")), k), ...i(e.filter((e) => !(e && typeof e == "object" && E(e))), k)], o = n(P.value), l = Object.fromEntries(Object.entries(O).filter(([e]) => e !== "RequestedTheme")), p = Object.keys(O).some((e) => D.has(e));
			return p || Object.keys(o).length > 0 ? g("div", {
				...l,
				class: [
					"win-page",
					O.class,
					j.value === "Light" ? "win-theme-scope theme-light" : j.value === "Dark" ? "win-theme-scope theme-dark" : void 0
				],
				style: [{
					...p ? {
						display: "grid",
						gridTemplateColumns: "minmax(0, 1fr)"
					} : {},
					minWidth: "0",
					minHeight: "0",
					maxWidth: "100%",
					...o,
					...s(O, k)
				}, O.style]
			}, r) : g(f, r);
		};
	}
});
//#endregion
export { O as default, C as xamlResourceDictionaryKey };

//# sourceMappingURL=Page.vue_vue_type_script_lang.js.map