import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./Ellipse.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                            */
import { createBlock as n, createCommentVNode as r, createElementBlock as i, mergeProps as a, openBlock as o, withDirectives as s } from "vue";
//#region src/components/Ellipse.vue
function c(e, t, c, l, u, d) {
	return s((o(), i("div", a({
		ref: "root",
		class: ["win-ellipse", l.attrs.class],
		style: l.ellipseStyle
	}, l.forwardedAttrs), [l.imageBrush ? (o(), n(l.Image, {
		key: 0,
		class: "win-ellipse-image-fill",
		Source: "{x:Bind EllipseFill.Source, Mode=OneWay}",
		Stretch: "{x:Bind EllipseFill.Stretch, Mode=OneWay}",
		Width: "{x:Bind EllipseFill.Width, Mode=OneWay}",
		Height: "{x:Bind EllipseFill.Height, Mode=OneWay}",
		IsHitTestVisible: "False",
		"AutomationProperties.AccessibilityView": "Raw",
		"aria-hidden": "true"
	})) : r("", !0)], 16)), [[l.vAcrylicBrush, l.ellipseStyle]]);
}
var l = /*#__PURE__*/ e(t, [
	["render", c],
	["__scopeId", "data-v-8e669a67"],
	["__file", "Ellipse.vue"]
]);
//#endregion
export { l as default };

//# sourceMappingURL=Ellipse.vue.js.map