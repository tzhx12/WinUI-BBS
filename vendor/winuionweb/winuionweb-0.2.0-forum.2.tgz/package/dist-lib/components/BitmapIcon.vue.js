import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./BitmapIcon.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                               */
import { createCommentVNode as n, createElementBlock as r, createVNode as i, mergeProps as a, normalizeStyle as o, openBlock as s, withCtx as c } from "vue";
//#region src/components/BitmapIcon.vue
var l = ["src"];
function u(e, t, u, d, f, p) {
	return s(), r("span", a({ ref: "Element" }, d.rootAttrs, {
		class: ["win-icon-element win-bitmap-icon", d.attrs.class],
		style: [d.attrs.style, d.iconStyle]
	}), [i(d.Grid, {
		class: "win-icon-grid",
		"data-icon-part": "LayoutRoot",
		Background: "Transparent"
	}, {
		default: c(() => [d.loaded && d.monochrome ? (s(), r("span", {
			key: 0,
			class: "win-bitmap-icon-image win-bitmap-icon-mask",
			"data-icon-part": "Image",
			style: o(d.maskStyle),
			"aria-hidden": "true"
		}, null, 4)) : d.loaded ? (s(), r("img", {
			key: 1,
			class: "win-bitmap-icon-image",
			"data-icon-part": "Image",
			src: d.source,
			alt: "",
			draggable: "false",
			"aria-hidden": "true"
		}, null, 8, l)) : n("", !0)]),
		_: 1
	})], 16);
}
var d = /*#__PURE__*/ e(t, [
	["render", u],
	["__scopeId", "data-v-04ea2c43"],
	["__file", "BitmapIcon.vue"]
]);
//#endregion
export { d as default };

//# sourceMappingURL=BitmapIcon.vue.js.map