import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./RowDefinition.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                                  */
import { createElementBlock as n, openBlock as r } from "vue";
//#region src/components/RowDefinition.vue
var i = {
	class: "win-definition",
	"aria-hidden": "true"
};
function a(e, t, a, o, s, c) {
	return r(), n("span", i);
}
var o = /*#__PURE__*/ e(t, [
	["render", a],
	["__scopeId", "data-v-b62e34a3"],
	["__file", "RowDefinition.vue"]
]);
//#endregion
export { o as default };

//# sourceMappingURL=RowDefinition.vue.js.map