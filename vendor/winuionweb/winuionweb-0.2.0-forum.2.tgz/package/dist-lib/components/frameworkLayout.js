import { alignment as e, cssLength as t, xamlThickness as n } from "./layout.js";
import { resolveBrushStyle as r } from "./AcrylicBrush.js";
import { resolveXamlValue as i } from "./xamlRuntime.js";
//#region src/components/frameworkLayout.ts
var a = (a, o) => {
	let s = (e) => i(e, o), c = {}, l = {
		Width: "width",
		Height: "height",
		MinWidth: "minWidth",
		MinHeight: "minHeight",
		MaxWidth: "maxWidth",
		MaxHeight: "maxHeight"
	};
	for (let e of Object.keys(l)) {
		let n = s(a[e]);
		n == null || n === "" || n === "Auto" || Number.isNaN(n) || (c[l[e]] = t(n), e === "Width" && (c.flex = "0 0 auto"));
	}
	let u = {
		Margin: "margin",
		Padding: "padding",
		BorderThickness: "borderWidth"
	};
	for (let e of Object.keys(u)) {
		let t = s(a[e]);
		t != null && t !== "" && (c[u[e]] = n(t));
	}
	for (let [e, t] of [["Background", "background"], ["BorderBrush", "borderColor"]]) {
		let n = s(a[e]);
		n != null && n !== "" && (e === "Background" ? Object.assign(c, r(n, o)) : c[t] = String(n));
	}
	let d = s(a.CornerRadius);
	d != null && d !== "" && (c.borderRadius = String(d).split(",").map((e) => t(e.trim())).join(" "));
	let f = s(a.HorizontalAlignment), p = s(a.VerticalAlignment);
	f && (c.justifySelf = e(f, "horizontal")), p && (c.alignSelf = e(p, "vertical")), s(a.Visibility) === "Collapsed" && (c.display = "none"), s(a.IsHitTestVisible) === !1 && (c.pointerEvents = "none");
	let m = s(a.Opacity);
	return m !== void 0 && m !== "" && (c.opacity = String(m)), s(a.BackgroundSizing) === "InnerBorderEdge" && (c.backgroundClip = "padding-box"), c;
};
//#endregion
export { a as frameworkLayoutStyle };

//# sourceMappingURL=frameworkLayout.js.map