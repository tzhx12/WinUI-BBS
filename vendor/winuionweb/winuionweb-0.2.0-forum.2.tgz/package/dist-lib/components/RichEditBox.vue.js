import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./RichEditBox.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                */
import { Fragment as n, createBlock as r, createCommentVNode as i, createElementBlock as a, createVNode as o, mergeProps as s, openBlock as c, withCtx as l } from "vue";
//#region src/components/RichEditBox.vue
function u(e, t, u, d, f, p) {
	return c(), a(n, null, [
		o(d.TextBox, s(d.forwardedAttrs, {
			class: "win-rich-edit-box",
			Header: "{x:Bind RichInput.Header, Mode=OneWay}",
			HeaderTemplate: "{x:Bind RichInputHeaderTemplate, Mode=OneWay}",
			Description: "{x:Bind RichInput.Description, Mode=OneWay}",
			AcceptsReturn: "{x:Bind RichInput.AcceptsReturn, Mode=OneWay}",
			IsReadOnly: "{x:Bind RichInput.IsReadOnly, Mode=OneWay}",
			IsEnabled: "{x:Bind RichInput.IsEnabled, Mode=OneWay}",
			MaxLength: "{x:Bind RichInput.MaxLength, Mode=OneWay}",
			FontFamily: "{x:Bind RichInput.FontFamily, Mode=OneWay}",
			FontSize: "{x:Bind RichInput.FontSize, Mode=OneWay}",
			FontWeight: "{x:Bind RichInput.FontWeight, Mode=OneWay}",
			FontStyle: "{x:Bind RichInput.FontStyle, Mode=OneWay}",
			TextWrapping: "{x:Bind RichInput.TextWrapping, Mode=OneWay}",
			TextAlignment: "{x:Bind RichInput.TextAlignment, Mode=OneWay}",
			IsSpellCheckEnabled: "{x:Bind RichInput.IsSpellCheckEnabled, Mode=OneWay}",
			IsTextPredictionEnabled: "{x:Bind RichInput.IsTextPredictionEnabled, Mode=OneWay}",
			InputScope: "{x:Bind RichInput.InputScope, Mode=OneWay}",
			CharacterCasing: "{x:Bind RichInput.CharacterCasing, Mode=OneWay}",
			SelectionHighlightColor: "{x:Bind RichInput.SelectionHighlightColor, Mode=OneWay}",
			PreventKeyboardDisplayOnProgrammaticFocus: "{x:Bind RichInput.PreventKeyboardDisplayOnProgrammaticFocus, Mode=OneWay}",
			Width: "{x:Bind RichInput.Width, Mode=OneWay}",
			Height: "{x:Bind RichInput.Height, Mode=OneWay}",
			MinHeight: "{x:Bind RichInput.MinHeight, Mode=OneWay}"
		}), {
			default: l(() => [
				d.headerPropertyNodes.length ? (c(), r(d.TextBox.Header, { key: 0 }, {
					default: l(() => [o(d.HeaderPropertyOutlet)]),
					_: 1
				})) : i("", !0),
				d.descriptionPropertyNodes.length ? (c(), r(d.TextBox.Description, { key: 1 }, {
					default: l(() => [o(d.DescriptionPropertyOutlet)]),
					_: 1
				})) : i("", !0),
				d.backgroundPropertyNodes.length ? (c(), r(d.TextBox.Background, { key: 2 }, {
					default: l(() => [o(d.BackgroundPropertyOutlet)]),
					_: 1
				})) : i("", !0)
			]),
			_: 1
		}, 16),
		o(d.TextCommandFlyoutOutlet),
		o(d.ContextFlyoutOutlet),
		o(d.SelectionFlyoutOutlet)
	], 64);
}
var d = /*#__PURE__*/ e(t, [["render", u], ["__file", "RichEditBox.vue"]]);
//#endregion
export { d as default };

//# sourceMappingURL=RichEditBox.vue.js.map