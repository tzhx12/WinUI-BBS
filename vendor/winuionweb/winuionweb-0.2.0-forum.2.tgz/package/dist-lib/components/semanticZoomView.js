import { computed as e, ref as t, shallowRef as n, toRaw as r } from "vue";
//#region src/components/semanticZoomView.ts
var i = (e, t) => r(e) === r(t), a = (e) => e?.Group ?? e, o = (e) => e?.Items ?? e?.GroupItems ?? [], s = (r, s, c, l) => {
	let u = n(null), d = t(!0), f = t(l), p = () => Array.from(r.value?.querySelectorAll(f.value ? "[role=\"gridcell\"]" : ".win-list-item") ?? []), m = 0, h = (e) => {
		let t = p(), n = r.value?.querySelector(".win-scroll-viewer-viewport")?.getBoundingClientRect();
		if (e) {
			let r = -1, i = Infinity;
			if (t.forEach((t, a) => {
				let o = t.getBoundingClientRect();
				if (n && (o.bottom <= n.top || o.top >= n.bottom || o.right <= n.left || o.left >= n.right)) return;
				let s = Math.max(o.left - e.X, 0, e.X - o.right), c = Math.max(o.top - e.Y, 0, e.Y - o.bottom);
				s * s + c * c < i && (r = a, i = s * s + c * c);
			}), r >= 0) return s()[r];
		}
		let i = t.findIndex((e) => e.contains(document.activeElement)), a = t.findIndex((e) => {
			let t = e.getBoundingClientRect();
			return !n || t.bottom > n.top && t.top < n.bottom;
		});
		return i >= 0 && (m = i), s()[i >= 0 ? i : Math.max(0, a)];
	}, g = (e) => c().find((t) => i(a(t), a(e)) || o(t).some((t) => i(t, e))) ?? a(e), _ = (e) => s().findIndex((t) => i(t, e) || i(a(t), a(e)));
	return {
		SemanticZoomOwner: u,
		IsActiveView: d,
		IsZoomedInView: f,
		InitializeViewChange() {
			r.value?.classList.add("semantic-zoom-view-changing"), h();
		},
		StartViewChangeFrom(e, t) {
			e.Item ??= h(e.ZoomPoint) ?? null, t.Item = f.value ? g(e.Item) : o(a(e.Item))[0] ?? a(e.Item);
			let n = p()[_(e.Item)]?.getBoundingClientRect(), i = r.value?.getBoundingClientRect();
			n && i && (e.Bounds = {
				X: n.left - i.left,
				Y: n.top - i.top,
				Width: n.width,
				Height: n.height
			});
		},
		StartViewChangeTo(e, t) {
			t.Item = f.value ? o(g(e.Item))[0] ?? t.Item : s().find((e) => i(a(e), a(t.Item))) ?? t.Item;
		},
		MakeVisible: (e) => {
			let t = _(e.Item), n = p()[Math.max(0, t)], i = r.value?.querySelector(".win-scroll-viewer-viewport");
			if (!n || !i) return;
			let a = (f.value ? n.closest(".win-grid-group") ?? n : n).getBoundingClientRect(), o = i.getBoundingClientRect(), s = o.height / Math.max(1, i.clientHeight);
			i.scrollTop = Math.max(0, Math.min(i.scrollHeight - i.clientHeight, i.scrollTop + (a.top - o.top) / Math.max(.001, s)));
			let c = n.getBoundingClientRect();
			e.Bounds = {
				X: (c.left - o.left) / s,
				Y: (c.top - o.top) / s,
				Width: c.width / s,
				Height: c.height / s
			};
		},
		CompleteViewChangeFrom(e, t) {},
		CompleteViewChangeTo(e, t) {
			if (u.value?.HasFocus?.() === !1) return;
			let n = _(t.Item);
			n < 0 && f.value && (n = _(o(g(t.Item))[0])), (p()[n < 0 ? m : n] ?? p()[0] ?? r.value)?.focus({ preventScroll: !0 }), n >= 0 && (m = n);
		},
		CompleteViewChange() {
			r.value?.classList.remove("semantic-zoom-view-changing");
		},
		CanHorizontallyScroll: e(() => {
			let e = r.value?.querySelector(".win-scroll-viewer-viewport");
			return !!e && e.scrollWidth > e.clientWidth;
		}),
		CanVerticallyScroll: e(() => {
			let e = r.value?.querySelector(".win-scroll-viewer-viewport");
			return !!e && e.scrollHeight > e.clientHeight;
		})
	};
};
//#endregion
export { s as createSemanticZoomView };

//# sourceMappingURL=semanticZoomView.js.map