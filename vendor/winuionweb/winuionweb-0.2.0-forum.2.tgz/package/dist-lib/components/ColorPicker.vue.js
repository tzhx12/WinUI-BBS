import { resolveXamlHandler as e, resolveXamlValue as t, updateXamlBinding as n, xamlScopeKey as r } from "./xamlRuntime.js";
import i from "../_virtual/_plugin-vue_export-helper.js";
import { useI18n as a } from "./i18n/index.js";
import o from "./TextBlock.vue.js";
import s from "./FontIcon.vue.js";
import c from "./TextBox.vue.js";
import l from "./Button.vue.js";
import u from "./ComboBox.vue.js";
import ee from "./NumberBox.vue.js";
import te from "./ToolTip.vue.js";
/* empty css                                                */
import { Fragment as d, computed as f, createBlock as ne, createCommentVNode as p, createElementBlock as m, createElementVNode as h, createVNode as g, getCurrentInstance as re, nextTick as _, normalizeClass as v, normalizeStyle as y, onMounted as ie, openBlock as b, provide as ae, reactive as oe, ref as x, unref as se, useAttrs as ce, watch as S, withCtx as C } from "vue";
//#region src/components/ColorPicker.vue
var w = 256, T = {
	__name: "ColorPicker",
	props: {
		Color: {
			type: [String, Object],
			default: void 0
		},
		ColorSpectrumShape: {
			type: [String, Number],
			default: void 0
		},
		IsMoreButtonVisible: {
			type: [Boolean, String],
			default: !1
		},
		IsColorPreviewVisible: {
			type: [Boolean, String],
			default: void 0
		},
		IsColorSliderVisible: {
			type: [Boolean, String],
			default: void 0
		},
		IsColorChannelTextInputVisible: {
			type: [Boolean, String],
			default: void 0
		},
		IsHexInputVisible: {
			type: [Boolean, String],
			default: void 0
		},
		IsAlphaEnabled: {
			type: [Boolean, String],
			default: void 0
		},
		IsAlphaSliderVisible: {
			type: [Boolean, String],
			default: void 0
		},
		IsAlphaTextInputVisible: {
			type: [Boolean, String],
			default: void 0
		},
		modelValue: {
			type: String,
			default: "#0067C0"
		},
		isColorPreviewVisible: {
			type: Boolean,
			default: !0
		},
		isColorSliderVisible: {
			type: Boolean,
			default: !0
		},
		isColorChannelTextInputVisible: {
			type: Boolean,
			default: !0
		},
		isHexInputVisible: {
			type: Boolean,
			default: !0
		},
		isAlphaEnabled: {
			type: Boolean,
			default: !1
		},
		isAlphaSliderVisible: {
			type: Boolean,
			default: !0
		},
		previousColor: {
			type: String,
			default: null
		},
		colorSpectrumShape: {
			type: String,
			default: "Box"
		}
	},
	emits: [
		"update:modelValue",
		"update:Color",
		"ColorChanged"
	],
	setup(i, { expose: d, emit: ne }) {
		d();
		let { t: p } = a(), m = re(), h = ce(), g = i, v = ne, y = x(null), b = x(null), C = x(null), T = x(null), E = x(null), D = oe({
			h: 0,
			s: 1,
			v: 1
		}), O = x(1), k = x(!1), A = x(""), j = x(0), M = f(() => String(t(g.Color, m) ?? g.modelValue ?? "#0067C0")), N = x(M.value), P = !1, F = !1, I = !1, L = x(!1), R = (e, n) => {
			let r = t(e, m);
			return r === void 0 ? n : r === !0;
		}, le = f(() => R(g.IsMoreButtonVisible, !1)), z = f(() => String(t(g.ColorSpectrumShape, m) ?? g.colorSpectrumShape)), ue = f(() => R(g.IsColorPreviewVisible, g.isColorPreviewVisible)), de = f(() => R(g.IsColorSliderVisible, g.isColorSliderVisible)), fe = f(() => R(g.IsColorChannelTextInputVisible, g.isColorChannelTextInputVisible)), pe = f(() => R(g.IsHexInputVisible, g.isHexInputVisible)), B = f(() => R(g.IsAlphaEnabled, g.isAlphaEnabled)), me = f(() => R(g.IsAlphaSliderVisible, g.isAlphaSliderVisible)), he = f(() => R(g.IsAlphaTextInputVisible, g.isAlphaTextInputVisible)), ge = f(() => !le.value || k.value), _e = f(() => [p("control.colorpicker.rgb"), p("control.colorpicker.hsv")]), ve = f(() => j.value === 1 ? "HSV" : "RGB"), V = f(() => z.value === "Ring"), ye = f(() => k.value ? "" : ""), H = f(() => {
			let { r: e, g: t, b: n } = K(D.h, D.s, D.v);
			return {
				r: e,
				g: t,
				b: n
			};
		}), U = f(() => {
			let { r: e, g: t, b: n } = H.value, r = "#" + [
				e,
				t,
				n
			].map((e) => e.toString(16).padStart(2, "0")).join("");
			return B.value && O.value < 1 ? r + Math.round(O.value * 255).toString(16).padStart(2, "0") : r;
		}), W = f(() => U.value.toUpperCase()), G = f(() => W.value), be = () => {
			k.value = !k.value;
		};
		ae(r, {
			spectrumToolTipOpen: L,
			spectrumToolTipContent: G,
			spectrumThumbRef: b,
			OnMoreButtonClick: be,
			colorModelItems: _e,
			selectedColorModelIndex: j
		});
		let xe = f(() => Math.round(O.value * 100)), Se = f(() => Math.round(D.h) % 360), Ce = f(() => Math.round(D.s * 100)), we = f(() => Math.round(D.v * 100)), Te = f(() => `linear-gradient(to right, rgb(0,0,0), ${De(D.h, D.s, 1)})`), Ee = f(() => {
			D.v > .6 && D.s;
			let e = D.v > .5 && D.s < .5 ? "rgba(0,0,0,0.8)" : "rgba(255,255,255,0.9)";
			if (V.value) {
				let t = w / 2, n = w / 2, r = w / 2 - 2, i = (D.h - 90) * Math.PI / 180, a = D.s * r, o = t + Math.cos(i) * a, s = n + Math.sin(i) * a;
				return {
					left: o + "px",
					top: s + "px",
					"--spectrum-thumb-color": e
				};
			}
			let t = D.h / 360 * w, n = (1 - D.s) * w;
			return {
				left: t + "px",
				top: n + "px",
				"--spectrum-thumb-color": e
			};
		});
		function K(e, t, n) {
			let r, i, a, o = Math.floor(e / 60) % 6, s = e / 60 - Math.floor(e / 60), c = n * (1 - t), l = n * (1 - s * t), u = n * (1 - (1 - s) * t);
			switch (o) {
				case 0:
					r = n, i = u, a = c;
					break;
				case 1:
					r = l, i = n, a = c;
					break;
				case 2:
					r = c, i = n, a = u;
					break;
				case 3:
					r = c, i = l, a = n;
					break;
				case 4:
					r = u, i = c, a = n;
					break;
				case 5:
					r = n, i = c, a = l;
					break;
			}
			return {
				r: Math.round(r * 255),
				g: Math.round(i * 255),
				b: Math.round(a * 255)
			};
		}
		function De(e, t, n) {
			let { r, g: i, b: a } = K(e, t, n);
			return `rgb(${r},${i},${a})`;
		}
		function q(e, t, n) {
			e /= 255, t /= 255, n /= 255;
			let r = Math.max(e, t, n), i = r - Math.min(e, t, n), a = 0, o = r === 0 ? 0 : i / r, s = r;
			if (i !== 0) switch (r) {
				case e:
					a = ((t - n) / i + (t < n ? 6 : 0)) * 60;
					break;
				case t:
					a = ((n - e) / i + 2) * 60;
					break;
				case n:
					a = ((e - t) / i + 4) * 60;
					break;
			}
			return {
				h: a,
				s: o,
				v: s
			};
		}
		function J(e) {
			let t = String(e ?? "#0067C0").replace("#", "");
			t.length === 3 && (t = t.split("").map((e) => e + e).join(""));
			let n = parseInt(t.slice(0, 2), 16) || 0, r = parseInt(t.slice(2, 4), 16) || 0, i = parseInt(t.slice(4, 6), 16) || 0, a = 1;
			return t.length === 8 && (a = (parseInt(t.slice(6, 8), 16) || 0) / 255), {
				r: n,
				g: r,
				b: i,
				a
			};
		}
		function Y() {
			let e = y.value;
			if (!e) return;
			let t = e.getContext("2d"), n = w, r = w;
			t.clearRect(0, 0, n, r), V.value ? ke(t, n, r) : Oe(t, n, r);
		}
		function Oe(e, t, n) {
			let r = e.createImageData(t, n), i = r.data;
			for (let e = 0; e < n; e++) {
				let r = 1 - e / (n - 1);
				for (let n = 0; n < t; n++) {
					let { r: a, g: o, b: s } = K(n / (t - 1) * 360, r, D.v), c = (e * t + n) * 4;
					i[c] = a, i[c + 1] = o, i[c + 2] = s, i[c + 3] = 255;
				}
			}
			e.putImageData(r, 0, 0);
		}
		function ke(e, t, n) {
			let r = t / 2, i = n / 2, a = t / 2 - 1, o = e.createImageData(t, n), s = o.data;
			for (let e = 0; e < n; e++) for (let n = 0; n < t; n++) {
				let o = n - r, c = e - i, l = Math.sqrt(o * o + c * c), u = (e * t + n) * 4;
				if (l <= a) {
					let e = Math.atan2(c, o) * 180 / Math.PI + 90;
					e < 0 && (e += 360);
					let t = Math.min(1, l / a), { r: n, g: r, b: i } = K(e % 360, t, D.v);
					s[u] = n, s[u + 1] = r, s[u + 2] = i, s[u + 3] = 255;
				} else s[u + 3] = 0;
			}
			e.putImageData(o, 0, 0);
		}
		function X() {
			let t = {
				OldColor: N.value,
				NewColor: U.value
			};
			v("update:modelValue", U.value), v("update:Color", U.value), n(g.Color, U.value, m), v("ColorChanged", t), e(h.ColorChanged, m)?.(t), N.value = U.value;
		}
		S(W, (e) => {
			A.value = e;
		}, { immediate: !0 });
		function Ae(e) {
			P = !0, e.currentTarget.focus?.({ preventScroll: !0 }), e.currentTarget.setPointerCapture(e.pointerId), Z(e), L.value = !0;
		}
		function je(e) {
			P && Z(e);
		}
		function Me(e) {
			P = !1, e.currentTarget.hasPointerCapture?.(e.pointerId) && e.currentTarget.releasePointerCapture(e.pointerId);
		}
		function Ne(e) {
			P = !1, e.currentTarget.hasPointerCapture?.(e.pointerId) && e.currentTarget.releasePointerCapture(e.pointerId);
		}
		function Pe() {
			L.value = !0;
		}
		function Fe() {
			P = !1, L.value = !1;
		}
		function Z(e) {
			let t = y.value.getBoundingClientRect(), n = e.clientX - t.left, r = e.clientY - t.top;
			if (V.value) {
				let e = w / 2, t = w / 2, i = w / 2 - 2, a = n - e, o = r - t, s = Math.atan2(o, a) * 180 / Math.PI + 90;
				s < 0 && (s += 360);
				let c = Math.min(i, Math.sqrt(a * a + o * o));
				D.h = s % 360, D.s = c / i;
			} else {
				let e = Math.max(0, Math.min(w - 1, n)), t = Math.max(0, Math.min(w - 1, r));
				D.h = e / (w - 1) * 360, D.s = 1 - t / (w - 1);
			}
			X();
		}
		function Ie(e) {
			F = !0, e.currentTarget.setPointerCapture(e.pointerId), Q(e);
			let t = e.currentTarget;
			t.onpointermove = (e) => {
				F && Q(e);
			}, t.onpointerup = () => {
				F = !1, t.onpointermove = null;
			};
		}
		function Q(e) {
			let t = T.value.getBoundingClientRect();
			D.v = Math.max(0, Math.min(t.width, e.clientX - t.left)) / t.width, Y(), X();
		}
		function Le(e) {
			I = !0, e.currentTarget.setPointerCapture(e.pointerId), $(e);
			let t = e.currentTarget;
			t.onpointermove = (e) => {
				I && $(e);
			}, t.onpointerup = () => {
				I = !1, t.onpointermove = null;
			};
		}
		function $(e) {
			let t = E.value.getBoundingClientRect();
			O.value = Math.max(0, Math.min(t.width, e.clientX - t.left)) / t.width, X();
		}
		function Re(e, t) {
			let n = parseInt(t) || 0;
			n = Math.max(0, Math.min(255, n));
			let r = q(e === "r" ? n : H.value.r, e === "g" ? n : H.value.g, e === "b" ? n : H.value.b);
			D.h = r.h, D.s = r.s, D.v = r.v, Y(), X();
		}
		function ze(e, t) {
			Re(e, t);
		}
		function Be(e, t) {
			let n = Number(t) || 0;
			e === "h" && (D.h = Math.max(0, Math.min(359, n))), e === "s" && (D.s = Math.max(0, Math.min(100, n)) / 100), e === "v" && (D.v = Math.max(0, Math.min(100, n)) / 100), Y(), X();
		}
		function Ve(e) {
			O.value = Math.max(0, Math.min(100, Number(e) || 0)) / 100, X();
		}
		function He(e) {
			A.value = e, e.replace("#", "").trim().length >= 6 && Ue(e);
		}
		function Ue(e) {
			let t = String(e).replace("#", "").trim();
			if (t.length >= 6) {
				let { r: e, g: n, b: r, a: i } = J(t), a = q(e, n, r);
				D.h = a.h, D.s = a.s, D.v = a.v, B.value && (O.value = i), Y(), X();
			}
		}
		function We(e) {
			let { r: t, g: n, b: r, a: i } = J(e), a = q(t, n, r);
			D.h = a.h, D.s = a.s, D.v = a.v, B.value && (O.value = i), _(() => Y());
		}
		S(M, (e) => {
			e && e.toLowerCase() !== U.value.toLowerCase() && (We(e), N.value = e);
		}), S(z, () => {
			_(() => Y());
		}), S(() => D.v, () => {}), S([G, Ee], () => {
			L.value && _(() => C.value?.updatePosition?.());
		}, { deep: !0 }), ie(() => {
			We(M.value), N.value = M.value;
		});
		let Ge = {
			t: p,
			instance: m,
			attrs: h,
			props: g,
			emit: v,
			spectrumSize: w,
			spectrumCanvas: y,
			spectrumThumbRef: b,
			spectrumToolTipRef: C,
			valueTrack: T,
			alphaTrack: E,
			hsv: D,
			alpha: O,
			moreExpanded: k,
			hexInputText: A,
			selectedColorModelIndex: j,
			resolvedColor: M,
			lastEmittedColor: N,
			get draggingSpectrum() {
				return P;
			},
			set draggingSpectrum(e) {
				P = e;
			},
			get draggingValue() {
				return F;
			},
			set draggingValue(e) {
				F = e;
			},
			get draggingAlpha() {
				return I;
			},
			set draggingAlpha(e) {
				I = e;
			},
			spectrumToolTipOpen: L,
			boolValue: R,
			IsMoreButtonVisible: le,
			ColorSpectrumShape: z,
			IsColorPreviewVisible: ue,
			IsColorSliderVisible: de,
			IsColorChannelTextInputVisible: fe,
			IsHexInputVisible: pe,
			IsAlphaEnabled: B,
			IsAlphaSliderVisible: me,
			IsAlphaTextInputVisible: he,
			detailsVisible: ge,
			colorModelItems: _e,
			selectedColorModel: ve,
			isRing: V,
			moreGlyph: ye,
			rgb: H,
			currentHex: U,
			hexDisplay: W,
			spectrumToolTipContent: G,
			OnMoreButtonClick: be,
			opacityPercent: xe,
			hsvHue: Se,
			hsvSaturation: Ce,
			hsvValue: we,
			valueGradient: Te,
			spectrumThumbStyle: Ee,
			hsvToRgb: K,
			hsvToRgbStr: De,
			rgbToHsv: q,
			parseColor: J,
			drawSpectrum: Y,
			drawBoxSpectrum: Oe,
			drawRingSpectrum: ke,
			emitColor: X,
			onSpectrumDown: Ae,
			onSpectrumMove: je,
			onSpectrumUp: Me,
			onSpectrumCancel: Ne,
			onSpectrumFocus: Pe,
			onSpectrumBlur: Fe,
			updateSpectrumFromEvent: Z,
			onValueDown: Ie,
			updateValueFromEvent: Q,
			onAlphaDown: Le,
			updateAlphaFromEvent: $,
			applyRgbValue: Re,
			onRgbValueInput: ze,
			onHsvValueInput: Be,
			onOpacityInput: Ve,
			onHexTextChanged: He,
			onHexInput: Ue,
			syncFromProp: We,
			ButtonContent1: f(() => p("text.more")),
			ButtonContentComputed: f,
			ButtonContentUnref: se,
			FontIcon: s,
			ref: x,
			reactive: oe,
			computed: f,
			watch: S,
			onMounted: ie,
			nextTick: _,
			getCurrentInstance: re,
			provide: ae,
			useAttrs: ce,
			Button: l,
			ComboBox: u,
			NumberBox: ee,
			TextBlock: o,
			TextBox: c,
			ToolTip: te,
			get useI18n() {
				return a;
			},
			get resolveXamlHandler() {
				return e;
			},
			get resolveXamlValue() {
				return t;
			},
			get updateXamlBinding() {
				return n;
			},
			get xamlScopeKey() {
				return r;
			}
		};
		return Object.defineProperty(Ge, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), Ge;
	}
}, E = { class: "cp-spectrum-grid" }, D = {
	key: 0,
	class: "cp-preview-bar"
}, O = {
	key: 0,
	class: "cp-sliders"
}, k = {
	key: 1,
	class: "cp-more-row"
}, A = {
	key: 2,
	class: "cp-details-grid"
};
function j(e, t, n, r, i, a) {
	return b(), m("div", { class: v(["win-color-picker", {
		"cp-has-preview": r.IsColorPreviewVisible,
		"cp-no-preview": !r.IsColorPreviewVisible
	}]) }, [
		h("div", E, [h("div", { class: v(["cp-spectrum-area", { "cp-ring": r.isRing }]) }, [h("canvas", {
			ref: "spectrumCanvas",
			class: "cp-spectrum",
			width: r.spectrumSize,
			height: r.spectrumSize,
			tabindex: "0",
			onPointerdown: r.onSpectrumDown,
			onPointermove: r.onSpectrumMove,
			onPointerup: r.onSpectrumUp,
			onPointercancel: r.onSpectrumCancel,
			onFocus: r.onSpectrumFocus,
			onBlur: r.onSpectrumBlur
		}, null, 544), h("div", {
			ref: "spectrumThumbRef",
			class: "cp-spectrum-thumb",
			style: y(r.spectrumThumbStyle)
		}, null, 4)], 2), r.IsColorPreviewVisible ? (b(), m("div", D, [h("div", {
			class: "cp-preview-current",
			style: y({ background: r.currentHex })
		}, null, 4), n.previousColor ? (b(), m("div", {
			key: 0,
			class: "cp-preview-previous",
			style: y({ background: n.previousColor })
		}, null, 4)) : p("", !0)])) : p("", !0)]),
		r.IsColorSliderVisible ? (b(), m("div", O, [h("div", {
			class: "cp-slider-row",
			onPointerdown: r.onValueDown
		}, [h("div", {
			class: "cp-value-track",
			ref: "valueTrack",
			style: y({ background: r.valueGradient })
		}, [h("div", {
			class: "cp-slider-thumb",
			style: y({ left: r.hsv.v * 100 + "%" })
		}, null, 4)], 4)], 32), r.IsAlphaEnabled && r.IsAlphaSliderVisible ? (b(), m("div", {
			key: 0,
			class: "cp-slider-row",
			onPointerdown: r.onAlphaDown
		}, [h("div", {
			class: "cp-alpha-track",
			ref: "alphaTrack",
			style: y({ "--alpha-color": r.hsvToRgbStr(r.hsv.h, r.hsv.s, 1) })
		}, [h("div", {
			class: "cp-slider-thumb",
			style: y({ left: r.alpha * 100 + "%" })
		}, null, 4)], 4)], 32)) : p("", !0)])) : p("", !0),
		r.IsMoreButtonVisible ? (b(), m("div", k, [g(r.Button, {
			class: "cp-more-button",
			Style: "{StaticResource SubtleButtonStyle}",
			Click: "OnMoreButtonClick"
		}, {
			default: C(() => [g(r.TextBlock, {
				class: "cp-more-label",
				Text: "{x:Bind ButtonContent1, Mode=OneWay}"
			}), g(r.FontIcon, {
				class: "icon",
				Glyph: "{x:Bind moreGlyph, Mode=OneWay}"
			})]),
			_: 1
		})])) : p("", !0),
		r.detailsVisible ? (b(), m("div", A, [
			g(r.ComboBox, {
				Width: "120",
				ItemsSource: "{x:Bind colorModelItems, Mode=OneWay}",
				SelectedIndex: "{x:Bind selectedColorModelIndex, Mode=TwoWay}"
			}),
			r.IsHexInputVisible ? (b(), ne(r.TextBox, {
				key: 0,
				class: "cp-hex-box",
				Text: r.hexInputText,
				MaxWidth: 132,
				MaxLength: r.IsAlphaEnabled ? 9 : 7,
				"onUpdate:Text": r.onHexTextChanged
			}, null, 8, ["Text", "MaxLength"])) : p("", !0),
			r.IsColorChannelTextInputVisible && r.selectedColorModel === "RGB" ? (b(), m(d, { key: 1 }, [
				g(r.NumberBox, {
					Width: "120",
					Value: r.rgb.r,
					Minimum: 0,
					Maximum: 255,
					"onUpdate:Value": t[0] ||= (e) => r.onRgbValueInput("r", e)
				}, null, 8, ["Value"]),
				g(r.TextBlock, { Text: r.t("text.red") }, null, 8, ["Text"]),
				g(r.NumberBox, {
					Width: "120",
					Value: r.rgb.g,
					Minimum: 0,
					Maximum: 255,
					"onUpdate:Value": t[1] ||= (e) => r.onRgbValueInput("g", e)
				}, null, 8, ["Value"]),
				g(r.TextBlock, { Text: r.t("text.green") }, null, 8, ["Text"]),
				g(r.NumberBox, {
					Width: "120",
					Value: r.rgb.b,
					Minimum: 0,
					Maximum: 255,
					"onUpdate:Value": t[2] ||= (e) => r.onRgbValueInput("b", e)
				}, null, 8, ["Value"]),
				g(r.TextBlock, { Text: r.t("text.blue") }, null, 8, ["Text"])
			], 64)) : p("", !0),
			r.IsColorChannelTextInputVisible && r.selectedColorModel === "HSV" ? (b(), m(d, { key: 2 }, [
				g(r.NumberBox, {
					Width: "120",
					Value: r.hsvHue,
					Minimum: 0,
					Maximum: 359,
					"onUpdate:Value": t[3] ||= (e) => r.onHsvValueInput("h", e)
				}, null, 8, ["Value"]),
				g(r.TextBlock, { Text: r.t("text.hue") }, null, 8, ["Text"]),
				g(r.NumberBox, {
					Width: "120",
					Value: r.hsvSaturation,
					Minimum: 0,
					Maximum: 100,
					"onUpdate:Value": t[4] ||= (e) => r.onHsvValueInput("s", e)
				}, null, 8, ["Value"]),
				g(r.TextBlock, { Text: r.t("text.saturation") }, null, 8, ["Text"]),
				g(r.NumberBox, {
					Width: "120",
					Value: r.hsvValue,
					Minimum: 0,
					Maximum: 100,
					"onUpdate:Value": t[5] ||= (e) => r.onHsvValueInput("v", e)
				}, null, 8, ["Value"]),
				g(r.TextBlock, { Text: r.t("text.value") }, null, 8, ["Text"])
			], 64)) : p("", !0),
			r.IsAlphaEnabled && r.IsAlphaTextInputVisible ? (b(), m(d, { key: 3 }, [g(r.NumberBox, {
				Width: "120",
				Value: r.opacityPercent,
				Minimum: 0,
				Maximum: 100,
				"onUpdate:Value": r.onOpacityInput
			}, null, 8, ["Value"]), g(r.TextBlock, { Text: r.t("sample.opacity") }, null, 8, ["Text"])], 64)) : p("", !0)
		])) : p("", !0),
		g(r.ToolTip, {
			ref: "spectrumToolTipRef",
			IsOpen: "{x:Bind spectrumToolTipOpen, Mode=TwoWay}",
			Content: "{x:Bind spectrumToolTipContent, Mode=OneWay}",
			Placement: "Top",
			PlacementTarget: "{x:Bind spectrumThumbRef, Mode=OneWay}"
		}, null, 512)
	], 2);
}
var M = /*#__PURE__*/ i(T, [["render", j], ["__file", "ColorPicker.vue"]]);
//#endregion
export { M as default };

//# sourceMappingURL=ColorPicker.vue.js.map