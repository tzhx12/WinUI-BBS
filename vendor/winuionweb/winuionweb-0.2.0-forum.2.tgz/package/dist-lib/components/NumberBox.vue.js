import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./NumberBox.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                              */
import { Teleport as n, createBlock as r, createCommentVNode as i, createElementBlock as a, createElementVNode as o, createVNode as s, normalizeClass as c, normalizeStyle as l, openBlock as u, withDirectives as d, withModifiers as f } from "vue";
//#region src/components/NumberBox.vue
var p = { class: "win-number-shell" };
function m(e, t, m, h, g, _) {
	return u(), a("div", {
		ref: "rootRef",
		class: c(["win-number-box", {
			"is-disabled": !h.resolvedIsEnabled,
			"is-inline": h.resolvedSpinButtonPlacementMode === "Inline",
			"is-compact": h.resolvedSpinButtonPlacementMode === "Compact"
		}]),
		style: l(h.rootStyle),
		onKeyup: h.onKeyup,
		onWheel: h.onWheel
	}, [o("div", p, [s(h.TextBox, {
		class: "win-number-textbox",
		Text: "{x:Bind NumberBoxTemplate.Text, Mode=OneWay}",
		Header: "{x:Bind NumberBoxTemplate.Header, Mode=OneWay}",
		HeaderTemplate: "{x:Bind NumberBoxTemplate.HeaderTemplate, Mode=OneWay}",
		Description: "{x:Bind NumberBoxTemplate.Description, Mode=OneWay}",
		PlaceholderText: "{x:Bind NumberBoxTemplate.PlaceholderText, Mode=OneWay}",
		IsEnabled: "{x:Bind NumberBoxTemplate.IsEnabled, Mode=OneWay}",
		MinHeight: "{x:Bind NumberBoxTemplate.MinHeight, Mode=OneWay}",
		InputScope: "{x:Bind NumberBoxTemplate.InputScope, Mode=OneWay}",
		TextAlignment: "{x:Bind NumberBoxTemplate.TextAlignment, Mode=OneWay}",
		SelectionHighlightColor: "{x:Bind NumberBoxTemplate.SelectionHighlightColor, Mode=OneWay}",
		PreventKeyboardDisplayOnProgrammaticFocus: "{x:Bind NumberBoxTemplate.PreventKeyboardDisplayOnProgrammaticFocus, Mode=OneWay}",
		TextChanged: "OnNumberBoxTextChanged",
		TextCompositionStarted: "OnNumberBoxTextCompositionStarted",
		TextCompositionEnded: "OnNumberBoxTextCompositionEnded",
		GotFocus: "OnNumberBoxGotFocus",
		LostFocus: "OnNumberBoxLostFocus"
	})]), (u(), r(n, { to: "body" }, [h.compactPopupOpen ? d((u(), a("div", {
		key: 0,
		class: c(["win-number-compact-popup win-theme-scope", h.compactPopupThemeClass]),
		style: l([h.compactPopupStyle, h.compactPopupBackgroundStyle]),
		onPointerdown: t[0] ||= f(() => {}, ["prevent"])
	}, [s(h.RepeatButton, {
		class: "win-number-popup-button",
		Content: "",
		Padding: "0",
		IsEnabled: "{x:Bind NumberBoxTemplate.CanIncrease, Mode=OneWay}",
		IsTabStop: "False",
		"AutomationProperties.Name": "{x:Bind NumberBoxTemplate.IncreaseLabel, Mode=OneWay}",
		Click: "OnNumberBoxSpinUp"
	}), s(h.RepeatButton, {
		class: "win-number-popup-button",
		Content: "",
		Padding: "0",
		IsEnabled: "{x:Bind NumberBoxTemplate.CanDecrease, Mode=OneWay}",
		IsTabStop: "False",
		"AutomationProperties.Name": "{x:Bind NumberBoxTemplate.DecreaseLabel, Mode=OneWay}",
		Click: "OnNumberBoxSpinDown"
	})], 38)), [[
		h.vAcrylicBrush,
		h.compactPopupBackgroundStyle,
		void 0,
		{ "host-backdrop": !0 }
	], [h.vThemeShadow, { Translation: h.compactPopupShadowDepth }]]) : i("", !0)]))], 38);
}
var h = /*#__PURE__*/ e(t, [
	["render", m],
	["__scopeId", "data-v-765ce84d"],
	["__file", "NumberBox.vue"]
]);
//#endregion
export { h as default };

//# sourceMappingURL=NumberBox.vue.js.map