import { useAcrylicBrushStyle as e } from "./AcrylicBrush.js";
import { materializeXamlVNode as t, resolveXamlHandler as n, resolveXamlValue as r, updateXamlBinding as i, xamlItemContextKey as a } from "./xamlRuntime.js";
import { vAcrylicBrush as o } from "./acrylicBrushVisual.js";
import { useI18n as ee } from "./i18n/index.js";
import { xamlResourceDictionaryKey as te } from "./Page.vue_vue_type_script_lang.js";
import { CollectionItemTemplate as ne, CollectionItemsPanel as re, getCollectionProperty as ie, getVNodeChildren as s } from "./CollectionProperties.js";
import ae from "./FontIcon.vue.js";
import { isHoverPointer as oe } from "./pointerInput.js";
import { Fragment as c, cloneVNode as se, computed as l, defineComponent as ce, getCurrentInstance as le, h as u, inject as ue, nextTick as de, onBeforeUnmount as fe, provide as pe, ref as d, useAttrs as me, useSlots as he, watch as f } from "vue";
var ge = /*@__PURE__*/ ce({
	inheritAttrs: !1,
	ItemTemplate: ne,
	ItemsPanel: re,
	__name: "FlipView",
	props: {
		ItemsSource: {
			type: [
				String,
				Array,
				Object
			],
			default: null
		},
		SelectedIndex: {
			type: [Number, String],
			default: void 0
		},
		SelectedItem: {
			type: [
				Object,
				String,
				Number,
				Boolean
			],
			default: void 0
		},
		Orientation: {
			type: String,
			default: void 0
		},
		FlowDirection: {
			type: String,
			default: void 0
		},
		HorizontalAlignment: {
			type: String,
			default: "Stretch"
		},
		VerticalAlignment: {
			type: String,
			default: "Stretch"
		},
		HorizontalContentAlignment: {
			type: String,
			default: "Stretch"
		},
		VerticalContentAlignment: {
			type: String,
			default: "Stretch"
		},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		IsTabStop: {
			type: [Boolean, String],
			default: !1
		},
		ItemTemplate: {
			type: [String, Object],
			default: void 0
		},
		Width: {
			type: [String, Number],
			default: ""
		},
		Height: {
			type: [String, Number],
			default: ""
		},
		MinWidth: {
			type: [String, Number],
			default: ""
		},
		MinHeight: {
			type: [String, Number],
			default: ""
		},
		MaxWidth: {
			type: [String, Number],
			default: ""
		},
		MaxHeight: {
			type: [String, Number],
			default: ""
		},
		Margin: {
			type: [String, Number],
			default: ""
		},
		Padding: {
			type: [String, Number],
			default: ""
		},
		Background: {
			type: [String, Object],
			default: ""
		},
		BorderBrush: {
			type: [String, Object],
			default: ""
		},
		BorderThickness: {
			type: [String, Number],
			default: ""
		},
		CornerRadius: {
			type: [String, Number],
			default: ""
		}
	},
	emits: [
		"SelectionChanged",
		"update:SelectedIndex",
		"update:SelectedItem"
	],
	setup(ne, { expose: re, emit: ge }) {
		let p = ne, m = ge, h = me(), _e = l(() => Object.fromEntries(Object.entries(h).filter(([e]) => ![
			"AutomationProperties.Name",
			"AutomationProperties.AutomationControlType",
			"AutomationProperties.LocalizedControlType",
			"SelectionChanged"
		].includes(e)))), ve = he(), g = le(), ye = ue(te, null), { t: be } = ee(), _ = d(null), v = d(0), y = d(!1), b = d(!1), x = d(!1), S = d(!1), C = null, w = l(() => ve.default?.() ?? []), T = l(() => w.value.filter((e) => !ie(e))), xe = l(() => w.value.find((e) => ie(e) === "itemTemplate")), Se = l(() => w.value.find((e) => ie(e) === "itemsPanel")), E = l(() => {
			let e = r(p.ItemsSource, g);
			return Array.isArray(e) ? e : e && typeof e != "string" && typeof e[Symbol.iterator] == "function" ? Array.from(e) : null;
		}), D = l(() => E.value ?? T.value), Ce = (e) => {
			if (typeof e != "string") return "";
			let t = e.trim().match(/^\{\s*StaticResource\s+([^\s}]+)\s*\}$/i);
			return t ? t[1] : e.trim().match(/^var\(--([^,)]+)\)$/)?.[1] ?? "";
		}, O = l(() => {
			let e = p.ItemTemplate, t = r(e, g), n = Ce(e) || Ce(t);
			return n && ye?.[n] ? s(ye[n]) : t && typeof t == "object" && t.type ? s(t) : xe.value ? s(xe.value) : [];
		}), we = l(() => {
			let e = Se.value ? s(Se.value)[0] : null;
			return String(r(e?.props?.Orientation, g) || r(p.Orientation, g) || "Horizontal");
		}), k = l(() => we.value.toLowerCase() === "vertical" ? "vertical" : "horizontal"), Te = l(() => String(r(p.FlowDirection, g) || "LeftToRight")), A = l(() => Te.value.toLowerCase() === "righttoleft"), j = l(() => r(p.IsEnabled, g) !== !1), M = d(""), N = d(""), Ee = e(() => !j.value || F.value <= 0 ? "{ThemeResource ButtonBackgroundDisabled}" : `{ThemeResource FlipViewNextPreviousButtonBackground${M.value}}`, g), De = e(() => !j.value || F.value >= D.value.length - 1 ? "{ThemeResource ButtonBackgroundDisabled}" : `{ThemeResource FlipViewNextPreviousButtonBackground${N.value}}`, g), Oe = l(() => r(p.IsTabStop, g) === !0), ke = l(() => String(r(p.HorizontalAlignment, g) || "Stretch")), Ae = l(() => String(r(p.VerticalAlignment, g) || "Stretch")), je = l(() => {
			let e = r(p.SelectedIndex, g);
			if (e == null || e === "") return;
			let t = Number(e);
			return Number.isFinite(t) ? t : void 0;
		}), Me = l(() => r(p.SelectedItem, g)), P = (e) => {
			let t = D.value.length;
			if (!t) return 0;
			let n = Number(e);
			return Number.isFinite(n) ? Math.max(0, Math.min(t - 1, Math.trunc(n))) : 0;
		}, Ne = (e, t) => {
			if (Object.is(e, t)) return !0;
			if (!e || !t || typeof e != "object" || typeof t != "object") return !1;
			let n = e.id ?? e.Id ?? e.key ?? e.Key, r = t.id ?? t.Id ?? t.key ?? t.Key;
			return n !== void 0 && r !== void 0 && n === r;
		}, F = l(() => P(v.value)), Pe = l(() => D.value[F.value]);
		f([
			je,
			Me,
			D
		], ([e, t, n]) => {
			let r = v.value;
			if (e !== void 0) r = e;
			else if (t !== void 0) {
				let e = n.findIndex((e) => Ne(e, t));
				e >= 0 && (r = e);
			}
			let i = n.length ? Math.max(0, Math.min(n.length - 1, Math.trunc(Number(r) || 0))) : 0;
			i !== v.value && (v.value = i, y.value && b.value && $());
		}, { immediate: !0 }), f(() => D.value.length, () => {
			let e = P(v.value);
			e !== v.value && (v.value = e, y.value && b.value && $());
		});
		let I = (e) => {
			let t = r(e, g);
			if (!(t === "" || t == null || t === "Auto")) return typeof t == "number" || /^-?\d+(?:\.\d+)?$/.test(String(t).trim()) ? `${t}px` : String(t);
		}, L = (e) => {
			let t = r(e, g);
			if (t === "" || t == null || t === "Auto") return;
			let n = String(t).split(",").map((e) => I(e.trim()));
			return n.length === 1 ? n[0] : n.length === 2 ? `${n[1]} ${n[0]}` : n.length === 4 ? `${n[1]} ${n[2]} ${n[3]} ${n[0]}` : String(t);
		}, Fe = e(() => p.Background || void 0, g), Ie = l(() => {
			let e = r(p.BorderBrush, g), t = L(p.BorderThickness);
			return {
				width: I(p.Width),
				height: I(p.Height),
				minWidth: I(p.MinWidth),
				minHeight: I(p.MinHeight),
				maxWidth: I(p.MaxWidth),
				maxHeight: I(p.MaxHeight),
				margin: L(p.Margin),
				padding: L(p.Padding),
				...Fe.value,
				borderColor: e || void 0,
				borderWidth: t,
				borderStyle: e || t ? "solid" : void 0,
				borderRadius: L(p.CornerRadius),
				justifySelf: {
					Left: "start",
					Center: "center",
					Right: "end",
					Stretch: "stretch"
				}[ke.value],
				alignSelf: {
					Top: "start",
					Center: "center",
					Bottom: "end",
					Stretch: "stretch"
				}[Ae.value]
			};
		}), Le = (e, t = "stretch") => {
			let n = String(r(e, g) || t).toLowerCase();
			return n === "center" ? "center" : n === "left" || n === "top" ? "flex-start" : n === "right" || n === "bottom" ? "flex-end" : "stretch";
		}, R = l(() => Le(p.HorizontalContentAlignment)), z = l(() => Le(p.VerticalContentAlignment)), Re = l(() => ({
			justifyContent: R.value === "stretch" ? "flex-start" : R.value,
			alignItems: z.value,
			"--flip-view-content-width": R.value === "stretch" ? "100%" : "auto",
			"--flip-view-content-height": z.value === "stretch" ? "100%" : "auto"
		})), ze = (e, t) => e && typeof e == "object" ? e.id ?? e.Id ?? e.key ?? e.Key ?? e.title ?? e.Title ?? t : `${typeof e}:${String(e)}:${t}`, Be = (e) => e == null ? "" : typeof e == "object" ? e.Title ?? e.title ?? e.Text ?? e.text ?? e.Name ?? e.name ?? "" : String(e), B = (e) => `flip-view-item-${e}`, Ve = l(() => D.value.length ? B(F.value) : void 0), He = l(() => Oe.value || !D.value.length ? 0 : -1), Ue = ce({
			name: "FlipViewItemTemplate",
			props: {
				item: {
					type: null,
					default: void 0
				},
				index: {
					type: Number,
					default: 0
				}
			},
			setup(e) {
				pe(a, e.item);
				let n = (e) => {
					if (!e || typeof e != "object") return e;
					if (e.type === c && Array.isArray(e.children)) return u(c, e.children.map(n));
					if ((e.type?.name ?? e.type?.__name) !== "Image") return e;
					let t = e.props ?? {}, r = (e) => e == null || e === "" || e === "Auto";
					return se(e, {
						"data-flip-view-auto-width": r(t.Width) && (t.HorizontalAlignment ?? "Stretch") === "Stretch" ? "" : void 0,
						"data-flip-view-auto-height": r(t.Height) && (t.VerticalAlignment ?? "Stretch") === "Stretch" ? "" : void 0
					});
				};
				return () => {
					if (O.value.length) {
						let r = t(O.value, e.item, g);
						return u(c, (Array.isArray(r) ? r : [r]).map(n));
					}
					return E.value === null && T.value[e.index] ? u(c, [n(T.value[e.index])]) : u(c, [u("span", Be(e.item))]);
				};
			}
		}), We = l(() => {
			let e = F.value * 100;
			return k.value === "vertical" ? { transform: `translateY(-${e}%)` } : { transform: `translateX(-${A.value ? (D.value.length - 1 - F.value) * 100 : e}%)` };
		}), Ge = (e, t, r) => {
			if (h[`on${e}`]) return;
			let i = h[e], a = n(i, g);
			a && a(t, r);
		}, V = (e, { focus: t = !1 } = {}) => {
			if (!j.value || !D.value.length) return !1;
			let n = P(e), r = F.value;
			if (n === r) return !1;
			let a = D.value[r], o = D.value[n];
			v.value = n, m("update:SelectedIndex", n), m("update:SelectedItem", o), i(p.SelectedIndex, n, g), i(p.SelectedItem, o, g);
			let ee = {
				AddedItems: o === void 0 ? [] : [o],
				RemovedItems: a === void 0 ? [] : [a],
				SelectedIndex: n,
				SelectedItem: o
			}, te = g?.exposeProxy ?? g?.proxy;
			return m("SelectionChanged", te, ee), Ge("SelectionChanged", te, ee), Z(), t && $(), !0;
		};
		function H() {
			V(F.value - 1, { focus: b.value }) && Z();
		}
		function U() {
			V(F.value + 1, { focus: b.value }) && Z();
		}
		let Ke = () => typeof performance < "u" && performance.now ? performance.now() : Date.now(), W = 0, G = 0;
		function qe(e) {
			if (!j.value || e.ctrlKey) return;
			let t = k.value === "vertical" ? e.deltaY : Math.abs(e.deltaX) >= Math.abs(e.deltaY) && e.deltaX !== 0 ? e.deltaX : e.deltaY;
			if (!t) return;
			let n = Math.sign(t), r = Ke(), i = n !== G || r - W > 200;
			if (W = r, !i) {
				e.preventDefault();
				return;
			}
			V(t > 0 ? F.value + 1 : F.value - 1) && (G = n, e.preventDefault());
		}
		let K = d(null), q = null, J = null, Je = (e) => k.value === "vertical" ? e.clientY : e.clientX, Ye = (e) => k.value === "vertical" ? e.clientX : e.clientY;
		function Xe(e, t, n = null) {
			K.value = {
				start: e,
				last: e,
				cross: t,
				pointerId: n,
				cancelled: !1
			};
		}
		function Ze(e, t, n) {
			let r = K.value;
			if (r) {
				if (r.last = e, Math.abs(t - r.cross) > Math.abs(e - r.start) + 8) {
					r.cancelled = !0;
					return;
				}
				Math.abs(e - r.start) > 8 && n.preventDefault();
			}
		}
		function Y(e = !1) {
			let t = K.value;
			K.value = null;
			let n = t && !e && !t.cancelled ? t.start - t.last : 0;
			!t || !n || Math.abs(n) < 30 || !j.value || ((k.value === "horizontal" && A.value ? n < 0 : n > 0) ? U() : H());
		}
		function Qe(e) {
			if (j.value) {
				if (e.pointerType === "mouse" || !e.pointerType) {
					b.value = !1, Z();
					return;
				}
				q = e.pointerId, J = null, Xe(Je(e), Ye(e), e.pointerId), Q();
				try {
					_.value?.setPointerCapture?.(e.pointerId);
				} catch {}
			}
		}
		function $e(e) {
			q === e.pointerId && Ze(Je(e), Ye(e), e);
		}
		function et(e) {
			if (q !== e.pointerId) return;
			q = null, J = null;
			let t = K.value;
			try {
				_.value?.releasePointerCapture?.(e.pointerId);
			} catch {}
			Y(!1), t && Q();
		}
		function tt(e) {
			q === e.pointerId && (q = null, J = null, Y(!0), Q());
		}
		function nt(e) {
			q !== null && e.pointerId === q && (q = null, Y(!0));
		}
		function rt(e) {
			if (q !== null || !j.value) return;
			let t = e.touches?.[0];
			t && (J = {
				start: k.value === "vertical" ? t.clientY : t.clientX,
				cross: k.value === "vertical" ? t.clientX : t.clientY
			}, Xe(J.start, J.cross), Q());
		}
		function it(e) {
			if (q !== null || !J) return;
			let t = e.touches?.[0];
			t && Ze(k.value === "vertical" ? t.clientY : t.clientX, k.value === "vertical" ? t.clientX : t.clientY, e);
		}
		function at(e) {
			if (q !== null || !J) return;
			let t = e.changedTouches?.[0];
			if (t) {
				let e = k.value === "vertical" ? t.clientY : t.clientX, n = k.value === "vertical" ? t.clientX : t.clientY;
				K.value.last = e, K.value.cancelled = Math.abs(n - J.cross) > Math.abs(e - J.start) + 8, Y(!1);
			}
			J = null, Q();
		}
		function ot() {
			q === null && (J = null, Y(!0), Q());
		}
		function X() {
			C !== null && (clearTimeout(C), C = null);
		}
		function Z() {
			!j.value || D.value.length < 2 || (X(), x.value = !0, C = setTimeout(() => {
				C = null, S.value || (x.value = !1);
			}, 3e3));
		}
		function Q() {
			X(), S.value || (x.value = !1);
		}
		function st(e) {
			j.value && oe(e) && Z();
		}
		function ct() {
			S.value || Z();
		}
		function lt() {
			S.value = !0, Z();
		}
		function ut(e, t) {
			let n = oe(e) ? "PointerOver" : "";
			t === "previous" ? M.value = n : N.value = n, n && lt();
		}
		function dt(e) {
			e === "previous" ? M.value = "Pressed" : N.value = "Pressed", lt();
		}
		function ft(e, t) {
			let n = oe(e) ? "PointerOver" : "";
			t === "previous" ? M.value = n : N.value = n, n || mt();
		}
		function pt(e) {
			e === "previous" ? M.value = "" : N.value = "", mt();
		}
		function mt() {
			S.value = !1, Z();
		}
		function $() {
			de(() => {
				let e = _.value?.querySelector?.(`#${B(F.value)}`);
				if (e && document.activeElement !== e) try {
					e.focus({ preventScroll: !0 });
				} catch {
					e.focus();
				}
			});
		}
		function ht(e) {
			y.value = !0, Z(), e.target === _.value && D.value.length && $();
		}
		function gt(e) {
			let t = e.relatedTarget;
			_.value?.contains?.(t) || (y.value = !1, b.value = !1, S.value = !1, Q());
		}
		function _t(e) {
			y.value = !0, e !== F.value && V(e, { focus: !1 });
		}
		function vt(e) {
			if (!j.value) return;
			b.value = !0, Z();
			let t = e.key, n = k.value === "horizontal", r = null;
			n && t === "ArrowRight" || !n && t === "ArrowDown" || t === "PageDown" ? r = F.value + 1 : n && t === "ArrowLeft" || !n && t === "ArrowUp" || t === "PageUp" ? r = F.value - 1 : t === "Home" ? r = 0 : t === "End" && (r = D.value.length - 1), r !== null && (n && A.value && (t === "ArrowLeft" || t === "ArrowRight") && (r = t === "ArrowLeft" ? F.value + 1 : F.value - 1), V(r, { focus: !0 }) && e.preventDefault());
		}
		let yt = l(() => x.value && F.value > 0), bt = l(() => x.value && F.value < D.value.length - 1), xt = l(() => be("text.previous")), St = l(() => be("text.next")), Ct = l(() => {
			let e = h["AutomationProperties.Name"] ?? h["automationproperties.name"];
			return e ? String(r(e, g)) : void 0;
		});
		f(k, () => {
			G = 0, Q();
		}), f(j, (e) => {
			e || Q();
		}), fe(() => {
			X(), K.value = null, J = null, q = null;
		});
		let wt = l({
			get: () => F.value,
			set: (e) => V(e)
		});
		re({
			SelectedIndex: wt,
			SelectedItem: Pe,
			MovePrevious: H,
			MoveNext: U
		});
		let Tt = {
			props: p,
			emit: m,
			attrs: h,
			forwardedAttrs: _e,
			slots: ve,
			instance: g,
			resources: ye,
			t: be,
			rootRef: _,
			currentIndex: v,
			hasFocus: y,
			keyboardInput: b,
			showButtons: x,
			keepButtonsVisible: S,
			get buttonsFadeTimer() {
				return C;
			},
			set buttonsFadeTimer(e) {
				C = e;
			},
			slotNodes: w,
			declaredNodes: T,
			itemTemplateNode: xe,
			itemsPanelNode: Se,
			sourceItems: E,
			items: D,
			templateResourceKey: Ce,
			templateNodes: O,
			orientation: we,
			orientationClass: k,
			flowDirection: Te,
			isRtl: A,
			isEnabled: j,
			previousButtonState: M,
			nextButtonState: N,
			previousButtonBackgroundStyle: Ee,
			nextButtonBackgroundStyle: De,
			isTabStop: Oe,
			horizontalAlignment: ke,
			verticalAlignment: Ae,
			resolvedSelectedIndex: je,
			resolvedSelectedItem: Me,
			clampIndex: P,
			itemMatches: Ne,
			selectedIndex: F,
			selectedItem: Pe,
			cssLength: I,
			xamlThickness: L,
			backgroundStyle: Fe,
			rootStyle: Ie,
			alignment: Le,
			horizontalContentAlignment: R,
			verticalContentAlignment: z,
			itemStyle: Re,
			getItemKey: ze,
			displayItem: Be,
			itemId: B,
			activeDescendantId: Ve,
			rootTabIndex: He,
			ItemRenderer: Ue,
			trackStyle: We,
			invokeUnnormalizedHandler: Ge,
			setSelectedIndex: V,
			prev: H,
			next: U,
			now: Ke,
			get lastWheelTime() {
				return W;
			},
			set lastWheelTime(e) {
				W = e;
			},
			get lastWheelDirection() {
				return G;
			},
			set lastWheelDirection(e) {
				G = e;
			},
			wheelDelay: 200,
			onWheel: qe,
			pointerGesture: K,
			get activePointerId() {
				return q;
			},
			set activePointerId(e) {
				q = e;
			},
			get touchGesture() {
				return J;
			},
			set touchGesture(e) {
				J = e;
			},
			gestureDistance: 30,
			mainAxis: Je,
			crossAxis: Ye,
			beginGesture: Xe,
			updateGesture: Ze,
			completeGesture: Y,
			onPointerDown: Qe,
			onPointerMove: $e,
			onPointerUp: et,
			onPointerCancel: tt,
			onLostPointerCapture: nt,
			onTouchStart: rt,
			onTouchMove: it,
			onTouchEnd: at,
			onTouchCancel: ot,
			clearButtonsFadeTimer: X,
			showNavigationButtons: Z,
			hideNavigationButtons: Q,
			onMouseEnter: st,
			onMouseLeave: ct,
			onButtonEnter: lt,
			onNavigationButtonEnter: ut,
			onNavigationButtonPressed: dt,
			onNavigationButtonReleased: ft,
			onNavigationButtonCanceled: pt,
			onButtonLeave: mt,
			focusSelectedItem: $,
			onFocusIn: ht,
			onFocusOut: gt,
			onItemFocus: _t,
			onKeyDown: vt,
			previousButtonVisible: yt,
			nextButtonVisible: bt,
			previousLabel: xt,
			nextLabel: St,
			automationName: Ct,
			exposedSelectedIndex: wt,
			FontIcon: ae,
			get vAcrylicBrush() {
				return o;
			}
		};
		return Object.defineProperty(Tt, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), Tt;
	}
});
//#endregion
export { ge as default };

//# sourceMappingURL=FlipView.vue_vue_type_script_setup_true_lang.js.map