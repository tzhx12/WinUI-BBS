import { attachedValue as e, xamlThickness as t } from "./layout.js";
import { normalizeXamlNodes as n, resolveXamlHandler as r, resolveXamlValue as i, updateXamlBinding as a } from "./xamlRuntime.js";
import { frameworkLayoutStyle as o } from "./frameworkLayout.js";
import { isHoverPointer as s } from "./pointerInput.js";
import { PivotItemContentTemplate as c, getPivotProperty as ee, pivotChildren as te, pivotItemContextKey as l, pivotItemIdentityKey as ne, pivotNodes as re, pivotProperties as ie, pivotPropertyChildren as ae, pivotRootAttributes as u, pivotText as oe, pivotTypeName as se, renderPivotPresenter as ce } from "./PivotProperties.js";
import le from "./PivotItem.vue.js";
import { Fragment as ue, cloneVNode as de, computed as d, defineComponent as fe, getCurrentInstance as pe, h as me, nextTick as he, onBeforeUnmount as ge, onMounted as _e, onUpdated as ve, provide as ye, ref as f, shallowReactive as be, shallowRef as p, useAttrs as xe, useSlots as Se, watch as m } from "vue";
var Ce = /*@__PURE__*/ fe({
	...ie,
	name: "Pivot",
	inheritAttrs: !1,
	__name: "Pivot",
	props: {
		Title: {
			type: null,
			default: null
		},
		TitleTemplate: {
			type: null,
			default: null
		},
		HeaderTemplate: {
			type: null,
			default: null
		},
		LeftHeader: {
			type: null,
			default: null
		},
		LeftHeaderTemplate: {
			type: null,
			default: null
		},
		RightHeader: {
			type: null,
			default: null
		},
		RightHeaderTemplate: {
			type: null,
			default: null
		},
		ItemsSource: {
			type: null,
			default: null
		},
		ItemTemplate: {
			type: null,
			default: null
		},
		ItemsPanel: {
			type: null,
			default: null
		},
		SelectedIndex: {
			type: null,
			default: void 0
		},
		SelectedItem: {
			type: null,
			default: void 0
		},
		IsLocked: {
			type: null,
			default: !1
		},
		IsHeaderItemsCarouselEnabled: {
			type: null,
			default: !0
		},
		HeaderFocusVisualPlacement: {
			type: null,
			default: "ItemHeaders"
		},
		IsEnabled: {
			type: null,
			default: !0
		},
		IsTabStop: {
			type: null,
			default: !1
		},
		Visibility: {
			type: null,
			default: "Visible"
		},
		Background: {
			type: null,
			default: "{ThemeResource PivotBackground}"
		},
		Foreground: {
			type: null,
			default: ""
		},
		Margin: {
			type: null,
			default: 0
		},
		Padding: {
			type: null,
			default: 0
		},
		Width: {
			type: null,
			default: ""
		},
		Height: {
			type: null,
			default: ""
		},
		MinWidth: {
			type: null,
			default: ""
		},
		MinHeight: {
			type: null,
			default: ""
		},
		MaxWidth: {
			type: null,
			default: ""
		},
		MaxHeight: {
			type: null,
			default: ""
		},
		HorizontalAlignment: {
			type: null,
			default: "Stretch"
		},
		VerticalAlignment: {
			type: null,
			default: "Stretch"
		},
		FlowDirection: {
			type: null,
			default: ""
		},
		RequestedTheme: {
			type: null,
			default: "Default"
		},
		Opacity: {
			type: null,
			default: 1
		},
		IsHitTestVisible: {
			type: null,
			default: !0
		}
	},
	emits: [
		"SelectionChanged",
		"PivotItemLoading",
		"PivotItemLoaded",
		"PivotItemUnloading",
		"PivotItemUnloaded",
		"update:SelectedIndex",
		"update:SelectedItem"
	],
	setup(ie, { expose: Ce, emit: we }) {
		let h = ie, Te = we, g = pe(), Ee = xe(), De = Se(), _ = f(null), v = f(null), y = f(null), Oe = f(null), b = /* @__PURE__ */ new Map(), ke = /* @__PURE__ */ new Map(), x = f(-1), S = p(null), Ae = p(null), je = p(null), Me = p(null), C = p(/* @__PURE__ */ new Set()), Ne = f(!1), w = f(!1), Pe = f("ltr"), T = f("Idle"), E = f(0), Fe = f(!1), D = f(!1), Ie = f({
			left: 0,
			width: 0,
			height: 48
		}), O = (e) => i(e, g), Le = be({}), k = (e) => {
			let t = e in Le ? Le[e] : h[e];
			return /Template$/.test(e) && typeof t == "string" && /^\{(?:StaticResource|ThemeResource)\s/.test(t) ? t : O(t);
		}, A = be(/* @__PURE__ */ new Map()), j = d(() => k("IsEnabled") !== !1), M = d(() => k("IsLocked") === !0), Re = d(() => k("IsHeaderItemsCarouselEnabled") !== !1), N = d(() => !Re.value || !Ne.value), ze = d(() => k("FlowDirection") === "RightToLeft" ? "rtl" : k("FlowDirection") === "LeftToRight" ? "ltr" : Pe.value), Be = d(() => ["Light", "Dark"].includes(String(k("RequestedTheme"))) ? String(k("RequestedTheme")).toLowerCase() : void 0), Ve = d(() => u(Ee, g)), He = d(() => ({
			...o({
				...Object.fromEntries(Object.keys(h).map((e) => [e, k(e)])),
				Padding: ""
			}, g),
			color: k("Foreground") ? String(k("Foreground")) : void 0
		})), Ue = d(() => ({ margin: t(k("Padding")) })), We = d(() => ({ transform: E.value ? `translate3d(${E.value}px,0,0)` : void 0 })), Ge = d(() => re(De.default?.() ?? [])), P = (e) => ae(Ge.value, "Pivot", e), Ke = d(() => P("title").length > 0 || k("Title") !== null && k("Title") !== void 0 && k("Title") !== "" || !!k("TitleTemplate") || P("titleTemplate").length > 0), qe = (e, t, n) => fe({ setup: () => () => ce(t(), P(e), n(), P(`${e}Template`), g) }), Je = qe("title", () => k("Title"), () => k("TitleTemplate")), Ye = qe("leftHeader", () => k("LeftHeader"), () => k("LeftHeaderTemplate")), Xe = qe("rightHeader", () => k("RightHeader"), () => k("RightHeaderTemplate")), Ze = /* @__PURE__ */ new WeakMap(), Qe = /* @__PURE__ */ new Map(), $e = 0, et = (e, t) => !e || typeof e != "object" ? (Qe.has(e) || Qe.set(e, ++$e), `source-value:${Qe.get(e)}:${t}`) : (Ze.has(e) || Ze.set(e, ++$e), `source-object:${Ze.get(e)}:${t}`), F = d(() => {
			let e = k("ItemsSource");
			if (e && typeof e[Symbol.iterator] == "function") {
				let t = /* @__PURE__ */ new Map();
				return Array.from(e, (e, n) => {
					let r = t.get(e) ?? 0;
					t.set(e, r + 1);
					let i = et(e, r), a = (e, t) => e in (A.get(i) ?? {}) ? A.get(i)[e] : t;
					return {
						key: i,
						index: n,
						vnode: null,
						source: e,
						header: a("Header", e),
						headerNodes: [],
						enabled: a("IsEnabled", !(e && typeof e == "object" && "IsEnabled" in e && O(e.IsEnabled) === !1)) !== !1
					};
				});
			}
			return (P("items").length ? P("items") : Ge.value.filter((e) => !ee(e, "Pivot"))).filter((e) => se(e) === "PivotItem").map((e, t) => {
				let n = e.key ?? `item:${t}`, r = (t) => t in (A.get(n) ?? {}) ? A.get(n)[t] : O(e.props?.[t]);
				return {
					key: n,
					index: t,
					vnode: e,
					source: e.props ?? {},
					header: r("Header"),
					headerNodes: "Header" in (A.get(n) ?? {}) ? [] : ae(te(e), "PivotItem", "header"),
					enabled: r("IsEnabled") !== !1,
					accessKey: r("AccessKey")
				};
			});
		}), tt = d(() => F.value[x.value] ?? null), I = d(() => tt.value?.key ?? null), nt = d(() => j.value && Fe.value && D.value && k("HeaderFocusVisualPlacement") === "SelectedItemHeader"), rt = d(() => ({
			width: `${Ie.value.width}px`,
			height: `${Ie.value.height}px`,
			transform: `translateX(${Ie.value.left}px)`
		})), it = d(() => N.value || x.value < 0 ? F.value : [...F.value.slice(x.value), ...F.value.slice(0, x.value)]), at = `pivot-${g?.uid ?? 0}`, ot = (e) => `${at}-header-${e.index}`, st = (e) => `${at}-item-${e.index}`, L = (e) => e?.vnode ? ke.get(e.key)?.$?.exposed ?? e.vnode.component?.exposed ?? e.source : e?.source ?? null, ct = (e) => e ? ke.get(e.key)?.$?.exposed ?? e.vnode?.component?.exposed ?? null : null, lt = (e, t) => {
			if (L(e) === t || e.source === t) return !0;
			let n = t && typeof t == "object" ? t[ne] : void 0;
			return n !== void 0 && n === ct(e)?.[ne];
		}, ut = d(() => j.value && !M.value && w.value && Ne.value && F.value.length > 1 && (!N.value || x.value > 0)), dt = d(() => j.value && !M.value && w.value && Ne.value && F.value.length > 1 && (!N.value || x.value < F.value.length - 1)), ft = fe({
			props: ["item"],
			setup: (e) => () => {
				let t = e.item;
				return ce(t.header, t.headerNodes, k("HeaderTemplate"), P("headerTemplate"), g);
			}
		}), pt = fe({ setup: () => () => me(ue, F.value.map((e) => {
			let t = (t) => {
				t && !(t instanceof Element) ? ke.set(e.key, t) : ke.delete(e.key);
			}, r = e.vnode ? de(e.vnode, {
				key: e.key,
				ref: t
			}) : me(le, {
				key: e.key,
				Header: e.source,
				IsEnabled: e.source && typeof e.source == "object" && "IsEnabled" in e.source ? O(e.source.IsEnabled) : !0,
				Content: e.source,
				ContentTemplate: k("ItemTemplate"),
				ref: t
			}, P("itemTemplate").length ? { default: () => me(c, null, { default: () => P("itemTemplate") }) } : void 0);
			return me("div", {
				key: e.key,
				class: "win-pivot-item-host",
				style: { display: e.key === S.value ? "grid" : "none" },
				role: "tabpanel",
				id: st(e),
				"aria-labelledby": ot(e),
				inert: e.key !== S.value,
				"aria-hidden": e.key !== S.value
			}, n([r], g));
		})) });
		ye(l, {
			isVisible: (e) => e === S.value,
			isLoaded: (e) => C.value.has(e),
			isEnabled: () => j.value,
			select: (e) => {
				let t = F.value.find((t) => t.key === e);
				t && X(t.index, !0);
			},
			setProperty: (e, t, n) => {
				if (![
					"Header",
					"IsEnabled",
					"AccessKey"
				].includes(t)) return;
				let r = A.get(e);
				if (n === void 0) {
					if (r && t in r) {
						let n = { ...r };
						delete n[t], A.set(e, n);
					}
					return;
				}
				r?.[t] !== n && A.set(e, {
					...r,
					[t]: n
				});
			}
		});
		let mt = (e) => ({
			"is-selected": e.key === I.value,
			"is-disabled": !j.value || !e.enabled,
			"is-locked-unselected": M.value && e.key !== I.value,
			"is-pointer-over": je.value === e.key,
			"is-pressed": Me.value === e.key,
			"has-focus-visual": Ae.value === e.key && k("HeaderFocusVisualPlacement") === "ItemHeaders",
			"has-selected-focus-visual": Ae.value === e.key && e.key === I.value && k("HeaderFocusVisualPlacement") !== "ItemHeaders"
		}), ht = (e, t) => {
			t instanceof HTMLElement ? b.set(e, t) : b.delete(e);
		}, R = (e, t) => {
			Te(e, Gt, t), r(Ee[e], g)?.(Gt, t);
		}, gt = (e) => Object.freeze({ Item: ct(e) }), z = () => Array.from(Oe.value?.children ?? []).find((e) => e.style.display !== "none"), B = [], V, H = 0, U = !1, _t = !1, W = null, vt, yt, G = 0, K = null, bt = 0, xt = 0, St = 0, q = !1, Ct = () => {
			for (let e of B) e.cancel();
			B = [];
		}, J = () => {
			V?.cancel(), V = void 0;
		}, wt = () => {
			Ct(), J();
		}, Tt = () => window.matchMedia?.("(prefers-reduced-motion: reduce)").matches, Et = async (e, t) => {
			let n = z();
			if (!n?.animate || Tt()) return;
			let r = e === "FlyIn", i = (r ? 20 : -7) * t, a = [n.animate([{ transform: `translate3d(${r ? i : 0}px,0,0)` }, { transform: `translate3d(${r ? 0 : i}px,0,0)` }], {
				duration: r ? 767 : 83,
				easing: r ? "cubic-bezier(0.1,0.9,0.2,1)" : "linear",
				fill: "both"
			}), n.animate([{ opacity: +!r }, { opacity: +!!r }], {
				duration: r ? 333 : 67,
				easing: r ? "cubic-bezier(0.1,0.9,0.2,1)" : "linear",
				fill: "both"
			})];
			B.push(...a);
			try {
				await Promise.all(a.map((e) => e.finished));
			} catch {} finally {
				if (r) for (let e of a) e.cancel();
				B = B.filter((e) => !a.includes(e) || !r);
			}
		}, Dt = () => {
			if (Tt()) return;
			let t = z();
			if (!t) return;
			let n = [t, ...Array.from(t.querySelectorAll("*"))], r = Y;
			for (let t of n) {
				let n = {
					GroupOne: 1,
					GroupTwo: 2,
					GroupThree: 3
				}[e(t, "Pivot.SlideInAnimationGroup") ?? ""];
				if (!n || !t.animate) continue;
				let i = 40 * n * r, a = [{
					transform: `translate3d(${i}px,0,0)`,
					offset: 0
				}, {
					transform: `translate3d(${i * .28335052129660765}px,0,0)`,
					offset: .5
				}];
				for (let e = 1; e <= 40; e++) {
					let t = e / 40, n = (Math.exp(-2.302585093 * t) - 1) / (Math.exp(-2.302585093) - 1);
					a.push({
						transform: `translate3d(${i * .28335052129660765 * (1 - n)}px,0,0)`,
						offset: .5 + t * .5
					});
				}
				let o = t.animate(a, {
					duration: 700,
					easing: "linear",
					fill: "both"
				});
				B.push(o), o.finished.catch(() => {}).finally(() => {
					o.cancel(), B = B.filter((e) => e !== o);
				});
			}
		}, Y = 1, Ot = () => b.get(I.value)?.focus({ preventScroll: !0 }), kt = () => {
			let e = b.get(I.value);
			e && (Ie.value = {
				left: e.offsetLeft,
				width: e.offsetWidth,
				height: e.offsetHeight
			});
		}, At = (e) => {
			let t = e.type === "focusout" ? e.relatedTarget : e.target;
			Fe.value = t instanceof Node && !!v.value?.contains(t), e.type === "focusin" && t instanceof Element && (D.value = t.matches(":focus-visible")), kt();
		}, jt = () => {
			let e = v.value, t = b.get(I.value);
			if (!e || !t) return;
			let n = e.getBoundingClientRect(), r = t.getBoundingClientRect();
			r.left < n.left ? e.scrollLeft += r.left - n.left : r.right > n.right && (e.scrollLeft += r.right - n.right), kt();
		}, Mt = (e, t, n = L(t)) => {
			x.value = e;
			let r = F.value[e] ?? null;
			Te("update:SelectedIndex", e), Te("update:SelectedItem", L(r)), a(h.SelectedIndex, e, g), a(h.SelectedItem, L(r), g), t?.key !== r?.key && R("SelectionChanged", Object.freeze({
				RemovedItems: t ? [n] : [],
				AddedItems: r ? [L(r)] : []
			}));
		}, X = async (e, t = !1, n = !1, r, i) => {
			if (U || t && (!j.value || M.value)) return;
			let a = F.value[e];
			if (!a || t && !a.enabled) return;
			if (e === x.value) {
				n && Ot();
				return;
			}
			if (T.value !== "Idle") {
				W = {
					index: e,
					user: t,
					focus: n,
					direction: r
				}, T.value === "FlyIn" && wt();
				return;
			}
			let o = ++H, s = i ?? tt.value, c = L(s), ee = s ? gt(s) : null, te = _t && !!s, l = b.get(a.key)?.getBoundingClientRect().left ?? null, ne = b.get(I.value)?.getBoundingClientRect().left ?? null, re = performance.now();
			if (J(), te && !N.value && l !== null && ne !== null && y.value?.animate && !Tt()) {
				let e = l - ne;
				V = y.value.animate([{ transform: "translateX(0)" }, { transform: `translateX(${-e}px)` }], {
					duration: 850,
					easing: "cubic-bezier(0.1,0.9,0.2,1)",
					fill: "both"
				});
			}
			let ie = !!z()?.contains(document.activeElement);
			if (Y = (r ?? (e < x.value ? -1 : 1)) * (ze.value === "rtl" ? -1 : 1), T.value = "FlyOut", te && await Et("FlyOut", Y), U || o !== H || (C.value = new Set([...C.value, a.key]), x.value = e, S.value = a.key, Ae.value = a.key, await he(), Ct(), J(), U || o !== H)) return;
			if (te && !N.value && l !== null && b.get(a.key) && y.value?.animate && !Tt()) {
				let e = l - b.get(a.key).getBoundingClientRect().left;
				if (Math.abs(e) > .5) {
					let t = y.value.animate([{ transform: `translateX(${e}px)` }, { transform: "translateX(0)" }], {
						duration: 850,
						easing: "cubic-bezier(0.1,0.9,0.2,1)",
						fill: "both"
					});
					V = t, t.currentTime = Math.min(850, performance.now() - re), t.finished.catch(() => {}).finally(() => {
						t.cancel(), V === t && (V = void 0);
					});
				}
			}
			Mt(e, s, c), s && (R("PivotItemUnloading", ee), R("PivotItemUnloaded", ee));
			let ae = gt(a);
			if (R("PivotItemLoading", ae), R("PivotItemLoaded", ae), jt(), n) Ot();
			else if (ie) {
				let e = z()?.querySelector("button:not(:disabled),input:not(:disabled),select:not(:disabled),textarea:not(:disabled),a[href],[tabindex=\"0\"]");
				e ? e.focus({ preventScroll: !0 }) : Ot();
			}
			if (T.value = "FlyIn", Dt(), te && await Et("FlyIn", Y), U || o !== H) return;
			Ct(), T.value = "Idle";
			let u = W;
			W = null, u && X(u.index, u.user, u.focus, u.direction);
		}, Z = (e, t = !1) => {
			if (!j.value || M.value || !F.value.length) return !1;
			let n = F.value.length;
			for (let r = 1; r < n; r++) {
				let i = x.value + e * r;
				if (N.value && (i < 0 || i >= n)) return !1;
				if (i = (i + n * r) % n, F.value[i]?.enabled) return X(i, !0, t, e), !0;
			}
			return !1;
		}, Nt = (e) => {
			if (D.value = !0, e.defaultPrevented || !j.value || M.value || e.ctrlKey || e.altKey || e.metaKey) return;
			let t = !1, n = ze.value === "rtl" ? -1 : 1;
			if (e.key === "ArrowLeft") t = Z(-n, !0);
			else if (e.key === "ArrowRight") t = Z(n, !0);
			else if (e.key === "Home" || e.key === "End") {
				let n = (e.key === "Home" ? F.value : [...F.value].reverse()).find((e) => e.enabled);
				n && n.index !== x.value && (X(n.index, !0, !0), t = !0);
			} else if (e.key === "ArrowDown") {
				let e = z()?.querySelector("button:not(:disabled),input:not(:disabled),select:not(:disabled),textarea:not(:disabled),a[href],[tabindex=\"0\"]");
				e && (e.focus(), t = !0);
			}
			t && (e.preventDefault(), e.stopPropagation());
		}, Pt = (e) => {
			if (D.value = !0, e.defaultPrevented || !e.ctrlKey || !j.value || M.value) return;
			let t = e.key === "PageUp" || e.key === "Tab" && e.shiftKey ? -1 : +(e.key === "PageDown" || e.key === "Tab");
			t && (Z(t, !!v.value?.contains(document.activeElement)), e.preventDefault());
		}, Ft = (e) => {
			let t = e.target instanceof Element ? e.target.closest(".win-pivot-header-item,.win-pivot-nav-button") : null;
			!t || t.disabled || t.closest(".win-pivot") !== _.value || (t.hasAttribute("data-pivot-index") ? X(Number(t.dataset.pivotIndex), !0, !0) : Z(t.classList.contains("win-pivot-previous-button") ? -1 : 1, !0));
		}, It = (e) => {
			w.value = s(e);
		}, Lt = (e) => {
			e.relatedTarget instanceof Node && _.value?.querySelector(".win-pivot-layout-element")?.contains(e.relatedTarget) && e.relatedTarget.closest?.(".win-pivot-nav-button,.win-pivot-header-clipper") || (w.value = !1, je.value = null);
		}, Rt = (e, t) => {
			e.button === 0 && j.value && (Me.value = t);
		}, zt = () => {
			Me.value = null;
		}, Q = (e) => {
			if (e instanceof PointerEvent && K !== e.pointerId) {
				zt();
				return;
			}
			let t = K;
			K = null, E.value = 0, q = !1, J(), zt(), t !== null && _.value?.hasPointerCapture(t) && _.value.releasePointerCapture(t);
		}, Bt = (e) => {
			e.target === _.value && Q(e);
		}, Vt = (e) => {
			D.value = !1, !(K !== null || !e.isPrimary || e.button !== 0 || e.pointerType === "mouse" || !j.value || M.value || T.value !== "Idle") && (e.target.closest("input,textarea,select,button,a,[contenteditable=\"true\"],.win-pivot-header-clipper") || (K = e.pointerId, bt = e.clientX, xt = e.clientY, St = performance.now()));
		}, Ht = (e) => {
			if (e.pointerId !== K) return;
			let t = e.clientX - bt, n = e.clientY - xt;
			if (!q) {
				if (Math.abs(n) > 8 && Math.abs(n) > Math.abs(t)) {
					Q(e);
					return;
				}
				if (Math.abs(t) < 8) return;
				q = !0, _.value?.setPointerCapture(e.pointerId);
			}
			e.preventDefault();
			let r = -Math.sign(t) * (ze.value === "rtl" ? -1 : 1);
			E.value = N.value && (x.value + r < 0 || x.value + r >= F.value.length) ? t * .15 : t;
		}, Ut = (e) => {
			if (e.pointerId !== K) {
				zt();
				return;
			}
			let t = e.clientX - bt, n = Oe.value?.clientWidth ?? 400, r = Math.max(1, performance.now() - St), i = q && (Math.abs(t) >= Math.max(40, Math.min(100, n * .2)) || Math.abs(t) > 12 && Math.abs(t) / r > .5);
			Q(e), i && Z(-Math.sign(t) * (ze.value === "rtl" ? -1 : 1));
		}, Wt = () => {
			let e = v.value, t = y.value;
			!e || !t || (Ne.value = t.scrollWidth > e.clientWidth + 1);
		}, $ = () => {
			G || U || (G = requestAnimationFrame(() => {
				G = 0, Wt(), jt();
			}));
		}, Gt = {
			get SelectedIndex() {
				return x.value;
			},
			set SelectedIndex(e) {
				X(Number(e));
			},
			get SelectedItem() {
				return L(tt.value);
			},
			set SelectedItem(e) {
				let t = F.value.find((t) => lt(t, e));
				t && X(t.index);
			},
			get Items() {
				return F.value.map((e) => L(e));
			},
			get IsLocked() {
				return M.value;
			},
			get IsHeaderItemsCarouselEnabled() {
				return Re.value;
			},
			get ActualWidth() {
				return _.value?.clientWidth ?? 0;
			},
			get ActualHeight() {
				return _.value?.clientHeight ?? 0;
			},
			ContainerFromIndex(e) {
				return ct(F.value[e]);
			},
			IndexFromContainer(e) {
				return F.value.findIndex((t) => lt(t, e));
			},
			Focus() {
				return Ot(), !!b.get(I.value);
			}
		};
		Ce(Gt);
		for (let e of Object.keys(h)) e === "SelectedIndex" || e === "SelectedItem" || (Object.defineProperty(Gt, e, {
			enumerable: !0,
			configurable: !0,
			get: () => k(e),
			set: (t) => {
				Le[e] = t, a(h[e], t, g);
			}
		}), m(() => O(h[e]), () => {
			delete Le[e];
		}));
		m(() => O(h.SelectedIndex), (e) => {
			e !== void 0 && Number.isInteger(Number(e)) && X(Number(e));
		}), m(() => O(h.SelectedItem), (e) => {
			if (e === void 0) return;
			let t = F.value.findIndex((t) => lt(t, e));
			t >= 0 && X(t);
		}), m([j, M], () => {
			Q(), zt(), j.value || (w.value = !1, je.value = null);
		}), m(F, async (e, t = []) => {
			let n = e.map((e) => e.key), r = t.map((e) => e.key), i = t[x.value] ?? null, o = i?.key;
			if (n.length === r.length && n.every((e, t) => e === r[t])) return;
			++H, wt(), Q(), T.value = "Idle", W = null;
			let s = x.value, c = o === void 0 ? -1 : n.indexOf(o);
			if (x.value = c >= 0 ? c : -1, C.value = new Set([...C.value].filter((e) => n.some((t) => t === e))), !n.length) {
				let e = i ? gt(i) : null;
				S.value = null, Ae.value = null, Mt(-1, i), i && (R("PivotItemUnloading", e), R("PivotItemUnloaded", e));
			} else if (c < 0) {
				let t = Number(O(h.SelectedIndex)), r = O(h.SelectedItem), a = r === void 0 ? -1 : e.findIndex((e) => lt(e, r));
				await X(a >= 0 ? a : Math.min(n.length - 1, Math.max(0, Number.isInteger(t) ? t : s)), !1, !1, void 0, i);
			} else S.value = o, c !== s && (Te("update:SelectedIndex", c), a(h.SelectedIndex, c, g));
			$();
		}, { immediate: !0 }), m([
			Re,
			() => k("HeaderTemplate"),
			() => k("Title")
		], () => {
			J(), $();
		}), _e(async () => {
			if (_t = !0, _.value?.addEventListener("click", Ft), _.value && (Pe.value = getComputedStyle(_.value).direction), typeof ResizeObserver < "u") {
				vt = new ResizeObserver(() => {
					J(), $();
				});
				for (let e of [
					_.value,
					v.value,
					y.value
				]) e && vt.observe(e);
			}
			typeof MutationObserver < "u" && y.value && (yt = new MutationObserver($), yt.observe(y.value, {
				childList: !0,
				subtree: !0,
				characterData: !0
			})), window.addEventListener("blur", Q), window.addEventListener("pointerup", Ut), window.addEventListener("pointercancel", Q), document.fonts?.ready.then(() => {
				U || $();
			}), await he(), $();
		}), ve($), ge(() => {
			U = !0, _.value?.removeEventListener("click", Ft), ++H, wt(), Q(), vt?.disconnect(), yt?.disconnect(), G && cancelAnimationFrame(G), window.removeEventListener("blur", Q), window.removeEventListener("pointerup", Ut), window.removeEventListener("pointercancel", Q);
		});
		let Kt = {
			props: h,
			emit: Te,
			instance: g,
			attrs: Ee,
			slots: De,
			rootRef: _,
			headerClipperRef: v,
			headerPanelRef: y,
			itemPresenterRef: Oe,
			headerRefs: b,
			itemRefs: ke,
			selectedIndex: x,
			displayedKey: S,
			focusedKey: Ae,
			hoveredKey: je,
			pressedKey: Me,
			loadedKeys: C,
			headerOverflow: Ne,
			headerPointerOver: w,
			inheritedFlowDirection: Pe,
			animationState: T,
			pointerOffset: E,
			headerHasFocus: Fe,
			keyboardFocus: D,
			focusFollowerBounds: Ie,
			value: O,
			overrides: Le,
			property: k,
			itemOverrides: A,
			enabled: j,
			locked: M,
			carousel: Re,
			usingStaticHeaders: N,
			flowDirection: ze,
			requestedTheme: Be,
			rootAttrs: Ve,
			rootStyle: He,
			templateGridStyle: Ue,
			itemPresenterStyle: We,
			nodes: Ge,
			propertyNodes: P,
			hasTitle: Ke,
			presenterOutlet: qe,
			TitleOutlet: Je,
			LeftHeaderOutlet: Ye,
			RightHeaderOutlet: Xe,
			objectKeys: Ze,
			valueKeys: Qe,
			get nextObjectKey() {
				return $e;
			},
			set nextObjectKey(e) {
				$e = e;
			},
			sourceKey: et,
			items: F,
			selectedRecord: tt,
			selectedKey: I,
			showFocusFollower: nt,
			focusFollowerStyle: rt,
			orderedItems: it,
			uid: at,
			headerId: ot,
			panelId: st,
			sourceOf: L,
			containerOf: ct,
			matchesItem: lt,
			showPreviousButton: ut,
			showNextButton: dt,
			HeaderOutlet: ft,
			ItemsOutlet: pt,
			headerClass: mt,
			setHeaderRef: ht,
			raise: R,
			pivotItemArgs: gt,
			currentHost: z,
			get animations() {
				return B;
			},
			set animations(e) {
				B = e;
			},
			get headerPanelAnimation() {
				return V;
			},
			set headerPanelAnimation(e) {
				V = e;
			},
			get animationToken() {
				return H;
			},
			set animationToken(e) {
				H = e;
			},
			get disposed() {
				return U;
			},
			set disposed(e) {
				U = e;
			},
			get mounted() {
				return _t;
			},
			set mounted(e) {
				_t = e;
			},
			get pendingRequest() {
				return W;
			},
			set pendingRequest(e) {
				W = e;
			},
			get observer() {
				return vt;
			},
			set observer(e) {
				vt = e;
			},
			get mutationObserver() {
				return yt;
			},
			set mutationObserver(e) {
				yt = e;
			},
			get layoutFrame() {
				return G;
			},
			set layoutFrame(e) {
				G = e;
			},
			get pointerId() {
				return K;
			},
			set pointerId(e) {
				K = e;
			},
			get pointerStartX() {
				return bt;
			},
			set pointerStartX(e) {
				bt = e;
			},
			get pointerStartY() {
				return xt;
			},
			set pointerStartY(e) {
				xt = e;
			},
			get pointerStartTime() {
				return St;
			},
			set pointerStartTime(e) {
				St = e;
			},
			get gestureActive() {
				return q;
			},
			set gestureActive(e) {
				q = e;
			},
			cancelContentAnimations: Ct,
			cancelHeaderAnimation: J,
			cancelAnimations: wt,
			reducedMotion: Tt,
			runAnimation: Et,
			applySlideInGroups: Dt,
			get activeDirection() {
				return Y;
			},
			set activeDirection(e) {
				Y = e;
			},
			focusHeader: Ot,
			updateFocusFollower: kt,
			onFocusChanged: At,
			ensureHeaderVisible: jt,
			commitSelection: Mt,
			selectIndex: X,
			moveSelection: Z,
			onHeaderKeyDown: Nt,
			onKeyDown: Pt,
			onRootClick: Ft,
			onHeaderPointerEnter: It,
			onHeaderPointerLeave: Lt,
			onHeaderPressed: Rt,
			clearPressedHeader: zt,
			cancelGesture: Q,
			onLostPointerCapture: Bt,
			onPointerDown: Vt,
			onPointerMove: Ht,
			onPointerUp: Ut,
			updateNavigationButtons: Wt,
			updateLayout: $,
			publicApi: Gt,
			get pivotText() {
				return oe;
			},
			get isHoverPointer() {
				return s;
			}
		};
		return Object.defineProperty(Kt, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), Kt;
	}
});
//#endregion
export { Ce as default };

//# sourceMappingURL=Pivot.vue_vue_type_script_setup_true_lang.js.map