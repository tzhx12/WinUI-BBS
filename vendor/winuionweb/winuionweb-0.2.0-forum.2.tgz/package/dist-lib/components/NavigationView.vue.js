import { resolveAcrylicResource as e, useAcrylicBrushStyle as t } from "./AcrylicBrush.js";
import { materializeXamlVNode as n, normalizeXamlNodes as r, resolveXamlHandler as i, resolveXamlResourceObject as a, resolveXamlValue as o, updateXamlBinding as s, xamlNameScopeKey as c, xamlScopeKey as l } from "./xamlRuntime.js";
import { vAcrylicBrush as u } from "./acrylicBrushVisual.js";
import { vThemeShadow as d } from "./themeShadowVisual.js";
import f from "../_virtual/_plugin-vue_export-helper.js";
import { resolveSymbolGlyph as ee } from "./symbolGlyphs.js";
import te from "./Viewbox.vue.js";
import { useI18n as ne } from "./i18n/index.js";
import { xamlResourceDictionaryKey as re } from "./Page.vue_vue_type_script_lang.js";
import ie from "./TextBlock.vue.js";
import { createAnimatedIconSource as ae } from "./animatedIconVisuals.js";
import oe from "./AnimatedIcon.vue.js";
import se from "./ScrollViewer.vue.js";
import ce from "./ContentPresenter.vue.js";
import { useAnimatedIconInput as le } from "./animatedIconInput.js";
import ue from "./Flyout.vue.js";
import { FontIconSource as de } from "./IconSource.js";
import { captureFrameNavigationCommit as fe, hasPendingRouteNavigation as pe, navigationInputFrozen as me, pendingNavigationCompletion as he, pendingRouteNavigationCompletion as ge } from "./frameNavigationRuntime.js";
import _e from "./InfoBadge.vue.js";
import { NavigationViewAutoSuggestBox as ve, NavigationViewContent as ye, NavigationViewContentOverlay as be, NavigationViewFooterMenuItems as xe, NavigationViewFooterMenuItemsSource as Se, NavigationViewHeader as Ce, NavigationViewHeaderTemplate as p, NavigationViewMenuItemContainerStyle as we, NavigationViewMenuItemContainerStyleSelector as Te, NavigationViewMenuItemTemplate as Ee, NavigationViewMenuItemTemplateSelector as De, NavigationViewMenuItems as Oe, NavigationViewMenuItemsSource as m, NavigationViewPaneCustomContent as h, NavigationViewPaneFooter as g, NavigationViewPaneHeader as ke, NavigationViewPaneToggleButtonStyle as _, NavigationViewProperties_exports as Ae, getNavigationViewProperty as je, navigationItemType as Me, navigationVNodeChildren as v, navigationViewItemRendererKey as Ne } from "./NavigationViewProperties.js";
import { createEntranceNavigationTransitionInfo as Pe, createSlideNavigationTransitionInfo as Fe } from "../utils/navigationTransitionInfo.js";
/* empty css                                                   */
import { Fragment as Ie, computed as y, createBlock as Le, createCommentVNode as b, createElementBlock as x, createElementVNode as S, createVNode as C, defineComponent as Re, getCurrentInstance as ze, h as w, inject as Be, isVNode as Ve, markRaw as He, mergeProps as Ue, nextTick as T, normalizeClass as We, normalizeStyle as Ge, onBeforeUnmount as Ke, onMounted as qe, openBlock as E, provide as Je, reactive as Ye, ref as D, shallowReactive as Xe, toDisplayString as Ze, toRaw as Qe, useAttrs as $e, useSlots as et, vShow as tt, watch as O, withCtx as nt, withDirectives as k } from "vue";
var rt = /*@__PURE__*/ Object.assign({
	MenuItems: Oe,
	MenuItemsSource: m,
	FooterMenuItems: xe,
	FooterMenuItemsSource: Se,
	Header: Ce,
	HeaderTemplate: p,
	Content: ye,
	PaneHeader: ke,
	PaneFooter: g,
	PaneCustomContent: h,
	AutoSuggestBox: ve,
	ContentOverlay: be,
	MenuItemTemplate: Ee,
	MenuItemTemplateSelector: De,
	MenuItemContainerStyle: we,
	MenuItemContainerStyleSelector: Te,
	PaneToggleButtonStyle: _
}, {
	__name: "NavigationView",
	props: {
		PaneDisplayMode: {
			type: String,
			default: "Auto"
		},
		SelectedItem: {
			type: [
				Object,
				String,
				Number
			],
			default: null
		},
		MenuItems: {
			type: [Array, String],
			default: () => []
		},
		MenuItemsSource: {
			type: [
				Array,
				Object,
				String
			],
			default: null
		},
		FooterMenuItems: {
			type: [Array, String],
			default: () => []
		},
		FooterMenuItemsSource: {
			type: [
				Array,
				Object,
				String
			],
			default: null
		},
		IsBackButtonVisible: {
			type: String,
			default: "Auto"
		},
		IsBackEnabled: {
			type: [Boolean, String],
			default: !1
		},
		IsSettingsVisible: {
			type: [Boolean, String],
			default: !0
		},
		IsPaneToggleButtonVisible: {
			type: [Boolean, String],
			default: !0
		},
		IsPaneOpen: {
			type: [Boolean, String],
			default: !0
		},
		IsPaneVisible: {
			type: [Boolean, String],
			default: !0
		},
		OpenPaneLength: {
			type: [Number, String],
			default: 320
		},
		CompactPaneLength: {
			type: [Number, String],
			default: 48
		},
		CompactModeThresholdWidth: {
			type: [Number, String],
			default: 641
		},
		ExpandedModeThresholdWidth: {
			type: [Number, String],
			default: 1008
		},
		PaneTitle: {
			type: String,
			default: ""
		},
		Header: {
			type: [
				String,
				Number,
				Object
			],
			default: ""
		},
		HeaderTemplate: {
			type: [
				Object,
				Function,
				String
			],
			default: null
		},
		PaneToggleButtonStyle: {
			type: [Object, String],
			default: null
		},
		MenuItemTemplate: {
			type: [
				Object,
				Function,
				String
			],
			default: null
		},
		MenuItemTemplateSelector: {
			type: [
				Object,
				Function,
				String
			],
			default: null
		},
		MenuItemContainerStyle: {
			type: [Object, String],
			default: null
		},
		MenuItemContainerStyleSelector: {
			type: [
				Object,
				Function,
				String
			],
			default: null
		},
		AutoSuggestBox: {
			type: [Object, String],
			default: null
		},
		PaneFooter: {
			type: [Object, String],
			default: null
		},
		PaneHeader: {
			type: [Object, String],
			default: null
		},
		PaneCustomContent: {
			type: [Object, String],
			default: null
		},
		ContentOverlay: {
			type: [Object, String],
			default: null
		},
		AlwaysShowHeader: {
			type: [Boolean, String],
			default: !0
		},
		SelectionFollowsFocus: {
			type: String,
			default: "Disabled"
		},
		ShoulderNavigationEnabled: {
			type: String,
			default: "Never"
		},
		OverflowLabelMode: {
			type: String,
			default: "MoreLabel"
		},
		IsTitleBarAutoPaddingEnabled: {
			type: [Boolean, String],
			default: !0
		},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		IsTabStop: {
			type: [Boolean, String],
			default: !1
		},
		Background: {
			type: [String, Object],
			default: "Transparent"
		},
		Content: {
			type: null,
			default: void 0
		},
		Width: {
			type: [String, Number],
			default: ""
		},
		Height: {
			type: [String, Number],
			default: ""
		},
		MinWidth: {
			type: [String, Number],
			default: ""
		},
		MinHeight: {
			type: [String, Number],
			default: ""
		},
		MaxWidth: {
			type: [String, Number],
			default: ""
		},
		MaxHeight: {
			type: [String, Number],
			default: ""
		},
		Margin: {
			type: [String, Number],
			default: ""
		},
		HorizontalAlignment: {
			type: String,
			default: ""
		},
		VerticalAlignment: {
			type: String,
			default: ""
		}
	},
	emits: [
		"update:SelectedItem",
		"update:IsPaneOpen",
		"SelectionChanged",
		"ItemInvoked",
		"DisplayModeChanged",
		"BackRequested",
		"PaneOpening",
		"PaneOpened",
		"PaneClosing",
		"PaneClosed",
		"Expanding",
		"Collapsed"
	],
	setup(f, { expose: ve, emit: ye }) {
		let { t: be } = ne(), xe = et(), Se = $e(), Ce = le(), p = le(), we = ae("AnimatedBackVisualSource"), Te = ae("AnimatedGlobalNavigationButtonVisualSource"), Ee = ae("AnimatedSettingsVisualSource"), De = ae("AnimatedChevronUpDownSmallVisualSource"), Oe = le(!1, (e, t) => {
			let n = t.dataset.expanded === "true";
			return `${e === "Disabled" ? "Normal" : e}${n ? "On" : "Off"}`;
		});
		Je(l, {
			...Be(l, {}),
			backVisualSource: we,
			hamburgerVisualSource: Te
		});
		let m = f, h = ze(), g = Ye({}), ke = new Set([
			"OpenPaneLength",
			"CompactPaneLength",
			"CompactModeThresholdWidth",
			"ExpandedModeThresholdWidth"
		]), _ = new Proxy(m, { get(e, t) {
			let n = t in g ? g[t] : o(Reflect.get(e, t), h);
			return ke.has(t) ? Math.max(Number(n) || 0, 0) : n;
		} }), Le = (e) => e === "" || e == null ? "" : typeof e == "string" && e.trim() !== "" && !Number.isNaN(Number(e.trim())) ? `${Number(e.trim())}px` : typeof e == "number" ? `${e}px` : e, b = (e) => {
			if (e === "" || e == null) return "";
			let t = String(e).split(",").map((e) => Le(e.trim()));
			return t.length === 1 ? t[0] : t.length === 2 ? `${t[1]} ${t[0]}` : t.length === 4 ? `${t[1]} ${t[2]} ${t[3]} ${t[0]}` : String(e);
		}, x = (e) => ({
			Left: "start",
			Center: "center",
			Right: "end",
			Stretch: "stretch",
			Top: "start",
			Bottom: "end"
		})[e] ?? "", S = (e) => e && typeof e == "object" ? e.Tag ?? e.Name : e, C = /* @__PURE__ */ new WeakMap(), Ue = 0, We = (e, t) => {
			if (!e || typeof e != "object") return S(e) ?? t;
			let n = Qe(e);
			return C.has(n) || (Ue += 1, C.set(n, `nvi-${Ue}`)), C.get(n);
		}, Ge = (e, t = "item") => {
			let n = e?.Type ?? "Item", r = n === "NavigationViewItemHeader" ? "Header" : n === "NavigationViewItemSeparator" ? "Separator" : n, i = e?.MenuItemsSource ?? e?.MenuItems, a = e?.__IconNodes ?? (Ve(e?.Icon) ? [e.Icon] : void 0), o = a?.[0]?.props;
			return {
				value: We(e, `__${String(r).toLowerCase()}-${t}`),
				tag: S(e),
				label: e?.Content ?? (typeof e == "string" || typeof e == "number" ? String(e) : ""),
				icon: Ve(e?.Icon) ? "" : ee(e?.Icon ?? o?.Symbol) || e?.Icon?.Glyph || o?.Glyph || e?.Icon || "",
				iconNodes: a,
				contentNodes: e?.__ContentNodes,
				infoBadge: e?.InfoBadge ?? null,
				automationName: e?.["AutomationProperties.Name"] ?? e?.AutomationProperties?.Name ?? "",
				tooltip: e?.["ToolTipService.ToolTip"] ?? "",
				type: r,
				children: Array.isArray(i) ? i.map((e, n) => Ge(e, `${t}-${n}`)) : null,
				isEnabled: e?.IsEnabled !== !1 && e?.IsEnabled !== "False" && _.IsEnabled !== !1,
				selectsOnInvoked: e?.SelectsOnInvoked !== !1 && e?.SelectsOnInvoked !== "False",
				hasChildren: !!e?.HasUnrealizedChildren || Array.isArray(i) && i.length > 0,
				source: e?.__DataItem ?? e,
				container: e
			};
		}, E = (e) => (Array.isArray(e) ? e : [e]).flatMap((e) => e?.type === Ie ? E(v(e)) : e ? [e] : []), Ze = () => E(xe.default?.() ?? []), tt = Be(c, null), nt = Be(re, null), k = (e) => Ze().filter((t) => je(t) === e).flatMap(v), rt = (e) => e.charAt(0).toUpperCase() + e.slice(1), it = (e) => _[rt(e)], at = (e) => rt(e) in g ? it(e) !== null && it(e) !== void 0 && it(e) !== "" : k(e).length > 0 || it(e) !== null && it(e) !== void 0 && it(e) !== "", ot = Re({
			props: { Property: {
				type: String,
				required: !0
			} },
			setup(e) {
				return () => {
					let t = rt(e.Property) in g ? [] : k(e.Property);
					if (t.length) return w(Ie, r(t, h));
					let i = it(e.Property);
					if (Ve(i)) return w(Ie, r([i], h));
					if (e.Property === "header") {
						let e = ht(k("headerTemplate")[0] ?? mt(m.HeaderTemplate));
						if (e.length) return w(Ie, r(e.map((e) => n(e, i, h)), h));
					}
					return i != null && typeof i != "object" ? w(ie, { Text: String(i) }) : null;
				};
			}
		}), st = Re({ setup() {
			return () => w(Ie, r(Ze().filter((e) => !je(e) && !Me(e)), h));
		} }), ct = /* @__PURE__ */ new Map(), lt = /* @__PURE__ */ new WeakMap(), ut = (e, t) => e?.length === t.length && t.every((t, n) => {
			let r = e[n];
			if (t === r) return !0;
			if (t?.type !== r?.type) return !1;
			let i = t?.props ?? {}, a = r?.props ?? {}, o = Object.keys(i).filter((e) => !e.startsWith("on") && !["ref", "key"].includes(e));
			return o.length !== Object.keys(a).filter((e) => !e.startsWith("on") && !["ref", "key"].includes(e)).length || o.some((e) => i[e] !== a[e]) ? !1 : typeof t.children == "string" ? t.children === r.children : ut(v(r), v(t));
		}), dt = (e, t) => {
			let n = Me(e);
			if (!n) return null;
			let r = e.props ?? {}, i = r["x:Name"] ?? r["data-xaml-ref"], a = i || r.key || t, s = ct.get(a);
			if (!s) {
				let e = {}, t = Xe({});
				s = He(new Proxy(e, {
					get(e, n) {
						let r = t[n];
						return r && r.original === e[n] ? r.value : e[n];
					},
					set(e, n, r) {
						let i = t[n];
						return (!i || i.value !== r || i.original !== e[n]) && (t[n] = {
							original: e[n],
							value: r
						}), !0;
					},
					ownKeys(e) {
						return [...new Set([...Reflect.ownKeys(e), ...Reflect.ownKeys(t)])];
					},
					getOwnPropertyDescriptor(e, n) {
						return Reflect.getOwnPropertyDescriptor(e, n) ?? (n in t ? {
							configurable: !0,
							enumerable: !0
						} : void 0);
					}
				})), ct.set(a, s), lt.set(s, e);
			}
			let c = lt.get(s), l = /* @__PURE__ */ new Set();
			for (let [e, t] of Object.entries(r)) e.startsWith("on") || [
				"ref",
				"key",
				"class",
				"style"
			].includes(e) || (l.add(e), c[e] = o(t, h));
			for (let e of Object.keys(c)) !l.has(e) && ![
				"Type",
				"Tag",
				"MenuItems",
				"__DataItem",
				"__IconNodes",
				"__ContentNodes",
				"InfoBadge"
			].includes(e) && delete c[e];
			c.Type = n, c.Tag ??= i || t;
			let u = v(e);
			for (let e of u) {
				let n = je(e);
				if (n === "icon" || n === "content") {
					let t = n === "icon" ? "__IconNodes" : "__ContentNodes", r = v(e);
					ut(c[t], r) || (c[t] = He(r));
				} else if (n === "infoBadge") {
					let t = v(e).find((e) => {
						let t = e.type;
						return (typeof t == "string" ? t : t?.name ?? t?.__name) === "InfoBadge";
					});
					if (t) {
						let e = {};
						for (let [n, r] of Object.entries(t.props ?? {})) {
							if (n.startsWith("on") || [
								"ref",
								"key",
								"class",
								"style"
							].includes(n)) continue;
							let t = o(r, h);
							t !== void 0 && (e[n] = ["Value", "Opacity"].includes(n) ? Number(t) : t);
						}
						c.InfoBadge = e;
					}
				} else if (n === "menuItems") c.MenuItems = v(e).map((e, n) => dt(e, `${t}-${n}`)).filter(Boolean);
				else if (n === "menuItemsSource") {
					let t = v(e)[0];
					c.MenuItemsSource = t?.props?.ItemsSource ? o(t.props.ItemsSource, h) : [];
				}
			}
			let d = u.filter((e) => !je(e) && !Me(e));
			return d.length && !c.__ContentNodes && (c.__ContentNodes = He(d)), i && tt && tt[i] !== s && (tt[i] = s), s;
		}, ft = (e) => Ze().filter((t) => je(t) === e).flatMap(v).map((t, n) => dt(t, `${e}-${n}`)).filter(Boolean), pt = (e, t) => Array.isArray(e) && e.length ? e : Array.isArray(t) ? t : [], mt = (e) => {
			if (typeof e != "string") return e;
			let t = e.match(/^\{StaticResource\s+([^}]+)\}$/)?.[1]?.trim() ?? e.match(/^var\(--([^,)]+)/)?.[1];
			return t ? nt?.[t] ?? a(t, h) : e;
		}, ht = (e) => Array.isArray(e) ? e.flatMap(ht) : Ve(e) ? (typeof e.type == "string" ? e.type : e.type?.name ?? e.type?.__name) === "DataTemplate" ? v(e) : [e] : [], gt = (e, t) => {
			let r = k("menuItemTemplate")[0] ?? mt(m.MenuItemTemplate), i = k("menuItemTemplateSelector")[0] ?? mt(m.MenuItemTemplateSelector);
			if (typeof i == "function") r = i(e);
			else if (i?.SelectTemplate) r = i.SelectTemplate(e);
			else if (i?.SelectTemplateCore) r = i.SelectTemplateCore(e);
			else if (Ve(i)) {
				let e = v(i).find((e) => je(e) === "itemTemplate");
				r = e ? v(e)[0] : r;
			} else i?.ItemTemplate && (r = mt(i.ItemTemplate));
			let a = ht(r).map((t) => n(t, e, h)).find((e) => Me(e));
			if (!a) return e;
			let o = dt(a, t);
			return lt.get(o).__DataItem = e, o;
		}, _t = y(() => {
			let e = ft("menuItems");
			return (e.length ? e : pt(_.MenuItems, _.MenuItemsSource).map((e, t) => gt(e, `menu-source-${We(e, t)}`))).map((e, t) => Ge(e, `menu-${t}`));
		}), vt = y(() => {
			let e = ft("footerMenuItems");
			return (e.length ? e : pt(_.FooterMenuItems, _.FooterMenuItemsSource).map((e, t) => gt(e, `footer-source-${We(e, t)}`))).map((e, t) => Ge(e, `footer-${t}`));
		}), yt = D(_.SelectedItem), bt = (e) => e.flatMap((e) => [e, ...bt(e.children ?? [])]), xt = y(() => bt([..._t.value, ...vt.value])), St = (e) => {
			if (e?.IsSettingsItem || S(e) === "settings") return "settings";
			if (e && typeof e == "object") {
				let t = Qe(e), n = xt.value.find((n) => n.source === e || Qe(n.source) === t || Qe(n.container) === t);
				if (n) return n.value;
			}
			let t = S(e);
			return xt.value.find((e) => e.tag === t)?.value ?? t;
		}, A = y(() => St(yt.value)), j = D(A.value), Ct = (e) => {
			for (let t of xt.value) t.container && typeof t.container == "object" && t.container.IsSelected !== (t.value === e) && (t.container.IsSelected = t.value === e);
		}, M = {
			get paneDisplayMode() {
				return _.PaneDisplayMode;
			},
			get selectedValue() {
				return A.value;
			},
			get menuItems() {
				return _t.value;
			},
			get footerItems() {
				return vt.value;
			},
			get isBackButtonVisible() {
				return _.IsBackButtonVisible;
			},
			get isSettingsVisible() {
				return _.IsSettingsVisible;
			},
			get isPaneToggleButtonVisible() {
				return _.IsPaneToggleButtonVisible;
			},
			get isPaneOpen() {
				return _.IsPaneOpen;
			},
			get openPaneLength() {
				return _.OpenPaneLength;
			},
			get compactPaneLength() {
				return _.CompactPaneLength;
			},
			get compactModeThresholdWidth() {
				return _.CompactModeThresholdWidth;
			},
			get expandedModeThresholdWidth() {
				return _.ExpandedModeThresholdWidth;
			},
			get paneTitle() {
				return _.PaneTitle;
			},
			get header() {
				return _.Header;
			},
			get settingsValue() {
				return "settings";
			},
			get settingsLabel() {
				return be("text.settings");
			},
			get settingsIcon() {
				return "";
			}
		}, wt = y(() => M.settingsLabel), Tt = ye, N = (e, t) => {
			if (e.startsWith("update:")) {
				Tt(e, t);
				return;
			}
			Tt(e, qr, t), Se[e] !== void 0 && i(Se[e], h)?.(qr, t);
		}, P = D(!_.IsPaneOpen || _.PaneDisplayMode === "LeftMinimal"), F = D(""), Et = D(null), I = D(null), L = D(null), Dt = D(null), Ot = D(null), kt = D(null), At = D(null), jt = D(null), Mt = D(null), Nt = D(null), Pt = D(null), Ft = D({ opacity: "0" }), It = D(!1), Lt = D(4), Rt = D(null), R = Ye({}), zt = Ye({}), Bt = Ye({}), z = D(!1), Vt = D(null), Ht = D(null), Ut = D(!1), Wt = D(null), Gt = D([]), Kt = 0, qt = D(Infinity), Jt = D({}), Yt = D(40), Xt = D(typeof window > "u" ? M.expandedModeThresholdWidth : window.innerWidth), Zt = y(() => M.paneDisplayMode), Qt = y(() => {
			if (Zt.value !== "Auto") return Zt.value;
			let e = Xt.value || (typeof window > "u" ? M.expandedModeThresholdWidth : window.innerWidth);
			return e >= M.expandedModeThresholdWidth ? "Left" : e >= M.compactModeThresholdWidth ? "LeftCompact" : "LeftMinimal";
		}), B = y(() => Qt.value === "Top"), $t = y(() => B.value ? "BottomEdgeAlignedLeft" : "RightEdgeAlignedTop"), V = y(() => Qt.value === "LeftMinimal"), en = y(() => Qt.value === "LeftCompact"), tn = y(() => V.value || en.value), nn = y(() => {
			let e = Number(o("{ThemeResource PaneOverlayShadowDepth}", h));
			return Number.isFinite(e) ? e : 16;
		}), rn = y(() => tn.value && !P.value && _.IsPaneVisible !== !1), an = D(!1), on = null;
		O(rn, (e) => {
			on && clearTimeout(on), on = null, e ? an.value = !0 : an.value && (on = setTimeout(() => {
				an.value = !1, on = null;
			}, 120));
		}, { immediate: !0 });
		let sn = y(() => !V.value || !P.value || F.value === "closing"), H = y(() => !B.value && P.value && !V.value), cn = y(() => !H.value && (!V.value || !P.value)), ln = (e) => {
			let t = e?.tooltip || (!B.value && H.value ? e?.label : "");
			return {
				tabindex: e?.isEnabled === !1 ? -1 : 0,
				...e?.automationName ? { "aria-label": e.automationName } : {},
				...t ? { "ToolTipService.ToolTip": t } : {}
			};
		}, un = y(() => V.value && P.value && F.value === "closing"), dn = y(() => sn.value && !H.value), fn = y(() => dn.value && !P.value), pn = y(() => fn.value), mn = y(() => be(P.value ? "text.open-navigation" : "text.close-navigation")), hn = y(() => B.value || V.value ? "Minimal" : en.value ? "Compact" : "Expanded"), gn = y(() => M.isSettingsVisible), _n = y(() => M.isPaneToggleButtonVisible), vn = y(() => M.paneTitle), yn = y(() => M.header), bn = y(() => at("header") && (_.AlwaysShowHeader || !B.value && hn.value === "Minimal")), U = y(() => M.settingsValue), xn = y(() => M.settingsLabel), Sn = y(() => M.settingsIcon), Cn = y(() => M.isBackButtonVisible === "Visible" ? !0 : M.isBackButtonVisible !== "Collapsed"), wn = y(() => Cn.value && !B.value), Tn = y(() => V.value || en.value ? {
			openDurationMs: 350,
			closeDurationMs: 120,
			easing: "cubic-bezier(0.1, 0.9, 0.2, 1)"
		} : {
			openDurationMs: 200,
			closeDurationMs: 200,
			easing: "cubic-bezier(0, 0.35, 0.15, 1)"
		}), En = (e, t = Tn.value) => e ? t.closeDurationMs : t.openDurationMs, Dn = t(() => {
			if (V.value) return "Transparent";
			let t = tn.value && (!P.value || F.value === "closing") ? "NavigationViewDefaultPaneBackground" : "NavigationViewExpandedPaneBackground";
			return e(t, h) ?? `{ThemeResource ${t}}`;
		}, h), On = t(() => V.value && (!P.value || F.value === "closing") ? "{ThemeResource NavigationViewDefaultPaneBackground}" : "Transparent", h), kn = t(() => m.Background, h), An = y(() => ({
			"--win-nav-open-pane-length": `${Math.max(M.compactPaneLength, Math.min(M.openPaneLength, Xt.value || M.openPaneLength))}px`,
			"--win-nav-compact-pane-length": `${M.compactPaneLength}px`,
			"--win-nav-header-margin-left": `${V.value ? Math.max(56, Number(M.compactPaneLength) + 8, (_n.value ? 40 : 0) + (wn.value ? 40 : 0) - 24) : 56}px`,
			"--win-nav-pane-duration": `${En(P.value)}ms`,
			"--win-nav-pane-open-duration": `${Tn.value.openDurationMs}ms`,
			"--win-nav-pane-close-duration": `${Tn.value.closeDurationMs}ms`,
			"--win-nav-pane-easing": Tn.value.easing
		})), jn = y(() => {
			let e = {
				...An.value,
				...kn.value
			};
			return _.Width !== "" && (e.width = Le(_.Width)), _.Height !== "" && (e.height = Le(_.Height)), _.MinWidth !== "" && (e.minWidth = Le(_.MinWidth)), _.MinHeight !== "" && (e.minHeight = Le(_.MinHeight)), _.MaxWidth !== "" && (e.maxWidth = Le(_.MaxWidth)), _.MaxHeight !== "" && (e.maxHeight = Le(_.MaxHeight)), _.Margin !== "" && (e.margin = b(_.Margin)), _.HorizontalAlignment && (e.justifySelf = x(_.HorizontalAlignment)), _.VerticalAlignment && (e.alignSelf = x(_.VerticalAlignment)), e;
		}), Mn = y(() => [
			B.value ? "is-top" : "is-left",
			tn.value ? "is-overlay-left" : "",
			V.value ? "is-left-minimal" : "",
			en.value ? "is-left-compact" : "",
			_.IsPaneVisible ? "" : "is-pane-hidden"
		]), W = {}, Nn = {}, Pn = null, G = null, K = !1, Fn = null, In = null, Ln = null, q = !1, Rn = 0, zn = null, Bn = null, Vn = null, Hn = null, Un = null, Wn = null, Gn = !1, J = null, Kn = 0, qn = _.IsPaneOpen === !1, Jn = !1, Yn = -Infinity, Xn = 0, Zn = 0, Qn = null, $n = !1, er = null, tr = null, nr = y(() => _.IsBackEnabled && _.IsEnabled), rr = "cubic-bezier(0.1, 0.9, 0.2, 1)", ir = (e) => {
			let t = 0, n = 0, r = e;
			for (; r;) t += r.offsetLeft || 0, n += r.offsetTop || 0, r = r.offsetParent;
			let i = e?.parentElement;
			for (; i;) t -= i.scrollLeft || 0, n -= i.scrollTop || 0, i = i.parentElement;
			return {
				left: t,
				top: n
			};
		}, ar = (e) => {
			let t = ir(e);
			return {
				left: t.left,
				top: t.top,
				width: e.offsetWidth || 1,
				height: e.offsetHeight || 1
			};
		}, or = (e, t, n = ar(t)) => {
			let r = ir(e), i = r.left - n.left, a = r.top - n.top;
			return {
				left: i,
				right: i + e.offsetWidth,
				top: a,
				bottom: a + e.offsetHeight
			};
		}, sr = (e, t, n = ar(t)) => {
			let r = or(e, t, n), i = e.parentElement;
			for (; i && I.value?.contains(i);) {
				let e = getComputedStyle(i);
				if (e.display === "none" || e.visibility === "hidden") return r.right = r.left, r.bottom = r.top, r;
				let a = or(i, t, n);
				e.overflowX !== "visible" && (r.left = Math.max(r.left, a.left), r.right = Math.min(r.right, a.right)), e.overflowY !== "visible" && (r.top = Math.max(r.top, a.top), r.bottom = Math.min(r.bottom, a.bottom)), i = i.parentElement;
			}
			return r;
		}, cr = (e, t) => {
			let n = or(e, t);
			return B.value ? {
				x: (n.left + n.right) / 2 - 8,
				y: 0
			} : {
				x: $r(e) - 4,
				y: (n.top + n.bottom) / 2 - 8
			};
		}, lr = () => {
			let e = Dt.value, t = e?.querySelector(".win-nav-indicator");
			t?.getAnimations().forEach((e) => e.cancel()), t && (t.style.opacity = "0", t.style.translate = ""), e && fr(e, B.value ? "x" : "y", null), Bn && (Bn.source = null, Bn.sourceSnapshot = null);
		}, ur = () => {
			let e = Bn, t = L.value, n = Dt.value;
			if (!(!e || !t || !n)) for (let [r, i, a] of [[
				e.target,
				t,
				e.targetPosition
			], [
				e.source,
				n,
				e.sourcePosition
			]]) {
				if (i === n && e.sourceSnapshot) {
					let t = i.querySelector(".win-nav-indicator");
					if (t.style.translate = "", !r || !I.value?.contains(r)) {
						lr();
						continue;
					}
					let n = sr(r, i), a = e.sourceSnapshot.clip, o = {
						left: Math.max(a.left, n.left),
						right: Math.min(a.right, n.right),
						top: Math.max(a.top, n.top),
						bottom: Math.min(a.bottom, n.bottom)
					};
					o.left >= o.right || o.top >= o.bottom ? lr() : fr(i, e.axis, o);
					continue;
				}
				if (!r || !I.value?.contains(r)) {
					fr(i, e.axis, null);
					continue;
				}
				let t = cr(r, i), o = i.querySelector(".win-nav-indicator");
				o.style.translate = `${t.x - a.x}px ${t.y - a.y}px`;
				let s = sr(r, i);
				i === n && (s.left >= s.right || s.top >= s.bottom) ? lr() : fr(i, e.axis, s);
			}
		}, dr = (e) => {
			e.style.maskImage = "", e.style.maskSize = "", e.style.maskPosition = "", e.style.maskRepeat = "", e.style.removeProperty("-webkit-mask-image"), e.style.removeProperty("-webkit-mask-size"), e.style.removeProperty("-webkit-mask-position"), e.style.removeProperty("-webkit-mask-repeat");
		}, fr = (e, t, n) => {
			let r = ar(e);
			if (dr(e), !n) {
				e.style.clipPath = "inset(0 100% 0 0)";
				return;
			}
			let i = Math.max(0, Math.min(r.width, n.left)), a = Math.max(i, Math.min(r.width, n.right)), o = t === "x" ? 0 : Math.max(0, Math.min(r.height, n.top)), s = t === "x" ? r.height : Math.max(o, Math.min(r.height, n.bottom));
			e.style.clipPath = `inset(${o}px ${r.width - a}px ${r.height - s}px ${i}px)`;
		}, pr = (e, t) => {
			let n = Ft.value || {};
			for (let r of Object.keys(n)) r in t || (e.style[r] = "");
			for (let [n, r] of Object.entries(t)) e.style[n] = r;
			Ft.value = t;
		}, mr = (e) => {
			Rn += 1, e?.getAnimations().forEach((e) => e.cancel());
			let t = Dt.value?.querySelector(".win-nav-indicator");
			return t?.getAnimations().forEach((e) => e.cancel()), t && (t.style.opacity = "0", t.style.translate = ""), Vn && cancelAnimationFrame(Vn), Vn = null, Bn = null, Rn;
		}, hr = y(() => {
			let e = {};
			for (let t of xt.value) if (t.children) for (let n of t.children) e[n.value] = t.value;
			return e;
		}), gr = D(void 0), _r = y(() => {
			let e = gr.value === void 0 ? M.selectedValue : gr.value, t = Y(e);
			if (t) {
				for (; Y(t.value);) t = Y(t.value);
				return t.value;
			}
			return M.menuItems.some((t) => t.value === e) ? e : null;
		}), vr = (e) => {
			let t = Jt.value[e];
			if (Number.isFinite(t) && t > 0) return t;
			let n = M.menuItems.find((t) => t.value === e);
			if (!n) return 84;
			let r = String(n.label || "").length * 7.5, i = n.icon ? 56 : 32, a = n.infoBadge ? 28 : 0, o = n.children ? n.icon ? 24 : 28 : 0;
			return Math.ceil(r + i + a + o);
		}, yr = (e) => e.length ? e.reduce((e, t) => e + vr(t), 0) : 0, br = y(() => {
			if (!B.value) return {
				visibleValues: M.menuItems.map((e) => e.value),
				overflowValues: []
			};
			let e = M.menuItems.map((e) => e.value), t = qt.value;
			if (!Number.isFinite(t) || yr(e) <= t) return {
				visibleValues: e,
				overflowValues: []
			};
			let n = _r.value, r = e.includes(n) ? n : e[0], i = Yt.value, a = Math.max(0, t - i), o = [];
			for (let t of e) for ((yr([...o, t]) <= a || t === r) && o.push(t); yr(o) > a && o.length > 1;) {
				let e = [...o].reverse().findIndex((e) => e !== r);
				if (e < 0) break;
				o.splice(o.length - 1 - e, 1);
			}
			r && !o.includes(r) && (o = [r]);
			let s = new Set(o);
			return {
				visibleValues: o,
				overflowValues: e.filter((e) => !s.has(e))
			};
		}), xr = y(() => {
			if (!B.value) return M.menuItems;
			let e = new Set(br.value.visibleValues);
			return M.menuItems.filter((t) => e.has(t.value));
		}), Sr = y(() => {
			if (!B.value) return [];
			let e = new Set(br.value.overflowValues);
			return M.menuItems.filter((t) => e.has(t.value));
		}), Cr = (e) => e.children ? bt(e.children).some((e) => e.value === j.value) : !1, Y = (e) => xt.value.find((t) => t.children?.some((t) => t.value === e)), X = (e) => xt.value.find((t) => t.value === e) ?? null, wr = {
			get Content() {
				return wt.value;
			},
			get IsSelected() {
				return j.value === M.settingsValue;
			},
			set IsSelected(e) {
				Z || !!e === wr.IsSelected || (e ? Lr(M.settingsValue, {
					invoked: !1,
					isSettings: !0
				}) : j.value === M.settingsValue && (qr.SelectedItem = null));
			},
			Tag: M.settingsValue,
			Icon: M.settingsIcon,
			IsSettingsItem: !0
		}, Tr = () => wr, Er = (e, t = !1) => {
			if (t || e === U.value) return M.menuItems.length + M.footerItems.length;
			let n = Y(e), r = n && B.value ? n.value : e;
			return [...M.menuItems, ...M.footerItems].findIndex((e) => e.value === r);
		}, Dr = (e, t = !1) => {
			if (!B.value) return Pe();
			let n = Er(A.value, A.value === U.value), r = Er(e, t);
			return n < 0 || r < 0 || n === r ? Pe() : Fe(r > n ? "FromRight" : "FromLeft");
		}, Z = null, Or = 0, Q = !1, kr = null, Ar = null, jr = null, Mr = () => {
			if (jr && cancelAnimationFrame(jr), jr = null, Rt.value = null, !Ar) return;
			Ar.classList.remove("is-pressed"), p.PointerReleased({ currentTarget: Ar });
			let e = Ar.querySelector(".win-nav-group-chevron");
			e && Oe.PointerReleased({ currentTarget: e }), Ar = null;
		}, Nr = (e, t, n) => {
			let r = kr;
			kr = {
				element: e,
				value: zr(e),
				pointerType: t.pointerType ?? "mouse"
			};
			try {
				return n();
			} finally {
				kr = r;
			}
		}, Pr = (e, t) => {
			if (Mr(), !e || Q) return;
			let n = e.element?.isConnected ? e.element : W[e.value] ?? W[t];
			if (!n || n.classList.contains("is-disabled")) return;
			Ar = n, Rt.value = zr(n), n.classList.add("is-pressed");
			let r = {
				currentTarget: n,
				button: 0,
				pointerType: e.pointerType
			};
			n.matches(":hover") && p.PointerEntered(r), n.classList.contains("win-nav-settings-item") || p.PointerPressed(r);
			let i = n.querySelector(".win-nav-group-chevron");
			i && Oe.PointerPressed({
				...r,
				currentTarget: i
			}), jr = requestAnimationFrame(() => {
				jr = requestAnimationFrame(Mr);
			});
		}, Fr = async (e) => {
			try {
				let t = await e.commit.completion;
				if (Q || Z !== e) return;
				if (!t) {
					let t = (e.boundRouteNavigation || e.commit.hasRouteNavigation) && m.SelectedItem != null, n = t ? o(m.SelectedItem, h) : e.previousItem;
					e.hadLocalSelectedItem && !t ? g.SelectedItem = e.previousLocalSelectedItem : delete g.SelectedItem, yt.value = n, j.value = St(n), s(m.SelectedItem, n, h), N("update:SelectedItem", n), await T(), Z === e && (Z = null), gr.value = void 0, St(n) !== e.previousValue && ri();
					return;
				}
				if (ni(e.value), gr.value = e.value, await T(), ui(), await T(), Q || Z !== e) return;
				if (Z = null, gr.value = void 0, j.value = e.value, e.value === null || e.value === void 0 || e.value === "") {
					G = null, K = !1, Ft.value = {
						opacity: "0",
						transition: "none"
					};
					return;
				}
				let n = Qr(e.value);
				Pr(e.press, n.value);
				let r = e.collapsePane && !V.value && Zr();
				V.value && P.value && F.value !== "closing" ? (G = W[n.value] || null, K = n.isChild, Ft.value = {
					opacity: "0",
					transition: "none"
				}) : r || Ai(n.value, n.isChild), e.collapsePane && V.value && Zr(), await T();
			} finally {
				Z === e && (Z = null, gr.value = void 0), e.commit.release();
			}
		}, Ir = (e, t, n = !1, r = !1) => {
			if (Z || Q) return !1;
			Mr(), Ji();
			let i = {
				press: kr,
				value: e,
				collapsePane: n,
				boundRouteNavigation: r && pe(),
				previousValue: A.value,
				previousItem: yt.value,
				hadLocalSelectedItem: Object.prototype.hasOwnProperty.call(g, "SelectedItem"),
				previousLocalSelectedItem: g.SelectedItem,
				commit: null
			};
			j.value = i.previousValue, Or += 1, gr.value = i.previousValue, Z = i;
			try {
				let e = he(), n = r ? ge() : Promise.resolve(!0);
				i.commit = fe(t), Ct(j.value), i.commit.completion = Promise.all([
					e,
					n,
					i.commit.completion
				]).then(([, e, t]) => e && t);
			} catch (e) {
				throw Z = null, gr.value = void 0, e;
			}
			return i.commit.result === !1 && (i.collapsePane = !1, i.value = i.previousValue, i.press = null), Fr(i), i.commit.result !== !1;
		}, Lr = (e, { invoked: t = !0, isSettings: n = !1, collapsePane: r = !1 } = {}) => {
			if (Z) return !1;
			let i = n ? null : X(e), a = n ? Tr() : i?.source;
			if (!a || !n && i.isEnabled === !1) return !1;
			let o = Dr(e, n);
			return Ir(e, () => (t && N("ItemInvoked", {
				InvokedItem: i?.container?.Content ?? a.Content,
				IsSettingsInvoked: n,
				InvokedItemContainer: i?.container ?? a,
				RecommendedNavigationTransitionInfo: o
			}), !n && i.selectsOnInvoked === !1 ? !1 : A.value === e ? !0 : (yt.value = a, s(m.SelectedItem, a, h), N("update:SelectedItem", a), N("SelectionChanged", {
				SelectedItem: a,
				IsSettingsSelected: n,
				SelectedItemContainer: i?.container ?? a,
				RecommendedNavigationTransitionInfo: o
			}), !0)), r && (n || !i?.hasChildren));
		}, Rr = (e) => e === U.value || M.footerItems.some((t) => t.value === e), zr = (e) => {
			let t = e?.getAttribute?.("data-navigation-value");
			if (t) return t;
			for (let [t, n] of Object.entries(W)) if (n === e) return t;
			return null;
		}, Br = (e, t) => {
			t ? W[e] = t : delete W[e];
		}, Vr = (e, t) => {
			t ? Nn[e] = t : delete Nn[e];
		}, Hr = (e) => {
			let t = St(e), n = X(t);
			if (n?.hasChildren) {
				if (R[t]) {
					delete zt[t];
					return;
				}
				N("Expanding", {
					ExpandingItemContainer: n.container,
					ExpandingItem: n.source
				}), delete zt[t], R[t] = !0, n.container && n.container.IsExpanded !== !0 && (n.container.IsExpanded = !0), T(() => Yr(t)), T(() => {
					let e = X(t), n = H.value && !Y(t), r = B.value && xr.value.some((e) => e.value === t);
					e && R[t] && (n || r) && !(z.value && Ht.value === t) && Ti(e);
				});
			}
		}, Ur = (e) => {
			let t = St(e), n = X(t);
			!n?.hasChildren || !R[t] || (zt[t] = !0, R[t] = !1, n.container && n.container.IsExpanded !== !1 && (n.container.IsExpanded = !1), N("Collapsed", {
				CollapsedItemContainer: n.container,
				CollapsedItem: n.source
			}), T(() => Yr(t)), z.value && Ht.value === t && $());
		}, Wr = (e) => {
			let t = e?.IsSettingsItem ? M.settingsValue : e?.nodeType ? zr(e) : St(e);
			return t === M.settingsValue ? Tr() : X(t)?.source ?? null;
		}, Gr = (e) => {
			let t = St(e);
			return t === M.settingsValue ? wr : X(t)?.container ?? null;
		}, Kr = {
			DisplayMode: hn,
			SettingsItem: y(Tr),
			TemplateSettings: y(() => ({
				TopPadding: 0,
				OverflowButtonVisibility: Sr.value.length ? "Visible" : "Collapsed",
				PaneToggleButtonVisibility: _n.value && !B.value ? "Visible" : "Collapsed",
				BackButtonVisibility: Cn.value ? "Visible" : "Collapsed",
				TopPaneVisibility: _.IsPaneVisible && B.value ? "Visible" : "Collapsed",
				LeftPaneVisibility: _.IsPaneVisible && !B.value ? "Visible" : "Collapsed",
				SingleSelectionFollowsFocus: _.SelectionFollowsFocus === "Enabled",
				PaneToggleButtonWidth: _.CompactPaneLength,
				SmallerPaneToggleButtonWidth: Math.max(0, _.CompactPaneLength - 8),
				OpenPaneLength: Math.min(_.OpenPaneLength, Xt.value || _.OpenPaneLength)
			})),
			MenuItemFromContainer: Wr,
			ContainerFromMenuItem: Gr,
			Expand: Hr,
			Collapse: Ur
		};
		for (let e of Object.keys(m)) Kr[e] = y({
			get: () => e === "SelectedItem" ? yt.value : e === "IsPaneOpen" ? !P.value : e === "MenuItems" ? _t.value.map((e) => e.source) : e === "FooterMenuItems" ? vt.value.map((e) => e.source) : !Object.prototype.hasOwnProperty.call(g, e) && [
				"AutoSuggestBox",
				"PaneHeader",
				"PaneFooter",
				"PaneCustomContent",
				"ContentOverlay"
			].includes(e) ? k(e.charAt(0).toLowerCase() + e.slice(1))[0] ?? _[e] : _[e],
			set: (t) => {
				let n = e === "SelectedItem" ? A.value : null, r = e === "SelectedItem" ? St(t) : null, i = e === "SelectedItem" ? Dr(r, r === M.settingsValue) : null;
				if (e === "SelectedItem") {
					let e = () => {
						g.SelectedItem = Ve(t) ? He(t) : t, yt.value = t, s(m.SelectedItem, t, h), N("update:SelectedItem", t);
					};
					Z ? (Z.value = r, e()) : n === r ? e() : Ir(r, () => (e(), N("SelectionChanged", {
						SelectedItem: t,
						SelectedItemContainer: X(r)?.container ?? (r === M.settingsValue ? wr : null),
						IsSettingsSelected: r === M.settingsValue,
						RecommendedNavigationTransitionInfo: i
					}), !0));
					return;
				}
				e === "IsPaneOpen" && !Ii(!t) || (g[e] = Ve(t) ? He(t) : t, e !== "IsPaneOpen" && s(m[e], t, h));
			}
		});
		let qr = new Proxy(Kr, {
			get: (e, t) => e[t]?.__v_isRef ? e[t].value : e[t],
			set: (e, t, n) => e[t]?.__v_isRef ? (e[t].value = n, !0) : (e[t] = n, !0)
		});
		ve(Kr);
		for (let e of Object.keys(m)) O(() => o(m[e], h), (t) => {
			e in g && g[e] !== t && delete g[e];
		});
		let Jr = (e) => {
			let t = Nn[e];
			if (!t) return Bt[e] ?? 0;
			let n = (e) => {
				let t = getComputedStyle(e);
				return e.offsetHeight + (Number.parseFloat(t.marginTop) || 0) + (Number.parseFloat(t.marginBottom) || 0);
			}, r = Array.from(t.children), i = getComputedStyle(t), a = (Number.parseFloat(i.paddingTop) || 0) + (Number.parseFloat(i.paddingBottom) || 0);
			a += Math.max(0, r.length - 1) * (Number.parseFloat(i.rowGap) || 0);
			for (let e of r) {
				if (!e.classList.contains("win-nav-group")) {
					a += n(e);
					continue;
				}
				let t = e.firstElementChild;
				if (!t) continue;
				let r = zr(t), i = Jr(r);
				a += n(t), R[r] && cn.value && (a += i);
			}
			return Bt[e] = a, a;
		}, Yr = (e) => {
			Jr(e);
			let t = Y(e);
			for (; t;) Jr(t.value), t = Y(t.value);
		}, Xr = () => {
			for (let e of [...M.menuItems, ...M.footerItems]) e.children && Jr(e.value);
		}, Zr = () => !tn.value || P.value ? !1 : Ri(), Qr = (e) => {
			let t = Y(e);
			if (t && (B.value || H.value)) {
				for (; Y(t.value);) t = Y(t.value);
				return {
					value: t.value,
					isChild: !1
				};
			}
			let n = t, r = null;
			for (; n;) R[n.value] || (r = n), n = Y(n.value);
			return r ? {
				value: r.value,
				isChild: !!Y(r.value)
			} : {
				value: e,
				isChild: !!t
			};
		}, $r = (e) => {
			let t = 0, n = Y(zr(e));
			for (; n;) t += 1, n = Y(n.value);
			return 4 + t * 31;
		}, ei = y(() => ({
			...Ft.value,
			left: `${Lt.value}px`
		})), ti = (e) => {
			let t = Qr(e);
			Ai(t.value, t.isChild);
		}, ni = (e) => {
			let t = Y(e);
			for (; t && !B.value && !H.value;) {
				delete zt[t.value], R[t.value] = !0;
				let e = t.value;
				T(() => Yr(e)), t = Y(t.value);
			}
		}, ri = (e, { collapsePane: t = !1 } = {}) => {
			if (Z || Q) return;
			let n = Or;
			if (e == null || e === "") {
				G = null, K = !1, Gn = !1, Ft.value = {
					opacity: "0",
					transition: "none"
				};
				return;
			}
			ni(e), T(() => {
				Z || n !== Or || Q || (ui(), T(() => {
					if (Z || n !== Or || Q) return;
					let r = Qr(e);
					if (V.value && P.value && F.value !== "closing") {
						G = W[r.value] || null, K = r.isChild, It.value = r.isChild, Gn = !1, Ft.value = {
							opacity: "0",
							transition: "none"
						};
						return;
					}
					t && !V.value && Zr() || Ai(r.value, r.isChild), t && V.value && Zr();
				}));
			});
		}, ii = (e, t = null, { collapsePane: n = !0 } = {}) => {
			Lr(e, { collapsePane: n });
		}, ai = (e) => {
			e.isEnabled && ii(e.value, !1);
		}, oi = (e, t) => {
			t.isEnabled && ii(t.value, !0);
		}, si = (e) => {
			if (Yn = -Infinity, e.key === " " && e.altKey) return;
			if ((e.key === "Enter" || e.key === " ") && e.repeat) {
				e.preventDefault();
				return;
			}
			if (e.key === "Escape" && (z.value || Ut.value || tn.value && !P.value)) {
				e.preventDefault(), z.value ? $() : Ut.value ? _i() : Ri();
				return;
			}
			let t = e.target?.closest?.(".win-nav-item");
			if (!t) return;
			let n = t.closest(".win-nav-more-panel") ?? I.value, r = Array.from(n?.querySelectorAll(".win-nav-item:not(.is-disabled)") ?? []).filter((e) => e.getClientRects().length && !e.closest("[inert]") && !e.closest(".win-nav-top-measure")), i = r.indexOf(t), a = zr(t), o = X(a), s = B.value && !t.closest(".win-nav-more-panel");
			if (e.key === "Escape") {
				e.preventDefault(), z.value ? $() : Ut.value ? _i() : tn.value && !P.value && Ri();
				return;
			}
			let c = s ? "ArrowRight" : "ArrowDown";
			if ([
				c,
				s ? "ArrowLeft" : "ArrowUp",
				"Home",
				"End"
			].includes(e.key)) {
				e.preventDefault();
				let t = e.key === "Home" ? 0 : e.key === "End" ? r.length - 1 : i + (e.key === c ? 1 : -1);
				r[Math.max(0, Math.min(r.length - 1, t))]?.focus({ preventScroll: !0 });
				return;
			}
			if (!s && (e.key === "ArrowRight" || e.key === "ArrowLeft")) {
				e.preventDefault(), e.key === "ArrowRight" && o?.hasChildren ? R[a] ? T(() => W[o.children?.find((e) => e.isEnabled)?.value]?.focus({ preventScroll: !0 })) : Hr(o.container) : e.key === "ArrowLeft" && (o?.hasChildren && R[a] ? Ur(o.container) : W[Y(a)?.value]?.focus({ preventScroll: !0 }));
				return;
			}
			if (!(e.key !== "Enter" && e.key !== " ")) {
				if (e.preventDefault(), t === Nt.value) {
					vi();
					return;
				}
				a && Nr(t, e, () => {
					if (a === U.value) {
						Pi();
						return;
					}
					if (!o || !o.isEnabled) return;
					let e = Y(a);
					t.closest(".win-nav-more-panel") ? o.hasChildren ? xi(o) : ($(), yi(o)) : o.hasChildren ? Ei(o) : e ? oi(e, o) : ai(o);
				});
			}
		}, ci = () => {
			Yn = performance.now();
		}, li = (e) => {
			if (_.SelectionFollowsFocus !== "Enabled") return;
			let t = e.target?.closest?.(".win-nav-item");
			if (!t || t.classList.contains("is-disabled") || performance.now() - Yn < 1e3 || !t.matches(":focus-visible")) return;
			let n = zr(t);
			if (!n || n === A.value || B.value && t.closest(".win-nav-overflow-panel")) return;
			if (n === U.value) {
				Pi();
				return;
			}
			let r = X(n);
			!r || !r.isEnabled || !r.selectsOnInvoked || Lr(r.value, { collapsePane: !1 });
		}, ui = () => {
			if (!B.value) return;
			let e = I.value, t = jt.value, n = Pt.value, r = Mt.value;
			if (!e) return;
			let i = e.clientWidth || e.offsetWidth, a = t?.offsetWidth || 0, o = n?.offsetWidth || 0, s = Array.from(e.children).filter((e) => e.classList.contains("win-nav-top-fixed")).reduce((e, t) => e + t.offsetWidth, 0), c = e.querySelector(".win-nav-top-pane-custom-content"), l = 48;
			if (c?.children.length) {
				let e = c.cloneNode(!0);
				Object.assign(e.style, {
					position: "fixed",
					left: "-10000px",
					top: "0",
					visibility: "hidden",
					pointerEvents: "none",
					width: "max-content",
					minWidth: "0",
					maxWidth: "none",
					flex: "none",
					font: getComputedStyle(c).font
				}), document.body.appendChild(e);
				try {
					l = Math.max(48, e.scrollWidth);
				} finally {
					e.remove();
				}
			}
			let u = Math.max(0, i - a - o - s - l);
			if (Math.abs(qt.value - u) >= .5 && (qt.value = u), r) {
				let e = {};
				r.querySelectorAll("[data-value]").forEach((t) => {
					let n = t.getAttribute("data-value"), r = getComputedStyle(t), i = Number.parseFloat(r.marginLeft || "0") + Number.parseFloat(r.marginRight || "0"), a = Math.ceil(t.offsetWidth + i);
					n === "__more" ? Yt.value = a : n && (e[n] = a);
				});
				let t = Jt.value, n = Object.keys(e);
				(Object.keys(t).length !== n.length || n.some((n) => t[n] !== e[n])) && (Jt.value = e);
			}
		}, di = null, fi = 0, pi = () => {
			fi += 1, di && cancelAnimationFrame(di), di = null;
		}, mi = (e = !1) => {
			pi();
			let t = fi;
			T(() => {
				t === fi && (di = requestAnimationFrame(() => {
					di = null, !(t !== fi || !(e ? Ut.value : z.value)) && document.querySelector(`.flyout-presenter ${e ? ".win-nav-overflow-panel" : ".win-nav-more-panel:not(.win-nav-overflow-panel)"}[data-navigation-owner="${h.uid}"]`)?.querySelector(".win-nav-item:not(.is-disabled)")?.focus({ preventScroll: !0 });
				}));
			});
		}, hi = () => {
			let e = Nt.value;
			if (!e) return;
			$(), Gt.value = Sr.value.slice(), Ut.value = !0;
			let t = ++Kt;
			T(() => {
				t === Kt && Ut.value && Wt.value?.ShowAt(e, { Placement: "BottomEdgeAlignedRight" });
			});
		}, gi = () => {
			Ut.value &&= (Kt += 1, pi(), !1);
		}, _i = () => {
			Wt.value?.IsOpen ? Wt.value.Hide() : gi();
		}, vi = () => {
			Ut.value ? _i() : hi();
		}, yi = (e) => {
			e.isEnabled && (_i(), ii(e.value, !1));
		}, bi = (e, t) => {
			t.isEnabled && (_i(), ii(t.value, !0));
		}, xi = (e) => {
			e.isEnabled && (e.selectsOnInvoked ? ii(e.value, !1, { collapsePane: !1 }) : Lr(e.value), R[e.value] ? Ur(e.container) : Hr(e.container));
		}, Si = (e) => {
			e.isEnabled && (R[e.value] ? Ur(e.source) : Hr(e.source));
		}, Ci = (e) => {
			let t = R[e.value], n = Cr(e);
			t ? (zt[e.value] = !0, Ur(e.source)) : (delete zt[e.value], Hr(e.source)), T(() => Yr(e.value)), n ? T(() => {
				Yr(e.value);
				let n = t ? W[e.value] : W[M.selectedValue];
				if (n) {
					if (Pn = G, G = n, K = !t, t) {
						ga({
							target: n,
							targetIsChild: !1
						}) || (q = !0, ta(), requestAnimationFrame(() => {
							q = !1;
						}));
						return;
					}
					ga({
						target: n,
						targetIsChild: !0,
						allowClippedTarget: !0
					}) || (q = !0, ta(), requestAnimationFrame(() => {
						q = !1;
					}));
				}
			}) : Oi();
		}, wi = (e) => {
			if (e.isEnabled) {
				if (B.value || P.value) {
					Ei(e, !1);
					return;
				}
				Ci(e);
			}
		}, Ti = (e) => {
			_i(), z.value && $();
			let t = W[e.value];
			if (!t) return;
			let n = t.getBoundingClientRect(), r = I.value?.getBoundingClientRect(), i = { Placement: $t.value };
			B.value || (i.Position = {
				X: (r?.left ?? n.left) + Number(M.compactPaneLength) - n.left,
				Y: 0
			}), Ht.value = e.value, Hr(e.container), z.value = !0;
			let a = ++Kt;
			T(() => {
				a === Kt && z.value && Ht.value === e.value && Vt.value?.ShowAt(t, i);
			});
		}, Ei = (e, t = !0) => {
			if (e.isEnabled) {
				if (t && (e.selectsOnInvoked ? ii(e.value, !1, { collapsePane: !1 }) : Lr(e.value)), B.value || H.value) {
					z.value && Ht.value === e.value ? $() : Ti(e);
					return;
				}
				Ci(e);
			}
		}, Di = null, Oi = () => {
			Di && cancelAnimationFrame(Di);
			let e = L.value, t = e?.querySelector(".win-nav-indicator");
			if (!e || !t || !G || !I.value) return;
			let n = performance.now(), r = () => {
				if (!G || !I.value || !I.value.contains(G)) {
					Di = null;
					return;
				}
				let i = or(G, e), a = i.top + (i.bottom - i.top) / 2 - 8;
				t.getAnimations().some((e) => e.playState === "running") ? ur() : (fr(e, "y", sr(G, e)), Ft.value = {
					transform: `translate3d(${$r(G) - 4}px,${a}px,0)`,
					height: "16px",
					opacity: "1",
					transition: "none"
				}), Di = performance.now() - n < 350 ? requestAnimationFrame(r) : null;
			};
			Di = requestAnimationFrame(r);
		}, ki = () => {
			let e = z.value;
			if (e && (Kt += 1, pi(), z.value = !1, Ht.value)) {
				let t = X(Ht.value);
				e && t && Ur(t.container);
			}
		}, $ = () => {
			Vt.value?.IsOpen ? Vt.value.Hide() : ki();
		}, Ai = (e, t) => {
			let n = W[e];
			n && ji(n, t);
		}, ji = (e, t) => {
			Z || Q || (Pn = G, G = e, K = t, ta({ animateSelectionChange: !0 }));
		}, Mi = () => {
			nr.value && N("BackRequested", {});
		}, Ni = () => {
			nr.value && Mi();
		}, Pi = () => {
			!gn.value || _.IsEnabled === !1 || Lr(U.value, {
				isSettings: !0,
				collapsePane: !0
			});
		}, Fi = () => {
			_.IsEnabled !== !1 && (P.value ? (qn = !1, Li()) : (qn = !0, Ri()));
		}, Ii = (e, t = !0) => {
			if (e === P.value) return !0;
			if (e) {
				let e = { Cancel: !1 };
				if (N("PaneClosing", e), e.Cancel) return !1;
			} else N("PaneOpening", {});
			let n = I.value, r = n ? getComputedStyle(n).clipPath : null;
			if (V.value && n) {
				let e = n.querySelector(".win-nav-pane-surface"), t = e ? getComputedStyle(e) : null, r = t && t.display !== "none" ? t.transform === "none" ? "translateX(0)" : t.transform : "translateX(calc(-1 * var(--win-nav-open-pane-length, 320px)))";
				n.style.setProperty("--win-nav-pane-transition-start", r);
			}
			Wn?.cancel(), Wn = null;
			let i = e ? "closing" : "opening", a = ++Kn;
			F.value = i, J && clearTimeout(J), J = null;
			let o = En(e);
			return P.value = e, T(() => {
				if (!n?.isConnected || Q || a !== Kn || F.value !== i || P.value !== e) return;
				let t = () => {
					if (!(a !== Kn || Q || F.value !== i)) {
						if (e) {
							let e = L.value?.querySelector(".win-nav-indicator");
							V.value ? (mr(e), Ft.value = {
								opacity: "0",
								transition: "none"
							}) : Bn?.source && Y(zr(Bn.source)) && lr();
						}
						F.value = "", J = null, N(e ? "PaneClosed" : "PaneOpened", {}), T(() => na());
					}
				};
				if (V.value) {
					let e = n.querySelector(".win-nav-pane-surface");
					e && getComputedStyle(e).animationName;
					let r = e?.getAnimations().find((e) => e.animationName?.startsWith("win-nav-minimal-pane"));
					r ? r.finished.then(t, () => {}) : J = setTimeout(t, o);
					return;
				}
				let s = getComputedStyle(n), c = Math.max(0, Number.parseFloat(s.width) || n.offsetWidth), l = Math.min(c, Math.max(0, -(Number.parseFloat(s.marginLeft) || 0))), u = Math.min(Math.max(0, Number(M.compactPaneLength)), c - l), d = `inset(0px ${Math.max(0, c - l - u)}px 0px ${l}px)`, f = e ? d : "inset(-30px -30px -30px -30px)", ee = r && r !== "none" ? r : e ? "inset(-30px -30px -30px -30px)" : d;
				Wn = n.animate([{ clipPath: ee }, { clipPath: f }], {
					duration: o,
					easing: Tn.value.easing,
					fill: "both"
				});
				let te = Wn;
				te.finished.then(() => {
					Wn === te && (t(), te.cancel(), Wn = null);
				}, () => {});
			}), s(m.IsPaneOpen, !e, h), t && N("update:IsPaneOpen", !e), !0;
		}, Li = (e = !0) => Ii(!1, e), Ri = (e = !0) => Ii(!0, e), zi = () => {
			H.value && (qn = !1, Li(), T(() => {
				requestAnimationFrame(() => {
					(kt.value?.querySelector?.("input, textarea, [contenteditable=\"true\"], [tabindex]:not([tabindex=\"-1\"])"))?.focus?.({ preventScroll: !0 });
				});
			}));
		}, Bi = () => {
			let e = Zt.value === "Auto";
			if (e && tn.value) {
				P.value || (J && clearTimeout(J), J = null, F.value = "", P.value = !0, s(m.IsPaneOpen, !1, h), N("update:IsPaneOpen", !1), T(() => na()));
				return;
			}
			if (e && Qt.value === "Left") {
				qn || Li();
				return;
			}
			if (Zt.value === "Left") {
				typeof M.isPaneOpen == "boolean" && (P.value = !M.isPaneOpen);
				return;
			}
			if (V.value) P.value = !0;
			else if (typeof M.isPaneOpen == "boolean") {
				P.value = !M.isPaneOpen;
				return;
			}
			tn.value ? P.value = !0 : B.value || (P.value = !1);
		}, Vi = (e) => {
			if (Z || me.value || !tn.value || P.value) return;
			let t = e.target;
			I.value?.contains(t) || t?.closest?.(".flyout-presenter") || t?.closest?.("[data-nav-pane-toggle]") || Ri();
		}, Hi = Ce.PointerPressed, Ui = Ce.PointerReleased, Wi = Ce.PointerExited, Gi = Ce.PointerPressed, Ki = Ce.PointerReleased, qi = Ce.PointerExited, Ji = () => {
			p.Reset(), Ce.Reset(), Oe.Reset();
		}, Yi = () => {
			Mr(), Ji(), $(), _i();
		}, Xi = () => {
			if ($n) return;
			let e = Qi();
			e && !P.value && (Zn = e.scrollTop), !(!G || !I.value?.contains(G) || tr) && (tr = requestAnimationFrame(() => {
				tr = null, !($n || !G || !I.value?.contains(G)) && (q = !0, ta(), requestAnimationFrame(() => {
					q = !1;
				}));
			}));
		}, Zi = () => {
			Ln && cancelAnimationFrame(Ln), Ln = requestAnimationFrame(() => {
				Ln = null, aa(), Xr(), B.value && ui(), na();
			});
		}, Qi = () => Ot.value?.scrollViewerRef?.value ?? Ot.value?.scrollViewerRef ?? Ot.value ?? null, $i = () => {
			let e = Qi();
			e !== er && (er?.removeEventListener("scroll", Xi), er = e, er?.addEventListener("scroll", Xi, { passive: !0 }));
		};
		O(Ot, () => T($i), { flush: "post" });
		let ea = ({ restoreScrollOffset: e = !1 } = {}) => {
			Qn && cancelAnimationFrame(Qn);
			let t = 0;
			$n = !0, q = !0;
			let n = () => {
				let r = Qi();
				if (e && r) {
					let e = Math.max(0, r.scrollHeight - r.clientHeight);
					r.scrollTop = Math.min(Zn, e);
				}
				let i = L.value?.querySelector(".win-nav-indicator"), a = i?.getAnimations().some((e) => e.playState === "running");
				a && Bn ? ur() : (i && (i.style.translate = ""), na());
				let o = Array.from(I.value?.querySelectorAll(".win-nav-group-children") ?? []).some((e) => e.getAnimations().some((e) => e.playState === "running"));
				if (F.value || Hn || a || o ? t = 0 : t += 1, t < 2) {
					Qn = requestAnimationFrame(n);
					return;
				}
				if (e && r) {
					let e = Math.max(0, r.scrollHeight - r.clientHeight);
					r.scrollTop = Math.min(Zn, e);
				}
				Qn = requestAnimationFrame(() => {
					Qn = null, $n = !1;
					let e = L.value?.querySelector(".win-nav-indicator");
					e && (e.style.translate = ""), na(), q = !1;
				});
			};
			Qn = requestAnimationFrame(n);
		}, ta = ({ animateSelectionChange: e = !1, sourceSnapshot: t = null, allowClippedTarget: n = !1 } = {}) => {
			if (Z || Q || Hn && !t || !I.value || !G || !I.value.contains(G)) return;
			let r = L.value, i = r?.querySelector(".win-nav-indicator");
			if (!r || !i) return;
			let a = i.getAnimations().some((e) => e.playState === "running");
			if (a && zn === G) return;
			let o = t?.element ?? (Pn && Pn !== G ? Pn : null);
			Pn = G;
			let s = ar(r), c = or(G, r, s), l = t?.rect ?? (o && I.value.contains(o) ? or(o, r, s) : null), u = B.value, d = u ? (c.left + c.right) / 2 - 8 : $r(G) - 4, f = u ? 0 : (c.top + c.bottom) / 2 - 8, ee = u ? "x" : "y", te = u ? "width" : "height", ne = sr(G, r, s);
			if ((ne.top >= ne.bottom || ne.left >= ne.right) && (!n || !e || !l)) {
				mr(i), zn = null, Gn = !0, pr(i, {
					transform: `translate3d(${d}px,${f}px,0)`,
					[te]: "16px",
					opacity: "0",
					transition: "none"
				});
				return;
			}
			let re = () => {
				let { x: e, y: t } = cr(G, r);
				i.style.translate = "", Lt.value = 4, It.value = K, fr(r, ee, sr(G, r)), pr(i, {
					transform: `translate3d(${e}px,${t}px,0)`,
					transformOrigin: "0 0",
					[te]: "16px",
					opacity: "1",
					transition: "none"
				});
			};
			Gn = !1;
			let ie = Dt.value?.querySelector(".win-nav-indicator");
			if (!e && q && !a || !l || !ie) {
				mr(i), zn = G, re();
				return;
			}
			let ae = t?.position.x ?? (u ? (l.left + l.right) / 2 - 8 : $r(o) - 4), oe = t?.position.y ?? (u ? 0 : (l.top + l.bottom) / 2 - 8);
			if (Math.hypot(d - ae, f - oe) < 1) {
				mr(i), zn = G, re();
				return;
			}
			let se = mr(i);
			zn = G, i.style.translate = "", Lt.value = 4, It.value = K, pr(i, {
				transform: `translate3d(${d}px,${f}px,0)`,
				transformOrigin: "0 0",
				[te]: "16px",
				opacity: "1",
				transition: "none"
			}), Object.assign(ie.style, {
				transform: `translate3d(${ae}px,${oe}px,0)`,
				transformOrigin: "0 0",
				[te]: "16px",
				opacity: "1",
				transition: "none"
			}), Bn = {
				source: o,
				target: G,
				axis: ee,
				sourcePosition: {
					x: ae,
					y: oe
				},
				targetPosition: {
					x: d,
					y: f
				},
				sourceSnapshot: t
			}, ur();
			let ce = u ? Math.abs(oe - f) < .5 : Math.abs(ae - d) < .5, le = {
				duration: 600,
				fill: "both"
			}, ue;
			if (ce) {
				let e = u ? ae : oe, t = u ? d : f, n = Math.min(e, t), r = [
					{
						transform: `translate3d(${ae}px,${oe}px,0)`,
						[te]: "16px",
						offset: 0,
						easing: "cubic-bezier(0.9,0.1,1,0.2)"
					},
					{
						transform: `translate3d(${u ? n : d}px,${u ? f : n}px,0)`,
						[te]: `${Math.abs(t - e) + 16}px`,
						offset: .333,
						easing: rr
					},
					{
						transform: `translate3d(${d}px,${f}px,0)`,
						[te]: "16px",
						offset: 1
					}
				];
				ue = i.animate(r, le), Bn.source && (ie.animate(r, le), ie.animate([
					{
						opacity: 1,
						offset: 0
					},
					{
						opacity: 1,
						offset: .333,
						easing: rr
					},
					{
						opacity: 0,
						offset: 1
					}
				], le));
			} else {
				let e = oe < f, t = u ? "scaleX" : "scaleY";
				ie.style.transformOrigin = u ? "8px 0" : e ? "0 16px" : "0 0";
				let n = u ? "8px 0" : e ? "0 0" : "0 16px", r = `translate3d(${ae}px,${oe}px,0)`, a = `translate3d(${d}px,${f}px,0)`;
				Bn.source && ie.animate([{
					transform: `${r} ${t}(1)`,
					easing: "cubic-bezier(0.5,0,0.5,1)"
				}, { transform: `${r} ${t}(0)` }], le), ue = i.animate([{
					transform: `${a} ${t}(0)`,
					transformOrigin: n,
					easing: "cubic-bezier(0.5,0,0.5,1)"
				}, {
					transform: `${a} ${t}(1)`,
					transformOrigin: n
				}], le);
			}
			let de = () => {
				se === Rn && (ur(), Vn = requestAnimationFrame(de));
			};
			Vn = requestAnimationFrame(de), ue.onfinish = () => {
				se === Rn && (mr(i), re());
			};
		}, na = () => {
			if (Z || Hn || Q || V.value && P.value) return;
			let e = M.selectedValue;
			if (!e || !I.value) return;
			let t = Qr(e), n = W[t.value] || null, r = L.value?.querySelector(".win-nav-indicator");
			!n || !r || r.getAnimations().some((e) => e.playState === "running") || (G = n, K = t.isChild, q = !0, ta(), requestAnimationFrame(() => {
				q = !1;
			}));
		}, ra = null, ia = () => {
			let e = Et.value?.clientWidth || Et.value?.offsetWidth || window.innerWidth, t = Math.abs(e - Xn) >= .5;
			Xn = e, Xt.value = e || (typeof window > "u" ? M.expandedModeThresholdWidth : window.innerWidth), ui();
			let n = (L.value?.querySelector(".win-nav-indicator"))?.getAnimations().some((e) => e.playState === "running");
			if (!(!t && n)) {
				if (q = !0, ra && cancelAnimationFrame(ra), !G || !I.value || !I.value.contains(G)) {
					let e = M.selectedValue;
					if (e) {
						let t = Y(e);
						t && (B.value || H.value) ? (G = W[t.value] || null, K = !1) : (G = W[e] || null, K = !!t && !H.value);
					}
				}
				ta(), ra = requestAnimationFrame(() => {
					ta(), ra = requestAnimationFrame(() => {
						ta(), ra = requestAnimationFrame(() => {
							q = !1;
						});
					});
				});
			}
		}, aa = () => {
			Fn && (Et.value && Fn.observe(Et.value), I.value && Fn.observe(I.value), jt.value && Fn.observe(jt.value), Pt.value && Fn.observe(Pt.value), I.value && I.value.querySelectorAll(".win-nav-pane-top, .win-nav-pane-header, .win-nav-pane-custom-content, .win-nav-pane-footer").forEach((e) => Fn.observe(e)));
		}, oa = () => {
			Fn && Fn.disconnect(), Fn = new ResizeObserver(ia), aa();
		}, sa = () => {
			In && (In.disconnect(), I.value && In.observe(I.value, {
				childList: !0,
				subtree: !0,
				characterData: !0
			}));
		}, ca = () => {
			q = !0, T(() => {
				oa(), sa(), Xr(), ui();
				let e = M.selectedValue;
				if (e) {
					let t = Y(e);
					t ? B.value || H.value ? (G = W[t.value], K = !1) : (G = W[e], K = !0) : (G = W[e], K = !1), ta();
				}
				requestAnimationFrame(() => {
					q = !1;
				});
			});
		}, la = () => {
			q = !0;
			let e = () => {
				requestAnimationFrame(() => {
					na(), requestAnimationFrame(() => {
						na(), q = !1;
					});
				});
			};
			T(() => {
				Xr(), ui();
				let t = M.selectedValue;
				if (t) {
					let n = Y(t);
					if (n) if (!B.value && !H.value) {
						if (!R[n.value]) {
							R[n.value] = !0, T(() => {
								Yr(n.value), T(() => {
									G = W[t], K = !0, It.value = !0, ta(), e();
								});
							});
							return;
						}
						G = W[t], K = !0, It.value = !0;
					} else G = W[n.value], K = !1;
					else G = W[t], K = !1;
					ta();
				}
				e();
			});
		}, ua = (e, t = "Left", n = 0) => {
			let i = t === "Measure", a = t === "Overflow" || t === "ChildrenFlyout", o = t === "Top" || t === "TopFooter" || i;
			if (e.type === "Header") return w("div", {
				key: e.value,
				class: "win-nav-item-header",
				"data-value": i ? e.value : void 0,
				style: n ? { marginLeft: `${n * 31}px` } : void 0,
				"data-template-part": "InnerHeaderGrid"
			}, [w(ie, { Text: e.label })]);
			if (e.type === "Separator") return w("div", {
				key: e.value,
				class: "win-nav-item-separator",
				"data-value": i ? e.value : void 0,
				style: n ? { marginLeft: `${n * 31}px` } : void 0,
				role: "separator",
				"data-template-part": "SeparatorLine"
			});
			let s = !!R[e.value], c = e.selectsOnInvoked && j.value === e.value, l = [];
			(e.iconNodes?.length || e.icon) && l.push(w(te, {
				class: "icon",
				Height: 16,
				Width: o || a ? 16 : "",
				HorizontalAlignment: "Center",
				VerticalAlignment: "Center",
				"data-template-part": "IconBox"
			}, { default: () => w(ce, {
				HorizontalContentAlignment: "Center",
				VerticalContentAlignment: "Center",
				"data-template-part": "Icon"
			}, { default: () => e.iconNodes?.length ? r(e.iconNodes, h) : w("span", String(e.icon)) }) })), e.contentNodes?.length ? l.push(w("div", {
				class: "label",
				"data-template-part": "ContentPresenter"
			}, r(e.contentNodes, h))) : l.push(w(ie, {
				class: "label",
				Text: e.label,
				"data-template-part": "ContentPresenter"
			})), e.infoBadge && l.push(w(ce, {
				class: "win-nav-infobadge-presenter",
				VerticalAlignment: "Center",
				HorizontalAlignment: o ? "Center" : "Right",
				Margin: o ? "-16,0,2,13" : "0",
				"data-template-part": "InfoBadgePresenter"
			}, { default: () => w(_e, {
				...e.infoBadge,
				class: "win-nav-infobadge"
			}) })), e.hasChildren && l.push(w("span", {
				class: ["icon", "win-nav-group-chevron"],
				"data-template-part": "ExpandCollapseChevron",
				"data-expanded": String(s),
				"aria-disabled": !e.isEnabled || void 0,
				"AnimatedIcon.State": s ? "NormalOn" : "NormalOff",
				ref: (e) => {
					Oe.Attach(e);
				},
				onClick: (t) => {
					t.stopPropagation(), a ? Si(e) : wi(e);
				}
			}, [w(oe, {
				Source: De,
				Width: 12,
				Height: 12,
				HorizontalAlignment: "Center",
				VerticalAlignment: "Center",
				"data-template-part": "ExpandCollapseChevronIcon",
				"AutomationProperties.AccessibilityView": "Raw"
			}, { default: () => w(oe.FallbackIconSource, {}, { default: () => w(de, {
				Foreground: "{ThemeResource NavigationViewItemForeground}",
				FontSize: 8,
				Glyph: "",
				FontFamily: "{StaticResource SymbolThemeFontFamily}"
			}) }) })]));
			let u = (e, t) => {
				if (e === "PointerPressed" || e === "KeyDown") {
					let n = t.target?.closest?.(".win-nav-group-chevron");
					n && t.currentTarget?.contains(n) && Oe[e]({
						currentTarget: n,
						pointerType: t.pointerType,
						button: t.button,
						pointerId: t.pointerId,
						key: t.key,
						repeat: t.repeat
					});
					return;
				}
				t.currentTarget === Ar && ["PointerExited", "LostFocus"].includes(e) && Mr(), p[e](t);
				let n = t.currentTarget?.querySelector(".win-nav-group-chevron");
				n && Oe[e]({
					currentTarget: n,
					pointerType: t.pointerType,
					button: t.button,
					pointerId: t.pointerId,
					key: t.key,
					repeat: t.repeat
				});
			}, d = w("div", {
				key: e.value,
				class: ["win-nav-item", {
					"win-nav-group-header": e.hasChildren,
					"win-nav-group-child": n > 0,
					"is-selected": c,
					"is-disabled": !e.isEnabled,
					"is-pressed": !i && Rt.value === e.value
				}],
				role: "menuitem",
				"aria-current": c ? "page" : void 0,
				"aria-disabled": !e.isEnabled || void 0,
				"aria-expanded": e.hasChildren ? s : void 0,
				"aria-level": n + 1,
				"data-value": i ? e.value : void 0,
				"data-navigation-value": e.value,
				"data-xaml-ref": e.container?.["x:Name"] ?? e.container?.["data-xaml-ref"],
				"data-template-part": "LayoutRoot",
				style: n ? { paddingLeft: `${(a ? 0 : 12) + n * 31}px` } : void 0,
				...i ? {} : ln(e),
				ref: (t) => {
					p.Attach(t), !i && !a && Br(e.value, t);
				},
				onPointerenter: (e) => u("PointerEntered", e),
				onPointerleave: (e) => u("PointerExited", e),
				onPointerdown: (e) => u("PointerPressed", e),
				onPointerup: (e) => u("PointerReleased", e),
				onPointercancel: (e) => u("PointerExited", e),
				onLostpointercapture: (e) => u("PointerExited", e),
				onKeydown: (e) => u("KeyDown", e),
				onKeyup: (e) => u("KeyUp", e),
				onFocusout: (e) => u("LostFocus", e),
				onClick: i ? void 0 : (t) => Nr(t.currentTarget, t, () => {
					e.isEnabled && (a ? e.hasChildren ? xi(e) : ($(), yi(e)) : e.hasChildren ? Ei(e) : ii(e.value, n > 0));
				})
			}, l);
			if (!e.hasChildren) return d;
			let f = s && (a || !o && cn.value);
			return w("div", {
				key: e.value,
				class: ["win-nav-group", {
					"is-expanded": f,
					"is-child-selected": Cr(e)
				}]
			}, [d, o ? null : w("div", {
				class: ["win-nav-group-children", { "is-pane-collapsing": !cn.value && F.value === "closing" }],
				style: { height: f ? a ? "auto" : `${Bt[e.value] ?? 0}px` : "0px" },
				"aria-hidden": !f || void 0,
				inert: !f
			}, [w("div", {
				class: "win-nav-group-children-inner",
				"data-template-part": "NavigationViewItemMenuItemsHost",
				ref: a ? void 0 : (t) => Vr(e.value, t)
			}, (e.children ?? []).map((e) => ua(e, t, n + 1)))])]);
		}, da = (e) => w("div", {
			class: [
				"win-nav-item",
				"win-nav-settings-item",
				{
					"is-selected": j.value === U.value,
					"is-disabled": !_.IsEnabled,
					"is-pressed": Rt.value === U.value
				}
			],
			role: "menuitem",
			tabindex: _.IsEnabled ? 0 : -1,
			"ToolTipService.ToolTip": B.value || P.value ? wt.value : void 0,
			"aria-label": wt.value,
			"aria-current": j.value === U.value ? "page" : void 0,
			"data-template-part": "SettingsNavPaneItem",
			"data-navigation-value": U.value,
			ref: (e) => {
				Br(U.value, e), p.Attach(e);
			},
			onPointerenter: p.PointerEntered,
			onPointerdown: p.PointerPressed,
			onKeydown: p.KeyDown,
			onKeyup: p.KeyUp,
			onFocusout: (e) => {
				Mr(), p.LostFocus(e);
			},
			onClick: (e) => Nr(e.currentTarget, e, Pi),
			onPointerup: p.PointerReleased,
			onPointerleave: (e) => {
				Mr(), p.PointerExited(e);
			},
			onPointercancel: (e) => {
				Mr(), p.PointerExited(e);
			},
			onLostpointercapture: (e) => {
				Mr(), p.PointerExited(e);
			}
		}, [w(oe, {
			class: "icon",
			Source: Ee,
			Width: 16,
			Height: 16,
			HorizontalAlignment: "Center",
			VerticalAlignment: "Center",
			IsHitTestVisible: "False"
		}), w(ie, {
			class: "label",
			Text: wt.value
		})]), fa = Re({
			props: { Mode: {
				type: String,
				default: "Left"
			} },
			setup(e) {
				return () => {
					let t = e.Mode, n = (t === "Top" ? xr.value : t === "Overflow" ? Gt.value : t === "Footer" || t === "TopFooter" ? vt.value : t === "ChildrenFlyout" ? X(Ht.value)?.children ?? [] : _t.value).map((e) => ua(e, t));
					return (t === "Footer" || t === "TopFooter") && gn.value && n.push(da(t)), w(Ie, n);
				};
			}
		}), pa = Re({ setup() {
			return Je(l, {
				...Be(l, {}),
				OnPaneViewChanged: Xi
			}), () => w(se, {
				class: "win-nav-left-scrollable",
				ref: Ot,
				VerticalScrollMode: "Auto",
				VerticalScrollBarVisibility: "Auto",
				HorizontalScrollMode: "Disabled",
				HorizontalScrollBarVisibility: "Disabled",
				ViewChanged: "OnPaneViewChanged",
				IsTabStop: "False"
			}, { default: () => w("div", {
				class: "win-nav-menu",
				"data-template-part": "MenuItemsHost"
			}, [w(fa, { Mode: "Left" })]) });
		} }), ma = Re({ setup() {
			let e = (e) => w(ue.FlyoutPresenterStyle, null, { default: () => [w("Style", { TargetType: "FlyoutPresenter" }, [
				w("Setter", {
					Property: "Padding",
					Value: e ? "{ThemeResource TopNavigationViewOverflowMenuPadding}" : "{ThemeResource NavigationViewItemChildrenMenuFlyoutPadding}"
				}),
				...e ? [] : [w("Setter", {
					Property: "Margin",
					Value: "0,-4,0,0"
				})],
				w("Setter", {
					Property: "ScrollViewer.HorizontalScrollMode",
					Value: "Auto"
				}),
				w("Setter", {
					Property: "ScrollViewer.HorizontalScrollBarVisibility",
					Value: "Auto"
				}),
				w("Setter", {
					Property: "ScrollViewer.VerticalScrollMode",
					Value: "Auto"
				}),
				w("Setter", {
					Property: "ScrollViewer.VerticalScrollBarVisibility",
					Value: "Auto"
				}),
				w("Setter", {
					Property: "ScrollViewer.ZoomMode",
					Value: "Disabled"
				}),
				w("Setter", {
					Property: "CornerRadius",
					Value: "{ThemeResource OverlayCornerRadius}"
				})
			])] }), t = (e) => w(ue.Content, null, { default: () => [w("div", {
				class: ["win-nav-more-panel", { "win-nav-overflow-panel": e }],
				"data-navigation-owner": h.uid,
				"data-template-part": e ? "TopNavMenuItemsOverflowHost" : "FlyoutContentGrid",
				onKeydown: si,
				onFocusin: li,
				onPointerdownCapture: ci
			}, [w(fa, { Mode: e ? "Overflow" : "ChildrenFlyout" })])] });
			return () => w(Ie, [w(ue, {
				ref: Vt,
				Placement: $t.value,
				onOpened: () => mi(),
				onClosing: ki,
				onClosed: () => {
					z.value || (Ht.value = null);
				}
			}, { default: () => [e(!1), t(!1)] }), w(ue, {
				ref: Wt,
				Placement: "BottomEdgeAlignedRight",
				onOpened: () => mi(!0),
				onClosing: gi,
				onClosed: () => {
					Ut.value || (Gt.value = []);
				}
			}, { default: () => [e(!0), t(!0)] })]);
		} });
		O(Sr, (e) => {
			Ut.value && (Gt.value = e.slice());
		}), Je(Ne, (e) => {
			let t = dt(e, `pane-item-${e.props?.["x:Name"] ?? e.props?.Icon ?? ""}`);
			return t ? ua(Ge(t), B.value ? "TopFooter" : "Left") : null;
		}), O(() => xt.value.map((e) => [
			e.value,
			e.container?.IsExpanded,
			e.container?.IsSelected
		]), (e) => {
			for (let [t, n, r] of e) {
				let e = X(t);
				e?.hasChildren && n !== void 0 && !!n != !!R[t] && (n ? Hr(e.container) : Ur(e.container)), !Z && r === !0 && A.value !== t && (Lr(t, { invoked: !1 }), ri(t));
			}
			Z && Ct(j.value);
		}, { immediate: !0 }), O(A, (e) => {
			Z || (j.value = e);
		}), O(j, Ct, { immediate: !0 }), O(() => xt.value.map((e) => e.value).join("|"), () => T(() => {
			Xr(), ui(), z.value && !X(Ht.value)?.hasChildren && $(), Ut.value && !Sr.value.length && _i(), A.value !== null && A.value !== void 0 && A.value !== "" && A.value !== U.value && !X(A.value) && (yt.value = null, s(m.SelectedItem, null, h), N("update:SelectedItem", null), N("SelectionChanged", {
				SelectedItem: null,
				SelectedItemContainer: null,
				IsSettingsSelected: !1,
				RecommendedNavigationTransitionInfo: Pe()
			})), na();
		}));
		let ha = () => {
			for (let e of Et.value?.querySelectorAll(".win-nav-hamburger, .win-nav-back-button") ?? []) Ce.Attach(e);
			Ce.Refresh();
		};
		O(() => [
			B.value,
			Cn.value,
			wn.value,
			_n.value,
			_.IsEnabled,
			nr.value
		], () => {
			T(ha);
		}, { flush: "post" }), O(R, () => {
			Oe.Refresh();
		}, {
			deep: !0,
			flush: "post"
		}), qe(() => {
			ha(), $i(), Xt.value = Et.value?.clientWidth || Et.value?.offsetWidth || window.innerWidth, Xn = Xt.value, Bi(), oa(), In = new MutationObserver(Zi), sa(), window.addEventListener("resize", ia), window.addEventListener("blur", Yi), document.addEventListener("pointerdown", Vi, !0), la();
		}), Ke(() => {
			on && clearTimeout(on), Q = !0, Mr(), Or += 1, Z?.commit?.release(), Z = null, Hn = null, Un && cancelAnimationFrame(Un), pi(), Fn && Fn.disconnect(), In && In.disconnect(), Ln && cancelAnimationFrame(Ln), Qn && cancelAnimationFrame(Qn), J && clearTimeout(J), Wn?.cancel(), Di && cancelAnimationFrame(Di), tr && cancelAnimationFrame(tr), er?.removeEventListener("scroll", Xi), er = null, ra && cancelAnimationFrame(ra), mr(L.value?.querySelector(".win-nav-indicator"));
			for (let e of ct.values()) {
				let t = e["x:Name"] ?? e["data-xaml-ref"];
				t && tt?.[t] === e && delete tt[t];
			}
			window.removeEventListener("resize", ia), window.removeEventListener("blur", Yi), document.removeEventListener("pointerdown", Vi, !0);
		}), O(() => M.paneDisplayMode, (e, t) => {
			e !== t && (qn = !1), Bi();
		}), O(Qt, (e, t) => {
			e !== t && (Mr(), $(), _i(), Ji(), J && clearTimeout(J), Wn?.cancel(), Wn = null, J = null, F.value = ""), Bi(), e !== t && T(Bi), ca(), e !== t && N("DisplayModeChanged", { DisplayMode: hn.value });
		}), O(() => _.IsPaneVisible, (e) => {
			e ? hn.value === "Expanded" && Li() : ($(), _i(), Ri());
		}), O(() => _.IsEnabled, (e) => {
			e || (Ji(), $(), _i());
		}), O(() => M.isPaneOpen, (e) => {
			let t = !e;
			t !== P.value && (qn = t), t ? Ri(!1) : Li(!1);
		}), O(() => _.SelectedItem, (e) => {
			let t = St(yt.value), n = St(e), r = Z?.value === n ? Z : null;
			if (Z) {
				r || (Z.value = n, yt.value = e);
				return;
			}
			if (t === n) return;
			t !== n && B.value && Y(n) && (Jn = !0);
			let i = Dr(n, n === M.settingsValue);
			if (t !== n) {
				let t = X(n);
				Ir(n, () => (yt.value = e, N("SelectionChanged", {
					SelectedItem: e,
					SelectedItemContainer: t?.container ?? (n === M.settingsValue ? wr : null),
					IsSettingsSelected: n === M.settingsValue,
					RecommendedNavigationTransitionInfo: i
				}), !0), !1, !0);
			}
		}), O(gn, (e) => {
			e || (delete W[U.value], M.selectedValue === U.value && ii(M.menuItems[0]?.value || "", !1));
		});
		let ga = ({ target: e, targetIsChild: t, sourceSnapshot: n = null, allowClippedTarget: r = !1 }) => !e || !L.value ? !1 : (G = e, K = t, ta({
			animateSelectionChange: !0,
			sourceSnapshot: n,
			allowClippedTarget: r
		}), !0);
		O(P, (e) => {
			Un && cancelAnimationFrame(Un), Un = null;
			let t = G, n = L.value, r = !V.value && !B.value && t && n && I.value?.contains(t) ? {
				element: t,
				track: n,
				rect: or(t, n),
				position: cr(t, n),
				clip: sr(t, n)
			} : null;
			Hn = r;
			let i = Qi();
			if (e && i && (Zn = i.scrollTop), !e) {
				let e = Y(M.selectedValue);
				for (; e;) zt[e.value] || (R[e.value] = !0), e = Y(e.value);
			}
			T(() => {
				if (Hn !== r) return;
				Xr();
				let t = () => {
					if (Hn !== r || Q) return;
					if (r && L.value !== r.track) {
						Hn = null, na();
						return;
					}
					let n = Qr(M.selectedValue), i = W[n.value];
					if (r && !e && i && F.value === "opening") {
						let e = sr(i, L.value);
						if (e.top >= e.bottom || e.left >= e.right) {
							Un = requestAnimationFrame(() => {
								Un = null, t();
							});
							return;
						}
					}
					Hn = null, V.value && e || (r ? ga({
						target: i,
						targetIsChild: n.isChild,
						sourceSnapshot: r
					}) : ti(M.selectedValue));
				};
				t(), ea({ restoreScrollOffset: !e });
			});
		}, { flush: "sync" }), O(() => M.selectedValue, (e) => {
			if (Z || !e) return;
			let t = Y(e);
			if (B.value && ui(), B.value && t) {
				if (Jn) {
					Jn = !1;
					return;
				}
				T(() => {
					ti(e);
				});
			}
		});
		let _a = {
			t: be,
			slots: xe,
			attrs: Se,
			commandIconInput: Ce,
			itemIconInput: p,
			backVisualSource: we,
			hamburgerVisualSource: Te,
			settingsVisualSource: Ee,
			groupChevronVisualSource: De,
			groupChevronInput: Oe,
			declaredProps: m,
			componentInstance: h,
			localProperties: g,
			coercedLengthProperties: ke,
			officialProps: _,
			cssLength: Le,
			xamlThickness: b,
			selfAlignment: x,
			getItemTag: S,
			sourceIdentityMap: C,
			get nextSourceIdentity() {
				return Ue;
			},
			set nextSourceIdentity(e) {
				Ue = e;
			},
			getSourceIdentity: We,
			normalizeItem: Ge,
			flattenNavigationNodes: E,
			navigationNodes: Ze,
			names: tt,
			pageResources: nt,
			propertyNodes: k,
			propertyName: rt,
			propertyValue: it,
			hasProperty: at,
			PropertyOutlet: ot,
			ContentOutlet: st,
			xamlItemSources: ct,
			xamlItemDescriptors: lt,
			sameNodes: ut,
			readNavigationItem: dt,
			readPropertyItems: ft,
			resolveItems: pt,
			resourceObject: mt,
			templateRoots: ht,
			sourceItemContainer: gt,
			menuItems: _t,
			footerItems: vt,
			internalSelectedItem: yt,
			flattenItems: bt,
			flattenedItems: xt,
			resolveSelectedValue: St,
			selectedValue: A,
			visualSelectedValue: j,
			synchronizeItemSelection: Ct,
			props: M,
			resolvedSettingsLabel: wt,
			nativeEmit: Tt,
			emit: N,
			isCompact: P,
			paneTransition: F,
			shellRef: Et,
			navRef: I,
			indicatorTrack: L,
			outgoingIndicatorTrack: Dt,
			scrollArea: Ot,
			paneAutoSuggestPresenterRef: kt,
			topPrimaryMenuRef: At,
			topFooterMenuRef: jt,
			topMeasureRef: Mt,
			moreButtonRef: Nt,
			topBackButtonRef: Pt,
			indicatorStyle: Ft,
			indicatorIsChild: It,
			indicatorLeftPx: Lt,
			pressedItemValue: Rt,
			groupExpanded: R,
			manuallyCollapsedGroups: zt,
			groupHeights: Bt,
			flyoutOpen: z,
			childrenFlyoutRef: Vt,
			flyoutGroupValue: Ht,
			moreFlyoutOpen: Ut,
			overflowFlyoutRef: Wt,
			moreFlyoutItems: Gt,
			get flyoutShowVersion() {
				return Kt;
			},
			set flyoutShowVersion(e) {
				Kt = e;
			},
			topAvailableWidth: qt,
			topItemWidths: Jt,
			topMoreButtonWidth: Yt,
			containerWidth: Xt,
			normalizedPaneDisplayMode: Zt,
			resolvedPaneDisplayMode: Qt,
			isTopNavigation: B,
			flyoutPlacement: $t,
			isLeftMinimalMode: V,
			isLeftCompactMode: en,
			isLeftOverlayMode: tn,
			paneShadowDepth: nn,
			paneShadowOpen: rn,
			paneShadowPresent: an,
			get paneShadowTimer() {
				return on;
			},
			set paneShadowTimer(e) {
				on = e;
			},
			isLeftPaneContentVisible: sn,
			isClosedCompact: H,
			isPaneGroupChildrenVisible: cn,
			itemToolTipAttrs: ln,
			isMinimalClosing: un,
			isFullPaneList: dn,
			showPaneTitle: fn,
			paneTitleSpaceVisible: pn,
			paneToggleLabel: mn,
			displayMode: hn,
			isSettingsVisible: gn,
			isPaneToggleButtonVisible: _n,
			paneTitle: vn,
			header: yn,
			shouldShowHeader: bn,
			settingsValue: U,
			settingsLabel: xn,
			settingsIcon: Sn,
			showBackButtonResolved: Cn,
			showBackButtonInLeftNav: wn,
			paneTransitionSpec: Tn,
			paneTransitionDurationMs: En,
			paneBackgroundStyle: Dn,
			minimalPaneBackgroundStyle: On,
			navigationBackgroundStyle: kn,
			paneStyle: An,
			navigationStyle: jn,
			shellClasses: Mn,
			get itemRefs() {
				return W;
			},
			set itemRefs(e) {
				W = e;
			},
			get childrenRefs() {
				return Nn;
			},
			set childrenRefs(e) {
				Nn = e;
			},
			get prevSelectedEl() {
				return Pn;
			},
			set prevSelectedEl(e) {
				Pn = e;
			},
			get lastSelectedEl() {
				return G;
			},
			set lastSelectedEl(e) {
				G = e;
			},
			get lastIsChild() {
				return K;
			},
			set lastIsChild(e) {
				K = e;
			},
			get ro() {
				return Fn;
			},
			set ro(e) {
				Fn = e;
			},
			get layoutObserver() {
				return In;
			},
			set layoutObserver(e) {
				In = e;
			},
			get layoutObserverFrame() {
				return Ln;
			},
			set layoutObserverFrame(e) {
				Ln = e;
			},
			get skipTransition() {
				return q;
			},
			set skipTransition(e) {
				q = e;
			},
			get indicatorAnimationId() {
				return Rn;
			},
			set indicatorAnimationId(e) {
				Rn = e;
			},
			get activeIndicatorTarget() {
				return zn;
			},
			set activeIndicatorTarget(e) {
				zn = e;
			},
			get activeIndicatorGeometry() {
				return Bn;
			},
			set activeIndicatorGeometry(e) {
				Bn = e;
			},
			get indicatorLayoutFrame() {
				return Vn;
			},
			set indicatorLayoutFrame(e) {
				Vn = e;
			},
			get pendingPaneIndicatorSource() {
				return Hn;
			},
			set pendingPaneIndicatorSource(e) {
				Hn = e;
			},
			get paneIndicatorCommitFrame() {
				return Un;
			},
			set paneIndicatorCommitFrame(e) {
				Un = e;
			},
			get paneClipAnimation() {
				return Wn;
			},
			set paneClipAnimation(e) {
				Wn = e;
			},
			get indicatorHiddenByScroll() {
				return Gn;
			},
			set indicatorHiddenByScroll(e) {
				Gn = e;
			},
			get paneTransitionTimer() {
				return J;
			},
			set paneTransitionTimer(e) {
				J = e;
			},
			get paneTransitionGeneration() {
				return Kn;
			},
			set paneTransitionGeneration(e) {
				Kn = e;
			},
			get wasForceClosed() {
				return qn;
			},
			set wasForceClosed(e) {
				qn = e;
			},
			get suppressNextTopChildWatcherMove() {
				return Jn;
			},
			set suppressNextTopChildWatcherMove(e) {
				Jn = e;
			},
			get lastNavigationPointerDownTime() {
				return Yn;
			},
			set lastNavigationPointerDownTime(e) {
				Yn = e;
			},
			get lastResizeShellWidth() {
				return Xn;
			},
			set lastResizeShellWidth(e) {
				Xn = e;
			},
			get expandedPaneVerticalOffset() {
				return Zn;
			},
			set expandedPaneVerticalOffset(e) {
				Zn = e;
			},
			get paneLayoutSyncFrame() {
				return Qn;
			},
			set paneLayoutSyncFrame(e) {
				Qn = e;
			},
			get isRestoringPaneScroll() {
				return $n;
			},
			set isRestoringPaneScroll(e) {
				$n = e;
			},
			get indicatorScrollElement() {
				return er;
			},
			set indicatorScrollElement(e) {
				er = e;
			},
			get indicatorScrollFrame() {
				return tr;
			},
			set indicatorScrollFrame(e) {
				tr = e;
			},
			canGoBack: nr,
			INDICATOR_SIZE: 16,
			EASE_OUT: rr,
			getLayoutPosition: ir,
			getTrackMetrics: ar,
			getTrackRelativeRect: or,
			getIndicatorClip: sr,
			getIndicatorPosition: cr,
			retireOutgoingIndicator: lr,
			syncAnimatingIndicatorLayout: ur,
			clearIndicatorMask: dr,
			setIndicatorVisibility: fr,
			setIndicatorRestingStyle: pr,
			nextIndicatorAnimation: mr,
			childParentMap: hr,
			pendingTopSelectionValue: gr,
			selectedTopRootValue: _r,
			measureTopItemWidth: vr,
			getTopItemsWidth: yr,
			topLayout: br,
			topVisibleMenuItems: xr,
			topOverflowMenuItems: Sr,
			isChildOfGroup: Cr,
			findParentGroup: Y,
			findNormalizedItem: X,
			settingsItem: wr,
			createSettingsItem: Tr,
			getNavigationTransitionIndex: Er,
			createRecommendedNavigationTransitionInfo: Dr,
			get pendingSelectionRequest() {
				return Z;
			},
			set pendingSelectionRequest(e) {
				Z = e;
			},
			get selectionVisualGeneration() {
				return Or;
			},
			set selectionVisualGeneration(e) {
				Or = e;
			},
			get navigationViewUnmounted() {
				return Q;
			},
			set navigationViewUnmounted(e) {
				Q = e;
			},
			get invocationPress() {
				return kr;
			},
			set invocationPress(e) {
				kr = e;
			},
			get pressedElement() {
				return Ar;
			},
			set pressedElement(e) {
				Ar = e;
			},
			get pressedReleaseFrame() {
				return jr;
			},
			set pressedReleaseFrame(e) {
				jr = e;
			},
			clearCommittedItemPress: Mr,
			invokeNavigationItem: Nr,
			showCommittedItemPress: Pr,
			completeNavigationSelection: Fr,
			dispatchNavigationSelection: Ir,
			commitNavigationValue: Lr,
			isFooterValue: Rr,
			getValueForElement: zr,
			setItemRef: Br,
			setChildrenRef: Vr,
			Expand: Hr,
			Collapse: Ur,
			MenuItemFromContainer: Wr,
			ContainerFromMenuItem: Gr,
			controlSender: Kr,
			dependencyPropertySender: qr,
			measureGroupContent: Jr,
			measureGroup: Yr,
			measureAllGroups: Xr,
			collapseOverlayAfterNavigation: Zr,
			getIndicatorTargetForValue: Qr,
			indicatorLeftForElement: $r,
			leftIndicatorStyle: ei,
			moveIndicatorForValue: ti,
			prepareSelectionTarget: ni,
			syncIndicatorForSelectedItem: ri,
			selectNavigationValue: ii,
			onItemClick: ai,
			onChildClick: oi,
			onNavigationKeydown: si,
			onNavigationPointerDown: ci,
			onNavigationFocusIn: li,
			updateTopNavigationLayout: ui,
			get flyoutFocusFrame() {
				return di;
			},
			set flyoutFocusFrame(e) {
				di = e;
			},
			get flyoutFocusVersion() {
				return fi;
			},
			set flyoutFocusVersion(e) {
				fi = e;
			},
			cancelFlyoutFocus: pi,
			focusFlyoutItems: mi,
			openMoreFlyout: hi,
			finishMoreFlyoutClosing: gi,
			closeMoreFlyout: _i,
			toggleMoreFlyout: vi,
			onMoreItemClick: yi,
			onMoreChildClick: bi,
			onMoreGroupHeaderClick: xi,
			onMoreGroupChevronClick: Si,
			toggleLeftGroup: Ci,
			onGroupChevronClick: wi,
			showChildrenFlyout: Ti,
			onGroupHeaderClick: Ei,
			get trackingRaf() {
				return Di;
			},
			set trackingRaf(e) {
				Di = e;
			},
			trackIndicatorDuringTransition: Oi,
			finishChildrenFlyoutClosing: ki,
			closeFlyout: $,
			moveIndicatorTo: Ai,
			moveIndicatorToEl: ji,
			goBack: Mi,
			onBackClick: Ni,
			selectSettings: Pi,
			toggleCompact: Fi,
			setCompact: Ii,
			OpenPane: Li,
			ClosePane: Ri,
			onPaneSearchButtonClick: zi,
			syncDisplayMode: Bi,
			onDocumentPointerDown: Vi,
			onHamburgerDown: Hi,
			onHamburgerUp: Ui,
			onHamburgerLeave: Wi,
			onBackDown: Gi,
			onBackUp: Ki,
			onBackLeave: qi,
			releaseAnimatedIconPresses: Ji,
			onWindowBlur: Yi,
			onScroll: Xi,
			queueLayoutRefresh: Zi,
			getScrollAreaElement: Qi,
			bindIndicatorScrollListener: $i,
			synchronizePaneLayoutTransition: ea,
			calcIndicator: ta,
			restoreIndicatorAfterPaneLayout: na,
			get resizeTimer() {
				return ra;
			},
			set resizeTimer(e) {
				ra = e;
			},
			onResize: ia,
			observeLayoutElements: aa,
			rebindRo: oa,
			rebindLayoutMutationObserver: sa,
			refreshAfterPositionChange: ca,
			initIndicator: la,
			renderNavigationItem: ua,
			renderSettingsItem: da,
			NavigationItems: fa,
			PaneItemsScrollHost: pa,
			NavigationFlyouts: ma,
			attachCommandIconHosts: ha,
			animatePaneIndicatorTransition: ga,
			get NavigationProperties() {
				return Ae;
			},
			ref: D,
			reactive: Ye,
			computed: y,
			defineComponent: Re,
			Fragment: Ie,
			h: w,
			getCurrentInstance: ze,
			onMounted: qe,
			onBeforeUnmount: Ke,
			watch: O,
			nextTick: T,
			useSlots: et,
			useAttrs: $e,
			toRaw: Qe,
			inject: Be,
			provide: Je,
			isVNode: Ve,
			markRaw: He,
			shallowReactive: Xe,
			Flyout: ue,
			ScrollViewer: se,
			InfoBadge: _e,
			ContentPresenter: ce,
			Viewbox: te,
			TextBlock: ie,
			AnimatedIcon: oe,
			get FontIconSource() {
				return de;
			},
			get createAnimatedIconSource() {
				return ae;
			},
			get useAnimatedIconInput() {
				return le;
			},
			get captureFrameNavigationCommit() {
				return fe;
			},
			get hasPendingRouteNavigation() {
				return pe;
			},
			get navigationInputFrozen() {
				return me;
			},
			get pendingNavigationCompletion() {
				return he;
			},
			get pendingRouteNavigationCompletion() {
				return ge;
			},
			get useI18n() {
				return ne;
			},
			get getNavigationViewProperty() {
				return je;
			},
			get navigationItemType() {
				return Me;
			},
			get navigationVNodeChildren() {
				return v;
			},
			get navigationViewItemRendererKey() {
				return Ne;
			},
			get normalizeXamlNodes() {
				return r;
			},
			get resolveXamlValue() {
				return o;
			},
			get resolveXamlHandler() {
				return i;
			},
			get materializeXamlVNode() {
				return n;
			},
			get resolveXamlResourceObject() {
				return a;
			},
			get updateXamlBinding() {
				return s;
			},
			get xamlNameScopeKey() {
				return c;
			},
			get xamlScopeKey() {
				return l;
			},
			xamlResourceDictionaryKey: re,
			get resolveSymbolGlyph() {
				return ee;
			},
			get resolveAcrylicResource() {
				return e;
			},
			get useAcrylicBrushStyle() {
				return t;
			},
			get vAcrylicBrush() {
				return u;
			},
			get vThemeShadow() {
				return d;
			},
			get createEntranceNavigationTransitionInfo() {
				return Pe;
			},
			get createSlideNavigationTransitionInfo() {
				return Fe;
			}
		};
		return Object.defineProperty(_a, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), _a;
	}
}), it = ["aria-disabled"], at = {
	class: "win-nav-indicator-track",
	ref: "indicatorTrack"
}, ot = {
	class: "win-nav-indicator-track",
	ref: "outgoingIndicatorTrack",
	"aria-hidden": "true"
}, st = ["disabled", "aria-label"], ct = {
	key: 1,
	class: "win-nav-top-fixed win-nav-top-pane-header"
}, lt = {
	key: 2,
	class: "win-nav-top-fixed win-nav-top-pane-title"
}, ut = {
	class: "win-nav-menu win-nav-top-primary-menu",
	"data-template-part": "TopNavMenuItemsHost",
	ref: "topPrimaryMenuRef"
}, dt = [
	"disabled",
	"aria-label",
	"aria-expanded"
], ft = {
	key: 0,
	class: "label"
}, pt = { class: "win-nav-top-pane-custom-content" }, mt = {
	key: 3,
	class: "win-nav-top-fixed win-nav-top-pane-search"
}, ht = {
	key: 4,
	class: "win-nav-top-fixed win-nav-top-pane-footer"
}, gt = {
	class: "win-nav-menu win-nav-top-footer-menu",
	"data-template-part": "TopNavFooterMenuItemsHost",
	ref: "topFooterMenuRef"
}, _t = {
	class: "win-nav-top-measure",
	ref: "topMeasureRef",
	"aria-hidden": "true",
	inert: ""
}, vt = {
	class: "win-nav-item win-nav-more-button",
	"data-value": "__more"
}, yt = {
	key: 0,
	class: "label"
}, bt = ["disabled", "aria-label"], xt = {
	key: 1,
	class: "win-nav-pane-command-row",
	"data-template-part": "PaneContentGridToggleButtonRow"
}, St = [
	"disabled",
	"aria-label",
	"aria-expanded"
], A = {
	key: 0,
	class: "win-nav-pane-title"
}, j = ["aria-hidden", "inert"], Ct = {
	class: "win-nav-indicator-track",
	ref: "indicatorTrack"
}, M = {
	class: "win-nav-indicator-track",
	ref: "outgoingIndicatorTrack",
	"aria-hidden": "true"
}, wt = {
	key: 0,
	class: "win-nav-pane-title-holder"
}, Tt = { class: "win-nav-pane-title" }, N = { class: "win-nav-pane-search" }, P = {
	class: "win-nav-pane-search-presenter",
	ref: "paneAutoSuggestPresenterRef"
}, F = ["aria-label"], Et = {
	key: 3,
	class: "win-nav-pane-custom-content"
}, I = {
	class: "win-nav-footer",
	"data-template-part": "FooterMenuItemsHost"
}, L = {
	key: 0,
	class: "win-nav-pane-footer"
}, Dt = {
	class: "win-nav-content",
	"data-template-part": "ContentGrid"
}, Ot = {
	key: 0,
	class: "win-nav-page-header",
	"data-template-part": "HeaderContent"
}, kt = {
	class: "win-nav-content-inner",
	"data-template-part": "ContentPresenter"
}, At = {
	key: 1,
	class: "win-nav-content-overlay"
};
function jt(e, t, n, r, i, a) {
	return k((E(), x("div", {
		class: We(["win-nav-shell", r.shellClasses]),
		style: Ge(r.navigationStyle),
		ref: "shellRef",
		"aria-disabled": !r.officialProps.IsEnabled || void 0
	}, [
		k(S("div", {
			class: We(["win-nav-shadow-caster", { "is-overlaying": r.paneShadowOpen }]),
			"data-template-part": "ShadowCaster",
			"aria-hidden": "true"
		}, null, 2), [[r.vThemeShadow, {
			Translation: r.paneShadowDepth,
			Enabled: r.paneShadowPresent
		}]]),
		r.isTopNavigation ? (E(), x("nav", {
			key: 0,
			class: "win-nav-top-bar",
			"data-template-part": "TopNavGrid",
			ref: "navRef",
			onKeydown: r.onNavigationKeydown,
			onFocusin: r.onNavigationFocusIn,
			onPointerdownCapture: r.onNavigationPointerDown
		}, [
			S("div", at, [S("div", {
				class: "win-nav-indicator",
				style: Ge(r.indicatorStyle)
			}, null, 4)], 512),
			S("div", ot, [...t[24] ||= [S("div", {
				class: "win-nav-indicator win-nav-indicator-outgoing",
				style: { opacity: "0" }
			}, null, -1)]], 512),
			r.showBackButtonResolved ? (E(), x("button", Ue({
				key: 0,
				class: "win-nav-back-button",
				disabled: !r.canGoBack,
				"aria-label": r.t("text.back")
			}, { "ToolTipService.ToolTip": r.t("text.back") }, {
				onClick: r.onBackClick,
				onPointerenter: t[0] ||= (...e) => r.commandIconInput.PointerEntered && r.commandIconInput.PointerEntered(...e),
				onPointerdown: t[1] ||= (...e) => r.onBackDown && r.onBackDown(...e),
				onPointerup: t[2] ||= (...e) => r.onBackUp && r.onBackUp(...e),
				onPointercancel: t[3] ||= (...e) => r.onBackLeave && r.onBackLeave(...e),
				onPointerleave: t[4] ||= (...e) => r.onBackLeave && r.onBackLeave(...e),
				onKeydown: t[5] ||= (...e) => r.commandIconInput.KeyDown && r.commandIconInput.KeyDown(...e),
				onKeyup: t[6] ||= (...e) => r.commandIconInput.KeyUp && r.commandIconInput.KeyUp(...e),
				onFocusout: t[7] ||= (...e) => r.commandIconInput.LostFocus && r.commandIconInput.LostFocus(...e),
				ref: "topBackButtonRef"
			}), [C(r.AnimatedIcon, {
				class: "icon",
				Source: "{x:Bind backVisualSource}",
				Width: "16",
				Height: "16",
				HorizontalAlignment: "Center",
				VerticalAlignment: "Center",
				MirroredWhenRightToLeft: "True"
			}, {
				default: nt(() => [C(r.AnimatedIcon.FallbackIconSource, null, {
					default: nt(() => [C(r.FontIconSource, {
						Glyph: "",
						FontSize: "16",
						FontFamily: "{ThemeResource SymbolThemeFontFamily}",
						MirroredWhenRightToLeft: "True"
					})]),
					_: 1
				})]),
				_: 1
			})], 16, st)) : b("", !0),
			r.hasProperty("paneHeader") ? (E(), x("div", ct, [C(r.PropertyOutlet, { Property: "paneHeader" })])) : r.paneTitle ? (E(), x("div", lt, Ze(r.paneTitle), 1)) : b("", !0),
			S("div", ut, [C(r.NavigationItems, { Mode: "Top" }), r.topOverflowMenuItems.length ? (E(), x("button", Ue({
				key: 0,
				class: "win-nav-item win-nav-more-button",
				disabled: !r.officialProps.IsEnabled,
				"aria-label": r.t("text.more"),
				"aria-expanded": r.moreFlyoutOpen
			}, { "ToolTipService.ToolTip": r.t("text.more") }, {
				onClick: r.toggleMoreFlyout,
				ref: "moreButtonRef"
			}), [t[25] ||= S("span", { class: "icon" }, "", -1), r.officialProps.OverflowLabelMode === "MoreLabel" ? (E(), x("span", ft, Ze(r.t("text.more")), 1)) : b("", !0)], 16, dt)) : b("", !0)], 512),
			S("div", pt, [C(r.PropertyOutlet, { Property: "paneCustomContent" })]),
			r.hasProperty("autoSuggestBox") ? (E(), x("div", mt, [C(r.PropertyOutlet, { Property: "autoSuggestBox" })])) : b("", !0),
			r.hasProperty("paneFooter") ? (E(), x("div", ht, [C(r.PropertyOutlet, { Property: "paneFooter" })])) : b("", !0),
			S("div", gt, [C(r.NavigationItems, { Mode: "TopFooter" })], 512),
			S("div", _t, [C(r.NavigationItems, { Mode: "Measure" }), S("div", vt, [t[26] ||= S("span", { class: "icon" }, "", -1), r.officialProps.OverflowLabelMode === "MoreLabel" ? (E(), x("span", yt, Ze(r.t("text.more")), 1)) : b("", !0)])], 512)
		], 544)) : k((E(), x("nav", {
			key: 1,
			class: We(["win-nav-left-panel", [{
				"is-compact": r.isCompact,
				"is-closed-compact": r.isClosedCompact,
				"is-minimal": r.isLeftMinimalMode,
				"has-back-button": r.showBackButtonInLeftNav,
				"has-pane-toggle-button": r.isPaneToggleButtonVisible
			}, r.paneTransition ? `is-pane-${r.paneTransition}` : ""]]),
			"data-template-part": "PaneContentGrid",
			style: Ge([r.paneStyle, r.paneBackgroundStyle]),
			ref: "navRef",
			onKeydown: r.onNavigationKeydown,
			onFocusin: r.onNavigationFocusIn,
			onPointerdownCapture: r.onNavigationPointerDown
		}, [
			r.showBackButtonInLeftNav ? (E(), x("button", Ue({
				key: 0,
				class: "win-nav-back-button",
				disabled: !r.canGoBack,
				"aria-label": r.t("text.back")
			}, { "ToolTipService.ToolTip": r.t("text.back") }, {
				onClick: r.onBackClick,
				onPointerenter: t[8] ||= (...e) => r.commandIconInput.PointerEntered && r.commandIconInput.PointerEntered(...e),
				onPointerdown: t[9] ||= (...e) => r.onBackDown && r.onBackDown(...e),
				onPointerup: t[10] ||= (...e) => r.onBackUp && r.onBackUp(...e),
				onPointerleave: t[11] ||= (...e) => r.onBackLeave && r.onBackLeave(...e),
				onPointercancel: t[12] ||= (...e) => r.onBackLeave && r.onBackLeave(...e),
				onKeydown: t[13] ||= (...e) => r.commandIconInput.KeyDown && r.commandIconInput.KeyDown(...e),
				onKeyup: t[14] ||= (...e) => r.commandIconInput.KeyUp && r.commandIconInput.KeyUp(...e),
				onFocusout: t[15] ||= (...e) => r.commandIconInput.LostFocus && r.commandIconInput.LostFocus(...e)
			}), [C(r.AnimatedIcon, {
				class: "icon",
				Source: "{x:Bind backVisualSource}",
				Width: "16",
				Height: "16",
				HorizontalAlignment: "Center",
				VerticalAlignment: "Center",
				MirroredWhenRightToLeft: "True"
			}, {
				default: nt(() => [C(r.AnimatedIcon.FallbackIconSource, null, {
					default: nt(() => [C(r.FontIconSource, {
						Glyph: "",
						FontSize: "16",
						FontFamily: "{ThemeResource SymbolThemeFontFamily}",
						MirroredWhenRightToLeft: "True"
					})]),
					_: 1
				})]),
				_: 1
			})], 16, bt)) : b("", !0),
			r.isPaneToggleButtonVisible ? (E(), x("div", xt, [S("button", Ue({
				class: ["win-nav-hamburger", { "has-pane-title": r.paneTitle && r.paneTitleSpaceVisible }],
				disabled: !r.officialProps.IsEnabled,
				"aria-label": r.paneToggleLabel,
				"aria-expanded": !r.isCompact
			}, { "ToolTipService.ToolTip": r.paneToggleLabel }, {
				onClick: r.toggleCompact,
				onPointerenter: t[16] ||= (...e) => r.commandIconInput.PointerEntered && r.commandIconInput.PointerEntered(...e),
				onPointerdown: t[17] ||= (...e) => r.onHamburgerDown && r.onHamburgerDown(...e),
				onPointerup: t[18] ||= (...e) => r.onHamburgerUp && r.onHamburgerUp(...e),
				onPointerleave: t[19] ||= (...e) => r.onHamburgerLeave && r.onHamburgerLeave(...e),
				onPointercancel: t[20] ||= (...e) => r.onHamburgerLeave && r.onHamburgerLeave(...e),
				onKeydown: t[21] ||= (...e) => r.commandIconInput.KeyDown && r.commandIconInput.KeyDown(...e),
				onKeyup: t[22] ||= (...e) => r.commandIconInput.KeyUp && r.commandIconInput.KeyUp(...e),
				onFocusout: t[23] ||= (...e) => r.commandIconInput.LostFocus && r.commandIconInput.LostFocus(...e)
			}), [C(r.AnimatedIcon, {
				class: "icon",
				Source: "{x:Bind hamburgerVisualSource}",
				Width: "16",
				Height: "16",
				HorizontalAlignment: "Center",
				VerticalAlignment: "Center"
			}, {
				default: nt(() => [C(r.AnimatedIcon.FallbackIconSource, null, {
					default: nt(() => [C(r.FontIconSource, {
						Glyph: "",
						FontSize: "16"
					})]),
					_: 1
				})]),
				_: 1
			}), r.paneTitle && r.showPaneTitle ? (E(), x("span", A, Ze(r.paneTitle), 1)) : b("", !0)], 16, St)])) : b("", !0),
			k((E(), x("div", {
				class: "win-nav-pane-surface",
				style: Ge(r.isLeftMinimalMode ? r.minimalPaneBackgroundStyle : void 0),
				"aria-hidden": r.isLeftMinimalMode && r.isCompact || void 0,
				inert: r.isLeftMinimalMode && r.isCompact
			}, [
				S("div", Ct, [S("div", {
					class: We(["win-nav-indicator", { "is-child": r.indicatorIsChild }]),
					style: Ge(r.leftIndicatorStyle)
				}, null, 6)], 512),
				S("div", M, [...t[27] ||= [S("div", {
					class: "win-nav-indicator win-nav-indicator-outgoing",
					style: { opacity: "0" }
				}, null, -1)]], 512),
				!r.isPaneToggleButtonVisible && r.paneTitle && r.showPaneTitle ? (E(), x("div", wt, [S("span", Tt, Ze(r.paneTitle), 1)])) : b("", !0),
				r.hasProperty("paneHeader") ? k((E(), x("div", {
					key: 1,
					class: We(["win-nav-pane-header", { "has-pane-toggle": r.isPaneToggleButtonVisible }])
				}, [C(r.PropertyOutlet, { Property: "paneHeader" })], 2)), [[tt, r.isFullPaneList]]) : b("", !0),
				r.hasProperty("autoSuggestBox") ? (E(), x("div", {
					key: 2,
					class: We(["win-nav-pane-top", { "is-closed-compact": r.isClosedCompact }])
				}, [S("div", N, [k(S("div", P, [C(r.PropertyOutlet, { Property: "autoSuggestBox" })], 512), [[tt, !r.isClosedCompact]]), k(S("button", {
					class: "win-nav-pane-search-button",
					"aria-label": r.t("text.search"),
					onClick: r.onPaneSearchButtonClick
				}, [...t[28] ||= [S("span", { class: "icon" }, "", -1)]], 8, F), [[tt, r.isClosedCompact]])])], 2)) : b("", !0),
				r.hasProperty("paneCustomContent") ? (E(), x("div", Et, [C(r.PropertyOutlet, { Property: "paneCustomContent" })])) : b("", !0),
				C(r.PaneItemsScrollHost),
				S("div", I, [r.hasProperty("paneFooter") ? (E(), x("div", L, [C(r.PropertyOutlet, { Property: "paneFooter" })])) : b("", !0), C(r.NavigationItems, { Mode: "Footer" })])
			], 12, j)), [[tt, r.isLeftPaneContentVisible], [
				r.vAcrylicBrush,
				r.isLeftMinimalMode ? r.minimalPaneBackgroundStyle : void 0,
				void 0,
				{ "host-backdrop": !0 }
			]])
		], 38)), [[
			r.vAcrylicBrush,
			r.paneBackgroundStyle,
			void 0,
			{ "host-backdrop": !0 }
		]]),
		S("main", Dt, [
			r.shouldShowHeader ? (E(), x("div", Ot, [C(r.PropertyOutlet, { Property: "header" })])) : b("", !0),
			S("div", kt, [r.hasProperty("content") ? (E(), Le(r.PropertyOutlet, {
				key: 0,
				Property: "content"
			})) : (E(), Le(r.ContentOutlet, { key: 1 }))]),
			r.hasProperty("contentOverlay") ? (E(), x("div", At, [C(r.PropertyOutlet, { Property: "contentOverlay" })])) : b("", !0)
		]),
		C(r.NavigationFlyouts)
	], 14, it)), [[r.vAcrylicBrush, r.navigationBackgroundStyle]]);
}
var Mt = /*#__PURE__*/ f(rt, [["render", jt], ["__file", "NavigationView.vue"]]);
//#endregion
export { Mt as default };

//# sourceMappingURL=NavigationView.vue.js.map