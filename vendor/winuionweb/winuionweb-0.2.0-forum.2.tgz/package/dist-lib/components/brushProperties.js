import { useAcrylicBrushStyle as e } from "./AcrylicBrush.js";
import { resolveXamlValue as t, xamlNameScopeKey as n } from "./xamlRuntime.js";
import { xamlResourceNodesEqual as r } from "./xamlBrushResources.js";
import { Comment as i, Fragment as a, Text as o, computed as s, defineComponent as c, onBeforeUnmount as l, shallowRef as u } from "vue";
//#region src/components/brushProperties.ts
var d = (e, t) => c({
	name: `${e}.${t}`,
	__xamlBrushProperty: t,
	setup: () => () => null
}), f = (e) => Array.isArray(e.children) ? e.children : e.children?.default?.() ?? [], p = (e) => !!e.type?.__xamlBrushProperty, m = (c, d, p, m) => {
	let h = u(), g, _, v, y = m?.provides[n], b = [], x = () => {
		b.forEach((e) => e()), b = [], v && y && y[v] === _ && delete y[v], v = void 0;
	};
	l(x);
	let S = (e) => {
		for (let t of e) {
			if (t.type === a) {
				let e = S(f(t));
				if (e) return e;
			}
			if (t.type?.__xamlBrushProperty === c) return f(t).find((e) => e.type !== i && !(e.type === o && !String(e.children ?? "").trim()));
		}
	}, C = s(() => {
		let e = S(p());
		if (!e) return g && (x(), g = void 0, h.value = void 0, _ = void 0), t(d(), m);
		let n = e.type;
		e.type === g ? r(h.value, e) || (h.value = e) : (x(), g = e.type, h.value = e, _ = n.__createXamlResource?.((e) => t(h.value?.props?.[e], m), {
			Dispose: (e) => b.push(e),
			Node: () => h.value,
			instance: m
		}));
		let i = e.props?.["x:Name"] ?? e.props?.["data-xaml-ref"];
		return v && v !== i && y && y[v] === _ && (delete y[v], v = void 0), typeof i == "string" && y && y[i] !== _ && (y[i] = _, v = i), _;
	});
	return {
		value: C,
		style: e(() => C.value, m)
	};
};
//#endregion
export { d as brushProperty, p as isBrushProperty, m as useBrushProperty };

//# sourceMappingURL=brushProperties.js.map