import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./ContentDialog.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                  */
import { Fragment as n, Teleport as r, Transition as i, createBlock as a, createCommentVNode as o, createElementBlock as s, createElementVNode as c, createVNode as l, normalizeClass as u, normalizeStyle as d, openBlock as f, withCtx as p, withDirectives as m } from "vue";
//#region src/components/ContentDialog.vue
var h = {
	ref: "host",
	class: "content-dialog-host",
	hidden: ""
}, g = {
	class: "content-dialog-layout-root",
	"data-template-part": "LayoutRoot"
}, _ = [
	"aria-labelledby",
	"aria-label",
	"aria-disabled"
], v = ["inert"];
function y(e, t, y, b, x, S) {
	return f(), s(n, null, [c("span", h, null, 512), (f(), a(r, {
		to: "body",
		disabled: b.placement === "InPlace"
	}, [l(i, {
		name: "content-dialog",
		duration: {
			enter: 250,
			leave: 167
		},
		onAfterLeave: b.finishClose
	}, {
		default: p(() => [b.isShowing ? (f(), s("div", {
			key: 0,
			ref: "layoutRoot",
			class: u(["content-dialog-container win-theme-scope", [b.themeClass, {
				"content-dialog-in-place": b.placement === "InPlace",
				"content-dialog-full-size": b.FullSizeDesired,
				"content-dialog-disabled": !b.IsEnabled
			}]]),
			style: d(b.containerStyle),
			"data-template-part": "Container"
		}, [c("div", g, [t[0] ||= c("div", {
			class: "content-dialog-smoke-layer",
			"data-template-part": "SmokeLayerBackground"
		}, null, -1), m((f(), s("section", {
			ref: "backgroundElement",
			class: "content-dialog",
			style: d(b.backgroundStyle),
			role: "dialog",
			"aria-modal": "true",
			"aria-labelledby": b.hasTitle ? b.titleId : void 0,
			"aria-label": b.automationName || void 0,
			"aria-disabled": !b.IsEnabled || void 0,
			tabindex: "-1",
			"data-template-part": "BackgroundElement",
			onKeydown: b.onKeyDown
		}, [l(b.Grid, {
			class: "content-dialog-space",
			CornerRadius: "{ThemeResource OverlayCornerRadius}"
		}, {
			default: p(() => [
				l(b.Grid.RowDefinitions, null, {
					default: p(() => [l(b.RowDefinition, { Height: "*" }), l(b.RowDefinition, { Height: "Auto" })]),
					_: 1
				}),
				l(b.ScrollViewer, {
					class: "content-dialog-content-scroll-viewer",
					HorizontalScrollBarVisibility: "Disabled",
					VerticalScrollBarVisibility: "Disabled",
					ZoomMode: "Disabled",
					IsTabStop: "False",
					"data-template-part": "ContentScrollViewer"
				}, {
					default: p(() => [l(b.Grid, {
						class: "content-dialog-content-grid",
						Background: "{ThemeResource ContentDialogTopOverlay}",
						Padding: "{ThemeResource ContentDialogPadding}",
						BorderThickness: "{ThemeResource ContentDialogSeparatorThickness}",
						BorderBrush: "{ThemeResource ContentDialogSeparatorBorderBrush}"
					}, {
						default: p(() => [
							l(b.Grid.RowDefinitions, null, {
								default: p(() => [l(b.RowDefinition, { Height: "Auto" }), l(b.RowDefinition, { Height: "*" })]),
								_: 1
							}),
							b.hasTitle ? (f(), s("div", {
								key: 0,
								id: b.titleId,
								class: "content-dialog-title",
								"data-template-part": "Title"
							}, [l(b.TitleOutlet)])) : o("", !0),
							c("div", {
								ref: "contentElement",
								class: "content-dialog-body",
								inert: !b.IsEnabled,
								"Grid.Row": "1",
								"data-template-part": "Content"
							}, [l(b.ContentOutlet)], 8, v)
						]),
						_: 1
					})]),
					_: 1
				}),
				b.hasCommandButtons ? (f(), a(b.Grid, {
					key: 0,
					class: u(["content-dialog-command-space", b.buttonVisibilityClass]),
					"Grid.Row": "1",
					HorizontalAlignment: "Stretch",
					VerticalAlignment: "Bottom",
					Padding: "{ThemeResource ContentDialogPadding}",
					Background: "{x:Bind DialogBackground}",
					"data-template-part": "CommandSpace"
				}, {
					default: p(() => [
						l(b.Grid.ColumnDefinitions, null, {
							default: p(() => [
								l(b.ColumnDefinition, { Width: "*" }),
								l(b.ColumnDefinition, { Width: "{x:Bind FirstSpacerWidth}" }),
								l(b.ColumnDefinition, { Width: "{x:Bind SecondaryColumnWidth}" }),
								l(b.ColumnDefinition, { Width: "{ThemeResource ContentDialogButtonSpacing}" }),
								l(b.ColumnDefinition, { Width: "*" })
							]),
							_: 1
						}),
						l(b.Button, {
							Visibility: "{x:Bind PrimaryButtonVisibility, Mode=OneWay}",
							class: "content-dialog-button content-dialog-primary",
							"Grid.Column": "{x:Bind PrimaryButtonColumn}",
							Content: "{x:Bind PrimaryButtonText}",
							Style: "{x:Bind PrimaryButtonStyle}",
							IsEnabled: "{x:Bind IsPrimaryButtonEnabled}",
							HorizontalAlignment: "Stretch",
							"data-template-part": "PrimaryButton",
							Click: "OnPrimaryButtonClick"
						}),
						l(b.Button, {
							Visibility: "{x:Bind SecondaryButtonVisibility, Mode=OneWay}",
							class: "content-dialog-button content-dialog-secondary",
							"Grid.Column": "{x:Bind SecondaryButtonColumn}",
							Content: "{x:Bind SecondaryButtonText}",
							Style: "{x:Bind SecondaryButtonStyle}",
							IsEnabled: "{x:Bind IsSecondaryButtonEnabled}",
							HorizontalAlignment: "Stretch",
							"data-template-part": "SecondaryButton",
							Click: "OnSecondaryButtonClick"
						}),
						l(b.Button, {
							Visibility: "{x:Bind CloseButtonVisibility, Mode=OneWay}",
							class: "content-dialog-button content-dialog-close",
							"Grid.Column": "4",
							Content: "{x:Bind CloseButtonText}",
							Style: "{x:Bind CloseButtonStyle}",
							IsEnabled: "{x:Bind IsCloseButtonEnabled}",
							HorizontalAlignment: "Stretch",
							"data-template-part": "CloseButton",
							Click: "OnCloseButtonClick"
						})
					]),
					_: 1
				}, 8, ["class"])) : o("", !0)
			]),
			_: 1
		})], 44, _)), [[b.vThemeShadow, { Translation: 128 }]])])], 6)) : o("", !0)]),
		_: 1
	})], 8, ["disabled"]))], 64);
}
var b = /*#__PURE__*/ e(t, [["render", y], ["__file", "ContentDialog.vue"]]);
//#endregion
export { b as default };

//# sourceMappingURL=ContentDialog.vue.js.map