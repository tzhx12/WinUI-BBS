import { alignment as e, cssLength as t, xamlThickness as n } from "./layout.js";
import { resolveXamlValue as r, updateXamlBinding as i } from "./xamlRuntime.js";
import { Comment as a, Fragment as o, Text as s, computed as c, defineComponent as l, getCurrentInstance as ee, isVNode as u, nextTick as te, onBeforeUnmount as d, onMounted as ne, onUpdated as re, ref as f, shallowRef as ie, useAttrs as ae, useSlots as p, watch as m } from "vue";
//#region src/components/Viewbox.vue?vue&type=script&setup=true&lang.ts
var h = l({
	name: "Viewbox.Child",
	__viewboxChildProperty: !0,
	setup: () => () => null
}), g = /*@__PURE__*/ l({
	Child: h,
	inheritAttrs: !1,
	__name: "Viewbox",
	props: {
		Child: {
			type: null,
			default: void 0
		},
		Width: {
			type: [String, Number],
			default: ""
		},
		Height: {
			type: [String, Number],
			default: ""
		},
		MinWidth: {
			type: [String, Number],
			default: 0
		},
		MinHeight: {
			type: [String, Number],
			default: 0
		},
		MaxWidth: {
			type: [String, Number],
			default: ""
		},
		MaxHeight: {
			type: [String, Number],
			default: ""
		},
		Margin: {
			type: [String, Number],
			default: ""
		},
		Visibility: {
			type: String,
			default: "Visible"
		},
		Stretch: {
			type: String,
			default: "Uniform"
		},
		StretchDirection: {
			type: String,
			default: "Both"
		},
		HorizontalAlignment: {
			type: String,
			default: "Stretch"
		},
		VerticalAlignment: {
			type: String,
			default: "Stretch"
		}
	},
	emits: [
		"update:Child",
		"update:Stretch",
		"update:StretchDirection"
	],
	setup(l, { expose: g, emit: _ }) {
		let v = l, y = _, b = ae(), x = p(), S = ee(), C = f(null), w = f(null), T = f({
			width: 0,
			height: 0
		}), E = f({
			width: Infinity,
			height: Infinity
		}), D = f({
			width: 0,
			height: 0
		}), O = f(), k = f(), A = ie(), j = c(() => Object.fromEntries(Object.entries(v).map(([e, t]) => [e, r(t, S)]))), M = c(() => O.value ?? String(j.value.Stretch ?? "Uniform")), N = c(() => k.value ?? String(j.value.StretchDirection ?? "Both")), P = (e) => e.flatMap((e) => {
			if (e.type === a || e.type === s && !String(e.children ?? "").trim()) return [];
			if (e.type === o) return P(e.children ?? []);
			if (e.type?.__viewboxChildProperty) {
				let t = e.children;
				return P(t?.default?.() ?? []);
			}
			return [e];
		}), F = () => {
			if (A.value !== void 0) return A.value;
			if (u(j.value.Child)) return j.value.Child;
			let e = P(x.default?.() ?? []);
			if (e.length > 1) throw Error("Viewbox can contain only one child.");
			return e[0] ?? null;
		}, I = c(() => {
			let { class: e, style: t, ...n } = b;
			return n;
		}), L = (e, t = Infinity) => {
			if (e === "" || e == null || String(e) === "Auto") return t;
			let n = Number(String(e).replace(/px$/, ""));
			return Number.isFinite(n) ? Math.max(0, n) : t;
		}, R = (e, t, n) => Math.max(L(t, 0), Math.min(L(n), e)), z = (e, t) => {
			let n = 1, r = 1, i = Number.isFinite(e.width), a = Number.isFinite(e.height);
			return M.value !== "None" && (i || a) && (n = t.width === 0 ? 0 : e.width / t.width, r = t.height === 0 ? 0 : e.height / t.height, i ? a ? M.value === "Uniform" ? n = r = Math.min(n, r) : M.value === "UniformToFill" && (n = r = Math.max(n, r)) : r = n : n = r, N.value === "UpOnly" ? (n = Math.max(1, n), r = Math.max(1, r)) : N.value === "DownOnly" && (n = Math.min(1, n), r = Math.min(1, r))), {
				x: n,
				y: r
			};
		}, B = c(() => ({
			width: R(L(j.value.Width, E.value.width), j.value.MinWidth, j.value.MaxWidth),
			height: R(L(j.value.Height, E.value.height), j.value.MinHeight, j.value.MaxHeight)
		})), V = c(() => {
			let e = z(B.value, T.value);
			return {
				width: e.x * T.value.width,
				height: e.y * T.value.height
			};
		}), oe = c(() => {
			let r = {
				display: j.value.Visibility === "Collapsed" ? "none" : "",
				width: t(j.value.Width) || `${V.value.width}px`,
				height: t(j.value.Height) || `${V.value.height}px`,
				minWidth: t(j.value.MinWidth),
				minHeight: t(j.value.MinHeight),
				maxWidth: t(j.value.MaxWidth),
				maxHeight: t(j.value.MaxHeight),
				margin: n(j.value.Margin),
				justifySelf: e(j.value.HorizontalAlignment, "horizontal"),
				alignSelf: e(j.value.VerticalAlignment, "vertical")
			};
			return [b.style, r];
		}), H = (e, t, n) => n === "Left" || n === "Top" ? 0 : n === "Right" || n === "Bottom" ? e - t : n === "Stretch" && t > e ? 0 : (e - t) / 2, se = c(() => {
			let e = {
				width: D.value.width || L(j.value.Width, V.value.width),
				height: D.value.height || L(j.value.Height, V.value.height)
			}, t = z(e, T.value);
			return {
				left: `${H(e.width, T.value.width * t.x, j.value.HorizontalAlignment)}px`,
				top: `${H(e.height, T.value.height * t.y, j.value.VerticalAlignment)}px`,
				transform: `scale(${t.x}, ${t.y})`
			};
		}), U, W, G = 0, K = !1, q = (e, t, n) => {
			(e.value.width !== t || e.value.height !== n) && (e.value = {
				width: t,
				height: n
			});
		}, J = () => {
			G = 0;
			let e = C.value, t = w.value;
			if (!e || !t) return;
			q(T, t.offsetWidth, t.offsetHeight), q(D, e.clientWidth, e.clientHeight);
			let n = e.parentElement;
			if (!n) return;
			if (n.classList.contains("win-viewbox-container")) {
				q(E, Infinity, Infinity);
				return;
			}
			let r = getComputedStyle(n), i = getComputedStyle(e), a = r.display.includes("flex") && r.flexDirection.startsWith("row"), o = r.display.includes("flex") && r.flexDirection.startsWith("column"), s = a ? Infinity : Math.max(0, n.clientWidth - (parseFloat(r.paddingLeft) || 0) - (parseFloat(r.paddingRight) || 0) - (parseFloat(i.marginLeft) || 0) - (parseFloat(i.marginRight) || 0)), c = n.style.height !== "" || n.style.minHeight !== "" || n.classList.contains("win-grid");
			q(E, s, o || !c ? Infinity : Math.max(0, n.clientHeight - (parseFloat(r.paddingTop) || 0) - (parseFloat(r.paddingBottom) || 0) - (parseFloat(i.marginTop) || 0) - (parseFloat(i.marginBottom) || 0)));
		}, Y = () => {
			K || G || (G = requestAnimationFrame(J));
		};
		ne(async () => {
			await te(), !K && (J(), w.value?.addEventListener("load", Y, !0), w.value?.addEventListener("error", Y, !0), typeof ResizeObserver < "u" && (U = new ResizeObserver(Y), C.value && U.observe(C.value), w.value && U.observe(w.value), C.value?.parentElement && U.observe(C.value.parentElement)), W = new MutationObserver((e) => {
				e.some((e) => e.target !== w.value || e.type !== "attributes") && Y();
			}), w.value && W.observe(w.value, {
				childList: !0,
				subtree: !0,
				characterData: !0,
				attributes: !0,
				attributeFilter: [
					"src",
					"width",
					"height",
					"style",
					"class"
				]
			}), document.fonts?.addEventListener("loadingdone", Y));
		}), re(Y), d(() => {
			K = !0, G && cancelAnimationFrame(G), U?.disconnect(), W?.disconnect(), w.value?.removeEventListener("load", Y, !0), w.value?.removeEventListener("error", Y, !0), document.fonts?.removeEventListener("loadingdone", Y);
		}), m(j, Y), m(() => j.value.Child, () => {
			A.value = void 0;
		}), m(() => j.value.Stretch, () => {
			O.value = void 0;
		}), m(() => j.value.StretchDirection, () => {
			k.value = void 0;
		});
		let X = c({
			get: () => M.value,
			set: (e) => {
				O.value = e, i(v.Stretch, e, S), y("update:Stretch", e);
			}
		}), Z = c({
			get: () => N.value,
			set: (e) => {
				k.value = e, i(v.StretchDirection, e, S), y("update:StretchDirection", e);
			}
		}), Q = c({
			get: () => A.value === void 0 ? u(j.value.Child) ? j.value.Child : P(x.default?.() ?? [])[0] ?? null : A.value,
			set: (e) => {
				A.value = e, i(v.Child, e, S), y("update:Child", e);
			}
		});
		g({
			Child: Q,
			Stretch: X,
			StretchDirection: Z,
			DesiredSize: V,
			RenderSize: D,
			rootRef: C
		});
		let $ = {
			ViewboxChild: h,
			props: v,
			emit: y,
			attrs: b,
			slots: x,
			instance: S,
			rootRef: C,
			contentRef: w,
			naturalSize: T,
			parentSize: E,
			arrangedSize: D,
			stretchOverride: O,
			directionOverride: k,
			childOverride: A,
			resolved: j,
			stretch: M,
			stretchDirection: N,
			visualChildren: P,
			ChildPresenter: F,
			forwardedAttrs: I,
			numericLength: L,
			constrainedLength: R,
			computeScale: z,
			availableSize: B,
			desiredSize: V,
			rootStyle: oe,
			layoutOffset: H,
			containerStyle: se,
			get resizeObserver() {
				return U;
			},
			set resizeObserver(e) {
				U = e;
			},
			get mutationObserver() {
				return W;
			},
			set mutationObserver(e) {
				W = e;
			},
			get frame() {
				return G;
			},
			set frame(e) {
				G = e;
			},
			get disposed() {
				return K;
			},
			set disposed(e) {
				K = e;
			},
			setSize: q,
			measure: J,
			scheduleMeasure: Y,
			Stretch: X,
			StretchDirection: Z,
			Child: Q
		};
		return Object.defineProperty($, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), $;
	}
});
//#endregion
export { g as default };

//# sourceMappingURL=Viewbox.vue_vue_type_script_setup_true_lang.js.map