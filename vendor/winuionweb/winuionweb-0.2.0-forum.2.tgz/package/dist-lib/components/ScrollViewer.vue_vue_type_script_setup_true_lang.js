import { boolValue as e, cssLength as t, xamlThickness as n } from "./layout.js";
import { uiSettings as r } from "./uiSettings.js";
import { useAcrylicBrushStyle as i } from "./AcrylicBrush.js";
import { normalizeXamlNodes as a, resolveXamlHandler as o, resolveXamlValue as s, xamlScopeKey as c } from "./xamlRuntime.js";
import { vAcrylicBrush as l } from "./acrylicBrushVisual.js";
import { scrollBarOwnerKey as ee } from "./scrollBarOwner.js";
import te from "./ScrollBar.vue.js";
import { Fragment as ne, computed as u, defineComponent as re, getCurrentInstance as ie, h as ae, inject as oe, nextTick as se, onBeforeUnmount as ce, onMounted as le, provide as ue, ref as d, useAttrs as de, useSlots as fe, watch as pe } from "vue";
//#region src/components/ScrollViewer.vue?vue&type=script&setup=true&lang.ts
var me = re({
	name: "ScrollViewer.Template",
	__scrollViewerTemplate: !0,
	setup() {
		return () => null;
	}
}), he = /*@__PURE__*/ re({
	Template: me,
	__name: "ScrollViewer",
	props: {
		Template: {},
		ZoomMode: { default: "Disabled" },
		MinZoomFactor: { default: .1 },
		MaxZoomFactor: { default: 10 },
		HorizontalScrollMode: { default: "Auto" },
		VerticalScrollMode: { default: "Auto" },
		HorizontalScrollBarVisibility: { default: "Disabled" },
		VerticalScrollBarVisibility: { default: "Visible" },
		IsVerticalScrollChainingEnabled: {
			type: [Boolean, String],
			default: !0
		},
		IsHorizontalScrollChainingEnabled: {
			type: [Boolean, String],
			default: !0
		},
		IsTabStop: {
			type: [Boolean, String],
			default: !1
		},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		IsHorizontalRailEnabled: {
			type: [Boolean, String],
			default: !0
		},
		IsVerticalRailEnabled: {
			type: [Boolean, String],
			default: !0
		},
		IsDeferredScrollingEnabled: {
			type: [Boolean, String],
			default: !1
		},
		Width: { default: NaN },
		Height: { default: NaN },
		MinWidth: {},
		MaxWidth: {},
		MinHeight: {},
		MaxHeight: {},
		Margin: {},
		Padding: { default: "0" },
		Background: { default: "Transparent" },
		BorderBrush: { default: "Transparent" },
		BorderThickness: { default: 0 },
		CornerRadius: { default: 0 },
		HorizontalContentAlignment: { default: "Left" },
		VerticalContentAlignment: { default: "Top" },
		HorizontalAlignment: { default: "Stretch" },
		VerticalAlignment: { default: "Stretch" }
	},
	emits: [
		"ViewChanged",
		"ViewChanging",
		"DirectManipulationStarted",
		"DirectManipulationCompleted",
		"Loaded"
	],
	setup(he, { expose: ge, emit: _e }) {
		let f = he, ve = _e, ye = ie(), be = de(), xe = fe();
		function Se(e, t) {
			ve(e, Nt, t), ye?.vnode.props?.[`on${e}`] || o(be[e], ye)?.(Nt, t);
		}
		let p = (e) => s(e, ye), Ce = u(() => {
			let e = [], t = !1, n = (r) => {
				for (let i of r) i.type === ne && Array.isArray(i.children) ? n(i.children) : i.type?.__scrollViewerTemplate || i.type?.name === "ScrollViewer.Template" ? t = !0 : e.push(i);
			};
			return n(xe.default?.() ?? []), {
				content: a(e, ye),
				hasTemplate: t
			};
		}), we = re({ setup: () => () => ae(ne, Ce.value.content) }), Te = oe(c, {}), Ee = u(() => {
			F.value, P.value;
			let e = m.value;
			return {
				Vertical: {
					Maximum: Math.max(0, (e?.scrollHeight ?? 0) - (e?.clientHeight ?? 0)),
					ViewportSize: e?.clientHeight ?? 0,
					Value: e?.scrollTop ?? 0
				},
				Horizontal: {
					Maximum: Math.max(0, (e?.scrollWidth ?? 0) - (e?.clientWidth ?? 0)),
					ViewportSize: e?.clientWidth ?? 0,
					Value: e?.scrollLeft ?? 0
				},
				IndicatorMode: _.value === "touch" ? "TouchIndicator" : r.AutoHideScrollBars ? _.value === "mouse" ? "MouseIndicator" : "None" : "MouseIndicator",
				IsEnabled: W.value
			};
		}), De = (e, t) => {
			let n = m.value;
			if (n) {
				if (Xe.value && t.ScrollEventType === "ThumbTrack") {
					e === "Vertical" ? O.value = t.NewValue : k.value = t.NewValue;
					return;
				}
				e === "Vertical" ? n.scrollTop = t.NewValue : n.scrollLeft = t.NewValue, t.ScrollEventType === "EndScroll" && (O.value = k.value = null, Q()), F.value += 1;
			}
		}, Oe = (e, t) => De("Vertical", t), ke = (e, t) => De("Horizontal", t);
		ue(c, {
			...Te,
			ScrollBars: Ee,
			VerticalScrollBar_Scroll: Oe,
			HorizontalScrollBar_Scroll: ke
		}), ue(ee, {
			autoHide: () => r.AutoHideScrollBars,
			onHover: (e, t) => {
				e === "Vertical" ? w.value = t : T.value = t, t || J();
			},
			onPointerActivity: (e) => {
				v = e === "touch" ? "touch" : "mouse", Y(v);
			},
			onInteraction: (e, t) => {
				e === "Vertical" ? E.value = t : D.value = t, t ? (Z(), K()) : (Q(), J());
			}
		});
		let Ae = d(), m = d(), je = d(), h = d(1), Me = d(!1), Ne = d(!1), Pe = d(!1), Fe = d(!1), Ie = d(!1), g = d(), _ = d("none"), v = "mouse", y = d(), Le = !1, Re = "", ze = "", b = !1, x = 0, S, Be, Ve = d(0), He = d(1), C = d(), w = d(!1), T = d(!1), E = d(!1), D = d(!1), O = d(null), k = d(null), A = d(), j = d(0), M = d(0), N = d(null), Ue = d(null), P = d(0), F = d(0), I, L, We = 7.600855902349023, Ge = .001, Ke = u(() => p(f.ZoomMode)), R = u(() => Math.max(.01, Number(p(f.MinZoomFactor)) || .1)), z = u(() => Math.max(R.value, Number(p(f.MaxZoomFactor)) || 10)), B = u(() => p(f.HorizontalScrollMode)), V = u(() => p(f.VerticalScrollMode)), H = u(() => p(f.HorizontalScrollBarVisibility)), U = u(() => p(f.VerticalScrollBarVisibility)), qe = u(() => e(p(f.IsVerticalScrollChainingEnabled))), Je = u(() => e(p(f.IsHorizontalScrollChainingEnabled))), Ye = u(() => e(p(f.IsTabStop)) && W.value), W = u(() => e(p(f.IsEnabled))), Xe = u(() => e(p(f.IsDeferredScrollingEnabled))), Ze = u(() => p(f.Width)), Qe = u(() => p(f.Height)), $e = u(() => p(f.HorizontalAlignment)), et = u(() => p(f.VerticalAlignment)), tt = u(() => Ce.value.hasTemplate || f.Template?.trim() === "{StaticResource ScrollViewerScrollBarlessTemplate}"), nt = (e) => e != null && e !== "" && !(typeof e == "number" && Number.isNaN(e)), rt = (e) => typeof e == "number" || typeof e == "string" && /^-?\d+(?:\.\d+)?$/.test(e.trim()) ? `${Number(e)}px` : e, it = i(() => f.Background ?? "Transparent", ye), at = u(() => {
			let e = {
				...it.value,
				borderColor: String(p(f.BorderBrush) ?? "transparent"),
				borderWidth: n(p(f.BorderThickness)),
				borderRadius: n(p(f.CornerRadius)),
				margin: n(p(f.Margin))
			};
			for (let n of [
				"MinWidth",
				"MaxWidth",
				"MinHeight",
				"MaxHeight"
			]) {
				let r = p(f[n]);
				if (r !== void 0 && r !== "" && r !== null) {
					let i = n[0].toLowerCase() + n.slice(1);
					e[i] = t(r);
				}
			}
			return nt(Ze.value) && (e.width = rt(Ze.value) ?? "", e.flexGrow = "0", e.flexShrink = "1", e.flexBasis = "auto", e.maxWidth = e.maxWidth || "100%"), nt(Qe.value) && (e.height = rt(Qe.value) ?? ""), e.justifySelf = {
				Left: "flex-start",
				Center: "center",
				Right: "flex-end",
				Stretch: "stretch"
			}[$e.value], e.alignSelf = et.value === "Stretch" ? "stretch" : {
				Top: "start",
				Center: "center",
				Bottom: "end"
			}[et.value] ?? "stretch", $e.value === "Stretch" && e.width === void 0 && (e.flexGrow = "1", e.flexShrink = "1", e.flexBasis = nt(Qe.value) ? "auto" : "0%", e.minWidth = "0"), et.value !== "Stretch" && (e.verticalAlign = {
				Top: "top",
				Center: "middle",
				Bottom: "bottom"
			}[et.value] ?? "top"), e;
		}), ot = u(() => {
			let e = {}, t = ft(B.value, H.value), r = ft(V.value, U.value);
			return e.overflowX = t, e.overflowY = r, e.padding = n(p(f.Padding)), e.maxWidth = e.maxWidth || "100%", e.maxHeight = e.maxHeight || "100%", e.overscrollBehaviorX = Je.value ? "auto" : "contain", e.overscrollBehaviorY = qe.value ? "auto" : "contain", e.touchAction = !W.value || Ke.value === "Enabled" ? "none" : "pan-x pan-y", e;
		}), st = u(() => {
			let e = {}, t = Math.max(R.value, Math.min(z.value, h.value));
			e.zoom = String(t), e.display = "block", e.width = "100%", e.minWidth = "0";
			let n = p(f.HorizontalContentAlignment), r = p(f.VerticalContentAlignment);
			return (n === "Center" || n === "Right") && (e.display = "flex", e.justifyContent = n === "Center" ? "center" : "flex-end"), (r === "Center" || r === "Bottom") && (e.display = "flex", e.alignItems = r === "Center" ? "center" : "flex-end", e.minHeight = `${(m.value?.clientHeight ?? 0) / t}px`), e;
		}), ct = u(() => (P.value, tt.value || U.value === "Disabled" || U.value === "Hidden" ? "hidden" : U.value === "Visible" ? "visible" : m.value && m.value.scrollHeight > m.value.clientHeight ? "auto" : "hidden")), lt = u(() => (P.value, tt.value || H.value === "Disabled" || H.value === "Hidden" ? "hidden" : H.value === "Visible" ? "visible" : m.value && m.value.scrollWidth > m.value.clientWidth ? "auto" : "hidden")), ut = u(() => ct.value !== "hidden"), dt = u(() => lt.value !== "hidden");
		function ft(e, t) {
			return e === "Disabled" || t === "Disabled" ? "hidden" : t === "Hidden" || t === "Visible" ? "scroll" : "auto";
		}
		function G(e) {
			if (!m.value) return;
			let t = {
				HorizontalOffset: m.value.scrollLeft,
				VerticalOffset: m.value.scrollTop,
				ZoomFactor: h.value
			}, n = `${t.HorizontalOffset}:${t.VerticalOffset}:${t.ZoomFactor}`;
			if (e) {
				if (Re === n) return;
				Re = n, Le = !0;
			} else {
				if (!Le && ze === n) return;
				Le = !1, ze = n, Re = n;
			}
			e && Se("ViewChanging", {
				NextView: t,
				FinalView: t,
				IsInertial: !1
			}), Se("ViewChanged", { IsIntermediate: e });
		}
		function K() {
			C.value !== void 0 && clearTimeout(C.value), C.value = window.setTimeout(Q, 150), !Fe.value && (Fe.value = !0, Se("DirectManipulationStarted", {}));
		}
		function pt() {
			Fe.value && (Fe.value = !1, Se("DirectManipulationCompleted", {}));
		}
		function mt() {
			Ct(), F.value += 1, Me.value = !0, C.value && clearTimeout(C.value), G(!0), C.value = window.setTimeout(Q, 150), Y(v);
		}
		function q() {
			P.value += 1;
		}
		function J() {
			if (g.value !== void 0 && clearTimeout(g.value), g.value = void 0, !W.value) {
				_.value = "none";
				return;
			}
			if (!r.AutoHideScrollBars) {
				_.value = "mouse";
				return;
			}
			w.value || T.value || E.value || D.value || (g.value = window.setTimeout(() => {
				if (g.value = void 0, w.value || T.value || E.value || D.value || Ne.value || S || Me.value) {
					J();
					return;
				}
				_.value = "none", q();
			}, _.value === "touch" ? 500 : 2e3));
		}
		function Y(e) {
			W.value && (_.value = e === "mouse" || _.value === "mouse" ? "mouse" : "touch", q(), J());
		}
		function ht(e) {
			e.pointerType === "mouse" && (Ie.value = !0, v = "mouse", Y("mouse"));
		}
		function gt(e) {
			e.pointerType !== "mouse" || !W.value || (v = "mouse", Y("mouse"));
		}
		function _t() {
			Ie.value = !1, w.value = !1, T.value = !1, J();
		}
		function vt(e) {
			if (!e.defaultPrevented) {
				if (v = "mouse", !W.value) {
					e.preventDefault();
					return;
				}
				if (B.value !== "Disabled" && H.value !== "Disabled" && (V.value === "Disabled" || U.value === "Disabled") && !e.ctrlKey && !e.metaKey) {
					let { deltaX: t, deltaY: n } = yt(e, !0), r = t || n;
					if (!r) return;
					A.value === void 0 && Z(), bt(r, 0) ? (K(), e.preventDefault(), e.stopPropagation()) : Je.value || (e.preventDefault(), e.stopPropagation());
					return;
				}
				if (Z(), e.ctrlKey && Ke.value !== "Disabled") {
					let t = -e.deltaY > 0 ? 1.1 : .9;
					K();
					let n = m.value?.getBoundingClientRect();
					Ot(h.value * t, n ? {
						x: e.clientX - n.left,
						y: e.clientY - n.top
					} : void 0), e.preventDefault(), e.stopPropagation();
					return;
				}
				if (K(), !qe.value && m.value) {
					let t = m.value.scrollTop === 0, n = m.value.scrollTop + m.value.clientHeight >= m.value.scrollHeight;
					(e.deltaY < 0 && t || e.deltaY > 0 && n) && e.preventDefault();
				}
				if (!Je.value && m.value) {
					let t = m.value.scrollLeft === 0, n = m.value.scrollLeft + m.value.clientWidth >= m.value.scrollWidth;
					(e.deltaX < 0 && t || e.deltaX > 0 && n) && e.preventDefault();
				}
			}
		}
		function yt(e, t = !1) {
			let n = e.deltaX, r = e.deltaY;
			return e.deltaMode === WheelEvent.DOM_DELTA_LINE ? (n *= 16, r *= 16) : e.deltaMode === WheelEvent.DOM_DELTA_PAGE && m.value && (n *= m.value.clientWidth, r *= t ? m.value.clientWidth : m.value.clientHeight), {
				deltaX: n,
				deltaY: r
			};
		}
		function bt(e = 0, t = 0, n = !0) {
			let r = m.value;
			if (!r) return !1;
			(B.value === "Disabled" || H.value === "Disabled") && (e = 0), (V.value === "Disabled" || U.value === "Disabled") && (t = 0);
			let i = Math.max(0, r.scrollWidth - r.clientWidth), a = Math.max(0, r.scrollHeight - r.clientHeight), o = A.value === void 0 ? r.scrollLeft : j.value, s = A.value === void 0 ? r.scrollTop : M.value, c = Math.max(0, Math.min(i, o + e)), l = Math.max(0, Math.min(a, s + t));
			c - 0 < Ge && (c = 0), i - c < Ge && (c = i), l - 0 < Ge && (l = 0), a - l < Ge && (l = a);
			let ee = e !== 0 && (Math.abs(c - r.scrollLeft) > .01 || Math.abs(c - j.value) > .01), te = t !== 0 && (Math.abs(l - r.scrollTop) > .01 || Math.abs(l - M.value) > .01);
			return ee || te ? (j.value = c, M.value = l, n ? xt() : (r.scrollLeft = c, r.scrollTop = l, F.value += 1, q(), G(!1)), !0) : !1;
		}
		function xt() {
			m.value && (Pe.value = !0, A.value === void 0 && (N.value = m.value.scrollLeft, Ue.value = m.value.scrollTop, A.value = requestAnimationFrame(St)));
		}
		function St() {
			let e = m.value;
			if (!e) {
				X();
				return;
			}
			let t = j.value - e.scrollLeft, n = M.value - e.scrollTop, r = Math.abs(t) <= 1, i = Math.abs(n) <= 1;
			if (r && i) {
				e.scrollLeft = j.value, e.scrollTop = M.value, N.value = e.scrollLeft, Ue.value = e.scrollTop, F.value += 1, G(!1), X();
				return;
			}
			let a = Math.min(.45, Math.max(.24, 1 / Math.sqrt(We)));
			r || (e.scrollLeft += t * a), i || (e.scrollTop += n * a), N.value = e.scrollLeft, Ue.value = e.scrollTop, F.value += 1, q(), G(!0), A.value = requestAnimationFrame(St);
		}
		function X() {
			A.value !== void 0 && (cancelAnimationFrame(A.value), A.value = void 0), m.value && (j.value = m.value.scrollLeft, M.value = m.value.scrollTop), N.value = null, Ue.value = null, Pe.value = !1;
		}
		function Z() {
			x += 1, y.value !== void 0 && cancelAnimationFrame(y.value), y.value = void 0, b = !1, X();
			let e = m.value;
			e?.scrollTo({
				left: e.scrollLeft,
				top: e.scrollTop,
				behavior: "instant"
			});
		}
		function Ct() {
			let e = m.value;
			if (!e || A.value === void 0) return;
			let t = N.value, n = Ue.value;
			if (t === null || n === null) {
				X();
				return;
			}
			Math.abs(e.scrollLeft - t) < .75 && Math.abs(e.scrollTop - n) < .75 || X();
		}
		function wt(e) {
			if (v = "touch", !W.value || (Y("touch"), Z(), K(), Ke.value === "Disabled")) return;
			if (e.touches.length === 1) {
				let t = e.touches[0];
				S = {
					x: t.clientX,
					y: t.clientY
				};
				return;
			}
			if (e.touches.length !== 2) return;
			S = void 0;
			let t = e.touches[0], n = e.touches[1];
			Ve.value = Math.hypot(n.clientX - t.clientX, n.clientY - t.clientY), He.value = h.value;
			let r = m.value?.getBoundingClientRect();
			Be = r ? {
				x: (t.clientX + n.clientX) / 2 - r.left,
				y: (t.clientY + n.clientY) / 2 - r.top
			} : void 0, e.preventDefault();
		}
		function Tt(e) {
			if (!W.value || Ke.value === "Disabled") return;
			if (e.touches.length === 1 && S && m.value) {
				let t = e.touches[0], n = S.x - t.clientX, r = S.y - t.clientY;
				B.value !== "Disabled" && H.value !== "Disabled" && (m.value.scrollLeft += n), V.value !== "Disabled" && U.value !== "Disabled" && (m.value.scrollTop += r), S = {
					x: t.clientX,
					y: t.clientY
				}, e.preventDefault();
				return;
			}
			if (e.touches.length !== 2 || Ve.value <= 0) return;
			let t = e.touches[0], n = e.touches[1], r = Math.hypot(n.clientX - t.clientX, n.clientY - t.clientY) / Ve.value;
			Ot(He.value * r, Be), Ne.value = !0, e.preventDefault();
		}
		function Et(e) {
			if (e.touches.length === 1) {
				S = {
					x: e.touches[0].clientX,
					y: e.touches[0].clientY
				};
				return;
			}
			S = void 0, Be = void 0, Ve.value = 0, Ne.value = !1, Q();
		}
		function Dt(e) {
			if (!W.value || e.target !== m.value || e.altKey || e.ctrlKey || e.metaKey) return;
			let t = m.value;
			if (!t) return;
			let n = 0, r = 0;
			if (e.key === "ArrowLeft") n = -16;
			else if (e.key === "ArrowRight") n = 16;
			else if (e.key === "ArrowUp") r = -16;
			else if (e.key === "ArrowDown") r = 16;
			else if (e.key === "PageUp") r = -t.clientHeight;
			else if (e.key === "PageDown") r = t.clientHeight;
			else if (e.key === "Home") r = -t.scrollTop;
			else if (e.key === "End") r = t.scrollHeight - t.clientHeight - t.scrollTop;
			else return;
			(B.value === "Disabled" || H.value === "Disabled") && (n = 0), (V.value === "Disabled" || U.value === "Disabled") && (r = 0), bt(n, r) && (K(), e.preventDefault());
		}
		function Ot(e, t) {
			if (!Number.isFinite(e)) return;
			let n = Math.max(R.value, Math.min(z.value, e));
			if (Math.abs(n - h.value) < 1e-4) return;
			let r = h.value, i = m.value, a = t ?? {
				x: 0,
				y: 0
			}, o = i ? (i.scrollLeft + a.x) * n / r - a.x : 0, s = i ? (i.scrollTop + a.y) * n / r - a.y : 0;
			h.value = n, P.value += 1, F.value += 1, se(() => {
				i && (i.scrollLeft = Math.max(0, o), i.scrollTop = Math.max(0, s)), F.value += 1, q(), G(!0), C.value !== void 0 && clearTimeout(C.value), C.value = window.setTimeout(Q, 150);
			});
		}
		function Q() {
			b || D.value || E.value || Ne.value || S || (C.value !== void 0 && clearTimeout(C.value), C.value = void 0, Me.value = !1, G(!1), pt(), J());
		}
		function kt(e, t, n, r = !1) {
			if (!m.value || [
				e,
				t,
				n
			].some((e) => e != null && !Number.isFinite(e))) return !1;
			Z();
			let i = m.value, a = Math.max(R.value, Math.min(z.value, n ?? h.value)), o = {
				x: i.scrollLeft,
				y: i.scrollTop,
				zoom: h.value
			}, s = {
				x: Math.max(0, e ?? o.x),
				y: Math.max(0, t ?? o.y),
				zoom: a
			}, c = x;
			if (r || window.matchMedia?.("(prefers-reduced-motion: reduce)").matches) return h.value = s.zoom, se(() => {
				c === x && (jt(s.x, s.y), P.value += 1, q(), Q());
			}), !0;
			b = !0;
			let l = performance.now(), ee = (e) => {
				if (c !== x) return;
				let t = Math.min(1, (e - l) / 300), n = 1 - (1 - t) ** 3;
				h.value = o.zoom + (s.zoom - o.zoom) * n, se(() => {
					!b || c !== x || (jt(o.x + (s.x - o.x) * n, o.y + (s.y - o.y) * n), P.value += 1, G(!0), t < 1 ? y.value = requestAnimationFrame(ee) : (b = !1, y.value = void 0, Q()));
				});
			};
			return y.value = requestAnimationFrame(ee), !0;
		}
		function At(e) {
			return kt(null, null, e, !0);
		}
		function jt(e, t) {
			m.value && (e != null && (m.value.scrollLeft = e), t != null && (m.value.scrollTop = t), F.value += 1);
		}
		let $ = (e) => (F.value, P.value, m.value?.[e] ?? 0), Mt = {
			ZoomFactor: u(() => h.value),
			MinZoomFactor: R,
			MaxZoomFactor: z,
			IsDeferredScrollingEnabled: Xe,
			HorizontalOffset: u(() => $("scrollLeft")),
			VerticalOffset: u(() => $("scrollTop")),
			ViewportWidth: u(() => $("clientWidth")),
			ViewportHeight: u(() => $("clientHeight")),
			ExtentWidth: u(() => $("scrollWidth")),
			ExtentHeight: u(() => $("scrollHeight")),
			ScrollableWidth: u(() => Math.max(0, $("scrollWidth") - $("clientWidth"))),
			ScrollableHeight: u(() => Math.max(0, $("scrollHeight") - $("clientHeight"))),
			ComputedHorizontalScrollBarVisibility: u(() => dt.value ? "Visible" : "Collapsed"),
			ComputedVerticalScrollBarVisibility: u(() => ut.value ? "Visible" : "Collapsed")
		}, Nt = {
			ChangeView: kt,
			ZoomToFactor: At
		};
		for (let [e, t] of Object.entries(Mt)) Object.defineProperty(Nt, e, {
			enumerable: !0,
			get: () => t.value
		});
		ge({
			...Mt,
			ChangeView: kt,
			ZoomToFactor: At,
			scrollViewerRef: m
		}), pe(Xe, () => {
			m.value && (O.value !== null && (m.value.scrollTop = O.value), k.value !== null && (m.value.scrollLeft = k.value)), O.value = k.value = null, F.value += 1;
		}), pe(() => r.AutoHideScrollBars, () => {
			g.value !== void 0 && clearTimeout(g.value), g.value = void 0, !r.AutoHideScrollBars || w.value || T.value || E.value || D.value ? Y(v) : (_.value = "none", q());
		}), pe([R, z], () => {
			(h.value < R.value || h.value > z.value) && At(h.value);
		}), pe(W, (e) => {
			e || (Z(), _t(), Q());
		}), pe([
			H,
			U,
			B,
			V
		], () => {
			se(() => {
				P.value += 1, F.value += 1, q();
			});
		}), le(() => {
			se(() => {
				q(), Se("Loaded", { OriginalSource: Nt }), m.value && G(!1), I = new ResizeObserver(() => {
					L !== void 0 && cancelAnimationFrame(L), L = requestAnimationFrame(() => {
						L = void 0, P.value += 1, F.value += 1, q();
					});
				}), Ae.value && I.observe(Ae.value), m.value && I.observe(m.value), je.value && I.observe(je.value);
			});
		}), ce(() => {
			x += 1, y.value !== void 0 && cancelAnimationFrame(y.value), b = !1, g.value !== void 0 && clearTimeout(g.value), C.value && clearTimeout(C.value), X(), I?.disconnect(), L !== void 0 && cancelAnimationFrame(L);
		});
		let Pt = {
			ScrollViewerTemplate: me,
			props: f,
			emit: ve,
			instance: ye,
			attrs: be,
			slots: xe,
			dispatch: Se,
			resolve: p,
			propertyNodes: Ce,
			ContentOutlet: we,
			inheritedScrollScope: Te,
			ScrollBars: Ee,
			scrollBarChanged: De,
			VerticalScrollBar_Scroll: Oe,
			HorizontalScrollBar_Scroll: ke,
			rootRef: Ae,
			scrollViewerRef: m,
			contentRef: je,
			currentZoomFactor: h,
			isScrolling: Me,
			isZooming: Ne,
			isWheelScrolling: Pe,
			isDirectManipulationActive: Fe,
			isRootPointerOver: Ie,
			indicatorTimer: g,
			indicatorMode: _,
			get lastIndicatorType() {
				return v;
			},
			set lastIndicatorType(e) {
				v = e;
			},
			programmaticFrame: y,
			get pendingViewChange() {
				return Le;
			},
			set pendingViewChange(e) {
				Le = e;
			},
			get lastIntermediateViewKey() {
				return Re;
			},
			set lastIntermediateViewKey(e) {
				Re = e;
			},
			get lastFinalViewKey() {
				return ze;
			},
			set lastFinalViewKey(e) {
				ze = e;
			},
			get programmaticAnimationActive() {
				return b;
			},
			set programmaticAnimationActive(e) {
				b = e;
			},
			get programmaticGeneration() {
				return x;
			},
			set programmaticGeneration(e) {
				x = e;
			},
			get touchPoint() {
				return S;
			},
			set touchPoint(e) {
				S = e;
			},
			get touchZoomCenter() {
				return Be;
			},
			set touchZoomCenter(e) {
				Be = e;
			},
			touchStartDistance: Ve,
			touchStartZoom: He,
			scrollTimer: C,
			isVerticalPointerOver: w,
			isHorizontalPointerOver: T,
			isDraggingVertical: E,
			isDraggingHorizontal: D,
			deferredVerticalOffset: O,
			deferredHorizontalOffset: k,
			wheelScrollAnimationFrame: A,
			wheelScrollTargetLeft: j,
			wheelScrollTargetTop: M,
			wheelScrollExpectedLeft: N,
			wheelScrollExpectedTop: Ue,
			overflowRevision: P,
			scrollRevision: F,
			get resizeObserver() {
				return I;
			},
			set resizeObserver(e) {
				I = e;
			},
			get resizeFrame() {
				return L;
			},
			set resizeFrame(e) {
				L = e;
			},
			scrollControllerVelocityNeededPerPixel: We,
			scrollControllerSmallChange: 16,
			scrollControllerMinMaxEpsilon: Ge,
			effectiveZoomMode: Ke,
			effectiveMinZoomFactor: R,
			effectiveMaxZoomFactor: z,
			effectiveHorizontalScrollMode: B,
			effectiveVerticalScrollMode: V,
			effectiveHorizontalScrollBarVisibility: H,
			effectiveVerticalScrollBarVisibility: U,
			effectiveIsVerticalScrollChainingEnabled: qe,
			effectiveIsHorizontalScrollChainingEnabled: Je,
			effectiveIsTabStop: Ye,
			effectiveIsEnabled: W,
			effectiveIsDeferredScrollingEnabled: Xe,
			effectiveWidth: Ze,
			effectiveHeight: Qe,
			effectiveHorizontalAlignment: $e,
			effectiveVerticalAlignment: et,
			isScrollBarlessTemplate: tt,
			hasCssSize: nt,
			cssSize: rt,
			backgroundStyle: it,
			scrollViewerStyle: at,
			viewportStyle: ot,
			contentStyle: st,
			computedVerticalScrollBarVisibility: ct,
			computedHorizontalScrollBarVisibility: lt,
			hasVerticalScrollBar: ut,
			hasHorizontalScrollBar: dt,
			getOverflowValue: ft,
			emitViewChanged: G,
			beginDirectManipulation: K,
			completeDirectManipulation: pt,
			handleScroll: mt,
			updateScrollBarVisibility: q,
			scheduleIndicatorHide: J,
			showIndicators: Y,
			handleViewerPointerEnter: ht,
			handleViewerPointerMove: gt,
			handleViewerPointerLeave: _t,
			handleWheel: vt,
			normalizeWheelDelta: yt,
			requestScrollByOffset: bt,
			startSmoothWheelScroll: xt,
			runSmoothWheelScroll: St,
			stopSmoothWheelScroll: X,
			cancelPendingAnimatedScrollForDirectInput: Z,
			stopSmoothWheelScrollIfExternalScroll: Ct,
			handleTouchStart: wt,
			handleTouchMove: Tt,
			handleTouchEnd: Et,
			handleKeyDown: Dt,
			setZoomFactor: Ot,
			finishViewChange: Q,
			ChangeView: kt,
			ZoomToFactor: At,
			setOffsets: jt,
			measure: $,
			publicProperties: Mt,
			controlSender: Nt,
			ScrollBar: te,
			get vAcrylicBrush() {
				return l;
			}
		};
		return Object.defineProperty(Pt, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), Pt;
	}
});
//#endregion
export { me as ScrollViewerTemplate, he as default };

//# sourceMappingURL=ScrollViewer.vue_vue_type_script_setup_true_lang.js.map