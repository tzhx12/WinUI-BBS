import { resolveXamlHandler as e, resolveXamlValue as t, updateXamlBinding as n, xamlScopeKey as r } from "./xamlRuntime.js";
import i from "./AnimatedIcon.vue.js";
import { useAnimatedIconInput as a } from "./animatedIconInput.js";
import { computed as o, defineComponent as s, getCurrentInstance as c, inject as l, provide as u, ref as d, useAttrs as f, watch as p } from "vue";
//#region src/components/CheckBox.vue?vue&type=script&setup=true&lang.ts
var m = /*@__PURE__*/ s({
	__name: "CheckBox",
	props: {
		Content: {
			type: [String, Number],
			default: ""
		},
		IsChecked: {
			type: [
				Boolean,
				String,
				null
			],
			default: void 0
		},
		IsThreeState: {
			type: [Boolean, String],
			default: void 0
		},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		IsTabStop: {
			type: [Boolean, String],
			default: !0
		},
		Margin: {
			type: String,
			default: ""
		}
	},
	emits: [
		"Click",
		"update:IsChecked",
		"Checked",
		"Unchecked",
		"Indeterminate"
	],
	setup(s, { expose: m, emit: h }) {
		let g = s, _ = c(), v = f(), y = o(() => {
			let { class: e, style: t, Click: n, onClick: r, onPointerdown: i, ...a } = v;
			return a;
		}), b = o(() => t(g.Content, _)), x = o(() => t(g.IsChecked, _)), S = o(() => t(g.IsThreeState, _)), C = o(() => t(g.IsEnabled, _) !== !1), w = h, T = d(!1), E = d(void 0), D = o(() => S.value === !0), O = o(() => t(g.IsTabStop, _) !== !1), k = o(() => !C.value), A = o(() => E.value === void 0 ? T.value : E.value);
		p(x, (e) => {
			e === void 0 ? E.value = void 0 : E.value = e === null ? null : e === !0;
		}, { immediate: !0 });
		let j = o(() => A.value === !0), M = o(() => D.value && A.value === null), N = o(() => M.value ? "mixed" : j.value), P = o(() => ({
			"is-checked": j.value,
			"is-unchecked": !j.value && !M.value,
			"is-indeterminate": M.value,
			"is-disabled": k.value
		})), F = d(null), I = a(!1, (e) => `${e === "Disabled" ? "Normal" : e}${M.value ? "Indeterminate" : j.value ? "On" : "Off"}`);
		p(F, (e) => I.Attach(e), { flush: "post" }), p([
			j,
			M,
			k
		], () => I.Refresh(), { flush: "post" }), u(r, {
			...l(r, {}),
			CheckGlyphMargin: o(() => M.value ? "0" : "0,1,0,-1")
		});
		let L = (e) => e === "" || e == null ? "" : typeof e == "string" && e.trim() !== "" && !Number.isNaN(Number(e.trim())) ? `${Number(e.trim())}px` : typeof e == "number" ? `${e}px` : e, R = (e) => {
			if (!e) return "";
			let t = String(e).split(",").map((e) => L(Number.isNaN(Number(e.trim())) ? e.trim() : Number(e.trim())));
			return t.length === 1 ? t[0] : t.length === 2 ? `${t[1]} ${t[0]}` : t.length === 4 ? `${t[1]} ${t[2]} ${t[3]} ${t[0]}` : e;
		}, z = o(() => g.Margin ? { margin: R(g.Margin) } : {}), B = (t, r) => {
			if (t === A.value) return;
			E.value = t, T.value = t === !0, w("update:IsChecked", t), n(g.IsChecked, t, _);
			let i = {
				OriginalSource: V,
				OriginalEvent: r,
				Handled: !1
			}, a = t === !0 ? "Checked" : t === null ? "Indeterminate" : "Unchecked", o = _?.vnode.props?.[`on${a}`];
			if (o) for (let e of Array.isArray(o) ? o : [o]) typeof e == "function" && e(V, i);
			else w(a, V, i), e(v[a], _)?.(V, i);
		}, V = {
			get IsChecked() {
				return A.value;
			},
			set IsChecked(e) {
				B(e);
			},
			get IsEnabled() {
				return !k.value;
			},
			get Content() {
				return b.value;
			},
			get Element() {
				return F.value;
			}
		};
		m(V);
		let H = (t) => {
			if (k.value || t instanceof KeyboardEvent && t.repeat) return;
			D.value ? A.value === !1 ? B(!0, t) : A.value === !0 ? B(null, t) : B(!1, t) : B(!j.value, t);
			let n = {
				OriginalEvent: t,
				Handled: !1
			};
			w("Click", V, n), _?.vnode.props?.onClick || e(v.Click, _)?.(V, n);
		}, U = !1, W = (e) => {
			I.KeyDown(e), !(e.key !== " " && e.key !== "Spacebar") && (e.preventDefault(), !e.repeat && !k.value && (U = !0));
		}, G = (e) => {
			if (I.KeyUp(e), e.key !== " " && e.key !== "Spacebar") return;
			e.preventDefault();
			let t = U && !k.value;
			U = !1, t && H(e);
		}, K = (e) => {
			U = !1, I.LostFocus(e);
		};
		p(k, (e) => {
			e && (U = !1);
		});
		let q = {
			props: g,
			instance: _,
			attrs: v,
			forwardedAttrs: y,
			resolvedContent: b,
			resolvedIsChecked: x,
			resolvedIsThreeState: S,
			resolvedIsEnabled: C,
			emit: w,
			localChecked: T,
			boundChecked: E,
			isThreeState: D,
			isTabStop: O,
			isDisabled: k,
			currentValue: A,
			isChecked: j,
			isIndeterminate: M,
			ariaChecked: N,
			stateClasses: P,
			checkboxElement: F,
			iconInput: I,
			cssLength: L,
			xamlThickness: R,
			checkboxStyle: z,
			emitState: B,
			publicApi: V,
			toggle: H,
			get spacePressed() {
				return U;
			},
			set spacePressed(e) {
				U = e;
			},
			onKeyDown: W,
			onKeyUp: G,
			onLostFocus: K,
			AnimatedIcon: i
		};
		return Object.defineProperty(q, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), q;
	}
});
//#endregion
export { m as default };

//# sourceMappingURL=CheckBox.vue_vue_type_script_setup_true_lang.js.map