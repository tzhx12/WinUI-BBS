import { resolveXamlHandler as e, resolveXamlValue as t, updateXamlBinding as n, xamlColor as r } from "./xamlRuntime.js";
import { useI18n as i } from "./i18n/index.js";
import a from "./ScrollViewer.vue.js";
import { calendarDateFromSerial as o, calendarDateSerial as s, createCalendarModel as ee, parseCalendarDate as te } from "./calendarEngine.js";
import { computed as c, defineComponent as ne, getCurrentInstance as re, nextTick as l, onBeforeUnmount as ie, onMounted as ae, reactive as oe, ref as u, watch as d } from "vue";
//#region src/components/CalendarView.vue?vue&type=script&setup=true&lang.ts
var se = /*@__PURE__*/ ne({
	__name: "CalendarView",
	props: {
		CalendarIdentifier: {
			type: String,
			default: "GregorianCalendar"
		},
		DayOfWeekFormat: {
			type: String,
			default: "{dayofweek.abbreviated(2)}"
		},
		DisplayMode: {
			type: String,
			default: "Month"
		},
		FirstDayOfWeek: {
			type: [String, Number],
			default: "Sunday"
		},
		IsGroupLabelVisible: {
			type: [Boolean, String],
			default: !1
		},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		IsOutOfScopeEnabled: {
			type: [Boolean, String],
			default: !0
		},
		IsTodayHighlighted: {
			type: [Boolean, String],
			default: !0
		},
		MaxDate: {
			type: [
				Date,
				String,
				Number
			],
			default: void 0
		},
		MinDate: {
			type: [
				Date,
				String,
				Number
			],
			default: void 0
		},
		NumberOfWeeksInView: {
			type: [Number, String],
			default: 6
		},
		SelectedDates: {
			type: [Array, String],
			default: void 0
		},
		SelectionMode: {
			type: String,
			default: "Single"
		},
		Language: {
			type: String,
			default: ""
		},
		RequestedTheme: {
			type: String,
			default: "Default"
		},
		SelectedDatesChanged: {
			type: [String, Function],
			default: void 0
		},
		CalendarViewDayItemChanging: {
			type: [String, Function],
			default: void 0
		},
		Style: [Object, String],
		Width: [Number, String],
		Height: [Number, String],
		MinWidth: [Number, String],
		MinHeight: [Number, String],
		MaxWidth: [Number, String],
		MaxHeight: [Number, String],
		Margin: [Number, String],
		Padding: [Number, String],
		HorizontalAlignment: {
			type: String,
			default: "Left"
		},
		VerticalAlignment: {
			type: String,
			default: "Center"
		},
		CornerRadius: [Number, String],
		BorderThickness: [Number, String],
		CalendarItemBorderThickness: [Number, String],
		CalendarItemCornerRadius: [Number, String],
		DayItemFontFamily: String,
		DayItemFontSize: [Number, String],
		DayItemFontWeight: [Number, String],
		DayItemMargin: [Number, String],
		FirstOfMonthLabelFontFamily: String,
		FirstOfMonthLabelFontSize: [Number, String],
		FirstOfMonthLabelFontWeight: [Number, String],
		FirstOfMonthLabelMargin: [Number, String],
		MonthYearItemFontFamily: String,
		MonthYearItemFontSize: [Number, String],
		MonthYearItemFontWeight: [Number, String],
		MonthYearItemMargin: [Number, String],
		FirstOfYearDecadeLabelFontFamily: String,
		FirstOfYearDecadeLabelFontSize: [Number, String],
		FirstOfYearDecadeLabelFontWeight: [Number, String],
		FirstOfYearDecadeLabelMargin: [Number, String],
		TodayFontWeight: [Number, String],
		Foreground: String,
		Background: String,
		BorderBrush: String,
		BlackoutStrikethroughBrush: String,
		SelectedHoverBorderBrush: String,
		SelectedPressedBorderBrush: String,
		SelectedDisabledBorderBrush: String,
		SelectedBorderBrush: String,
		HoverBorderBrush: String,
		PressedBorderBrush: String,
		CalendarItemBorderBrush: String,
		TodaySelectedInnerBorderBrush: String,
		TodayForeground: String,
		DisabledForeground: String,
		BlackoutForeground: String,
		SelectedForeground: String,
		SelectedHoverForeground: String,
		SelectedPressedForeground: String,
		SelectedDisabledForeground: String,
		PressedForeground: String,
		OutOfScopeForeground: String,
		OutOfScopeHoverForeground: String,
		OutOfScopePressedForeground: String,
		CalendarItemForeground: String,
		TodayBackground: String,
		TodayBlackoutBackground: String,
		TodayBlackoutForeground: String,
		TodayHoverBackground: String,
		TodayPressedBackground: String,
		TodayDisabledBackground: String,
		BlackoutBackground: String,
		OutOfScopeBackground: String,
		CalendarItemBackground: String,
		CalendarItemHoverBackground: String,
		CalendarItemPressedBackground: String,
		CalendarItemDisabledBackground: String
	},
	emits: [
		"SelectedDatesChanged",
		"CalendarViewDayItemChanging",
		"update:SelectedDates",
		"update:DisplayMode"
	],
	setup(ne, { expose: se, emit: ce }) {
		let f = ne, p = ce, m = re(), { t: h, locale: le } = i(), g = (e) => t(e, m), _ = (e, t) => String(g(e) ?? t), v = (e, t) => {
			let n = Number(g(e));
			return Number.isFinite(n) ? n : t;
		}, y = (e, t) => {
			let n = g(e);
			return typeof n == "boolean" ? n : typeof n == "string" && /^(true|false)$/i.test(n) ? n.toLowerCase() === "true" : t;
		}, b = c(() => y(f.IsEnabled, !0)), ue = c(() => y(f.IsGroupLabelVisible, !1)), de = c(() => y(f.IsOutOfScopeEnabled, !0)), fe = c(() => y(f.IsTodayHighlighted, !0)), pe = u(), me = u(), he = u(), ge = c(() => pe.value ?? (_(f.Language, "") || le)), _e = c(() => me.value ?? _(f.CalendarIdentifier, "GregorianCalendar")), x = c(() => he.value ?? _(f.SelectionMode, "Single")), S = s(/* @__PURE__ */ new Date()), ve = new Date((/* @__PURE__ */ new Date()).getFullYear() - 100, 0, 1), ye = new Date((/* @__PURE__ */ new Date()).getFullYear() + 100, 11, 31), C = c(() => s(te(g(f.MinDate)) ?? ve)), w = c(() => Math.max(C.value, s(te(g(f.MaxDate)) ?? ye))), T = (e) => Math.max(C.value, Math.min(w.value, e)), E = c(() => ee(_e.value, ge.value, C.value, w.value)), be = c(() => {
			let e = g(f.FirstDayOfWeek), t = typeof e == "number" ? e : [
				"Sunday",
				"Monday",
				"Tuesday",
				"Wednesday",
				"Thursday",
				"Friday",
				"Saturday"
			].indexOf(String(e));
			return t < 0 || t > 6 ? 0 : t;
		}), D = c(() => Math.max(2, Math.min(8, Math.trunc(v(f.NumberOfWeeksInView, 6))))), xe = c(() => Array.from({ length: 7 }, (e, t) => E.value.weekdayText(19729 + be.value + t, _(f.DayOfWeekFormat, "{dayofweek.abbreviated(2)}")))), O = u(), k = u(), Se = u(), Ce = u(), we = u(), A = u("Month"), j = u(T(S)), Te = u(T(S)), M = u(T(S)), N = u(4), Ee = u(4), P = u(42), De = u(294), F = oe({
			Month: 0,
			Year: 0,
			Decade: 0
		}), I = oe(/* @__PURE__ */ new Map()), L = u([]), Oe = c(() => new Set(L.value.map(s))), R = c(() => C.value - ((/* @__PURE__ */ new Date(C.value * 864e5)).getUTCDay() - be.value + 7) % 7), ke = c(() => Math.ceil((w.value - R.value + 1) / 7)), Ae = c(() => ke.value * P.value + 4), z = c(() => Math.max(40, De.value / Ee.value)), je = c(() => Math.ceil(E.value.months.length / N.value) * z.value + 4), Me = c(() => Math.ceil(E.value.years.length / N.value) * z.value + 4), Ne = c(() => Math.max(0, Math.floor(F.Month / P.value) - 2)), Pe = c(() => Ne.value * P.value + 2), Fe = c(() => Math.max(0, Math.floor(F.Year / z.value) - 1)), Ie = c(() => Fe.value * z.value + 2), Le = c(() => Math.max(0, Math.floor(F.Decade / z.value) - 1)), Re = c(() => Le.value * z.value + 2), ze = (e) => {
			let t = I.get(e);
			return t || (t = oe({
				Date: o(e),
				IsBlackout: !1,
				DensityColors: [],
				SetDensityColors(e) {
					this.DensityColors = Array.from(e ?? []).slice(0, 10).map((e) => String(r(e)));
				}
			}), I.set(e, t)), t;
		}, B = c(() => E.value.monthAt(j.value)), V = c(() => E.value.yearAt(j.value)), H = c(() => Math.floor(E.value.displayYear(V.value) / 10) * 10), Be = c(() => {
			let e = [], t = Math.min(ke.value, Ne.value + D.value + 5);
			for (let n = Ne.value; n < t; n++) for (let t = 0; t < 7; t++) {
				let r = R.value + n * 7 + t, i = E.value.monthAt(r);
				e.push({
					serial: r,
					month: i,
					outOfScope: i.index !== B.value.index,
					showLabel: E.value.day(r) === 1,
					state: ze(r)
				});
			}
			return e;
		}), Ve = c(() => E.value.months.slice(Fe.value * N.value, (Fe.value + Ee.value + 3) * N.value)), He = c(() => E.value.years.slice(Le.value * N.value, (Le.value + Ee.value + 3) * N.value)), Ue = c(() => A.value === "Month" ? E.value.headerText(j.value) : A.value === "Year" ? V.value.text : `${E.value.formatNumber(H.value)} - ${E.value.formatNumber(H.value + 9)}`), We = (e) => A.value === "Month" ? B.value.index + e >= 0 && B.value.index + e < E.value.months.length : A.value === "Year" ? V.value.index + e >= 0 && V.value.index + e < E.value.years.length : !!(e > 0 ? E.value.years.find((e) => E.value.displayYear(e) >= H.value + 10) : [...E.value.years].reverse().find((e) => E.value.displayYear(e) <= H.value - 10)), Ge = c(() => ({
			disabled: !b.value || A.value === "Decade",
			"aria-label": Ue.value
		})), Ke = c(() => ({
			disabled: !b.value || !We(-1),
			"aria-label": h("text.previous"),
			title: h("text.previous")
		})), qe = c(() => ({
			disabled: !b.value || !We(1),
			"aria-label": h("text.next"),
			title: h("text.next")
		})), U = (e, t) => {
			let n = g(e);
			if (n === void 0 || n === "") return t;
			if (typeof n == "string" && n.startsWith("var(")) return n;
			let r = String(n).split(/[,\s]+/).map(Number);
			return r.some(Number.isNaN) ? t : (r.length === 4 ? [
				r[1],
				r[2],
				r[3],
				r[0]
			] : r.length === 2 ? [r[1], r[0]] : r).map((e) => e + "px").join(" ");
		}, Je = (e, t) => ({
			Normal: "400",
			SemiBold: "600",
			Bold: "700",
			Light: "300"
		})[_(e, t)] ?? _(e, t), Ye = c(() => {
			let e = g(f.Style);
			if (!e || typeof e != "object") return {};
			let t = e;
			return Array.isArray(t.Setters) ? Object.fromEntries(t.Setters.map((e) => [e.Property, e.Value])) : e;
		}), W = new Proxy(f, { get(e, t) {
			return e[t] ?? Ye.value[t];
		} }), Xe = c(() => {
			let e = {
				width: v(W.Width, 300) + "px",
				minWidth: v(W.MinWidth, 300) + "px",
				maxWidth: W.MaxWidth === void 0 ? "100%" : v(W.MaxWidth, 300) + "px",
				height: W.Height === void 0 ? "auto" : v(W.Height, 347) + "px",
				minHeight: v(W.MinHeight, 0) + "px",
				maxHeight: W.MaxHeight === void 0 ? "none" : v(W.MaxHeight, 347) + "px",
				margin: U(W.Margin, "0"),
				padding: U(W.Padding, "0"),
				borderWidth: U(W.BorderThickness, "1px"),
				borderRadius: U(W.CornerRadius, "var(--ControlCornerRadius, 4px)"),
				"--calendar-weeks": D.value,
				"--calendar-item-border-thickness": U(W.CalendarItemBorderThickness, "1px"),
				"--calendar-item-radius": U(W.CalendarItemCornerRadius, "999px"),
				"--calendar-today-font-weight": Je(W.TodayFontWeight, "400")
			};
			for (let t of new Set([...Object.keys(f), ...Object.keys(Ye.value)])) {
				if (!/(Brush|Foreground|Background)$/.test(t)) continue;
				let n = g(W[t]);
				typeof n == "string" && n && (e["--CalendarView" + t] = n);
			}
			for (let [t, n] of Object.entries({
				DayItem: ["14", "3px 0 0"],
				MonthYearItem: ["14", "0"],
				FirstOfMonthLabel: ["8", "2px 0 0"],
				FirstOfYearDecadeLabel: ["8", "9px 0 0"]
			})) {
				let r = W;
				e["--calendar-" + t + "-size"] = v(r[t + "FontSize"], Number(n[0])) + "px", e["--calendar-" + t + "-family"] = _(r[t + "FontFamily"], "inherit"), e["--calendar-" + t + "-weight"] = Je(r[t + "FontWeight"], "400"), e["--calendar-" + t + "-margin"] = U(r[t + "Margin"], n[1]);
			}
			return e.alignSelf = {
				Top: "flex-start",
				Center: "center",
				Bottom: "flex-end",
				Stretch: "stretch"
			}[_(f.VerticalAlignment, "Center")], e.justifySelf = {
				Left: "start",
				Center: "center",
				Right: "end",
				Stretch: "stretch"
			}[_(f.HorizontalAlignment, "Left")], {
				style: e,
				class: {
					"is-disabled": !b.value,
					"has-explicit-height": W.Height !== void 0,
					"win-theme-scope": !0,
					"theme-dark": _(f.RequestedTheme, "Default") === "Dark",
					"theme-light": _(f.RequestedTheme, "Default") === "Light"
				},
				lang: ge.value,
				"aria-disabled": !b.value,
				"data-display-mode": A.value
			};
		}), Ze = (e) => {
			let t = e.serial < C.value || e.serial > w.value, n = t ? "hidden" : "visible";
			return {
				"data-date": e.serial,
				"data-kind": "day",
				disabled: !b.value,
				tabindex: !t && e.serial === M.value ? 0 : -1,
				"aria-label": E.value.fullDateText(e.serial),
				"aria-pressed": Oe.value.has(e.serial),
				"aria-disabled": !b.value || e.state.IsBlackout || t,
				class: {
					"out-of-scope": e.outOfScope && de.value,
					"is-today": fe.value && e.serial === S,
					"is-selected": Oe.value.has(e.serial),
					"is-blackout": e.state.IsBlackout
				},
				style: { visibility: n }
			};
		}, Qe = (e) => ({
			"data-date": e.start,
			"data-kind": "month",
			disabled: !b.value,
			tabindex: E.value.monthAt(M.value).index === e.index ? 0 : -1,
			"aria-label": E.value.headerText(e.start),
			class: {
				"out-of-scope": de.value && e.yearIndex !== V.value.index,
				"is-today": fe.value && S >= e.start && S <= e.end
			}
		}), $e = (e) => ({
			"data-date": e.start,
			"data-kind": "year",
			disabled: !b.value,
			tabindex: E.value.yearAt(M.value).index === e.index ? 0 : -1,
			"aria-label": e.text,
			class: {
				"out-of-scope": de.value && (E.value.displayYear(e) < H.value || E.value.displayYear(e) >= H.value + 10),
				"is-today": fe.value && S >= e.start && S <= e.end
			}
		}), et = (e) => {
			let t = e === "Month" ? Se.value : e === "Year" ? Ce.value : we.value;
			return t?.scrollViewerRef?.value ?? t?.scrollViewerRef;
		}, tt = (e, t) => t === "Month" ? Math.floor((e - R.value) / 7) * P.value : t === "Year" ? Math.floor(E.value.monthAt(e).index / N.value) * z.value : Math.floor(E.value.yearAt(e).index / N.value) * z.value, G = 0, K = (e, t = A.value, n = !1, r = !1, i = !1) => {
			G = performance.now() + 500;
			let a = T(e);
			i || (Te.value = a), n || (j.value = a);
			let o = et(t), s = tt(t === "Month" ? E.value.monthAt(a).start : t === "Year" ? E.value.yearAt(a).start : a, t);
			if (r && o) {
				let e = tt(a, t), n = t === "Month" ? P.value : z.value;
				if (e >= o.scrollTop && e + n <= o.scrollTop + o.clientHeight) return;
				s = e < o.scrollTop ? e : e + n - o.clientHeight;
			}
			o && o.scrollTo({
				top: Math.max(0, s),
				behavior: n ? "smooth" : "instant"
			}), n || (F[t] = o?.scrollTop ?? Math.max(0, s));
		}, nt = (e, t) => {
			if (e !== A.value) return;
			let n = et(e)?.clientHeight ?? De.value, r = e === "Month" ? P.value : z.value, i = e === "Month" ? 7 : N.value, a = /* @__PURE__ */ new Map();
			for (let o = Math.floor(t / r); o < Math.ceil((t + n) / r); o++) {
				let s = Math.max(0, Math.min((o + 1) * r, t + n) - Math.max(o * r, t));
				for (let t = 0; t < i; t++) {
					let n = o * i + t, r;
					if (e === "Month") {
						let e = R.value + n;
						if (e < C.value || e > w.value) continue;
						r = E.value.monthAt(e).index;
					} else if (e === "Year") {
						let e = E.value.months[n];
						if (!e) continue;
						r = e.yearIndex;
					} else {
						let e = E.value.years[n];
						if (!e) continue;
						r = Math.floor(E.value.displayYear(e) / 10) * 10;
					}
					a.set(r, (a.get(r) ?? 0) + s);
				}
			}
			let o = -1, s = -1;
			for (let [e, t] of a) t > s && (o = e, s = t);
			if (o < 0) return;
			let ee = e === "Month" ? E.value.months[o] : e === "Year" ? E.value.years[o] : E.value.years.find((e) => Math.floor(E.value.displayYear(e) / 10) * 10 === o);
			ee && (j.value = T(ee.start));
		}, rt = (e) => {
			let t = e.target, n = t.closest("[data-panel]")?.getAttribute("data-panel");
			n && (F[n] = t.scrollTop, nt(n, t.scrollTop), performance.now() > G && (Te.value = j.value));
		}, it = () => {
			G = 0;
		}, q = [], at = 0, J = (e, t = []) => {
			for (let n of k.value?.querySelectorAll("[data-panel]") ?? []) {
				let r = n.dataset.panel === e;
				n.style.visibility = r || t.includes(n.dataset.panel) ? "visible" : "hidden", n.style.opacity = r ? "1" : "0", n.style.pointerEvents = r && b.value ? "auto" : "none", n.inert = !r || !b.value, n.setAttribute("aria-hidden", String(!r));
			}
		}, ot = () => {
			at++, q.forEach((e) => e.cancel()), q = [], J(A.value);
		}, Y = async (e, t = j.value, r = !0, i = !1) => {
			if (![
				"Month",
				"Year",
				"Decade"
			].includes(e)) return;
			let a = A.value;
			ot();
			let o = at;
			if (A.value = e, M.value = T(t), j.value = T(t), n(f.DisplayMode, e, m), p("update:DisplayMode", e), await l(), J(e), K(t, e), a !== e && r && !globalThis.matchMedia?.("(prefers-reduced-motion: reduce)").matches) {
				let t = k.value?.querySelector(`[data-panel="${a}"]`), n = k.value?.querySelector(`[data-panel="${e}"]`);
				if (t?.animate && n?.animate) {
					J(e, [a, e]);
					let r = [
						"Month",
						"Year",
						"Decade"
					].indexOf(e) > [
						"Month",
						"Year",
						"Decade"
					].indexOf(a), i = "cubic-bezier(0,0,0,1)";
					if (q = [t.animate([{
						opacity: 1,
						transform: "scale(1)"
					}, {
						opacity: 0,
						transform: `scale(${r ? .84 : 1.29})`
					}], {
						duration: 150,
						easing: i,
						fill: "forwards"
					}), n.animate([{
						opacity: 0,
						transform: `scale(${r ? 1.29 : .84})`
					}, {
						opacity: 1,
						transform: "scale(1)"
					}], {
						delay: 150,
						duration: 350,
						easing: i,
						fill: "both"
					})], await Promise.allSettled(q.map((e) => e.finished)), o !== at) return;
					ot();
				}
			}
			i && await Q(M.value);
		}, X = {
			get SelectedDates() {
				return ct;
			},
			set SelectedDates(e) {
				Z(e);
			},
			get SelectionMode() {
				return x.value;
			},
			set SelectionMode(e) {
				he.value = e;
			},
			get Language() {
				return ge.value;
			},
			set Language(e) {
				pe.value = e;
			},
			get CalendarIdentifier() {
				return _e.value;
			},
			set CalendarIdentifier(e) {
				me.value = e;
			},
			get DisplayMode() {
				return A.value;
			},
			set DisplayMode(e) {
				Y(e);
			},
			SetDisplayDate(e) {
				let t = te(e);
				t && (M.value = T(s(t)), l(() => K(M.value)));
			},
			SetYearDecadeDisplayDimensions(e, t) {
				N.value = Math.max(1, Math.min(16, Math.trunc(e))), Ee.value = Math.max(1, Math.min(16, Math.trunc(t))), l(() => K(j.value));
			},
			Focus: () => Q(L.value[0] ?? o(M.value)),
			FocusFirst: () => Q(L.value[0] ?? o(T(S))),
			FocusDate: (e) => Q(e)
		}, st = (e) => Array.isArray(e) ? e.map(te).filter((e) => e !== null) : [], Z = (t) => {
			let r = st(t).filter((e) => {
				let t = s(e);
				return t >= C.value && t <= w.value && !I.get(t)?.IsBlackout;
			}), i = [...new Map(r.map((e) => [s(e), e])).values()], a = x.value === "None" ? [] : x.value === "Single" ? i.slice(0, 1) : i, o = L.value, ee = new Set(o.map(s)), te = new Set(a.map(s)), c = a.filter((e) => !ee.has(s(e))), ne = o.filter((e) => !te.has(s(e)));
			if (L.value = a, !c.length && !ne.length) return;
			n(f.SelectedDates, a, m), p("update:SelectedDates", a);
			let re = {
				AddedDates: c,
				RemovedDates: ne
			};
			e(f.SelectedDatesChanged, m)?.(X, re), p("SelectedDatesChanged", X, re);
		}, ct = new Proxy([], {
			get(e, t) {
				let n = L.value;
				if (t === "Clear") return () => Z([]);
				if (t === "Add" || t === "Append") return (e) => Z([...n, e]);
				if (t === "Remove") return (e) => Z(n.filter((t) => s(t) !== s(e)));
				if (t === "RemoveAt") return (e) => Z(n.filter((t, n) => n !== e));
				if (t === "GetAt") return (e) => n[e];
				if (t === "Size" || t === "Count") return n.length;
				if ([
					"push",
					"pop",
					"shift",
					"unshift",
					"splice",
					"sort",
					"reverse"
				].includes(String(t))) return (...e) => {
					let r = [...n], i = Array.prototype[t].apply(r, e);
					return Z(r), i;
				};
				let r = n[t];
				return typeof r == "function" ? r.bind(n) : r;
			},
			set(e, t, n) {
				let r = [...L.value];
				return r[t] = n, Z(r), !0;
			}
		}), lt = (e) => {
			!b.value || e < C.value || e > w.value || ze(e).IsBlackout || x.value === "None" || (M.value = e, Z(Oe.value.has(e) ? L.value.filter((t) => s(t) !== e) : x.value === "Single" ? [o(e)] : [...L.value, o(e)]));
		}, ut = (e) => {
			if (A.value === "Month") return E.value.months[B.value.index + e]?.start;
			if (A.value === "Year") return E.value.years[V.value.index + e]?.start;
			let t = H.value + e * 10;
			return (e > 0 ? E.value.years.find((e) => E.value.displayYear(e) >= t) : [...E.value.years].reverse().find((e) => E.value.displayYear(e) <= t))?.start;
		}, dt = (e) => {
			let t = e.target.closest("button");
			if (!t || !O.value?.contains(t) || t.disabled || !b.value) return;
			let n = t.dataset.cmd;
			if (n === "header") {
				Y(A.value === "Month" ? "Year" : "Decade");
				return;
			}
			if (n === "previous" || n === "next") {
				let e = ut(n === "previous" ? -1 : 1);
				e !== void 0 && (M.value = T(e), K(e, A.value, !0));
				return;
			}
			let r = Number(t.dataset.date);
			Number.isFinite(r) && (t.dataset.kind === "day" ? lt(r) : Y(t.dataset.kind === "month" ? "Month" : "Year", r, !0, !0));
		}, Q = async (e = M.value) => {
			M.value = T(e instanceof Date ? s(e) : e), K(M.value, A.value, !1, !0), await l();
			let t = A.value === "Month" ? M.value : A.value === "Year" ? E.value.monthAt(M.value).start : E.value.yearAt(M.value).start;
			return O.value?.querySelector(`[data-panel="${A.value}"] [data-date="${t}"]`)?.focus({ preventScroll: !0 }), !!O.value?.contains(document.activeElement);
		}, ft = (e) => {
			let t = e.target;
			t.dataset.date && (M.value = T(Number(t.dataset.date)));
		}, pt = (e) => {
			if (!b.value || !e.target.dataset.date) return;
			let t = e.key, n = A.value === "Month" ? 7 : N.value, r = t === "ArrowLeft" ? -1 : t === "ArrowRight" ? 1 : t === "ArrowUp" ? -n : t === "ArrowDown" ? n : 0;
			getComputedStyle(O.value).direction === "rtl" && (t === "ArrowLeft" || t === "ArrowRight") && (r *= -1);
			let i = M.value;
			if (!(t === "Enter" || t === " ")) {
				if (t === "Escape" && A.value !== "Month") {
					e.preventDefault(), Y(A.value === "Decade" ? "Year" : "Month", i, !0, !0);
					return;
				}
				if (e.ctrlKey && t === "ArrowUp" && A.value !== "Decade") {
					e.preventDefault(), Y(A.value === "Month" ? "Year" : "Decade", i, !0, !0);
					return;
				}
				if (e.ctrlKey && t === "ArrowDown" && A.value !== "Month") {
					e.preventDefault(), Y(A.value === "Decade" ? "Year" : "Month", i, !0, !0);
					return;
				}
				if (t === "PageUp" || t === "PageDown") {
					let n = t === "PageUp" ? -1 : 1, r = E.value.monthAt(i);
					if (A.value === "Month") {
						let t = E.value.months[r.index + n * (e.ctrlKey ? 12 : 1)];
						t && (i = Math.min(t.end, t.start + i - r.start));
					} else i = ut(n) ?? i;
				} else if (t === "Home" || t === "End") if (e.ctrlKey) i = t === "Home" ? C.value : w.value;
				else if (A.value === "Month") i = t === "Home" ? E.value.monthAt(i).start : E.value.monthAt(i).end;
				else if (A.value === "Year") i = t === "Home" ? E.value.yearAt(i).start : E.value.yearAt(i).end;
				else {
					let e = E.value.years.filter((e) => E.value.displayYear(e) >= H.value && E.value.displayYear(e) <= H.value + 9);
					i = (t === "Home" ? e[0] : e[e.length - 1])?.start ?? i;
				}
				else if (r) A.value === "Month" ? i += r : i = A.value === "Year" ? E.value.months[E.value.monthAt(i).index + r]?.start ?? i : E.value.years[E.value.yearAt(i).index + r]?.start ?? i;
				else return;
				e.preventDefault(), Q(T(i));
			}
		}, $ = /* @__PURE__ */ new Set(), mt = !0, ht = (e, t, n = !1) => ({
			Item: ze(e),
			Phase: t,
			InRecycleQueue: n,
			RegisterUpdateCallback(r, i) {
				let a = typeof r == "number" ? r : t + 1, o = typeof r == "function" ? r : i;
				!o || n || queueMicrotask(() => {
					mt && $.has(e) && o(X, ht(e, a));
				});
			}
		}), gt = (t, n = !1) => {
			let r = ht(t, 0, n);
			e(f.CalendarViewDayItemChanging, m)?.(X, r), p("CalendarViewDayItemChanging", X, r);
		};
		d(Be, (e) => {
			let t = new Set(e.map((e) => e.serial));
			for (let e of $) t.has(e) || (gt(e, !0), $.delete(e));
			for (let t of e) $.has(t.serial) || t.serial < C.value || t.serial > w.value || ($.add(t.serial), gt(t.serial));
		}, {
			flush: "post",
			immediate: !0
		}), d(() => L.value.some((e) => I.get(s(e))?.IsBlackout), (e) => {
			e && Z(L.value);
		}), d(() => g(f.SelectedDates), (e) => Z(st(e)), {
			immediate: !0,
			deep: !0
		}), d(x, () => Z(L.value)), d(() => _(f.DisplayMode, "Month"), (e) => {
			Y(e, j.value, !1);
		}, { immediate: !0 }), d(b, () => J(A.value)), d(() => g(f.Language), () => {
			pe.value = void 0;
		}), d(() => g(f.CalendarIdentifier), () => {
			me.value = void 0;
		}), d(() => g(f.SelectionMode), () => {
			he.value = void 0;
		}), d([
			E,
			be,
			D
		], async () => {
			$.clear(), Z(L.value), j.value = T(Te.value), M.value = T(M.value), await l(), vt(), K(Te.value, A.value, !1, !1, !0);
		});
		let _t, vt = () => {
			let e = et("Month");
			e?.clientHeight && (P.value = Math.max(42, (e.clientHeight - 4) / D.value)), k.value?.clientHeight && (De.value = k.value.clientHeight - 4);
		};
		ae(async () => {
			O.value?.addEventListener("click", dt), O.value?.addEventListener("keydown", pt), O.value?.addEventListener("focusin", ft), O.value?.addEventListener("scroll", rt, !0), O.value?.addEventListener("wheel", it, {
				capture: !0,
				passive: !0
			}), O.value?.addEventListener("touchstart", it, {
				capture: !0,
				passive: !0
			}), _t = new ResizeObserver(vt), k.value && _t.observe(k.value), await l(), vt(), J(A.value), K(j.value);
		}), ie(() => {
			mt = !1, ot(), _t?.disconnect(), O.value?.removeEventListener("click", dt), O.value?.removeEventListener("keydown", pt), O.value?.removeEventListener("focusin", ft), O.value?.removeEventListener("scroll", rt, !0), O.value?.removeEventListener("wheel", it, !0), O.value?.removeEventListener("touchstart", it, !0);
		}), se(X);
		let yt = {
			props: f,
			emit: p,
			instance: m,
			t: h,
			locale: le,
			resolve: g,
			text: _,
			number: v,
			bool: y,
			enabled: b,
			groupLabels: ue,
			outOfScope: de,
			todayHighlight: fe,
			langOverride: pe,
			idOverride: me,
			modeOverride: he,
			language: ge,
			identifier: _e,
			selectionMode: x,
			today: S,
			defaultMin: ve,
			defaultMax: ye,
			minimum: C,
			maximum: w,
			clamp: T,
			model: E,
			firstDay: be,
			weeks: D,
			weekdayNames: xe,
			root: O,
			views: k,
			monthViewer: Se,
			yearViewer: Ce,
			decadeViewer: we,
			currentMode: A,
			displayDate: j,
			anchorDate: Te,
			focusedDate: M,
			columns: N,
			rows: Ee,
			rowHeight: P,
			viewHeight: De,
			offsets: F,
			dayStates: I,
			localSelected: L,
			selectedSerials: Oe,
			dayStart: R,
			dayRows: ke,
			dayExtent: Ae,
			largeRowHeight: z,
			yearExtent: je,
			decadeExtent: Me,
			dayStartRow: Ne,
			dayRenderTop: Pe,
			monthStartRow: Fe,
			monthRenderTop: Ie,
			yearStartRow: Le,
			yearRenderTop: Re,
			getDayState: ze,
			scopeMonth: B,
			scopeYear: V,
			decade: H,
			dayCells: Be,
			monthCells: Ve,
			yearCells: He,
			headerText: Ue,
			canNavigate: We,
			headerAttrs: Ge,
			previousAttrs: Ke,
			nextAttrs: qe,
			thickness: U,
			weight: Je,
			styleSetters: Ye,
			styled: W,
			rootAttrs: Xe,
			dayAttrs: Ze,
			monthAttrs: Qe,
			yearAttrs: $e,
			viewport: et,
			dateTop: tt,
			get preserveAnchorUntil() {
				return G;
			},
			set preserveAnchorUntil(e) {
				G = e;
			},
			scrollToDate: K,
			updateScope: nt,
			onScroll: rt,
			onUserScroll: it,
			get animations() {
				return q;
			},
			set animations(e) {
				q = e;
			},
			get transition() {
				return at;
			},
			set transition(e) {
				at = e;
			},
			setPanelVisibility: J,
			stopAnimations: ot,
			setMode: Y,
			sender: X,
			normalizeDates: st,
			changeSelection: Z,
			selectedCollection: ct,
			selectDay: lt,
			navigationTarget: ut,
			onClick: dt,
			focusDate: Q,
			onFocus: ft,
			onKeydown: pt,
			prepared: $,
			get dayItemsActive() {
				return mt;
			},
			set dayItemsActive(e) {
				mt = e;
			},
			changingArgs: ht,
			notifyChanging: gt,
			get observer() {
				return _t;
			},
			set observer(e) {
				_t = e;
			},
			measure: vt,
			ScrollViewer: a
		};
		return Object.defineProperty(yt, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), yt;
	}
});
//#endregion
export { se as default };

//# sourceMappingURL=CalendarView.vue_vue_type_script_setup_true_lang.js.map