import { materializeXamlVNode as e, normalizeXamlNodes as t, resolveXamlHandler as n, resolveXamlResourceObject as r, resolveXamlValue as i, updateXamlBinding as a, xamlItemContextKey as o, xamlNameScopeKey as ee, xamlScopeKey as s } from "./xamlRuntime.js";
import { frameworkLayoutStyle as te } from "./frameworkLayout.js";
import { xamlResourceDictionaryKey as ne } from "./Page.vue_vue_type_script_lang.js";
import { CollectionItemTemplate as re, getCollectionProperty as ie, getVNodeChildren as c } from "./CollectionProperties.js";
import { breadcrumbBarItemContextKey as ae } from "./breadcrumbBarTemplate.js";
import l from "./BreadcrumbBarItem.vue.js";
import oe from "./Flyout.vue.js";
import { cloneVNode as se, computed as u, defineComponent as ce, getCurrentInstance as le, h as d, inject as ue, isVNode as de, nextTick as f, onBeforeUnmount as fe, onMounted as pe, provide as p, proxyRefs as me, ref as m, shallowReactive as he, shallowRef as h, unref as ge, useAttrs as _e, useSlots as ve, watch as g } from "vue";
var ye = /*@__PURE__*/ ce({
	ItemTemplate: re,
	name: "BreadcrumbBar",
	inheritAttrs: !1,
	__name: "BreadcrumbBar",
	props: {
		ItemsSource: {
			type: [
				String,
				Array,
				Object
			],
			default: null
		},
		ItemTemplate: {
			type: [
				String,
				Object,
				Function
			],
			default: void 0
		},
		IsEnabled: {
			type: [String, Boolean],
			default: !0
		},
		FlowDirection: {
			type: String,
			default: ""
		},
		Width: {
			type: [String, Number],
			default: ""
		},
		Height: {
			type: [String, Number],
			default: ""
		},
		MinWidth: {
			type: [String, Number],
			default: 0
		},
		MinHeight: {
			type: [String, Number],
			default: 0
		},
		MaxWidth: {
			type: [String, Number],
			default: ""
		},
		MaxHeight: {
			type: [String, Number],
			default: ""
		},
		Margin: {
			type: [String, Number],
			default: ""
		},
		HorizontalAlignment: {
			type: String,
			default: "Stretch"
		},
		VerticalAlignment: {
			type: String,
			default: "Stretch"
		},
		Visibility: {
			type: String,
			default: "Visible"
		}
	},
	emits: [
		"ItemClicked",
		"update:ItemsSource",
		"update:ItemTemplate",
		"update:IsEnabled",
		"update:FlowDirection"
	],
	setup(re, { expose: ye, emit: be }) {
		let _ = re, xe = be, v = le(), y = _e(), Se = ve(), Ce = ue(ne, null), we = ue(s, {}), b = m(null), x = m(null), Te = `breadcrumb-${v?.uid ?? 0}`, S = h({}), C = (e) => i(e, v), Ee = (e) => e in S.value ? S.value[e] : C(_[e]), w = (e) => u({
			get: () => Ee(e),
			set: (t) => {
				S.value = {
					...S.value,
					[e]: t
				}, a(_[e], t, v), xe(`update:${e}`, t);
			}
		}), T = w("ItemsSource"), E = w("ItemTemplate"), D = w("IsEnabled"), O = w("FlowDirection"), k = me({
			Element: b,
			ItemsSource: T,
			ItemTemplate: E,
			IsEnabled: D,
			FlowDirection: O,
			Focus: () => q(K()[0])
		});
		for (let e of [
			"ItemsSource",
			"ItemTemplate",
			"IsEnabled",
			"FlowDirection"
		]) g(() => C(_[e]), () => {
			let t = { ...S.value };
			delete t[e], S.value = t;
		});
		let De = m(0), A;
		g(T, (e) => {
			if (A?.(), A = void 0, typeof e?.addEventListener == "function") {
				let t = () => {
					De.value += 1;
				};
				e.addEventListener("CollectionChanged", t), A = () => e.removeEventListener("CollectionChanged", t);
			}
		}, { immediate: !0 });
		let j = u(() => {
			De.value;
			let e = T.value;
			return Array.isArray(e) ? e : e && Number.isFinite(e.Count) ? Array.from({ length: e.Count }, (t, n) => e.GetAt?.(n) ?? e[n]) : e && typeof e[Symbol.iterator] == "function" ? Array.from(e) : [];
		}), Oe = u(() => Object.fromEntries(Object.entries(y).filter(([e]) => ![
			"class",
			"style",
			"ItemClicked",
			"onItemClicked"
		].includes(e)))), ke = m("ltr"), M = u(() => O.value === "RightToLeft" ? "rtl" : O.value === "LeftToRight" ? "ltr" : ke.value), Ae = u(() => te(_, v)), N = m(null), P = m(0), je = u(() => ({
			"--breadcrumb-available-width": N.value === null ? void 0 : `${N.value}px`,
			minHeight: P.value ? `${P.value}px` : void 0
		})), F = m(0), I = m(!1), L = m(null), R = /* @__PURE__ */ new Map(), z = /* @__PURE__ */ new Map(), B = j.value.slice(), V = null, H = h([]), Me = u(() => j.value.length - F.value), U = /* @__PURE__ */ new WeakMap(), Ne = 0, Pe = (e, t) => e && typeof e == "object" ? (U.has(e) || U.set(e, ++Ne), `item:${U.get(e)}:${t}`) : `${t}:${String(e)}`, W = (e) => ge(e?.Element) ?? e?.$el ?? e ?? null, G = (e) => D.value !== !1 && (e < 0 || R.get(e)?.IsEnabled !== !1), K = () => {
			let e = [];
			I.value && G(-1) && e.push(-1);
			for (let t = F.value; t < j.value.length; t += 1) G(t) && e.push(t);
			return e;
		}, Fe = (e) => {
			let t = K();
			return (t.includes(L.value) ? L.value : t[0]) === e ? 0 : -1;
		}, q = (e) => K().includes(e) ? (L.value = e, R.get(e)?.Focus?.(), document.activeElement === W(R.get(e))) : !1, Ie = () => {
			let e = K(), t = document.activeElement, n = b.value?.contains(t) ?? !1;
			e.includes(L.value) || (L.value = e[0] ?? null, n && L.value !== null && f(() => q(L.value)));
		}, Le = (e) => {
			b.value?.contains(e.relatedTarget) || (L.value = null, e.relatedTarget && e.relatedTarget !== document.body && e.relatedTarget !== document.documentElement && (V = null));
		}, Re = () => {
			let e = document.activeElement;
			if (!e || !b.value?.contains(e)) return;
			let t = [...R].find(([, t]) => W(t)?.contains(e))?.[0];
			if (t === void 0) return;
			let n = B[t];
			V = {
				item: n,
				occurrence: t < 0 ? 0 : B.slice(0, t).filter((e) => Object.is(e, n)).length,
				index: t,
				element: e
			};
		}, ze = () => {
			let e = V;
			if (V = null, !e) return;
			let t = document.activeElement;
			if (t && t !== e.element && t !== document.body && t !== document.documentElement) return;
			let n = K();
			if (!n.length) return;
			let r = e.index;
			if (e.index >= 0) {
				let t = 0;
				r = j.value.findIndex((n) => Object.is(n, e.item) && t++ === e.occurrence), r < 0 ? r = e.index : r < F.value && I.value && (r = -1);
			}
			q(n.includes(r) ? r : n.find((e) => e >= r) ?? n[n.length - 1]);
		}, Be = (e, t) => {
			if (!G(t)) return;
			let r = Object.freeze({
				Item: e,
				Index: t
			});
			n(y.ItemClicked ?? y.onItemClicked, v)?.(k, r), xe("ItemClicked", k, r);
		}, J = () => x.value?.Hide?.(), Ve = async () => {
			!G(-1) || !I.value || F.value < 1 || (H.value = j.value.slice(0, F.value).map((e, t) => ({
				Item: e,
				Index: t
			})).reverse(), await f(), x.value?.ShowAt?.(W(R.get(-1))));
		}, He = (e, t) => {
			let n = M.value === "rtl" ? "ArrowLeft" : "ArrowRight", r = M.value === "rtl" ? "ArrowRight" : "ArrowLeft";
			if (e.key !== n && e.key !== r) return;
			let i = K(), a = i.indexOf(t), o = a + (e.key === n ? 1 : -1);
			a < 0 || o < 0 || o >= i.length || (e.preventDefault(), q(i[o]));
		}, Ue = (e, t) => {
			let n = H.value.map((e, t) => t).filter((e) => z.get(e)?.IsEnabled !== !1), r = n.indexOf(t), i = r;
			if (e.key === "ArrowDown") i = Math.min(n.length - 1, r + 1);
			else if (e.key === "ArrowUp") i = Math.max(0, r - 1);
			else if (e.key === "Home") i = 0;
			else if (e.key === "End") i = n.length - 1;
			else return;
			e.preventDefault(), z.get(n[i])?.Focus?.();
		}, We = h(Se.default?.() ?? []), Ge = u(() => {
			let e = "ItemTemplate" in S.value ? S.value.ItemTemplate : _.ItemTemplate, t = typeof e == "string" ? e.match(/^\{(?:StaticResource|ThemeResource)\s+([^}]+)\}$/)?.[1] : null, n = t ? Ce?.[t] ?? r(t, v) : null;
			if (de(n)) return c(n);
			if (de(E.value)) return c(E.value);
			if (Array.isArray(E.value)) return E.value;
			let i = We.value.find((e) => ie(e) === "itemTemplate");
			return i ? c(i) : [];
		}), Ke = ce({
			name: "BreadcrumbBarElementFactory",
			props: {
				item: {
					type: null,
					default: void 0
				},
				index: {
					type: [Number, String],
					required: !0
				},
				dropDown: Boolean,
				flyoutIndex: {
					type: Number,
					default: -1
				}
			},
			setup(n) {
				let r = le(), i = () => Number(n.index);
				p(ae, {
					get enabled() {
						return D.value !== !1;
					},
					get direction() {
						return M.value;
					},
					get flyoutOpen() {
						return !!x.value?.IsOpen;
					},
					get type() {
						return n.dropDown ? "EllipsisDropDown" : i() === -1 ? "Ellipsis" : i() === j.value.length - 1 ? "LastItem" : "Inline";
					},
					get hidden() {
						return !n.dropDown && (i() === -1 ? !I.value : i() < F.value);
					},
					get tabIndex() {
						return n.dropDown ? 0 : Fe(i());
					},
					activate() {
						n.dropDown ? (J(), Be(n.item, i())) : i() === -1 ? Ve() : Be(n.item, i());
					},
					gotFocus() {
						n.dropDown || (L.value = i());
					},
					keyDown(e) {
						n.dropDown ? Ue(e, n.flyoutIndex) : He(e, i());
					}
				}), p(o, u(() => n.item)), p(ee, he({}));
				let a = (e) => {
					let t = n.dropDown ? z : R, r = n.dropDown ? n.flyoutIndex : i();
					e ? t.set(r, e) : t.delete(r);
				};
				return () => {
					let o = {
						Content: n.item,
						ref: a,
						"aria-posinset": n.dropDown ? n.flyoutIndex + 1 : i() < 0 ? void 0 : i() - F.value + 1,
						"aria-setsize": n.dropDown ? H.value.length : Me.value
					};
					if (i() === -1) return d(l, o);
					let ee = Ge.value;
					if (ee.length) {
						let i = t(e(ee, n.item, r), r), a = i.find((e) => e.type === l || e.type?.name === "BreadcrumbBarItem");
						return a ? se(a, o) : d(l, o, { default: () => i });
					}
					let s = E.value;
					return s && (typeof s == "function" || typeof s == "object") ? d(l, o, { default: () => [d(s)] }) : d(l, o);
				};
			}
		}), Y, X = 0, Z = !1, qe = () => {
			X = 0;
			let e = b.value;
			if (!e || Z) return;
			let t = getComputedStyle(e), n = Math.max(0, e.clientWidth - parseFloat(t.paddingLeft || "0") - parseFloat(t.paddingRight || "0"));
			ke.value = getComputedStyle(e.parentElement ?? e).direction === "rtl" ? "rtl" : "ltr", N.value = n;
			let r = (e) => {
				let t = W(R.get(e));
				if (!t) return {
					width: 0,
					height: 0
				};
				let n = t.getBoundingClientRect(), r = getComputedStyle(t);
				return {
					width: n.width + parseFloat(r.marginLeft || "0") + parseFloat(r.marginRight || "0"),
					height: n.height + parseFloat(r.marginTop || "0") + parseFloat(r.marginBottom || "0")
				};
			}, i = j.value.map((e, t) => r(t));
			if (P.value = i.reduce((e, t) => Math.max(e, t.height), 0), I.value = i.reduce((e, t) => e + t.width, 0) > n, !I.value || !j.value.length) F.value = 0, J();
			else {
				let e = j.value.length - 1, t = i[e].width + r(-1).width;
				for (let r = e - 1; r >= 0 && !(t + i[r].width > n); --r) t += i[r].width, e = r;
				F.value = e;
			}
			Ie(), ze();
		}, Q = () => {
			X || Z || (X = requestAnimationFrame(qe));
		}, $ = () => {
			Y?.disconnect(), b.value && Y?.observe(b.value), R.forEach((e) => {
				let t = W(e);
				t && Y?.observe(t);
			});
		};
		g(j, async () => {
			J(), Re(), B = j.value.slice(), await f(), $(), Q();
		}, { deep: !0 }), g(E, async () => {
			J(), await f(), $(), Q();
		}), g([D, O], () => {
			D.value === !1 && J(), Q();
		}), pe(async () => {
			typeof ResizeObserver < "u" && (Y = new ResizeObserver(Q)), await f(), $(), Q(), document.fonts?.ready.then(Q);
		}), fe(() => {
			Z = !0, V = null, A?.(), Y?.disconnect(), X && cancelAnimationFrame(X);
		}), p(s, {
			...we,
			BreadcrumbBarTemplate: { FlyoutPresenterStyle: {
				Background: "{ThemeResource BreadcrumbBarEllipsisFlyoutPresenterBackground}",
				BorderBrush: "{ThemeResource BreadcrumbBarEllipsisFlyoutPresenterBorderBrush}",
				BorderThickness: "{ThemeResource BreadcrumbBarEllipsisFlyoutPresenterBorderThemeThickness}",
				Padding: "0,2",
				MinHeight: 40,
				MaxWidth: "{ThemeResource FlyoutThemeMaxWidth}",
				CornerRadius: "{ThemeResource OverlayCornerRadius}",
				"ScrollViewer.HorizontalScrollMode": "Disabled",
				"ScrollViewer.HorizontalScrollBarVisibility": "Disabled",
				"ScrollViewer.VerticalScrollMode": "Auto",
				"ScrollViewer.VerticalScrollBarVisibility": "Auto",
				"ScrollViewer.IsHorizontalRailEnabled": !1,
				"ScrollViewer.IsVerticalRailEnabled": !1,
				"ScrollViewer.ZoomMode": "Disabled"
			} }
		}), ye({
			Element: b,
			ItemsSource: T,
			ItemTemplate: E,
			IsEnabled: D,
			FlowDirection: O,
			Focus: () => q(K()[0])
		});
		let Je = {
			props: _,
			emit: xe,
			instance: v,
			attrs: y,
			slots: Se,
			resources: Ce,
			inheritedScope: we,
			rootRef: b,
			flyoutRef: x,
			instanceId: Te,
			overrides: S,
			resolve: C,
			property: Ee,
			dependencyProperty: w,
			ItemsSource: T,
			ItemTemplate: E,
			IsEnabled: D,
			FlowDirection: O,
			publicApi: k,
			sourceRevision: De,
			get unsubscribeSource() {
				return A;
			},
			set unsubscribeSource(e) {
				A = e;
			},
			Items: j,
			rootAttrs: Oe,
			inheritedDirection: ke,
			effectiveFlowDirection: M,
			rootStyle: Ae,
			availableWidth: N,
			desiredHeight: P,
			repeaterStyle: je,
			firstRenderedIndex: F,
			ellipsisIsRendered: I,
			focusedIndex: L,
			itemRefs: R,
			flyoutItemRefs: z,
			get previousItems() {
				return B;
			},
			set previousItems(e) {
				B = e;
			},
			get pendingCollectionFocus() {
				return V;
			},
			set pendingCollectionFocus(e) {
				V = e;
			},
			flyoutItems: H,
			visibleItemsCount: Me,
			itemKeys: U,
			get nextKey() {
				return Ne;
			},
			set nextKey(e) {
				Ne = e;
			},
			getItemKey: Pe,
			elementFor: W,
			isEnabled: G,
			focusableIndices: K,
			getTabIndex: Fe,
			focusItem: q,
			ensureFocus: Ie,
			onFocusOut: Le,
			captureCollectionFocus: Re,
			restoreCollectionFocus: ze,
			raiseItemClicked: Be,
			closeFlyout: J,
			openFlyout: Ve,
			onItemKeyDown: He,
			onDropDownKeyDown: Ue,
			slotNodes: We,
			templateNodes: Ge,
			ItemOutlet: Ke,
			get resizeObserver() {
				return Y;
			},
			set resizeObserver(e) {
				Y = e;
			},
			get frame() {
				return X;
			},
			set frame(e) {
				X = e;
			},
			get unmounted() {
				return Z;
			},
			set unmounted(e) {
				Z = e;
			},
			measure: qe,
			requestMeasure: Q,
			observeItems: $,
			Flyout: oe
		};
		return Object.defineProperty(Je, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), Je;
	}
});
//#endregion
export { ye as default };

//# sourceMappingURL=BreadcrumbBar.vue_vue_type_script_setup_true_lang.js.map