import "./imageSource.js";
import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./Image.vue_vue_type_script_setup_true_lang.js";
/* empty css                                          */
import { createCommentVNode as n, createElementBlock as r, createVNode as i, mergeProps as a, normalizeStyle as o, openBlock as s, withModifiers as c } from "vue";
//#region src/components/Image.vue
var l = ["aria-label"], u = {
	key: 0,
	ref: "canvasRef",
	class: "win-image-surface",
	"aria-hidden": "true"
}, d = ["src", "alt"];
function f(e, t, f, p, m, h) {
	return s(), r("div", a({ ref: "rootRef" }, p.rootAttrs, {
		class: ["win-image-host", p.attrs.class],
		style: p.hostStyle,
		role: "img",
		"aria-label": p.automationName || void 0,
		onDragstart: t[0] ||= c(() => {}, ["prevent"])
	}), [p.usesCanvas ? (s(), r("canvas", u, null, 512)) : p.uri && p.loaded ? (s(), r("img", {
		key: 1,
		class: "win-image-surface",
		src: p.uri,
		style: o(p.surfaceStyle),
		alt: p.automationName,
		draggable: "false",
		decoding: "async"
	}, null, 12, d)) : n("", !0), i(p.SourceOutlet)], 16, l);
}
var p = /*#__PURE__*/ e(t, [["render", f], ["__file", "Image.vue"]]);
//#endregion
export { p as default };

//# sourceMappingURL=Image.vue.js.map