import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./FocusVisual.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                */
import { createElementBlock as n, createElementVNode as r, normalizeStyle as i, openBlock as a } from "vue";
//#region src/components/FocusVisual.vue
function o(e, t, o, s, c, l) {
	return a(), n("span", {
		class: "win-focus-visual",
		"aria-hidden": "true",
		style: i(s.focusStyle)
	}, [...t[0] ||= [r("span", { class: "win-focus-visual-secondary" }, null, -1)]], 4);
}
var s = /*#__PURE__*/ e(t, [["render", o], ["__file", "FocusVisual.vue"]]);
//#endregion
export { s as default };

//# sourceMappingURL=FocusVisual.vue.js.map