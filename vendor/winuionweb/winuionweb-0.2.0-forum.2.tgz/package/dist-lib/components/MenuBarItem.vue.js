import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./MenuBarItem.vue_vue_type_script_lang.js";
/* empty css                                                                */
//#region src/components/MenuBarItem.vue
var n = /*#__PURE__*/ e(t, [["__scopeId", "data-v-804a0295"], ["__file", "MenuBarItem.vue"]]);
//#endregion
export { n as default };

//# sourceMappingURL=MenuBarItem.vue.js.map