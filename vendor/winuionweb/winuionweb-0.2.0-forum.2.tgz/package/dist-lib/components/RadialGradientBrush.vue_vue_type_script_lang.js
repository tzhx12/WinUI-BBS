import { clampOpacity as e, colorString as t } from "./brushCore.js";
import { resolveXamlValue as n, updateXamlBinding as r, xamlNameScopeKey as i } from "./xamlRuntime.js";
import { Fragment as a, defineComponent as o, markRaw as s, reactive as c, shallowRef as l, watch as u } from "vue";
//#region src/components/RadialGradientBrush.vue?vue&type=script&lang.ts
var d = (e, t) => Number.isFinite(Number(e)) ? Number(e) : t, f = (e, t = {
	X: .5,
	Y: .5
}) => {
	if (e && typeof e == "object" && "X" in e && "Y" in e) return {
		X: d(e.X, t.X),
		Y: d(e.Y, t.Y)
	};
	let n = String(e ?? "").trim().split(/[\s,]+/);
	return n.length === 2 ? {
		X: d(n[0], t.X),
		Y: d(n[1], t.Y)
	} : { ...t };
}, p = (e = {}) => c(new Proxy({
	Color: t(e.Color ?? "Transparent"),
	Offset: d(e.Offset ?? 0, 0)
}, { set(e, n, r, i) {
	return Reflect.set(e, n, n === "Color" ? t(r) : n === "Offset" ? d(r, 0) : r, i);
} })), m = class {
	#e = c([]);
	#t = /* @__PURE__ */ new Set();
	constructor() {
		s(this);
	}
	get Size() {
		return this.#e.length;
	}
	get Count() {
		return this.Size;
	}
	GetAt(e) {
		return this.#r(e), this.#e[e];
	}
	SetAt(e, t) {
		this.#r(e), this.#e[e] = this.#n(t), this.#i("ItemChanged", e);
	}
	InsertAt(e, t) {
		this.#r(e, !0), this.#e.splice(e, 0, this.#n(t)), this.#i("ItemInserted", e);
	}
	Append(e) {
		this.InsertAt(this.Size, e);
	}
	RemoveAt(e) {
		this.#r(e), this.#e.splice(e, 1), this.#i("ItemRemoved", e);
	}
	RemoveAtEnd() {
		this.RemoveAt(this.Size - 1);
	}
	Clear() {
		this.ReplaceAll([]);
	}
	ReplaceAll(e) {
		let t = Array.from(e, (e) => this.#n(e));
		this.#e.splice(0, this.Size, ...t), this.#i("Reset", 0);
	}
	IndexOf(e) {
		let t = this.#e.indexOf(e);
		return {
			found: t >= 0,
			index: Math.max(0, t)
		};
	}
	GetView() {
		return Object.freeze([...this.#e]);
	}
	VectorChanged(e) {
		return this.#t.add(e), () => this.#t.delete(e);
	}
	[Symbol.iterator]() {
		return this.#e[Symbol.iterator]();
	}
	#n(e) {
		if (!e || typeof e != "object" || !("Color" in e) || !("Offset" in e)) throw TypeError("GradientStops must contain GradientStop values.");
		return c(e);
	}
	#r(e, t = !1) {
		if (!Number.isInteger(e) || e < 0 || e >= this.Size + Number(t)) throw RangeError("GradientStops index is out of bounds.");
	}
	#i(e, t) {
		for (let n of this.#t) n(this, {
			CollectionChange: e,
			Index: t
		});
	}
}, h = () => {
	let n = new m();
	return c(new Proxy({
		__radialGradient: !0,
		Center: {
			X: .5,
			Y: .5
		},
		GradientOrigin: {
			X: .5,
			Y: .5
		},
		RadiusX: .5,
		RadiusY: .5,
		MappingMode: "RelativeToBoundingBox",
		SpreadMethod: "Pad",
		InterpolationSpace: "Auto",
		Opacity: 1,
		FallbackColor: t("Transparent"),
		get GradientStops() {
			return n;
		}
	}, { set(n, r, i, a) {
		let o = i;
		return r === "Center" || r === "GradientOrigin" ? o = f(i) : r === "RadiusX" || r === "RadiusY" ? o = d(i, .5) : r === "Opacity" ? o = e(i) : r === "FallbackColor" ? o = t(i) : r === "MappingMode" ? o = i === "Absolute" ? "Absolute" : "RelativeToBoundingBox" : r === "SpreadMethod" && (o = i === "Repeat" || i === "Reflect" ? i : "Pad"), Reflect.set(n, r, o, a);
	} }));
};
o({
	name: "GradientStop",
	__xamlReactive: !0,
	props: {
		Color: {
			type: String,
			default: "Transparent"
		},
		Offset: {
			type: [String, Number],
			default: 0
		}
	},
	setup: () => () => null
});
var g = o({
	name: "RadialGradientBrush.GradientStops",
	setup: () => () => null
}), _ = (e) => Array.isArray(e.children) ? e.children : e.children?.default?.() ?? [], v = o({
	name: "RadialGradientBrush",
	__xamlBrush: !0,
	__xamlReactive: !0,
	__createXamlResource: (e, o) => {
		let s = h(), c = (e) => n(e, o.instance ?? null);
		for (let t of [
			"Center",
			"GradientOrigin",
			"RadiusX",
			"RadiusY",
			"MappingMode",
			"SpreadMethod",
			"InterpolationSpace",
			"Opacity",
			"FallbackColor"
		]) o.Dispose(u(() => c(e(t)), (e) => {
			if (e != null) {
				if (t === "Center" || t === "GradientOrigin") {
					let n = f(e);
					if (s[t].X === n.X && s[t].Y === n.Y) return;
				}
				Reflect.set(s, t, e);
			}
		}, {
			immediate: !0,
			deep: !0
		})), o.Dispose(u(() => s[t], (e) => {
			let n = o.Node?.().props?.[t];
			if (t === "Center" || t === "GradientOrigin") {
				let t = c(n), r = e;
				if (t && typeof t == "object" && "X" in t && "Y" in t && t.X === r.X && t.Y === r.Y) return;
			}
			r(n, e, o.instance ?? null);
		}, { deep: !0 }));
		let m = o.instance?.provides[i], v = [], y = () => {
			let e = [], t = (n) => {
				for (let r of n) r.type === a || r.type === g ? t(_(r)) : r.type.name === "GradientStop" && e.push(r);
			}, n = o.Node?.();
			return n && t(_(n)), e;
		}, b = (e) => e.props?.["x:Name"] ?? e.props?.["data-xaml-ref"], x = (e) => {
			let n = l(e), i = p(), a = [];
			for (let e of ["Color", "Offset"]) a.push(u(() => c(n.value.props?.[e]), (n) => {
				e === "Color" ? i.Color = t(n ?? "Transparent") : i.Offset = d(n ?? 0, 0);
			}, { immediate: !0 })), a.push(u(() => i[e], (t) => {
				r(n.value.props?.[e], t, o.instance ?? null);
			}));
			return {
				node: n,
				stop: i,
				dispose: () => a.forEach((e) => e())
			};
		}, S = (e) => {
			e.name && m?.[e.name] === e.stop && delete m[e.name], e.name = void 0;
		};
		return o.Dispose(u(y, (e) => {
			let t = [...v], n = e.map((e, n) => {
				let r = b(e), i = e.key ?? r, a = i === void 0 ? t.indexOf(v[n]) : t.findIndex((e) => e.node.value && (e.node.value.key ?? b(e.node.value)) === i), o = a >= 0 ? t.splice(a, 1)[0] : x(e);
				return o.node.value = e, o.name !== r && S(o), typeof r == "string" && m && (m[r] = o.stop, o.name = r), o;
			}), r = n.length !== v.length || n.some((e, t) => e !== v[t]);
			for (let e of t) S(e), e.dispose();
			v = n, r && s.GradientStops.ReplaceAll(n.map((e) => e.stop));
		}, { immediate: !0 })), o.Dispose(() => {
			for (let e of v) S(e), e.dispose();
			v = [];
		}), s;
	},
	GradientStops: g,
	props: {
		Center: {
			type: [String, Object],
			default: "0.5,0.5"
		},
		GradientOrigin: {
			type: [String, Object],
			default: "0.5,0.5"
		},
		RadiusX: {
			type: [String, Number],
			default: .5
		},
		RadiusY: {
			type: [String, Number],
			default: .5
		},
		MappingMode: {
			type: String,
			default: "RelativeToBoundingBox"
		},
		SpreadMethod: {
			type: String,
			default: "Pad"
		},
		InterpolationSpace: {
			type: String,
			default: "Auto"
		},
		Opacity: {
			type: [String, Number],
			default: 1
		},
		FallbackColor: {
			type: String,
			default: "Transparent"
		}
	},
	setup: () => () => null
});
//#endregion
export { m as GradientStopCollection, g as RadialGradientStops, p as createGradientStop, h as createRadialGradientBrush, v as default, f as gradientPoint };

//# sourceMappingURL=RadialGradientBrush.vue_vue_type_script_lang.js.map