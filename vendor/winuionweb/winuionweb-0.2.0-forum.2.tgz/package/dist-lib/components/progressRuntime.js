import { resolveXamlValue as e, updateXamlBinding as t } from "./xamlRuntime.js";
import { computed as n, ref as r, watch as i } from "vue";
//#region src/components/progressRuntime.ts
var a = (a, o, s, c) => {
	let l = n(() => e(a[o], s)), u = r(l.value);
	return i(l, (e) => {
		u.value = e;
	}, { flush: "sync" }), n({
		get: () => u.value,
		set: (n) => {
			let r = e(n, s);
			u.value = r, t(a[o], r, s), c(o, r);
		}
	});
}, o = (e, t = 0) => {
	if (e == null || e === "") return t;
	let n = Number(e);
	return Number.isFinite(n) ? n : t;
}, s = (e, t = !1) => typeof e == "boolean" ? e : typeof e == "string" && /^(True|False)$/i.test(e.trim()) ? /^True$/i.test(e.trim()) : t, c = (e, t, r) => {
	let s = a(e, "Value", t, r), c = a(e, "Minimum", t, r), l = a(e, "Maximum", t, r), u = n(() => o(c.value, 0)), d = n(() => Math.max(u.value, o(l.value, 100))), f = (e) => Math.min(d.value, Math.max(u.value, o(e, u.value))), p = n(() => f(s.value)), m = n(() => d.value > u.value ? (p.value - u.value) / (d.value - u.value) : 0);
	return i(s, (e) => {
		let t = f(e);
		Object.is(o(e, u.value), t) || (s.value = t);
	}, { flush: "sync" }), i(() => o(c.value, 0), (e) => {
		e > o(l.value, 100) && (l.value = e), Object.is(s.value, f(s.value)) || (s.value = f(s.value));
	}, { flush: "sync" }), i(() => o(l.value, 100), (e) => {
		e < o(c.value, 0) && (c.value = e), Object.is(s.value, f(s.value)) || (s.value = f(s.value));
	}, { flush: "sync" }), o(l.value, 100) < u.value && (l.value = u.value), Object.is(o(s.value, u.value), f(s.value)) || (s.value = f(s.value)), {
		Value: n({
			get: () => p.value,
			set: (e) => {
				s.value = f(e);
			}
		}),
		Minimum: n({
			get: () => u.value,
			set: (e) => {
				c.value = o(e, u.value);
			}
		}),
		Maximum: n({
			get: () => d.value,
			set: (e) => {
				l.value = o(e, d.value);
			}
		}),
		minimum: u,
		maximum: d,
		fraction: m,
		coercedValue: p
	};
}, l = (e) => {
	if (typeof e == "string") return e || void 0;
	if (e && typeof e == "object" && "Color" in e) return String(e.Color);
}, u = (e) => {
	let t = String(e || 0).split(",").map((e) => o(e.trim(), 0));
	return t.length === 4 ? {
		left: t[0],
		top: t[1],
		right: t[2],
		bottom: t[3]
	} : t.length === 2 ? {
		left: t[0],
		top: t[1],
		right: t[0],
		bottom: t[1]
	} : {
		left: t[0],
		top: t[0],
		right: t[0],
		bottom: t[0]
	};
}, d = (e) => {
	if (e == null || e === "") return;
	let t = String(e).split(",").map((e) => `${o(e.trim(), 0)}px`);
	return t.length === 4 ? t.join(" ") : t[0];
}, f = (e) => {
	let t = [
		[0, 1e-4],
		[.00833333377, 1e-4],
		[.25, .25],
		[.5, .5],
		[.75, .75],
		[.983333349, .96666666],
		[.991666675, 1],
		[1, 1]
	];
	for (let n = 1; n < t.length; n++) {
		let [r, i] = t[n];
		if (e <= r) {
			let [a, o] = t[n - 1];
			return o + (i - o) * Math.max(0, (e - a) / (r - a));
		}
	}
	return 1;
};
//#endregion
export { f as determinateRingTrim, s as progressBoolean, l as progressBrush, d as progressCornerRadius, o as progressNumber, u as progressThickness, a as useProgressProperty, c as useProgressRange };

//# sourceMappingURL=progressRuntime.js.map