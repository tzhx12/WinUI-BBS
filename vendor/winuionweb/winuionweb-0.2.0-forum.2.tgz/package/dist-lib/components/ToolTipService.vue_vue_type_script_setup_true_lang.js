import { xamlScopeKey as e } from "./xamlRuntime.js";
import { isInToolTipSafeZone as t, registeredToolTip as n, toolTipOwnerContextKey as r } from "./toolTipRuntime.js";
import { ToolTipServiceToolTip as i } from "./ToolTipServiceProperties.js";
import a from "./ToolTip.vue.js";
import { defineComponent as o, nextTick as ee, onBeforeUnmount as te, onMounted as ne, provide as s, ref as c, shallowRef as re } from "vue";
var l = /*@__PURE__*/ o({
	ToolTip: i,
	__name: "ToolTipService",
	setup(i, { expose: o }) {
		o();
		let l = "tooltipservice.tooltip", ie = "tooltipservice.placement", ae = "tooltipservice.placementtarget", u = "[tooltipservice\\.tooltip]", oe = 5e3, d = c("");
		s(e, { ServiceContent: d });
		let se = c(null), f = () => se.value?.ownerDocument ?? document, p = () => f().defaultView ?? window, m = (e) => !!(e && typeof e == "object" && "nodeType" in e), h = (e) => e.nodeType === 1 && e.namespaceURI === "http://www.w3.org/1999/xhtml", g = c(null), _ = re(null), v = c("none"), y = c(null), b = c("");
		s(r, {
			owner: _,
			inputMode: v,
			point: y,
			theme: b,
			attached: !1
		});
		let x = /* @__PURE__ */ new WeakMap(), S = /* @__PURE__ */ new Set(), C = /* @__PURE__ */ new WeakMap(), w = null, T = null, E = null, D = null, O, k, A, j = -Infinity, M = "none", N, P = 0, F = (e) => n(e) ?? (_.value === e ? g.value?.Controller : null), I = (e) => {
			if (e.matches(":disabled") || e.closest("[aria-disabled=\"true\"]") || e.matches(":disabled") || e.querySelector(":disabled")) return !1;
			let t = n(e);
			if (t) return t.IsEnabled();
			let r = e.getAttribute(l);
			return !!r && !/\{(?:x:Bind|Binding)\s|\[object Object\]/.test(r);
		}, L = (e) => {
			let t = m(e) ? h(e) ? e : e.parentElement : null;
			for (; t;) {
				if (t.hasAttribute(l)) return t;
				t = t.parentElement;
			}
			return null;
		};
		function R(e) {
			if (!e.hasAttribute(l)) {
				w === e && U(), z(e);
				return;
			}
			S.has(e) || (x.set(e, e.getAttribute("title")), S.add(e)), e.removeAttribute("title"), w === e && _.value === e && (d.value = e.getAttribute(l) ?? "");
		}
		function z(e) {
			if (!S.has(e)) return;
			let t = x.get(e);
			t == null ? e.removeAttribute("title") : e.setAttribute("title", t), S.delete(e), x.delete(e);
		}
		let B = () => {
			O !== void 0 && p().clearTimeout(O), O = void 0, T = null, P += 1;
		}, V = () => {
			k !== void 0 && p().clearTimeout(k), k = void 0;
		}, H = () => {
			A !== void 0 && p().clearTimeout(A), A = void 0;
		};
		function ce(e) {
			if (!C.has(e)) return;
			let t = C.get(e);
			t == null ? e.removeAttribute("aria-describedby") : e.setAttribute("aria-describedby", t), C.delete(e);
		}
		function U() {
			B(), V(), H(), w && (F(w)?.Close(), ce(w), j = p().performance.now()), w = null;
		}
		function W(e) {
			let t = e.closest(".theme-light, .theme-dark");
			b.value = t?.classList.contains("theme-dark") ? "dark" : t?.classList.contains("theme-light") ? "light" : "";
		}
		async function G(e, t, r) {
			if (!e.isConnected || !I(e)) return;
			V(), B(), w && w !== e && U(), w = e, M = t, N = r;
			let i = n(e);
			if (!i) {
				let n = P;
				if (_.value = e, v.value = t, y.value = r ?? null, d.value = e.getAttribute(l) ?? "", W(e), await ee(), n !== P || w !== e || !e.isConnected) return;
				i = g.value?.Controller;
			}
			if (!i || w !== e || !e.isConnected) return;
			i?.Open(t, r);
			let a = P;
			if (await ee(), await i?.UpdatePosition(), a !== P || w !== e) return;
			let o = i?.Element()?.id;
			if (o) {
				C.has(e) || C.set(e, e.getAttribute("aria-describedby"));
				let t = C.get(e);
				e.setAttribute("aria-describedby", [t, o].filter(Boolean).join(" "));
			}
		}
		function K(e, t, n) {
			if (E === e || !I(e)) return;
			if (w === e && F(e)?.IsOpen()) {
				V();
				return;
			}
			if (T === e) {
				N = n;
				return;
			}
			let r = !!(w && w !== e);
			r ? U() : (B(), V());
			let i = p().performance.now() - j <= 200, a = t === "touch" ? i || r ? 0 : 400 : t === "keyboard" ? 400 * 2 : i || r ? 400 * 1.5 : 400 * 2;
			T = e, N = n, O = p().setTimeout(() => {
				G(e, t, N);
			}, a);
		}
		function q(e) {
			let n = w ? F(w)?.Element() : null;
			return !!(w && n && t(e, w.getBoundingClientRect(), n.getBoundingClientRect()));
		}
		function J(e, t = !1) {
			T !== e && w !== e || (T === e && B(), !(!t && N && q(N)) && k === void 0 && (k = p().setTimeout(() => {
				k = void 0, U();
			}, 167)));
		}
		function le(e) {
			if (e.nodeType !== 1) return;
			let t = e;
			h(e) && t.hasAttribute(l) && R(e), t.querySelectorAll(u).forEach(R);
		}
		function ue(e) {
			if (e.nodeType !== 1) return;
			let t = e;
			(h(e) && t.hasAttribute(l) ? [e, ...t.querySelectorAll(u)] : [...t.querySelectorAll(u)]).forEach((e) => {
				w === e && U(), T === e && B(), E === e && (E = null), z(e);
			});
		}
		function de(e) {
			let t = L(e.target);
			t && e.pointerType !== "touch" ? (M = "mouse", K(t, "mouse", {
				x: e.clientX,
				y: e.clientY
			})) : w && e.target?.closest?.(".win-tooltip") && V();
		}
		function Y(e) {
			e.pointerType !== "touch" && (N = {
				x: e.clientX,
				y: e.clientY
			}, w && (q(N) ? V() : J(w)));
		}
		function fe(e) {
			let t = e.target?.closest?.(".win-tooltip");
			if (t && w) {
				let n = e.relatedTarget;
				m(n) && t.contains(n) || (N = {
					x: e.clientX,
					y: e.clientY
				}, J(w, n === null));
				return;
			}
			let n = L(e.target);
			if (!n) return;
			let r = e.relatedTarget;
			m(r) && n.contains(r) || (E === n && !n.matches(":hover") && (E = null), N = {
				x: e.clientX,
				y: e.clientY
			}, J(n, r === null));
		}
		function pe(e) {
			let t = L(e.target);
			M = e.pointerType === "touch" ? "touch" : "mouse", e.pointerType === "touch" && t ? (K(t, "touch", {
				x: e.clientX,
				y: e.clientY
			}), H(), A = p().setTimeout(U, oe)) : t ? (E = t, (w === t || T === t) && U()) : w && U();
		}
		function X() {
			U();
		}
		function me(e) {
			e.pointerType === "touch" && T && B();
		}
		function he(e) {
			let t = L(e.target);
			t && M === "keyboard" && K(t, "keyboard");
		}
		function ge(e) {
			let t = L(e.target);
			!t || m(e.relatedTarget) && t.contains(e.relatedTarget) || (E === t && !(M === "mouse" && t.matches(":hover")) && (E = null), J(t, !0));
		}
		function _e(e) {
			if (M = "keyboard", e.key === "Escape") {
				w && (E = w), U();
				return;
			}
			![
				"Alt",
				"Backspace",
				"Delete",
				"ArrowDown",
				"End",
				"Home",
				"Insert",
				"ArrowLeft",
				"PageDown",
				"PageUp",
				"ArrowRight",
				" ",
				"ArrowUp"
			].includes(e.key) && w && U();
		}
		function Z() {
			U(), E = null;
		}
		function Q() {
			f().hidden && Z();
		}
		let $ = {
			pointerover: de,
			pointermove: Y,
			pointerout: fe,
			pointerdown: pe,
			pointercancel: X,
			lostpointercapture: X,
			pointerup: me,
			keydown: _e,
			focusin: he,
			focusout: ge
		};
		ne(() => {
			let e = f(), t = p();
			e.querySelectorAll(u).forEach(R), D = new t.MutationObserver((e) => e.forEach((e) => {
				e.type === "attributes" && h(e.target) && (e.attributeName === l && R(e.target), w && (e.target === w || e.target.contains(w)) && (I(w) ? (W(w), F(w)?.UpdatePosition()) : U())), e.addedNodes.forEach(le), e.removedNodes.forEach(ue);
			})), D.observe(e.body, {
				attributes: !0,
				attributeFilter: [
					l,
					ie,
					ae,
					"class",
					"disabled",
					"aria-disabled"
				],
				childList: !0,
				subtree: !0
			});
			for (let [t, n] of Object.entries($)) e.addEventListener(t, n, !0);
			t.addEventListener("blur", Z), e.addEventListener("visibilitychange", Q);
		}), te(() => {
			let e = f(), t = p();
			D?.disconnect(), U(), S.forEach(z);
			for (let [t, n] of Object.entries($)) e.removeEventListener(t, n, !0);
			t.removeEventListener("blur", Z), e.removeEventListener("visibilitychange", Q);
		});
		let ve = {
			TOOLTIP: l,
			PLACEMENT: ie,
			TARGET: ae,
			SELECTOR: u,
			HOVER: 400,
			BETWEEN: 200,
			CLOSE: 167,
			DURATION: oe,
			ServiceContent: d,
			hostRef: se,
			ownerDocument: f,
			ownerWindow: p,
			isNode: m,
			isHTMLElement: h,
			fallbackRef: g,
			owner: _,
			mode: v,
			point: y,
			theme: b,
			originalTitles: x,
			attached: S,
			describedBy: C,
			get active() {
				return w;
			},
			set active(e) {
				w = e;
			},
			get pending() {
				return T;
			},
			set pending(e) {
				T = e;
			},
			get suppressed() {
				return E;
			},
			set suppressed(e) {
				E = e;
			},
			get observer() {
				return D;
			},
			set observer(e) {
				D = e;
			},
			get openTimer() {
				return O;
			},
			set openTimer(e) {
				O = e;
			},
			get closeTimer() {
				return k;
			},
			set closeTimer(e) {
				k = e;
			},
			get touchTimer() {
				return A;
			},
			set touchTimer(e) {
				A = e;
			},
			get lastClosed() {
				return j;
			},
			set lastClosed(e) {
				j = e;
			},
			get inputMode() {
				return M;
			},
			set inputMode(e) {
				M = e;
			},
			get lastPoint() {
				return N;
			},
			set lastPoint(e) {
				N = e;
			},
			get openSequence() {
				return P;
			},
			set openSequence(e) {
				P = e;
			},
			controller: F,
			canOpen: I,
			findOwner: L,
			syncTitle: R,
			restoreTitle: z,
			clearOpen: B,
			clearClose: V,
			clearTouch: H,
			restoreDescription: ce,
			closeActive: U,
			syncTheme: W,
			openActive: G,
			queueOpen: K,
			inSafeZone: q,
			queueClose: J,
			scan: le,
			release: ue,
			onPointerOver: de,
			onPointerMove: Y,
			onPointerOut: fe,
			onPointerDown: pe,
			onPointerCanceled: X,
			onPointerReleased: me,
			onFocusIn: he,
			onFocusOut: ge,
			onKeyDown: _e,
			onBlur: Z,
			onVisibilityChanged: Q,
			listeners: $,
			ToolTip: a
		};
		return Object.defineProperty(ve, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), ve;
	}
});
//#endregion
export { l as default };

//# sourceMappingURL=ToolTipService.vue_vue_type_script_setup_true_lang.js.map