import { alignment as e, cssLength as t, xamlThickness as n } from "./layout.js";
import { resolveXamlHandler as r, resolveXamlValue as ee } from "./xamlRuntime.js";
import { RefreshContainerContent as i, RefreshContainerVisualizer as te, getRefreshContainerProperty as ne, refreshChildren as re, refreshNodes as ie } from "./RefreshProperties.js";
import { DEFAULT_EXECUTION_RATIO as ae, createRefreshContext as oe, isFarPull as a, isVerticalPull as se, raiseRefreshRequested as ce, refreshContextKey as le } from "./refreshRuntime.js";
import ue from "./RefreshVisualizer.vue.js";
import { Fragment as o, cloneVNode as s, computed as c, defineComponent as l, getCurrentInstance as de, h as u, isVNode as d, nextTick as f, onBeforeUnmount as fe, onMounted as pe, provide as me, ref as p, useAttrs as he, useSlots as ge, watch as m } from "vue";
var _e = /*@__PURE__*/ l({
	Visualizer: te,
	Content: i,
	inheritAttrs: !1,
	__name: "RefreshContainer",
	props: {
		Visualizer: {
			type: [String, Object],
			default: ""
		},
		Content: {
			type: [
				String,
				Number,
				Object
			],
			default: ""
		},
		PullDirection: {
			type: String,
			default: "TopToBottom"
		},
		Width: {
			type: [String, Number],
			default: ""
		},
		Height: {
			type: [String, Number],
			default: ""
		},
		MinWidth: {
			type: [String, Number],
			default: ""
		},
		MinHeight: {
			type: [String, Number],
			default: ""
		},
		MaxWidth: {
			type: [String, Number],
			default: ""
		},
		MaxHeight: {
			type: [String, Number],
			default: ""
		},
		Margin: {
			type: [String, Number],
			default: ""
		},
		Padding: {
			type: [String, Number],
			default: ""
		},
		HorizontalAlignment: {
			type: String,
			default: "Stretch"
		},
		VerticalAlignment: {
			type: String,
			default: "Stretch"
		},
		HorizontalContentAlignment: {
			type: String,
			default: "Left"
		},
		VerticalContentAlignment: {
			type: String,
			default: "Top"
		},
		Background: {
			type: String,
			default: "{ThemeResource RefreshContainerBackgroundBrush}"
		},
		Foreground: {
			type: String,
			default: "{ThemeResource RefreshContainerForegroundBrush}"
		},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		Visibility: {
			type: String,
			default: "Visible"
		}
	},
	emits: ["RefreshRequested"],
	setup(i, { expose: te, emit: _e }) {
		let h = i, ve = _e, g = de(), _ = he(), ye = c(() => {
			let { RefreshRequested: e, ...t } = _;
			return t;
		}), v = ge(), y = p(null), b = p(null), x = (e) => ee(e, g), S = c(() => {
			let e = x(h.PullDirection);
			return e === "BottomToTop" || e === "LeftToRight" || e === "RightToLeft" ? e : "TopToBottom";
		}), C = oe({
			pullDirection: S.value,
			executionRatio: ae
		});
		me(le, C);
		let w = c(() => se(C.pullDirection)), T = c(() => a(C.pullDirection) ? -1 : 1), E = c(() => ![
			!1,
			"False",
			"false"
		].includes(x(h.IsEnabled))), D = p(!1), O = p(null), k = p(0), A = 0, j = 0, M = !1, N = !1, P = null, F = "", I = "", L = c(() => ie(v.default?.() ?? [])), R = (e) => {
			let t = L.value.find((t) => ne(t) === e);
			return t ? re(t) : [];
		}, be = l({ setup() {
			return () => {
				let t = R("content"), n = t.length ? t : L.value.filter((e) => !ne(e));
				if (n.length) return u(o, n.map((t) => s(t, { style: {
					justifySelf: t.props?.HorizontalAlignment ? e(x(t.props.HorizontalAlignment), "horizontal") : void 0,
					alignSelf: t.props?.VerticalAlignment ? e(x(t.props.VerticalAlignment), "vertical") : void 0
				} })));
				let r = x(h.Content);
				return d(r) ? s(r) : typeof r == "string" || typeof r == "number" ? r : null;
			};
		} }), xe = l({ setup() {
			return () => {
				let e = R("visualizer");
				if (e.length) return u(o, e);
				let t = x(h.Visualizer);
				return d(t) ? s(t) : u(ue, { ref: b });
			};
		} });
		C.containerRefreshRequested = (e) => {
			let t = e.GetDeferral();
			ce((e) => {
				ve("RefreshRequested", $, e), r(_.RefreshRequested, g)?.($, e);
			}, () => t.Complete());
		}, C.containerStateChanged = (e, t) => {
			t === "Idle" && O.value === null && (k.value = 0);
		};
		let z = c(() => C.visualizerSize || 100), Se = c(() => T.value * (C.state === "Refreshing" ? z.value * C.executionRatio : Math.min(z.value, k.value))), Ce = c(() => T.value * (C.state === "Refreshing" ? -z.value * (1 - C.executionRatio) : -z.value + Math.min(z.value, k.value))), B = (e) => w.value ? `translateY(${e}px)` : `translateX(${e}px)`, V = c(() => O.value === null ? "transform 100ms cubic-bezier(0.5, 0, 0, 1)" : "none"), we = c(() => ({
			transform: B(Se.value),
			transition: V.value,
			justifyItems: e(x(h.HorizontalContentAlignment), "horizontal"),
			alignItems: e(x(h.VerticalContentAlignment), "vertical")
		})), Te = c(() => ({
			transform: B(Ce.value),
			transition: V.value,
			...w.value ? {
				left: "0",
				right: "0",
				[a(C.pullDirection) ? "bottom" : "top"]: "0"
			} : {
				top: "0",
				bottom: "0",
				[a(C.pullDirection) ? "right" : "left"]: "0"
			}
		})), Ee = c(() => {
			let r = {
				background: x(h.Background),
				color: x(h.Foreground),
				justifySelf: e(x(h.HorizontalAlignment), "horizontal"),
				alignSelf: e(x(h.VerticalAlignment), "vertical"),
				margin: n(x(h.Margin)),
				padding: n(x(h.Padding)),
				touchAction: E.value && D.value ? {
					TopToBottom: "pan-x pan-down",
					BottomToTop: "pan-x pan-up",
					LeftToRight: "pan-y pan-right",
					RightToLeft: "pan-y pan-left"
				}[C.pullDirection] : "pan-x pan-y"
			};
			for (let e of [
				"Width",
				"Height",
				"MinWidth",
				"MinHeight",
				"MaxWidth",
				"MaxHeight"
			]) {
				let n = t(x(h[e]));
				n && (r[e[0].toLowerCase() + e.slice(1)] = n);
			}
			return x(h.Visibility) === "Collapsed" && (r.display = "none"), x(h.Visibility) === "Hidden" && (r.visibility = "hidden"), r;
		}), H = () => y.value?.querySelector(".win-scroll-viewer-viewport, .win-scroll-presenter") ?? null, U = (e) => w.value ? e.scrollTop : e.scrollLeft, W = (e) => {
			let t = U(e), n = w.value ? e.scrollHeight - e.clientHeight : e.scrollWidth - e.clientWidth;
			return a(C.pullDirection) ? t >= Math.max(0, n) - 1 : t < 1;
		}, G = () => {
			let e = H();
			D.value = !!(e && W(e)), e && (P !== e && (P && (P.style.touchAction = F, P.style.overscrollBehavior = I), P = e, F = e.style.touchAction, I = e.style.overscrollBehavior), e.style.touchAction = String(Ee.value.touchAction), e.style.overscrollBehavior = "contain"), O.value !== null && e && Math.abs(U(e) - j) >= 1 && Y();
		}, K = () => C.publishInteractionRatio(Math.min(1, k.value / z.value)), q = (e) => {
			M !== e && (M = e, C.publishIsInteractingForRefresh(e));
		}, J = (e) => {
			e !== null && y.value?.hasPointerCapture?.(e) && y.value.releasePointerCapture(e);
		}, Y = (e) => {
			if (e && O.value !== e.pointerId) return;
			let t = O.value;
			O.value = null, k.value = 0, K(), q(!1), J(t);
		}, De = (e) => {
			if (O.value !== null) {
				O.value !== e.pointerId && Y();
				return;
			}
			if (!E.value || e.pointerType !== "touch" || !e.isPrimary || e.button > 0 || C.state === "Refreshing") return;
			let t = H();
			!t || !W(t) || !(e.target instanceof Node) || !t.contains(e.target) || (O.value = e.pointerId, A = w.value ? e.clientY : e.clientX, j = U(t), k.value = 0, K(), q(!0));
		}, Oe = (e) => {
			if (O.value !== e.pointerId) return;
			let t = H();
			if (!t || !W(t) || Math.abs(U(t) - j) >= 1) {
				Y();
				return;
			}
			let n = T.value * ((w.value ? e.clientY : e.clientX) - A);
			k.value = Math.max(0, n), n > 0 && (e.preventDefault(), y.value?.setPointerCapture?.(e.pointerId)), K();
		}, ke = (e) => {
			O.value === e.pointerId && (O.value = null, q(!1), k.value = 0, C.state !== "Refreshing" && K(), J(e.pointerId));
		}, Ae = (e) => {
			e.target === y.value && O.value === e.pointerId && Y(e);
		}, X = () => Y(), Z = () => {
			document.hidden && Y();
		}, je = () => {
			N || C.state === "Refreshing" || (Y(), C.visualizerHandle?.RequestRefresh());
		};
		m(S, (e) => {
			Y(), C.pullDirection = e, C.visualizerHandle?.setInternalPullDirection(e), f(G);
		}), m(E, (e) => {
			e || Y(), f(G);
		});
		let Q;
		pe(() => {
			G(), typeof ResizeObserver == "function" && (Q = new ResizeObserver(G), y.value && Q.observe(y.value)), window.addEventListener("blur", X), document.addEventListener("visibilitychange", Z);
		}), fe(() => {
			N = !0, Y(), Q?.disconnect(), P && (P.style.touchAction = F, P.style.overscrollBehavior = I), C.containerRefreshRequested = null, C.containerStateChanged = null, window.removeEventListener("blur", X), document.removeEventListener("visibilitychange", Z);
		});
		let $ = {
			RequestRefresh: je,
			get Visualizer() {
				return C.visualizerHandle?.publicInstance ?? b.value;
			}
		};
		te($);
		let Me = {
			props: h,
			emit: ve,
			instance: g,
			attrs: _,
			rootAttrs: ye,
			slots: v,
			rootRef: y,
			visualizerRef: b,
			value: x,
			direction: S,
			context: C,
			vertical: w,
			sign: T,
			enabled: E,
			atBoundary: D,
			activePointerId: O,
			pullDistance: k,
			get pointerStart() {
				return A;
			},
			set pointerStart(e) {
				A = e;
			},
			get initialScrollOffset() {
				return j;
			},
			set initialScrollOffset(e) {
				j = e;
			},
			get interacting() {
				return M;
			},
			set interacting(e) {
				M = e;
			},
			get disposed() {
				return N;
			},
			set disposed(e) {
				N = e;
			},
			get adaptedViewport() {
				return P;
			},
			set adaptedViewport(e) {
				P = e;
			},
			get previousTouchAction() {
				return F;
			},
			set previousTouchAction(e) {
				F = e;
			},
			get previousOverscrollBehavior() {
				return I;
			},
			set previousOverscrollBehavior(e) {
				I = e;
			},
			nodes: L,
			propertyNodes: R,
			ContentOutlet: be,
			VisualizerOutlet: xe,
			size: z,
			contentOffset: Se,
			visualizerOffset: Ce,
			transform: B,
			transition: V,
			contentPresenterStyle: we,
			visualizerPresenterStyle: Te,
			rootStyle: Ee,
			viewport: H,
			offset: U,
			withinBoundary: W,
			updateScrollBoundary: G,
			publishRatio: K,
			setInteracting: q,
			releaseCapture: J,
			cancelGesture: Y,
			onPointerDown: De,
			onPointerMove: Oe,
			onPointerUp: ke,
			onLostPointerCapture: Ae,
			onWindowBlur: X,
			onVisibilityChanged: Z,
			RequestRefresh: je,
			get resizeObserver() {
				return Q;
			},
			set resizeObserver(e) {
				Q = e;
			},
			publicApi: $
		};
		return Object.defineProperty(Me, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), Me;
	}
});
//#endregion
export { _e as default };

//# sourceMappingURL=RefreshContainer.vue_vue_type_script_setup_true_lang.js.map