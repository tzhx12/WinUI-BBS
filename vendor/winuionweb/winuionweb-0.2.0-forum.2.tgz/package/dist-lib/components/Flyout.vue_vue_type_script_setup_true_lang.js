import { cssLength as e, xamlThickness as t } from "./layout.js";
import { xamlThemeKey as n } from "./brushCore.js";
import { useAcrylicBrushStyle as r } from "./AcrylicBrush.js";
import { normalizeXamlNodes as i, resolveXamlHandler as a, resolveXamlResourceObject as o, resolveXamlValue as ee, updateXamlBinding as te, xamlScopeKey as ne } from "./xamlRuntime.js";
import { vAcrylicBrush as re } from "./acrylicBrushVisual.js";
import { vThemeShadow as ie } from "./themeShadowVisual.js";
import { fitPopupPosition as ae, popupBoundsFor as oe, popupPlacementPosition as se, resolvePopupElement as ce } from "./popupRuntime.js";
import { flyoutContainsNode as le, flyoutInputContextKey as ue, hasOpenDescendantFlyout as de, hideDescendantFlyouts as fe, isDescendantFlyoutOpening as pe, nestedFlyoutLayers as me, registerFlyoutInputRegion as he } from "./flyoutInput.js";
import ge from "./ScrollViewer.vue.js";
import { Fragment as _e, computed as s, defineComponent as c, getCurrentInstance as ve, h as ye, inject as l, isVNode as be, nextTick as xe, onBeforeUnmount as Se, onMounted as Ce, onUpdated as we, provide as Te, ref as u, shallowReactive as Ee, shallowRef as De, unref as Oe, useAttrs as ke, useSlots as Ae, watch as je } from "vue";
//#region src/components/Flyout.vue?vue&type=script&setup=true&lang.ts
var Me = c({
	name: "Flyout.Content",
	__flyoutProperty: "Content",
	setup() {
		return () => null;
	}
}), Ne = c({
	name: "Flyout.FlyoutPresenterStyle",
	__flyoutProperty: "FlyoutPresenterStyle",
	setup() {
		return () => null;
	}
}), Pe = /*@__PURE__*/ c({
	Content: Me,
	FlyoutPresenterStyle: Ne,
	name: "Flyout",
	inheritAttrs: !1,
	__name: "Flyout",
	props: {
		Content: {
			type: null,
			default: void 0
		},
		Placement: {
			type: String,
			default: "Top"
		},
		ShowMode: {
			type: String,
			default: "Standard"
		},
		LightDismissOverlayMode: {
			type: String,
			default: "Auto"
		},
		AreOpenCloseAnimationsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		ShouldConstrainToRootBounds: {
			type: [Boolean, String],
			default: !0
		},
		AllowFocusOnInteraction: {
			type: [Boolean, String],
			default: !0
		},
		AllowFocusWhenDisabled: {
			type: [Boolean, String],
			default: !1
		},
		FlyoutPresenterStyle: {
			type: null,
			default: void 0
		}
	},
	emits: [
		"Opening",
		"Opened",
		"Closing",
		"Closed",
		"update:Content",
		"update:Placement",
		"update:ShowMode",
		"update:LightDismissOverlayMode",
		"update:AreOpenCloseAnimationsEnabled",
		"update:ShouldConstrainToRootBounds",
		"update:AllowFocusOnInteraction",
		"update:AllowFocusWhenDisabled",
		"update:FlyoutPresenterStyle"
	],
	setup(Pe, { expose: Fe, emit: Ie }) {
		let d = Pe, Le = Ie, f = ve(), Re = ke(), ze = Ae(), p = (e) => ee(e, f), m = Ee({}), h = (e) => e in m, g = (e) => h(e) ? m[e] : p(d[e]), Be = (e) => s({
			get: () => g(e),
			set: (t) => {
				m[e] = t, te(d[e], t, f), Le(`update:${e}`, t);
			}
		}), Ve = Object.fromEntries(Object.keys(d).filter((e) => e !== "Content").map((e) => [e, Be(e)]));
		for (let e of Object.keys(d)) je(() => p(d[e]), () => {
			delete m[e];
		});
		let _ = (e) => p(e) !== !1 && p(e) !== "False", He = u(null), v = u(null), Ue = u(null), We = u(null), y = document.createElement("div");
		y.className = "flyout-content-host", y.style.display = "none";
		let b = l("buttonFlyoutAnchor", null), x = l("buttonFlyoutController", null), Ge = l(n, null) ?? l("winuiTheme", null), S = u(!1), Ke = u(!1), C = u(!1), w = u(null), T = typeof document > "u" ? null : document.createElement("div");
		T && (T.className = "flyout-portal-host");
		let qe = T || "body", E = u("Top"), D = u(null), O = u({
			left: 0,
			top: 0,
			right: 0,
			bottom: 0,
			width: 0,
			height: 0
		}), k = u({
			left: 0,
			top: 0
		}), A = u(null), j = s(() => String(D.value?.ShowMode || g("ShowMode") || "Standard") === "Auto" ? "Standard" : String(D.value?.ShowMode || g("ShowMode") || "Standard")), Je = s(() => String(g("LightDismissOverlayMode")) === "On"), Ye = s(() => String(p(Re["AutomationProperties.Name"]) ?? "")), Xe = u(0), M = s(() => {
			Xe.value;
			let e = String(Oe(Ge) || "").toLowerCase(), t = w.value?.closest("[data-theme], .win-theme-scope, .example-theme-wrapper, .theme-light, .theme-dark"), n = t?.getAttribute("data-theme")?.toLowerCase();
			return n === "light" || n === "dark" ? n : t?.classList.contains("theme-dark") ? "dark" : t?.classList.contains("theme-light") ? "light" : e;
		});
		Te(n, M);
		let Ze = s(() => M.value === "light" || M.value === "dark" ? `win-theme-scope theme-${M.value}` : ""), Qe = s(() => ({
			left: `${O.value.left}px`,
			top: `${O.value.top}px`,
			width: `${O.value.width}px`,
			height: `${O.value.height}px`,
			zIndex: A.value?.overlay
		})), $e = (e) => Array.isArray(e.children) ? e.children : e.children?.default?.() ?? [], et = De([]), N = s(() => {
			let e = et.value.find((e) => e.type?.__flyoutProperty === "FlyoutPresenterStyle"), t = {};
			if (e && !h("FlyoutPresenterStyle")) {
				for (let n of $e(e)) for (let e of $e(n)) typeof e.props?.Property == "string" && (t[e.props.Property] = p(e.props.Value));
				return t;
			}
			let n = h("FlyoutPresenterStyle") ? m.FlyoutPresenterStyle : d.FlyoutPresenterStyle, r = typeof n == "string" ? n.match(/^\{(?:StaticResource|ThemeResource)\s+([^}]+)\}$/)?.[1] : "", i = r ? o(r, f) : p(n);
			if (!i || typeof i != "object") return t;
			let a = i;
			return Array.isArray(a.Setters) ? Object.fromEntries(a.Setters.map((e) => [e.Property, p(e.Value)])) : i;
		}), tt = s(() => ({
			HorizontalScrollMode: N.value["ScrollViewer.HorizontalScrollMode"] ?? "Auto",
			HorizontalScrollBarVisibility: N.value["ScrollViewer.HorizontalScrollBarVisibility"] ?? "Auto",
			VerticalScrollMode: N.value["ScrollViewer.VerticalScrollMode"] ?? "Auto",
			VerticalScrollBarVisibility: N.value["ScrollViewer.VerticalScrollBarVisibility"] ?? "Auto"
		})), nt = l(ne, {});
		Te(ne, {
			...nt,
			ScrollSettings: tt
		});
		let rt = c({
			name: "FlyoutPresenterOutlet",
			setup(e, { slots: t }) {
				let n = ve();
				return () => ye(_e, i(t.default?.() ?? [], n));
			}
		}), it = s(() => ({
			margin: N.value.Padding === void 0 ? void 0 : t(N.value.Padding),
			display: "flex",
			flexDirection: "column",
			alignItems: {
				Left: "flex-start",
				Center: "center",
				Right: "flex-end",
				Stretch: "stretch"
			}[String(N.value.HorizontalContentAlignment ?? "Stretch")],
			justifyContent: {
				Top: "flex-start",
				Center: "center",
				Bottom: "flex-end",
				Stretch: "flex-start"
			}[String(N.value.VerticalContentAlignment ?? "Stretch")]
		})), at = r(() => N.value.Background ?? "{ThemeResource FlyoutPresenterBackground}", f), ot = s(() => {
			let n = {
				...at.value,
				left: `${k.value.left}px`,
				top: `${k.value.top}px`,
				zIndex: A.value?.presenter,
				"--flyout-available-width": `${Math.max(0, O.value.width - 8)}px`,
				"--flyout-available-height": `${Math.max(0, O.value.height - 8)}px`,
				width: E.value === "Full" ? `${Math.max(0, O.value.width - 8)}px` : void 0,
				height: E.value === "Full" ? `${Math.max(0, O.value.height - 8)}px` : void 0
			}, r = N.value;
			r.Margin !== void 0 && (n.margin = t(p(r.Margin)));
			for (let [e, t] of Object.entries({
				Foreground: "color",
				BorderBrush: "borderColor"
			})) r[e] !== void 0 && (n[t] = p(r[e]));
			r.BorderThickness !== void 0 && (n.borderWidth = t(r.BorderThickness)), r.CornerRadius !== void 0 && (n.borderRadius = e(r.CornerRadius));
			for (let t of [
				"Width",
				"Height",
				"MinWidth",
				"MinHeight",
				"MaxWidth",
				"MaxHeight"
			]) {
				if (r[t] === void 0) continue;
				let i = t[0].toLowerCase() + t.slice(1), a = e(p(r[t]));
				n[i] = t.includes("Width") ? `min(${a}, var(--flyout-available-width))` : `min(${a}, var(--flyout-available-height))`;
			}
			return n;
		}), st = s(() => {
			if (h("Content") || d.Content !== void 0) {
				let e = g("Content");
				return be(e) ? i([e], f) : [];
			}
			let e = et.value, t = e.find((e) => e.type?.__flyoutProperty === "Content")?.children?.default;
			return i(t ? t() : e.filter((e) => !e.type?.__flyoutProperty), f);
		}), ct = c({
			name: "FlyoutContentPresenterOutlet",
			setup() {
				return () => (et.value = ze.default?.() ?? [], st.value.length ? ye(_e, st.value) : ye(_e, typeof g("Content") == "string" || typeof g("Content") == "number" ? [String(g("Content"))] : []));
			}
		}), lt = De(null), P = null, ut = () => {
			let e = y.querySelector(".flyout-content-presenter");
			if (!e) return;
			let t = g("Content"), n = ce(t);
			P && P !== n && P.parentElement === e && P.remove(), P = n, n && n.parentElement !== e && e.appendChild(n), lt.value = h("Content") || d.Content !== void 0 ? t : e.firstElementChild;
		}, dt = s({
			get: () => h("Content") || d.Content !== void 0 ? g("Content") : lt.value,
			set: (e) => {
				if (e !== null && !be(e) && !ce(e)) throw TypeError("Flyout.Content must be a UIElement or null");
				m.Content = e, te(d.Content, e, f), Le("update:Content", e);
			}
		}), ft = () => {
			let e = We.value || T;
			e && y.parentElement !== e && e.appendChild(y), y.style.display = We.value ? "contents" : "none", ut();
		}, F = 0, I = [], L = null, R = null, z = null, B = null, V = null, H = !1, U = !1, W = !1, G = !1, K = null, pt = /* @__PURE__ */ new WeakSet(), mt = (e) => {
			if (e.pointerType !== "mouse") return;
			let t = K?.pointerId === e.pointerId ? K.x !== e.clientX || K.y !== e.clientY : e.movementX !== 0 || e.movementY !== 0;
			K = {
				pointerId: e.pointerId,
				x: e.clientX,
				y: e.clientY
			}, e.type === "pointermove" && t && (pt.add(e), U || (G = !1));
		};
		Te(ue, { allowsHover: (e) => e.pointerType !== "touch" && (e.pointerType !== "mouse" || pt.has(e) || !U && !G) });
		let q = {
			ShowAt: xt,
			Hide: Z,
			get IsOpen() {
				return S.value;
			},
			get Target() {
				return w.value;
			}
		};
		Object.defineProperty(q, "Content", {
			enumerable: !0,
			get: () => dt.value,
			set: (e) => {
				dt.value = e;
			}
		});
		for (let [e, t] of Object.entries(Ve)) Object.defineProperty(q, e, {
			enumerable: !0,
			get: () => t.value,
			set: (e) => {
				t.value = e;
			}
		});
		Object.defineProperty(q, "IsConstrainedToRootBounds", {
			enumerable: !0,
			get: () => _(g("ShouldConstrainToRootBounds"))
		});
		let J = {
			Owner: q,
			get IsOpen() {
				return S.value;
			},
			get Target() {
				return w.value;
			},
			get Presenter() {
				return v.value;
			},
			get DismissLayer() {
				return Ue.value;
			},
			Hide: Z
		}, ht = he(J), Y = (e, t = {}) => {
			let n = f?.vnode.props?.[`on${e}`];
			for (let e of Array.isArray(n) ? n : n ? [n] : []) typeof e == "function" && e(q, t);
			a(Re[e], f)?.(q, t);
		}, gt = (e) => {
			S.value = e;
		}, X = () => {
			for (let e of I) e.cancel();
			I = [];
		}, _t = (e, t) => {
			let n = v.value;
			if (!n || !_(g("AreOpenCloseAnimationsEnabled")) || window.matchMedia("(prefers-reduced-motion: reduce)").matches || typeof n.animate != "function") return Promise.resolve();
			let r = E.value.startsWith("Top") ? "0, 50px" : E.value.startsWith("Bottom") ? "0, -50px" : E.value.startsWith("Left") ? "50px, 0" : E.value.startsWith("Right") ? "-50px, 0" : "0, 0";
			e && (W = r !== "0, 0");
			let i = getComputedStyle(n);
			return I = [n.animate(e ? [{ opacity: 0 }, { opacity: 1 }] : [{ opacity: t?.opacity ?? i.opacity }, { opacity: 0 }], {
				duration: 83,
				easing: "linear",
				fill: "both"
			})], e ? I.push(n.animate([{ transform: `translate(${r})` }, { transform: "translate(0, 0)" }], {
				duration: 333,
				easing: "cubic-bezier(0.1, 0.9, 0.2, 1)",
				fill: "both"
			})) : t?.transform && t.transform !== "none" && I.push(n.animate([{ transform: t.transform }, { transform: t.transform }], {
				duration: 83,
				fill: "both"
			})), Promise.all(I.map((e) => e.finished.catch(() => void 0))).then(() => void 0);
		}, vt = async () => {
			let e = v.value, t = w.value || b?.value || He.value?.parentElement;
			if (!e || !t) return;
			O.value = oe(t, _(g("ShouldConstrainToRootBounds"))), await xe();
			let n = e.offsetWidth, r = e.offsetHeight, i = D.value?.Placement || String(g("Placement") || "Top"), a = se(t.getBoundingClientRect(), {
				width: n,
				height: r
			}, i, O.value, 4, getComputedStyle(t).direction === "rtl"), o = D.value?.Position, ee = t.getBoundingClientRect();
			k.value = o ? ae({
				left: ee.left + Number(o.X ?? o.x ?? 0),
				top: ee.top + Number(o.Y ?? o.y ?? 0)
			}, {
				width: n,
				height: r
			}, O.value) : {
				left: a.left,
				top: a.top
			}, E.value = a.placement, C.value = !0;
		}, yt = () => Array.from(v.value?.querySelectorAll("button:not(:disabled), input:not(:disabled), select:not(:disabled), textarea:not(:disabled), a[href], [tabindex]:not([tabindex=\"-1\"])") ?? []).filter((e) => e.getClientRects().length > 0 && !e.closest("[inert]")), bt = () => {
			R?.disconnect();
			let e = w.value?.closest("[data-theme], .win-theme-scope, .example-theme-wrapper, .theme-light, .theme-dark");
			e && R?.observe(e, {
				attributes: !0,
				attributeFilter: ["class", "data-theme"]
			}), e !== document.documentElement && R?.observe(document.documentElement, {
				attributes: !0,
				attributeFilter: ["class", "data-theme"]
			}), Xe.value += 1;
		};
		async function xt(e, t) {
			let n = ce(e) || b?.value || He.value?.parentElement || null;
			if (!n || H) return;
			if (S.value) {
				w.value = n, bt(), D.value = t ?? null, await vt();
				return;
			}
			let r = ++F;
			if (X(), U = !0, W = !1, G = !0, B = document.activeElement instanceof HTMLElement ? document.activeElement : null, w.value = n, A.value = me(J), $(), T?.parentElement?.appendChild(T), window.dispatchEvent(new CustomEvent("winui-flyout-opening", { detail: q })), bt(), D.value = t ?? null, Y("Opening"), gt(!0), C.value = !1, Ke.value = !0, await xe(), ft(), await vt(), r !== F || !S.value || H) return;
			L?.disconnect(), v.value && L?.observe(v.value), L?.observe(n), j.value === "Standard" && _(g("AllowFocusOnInteraction")) && (yt()[0] || v.value)?.focus({ preventScroll: !0 });
			let i = _t(!0);
			Y("Opened"), await i, r === F && (U = !1, W || (G = !1), X());
		}
		function Z(e = !0) {
			if (!S.value) return;
			let t = { Cancel: !1 };
			if (Y("Closing", t), t.Cancel) return;
			let n = le(J, document.activeElement);
			fe(J);
			let r = ++F;
			U = !1, G = !1;
			let i = v.value ? getComputedStyle(v.value) : null, a = i ? {
				opacity: i.opacity,
				transform: i.transform
			} : void 0;
			X(), gt(!1), L?.disconnect();
			let o = B?.isConnected ? B : w.value;
			e && n && o?.isConnected && o.focus({ preventScroll: !0 }), _t(!1, a).then(() => {
				r !== F || S.value || H || (X(), T && T.appendChild(y), y.style.display = "none", Ke.value = !1, C.value = !1, Y("Closed"));
			});
		}
		let St = (e) => {
			e.preventDefault(), Z();
		}, Ct = () => {
			xt(b?.value);
		}, wt = (e) => {
			let t = e.detail;
			t !== q && !pe(t, J) && Z();
		}, Q = () => {
			!S.value || z !== null || (z = requestAnimationFrame(() => {
				z = null, S.value && vt();
			}));
		}, Tt = (e) => {
			mt(e), S.value && !le(J, e.target) && !w.value?.contains(e.target) && (j.value === "Standard" && e.preventDefault(), Z());
		}, Et = (e) => {
			if (mt(e), !S.value || j.value !== "TransientWithDismissOnPointerMoveAway" || de(J)) return;
			let t = v.value?.getBoundingClientRect(), n = w.value?.getBoundingClientRect();
			!t || !n || (e.clientX < Math.min(t.left, n.left) - 40 || e.clientX > Math.max(t.right, n.right) + 40 || e.clientY < Math.min(t.top, n.top) - 40 || e.clientY > Math.max(t.bottom, n.bottom) + 40) && Z();
		}, Dt = (e) => {
			if (!S.value || de(J)) return;
			if (e.key === "Escape") {
				e.preventDefault(), e.stopPropagation(), Z();
				return;
			}
			if (e.key !== "Tab" || j.value !== "Standard") return;
			let t = yt(), n = t[0], r = t[t.length - 1];
			n ? e.shiftKey && (document.activeElement === n || !v.value?.contains(document.activeElement)) ? (e.preventDefault(), r.focus({ preventScroll: !0 })) : !e.shiftKey && (document.activeElement === r || !v.value?.contains(document.activeElement)) && (e.preventDefault(), n.focus({ preventScroll: !0 })) : (e.preventDefault(), v.value?.focus({ preventScroll: !0 }));
		}, Ot = () => Z(), $ = () => {
			if (!T) return;
			let e = document.fullscreenElement || document.body;
			T.parentElement !== e && !T.contains(e) && e.appendChild(T);
		}, kt = () => {
			$(), Q();
		};
		je(() => g("Content"), async () => {
			await xe(), ut(), Q();
		}, { flush: "post" }), we(ft), Ce(() => {
			$(), ft(), je(() => [
				g("Placement"),
				g("ShowMode"),
				g("ShouldConstrainToRootBounds"),
				N.value
			], Q), L = new ResizeObserver(Q), R = new MutationObserver(() => {
				Xe.value += 1;
			}), x && (x.value = q), V = b?.value ?? null, V?.addEventListener("click", Ct), window.addEventListener("resize", Q), window.addEventListener("scroll", Q, !0), window.addEventListener("blur", Ot), window.addEventListener("winui-flyout-opening", wt), document.addEventListener("pointerdown", Tt, !0), document.addEventListener("pointermove", Et, !0), document.addEventListener("keydown", Dt, !0), document.addEventListener("fullscreenchange", kt);
		}), Se(() => {
			fe(J), ht(), H = !0, U = !1, G = !1, K = null, F += 1, X(), L?.disconnect(), R?.disconnect(), z !== null && cancelAnimationFrame(z), x?.value === q && (x.value = null), V?.removeEventListener("click", Ct), window.removeEventListener("resize", Q), window.removeEventListener("scroll", Q, !0), window.removeEventListener("blur", Ot), window.removeEventListener("winui-flyout-opening", wt), document.removeEventListener("pointerdown", Tt, !0), document.removeEventListener("pointermove", Et, !0), document.removeEventListener("keydown", Dt, !0), document.removeEventListener("fullscreenchange", kt), T?.remove();
		}), Fe({
			...Ve,
			Content: dt,
			ShowAt: xt,
			Hide: Z,
			IsOpen: s(() => S.value),
			Target: s(() => w.value),
			IsConstrainedToRootBounds: s(() => _(g("ShouldConstrainToRootBounds")))
		});
		let At = {
			FlyoutContent: Me,
			FlyoutPresenterStyle: Ne,
			props: d,
			emit: Le,
			instance: f,
			attrs: Re,
			slots: ze,
			resolve: p,
			overrides: m,
			hasOverride: h,
			propertyValue: g,
			dependencyProperty: Be,
			exposedProperties: Ve,
			enabled: _,
			anchorRef: He,
			presenterRef: v,
			dismissLayerRef: Ue,
			contentMountRef: We,
			contentHost: y,
			buttonAnchor: b,
			buttonController: x,
			inheritedTheme: Ge,
			isOpen: S,
			isPresent: Ke,
			isPositioned: C,
			target: w,
			portalHost: T,
			teleportTarget: qe,
			placement: E,
			showOptions: D,
			bounds: O,
			position: k,
			nestedLayers: A,
			showMode: j,
			overlayVisible: Je,
			automationName: Ye,
			themeRevision: Xe,
			effectiveTheme: M,
			themeClass: Ze,
			boundsStyle: Qe,
			childrenOf: $e,
			propertyNodes: et,
			presenterSetters: N,
			scrollSettings: tt,
			inheritedTemplateScope: nt,
			PresenterOutlet: rt,
			contentStyle: it,
			presenterBackgroundStyle: at,
			presenterStyle: ot,
			contentNodes: st,
			ContentOutlet: ct,
			retainedContent: lt,
			get adoptedContent() {
				return P;
			},
			set adoptedContent(e) {
				P = e;
			},
			synchronizeContent: ut,
			publicContent: dt,
			mountContent: ft,
			get generation() {
				return F;
			},
			set generation(e) {
				F = e;
			},
			get animations() {
				return I;
			},
			set animations(e) {
				I = e;
			},
			get resizeObserver() {
				return L;
			},
			set resizeObserver(e) {
				L = e;
			},
			get themeObserver() {
				return R;
			},
			set themeObserver(e) {
				R = e;
			},
			get viewportFrame() {
				return z;
			},
			set viewportFrame(e) {
				z = e;
			},
			get previousFocus() {
				return B;
			},
			set previousFocus(e) {
				B = e;
			},
			get boundButton() {
				return V;
			},
			set boundButton(e) {
				V = e;
			},
			get unmounted() {
				return H;
			},
			set unmounted(e) {
				H = e;
			},
			get isOpening() {
				return U;
			},
			set isOpening(e) {
				U = e;
			},
			get openingHasMotion() {
				return W;
			},
			set openingHasMotion(e) {
				W = e;
			},
			get suppressStationaryHover() {
				return G;
			},
			set suppressStationaryHover(e) {
				G = e;
			},
			get mousePosition() {
				return K;
			},
			set mousePosition(e) {
				K = e;
			},
			realMouseMoves: pt,
			recordMousePosition: mt,
			api: q,
			inputRegion: J,
			unregisterInputRegion: ht,
			raise: Y,
			changeOpen: gt,
			stopAnimations: X,
			animate: _t,
			updatePosition: vt,
			focusableElements: yt,
			observeTheme: bt,
			ShowAt: xt,
			Hide: Z,
			onLightDismiss: St,
			onButtonClick: Ct,
			onOtherFlyoutOpening: wt,
			onViewportChanged: Q,
			onPointerDown: Tt,
			onPointerMove: Et,
			onKeyDown: Dt,
			onWindowBlur: Ot,
			mountPortalHost: $,
			onFullscreenChanged: kt,
			ScrollViewer: ge,
			get vAcrylicBrush() {
				return re;
			},
			get vThemeShadow() {
				return ie;
			}
		};
		return Object.defineProperty(At, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), At;
	}
});
//#endregion
export { Pe as default };

//# sourceMappingURL=Flyout.vue_vue_type_script_setup_true_lang.js.map