import { defineComponent as e, h as t } from "vue";
//#region src/components/ExpanderProperties.ts
var n = (n) => e({
	name: `Expander.${n[0].toUpperCase()}${n.slice(1)}`,
	__expanderProperty: n,
	setup(e, { slots: n }) {
		return () => t("span", { class: "expander-property" }, n.default?.());
	}
}), r = n("header"), i = n("content"), a = n("description"), o = n("headerIcon"), s = n("headerControls"), c = (e) => e.type?.__expanderProperty;
//#endregion
export { i as ExpanderContent, a as ExpanderDescription, r as ExpanderHeader, s as ExpanderHeaderControls, o as ExpanderHeaderIcon, c as getExpanderProperty };

//# sourceMappingURL=ExpanderProperties.js.map