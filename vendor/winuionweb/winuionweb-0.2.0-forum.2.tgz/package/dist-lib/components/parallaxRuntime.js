//#region src/components/parallaxRuntime.ts
var e = Symbol("ParallaxView.ChildLayout");
function t(e, t, n, r) {
	let i = Math.max(0, n), a = Math.max(i, r), o = Math.min(a, Math.max(i, e));
	return {
		availableSize: o,
		desiredSize: Math.min(a, Math.max(i, Number.isFinite(o) ? o : t))
	};
}
function n(e) {
	let { kind: t, startOffset: n, endOffset: r, viewportSize: i, contentSize: a, zoomFactor: o, underpan: s, overpan: c, insideSource: l, parallaxOffset: u, parallaxSize: d } = e;
	if (t === "Relative") return {
		startOffset: (l ? u + n : n) * o - (l ? i : 0) - s,
		endOffset: (l ? (u + d + r) * o : Math.max(0, (a + r) * o - i)) + c
	};
	let f = n > 0 ? n * o : n, p;
	return p = a > i ? r <= a - i ? Math.max(0, r * o) : Math.max(0, (a - i) * o) + r - a + i : r <= 0 ? Math.max(0, (a + r) * o - i) : Math.max(0, a * o - i) + r, {
		startOffset: f,
		endOffset: p
	};
}
function r(e) {
	let { position: t, startOffset: n, endOffset: r, shift: i, clamped: a } = e;
	if (i === 0) return 0;
	let o = Math.max(0, e.maxRatio), s = r - n;
	if (a) {
		let e = -Math.min(o * Math.max(0, s), Math.abs(i));
		return i > 0 ? t <= n ? 0 : t < r ? -Math.min(o, i / s) * (t - n) : e : t <= n ? e : t < r ? Math.min(o, -i / s) * (t - r) : 0;
	}
	return s === 0 ? 0 : i > 0 ? -Math.min(o, i / s) * (t - n) : Math.min(o, -i / s) * (t - r);
}
function i(e) {
	let t = e.desiredWidth, n = e.desiredHeight, r = e.width + Math.abs(e.horizontalShift), i = e.height + Math.abs(e.verticalShift);
	if (e.horizontalShift !== 0 && t < r) {
		let i = t > 0 ? r / t : 0;
		t = r, i !== 0 && e.autoHeight && e.verticalAlignment === "Stretch" && (n *= i);
	}
	if (e.verticalShift !== 0 && n < i) {
		let r = n > 0 ? i / n : 0;
		n = i, r !== 0 && e.autoWidth && e.horizontalAlignment === "Stretch" && (t *= r);
	}
	return {
		x: e.horizontalAlignment === "Center" || e.horizontalAlignment === "Stretch" && t < e.width ? (e.width - t) / 2 : e.horizontalAlignment === "Right" ? e.width - t : 0,
		y: e.verticalAlignment === "Center" || e.verticalAlignment === "Stretch" && n < e.height ? (e.height - n) / 2 : e.verticalAlignment === "Bottom" ? e.height - n : 0,
		width: t,
		height: n
	};
}
//#endregion
export { i as arrangeParallaxChild, r as computeParallaxTranslation, t as measureParallaxAxis, e as parallaxChildLayoutKey, n as resolveParallaxOffsets };

//# sourceMappingURL=parallaxRuntime.js.map