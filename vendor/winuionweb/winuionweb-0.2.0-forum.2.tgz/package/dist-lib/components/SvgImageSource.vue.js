import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./SvgImageSource.vue_vue_type_script_setup_true_lang.js";
//#region src/components/SvgImageSource.vue
function n(e, t, n, r, i, a) {
	return null;
}
var r = /*#__PURE__*/ e(t, [["render", n], ["__file", "SvgImageSource.vue"]]);
//#endregion
export { r as default };

//# sourceMappingURL=SvgImageSource.vue.js.map