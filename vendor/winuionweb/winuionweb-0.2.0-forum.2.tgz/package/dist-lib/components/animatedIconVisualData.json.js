var e = {
	AnimatedAcceptVisualSource: /* @__PURE__ */ JSON.parse("{\"duration\":2.6666666,\"frameCount\":160,\"framerate\":60,\"size\":[48,48],\"markers\":{\"NormalOnToNormalOff_Start\":0,\"NormalOnToNormalOff_End\":0.0253125,\"NormalOnToPointerOverOn_Start\":0.0315625,\"NormalOnToPointerOverOn_End\":0.0565625,\"NormalOnToPressedOn_Start\":0.0628125,\"NormalOnToPressedOn_End\":0.0878125,\"NormalOffToNormalOn_Start\":0.0940625,\"NormalOffToNormalOn_End\":0.2128125,\"NormalOffToPointerOverOff_Start\":0.2190625,\"NormalOffToPointerOverOff_End\":0.2440625,\"NormalOffToPressedOff_Start\":0.2503125,\"NormalOffToPressedOff_End\":0.2753125,\"PointerOverOnToPointerOverOff_Start\":0.2815625,\"PointerOverOnToPointerOverOff_End\":0.3065625,\"PointerOverOnToNormalOn_Start\":0.3128125,\"PointerOverOnToNormalOn_End\":0.3378125,\"PointerOverOnToPressedOn_Start\":0.3440625,\"PointerOverOnToPressedOn_End\":0.3690625,\"PointerOverOffToPointerOverOn_Start\":0.3753125,\"PointerOverOffToPointerOverOn_End\":0.4940625,\"PointerOverOffToNormalOff_Start\":0.5003125,\"PointerOverOffToNormalOff_End\":0.5253125,\"PointerOverOffToPressedOff_Start\":0.5315625,\"PointerOverOffToPressedOff_End\":0.5565625,\"PressedOnToPressedOff_Start\":0.5628125,\"PressedOnToPressedOff_End\":0.5878125,\"PressedOnToPointerOverOff_Start\":0.5940625,\"PressedOnToPointerOverOff_End\":0.6190625,\"PressedOnToNormalOff_Start\":0.6253125,\"PressedOnToNormalOff_End\":0.6503125,\"PressedOffToPressedOn_Start\":0.6565625,\"PressedOffToPressedOn_End\":0.7128125,\"PressedOffToPointerOverOn_Start\":0.7190625,\"PressedOffToPointerOverOn_End\":0.8378125,\"PressedOffToNormalOn_Start\":0.8440625,\"PressedOffToNormalOn_End\":0.9628125,\"NormalIndeterminate\":0.9690625,\"PointerOverIndeterminate\":0.9815625,\"PressedIndeterminate\":0.9940625},\"root\":{\"ref\":1},\"records\":[{\"id\":0,\"type\":\"PropertySet\",\"props\":{\"Foreground\":[0,0,0,255]},\"animations\":{},\"children\":[]},{\"id\":1,\"type\":\"ContainerVisual\",\"props\":{\"Progress\":0},\"animations\":{},\"children\":[{\"ref\":2},{\"ref\":12},{\"ref\":23},{\"ref\":30},{\"ref\":37},{\"ref\":45},{\"ref\":52},{\"ref\":59},{\"ref\":63},{\"ref\":67},{\"ref\":74},{\"ref\":81},{\"ref\":87},{\"ref\":94},{\"ref\":98},{\"ref\":102},{\"ref\":109},{\"ref\":114},{\"ref\":119}]},{\"id\":2,\"type\":\"ContainerVisual\",\"props\":{\"IsVisible\":false,\"TransformMatrix\":[1.04999995,0,0,0,0,1.04999995,0,0,0,0,0,0,24,24,0,1]},\"animations\":{\"IsVisible\":{\"ref\":10}},\"children\":[{\"ref\":3}],\"progressBindings\":{\"IsVisible\":{\"ref\":11}}},{\"id\":3,\"type\":\"ContainerVisual\",\"props\":{\"Clip\":{\"ref\":4},\"Size\":[48,48],\"TransformMatrix\":[1,0,0,0,0,1,0,0,0,0,0,0,-24,-24,0,1]},\"animations\":{},\"children\":[{\"ref\":5}]},{\"id\":4,\"type\":\"InsetClip\",\"props\":{},\"animations\":{},\"children\":[]},{\"id\":5,\"type\":\"ShapeVisual\",\"props\":{\"Size\":[48,48]},\"animations\":{},\"children\":[{\"ref\":8}]},{\"id\":6,\"type\":\"Geometry\",\"commands\":[[\"M\",-11.75,-0.125],[\"L\",11.875,-0.125]],\"fillRule\":\"evenodd\"},{\"id\":7,\"type\":\"PathGeometry\",\"props\":{},\"animations\":{},\"children\":[],\"geometry\":{\"ref\":6}},{\"id\":8,\"type\":\"SpriteShape\",\"props\":{\"TransformMatrix\":[0.699999988,0,0,0.699999988,24,24],\"StrokeBrush\":{\"ref\":9},\"StrokeDashCap\":\"Round\",\"StrokeStartCap\":\"Round\",\"StrokeEndCap\":\"Round\",\"StrokeMiterLimit\":2,\"StrokeThickness\":4},\"animations\":{},\"children\":[],\"geometry\":{\"ref\":7}},{\"id\":9,\"type\":\"ColorBrush\",\"props\":{},\"animations\":{},\"children\":[],\"bindings\":{\"Color\":{\"expression\":\"ColorRGB(_theme.Foreground.W,_theme.Foreground.X,_theme.Foreground.Y,_theme.Foreground.Z)\",\"parameter\":\"_theme\",\"reference\":{\"ref\":0}}}},{\"id\":10,\"type\":\"BooleanKeyFrameAnimation\",\"props\":{\"Duration\":2.6666666},\"animations\":{},\"children\":[],\"frames\":[{\"at\":0.96875,\"value\":true}]},{\"id\":11,\"type\":\"ExpressionAnimation\",\"props\":{},\"animations\":{},\"children\":[],\"expression\":\"_.Progress\",\"references\":{\"_\":{\"ref\":1}}},{\"id\":12,\"type\":\"ContainerVisual\",\"props\":{\"IsVisible\":false,\"TransformMatrix\":[1.04999995,0,0,0,0,1.04999995,0,0,0,0,0,0,24,24,0,1]},\"animations\":{\"IsVisible\":{\"ref\":22}},\"children\":[{\"ref\":13}],\"progressBindings\":{\"IsVisible\":{\"ref\":11}}},{\"id\":13,\"type\":\"ContainerVisual\",\"props\":{\"Clip\":{\"ref\":4},\"Size\":[48,48],\"TransformMatrix\":[1,0,0,0,0,1,0,0,0,0,0,0,-24,-24,0,1]},\"animations\":{},\"children\":[{\"ref\":14}]},{\"id\":14,\"type\":\"ShapeVisual\",\"props\":{\"Size\":[48,48]},\"animations\":{},\"children\":[{\"ref\":21}]},{\"id\":15,\"type\":\"Geometry\",\"commands\":[[\"M\",-15.1719999,0.0160000008],[\"L\",-5,10.1879997],[\"L\",15.3369999,-10.3369999]],\"fillRule\":\"evenodd\"},{\"id\":16,\"type\":\"PathGeometry\",\"props\":{},\"animations\":{\"TrimEnd\":{\"ref\":18}},\"children\":[],\"geometry\":{\"ref\":15},\"progressBindings\":{\"TrimEnd\":{\"ref\":11}}},{\"id\":17,\"type\":\"StepEasingFunction\",\"props\":{\"IsInitialStepSingleFrame\":true},\"animations\":{},\"children\":[]},{\"id\":18,\"type\":\"ScalarKeyFrameAnimation\",\"props\":{\"Duration\":2.6666666},\"animations\":{},\"children\":[],\"frames\":[{\"at\":0,\"value\":0,\"easing\":{\"ref\":17}},{\"at\":0.84375,\"value\":0,\"easing\":{\"ref\":19}},{\"at\":0.962499976,\"value\":1,\"easing\":{\"ref\":20}}]},{\"id\":19,\"type\":\"StepEasingFunction\",\"props\":{\"IsFinalStepSingleFrame\":true},\"animations\":{},\"children\":[]},{\"id\":20,\"type\":\"CubicBezierEasingFunction\",\"props\":{},\"animations\":{},\"children\":[],\"points\":[0.550000012,0,0,1]},{\"id\":21,\"type\":\"SpriteShape\",\"props\":{\"TransformMatrix\":[0.699999988,0,0,0.699999988,24,23],\"StrokeBrush\":{\"ref\":9},\"StrokeDashCap\":\"Round\",\"StrokeStartCap\":\"Round\",\"StrokeEndCap\":\"Round\",\"StrokeLineJoin\":\"Round\",\"StrokeMiterLimit\":2,\"StrokeThickness\":4},\"animations\":{},\"children\":[],\"geometry\":{\"ref\":16}},{\"id\":22,\"type\":\"BooleanKeyFrameAnimation\",\"props\":{\"Duration\":2.6666666},\"animations\":{},\"children\":[],\"frames\":[{\"at\":0.84375,\"value\":true},{\"at\":0.96875,\"value\":false}]},{\"id\":23,\"type\":\"ContainerVisual\",\"props\":{\"IsVisible\":false,\"TransformMatrix\":[1.04999995,0,0,0,0,1.04999995,0,0,0,0,0,0,24,24,0,1]},\"animations\":{\"IsVisible\":{\"ref\":29}},\"children\":[{\"ref\":24}],\"progressBindings\":{\"IsVisible\":{\"ref\":11}}},{\"id\":24,\"type\":\"ContainerVisual\",\"props\":{\"Clip\":{\"ref\":4},\"Size\":[48,48],\"TransformMatrix\":[1,0,0,0,0,1,0,0,0,0,0,0,-24,-24,0,1]},\"animations\":{},\"children\":[{\"ref\":25}]},{\"id\":25,\"type\":\"ShapeVisual\",\"props\":{\"Size\":[48,48]},\"animations\":{},\"children\":[{\"ref\":28}]},{\"id\":26,\"type\":\"PathGeometry\",\"props\":{},\"animations\":{\"TrimEnd\":{\"ref\":27}},\"children\":[],\"geometry\":{\"ref\":15},\"progressBindings\":{\"TrimEnd\":{\"ref\":11}}},{\"id\":27,\"type\":\"ScalarKeyFrameAnimation\",\"props\":{\"Duration\":2.6666666},\"animations\":{},\"children\":[],\"frames\":[{\"at\":0,\"value\":0,\"easing\":{\"ref\":17}},{\"at\":0.71875,\"value\":0,\"easing\":{\"ref\":19}},{\"at\":0.837499976,\"value\":1,\"easing\":{\"ref\":20}}]},{\"id\":28,\"type\":\"SpriteShape\",\"props\":{\"TransformMatrix\":[0.699999988,0,0,0.699999988,24,23],\"StrokeBrush\":{\"ref\":9},\"StrokeDashCap\":\"Round\",\"StrokeStartCap\":\"Round\",\"StrokeEndCap\":\"Round\",\"StrokeLineJoin\":\"Round\",\"StrokeMiterLimit\":2,\"StrokeThickness\":4},\"animations\":{},\"children\":[],\"geometry\":{\"ref\":26}},{\"id\":29,\"type\":\"BooleanKeyFrameAnimation\",\"props\":{\"Duration\":2.6666666},\"animations\":{},\"children\":[],\"frames\":[{\"at\":0.71875,\"value\":true},{\"at\":0.84375,\"value\":false}]},{\"id\":30,\"type\":\"ContainerVisual\",\"props\":{\"IsVisible\":false,\"TransformMatrix\":[1.04999995,0,0,0,0,1.04999995,0,0,0,0,0,0,24,24,0,1]},\"animations\":{\"IsVisible\":{\"ref\":36}},\"children\":[{\"ref\":31}],\"progressBindings\":{\"IsVisible\":{\"ref\":11}}},{\"id\":31,\"type\":\"ContainerVisual\",\"props\":{\"Clip\":{\"ref\":4},\"Size\":[48,48],\"TransformMatrix\":[1,0,0,0,0,1,0,0,0,0,0,0,-24,-24,0,1]},\"animations\":{},\"children\":[{\"ref\":32}]},{\"id\":32,\"type\":\"ShapeVisual\",\"props\":{\"Size\":[48,48]},\"animations\":{},\"children\":[{\"ref\":35}]},{\"id\":33,\"type\":\"PathGeometry\",\"props\":{},\"animations\":{\"TrimEnd\":{\"ref\":34}},\"children\":[],\"geometry\":{\"ref\":15},\"progressBindings\":{\"TrimEnd\":{\"ref\":11}}},{\"id\":34,\"type\":\"ScalarKeyFrameAnimation\",\"props\":{\"Duration\":2.6666666},\"animations\":{},\"children\":[],\"frames\":[{\"at\":0,\"value\":0,\"easing\":{\"ref\":17}},{\"at\":0.65625,\"value\":0,\"easing\":{\"ref\":19}},{\"at\":0.712499976,\"value\":1,\"easing\":{\"ref\":20}}]},{\"id\":35,\"type\":\"SpriteShape\",\"props\":{\"TransformMatrix\":[0.699999988,0,0,0.699999988,24,23],\"StrokeBrush\":{\"ref\":9},\"StrokeDashCap\":\"Round\",\"StrokeStartCap\":\"Round\",\"StrokeEndCap\":\"Round\",\"StrokeLineJoin\":\"Round\",\"StrokeMiterLimit\":2,\"StrokeThickness\":4},\"animations\":{},\"children\":[],\"geometry\":{\"ref\":33}},{\"id\":36,\"type\":\"BooleanKeyFrameAnimation\",\"props\":{\"Duration\":2.6666666},\"animations\":{},\"children\":[],\"frames\":[{\"at\":0.65625,\"value\":true},{\"at\":0.71875,\"value\":false}]},{\"id\":37,\"type\":\"ContainerVisual\",\"props\":{\"IsVisible\":false,\"TransformMatrix\":[1.04999995,0,0,0,0,1.04999995,0,0,0,0,0,0,24,24,0,1]},\"animations\":{\"IsVisible\":{\"ref\":44}},\"children\":[{\"ref\":38}],\"progressBindings\":{\"IsVisible\":{\"ref\":11}}},{\"id\":38,\"type\":\"ContainerVisual\",\"props\":{\"Clip\":{\"ref\":4},\"Size\":[48,48],\"TransformMatrix\":[1,0,0,0,0,1,0,0,0,0,0,0,-24,-24,0,1]},\"animations\":{},\"children\":[{\"ref\":39}]},{\"id\":39,\"type\":\"ShapeVisual\",\"props\":{\"Size\":[48,48]},\"animations\":{},\"children\":[{\"ref\":43}]},{\"id\":40,\"type\":\"PathGeometry\",\"props\":{},\"animations\":{\"TrimStart\":{\"ref\":41}},\"children\":[],\"geometry\":{\"ref\":15},\"progressBindings\":{\"TrimStart\":{\"ref\":11}}},{\"id\":41,\"type\":\"ScalarKeyFrameAnimation\",\"props\":{\"Duration\":2.6666666},\"animations\":{},\"children\":[],\"frames\":[{\"at\":0,\"value\":0,\"easing\":{\"ref\":17}},{\"at\":0.625,\"value\":0,\"easing\":{\"ref\":19}},{\"at\":0.649999976,\"value\":1,\"easing\":{\"ref\":42}}]},{\"id\":42,\"type\":\"CubicBezierEasingFunction\",\"props\":{},\"animations\":{},\"children\":[],\"points\":[0.166999996,0.166999996,0.833000004,0.833000004]},{\"id\":43,\"type\":\"SpriteShape\",\"props\":{\"TransformMatrix\":[0.699999988,0,0,0.699999988,24,23],\"StrokeBrush\":{\"ref\":9},\"StrokeDashCap\":\"Round\",\"StrokeStartCap\":\"Round\",\"StrokeEndCap\":\"Round\",\"StrokeLineJoin\":\"Round\",\"StrokeMiterLimit\":2,\"StrokeThickness\":4},\"animations\":{},\"children\":[],\"geometry\":{\"ref\":40}},{\"id\":44,\"type\":\"BooleanKeyFrameAnimation\",\"props\":{\"Duration\":2.6666666},\"animations\":{},\"children\":[],\"frames\":[{\"at\":0.625,\"value\":true},{\"at\":0.65625,\"value\":false}]},{\"id\":45,\"type\":\"ContainerVisual\",\"props\":{\"IsVisible\":false,\"TransformMatrix\":[1.04999995,0,0,0,0,1.04999995,0,0,0,0,0,0,24,24,0,1]},\"animations\":{\"IsVisible\":{\"ref\":51}},\"children\":[{\"ref\":46}],\"progressBindings\":{\"IsVisible\":{\"ref\":11}}},{\"id\":46,\"type\":\"ContainerVisual\",\"props\":{\"Clip\":{\"ref\":4},\"Size\":[48,48],\"TransformMatrix\":[1,0,0,0,0,1,0,0,0,0,0,0,-24,-24,0,1]},\"animations\":{},\"children\":[{\"ref\":47}]},{\"id\":47,\"type\":\"ShapeVisual\",\"props\":{\"Size\":[48,48]},\"animations\":{},\"children\":[{\"ref\":50}]},{\"id\":48,\"type\":\"PathGeometry\",\"props\":{},\"animations\":{\"TrimStart\":{\"ref\":49}},\"children\":[],\"geometry\":{\"ref\":15},\"progressBindings\":{\"TrimStart\":{\"ref\":11}}},{\"id\":49,\"type\":\"ScalarKeyFrameAnimation\",\"props\":{\"Duration\":2.6666666},\"animations\":{},\"children\":[],\"frames\":[{\"at\":0,\"value\":0,\"easing\":{\"ref\":17}},{\"at\":0.59375,\"value\":0,\"easing\":{\"ref\":19}},{\"at\":0.618749976,\"value\":1,\"easing\":{\"ref\":42}}]},{\"id\":50,\"type\":\"SpriteShape\",\"props\":{\"TransformMatrix\":[0.699999988,0,0,0.699999988,24,23],\"StrokeBrush\":{\"ref\":9},\"StrokeDashCap\":\"Round\",\"StrokeStartCap\":\"Round\",\"StrokeEndCap\":\"Round\",\"StrokeLineJoin\":\"Round\",\"StrokeMiterLimit\":2,\"StrokeThickness\":4},\"animations\":{},\"children\":[],\"geometry\":{\"ref\":48}},{\"id\":51,\"type\":\"BooleanKeyFrameAnimation\",\"props\":{\"Duration\":2.6666666},\"animations\":{},\"children\":[],\"frames\":[{\"at\":0.59375,\"value\":true},{\"at\":0.625,\"value\":false}]},{\"id\":52,\"type\":\"ContainerVisual\",\"props\":{\"IsVisible\":false,\"TransformMatrix\":[1.04999995,0,0,0,0,1.04999995,0,0,0,0,0,0,24,24,0,1]},\"animations\":{\"IsVisible\":{\"ref\":58}},\"children\":[{\"ref\":53}],\"progressBindings\":{\"IsVisible\":{\"ref\":11}}},{\"id\":53,\"type\":\"ContainerVisual\",\"props\":{\"Clip\":{\"ref\":4},\"Size\":[48,48],\"TransformMatrix\":[1,0,0,0,0,1,0,0,0,0,0,0,-24,-24,0,1]},\"animations\":{},\"children\":[{\"ref\":54}]},{\"id\":54,\"type\":\"ShapeVisual\",\"props\":{\"Size\":[48,48]},\"animations\":{},\"children\":[{\"ref\":57}]},{\"id\":55,\"type\":\"PathGeometry\",\"props\":{},\"animations\":{\"TrimStart\":{\"ref\":56}},\"children\":[],\"geometry\":{\"ref\":15},\"progressBindings\":{\"TrimStart\":{\"ref\":11}}},{\"id\":56,\"type\":\"ScalarKeyFrameAnimation\",\"props\":{\"Duration\":2.6666666},\"animations\":{},\"children\":[],\"frames\":[{\"at\":0,\"value\":0,\"easing\":{\"ref\":17}},{\"at\":0.5625,\"value\":0,\"easing\":{\"ref\":19}},{\"at\":0.587499976,\"value\":1,\"easing\":{\"ref\":42}}]},{\"id\":57,\"type\":\"SpriteShape\",\"props\":{\"TransformMatrix\":[0.699999988,0,0,0.699999988,24,23],\"StrokeBrush\":{\"ref\":9},\"StrokeDashCap\":\"Round\",\"StrokeStartCap\":\"Round\",\"StrokeEndCap\":\"Round\",\"StrokeLineJoin\":\"Round\",\"StrokeMiterLimit\":2,\"StrokeThickness\":4},\"animations\":{},\"children\":[],\"geometry\":{\"ref\":55}},{\"id\":58,\"type\":\"BooleanKeyFrameAnimation\",\"props\":{\"Duration\":2.6666666},\"animations\":{},\"children\":[],\"frames\":[{\"at\":0.5625,\"value\":true},{\"at\":0.59375,\"value\":false}]},{\"id\":59,\"type\":\"ContainerVisual\",\"props\":{\"IsVisible\":false,\"TransformMatrix\":[1.04999995,0,0,0,0,1.04999995,0,0,0,0,0,0,24,24,0,1]},\"animations\":{\"IsVisible\":{\"ref\":62}},\"children\":[{\"ref\":60}],\"progressBindings\":{\"IsVisible\":{\"ref\":11}}},{\"id\":60,\"type\":\"ContainerVisual\",\"props\":{\"Clip\":{\"ref\":4},\"Size\":[48,48],\"TransformMatrix\":[1,0,0,0,0,1,0,0,0,0,0,0,-24,-24,0,1]},\"animations\":{},\"children\":[{\"ref\":61}]},{\"id\":61,\"type\":\"ContainerVisual\",\"props\":{\"Clip\":{\"ref\":4},\"Size\":[48,48]},\"animations\":{},\"children\":[]},{\"id\":62,\"type\":\"BooleanKeyFrameAnimation\",\"props\":{\"Duration\":2.6666666},\"animations\":{},\"children\":[],\"frames\":[{\"at\":0.53125,\"value\":true},{\"at\":0.5625,\"value\":false}]},{\"id\":63,\"type\":\"ContainerVisual\",\"props\":{\"IsVisible\":false,\"TransformMatrix\":[1.04999995,0,0,0,0,1.04999995,0,0,0,0,0,0,24,24,0,1]},\"animations\":{\"IsVisible\":{\"ref\":66}},\"children\":[{\"ref\":64}],\"progressBindings\":{\"IsVisible\":{\"ref\":11}}},{\"id\":64,\"type\":\"ContainerVisual\",\"props\":{\"Clip\":{\"ref\":4},\"Size\":[48,48],\"TransformMatrix\":[1,0,0,0,0,1,0,0,0,0,0,0,-24,-24,0,1]},\"animations\":{},\"children\":[{\"ref\":65}]},{\"id\":65,\"type\":\"ContainerVisual\",\"props\":{\"Clip\":{\"ref\":4},\"Size\":[48,48]},\"animations\":{},\"children\":[]},{\"id\":66,\"type\":\"BooleanKeyFrameAnimation\",\"props\":{\"Duration\":2.6666666},\"animations\":{},\"children\":[],\"frames\":[{\"at\":0.5,\"value\":true},{\"at\":0.53125,\"value\":false}]},{\"id\":67,\"type\":\"ContainerVisual\",\"props\":{\"IsVisible\":false,\"TransformMatrix\":[1.04999995,0,0,0,0,1.04999995,0,0,0,0,0,0,24,24,0,1]},\"animations\":{\"IsVisible\":{\"ref\":73}},\"children\":[{\"ref\":68}],\"progressBindings\":{\"IsVisible\":{\"ref\":11}}},{\"id\":68,\"type\":\"ContainerVisual\",\"props\":{\"Clip\":{\"ref\":4},\"Size\":[48,48],\"TransformMatrix\":[1,0,0,0,0,1,0,0,0,0,0,0,-24,-24,0,1]},\"animations\":{},\"children\":[{\"ref\":69}]},{\"id\":69,\"type\":\"ShapeVisual\",\"props\":{\"Size\":[48,48]},\"animations\":{},\"children\":[{\"ref\":72}]},{\"id\":70,\"type\":\"PathGeometry\",\"props\":{},\"animations\":{\"TrimEnd\":{\"ref\":71}},\"children\":[],\"geometry\":{\"ref\":15},\"progressBindings\":{\"TrimEnd\":{\"ref\":11}}},{\"id\":71,\"type\":\"ScalarKeyFrameAnimation\",\"props\":{\"Duration\":2.6666666},\"animations\":{},\"children\":[],\"frames\":[{\"at\":0,\"value\":0,\"easing\":{\"ref\":17}},{\"at\":0.375,\"value\":0,\"easing\":{\"ref\":19}},{\"at\":0.493750006,\"value\":1,\"easing\":{\"ref\":20}}]},{\"id\":72,\"type\":\"SpriteShape\",\"props\":{\"TransformMatrix\":[0.699999988,0,0,0.699999988,24,23],\"StrokeBrush\":{\"ref\":9},\"StrokeDashCap\":\"Round\",\"StrokeStartCap\":\"Round\",\"StrokeEndCap\":\"Round\",\"StrokeLineJoin\":\"Round\",\"StrokeMiterLimit\":2,\"StrokeThickness\":4},\"animations\":{},\"children\":[],\"geometry\":{\"ref\":70}},{\"id\":73,\"type\":\"BooleanKeyFrameAnimation\",\"props\":{\"Duration\":2.6666666},\"animations\":{},\"children\":[],\"frames\":[{\"at\":0.375,\"value\":true},{\"at\":0.5,\"value\":false}]},{\"id\":74,\"type\":\"ContainerVisual\",\"props\":{\"IsVisible\":false,\"TransformMatrix\":[1.04999995,0,0,0,0,1.04999995,0,0,0,0,0,0,24,24,0,1]},\"animations\":{\"IsVisible\":{\"ref\":80}},\"children\":[{\"ref\":75}],\"progressBindings\":{\"IsVisible\":{\"ref\":11}}},{\"id\":75,\"type\":\"ContainerVisual\",\"props\":{\"Clip\":{\"ref\":4},\"Size\":[48,48],\"TransformMatrix\":[1,0,0,0,0,1,0,0,0,0,0,0,-24,-24,0,1]},\"animations\":{},\"children\":[{\"ref\":76}]},{\"id\":76,\"type\":\"ShapeVisual\",\"props\":{\"Size\":[48,48]},\"animations\":{},\"children\":[{\"ref\":79}]},{\"id\":77,\"type\":\"Geometry\",\"commands\":[[\"M\",-15.1719999,0.0160000008],[\"L\",-5,10.1879997],[\"L\",15.3369999,-10.2810001]],\"fillRule\":\"evenodd\"},{\"id\":78,\"type\":\"PathGeometry\",\"props\":{},\"animations\":{},\"children\":[],\"geometry\":{\"ref\":77}},{\"id\":79,\"type\":\"SpriteShape\",\"props\":{\"TransformMatrix\":[0.699999988,0,0,0.699999988,24,23],\"StrokeBrush\":{\"ref\":9},\"StrokeDashCap\":\"Round\",\"StrokeStartCap\":\"Round\",\"StrokeEndCap\":\"Round\",\"StrokeLineJoin\":\"Round\",\"StrokeMiterLimit\":2,\"StrokeThickness\":4},\"animations\":{},\"children\":[],\"geometry\":{\"ref\":78}},{\"id\":80,\"type\":\"BooleanKeyFrameAnimation\",\"props\":{\"Duration\":2.6666666},\"animations\":{},\"children\":[],\"frames\":[{\"at\":0.34375,\"value\":true},{\"at\":0.375,\"value\":false}]},{\"id\":81,\"type\":\"ContainerVisual\",\"props\":{\"IsVisible\":false,\"TransformMatrix\":[1.04999995,0,0,0,0,1.04999995,0,0,0,0,0,0,24,24,0,1]},\"animations\":{\"IsVisible\":{\"ref\":86}},\"children\":[{\"ref\":82}],\"progressBindings\":{\"IsVisible\":{\"ref\":11}}},{\"id\":82,\"type\":\"ContainerVisual\",\"props\":{\"Clip\":{\"ref\":4},\"Size\":[48,48],\"TransformMatrix\":[1,0,0,0,0,1,0,0,0,0,0,0,-24,-24,0,1]},\"animations\":{},\"children\":[{\"ref\":83}]},{\"id\":83,\"type\":\"ShapeVisual\",\"props\":{\"Size\":[48,48]},\"animations\":{},\"children\":[{\"ref\":85}]},{\"id\":84,\"type\":\"PathGeometry\",\"props\":{},\"animations\":{},\"children\":[],\"geometry\":{\"ref\":15}},{\"id\":85,\"type\":\"SpriteShape\",\"props\":{\"TransformMatrix\":[0.699999988,0,0,0.699999988,24,23],\"StrokeBrush\":{\"ref\":9},\"StrokeDashCap\":\"Round\",\"StrokeStartCap\":\"Round\",\"StrokeEndCap\":\"Round\",\"StrokeLineJoin\":\"Round\",\"StrokeMiterLimit\":2,\"StrokeThickness\":4},\"animations\":{},\"children\":[],\"geometry\":{\"ref\":84}},{\"id\":86,\"type\":\"BooleanKeyFrameAnimation\",\"props\":{\"Duration\":2.6666666},\"animations\":{},\"children\":[],\"frames\":[{\"at\":0.3125,\"value\":true},{\"at\":0.34375,\"value\":false}]},{\"id\":87,\"type\":\"ContainerVisual\",\"props\":{\"IsVisible\":false,\"TransformMatrix\":[1.04999995,0,0,0,0,1.04999995,0,0,0,0,0,0,24,24,0,1]},\"animations\":{\"IsVisible\":{\"ref\":93}},\"children\":[{\"ref\":88}],\"progressBindings\":{\"IsVisible\":{\"ref\":11}}},{\"id\":88,\"type\":\"ContainerVisual\",\"props\":{\"Clip\":{\"ref\":4},\"Size\":[48,48],\"TransformMatrix\":[1,0,0,0,0,1,0,0,0,0,0,0,-24,-24,0,1]},\"animations\":{},\"children\":[{\"ref\":89}]},{\"id\":89,\"type\":\"ShapeVisual\",\"props\":{\"Size\":[48,48]},\"animations\":{},\"children\":[{\"ref\":92}]},{\"id\":90,\"type\":\"PathGeometry\",\"props\":{},\"animations\":{\"TrimStart\":{\"ref\":91}},\"children\":[],\"geometry\":{\"ref\":15},\"progressBindings\":{\"TrimStart\":{\"ref\":11}}},{\"id\":91,\"type\":\"ScalarKeyFrameAnimation\",\"props\":{\"Duration\":2.6666666},\"animations\":{},\"children\":[],\"frames\":[{\"at\":0,\"value\":0,\"easing\":{\"ref\":17}},{\"at\":0.28125,\"value\":0,\"easing\":{\"ref\":19}},{\"at\":0.306250006,\"value\":1,\"easing\":{\"ref\":42}}]},{\"id\":92,\"type\":\"SpriteShape\",\"props\":{\"TransformMatrix\":[0.699999988,0,0,0.699999988,24,23],\"StrokeBrush\":{\"ref\":9},\"StrokeDashCap\":\"Round\",\"StrokeStartCap\":\"Round\",\"StrokeEndCap\":\"Round\",\"StrokeLineJoin\":\"Round\",\"StrokeMiterLimit\":2,\"StrokeThickness\":4},\"animations\":{},\"children\":[],\"geometry\":{\"ref\":90}},{\"id\":93,\"type\":\"BooleanKeyFrameAnimation\",\"props\":{\"Duration\":2.6666666},\"animations\":{},\"children\":[],\"frames\":[{\"at\":0.28125,\"value\":true},{\"at\":0.3125,\"value\":false}]},{\"id\":94,\"type\":\"ContainerVisual\",\"props\":{\"IsVisible\":false,\"TransformMatrix\":[1.04999995,0,0,0,0,1.04999995,0,0,0,0,0,0,24,24,0,1]},\"animations\":{\"IsVisible\":{\"ref\":97}},\"children\":[{\"ref\":95}],\"progressBindings\":{\"IsVisible\":{\"ref\":11}}},{\"id\":95,\"type\":\"ContainerVisual\",\"props\":{\"Clip\":{\"ref\":4},\"Size\":[48,48],\"TransformMatrix\":[1,0,0,0,0,1,0,0,0,0,0,0,-24,-24,0,1]},\"animations\":{},\"children\":[{\"ref\":96}]},{\"id\":96,\"type\":\"ContainerVisual\",\"props\":{\"Clip\":{\"ref\":4},\"Size\":[48,48]},\"animations\":{},\"children\":[]},{\"id\":97,\"type\":\"BooleanKeyFrameAnimation\",\"props\":{\"Duration\":2.6666666},\"animations\":{},\"children\":[],\"frames\":[{\"at\":0.25,\"value\":true},{\"at\":0.28125,\"value\":false}]},{\"id\":98,\"type\":\"ContainerVisual\",\"props\":{\"IsVisible\":false,\"TransformMatrix\":[1.04999995,0,0,0,0,1.04999995,0,0,0,0,0,0,24,24,0,1]},\"animations\":{\"IsVisible\":{\"ref\":101}},\"children\":[{\"ref\":99}],\"progressBindings\":{\"IsVisible\":{\"ref\":11}}},{\"id\":99,\"type\":\"ContainerVisual\",\"props\":{\"Clip\":{\"ref\":4},\"Size\":[48,48],\"TransformMatrix\":[1,0,0,0,0,1,0,0,0,0,0,0,-24,-24,0,1]},\"animations\":{},\"children\":[{\"ref\":100}]},{\"id\":100,\"type\":\"ContainerVisual\",\"props\":{\"Clip\":{\"ref\":4},\"Size\":[48,48]},\"animations\":{},\"children\":[]},{\"id\":101,\"type\":\"BooleanKeyFrameAnimation\",\"props\":{\"Duration\":2.6666666},\"animations\":{},\"children\":[],\"frames\":[{\"at\":0.21875,\"value\":true},{\"at\":0.25,\"value\":false}]},{\"id\":102,\"type\":\"ContainerVisual\",\"props\":{\"IsVisible\":false,\"TransformMatrix\":[1.04999995,0,0,0,0,1.04999995,0,0,0,0,0,0,24,24,0,1]},\"animations\":{\"IsVisible\":{\"ref\":108}},\"children\":[{\"ref\":103}],\"progressBindings\":{\"IsVisible\":{\"ref\":11}}},{\"id\":103,\"type\":\"ContainerVisual\",\"props\":{\"Clip\":{\"ref\":4},\"Size\":[48,48],\"TransformMatrix\":[1,0,0,0,0,1,0,0,0,0,0,0,-24,-24,0,1]},\"animations\":{},\"children\":[{\"ref\":104}]},{\"id\":104,\"type\":\"ShapeVisual\",\"props\":{\"Size\":[48,48]},\"animations\":{},\"children\":[{\"ref\":107}]},{\"id\":105,\"type\":\"PathGeometry\",\"props\":{},\"animations\":{\"TrimEnd\":{\"ref\":106}},\"children\":[],\"geometry\":{\"ref\":15},\"progressBindings\":{\"TrimEnd\":{\"ref\":11}}},{\"id\":106,\"type\":\"ScalarKeyFrameAnimation\",\"props\":{\"Duration\":2.6666666},\"animations\":{},\"children\":[],\"frames\":[{\"at\":0,\"value\":0,\"easing\":{\"ref\":17}},{\"at\":0.09375,\"value\":0,\"easing\":{\"ref\":19}},{\"at\":0.212500006,\"value\":1,\"easing\":{\"ref\":20}}]},{\"id\":107,\"type\":\"SpriteShape\",\"props\":{\"TransformMatrix\":[0.699999988,0,0,0.699999988,24,23],\"StrokeBrush\":{\"ref\":9},\"StrokeDashCap\":\"Round\",\"StrokeStartCap\":\"Round\",\"StrokeEndCap\":\"Round\",\"StrokeLineJoin\":\"Round\",\"StrokeMiterLimit\":2,\"StrokeThickness\":4},\"animations\":{},\"children\":[],\"geometry\":{\"ref\":105}},{\"id\":108,\"type\":\"BooleanKeyFrameAnimation\",\"props\":{\"Duration\":2.6666666},\"animations\":{},\"children\":[],\"frames\":[{\"at\":0.09375,\"value\":true},{\"at\":0.21875,\"value\":false}]},{\"id\":109,\"type\":\"ContainerVisual\",\"props\":{\"IsVisible\":false,\"TransformMatrix\":[1.04999995,0,0,0,0,1.04999995,0,0,0,0,0,0,24,24,0,1]},\"animations\":{\"IsVisible\":{\"ref\":113}},\"children\":[{\"ref\":110}],\"progressBindings\":{\"IsVisible\":{\"ref\":11}}},{\"id\":110,\"type\":\"ContainerVisual\",\"props\":{\"Clip\":{\"ref\":4},\"Size\":[48,48],\"TransformMatrix\":[1,0,0,0,0,1,0,0,0,0,0,0,-24,-24,0,1]},\"animations\":{},\"children\":[{\"ref\":111}]},{\"id\":111,\"type\":\"ShapeVisual\",\"props\":{\"Size\":[48,48]},\"animations\":{},\"children\":[{\"ref\":112}]},{\"id\":112,\"type\":\"SpriteShape\",\"props\":{\"TransformMatrix\":[0.699999988,0,0,0.699999988,24,23],\"StrokeBrush\":{\"ref\":9},\"StrokeDashCap\":\"Round\",\"StrokeStartCap\":\"Round\",\"StrokeEndCap\":\"Round\",\"StrokeLineJoin\":\"Round\",\"StrokeMiterLimit\":2,\"StrokeThickness\":4},\"animations\":{},\"children\":[],\"geometry\":{\"ref\":84}},{\"id\":113,\"type\":\"BooleanKeyFrameAnimation\",\"props\":{\"Duration\":2.6666666},\"animations\":{},\"children\":[],\"frames\":[{\"at\":0.0625,\"value\":true},{\"at\":0.09375,\"value\":false}]},{\"id\":114,\"type\":\"ContainerVisual\",\"props\":{\"IsVisible\":false,\"TransformMatrix\":[1.04999995,0,0,0,0,1.04999995,0,0,0,0,0,0,24,24,0,1]},\"animations\":{\"IsVisible\":{\"ref\":118}},\"children\":[{\"ref\":115}],\"progressBindings\":{\"IsVisible\":{\"ref\":11}}},{\"id\":115,\"type\":\"ContainerVisual\",\"props\":{\"Clip\":{\"ref\":4},\"Size\":[48,48],\"TransformMatrix\":[1,0,0,0,0,1,0,0,0,0,0,0,-24,-24,0,1]},\"animations\":{},\"children\":[{\"ref\":116}]},{\"id\":116,\"type\":\"ShapeVisual\",\"props\":{\"Size\":[48,48]},\"animations\":{},\"children\":[{\"ref\":117}]},{\"id\":117,\"type\":\"SpriteShape\",\"props\":{\"TransformMatrix\":[0.699999988,0,0,0.699999988,24,23],\"StrokeBrush\":{\"ref\":9},\"StrokeDashCap\":\"Round\",\"StrokeStartCap\":\"Round\",\"StrokeEndCap\":\"Round\",\"StrokeLineJoin\":\"Round\",\"StrokeMiterLimit\":2,\"StrokeThickness\":4},\"animations\":{},\"children\":[],\"geometry\":{\"ref\":84}},{\"id\":118,\"type\":\"BooleanKeyFrameAnimation\",\"props\":{\"Duration\":2.6666666},\"animations\":{},\"children\":[],\"frames\":[{\"at\":0.03125,\"value\":true},{\"at\":0.0625,\"value\":false}]},{\"id\":119,\"type\":\"ContainerVisual\",\"props\":{\"TransformMatrix\":[1.04999995,0,0,0,0,1.04999995,0,0,0,0,0,0,24,24,0,1]},\"animations\":{\"IsVisible\":{\"ref\":125}},\"children\":[{\"ref\":120}],\"progressBindings\":{\"IsVisible\":{\"ref\":11}}},{\"id\":120,\"type\":\"ContainerVisual\",\"props\":{\"Clip\":{\"ref\":4},\"Size\":[48,48],\"TransformMatrix\":[1,0,0,0,0,1,0,0,0,0,0,0,-24,-24,0,1]},\"animations\":{},\"children\":[{\"ref\":121}]},{\"id\":121,\"type\":\"ShapeVisual\",\"props\":{\"Size\":[48,48]},\"animations\":{},\"children\":[{\"ref\":124}]},{\"id\":122,\"type\":\"PathGeometry\",\"props\":{},\"animations\":{\"TrimStart\":{\"ref\":123}},\"children\":[],\"geometry\":{\"ref\":15},\"progressBindings\":{\"TrimStart\":{\"ref\":11}}},{\"id\":123,\"type\":\"ScalarKeyFrameAnimation\",\"props\":{\"Duration\":2.6666666},\"animations\":{},\"children\":[],\"frames\":[{\"at\":0,\"value\":0,\"easing\":{\"ref\":19}},{\"at\":0.0250000004,\"value\":1,\"easing\":{\"ref\":42}}]},{\"id\":124,\"type\":\"SpriteShape\",\"props\":{\"TransformMatrix\":[0.699999988,0,0,0.699999988,24,23],\"StrokeBrush\":{\"ref\":9},\"StrokeDashCap\":\"Round\",\"StrokeStartCap\":\"Round\",\"StrokeEndCap\":\"Round\",\"StrokeLineJoin\":\"Round\",\"StrokeMiterLimit\":2,\"StrokeThickness\":4},\"animations\":{},\"children\":[],\"geometry\":{\"ref\":122}},{\"id\":125,\"type\":\"BooleanKeyFrameAnimation\",\"props\":{\"Duration\":2.6666666},\"animations\":{},\"children\":[],\"frames\":[{\"at\":0.03125,\"value\":false}]}]}"),
	AnimatedBackVisualSource: /* @__PURE__ */ JSON.parse("{\"duration\":1.3333333,\"frameCount\":80,\"framerate\":60,\"size\":[48,48],\"markers\":{\"NormalToPointerOver_Start\":0,\"NormalToPointerOver_End\":0.113125,\"NormalToPressed_Start\":0.125625,\"NormalToPressed_End\":0.238125,\"PointerOverToNormal_Start\":0.250625,\"PointerOverToNormal_End\":0.363125,\"PointerOverToPressed_Start\":0.375625,\"PointerOverToPressed_End\":0.488125,\"PressedToNormal_Start\":0.500625,\"PressedToNormal_End\":0.738125,\"PressedToPointerOver_Start\":0.750625,\"PressedToPointerOver_End\":0.988125},\"root\":{\"ref\":1},\"records\":[{\"id\":0,\"type\":\"PropertySet\",\"props\":{\"Foreground\":[0,0,0,255]},\"animations\":{},\"children\":[]},{\"id\":1,\"type\":\"ContainerVisual\",\"props\":{\"Progress\":0,\"t0\":0},\"animations\":{\"t0\":{\"ref\":37}},\"children\":[{\"ref\":2},{\"ref\":30}],\"progressBindings\":{\"t0\":{\"ref\":19}}},{\"id\":2,\"type\":\"ContainerVisual\",\"props\":{\"Clip\":{\"ref\":3},\"IsVisible\":false,\"Size\":[48,48],\"TransformMatrix\":[1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1]},\"animations\":{\"Opacity\":{\"ref\":28},\"IsVisible\":{\"ref\":29}},\"children\":[{\"ref\":4}],\"progressBindings\":{\"Opacity\":{\"ref\":19},\"IsVisible\":{\"ref\":19}}},{\"id\":3,\"type\":\"InsetClip\",\"props\":{},\"animations\":{},\"children\":[]},{\"id\":4,\"type\":\"ShapeVisual\",\"props\":{\"Size\":[48,48]},\"animations\":{},\"children\":[{\"ref\":5},{\"ref\":25}]},{\"id\":5,\"type\":\"ContainerShape\",\"props\":{},\"animations\":{\"Offset\":{\"ref\":22}},\"children\":[{\"ref\":9},{\"ref\":12}],\"progressBindings\":{\"Offset\":{\"ref\":19}}},{\"id\":6,\"type\":\"Geometry\",\"commands\":[[\"M\",7.5,0.499000013],[\"C\",7.77600002,0.499000013,8,0.275000006,8,-0.00100000005],[\"C\",8,-0.27700001,7.77600002,-0.500999987,7.5,-0.500999987],[\"L\",7.5,0.499000013],[\"Z\"]],\"fillRule\":\"nonzero\"},{\"id\":7,\"type\":\"PathGeometry\",\"props\":{},\"animations\":{},\"children\":[],\"geometry\":{\"ref\":6}},{\"id\":8,\"type\":\"ColorBrush\",\"props\":{},\"animations\":{},\"children\":[],\"bindings\":{\"Color\":{\"expression\":\"ColorRGB(_theme.Foreground.W,_theme.Foreground.X,_theme.Foreground.Y,_theme.Foreground.Z)\",\"parameter\":\"_theme\",\"reference\":{\"ref\":0}}}},{\"id\":9,\"type\":\"SpriteShape\",\"props\":{\"TransformMatrix\":[2.25,0,0,2.25,0,0],\"FillBrush\":{\"ref\":8}},\"animations\":{},\"children\":[],\"geometry\":{\"ref\":7}},{\"id\":10,\"type\":\"Geometry\",\"commands\":[[\"M\",-5.33400011,0.495000005],[\"L\",7.5,0.499000013],[\"L\",7.5,-0.500999987],[\"L\",-5.33099985,-0.504999995],[\"L\",-5.33400011,0.495000005],[\"Z\"]],\"fillRule\":\"nonzero\"},{\"id\":11,\"type\":\"PathGeometry\",\"props\":{},\"animations\":{},\"children\":[],\"geometry\":{\"ref\":10}},{\"id\":12,\"type\":\"SpriteShape\",\"props\":{\"CenterPoint\":[7.5,-0.00300000003],\"Offset\":[9.375,-0.00400000019],\"FillBrush\":{\"ref\":8}},\"animations\":{\"Scale.X\":{\"ref\":14},\"Scale.Y\":{\"ref\":20}},\"children\":[],\"geometry\":{\"ref\":11},\"progressBindings\":{\"Scale.X\":{\"ref\":19},\"Scale.Y\":{\"ref\":19}}},{\"id\":13,\"type\":\"StepEasingFunction\",\"props\":{\"IsInitialStepSingleFrame\":true},\"animations\":{},\"children\":[]},{\"id\":14,\"type\":\"ScalarKeyFrameAnimation\",\"props\":{\"Duration\":1.3333333},\"animations\":{},\"children\":[],\"frames\":[{\"at\":0,\"value\":2.25,\"easing\":{\"ref\":13}},{\"at\":0.125,\"value\":2.25,\"easing\":{\"ref\":15}},{\"at\":0.237499997,\"value\":1.62211001,\"easing\":{\"ref\":16}},{\"at\":0.375,\"value\":2.25,\"easing\":{\"ref\":15}},{\"at\":0.487500012,\"value\":1.62211001,\"easing\":{\"ref\":16}},{\"at\":0.5,\"value\":1.62211001,\"easing\":{\"ref\":15}},{\"at\":0.625,\"value\":2.26947999,\"easing\":{\"ref\":17}},{\"at\":0.737500012,\"value\":2.25,\"easing\":{\"ref\":18}},{\"at\":0.75,\"value\":1.62211001,\"easing\":{\"ref\":15}},{\"at\":0.875,\"value\":2.26947999,\"easing\":{\"ref\":17}},{\"at\":0.987500012,\"value\":2.25,\"easing\":{\"ref\":18}}]},{\"id\":15,\"type\":\"StepEasingFunction\",\"props\":{\"IsFinalStepSingleFrame\":true},\"animations\":{},\"children\":[]},{\"id\":16,\"type\":\"CubicBezierEasingFunction\",\"props\":{},\"animations\":{},\"children\":[],\"points\":[0.166999996,0.166999996,0,1]},{\"id\":17,\"type\":\"CubicBezierEasingFunction\",\"props\":{},\"animations\":{},\"children\":[],\"points\":[0.550000012,0,0.75,1]},{\"id\":18,\"type\":\"CubicBezierEasingFunction\",\"props\":{},\"animations\":{},\"children\":[],\"points\":[0.349999994,0,0,1]},{\"id\":19,\"type\":\"ExpressionAnimation\",\"props\":{},\"animations\":{},\"children\":[],\"expression\":\"_.Progress\",\"references\":{\"_\":{\"ref\":1}}},{\"id\":20,\"type\":\"ScalarKeyFrameAnimation\",\"props\":{\"Duration\":1.3333333},\"animations\":{},\"children\":[],\"frames\":[{\"at\":0,\"value\":2.25,\"easing\":{\"ref\":13}},{\"at\":0.125,\"value\":2.25,\"easing\":{\"ref\":15}},{\"at\":0.237499997,\"value\":2.25,\"easing\":{\"ref\":21}},{\"at\":0.375,\"value\":2.25,\"easing\":{\"ref\":15}},{\"at\":0.487500012,\"value\":2.25,\"easing\":{\"ref\":21}},{\"at\":0.5,\"value\":2.25,\"easing\":{\"ref\":15}},{\"at\":0.625,\"value\":2.25,\"easing\":{\"ref\":17}},{\"at\":0.737500012,\"value\":2.25,\"easing\":{\"ref\":18}},{\"at\":0.75,\"value\":2.25,\"easing\":{\"ref\":15}},{\"at\":0.875,\"value\":2.25,\"easing\":{\"ref\":17}},{\"at\":0.987500012,\"value\":2.25,\"easing\":{\"ref\":18}}]},{\"id\":21,\"type\":\"CubicBezierEasingFunction\",\"props\":{},\"animations\":{},\"children\":[],\"points\":[0.166999996,0,0,1]},{\"id\":22,\"type\":\"Vector2KeyFrameAnimation\",\"props\":{\"Duration\":1.3333333},\"animations\":{},\"children\":[],\"frames\":[{\"at\":0,\"value\":[24,24],\"easing\":{\"ref\":13}},{\"at\":0.125,\"value\":[24,24],\"easing\":{\"ref\":15}},{\"at\":0.237499997,\"value\":[24.9379997,24],\"easing\":{\"ref\":16}},{\"at\":0.375,\"value\":[24,24],\"easing\":{\"ref\":15}},{\"at\":0.487500012,\"value\":[24.9379997,24],\"easing\":{\"ref\":16}},{\"at\":0.5,\"value\":[24.9379997,24],\"easing\":{\"ref\":15}},{\"at\":0.625,\"value\":[20.25,24],\"easing\":{\"ref\":17}},{\"at\":0.737499952,\"expression\":\"Pow(1-_.t0,3)*Vector2(20.25,24)+(3*Square(1-_.t0)*_.t0*Vector2(20.094,24))+(3*(1-_.t0)*Square(_.t0)*Vector2(23.375,24))+(Pow(_.t0,3)*Vector2(24,24))\",\"easing\":{\"ref\":13}},{\"at\":0.737500012,\"value\":[24,24],\"easing\":{\"ref\":13}},{\"at\":0.75,\"value\":[24.9379997,24],\"easing\":{\"ref\":15}},{\"at\":0.875,\"value\":[20.25,24],\"easing\":{\"ref\":17}},{\"at\":0.987499952,\"expression\":\"Pow(1-_.t0,3)*Vector2(20.25,24)+(3*Square(1-_.t0)*_.t0*Vector2(20.094,24))+(3*(1-_.t0)*Square(_.t0)*Vector2(23.375,24))+(Pow(_.t0,3)*Vector2(24,24))\",\"easing\":{\"ref\":13}},{\"at\":0.987500012,\"value\":[24,24],\"easing\":{\"ref\":13}}],\"references\":{\"_\":{\"ref\":1}}},{\"id\":23,\"type\":\"Geometry\",\"commands\":[[\"M\",-0.837000012,6.86800003],[\"C\",-0.633000016,7.0539999,-0.317000002,7.03999996,-0.130999997,6.83599997],[\"C\",0.0549999997,6.63199997,0.0410000011,6.31500006,-0.163000003,6.12900019],[\"L\",-6.33099985,0.499000013],[\"L\",-5.32800007,0.488999993],[\"L\",-5.32800007,-0.510999978],[\"L\",-6.32800007,-0.500999987],[\"L\",-0.163000003,-6.12900019],[\"C\",0.0410000011,-6.31500006,0.0549999997,-6.63199997,-0.130999997,-6.83599997],[\"C\",-0.317000002,-7.03999996,-0.633000016,-7.0539999,-0.837000012,-6.86800003],[\"L\",-7.75299978,-0.55400002],[\"C\",-7.89300013,-0.425999999,-7.97300005,-0.257999986,-7.99300003,-0.0850000009],[\"C\",-7.99800014,-0.0579999983,-8,-0.0299999993,-8,-0.00100000005],[\"C\",-8,0.0260000005,-7.99800014,0.0520000011,-7.99399996,0.0780000016],[\"C\",-7.97599983,0.254000008,-7.89499998,0.423999995,-7.75299978,0.55400002],[\"L\",-0.837000012,6.86800003],[\"Z\"]],\"fillRule\":\"nonzero\"},{\"id\":24,\"type\":\"PathGeometry\",\"props\":{},\"animations\":{},\"children\":[],\"geometry\":{\"ref\":23}},{\"id\":25,\"type\":\"SpriteShape\",\"props\":{\"Scale\":[2.25,2.25],\"FillBrush\":{\"ref\":8}},\"animations\":{\"Offset\":{\"ref\":26}},\"children\":[],\"geometry\":{\"ref\":24},\"progressBindings\":{\"Offset\":{\"ref\":19}}},{\"id\":26,\"type\":\"Vector2KeyFrameAnimation\",\"props\":{\"Duration\":1.3333333},\"animations\":{},\"children\":[],\"frames\":[{\"at\":0,\"value\":[24,24],\"easing\":{\"ref\":13}},{\"at\":0.125,\"value\":[24,24],\"easing\":{\"ref\":15}},{\"at\":0.237499997,\"value\":[33,24],\"easing\":{\"ref\":16}},{\"at\":0.375,\"value\":[24,24],\"easing\":{\"ref\":15}},{\"at\":0.487500012,\"value\":[33,24],\"easing\":{\"ref\":16}},{\"at\":0.5,\"value\":[33,24],\"easing\":{\"ref\":15}},{\"at\":0.625,\"value\":[19.9839993,24],\"easing\":{\"ref\":27}},{\"at\":0.737500012,\"value\":[24,24],\"easing\":{\"ref\":18}},{\"at\":0.75,\"value\":[33,24],\"easing\":{\"ref\":15}},{\"at\":0.875,\"value\":[19.9839993,24],\"easing\":{\"ref\":27}},{\"at\":0.987500012,\"value\":[24,24],\"easing\":{\"ref\":18}}]},{\"id\":27,\"type\":\"CubicBezierEasingFunction\",\"props\":{},\"animations\":{},\"children\":[],\"points\":[0.850000024,0,0.75,1]},{\"id\":28,\"type\":\"ScalarKeyFrameAnimation\",\"props\":{\"Duration\":1.3333333},\"animations\":{},\"children\":[],\"frames\":[{\"at\":0,\"value\":1,\"easing\":{\"ref\":13}},{\"at\":0.125,\"value\":1,\"easing\":{\"ref\":15}},{\"at\":0.25,\"value\":0,\"easing\":{\"ref\":15}},{\"at\":0.375,\"value\":1,\"easing\":{\"ref\":15}}]},{\"id\":29,\"type\":\"BooleanKeyFrameAnimation\",\"props\":{\"Duration\":1.3333333},\"animations\":{},\"children\":[],\"frames\":[{\"at\":0.125,\"value\":true}]},{\"id\":30,\"type\":\"ContainerVisual\",\"props\":{\"Clip\":{\"ref\":3},\"Size\":[48,48],\"TransformMatrix\":[1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1]},\"animations\":{\"Opacity\":{\"ref\":35},\"IsVisible\":{\"ref\":36}},\"children\":[{\"ref\":31}],\"progressBindings\":{\"Opacity\":{\"ref\":19},\"IsVisible\":{\"ref\":19}}},{\"id\":31,\"type\":\"ShapeVisual\",\"props\":{\"Size\":[48,48]},\"animations\":{},\"children\":[{\"ref\":32},{\"ref\":33},{\"ref\":34}]},{\"id\":32,\"type\":\"SpriteShape\",\"props\":{\"TransformMatrix\":[2.25,0,0,2.25,24,24],\"FillBrush\":{\"ref\":8}},\"animations\":{},\"children\":[],\"geometry\":{\"ref\":7}},{\"id\":33,\"type\":\"SpriteShape\",\"props\":{\"TransformMatrix\":[2.25,0,0,2.25,24,23.9997501],\"FillBrush\":{\"ref\":8}},\"animations\":{},\"children\":[],\"geometry\":{\"ref\":11}},{\"id\":34,\"type\":\"SpriteShape\",\"props\":{\"TransformMatrix\":[2.25,0,0,2.25,24,24],\"FillBrush\":{\"ref\":8}},\"animations\":{},\"children\":[],\"geometry\":{\"ref\":24}},{\"id\":35,\"type\":\"ScalarKeyFrameAnimation\",\"props\":{\"Duration\":1.3333333},\"animations\":{},\"children\":[],\"frames\":[{\"at\":0,\"value\":1,\"easing\":{\"ref\":15}},{\"at\":0.125,\"value\":0,\"easing\":{\"ref\":15}},{\"at\":0.25,\"value\":1,\"easing\":{\"ref\":15}}]},{\"id\":36,\"type\":\"BooleanKeyFrameAnimation\",\"props\":{\"Duration\":1.3333333},\"animations\":{},\"children\":[],\"frames\":[{\"at\":0.375,\"value\":false}]},{\"id\":37,\"type\":\"ScalarKeyFrameAnimation\",\"props\":{\"Duration\":1.3333333},\"animations\":{},\"children\":[],\"frames\":[{\"at\":0.62500006,\"value\":0,\"easing\":{\"ref\":13}},{\"at\":0.737499952,\"value\":1,\"easing\":{\"ref\":18}},{\"at\":0.87500006,\"value\":0,\"easing\":{\"ref\":13}},{\"at\":0.987499952,\"value\":1,\"easing\":{\"ref\":18}}],\"references\":{\"_\":{\"ref\":1}}}]}"),
	AnimatedChevronDownSmallVisualSource: {
		duration: .4833333,
		frameCount: 29,
		framerate: 60,
		size: [48, 48],
		markers: {
			NormalToPointerOver_Start: 0,
			NormalToPointerOver_End: 0,
			NormalToPressed_Start: 0,
			NormalToPressed_End: .312068965517241,
			PointerOverToNormal_Start: 0,
			PointerOverToNormal_End: 0,
			PointerOverToPressed_Start: 0,
			PointerOverToPressed_End: .312068965517241,
			PressedToNormal_Start: .346551724137931,
			PressedToNormal_End: .967241379310345,
			PressedToPointerOver_Start: .346551724137931,
			PressedToPointerOver_End: .967241379310345
		},
		root: { ref: 1 },
		records: [
			{
				id: 0,
				type: "PropertySet",
				props: { Foreground: [
					0,
					0,
					0,
					255
				] },
				animations: {},
				children: []
			},
			{
				id: 1,
				type: "ContainerVisual",
				props: { Progress: 0 },
				animations: {},
				children: [{ ref: 2 }, { ref: 16 }]
			},
			{
				id: 2,
				type: "ContainerVisual",
				props: {
					Clip: { ref: 3 },
					IsVisible: !1,
					Size: [48, 48],
					TransformMatrix: [
						1,
						0,
						0,
						0,
						0,
						1,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						1
					]
				},
				animations: { IsVisible: { ref: 15 } },
				children: [{ ref: 4 }],
				progressBindings: { IsVisible: { ref: 14 } }
			},
			{
				id: 3,
				type: "InsetClip",
				props: {},
				animations: {},
				children: []
			},
			{
				id: 4,
				type: "ShapeVisual",
				props: { Size: [48, 48] },
				animations: {},
				children: [{ ref: 7 }]
			},
			{
				id: 5,
				type: "Geometry",
				commands: [
					[
						"M",
						-3.85400009,
						-2.10400009
					],
					[
						"C",
						-3.65899992,
						-2.29900002,
						-3.34100008,
						-2.29900002,
						-3.14599991,
						-2.10400009
					],
					[
						"L",
						0,
						1.04299998
					],
					[
						"L",
						3.14599991,
						-2.10400009
					],
					[
						"C",
						3.34100008,
						-2.29900002,
						3.65899992,
						-2.29900002,
						3.85400009,
						-2.10400009
					],
					[
						"C",
						4.04899979,
						-1.90900004,
						4.04899979,
						-1.59099996,
						3.85400009,
						-1.39600003
					],
					[
						"L",
						.354000002,
						2.10400009
					],
					[
						"C",
						.158999994,
						2.29900002,
						-.158999994,
						2.29900002,
						-.354000002,
						2.10400009
					],
					[
						"L",
						-3.85400009,
						-1.39600003
					],
					[
						"C",
						-4.04899979,
						-1.59099996,
						-4.04899979,
						-1.90900004,
						-3.85400009,
						-2.10400009
					],
					["Z"]
				],
				fillRule: "nonzero"
			},
			{
				id: 6,
				type: "PathGeometry",
				props: {},
				animations: {},
				children: [],
				geometry: { ref: 5 }
			},
			{
				id: 7,
				type: "SpriteShape",
				props: {
					Scale: [4, 4],
					FillBrush: { ref: 8 }
				},
				animations: { Offset: { ref: 10 } },
				children: [],
				geometry: { ref: 6 },
				progressBindings: { Offset: { ref: 14 } }
			},
			{
				id: 8,
				type: "ColorBrush",
				props: {},
				animations: {},
				children: [],
				bindings: { Color: {
					expression: "ColorRGB(_theme.Foreground.W,_theme.Foreground.X,_theme.Foreground.Y,_theme.Foreground.Z)",
					parameter: "_theme",
					reference: { ref: 0 }
				} }
			},
			{
				id: 9,
				type: "StepEasingFunction",
				props: { IsFinalStepSingleFrame: !0 },
				animations: {},
				children: []
			},
			{
				id: 10,
				type: "Vector2KeyFrameAnimation",
				props: { Duration: .4833333 },
				animations: {},
				children: [],
				frames: [
					{
						at: 0,
						value: [24, 24],
						easing: { ref: 9 }
					},
					{
						at: .344827592,
						value: [24, 31.5],
						easing: { ref: 11 }
					},
					{
						at: .517241359,
						value: [24, 21],
						easing: { ref: 12 }
					},
					{
						at: 1,
						value: [24, 24],
						easing: { ref: 13 }
					}
				]
			},
			{
				id: 11,
				type: "CubicBezierEasingFunction",
				props: {},
				animations: {},
				children: [],
				points: [
					.166999996,
					.166999996,
					0,
					1
				]
			},
			{
				id: 12,
				type: "CubicBezierEasingFunction",
				props: {},
				animations: {},
				children: [],
				points: [
					.550000012,
					0,
					.75,
					1
				]
			},
			{
				id: 13,
				type: "CubicBezierEasingFunction",
				props: {},
				animations: {},
				children: [],
				points: [
					.349999994,
					0,
					0,
					1
				]
			},
			{
				id: 14,
				type: "ExpressionAnimation",
				props: {},
				animations: {},
				children: [],
				expression: "_.Progress",
				references: { _: { ref: 1 } }
			},
			{
				id: 15,
				type: "BooleanKeyFrameAnimation",
				props: { Duration: .4833333 },
				animations: {},
				children: [],
				frames: [{
					at: .344827592,
					value: !0
				}]
			},
			{
				id: 16,
				type: "ContainerVisual",
				props: {
					Clip: { ref: 3 },
					Size: [48, 48],
					TransformMatrix: [
						1,
						0,
						0,
						0,
						0,
						1,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						1
					]
				},
				animations: { IsVisible: { ref: 22 } },
				children: [{ ref: 17 }],
				progressBindings: { IsVisible: { ref: 14 } }
			},
			{
				id: 17,
				type: "ShapeVisual",
				props: { Size: [48, 48] },
				animations: {},
				children: [{ ref: 18 }]
			},
			{
				id: 18,
				type: "SpriteShape",
				props: {
					Scale: [4, 4],
					FillBrush: { ref: 8 }
				},
				animations: { Offset: { ref: 20 } },
				children: [],
				geometry: { ref: 6 },
				progressBindings: { Offset: { ref: 14 } }
			},
			{
				id: 19,
				type: "CubicBezierEasingFunction",
				props: {},
				animations: {},
				children: [],
				points: [
					.166999996,
					.166999996,
					.833000004,
					.833000004
				]
			},
			{
				id: 20,
				type: "Vector2KeyFrameAnimation",
				props: { Duration: .4833333 },
				animations: {},
				children: [],
				frames: [{
					at: 0,
					value: [24, 24],
					easing: { ref: 19 }
				}, {
					at: .310344815,
					value: [24, 31.5],
					easing: { ref: 21 }
				}]
			},
			{
				id: 21,
				type: "CubicBezierEasingFunction",
				props: {},
				animations: {},
				children: [],
				points: [
					.166999996,
					.166999996,
					.649999976,
					1
				]
			},
			{
				id: 22,
				type: "BooleanKeyFrameAnimation",
				props: { Duration: .4833333 },
				animations: {},
				children: [],
				frames: [{
					at: .344827592,
					value: !1
				}]
			}
		]
	},
	AnimatedChevronRightDownSmallVisualSource: {
		duration: 3.6666666,
		frameCount: 220,
		framerate: 60,
		size: [48, 48],
		markers: {
			NormalOnToNormalOff_Start: 0,
			NormalOnToNormalOff_End: .0411363636363636,
			NormalOnToPointerOverOn_Start: .0456818181818182,
			NormalOnToPointerOverOn_End: .0865909090909091,
			NormalOnToPressedOn_Start: .0911363636363636,
			NormalOnToPressedOn_End: .132045454545455,
			NormalOffToNormalOn_Start: .136590909090909,
			NormalOffToNormalOn_End: .268409090909091,
			NormalOffToPointerOverOff_Start: .272954545454545,
			NormalOffToPointerOverOff_End: .313863636363636,
			NormalOffToPressedOff_Start: .318409090909091,
			NormalOffToPressedOff_End: .359318181818182,
			PointerOverOnToPointerOverOff_Start: .363863636363636,
			PointerOverOnToPointerOverOff_End: .404772727272727,
			PointerOverOnToNormalOn_Start: .409318181818182,
			PointerOverOnToNormalOn_End: .450227272727273,
			PointerOverOnToPressedOn_Start: .454772727272727,
			PointerOverOnToPressedOn_End: .495681818181818,
			PointerOverOffToPointerOverOn_Start: .500227272727273,
			PointerOverOffToPointerOverOn_End: .541136363636364,
			PointerOverOffToNormalOff_Start: .545681818181818,
			PointerOverOffToNormalOff_End: .586590909090909,
			PointerOverOffToPressedOff_Start: .591136363636364,
			PointerOverOffToPressedOff_End: .632045454545455,
			PressedOnToPressedOff_Start: .636590909090909,
			PressedOnToPressedOff_End: .6775,
			PressedOnToPointerOverOff_Start: .682045454545455,
			PressedOnToPointerOverOff_End: .722954545454546,
			PressedOnToNormalOff_Start: .7275,
			PressedOnToNormalOff_End: .768409090909091,
			PressedOffToPressedOn_Start: .772954545454546,
			PressedOffToPressedOn_End: .813863636363636,
			PressedOffToPointerOverOn_Start: .818409090909091,
			PressedOffToPointerOverOn_End: .904772727272727,
			PressedOffToNormalOn_Start: .909318181818182,
			PressedOffToNormalOn_End: .995681818181818
		},
		root: { ref: 1 },
		records: [
			{
				id: 0,
				type: "PropertySet",
				props: { Foreground: [
					0,
					0,
					0,
					255
				] },
				animations: {},
				children: []
			},
			{
				id: 1,
				type: "ContainerVisual",
				props: { Progress: 0 },
				animations: {},
				children: [{ ref: 2 }]
			},
			{
				id: 2,
				type: "ContainerVisual",
				props: {
					Clip: { ref: 3 },
					Size: [48, 48],
					TransformMatrix: [
						1,
						0,
						0,
						0,
						0,
						1,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						1
					]
				},
				animations: {},
				children: [{ ref: 4 }]
			},
			{
				id: 3,
				type: "InsetClip",
				props: {},
				animations: {},
				children: []
			},
			{
				id: 4,
				type: "ShapeVisual",
				props: { Size: [48, 48] },
				animations: {},
				children: [{ ref: 5 }]
			},
			{
				id: 5,
				type: "ContainerShape",
				props: { Scale: [4, 4] },
				animations: {
					RotationAngleInDegrees: { ref: 11 },
					Offset: { ref: 14 }
				},
				children: [{ ref: 9 }],
				progressBindings: {
					RotationAngleInDegrees: { ref: 13 },
					Offset: { ref: 13 }
				}
			},
			{
				id: 6,
				type: "Geometry",
				commands: [
					[
						"M",
						-3.85400009,
						-2.10400009
					],
					[
						"C",
						-3.65899992,
						-2.29900002,
						-3.34100008,
						-2.29900002,
						-3.14599991,
						-2.10400009
					],
					[
						"L",
						0,
						1.04299998
					],
					[
						"L",
						3.14599991,
						-2.10400009
					],
					[
						"C",
						3.34100008,
						-2.29900002,
						3.65899992,
						-2.29900002,
						3.85400009,
						-2.10400009
					],
					[
						"C",
						4.04899979,
						-1.90900004,
						4.04899979,
						-1.59099996,
						3.85400009,
						-1.39600003
					],
					[
						"L",
						.354000002,
						2.10400009
					],
					[
						"C",
						.158999994,
						2.29900002,
						-.158999994,
						2.29900002,
						-.354000002,
						2.10400009
					],
					[
						"L",
						-3.85400009,
						-1.39600003
					],
					[
						"C",
						-4.04899979,
						-1.59099996,
						-4.04899979,
						-1.90900004,
						-3.85400009,
						-2.10400009
					],
					["Z"]
				],
				fillRule: "nonzero"
			},
			{
				id: 7,
				type: "PathGeometry",
				props: {},
				animations: {},
				children: [],
				geometry: { ref: 6 }
			},
			{
				id: 8,
				type: "ColorBrush",
				props: {},
				animations: {},
				children: [],
				bindings: { Color: {
					expression: "ColorRGB(_theme.Foreground.W,_theme.Foreground.X,_theme.Foreground.Y,_theme.Foreground.Z)",
					parameter: "_theme",
					reference: { ref: 0 }
				} }
			},
			{
				id: 9,
				type: "SpriteShape",
				props: {
					TransformMatrix: [
						0,
						-1,
						1,
						0,
						0,
						0
					],
					FillBrush: { ref: 8 }
				},
				animations: {},
				children: [],
				geometry: { ref: 7 }
			},
			{
				id: 10,
				type: "StepEasingFunction",
				props: { IsFinalStepSingleFrame: !0 },
				animations: {},
				children: []
			},
			{
				id: 11,
				type: "ScalarKeyFrameAnimation",
				props: { Duration: 3.6666666 },
				animations: {},
				children: [],
				frames: [
					{
						at: 0,
						value: 90,
						easing: { ref: 10 }
					},
					{
						at: .0409090891,
						value: 0,
						easing: { ref: 12 }
					},
					{
						at: .0454545468,
						value: 90,
						easing: { ref: 10 }
					},
					{
						at: .0909090936,
						value: 90,
						easing: { ref: 10 }
					},
					{
						at: .131818175,
						value: 0,
						easing: { ref: 12 }
					},
					{
						at: .13636364,
						value: 0,
						easing: { ref: 10 }
					},
					{
						at: .181818187,
						value: 90,
						easing: { ref: 12 }
					},
					{
						at: .272727281,
						value: 0,
						easing: { ref: 10 }
					},
					{
						at: .318181813,
						value: 0,
						easing: { ref: 10 }
					},
					{
						at: .359090894,
						value: 90,
						easing: { ref: 12 }
					},
					{
						at: .363636374,
						value: 90,
						easing: { ref: 10 }
					},
					{
						at: .404545456,
						value: 0,
						easing: { ref: 12 }
					},
					{
						at: .409090906,
						value: 90,
						easing: { ref: 10 }
					},
					{
						at: .454545468,
						value: 90,
						easing: { ref: 10 }
					},
					{
						at: .49545455,
						value: 0,
						easing: { ref: 12 }
					},
					{
						at: .5,
						value: 0,
						easing: { ref: 10 }
					},
					{
						at: .540909111,
						value: 90,
						easing: { ref: 12 }
					},
					{
						at: .545454562,
						value: 0,
						easing: { ref: 10 }
					},
					{
						at: .590909064,
						value: 0,
						easing: { ref: 10 }
					},
					{
						at: .631818175,
						value: 90,
						easing: { ref: 12 }
					},
					{
						at: .636363626,
						value: 0,
						easing: { ref: 10 }
					},
					{
						at: .677272737,
						value: 90,
						easing: { ref: 12 }
					},
					{
						at: .681818187,
						value: 0,
						easing: { ref: 10 }
					},
					{
						at: .727272749,
						value: 0,
						easing: { ref: 10 }
					},
					{
						at: .772727251,
						value: 90,
						easing: { ref: 10 }
					},
					{
						at: .813636363,
						value: 0,
						easing: { ref: 12 }
					},
					{
						at: .818181813,
						value: 90,
						easing: { ref: 10 }
					}
				]
			},
			{
				id: 12,
				type: "CubicBezierEasingFunction",
				props: {},
				animations: {},
				children: [],
				points: [
					.166999996,
					.166999996,
					0,
					1
				]
			},
			{
				id: 13,
				type: "ExpressionAnimation",
				props: {},
				animations: {},
				children: [],
				expression: "_.Progress",
				references: { _: { ref: 1 } }
			},
			{
				id: 14,
				type: "Vector2KeyFrameAnimation",
				props: { Duration: 3.6666666 },
				animations: {},
				children: [],
				frames: [
					{
						at: 0,
						value: [24, 24],
						easing: { ref: 10 }
					},
					{
						at: .0454545468,
						value: [24.1709995, 24],
						easing: { ref: 10 }
					},
					{
						at: .13636364,
						value: [24, 24],
						easing: { ref: 10 }
					},
					{
						at: .181818187,
						value: [24, 24],
						easing: { ref: 10 }
					},
					{
						at: .204545453,
						value: [24, 30],
						easing: { ref: 15 }
					},
					{
						at: .268181831,
						value: [24, 24],
						easing: { ref: 16 }
					},
					{
						at: .272727281,
						value: [24.1709995, 24],
						easing: { ref: 10 }
					},
					{
						at: .318181813,
						value: [24.1709995, 24],
						easing: { ref: 10 }
					},
					{
						at: .363636374,
						value: [24, 24],
						easing: { ref: 10 }
					},
					{
						at: .409090906,
						value: [24.1709995, 24],
						easing: { ref: 10 }
					},
					{
						at: .454545468,
						value: [24.1709995, 24],
						easing: { ref: 10 }
					},
					{
						at: .5,
						value: [24, 24],
						easing: { ref: 10 }
					},
					{
						at: .545454562,
						value: [24.1709995, 24],
						easing: { ref: 10 }
					},
					{
						at: .590909064,
						value: [24.1709995, 24],
						easing: { ref: 10 }
					},
					{
						at: .636363626,
						value: [24, 24],
						easing: { ref: 10 }
					},
					{
						at: .818181813,
						value: [24, 24],
						easing: { ref: 10 }
					},
					{
						at: .840909064,
						value: [24, 30],
						easing: { ref: 15 }
					},
					{
						at: .904545426,
						value: [24, 24],
						easing: { ref: 16 }
					},
					{
						at: .909090936,
						value: [24, 24],
						easing: { ref: 10 }
					},
					{
						at: .931818187,
						value: [24, 30],
						easing: { ref: 15 }
					},
					{
						at: .99545455,
						value: [24, 24],
						easing: { ref: 16 }
					}
				]
			},
			{
				id: 15,
				type: "CubicBezierEasingFunction",
				props: {},
				animations: {},
				children: [],
				points: [
					.850000024,
					0,
					.75,
					1
				]
			},
			{
				id: 16,
				type: "CubicBezierEasingFunction",
				props: {},
				animations: {},
				children: [],
				points: [
					.349999994,
					0,
					0,
					1
				]
			}
		]
	},
	AnimatedChevronUpDownSmallVisualSource: {
		duration: 4.3333333,
		frameCount: 260,
		framerate: 60,
		size: [48, 48],
		markers: {
			NormalOnToNormalOff_Start: 0,
			NormalOnToNormalOff_End: .111730769230769,
			NormalOnToPointerOverOn_Start: .115576923076923,
			NormalOnToPointerOverOn_End: .150192307692308,
			NormalOnToPressedOn_Start: .154038461538462,
			NormalOnToPressedOn_End: .188653846153846,
			NormalOffToNormalOn_Start: .1925,
			NormalOffToNormalOn_End: .304038461538462,
			NormalOffToPointerOverOff_Start: .307884615384615,
			NormalOffToPointerOverOff_End: .3425,
			NormalOffToPressedOff_Start: .346346153846154,
			NormalOffToPressedOff_End: .380961538461538,
			PointerOverOnToPointerOverOff_Start: .384807692307692,
			PointerOverOnToPointerOverOff_End: .419423076923077,
			PointerOverOnToNormalOn_Start: .423269230769231,
			PointerOverOnToNormalOn_End: .457884615384615,
			PointerOverOnToPressedOn_Start: .461730769230769,
			PointerOverOnToPressedOn_End: .496346153846154,
			PointerOverOffToPointerOverOn_Start: .500192307692308,
			PointerOverOffToPointerOverOn_End: .534807692307692,
			PointerOverOffToNormalOff_Start: .538653846153846,
			PointerOverOffToNormalOff_End: .573269230769231,
			PointerOverOffToPressedOff_Start: .577115384615385,
			PointerOverOffToPressedOff_End: .611730769230769,
			PressedOnToPressedOff_Start: .615576923076923,
			PressedOnToPressedOff_End: .650192307692308,
			PressedOnToPointerOverOff_Start: .654038461538462,
			PressedOnToPointerOverOff_End: .727115384615385,
			PressedOnToNormalOff_Start: .730961538461539,
			PressedOnToNormalOff_End: .804038461538462,
			PressedOffToPressedOn_Start: .807884615384615,
			PressedOffToPressedOn_End: .8425,
			PressedOffToPointerOverOn_Start: .846346153846154,
			PressedOffToPointerOverOn_End: .919423076923077,
			PressedOffToNormalOn_Start: .923269230769231,
			PressedOffToNormalOn_End: .996346153846154
		},
		root: { ref: 1 },
		records: [
			{
				id: 0,
				type: "PropertySet",
				props: { Foreground: [
					0,
					0,
					0,
					255
				] },
				animations: {},
				children: []
			},
			{
				id: 1,
				type: "ContainerVisual",
				props: { Progress: 0 },
				animations: {},
				children: [{ ref: 2 }]
			},
			{
				id: 2,
				type: "ContainerVisual",
				props: {
					Clip: { ref: 3 },
					Size: [48, 48],
					TransformMatrix: [
						1,
						0,
						0,
						0,
						0,
						1,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						1
					]
				},
				animations: {},
				children: [{ ref: 4 }]
			},
			{
				id: 3,
				type: "InsetClip",
				props: {},
				animations: {},
				children: []
			},
			{
				id: 4,
				type: "ShapeVisual",
				props: { Size: [48, 48] },
				animations: {},
				children: [{ ref: 7 }]
			},
			{
				id: 5,
				type: "Geometry",
				commands: [
					[
						"M",
						-3.54299998,
						-1.79299998
					],
					[
						"L",
						.0199999996,
						1.70700002
					],
					[
						"L",
						3.48900008,
						-1.71500003
					]
				],
				fillRule: "evenodd"
			},
			{
				id: 6,
				type: "PathGeometry",
				props: {},
				animations: {},
				children: [],
				geometry: { ref: 5 }
			},
			{
				id: 7,
				type: "SpriteShape",
				props: {
					Scale: [4, 4],
					StrokeBrush: { ref: 8 },
					StrokeDashCap: "Round",
					StrokeStartCap: "Round",
					StrokeEndCap: "Round",
					StrokeLineJoin: "Round",
					StrokeMiterLimit: 2
				},
				animations: {
					RotationAngleInDegrees: { ref: 10 },
					Offset: { ref: 14 }
				},
				children: [],
				geometry: { ref: 6 },
				progressBindings: {
					RotationAngleInDegrees: { ref: 13 },
					Offset: { ref: 13 }
				}
			},
			{
				id: 8,
				type: "ColorBrush",
				props: {},
				animations: {},
				children: [],
				bindings: { Color: {
					expression: "ColorRGB(_theme.Foreground.W,_theme.Foreground.X,_theme.Foreground.Y,_theme.Foreground.Z)",
					parameter: "_theme",
					reference: { ref: 0 }
				} }
			},
			{
				id: 9,
				type: "StepEasingFunction",
				props: { IsInitialStepSingleFrame: !0 },
				animations: {},
				children: []
			},
			{
				id: 10,
				type: "ScalarKeyFrameAnimation",
				props: { Duration: 4.3333333 },
				animations: {},
				children: [],
				frames: [
					{
						at: 0,
						value: 180,
						easing: { ref: 9 }
					},
					{
						at: .057692308,
						value: 180,
						easing: { ref: 11 }
					},
					{
						at: .0961538479,
						value: 0,
						easing: { ref: 12 }
					},
					{
						at: .115384616,
						value: 180,
						easing: { ref: 11 }
					},
					{
						at: .15384616,
						value: 180,
						easing: { ref: 11 }
					},
					{
						at: .192307696,
						value: 0,
						easing: { ref: 11 }
					},
					{
						at: .25,
						value: 0,
						easing: { ref: 11 }
					},
					{
						at: .288461536,
						value: 180,
						easing: { ref: 12 }
					},
					{
						at: .307692319,
						value: 0,
						easing: { ref: 11 }
					},
					{
						at: .346153855,
						value: 0,
						easing: { ref: 11 }
					},
					{
						at: .384615391,
						value: 180,
						easing: { ref: 11 }
					},
					{
						at: .419230759,
						value: 0,
						easing: { ref: 12 }
					},
					{
						at: .423076928,
						value: 180,
						easing: { ref: 11 }
					},
					{
						at: .461538464,
						value: 180,
						easing: { ref: 11 }
					},
					{
						at: .5,
						value: 0,
						easing: { ref: 11 }
					},
					{
						at: .534615397,
						value: 180,
						easing: { ref: 12 }
					},
					{
						at: .538461566,
						value: 0,
						easing: { ref: 11 }
					},
					{
						at: .576923072,
						value: 0,
						easing: { ref: 11 }
					},
					{
						at: .615384638,
						value: 180,
						easing: { ref: 11 }
					},
					{
						at: .649999976,
						value: 0,
						easing: { ref: 12 }
					},
					{
						at: .653846145,
						value: 180,
						easing: { ref: 11 }
					},
					{
						at: .673076928,
						value: 180,
						easing: { ref: 11 }
					},
					{
						at: .711538434,
						value: 0,
						easing: { ref: 12 }
					},
					{
						at: .730769217,
						value: 180,
						easing: { ref: 11 }
					},
					{
						at: .75,
						value: 180,
						easing: { ref: 11 }
					},
					{
						at: .788461566,
						value: 0,
						easing: { ref: 12 }
					},
					{
						at: .807692289,
						value: 0,
						easing: { ref: 11 }
					},
					{
						at: .842307687,
						value: 180,
						easing: { ref: 12 }
					},
					{
						at: .846153855,
						value: 0,
						easing: { ref: 11 }
					},
					{
						at: .865384638,
						value: 0,
						easing: { ref: 11 }
					},
					{
						at: .903846145,
						value: 180,
						easing: { ref: 12 }
					},
					{
						at: .923076928,
						value: 0,
						easing: { ref: 11 }
					},
					{
						at: .942307711,
						value: 0,
						easing: { ref: 11 }
					},
					{
						at: .980769217,
						value: 180,
						easing: { ref: 12 }
					}
				]
			},
			{
				id: 11,
				type: "StepEasingFunction",
				props: { IsFinalStepSingleFrame: !0 },
				animations: {},
				children: []
			},
			{
				id: 12,
				type: "CubicBezierEasingFunction",
				props: {},
				animations: {},
				children: [],
				points: [
					.166999996,
					.166999996,
					0,
					1
				]
			},
			{
				id: 13,
				type: "ExpressionAnimation",
				props: {},
				animations: {},
				children: [],
				expression: "_.Progress",
				references: { _: { ref: 1 } }
			},
			{
				id: 14,
				type: "Vector2KeyFrameAnimation",
				props: { Duration: 4.3333333 },
				animations: {},
				children: [],
				frames: [
					{
						at: 0,
						value: [24, 24],
						easing: { ref: 11 }
					},
					{
						at: .0384615399,
						value: [24, 26],
						easing: { ref: 12 }
					},
					{
						at: .057692308,
						value: [24, 18],
						easing: { ref: 15 }
					},
					{
						at: .111538462,
						value: [24.1709995, 23.9230003],
						easing: { ref: 16 }
					},
					{
						at: .115384616,
						value: [24, 24],
						easing: { ref: 11 }
					},
					{
						at: .15384616,
						value: [24, 24],
						easing: { ref: 11 }
					},
					{
						at: .188461542,
						value: [24, 26],
						easing: { ref: 12 }
					},
					{
						at: .192307696,
						value: [24, 24],
						easing: { ref: 11 }
					},
					{
						at: .230769232,
						value: [24, 22],
						easing: { ref: 12 }
					},
					{
						at: .25,
						value: [24, 30],
						easing: { ref: 17 }
					},
					{
						at: .303846151,
						value: [24, 24],
						easing: { ref: 16 }
					},
					{
						at: .346153855,
						value: [24, 24],
						easing: { ref: 11 }
					},
					{
						at: .380769223,
						value: [24, 22],
						easing: { ref: 12 }
					},
					{
						at: .384615391,
						value: [24, 24],
						easing: { ref: 11 }
					},
					{
						at: .461538464,
						value: [24, 24],
						easing: { ref: 11 }
					},
					{
						at: .496153831,
						value: [24, 26],
						easing: { ref: 12 }
					},
					{
						at: .5,
						value: [24, 24],
						easing: { ref: 11 }
					},
					{
						at: .576923072,
						value: [24, 24],
						easing: { ref: 11 }
					},
					{
						at: .61153847,
						value: [24, 22],
						easing: { ref: 12 }
					},
					{
						at: .615384638,
						value: [24, 26],
						easing: { ref: 11 }
					},
					{
						at: .649999976,
						value: [24, 22],
						easing: { ref: 12 }
					},
					{
						at: .653846145,
						value: [24, 26],
						easing: { ref: 11 }
					},
					{
						at: .673076928,
						value: [24, 18],
						easing: { ref: 15 }
					},
					{
						at: .726923048,
						value: [24.1709995, 23.9230003],
						easing: { ref: 16 }
					},
					{
						at: .730769217,
						value: [24, 26],
						easing: { ref: 11 }
					},
					{
						at: .75,
						value: [24, 18],
						easing: { ref: 15 }
					},
					{
						at: .80384618,
						value: [24.1709995, 23.9230003],
						easing: { ref: 16 }
					},
					{
						at: .807692289,
						value: [24, 22],
						easing: { ref: 11 }
					},
					{
						at: .842307687,
						value: [24, 26],
						easing: { ref: 12 }
					},
					{
						at: .846153855,
						value: [24, 22],
						easing: { ref: 11 }
					},
					{
						at: .865384638,
						value: [24, 30],
						easing: { ref: 17 }
					},
					{
						at: .919230759,
						value: [24, 24],
						easing: { ref: 16 }
					},
					{
						at: .923076928,
						value: [24, 22],
						easing: { ref: 11 }
					},
					{
						at: .942307711,
						value: [24, 30],
						easing: { ref: 17 }
					},
					{
						at: .996153831,
						value: [24, 24],
						easing: { ref: 16 }
					}
				]
			},
			{
				id: 15,
				type: "CubicBezierEasingFunction",
				props: {},
				animations: {},
				children: [],
				points: [
					.850000024,
					0,
					.75,
					1
				]
			},
			{
				id: 16,
				type: "CubicBezierEasingFunction",
				props: {},
				animations: {},
				children: [],
				points: [
					.349999994,
					0,
					0,
					1
				]
			},
			{
				id: 17,
				type: "CubicBezierEasingFunction",
				props: {},
				animations: {},
				children: [],
				points: [
					.850000024,
					0,
					.449999988,
					1
				]
			}
		]
	},
	AnimatedFindVisualSource: {
		duration: 1.3333333,
		frameCount: 80,
		framerate: 60,
		size: [48, 48],
		markers: {
			NormalToPointerOver_Start: 0,
			NormalToPointerOver_End: .113125,
			NormalToPressed_Start: .125625,
			NormalToPressed_End: .238125,
			PointerOverToNormal_Start: .250625,
			PointerOverToNormal_End: .363125,
			PointerOverToPressed_Start: .375625,
			PointerOverToPressed_End: .488125,
			PressedToNormal_Start: .500625,
			PressedToNormal_End: .738125,
			PressedToPointerOver_Start: .750625,
			PressedToPointerOver_End: .988125
		},
		root: { ref: 1 },
		records: [
			{
				id: 0,
				type: "PropertySet",
				props: { Foreground: [
					0,
					0,
					0,
					255
				] },
				animations: {},
				children: []
			},
			{
				id: 1,
				type: "ContainerVisual",
				props: {
					Progress: 0,
					t0: 0,
					t1: 0,
					t2: 0
				},
				animations: {
					t0: { ref: 24 },
					t1: { ref: 25 },
					t2: { ref: 27 }
				},
				children: [{ ref: 2 }],
				progressBindings: {
					t0: { ref: 12 },
					t1: { ref: 12 },
					t2: { ref: 12 }
				}
			},
			{
				id: 2,
				type: "ContainerVisual",
				props: {
					Clip: { ref: 3 },
					Size: [48, 48],
					TransformMatrix: [
						1,
						0,
						0,
						0,
						0,
						1,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						1
					]
				},
				animations: {},
				children: [{ ref: 4 }, { ref: 13 }]
			},
			{
				id: 3,
				type: "InsetClip",
				props: {},
				animations: {},
				children: []
			},
			{
				id: 4,
				type: "ShapeVisual",
				props: { Size: [48, 48] },
				animations: {},
				children: [{ ref: 7 }]
			},
			{
				id: 5,
				type: "Geometry",
				commands: [
					[
						"M",
						12.9329996,
						278.140015
					],
					[
						"L",
						9.42300034,
						281.64801
					],
					[
						"C",
						9.25599957,
						281.815002,
						9.25599957,
						282.087006,
						9.42300034,
						282.253998
					],
					[
						"C",
						9.57199955,
						282.403015,
						9.80300045,
						282.419006,
						9.97000027,
						282.303009
					],
					[
						"L",
						10.0290003,
						282.253998
					],
					[
						"L",
						13.5340004,
						278.748993
					],
					[
						"C",
						13.5340004,
						278.748993,
						13.3599997,
						278.609985,
						13.1879997,
						278.432007
					],
					[
						"C",
						13.0159998,
						278.253998,
						12.9329996,
						278.140015,
						12.9329996,
						278.140015
					],
					["Z"]
				],
				fillRule: "nonzero"
			},
			{
				id: 6,
				type: "PathGeometry",
				props: {},
				animations: {},
				children: [],
				geometry: { ref: 5 }
			},
			{
				id: 7,
				type: "SpriteShape",
				props: {
					CenterPoint: [13.566, 278.109985],
					Scale: [3, 3],
					FillBrush: { ref: 8 }
				},
				animations: { Offset: { ref: 10 } },
				children: [],
				geometry: { ref: 6 },
				progressBindings: { Offset: { ref: 12 } }
			},
			{
				id: 8,
				type: "ColorBrush",
				props: {},
				animations: {},
				children: [],
				bindings: { Color: {
					expression: "ColorRGB(_theme.Foreground.W,_theme.Foreground.X,_theme.Foreground.Y,_theme.Foreground.Z)",
					parameter: "_theme",
					reference: { ref: 0 }
				} }
			},
			{
				id: 9,
				type: "StepEasingFunction",
				props: { IsFinalStepSingleFrame: !0 },
				animations: {},
				children: []
			},
			{
				id: 10,
				type: "Vector2KeyFrameAnimation",
				props: { Duration: 1.3333333 },
				animations: {},
				children: [],
				frames: [
					{
						at: 0,
						value: [5.64699984, -249.322998],
						easing: { ref: 9 }
					},
					{
						at: .125,
						value: [5.64699984, -249.322998],
						easing: { ref: 9 }
					},
					{
						at: .237499982,
						expression: "Pow(1-_.t0,3)*Vector2(5.647,-249.323)+(3*Square(1-_.t0)*_.t0*Vector2(5.939,-249.615))+(3*(1-_.t0)*Square(_.t0)*Vector2(7.105,-250.781))+(Pow(_.t0,3)*Vector2(7.397,-251.073))",
						easing: { ref: 11 }
					},
					{
						at: .237499997,
						value: [7.39699984, -251.072998],
						easing: { ref: 11 }
					},
					{
						at: .25,
						value: [5.64699984, -249.322998],
						easing: { ref: 9 }
					},
					{
						at: .375,
						value: [5.64699984, -249.322998],
						easing: { ref: 9 }
					},
					{
						at: .487499982,
						expression: "Pow(1-_.t0,3)*Vector2(5.647,-249.323)+(3*Square(1-_.t0)*_.t0*Vector2(5.939,-249.615))+(3*(1-_.t0)*Square(_.t0)*Vector2(7.105,-250.781))+(Pow(_.t0,3)*Vector2(7.397,-251.073))",
						easing: { ref: 11 }
					},
					{
						at: .487500012,
						value: [7.39699984, -251.072998],
						easing: { ref: 11 }
					},
					{
						at: .5,
						value: [7.39699984, -251.072998],
						easing: { ref: 9 }
					},
					{
						at: .56249994,
						expression: "Pow(1-_.t1,3)*Vector2(7.397,-251.073)+(3*Square(1-_.t1)*_.t1*Vector2(6.767,-250.443))+(3*(1-_.t1)*Square(_.t1)*Vector2(3.616,-247.292))+(Pow(_.t1,3)*Vector2(3.616,-247.292))",
						easing: { ref: 11 }
					},
					{
						at: .737499952,
						expression: "Pow(1-_.t1,3)*Vector2(3.616,-247.292)+(3*Square(1-_.t1)*_.t1*Vector2(3.616,-247.292))+(3*(1-_.t1)*Square(_.t1)*Vector2(5.308,-248.984))+(Pow(_.t1,3)*Vector2(5.647,-249.323))",
						easing: { ref: 11 }
					},
					{
						at: .737500012,
						value: [5.64699984, -249.322998],
						easing: { ref: 11 }
					},
					{
						at: .75,
						value: [7.39699984, -251.072998],
						easing: { ref: 9 }
					},
					{
						at: .81249994,
						expression: "Pow(1-_.t2,3)*Vector2(7.397,-251.073)+(3*Square(1-_.t2)*_.t2*Vector2(6.767,-250.443))+(3*(1-_.t2)*Square(_.t2)*Vector2(3.616,-247.292))+(Pow(_.t2,3)*Vector2(3.616,-247.292))",
						easing: { ref: 11 }
					},
					{
						at: .987499952,
						expression: "Pow(1-_.t2,3)*Vector2(3.616,-247.292)+(3*Square(1-_.t2)*_.t2*Vector2(3.616,-247.292))+(3*(1-_.t2)*Square(_.t2)*Vector2(5.308,-248.984))+(Pow(_.t2,3)*Vector2(5.647,-249.323))",
						easing: { ref: 11 }
					},
					{
						at: .987500012,
						value: [5.64699984, -249.322998],
						easing: { ref: 11 }
					}
				],
				references: { _: { ref: 1 } }
			},
			{
				id: 11,
				type: "StepEasingFunction",
				props: { IsInitialStepSingleFrame: !0 },
				animations: {},
				children: []
			},
			{
				id: 12,
				type: "ExpressionAnimation",
				props: {},
				animations: {},
				children: [],
				expression: "_.Progress",
				references: { _: { ref: 1 } }
			},
			{
				id: 13,
				type: "ShapeVisual",
				props: {
					Opacity: .970000029,
					Size: [48, 48]
				},
				animations: {},
				children: [{ ref: 14 }]
			},
			{
				id: 14,
				type: "ContainerShape",
				props: {
					CenterPoint: [3.81299996, -3.93799996],
					Offset: [24, 24]
				},
				animations: {
					"Scale.X": { ref: 21 },
					"Scale.Y": { ref: 21 }
				},
				children: [{ ref: 16 }],
				progressBindings: {
					"Scale.X": { ref: 12 },
					"Scale.Y": { ref: 12 }
				}
			},
			{
				id: 15,
				type: "EllipseGeometry",
				props: { Radius: [14.1875, 14.1875] },
				animations: {},
				children: []
			},
			{
				id: 16,
				type: "SpriteShape",
				props: {
					TransformMatrix: [
						.922860026,
						0,
						0,
						.922860026,
						3.81200004,
						-3.93799996
					],
					StrokeBrush: { ref: 8 }
				},
				animations: { StrokeThickness: { ref: 17 } },
				children: [],
				geometry: { ref: 15 },
				progressBindings: { StrokeThickness: { ref: 12 } }
			},
			{
				id: 17,
				type: "ScalarKeyFrameAnimation",
				props: { Duration: 1.3333333 },
				animations: {},
				children: [],
				frames: [
					{
						at: 0,
						value: 2.5,
						easing: { ref: 9 }
					},
					{
						at: .125,
						value: 2.5,
						easing: { ref: 9 }
					},
					{
						at: .237499997,
						value: 3,
						easing: { ref: 18 }
					},
					{
						at: .25,
						value: 2.5,
						easing: { ref: 9 }
					},
					{
						at: .375,
						value: 2.5,
						easing: { ref: 9 }
					},
					{
						at: .487500012,
						value: 3,
						easing: { ref: 18 }
					},
					{
						at: .5,
						value: 3,
						easing: { ref: 9 }
					},
					{
						at: .5625,
						value: 2.20000005,
						easing: { ref: 19 }
					},
					{
						at: .737500012,
						value: 2.5,
						easing: { ref: 20 }
					},
					{
						at: .75,
						value: 3,
						easing: { ref: 9 }
					},
					{
						at: .8125,
						value: 2.20000005,
						easing: { ref: 19 }
					},
					{
						at: .987500012,
						value: 2.5,
						easing: { ref: 20 }
					}
				]
			},
			{
				id: 18,
				type: "CubicBezierEasingFunction",
				props: {},
				animations: {},
				children: [],
				points: [
					.166999996,
					.166999996,
					0,
					1
				]
			},
			{
				id: 19,
				type: "CubicBezierEasingFunction",
				props: {},
				animations: {},
				children: [],
				points: [
					.550000012,
					0,
					.75,
					1
				]
			},
			{
				id: 20,
				type: "CubicBezierEasingFunction",
				props: {},
				animations: {},
				children: [],
				points: [
					.349999994,
					0,
					0,
					1
				]
			},
			{
				id: 21,
				type: "ScalarKeyFrameAnimation",
				props: { Duration: 1.3333333 },
				animations: {},
				children: [],
				frames: [
					{
						at: 0,
						value: 1,
						easing: { ref: 9 }
					},
					{
						at: .125,
						value: 1,
						easing: { ref: 9 }
					},
					{
						at: .237499997,
						value: .800000012,
						easing: { ref: 22 }
					},
					{
						at: .25,
						value: 1,
						easing: { ref: 9 }
					},
					{
						at: .375,
						value: 1,
						easing: { ref: 9 }
					},
					{
						at: .487500012,
						value: .800000012,
						easing: { ref: 22 }
					},
					{
						at: .5,
						value: .800000012,
						easing: { ref: 9 }
					},
					{
						at: .5625,
						value: 1.20000005,
						easing: { ref: 23 }
					},
					{
						at: .737500012,
						value: 1,
						easing: { ref: 20 }
					},
					{
						at: .75,
						value: .800000012,
						easing: { ref: 9 }
					},
					{
						at: .8125,
						value: 1.20000005,
						easing: { ref: 23 }
					},
					{
						at: .987500012,
						value: 1,
						easing: { ref: 20 }
					}
				]
			},
			{
				id: 22,
				type: "CubicBezierEasingFunction",
				props: {},
				animations: {},
				children: [],
				points: [
					.166999996,
					.166999996,
					.449999988,
					1
				]
			},
			{
				id: 23,
				type: "CubicBezierEasingFunction",
				props: {},
				animations: {},
				children: [],
				points: [
					.449999988,
					0,
					.75,
					1
				]
			},
			{
				id: 24,
				type: "ScalarKeyFrameAnimation",
				props: { Duration: 1.3333333 },
				animations: {},
				children: [],
				frames: [
					{
						at: .125000015,
						value: 0,
						easing: { ref: 11 }
					},
					{
						at: .237499982,
						value: 1,
						easing: { ref: 22 }
					},
					{
						at: .37500003,
						value: 0,
						easing: { ref: 11 }
					},
					{
						at: .487499982,
						value: 1,
						easing: { ref: 22 }
					}
				],
				references: { _: { ref: 1 } }
			},
			{
				id: 25,
				type: "ScalarKeyFrameAnimation",
				props: { Duration: 1.3333333 },
				animations: {},
				children: [],
				frames: [
					{
						at: .50000006,
						value: 0,
						easing: { ref: 11 }
					},
					{
						at: .56249994,
						value: 1,
						easing: { ref: 26 }
					},
					{
						at: .5625,
						value: 0,
						easing: { ref: 11 }
					},
					{
						at: .737499952,
						value: 1,
						easing: { ref: 20 }
					}
				],
				references: { _: { ref: 1 } }
			},
			{
				id: 26,
				type: "CubicBezierEasingFunction",
				props: {},
				animations: {},
				children: [],
				points: [
					.75,
					0,
					.75,
					1
				]
			},
			{
				id: 27,
				type: "ScalarKeyFrameAnimation",
				props: { Duration: 1.3333333 },
				animations: {},
				children: [],
				frames: [
					{
						at: .75000006,
						value: 0,
						easing: { ref: 11 }
					},
					{
						at: .81249994,
						value: 1,
						easing: { ref: 26 }
					},
					{
						at: .8125,
						value: 0,
						easing: { ref: 11 }
					},
					{
						at: .987499952,
						value: 1,
						easing: { ref: 20 }
					}
				],
				references: { _: { ref: 1 } }
			}
		]
	},
	AnimatedGlobalNavigationButtonVisualSource: /* @__PURE__ */ JSON.parse("{\"duration\":1.3333333,\"frameCount\":80,\"framerate\":60,\"size\":[48,48],\"markers\":{\"NormalToPointerOver_Start\":0,\"NormalToPointerOver_End\":0.113125,\"NormalToPressed_Start\":0.125625,\"NormalToPressed_End\":0.238125,\"PointerOverToNormal_Start\":0.250625,\"PointerOverToNormal_End\":0.363125,\"PointerOverToPressed_Start\":0.375625,\"PointerOverToPressed_End\":0.488125,\"PressedToNormal_Start\":0.500625,\"PressedToNormal_End\":0.738125,\"PressedToPointerOver_Start\":0.750625,\"PressedToPointerOver_End\":0.988125},\"root\":{\"ref\":1},\"records\":[{\"id\":0,\"type\":\"PropertySet\",\"props\":{\"Foreground\":[0,0,0,255]},\"animations\":{},\"children\":[]},{\"id\":1,\"type\":\"ContainerVisual\",\"props\":{\"Progress\":0},\"animations\":{},\"children\":[{\"ref\":2},{\"ref\":49}]},{\"id\":2,\"type\":\"ContainerVisual\",\"props\":{\"Clip\":{\"ref\":3},\"IsVisible\":false,\"Size\":[48,48],\"TransformMatrix\":[1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1]},\"animations\":{\"Opacity\":{\"ref\":47},\"IsVisible\":{\"ref\":48}},\"children\":[{\"ref\":4}],\"progressBindings\":{\"Opacity\":{\"ref\":22},\"IsVisible\":{\"ref\":22}}},{\"id\":3,\"type\":\"InsetClip\",\"props\":{},\"animations\":{},\"children\":[]},{\"id\":4,\"type\":\"ShapeVisual\",\"props\":{\"Size\":[48,48]},\"animations\":{},\"children\":[{\"ref\":5},{\"ref\":23},{\"ref\":34}]},{\"id\":5,\"type\":\"ContainerShape\",\"props\":{\"CenterPoint\":[7.5,-5],\"Scale\":[2.75,2.75]},\"animations\":{\"Offset\":{\"ref\":17}},\"children\":[{\"ref\":9},{\"ref\":12},{\"ref\":15}],\"progressBindings\":{\"Offset\":{\"ref\":22}}},{\"id\":6,\"type\":\"Geometry\",\"commands\":[[\"M\",7.5,0.5],[\"C\",7.63500023,0.5,7.75299978,0.451000005,7.85200024,0.351999998],[\"C\",7.95100021,0.252999991,8,0.135000005,8,0],[\"C\",8,-0.135000005,7.95100021,-0.252999991,7.85200024,-0.351999998],[\"C\",7.75299978,-0.451000005,7.63500023,-0.5,7.5,-0.5],[\"L\",7.5,0.5],[\"Z\"]],\"fillRule\":\"nonzero\"},{\"id\":7,\"type\":\"PathGeometry\",\"props\":{},\"animations\":{},\"children\":[],\"geometry\":{\"ref\":6}},{\"id\":8,\"type\":\"ColorBrush\",\"props\":{},\"animations\":{},\"children\":[],\"bindings\":{\"Color\":{\"expression\":\"ColorRGB(_theme.Foreground.W,_theme.Foreground.X,_theme.Foreground.Y,_theme.Foreground.Z)\",\"parameter\":\"_theme\",\"reference\":{\"ref\":0}}}},{\"id\":9,\"type\":\"SpriteShape\",\"props\":{\"TransformMatrix\":[1,0,0,1,0,-10],\"FillBrush\":{\"ref\":8}},\"animations\":{},\"children\":[],\"geometry\":{\"ref\":7}},{\"id\":10,\"type\":\"Geometry\",\"commands\":[[\"M\",7.5,-0.486999989],[\"L\",7.5,0.513000011],[\"C\",7.63500023,0.513000011,7.75299978,0.463,7.85200024,0.363999993],[\"C\",7.95100021,0.264999986,8,0.148000002,8,0.0130000003],[\"C\",8,-0.122000001,7.95100021,-0.239999995,7.85200024,-0.338999987],[\"C\",7.75299978,-0.437999994,7.63500023,-0.486999989,7.5,-0.486999989],[\"Z\"]],\"fillRule\":\"nonzero\"},{\"id\":11,\"type\":\"PathGeometry\",\"props\":{},\"animations\":{},\"children\":[],\"geometry\":{\"ref\":10}},{\"id\":12,\"type\":\"SpriteShape\",\"props\":{\"TransformMatrix\":[1,0,0,1,0,-4.8499999],\"FillBrush\":{\"ref\":8}},\"animations\":{},\"children\":[],\"geometry\":{\"ref\":11}},{\"id\":13,\"type\":\"Geometry\",\"commands\":[[\"M\",7.5,-0.5],[\"L\",7.5,0.5],[\"C\",7.63500023,0.5,7.75299978,0.451000005,7.85200024,0.351999998],[\"C\",7.95100021,0.252999991,8,0.135000005,8,0],[\"C\",8,-0.135000005,7.95100021,-0.252999991,7.85200024,-0.351999998],[\"C\",7.75299978,-0.451000005,7.63500023,-0.5,7.5,-0.5],[\"Z\"]],\"fillRule\":\"nonzero\"},{\"id\":14,\"type\":\"PathGeometry\",\"props\":{},\"animations\":{},\"children\":[],\"geometry\":{\"ref\":13}},{\"id\":15,\"type\":\"SpriteShape\",\"props\":{\"FillBrush\":{\"ref\":8}},\"animations\":{},\"children\":[],\"geometry\":{\"ref\":14}},{\"id\":16,\"type\":\"StepEasingFunction\",\"props\":{\"IsInitialStepSingleFrame\":true},\"animations\":{},\"children\":[]},{\"id\":17,\"type\":\"Vector2KeyFrameAnimation\",\"props\":{\"Duration\":1.3333333},\"animations\":{},\"children\":[],\"frames\":[{\"at\":0,\"value\":[37.5079994,29],\"easing\":{\"ref\":16}},{\"at\":0.125,\"value\":[37.5079994,29],\"easing\":{\"ref\":18}},{\"at\":0.237499997,\"value\":[27.5079994,29],\"easing\":{\"ref\":19}},{\"at\":0.375,\"value\":[37.5079994,29],\"easing\":{\"ref\":18}},{\"at\":0.487500012,\"value\":[27.5079994,29],\"easing\":{\"ref\":19}},{\"at\":0.5,\"value\":[27.5079994,29],\"easing\":{\"ref\":18}},{\"at\":0.600000024,\"value\":[38.5040016,29],\"easing\":{\"ref\":20}},{\"at\":0.737500012,\"value\":[37.5079994,29],\"easing\":{\"ref\":21}},{\"at\":0.75,\"value\":[27.5079994,29],\"easing\":{\"ref\":18}},{\"at\":0.850000024,\"value\":[38.5040016,29],\"easing\":{\"ref\":20}},{\"at\":0.987500012,\"value\":[37.5079994,29],\"easing\":{\"ref\":21}}]},{\"id\":18,\"type\":\"StepEasingFunction\",\"props\":{\"IsFinalStepSingleFrame\":true},\"animations\":{},\"children\":[]},{\"id\":19,\"type\":\"CubicBezierEasingFunction\",\"props\":{},\"animations\":{},\"children\":[],\"points\":[0.166999996,0.166999996,0,1]},{\"id\":20,\"type\":\"CubicBezierEasingFunction\",\"props\":{},\"animations\":{},\"children\":[],\"points\":[0.850000024,0,0.75,1]},{\"id\":21,\"type\":\"CubicBezierEasingFunction\",\"props\":{},\"animations\":{},\"children\":[],\"points\":[0.349999994,0,0,1]},{\"id\":22,\"type\":\"ExpressionAnimation\",\"props\":{},\"animations\":{},\"children\":[],\"expression\":\"_.Progress\",\"references\":{\"_\":{\"ref\":1}}},{\"id\":23,\"type\":\"ContainerShape\",\"props\":{\"CenterPoint\":[-7.5,-5],\"Scale\":[2.75,2.75]},\"animations\":{\"Offset\":{\"ref\":33}},\"children\":[{\"ref\":26},{\"ref\":29},{\"ref\":32}],\"progressBindings\":{\"Offset\":{\"ref\":22}}},{\"id\":24,\"type\":\"Geometry\",\"commands\":[[\"M\",-7.5,0.5],[\"L\",-7.5,-0.5],[\"C\",-7.63500023,-0.5,-7.75299978,-0.451000005,-7.85200024,-0.351999998],[\"C\",-7.95100021,-0.252999991,-8,-0.135000005,-8,0],[\"C\",-8,0.135000005,-7.95100021,0.252999991,-7.85200024,0.351999998],[\"C\",-7.75299978,0.451000005,-7.63500023,0.5,-7.5,0.5],[\"Z\"]],\"fillRule\":\"nonzero\"},{\"id\":25,\"type\":\"PathGeometry\",\"props\":{},\"animations\":{},\"children\":[],\"geometry\":{\"ref\":24}},{\"id\":26,\"type\":\"SpriteShape\",\"props\":{\"TransformMatrix\":[1,0,0,1,0,-10],\"FillBrush\":{\"ref\":8}},\"animations\":{},\"children\":[],\"geometry\":{\"ref\":25}},{\"id\":27,\"type\":\"Geometry\",\"commands\":[[\"M\",-7.5,-0.486999989],[\"C\",-7.63500023,-0.486999989,-7.75299978,-0.437999994,-7.85200024,-0.338999987],[\"C\",-7.95100021,-0.239999995,-8,-0.122000001,-8,0.0130000003],[\"C\",-8,0.148000002,-7.95100021,0.264999986,-7.85200024,0.363999993],[\"C\",-7.75299978,0.463,-7.63500023,0.513000011,-7.5,0.513000011],[\"L\",-7.5,-0.486999989],[\"Z\"]],\"fillRule\":\"nonzero\"},{\"id\":28,\"type\":\"PathGeometry\",\"props\":{},\"animations\":{},\"children\":[],\"geometry\":{\"ref\":27}},{\"id\":29,\"type\":\"SpriteShape\",\"props\":{\"TransformMatrix\":[1,0,0,1,0,-4.8499999],\"FillBrush\":{\"ref\":8}},\"animations\":{},\"children\":[],\"geometry\":{\"ref\":28}},{\"id\":30,\"type\":\"Geometry\",\"commands\":[[\"M\",-7.5,-0.5],[\"C\",-7.63500023,-0.5,-7.75299978,-0.451000005,-7.85200024,-0.351999998],[\"C\",-7.95100021,-0.252999991,-8,-0.135000005,-8,0],[\"C\",-8,0.135000005,-7.95100021,0.252999991,-7.85200024,0.351999998],[\"C\",-7.75299978,0.451000005,-7.63500023,0.5,-7.5,0.5],[\"L\",-7.5,-0.5],[\"Z\"]],\"fillRule\":\"nonzero\"},{\"id\":31,\"type\":\"PathGeometry\",\"props\":{},\"animations\":{},\"children\":[],\"geometry\":{\"ref\":30}},{\"id\":32,\"type\":\"SpriteShape\",\"props\":{\"FillBrush\":{\"ref\":8}},\"animations\":{},\"children\":[],\"geometry\":{\"ref\":31}},{\"id\":33,\"type\":\"Vector2KeyFrameAnimation\",\"props\":{\"Duration\":1.3333333},\"animations\":{},\"children\":[],\"frames\":[{\"at\":0,\"value\":[10.5039997,29],\"easing\":{\"ref\":16}},{\"at\":0.125,\"value\":[10.5039997,29],\"easing\":{\"ref\":18}},{\"at\":0.237499997,\"value\":[20.5079994,29],\"easing\":{\"ref\":19}},{\"at\":0.375,\"value\":[10.5039997,29],\"easing\":{\"ref\":18}},{\"at\":0.487500012,\"value\":[20.5079994,29],\"easing\":{\"ref\":19}},{\"at\":0.5,\"value\":[20.5079994,29],\"easing\":{\"ref\":18}},{\"at\":0.600000024,\"value\":[9.50800037,29],\"easing\":{\"ref\":20}},{\"at\":0.737500012,\"value\":[10.5039997,29],\"easing\":{\"ref\":21}},{\"at\":0.75,\"value\":[20.5079994,29],\"easing\":{\"ref\":18}},{\"at\":0.850000024,\"value\":[9.50800037,29],\"easing\":{\"ref\":20}},{\"at\":0.987500012,\"value\":[10.5039997,29],\"easing\":{\"ref\":21}}]},{\"id\":34,\"type\":\"ContainerShape\",\"props\":{\"CenterPoint\":[0.0480000004,-5],\"Offset\":[23.9559994,29]},\"animations\":{\"Scale.X\":{\"ref\":44},\"Scale.Y\":{\"ref\":45}},\"children\":[{\"ref\":37},{\"ref\":40},{\"ref\":43}],\"progressBindings\":{\"Scale.X\":{\"ref\":22},\"Scale.Y\":{\"ref\":22}}},{\"id\":35,\"type\":\"Geometry\",\"commands\":[[\"M\",-7.60599995,0.5],[\"L\",7.70100021,0.5],[\"L\",7.70100021,-0.5],[\"L\",-7.60599995,-0.5],[\"L\",-7.60599995,0.5],[\"Z\"]],\"fillRule\":\"nonzero\"},{\"id\":36,\"type\":\"PathGeometry\",\"props\":{},\"animations\":{},\"children\":[],\"geometry\":{\"ref\":35}},{\"id\":37,\"type\":\"SpriteShape\",\"props\":{\"TransformMatrix\":[1,0,0,1,0,-10],\"FillBrush\":{\"ref\":8}},\"animations\":{},\"children\":[],\"geometry\":{\"ref\":36}},{\"id\":38,\"type\":\"Geometry\",\"commands\":[[\"M\",7.70100021,-0.486999989],[\"L\",-7.60599995,-0.486999989],[\"L\",-7.60599995,0.513000011],[\"L\",7.70100021,0.513000011],[\"L\",7.70100021,-0.486999989],[\"Z\"]],\"fillRule\":\"nonzero\"},{\"id\":39,\"type\":\"PathGeometry\",\"props\":{},\"animations\":{},\"children\":[],\"geometry\":{\"ref\":38}},{\"id\":40,\"type\":\"SpriteShape\",\"props\":{\"TransformMatrix\":[1,0,0,1,0,-4.8499999],\"FillBrush\":{\"ref\":8}},\"animations\":{},\"children\":[],\"geometry\":{\"ref\":39}},{\"id\":41,\"type\":\"Geometry\",\"commands\":[[\"M\",7.70100021,-0.5],[\"L\",-7.60500002,-0.5],[\"L\",-7.60500002,0.5],[\"L\",7.70100021,0.5],[\"L\",7.70100021,-0.5],[\"Z\"]],\"fillRule\":\"nonzero\"},{\"id\":42,\"type\":\"PathGeometry\",\"props\":{},\"animations\":{},\"children\":[],\"geometry\":{\"ref\":41}},{\"id\":43,\"type\":\"SpriteShape\",\"props\":{\"FillBrush\":{\"ref\":8}},\"animations\":{},\"children\":[],\"geometry\":{\"ref\":42}},{\"id\":44,\"type\":\"ScalarKeyFrameAnimation\",\"props\":{\"Duration\":1.3333333},\"animations\":{},\"children\":[],\"frames\":[{\"at\":0,\"value\":2.74900007,\"easing\":{\"ref\":16}},{\"at\":0.125,\"value\":2.74900007,\"easing\":{\"ref\":18}},{\"at\":0.237499997,\"value\":1.43256998,\"easing\":{\"ref\":19}},{\"at\":0.375,\"value\":2.74900007,\"easing\":{\"ref\":18}},{\"at\":0.487500012,\"value\":1.43256998,\"easing\":{\"ref\":19}},{\"at\":0.5,\"value\":1.43256998,\"easing\":{\"ref\":18}},{\"at\":0.600000024,\"value\":2.88000011,\"easing\":{\"ref\":20}},{\"at\":0.737500012,\"value\":2.74850011,\"easing\":{\"ref\":21}},{\"at\":0.75,\"value\":1.43256998,\"easing\":{\"ref\":18}},{\"at\":0.850000024,\"value\":2.88000011,\"easing\":{\"ref\":20}},{\"at\":0.987500012,\"value\":2.74850011,\"easing\":{\"ref\":21}}]},{\"id\":45,\"type\":\"ScalarKeyFrameAnimation\",\"props\":{\"Duration\":1.3333333},\"animations\":{},\"children\":[],\"frames\":[{\"at\":0,\"value\":2.75,\"easing\":{\"ref\":16}},{\"at\":0.125,\"value\":2.75,\"easing\":{\"ref\":18}},{\"at\":0.237499997,\"value\":2.75,\"easing\":{\"ref\":46}},{\"at\":0.375,\"value\":2.75,\"easing\":{\"ref\":18}},{\"at\":0.487500012,\"value\":2.75,\"easing\":{\"ref\":46}},{\"at\":0.5,\"value\":2.75,\"easing\":{\"ref\":18}},{\"at\":0.600000024,\"value\":2.73294997,\"easing\":{\"ref\":20}},{\"at\":0.737500012,\"value\":2.75,\"easing\":{\"ref\":21}},{\"at\":0.75,\"value\":2.75,\"easing\":{\"ref\":18}},{\"at\":0.850000024,\"value\":2.73294997,\"easing\":{\"ref\":20}},{\"at\":0.987500012,\"value\":2.75,\"easing\":{\"ref\":21}}]},{\"id\":46,\"type\":\"CubicBezierEasingFunction\",\"props\":{},\"animations\":{},\"children\":[],\"points\":[0.166999996,0,0,1]},{\"id\":47,\"type\":\"ScalarKeyFrameAnimation\",\"props\":{\"Duration\":1.3333333},\"animations\":{},\"children\":[],\"frames\":[{\"at\":0,\"value\":1,\"easing\":{\"ref\":16}},{\"at\":0.125,\"value\":1,\"easing\":{\"ref\":18}},{\"at\":0.25,\"value\":0,\"easing\":{\"ref\":18}},{\"at\":0.375,\"value\":1,\"easing\":{\"ref\":18}}]},{\"id\":48,\"type\":\"BooleanKeyFrameAnimation\",\"props\":{\"Duration\":1.3333333},\"animations\":{},\"children\":[],\"frames\":[{\"at\":0.125,\"value\":true}]},{\"id\":49,\"type\":\"ContainerVisual\",\"props\":{\"Clip\":{\"ref\":3},\"Size\":[48,48],\"TransformMatrix\":[1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1]},\"animations\":{\"Opacity\":{\"ref\":66},\"IsVisible\":{\"ref\":67}},\"children\":[{\"ref\":50}],\"progressBindings\":{\"Opacity\":{\"ref\":22},\"IsVisible\":{\"ref\":22}}},{\"id\":50,\"type\":\"ShapeVisual\",\"props\":{\"Size\":[48,48]},\"animations\":{},\"children\":[{\"ref\":51},{\"ref\":52},{\"ref\":53},{\"ref\":54},{\"ref\":55},{\"ref\":56},{\"ref\":59},{\"ref\":62},{\"ref\":65}]},{\"id\":51,\"type\":\"SpriteShape\",\"props\":{\"TransformMatrix\":[2.75,0,0,2.75,24.3829994,10.25],\"FillBrush\":{\"ref\":8}},\"animations\":{},\"children\":[],\"geometry\":{\"ref\":7}},{\"id\":52,\"type\":\"SpriteShape\",\"props\":{\"TransformMatrix\":[2.75,0,0,2.75,24.3829994,24.4125004],\"FillBrush\":{\"ref\":8}},\"animations\":{},\"children\":[],\"geometry\":{\"ref\":11}},{\"id\":53,\"type\":\"SpriteShape\",\"props\":{\"TransformMatrix\":[2.75,0,0,2.75,24.3829994,37.75],\"FillBrush\":{\"ref\":8}},\"animations\":{},\"children\":[],\"geometry\":{\"ref\":14}},{\"id\":54,\"type\":\"SpriteShape\",\"props\":{\"TransformMatrix\":[2.75,0,0,2.75,23.6289997,10.25],\"FillBrush\":{\"ref\":8}},\"animations\":{},\"children\":[],\"geometry\":{\"ref\":25}},{\"id\":55,\"type\":\"SpriteShape\",\"props\":{\"TransformMatrix\":[2.75,0,0,2.75,23.6289997,24.4125004],\"FillBrush\":{\"ref\":8}},\"animations\":{},\"children\":[],\"geometry\":{\"ref\":28}},{\"id\":56,\"type\":\"SpriteShape\",\"props\":{\"TransformMatrix\":[2.75,0,0,2.75,23.6289997,37.75],\"FillBrush\":{\"ref\":8}},\"animations\":{},\"children\":[],\"geometry\":{\"ref\":31}},{\"id\":57,\"type\":\"Geometry\",\"commands\":[[\"M\",-7.5999999,0.5],[\"L\",7.6960001,0.5],[\"L\",7.6960001,-0.5],[\"L\",-7.5999999,-0.5],[\"L\",-7.5999999,0.5],[\"Z\"]],\"fillRule\":\"nonzero\"},{\"id\":58,\"type\":\"PathGeometry\",\"props\":{},\"animations\":{},\"children\":[],\"geometry\":{\"ref\":57}},{\"id\":59,\"type\":\"SpriteShape\",\"props\":{\"TransformMatrix\":[2.74900007,0,0,2.75,23.8720474,10.25],\"FillBrush\":{\"ref\":8}},\"animations\":{},\"children\":[],\"geometry\":{\"ref\":58}},{\"id\":60,\"type\":\"Geometry\",\"commands\":[[\"M\",7.6960001,-0.486999989],[\"L\",-7.5999999,-0.486999989],[\"L\",-7.5999999,0.513000011],[\"L\",7.6960001,0.513000011],[\"L\",7.6960001,-0.486999989],[\"Z\"]],\"fillRule\":\"nonzero\"},{\"id\":61,\"type\":\"PathGeometry\",\"props\":{},\"animations\":{},\"children\":[],\"geometry\":{\"ref\":60}},{\"id\":62,\"type\":\"SpriteShape\",\"props\":{\"TransformMatrix\":[2.74900007,0,0,2.75,23.8720474,24.4125004],\"FillBrush\":{\"ref\":8}},\"animations\":{},\"children\":[],\"geometry\":{\"ref\":61}},{\"id\":63,\"type\":\"Geometry\",\"commands\":[[\"M\",7.6960001,-0.5],[\"L\",-7.59899998,-0.5],[\"L\",-7.59899998,0.5],[\"L\",7.6960001,0.5],[\"L\",7.6960001,-0.5],[\"Z\"]],\"fillRule\":\"nonzero\"},{\"id\":64,\"type\":\"PathGeometry\",\"props\":{},\"animations\":{},\"children\":[],\"geometry\":{\"ref\":63}},{\"id\":65,\"type\":\"SpriteShape\",\"props\":{\"TransformMatrix\":[2.74900007,0,0,2.75,23.8720474,37.75],\"FillBrush\":{\"ref\":8}},\"animations\":{},\"children\":[],\"geometry\":{\"ref\":64}},{\"id\":66,\"type\":\"ScalarKeyFrameAnimation\",\"props\":{\"Duration\":1.3333333},\"animations\":{},\"children\":[],\"frames\":[{\"at\":0,\"value\":1,\"easing\":{\"ref\":18}},{\"at\":0.125,\"value\":0,\"easing\":{\"ref\":18}},{\"at\":0.25,\"value\":1,\"easing\":{\"ref\":18}}]},{\"id\":67,\"type\":\"BooleanKeyFrameAnimation\",\"props\":{\"Duration\":1.3333333},\"animations\":{},\"children\":[],\"frames\":[{\"at\":0.375,\"value\":false}]}]}"),
	AnimatedSettingsVisualSource: /* @__PURE__ */ JSON.parse("{\"duration\":2,\"frameCount\":120,\"framerate\":60,\"size\":[48,48],\"markers\":{\"NormalToPointerOver_Start\":0,\"NormalToPointerOver_End\":0.0754166666666667,\"NormalToPressed_Start\":0.08375,\"NormalToPressed_End\":0.15875,\"PointerOverToNormal_Start\":0.167083333333333,\"PointerOverToNormal_End\":0.242083333333333,\"PointerOverToPressed_Start\":0.250416666666667,\"PointerOverToPressed_End\":0.325416666666667,\"PressedToNormal_Start\":0.33375,\"PressedToNormal_End\":0.65875,\"PressedToPointerOver_Start\":0.667083333333333,\"PressedToPointerOver_End\":0.992083333333333},\"root\":{\"ref\":1},\"records\":[{\"id\":0,\"type\":\"PropertySet\",\"props\":{\"Foreground\":[0,0,0,255]},\"animations\":{},\"children\":[]},{\"id\":1,\"type\":\"ContainerVisual\",\"props\":{\"Progress\":0},\"animations\":{},\"children\":[{\"ref\":2},{\"ref\":20},{\"ref\":25}]},{\"id\":2,\"type\":\"ContainerVisual\",\"props\":{\"Clip\":{\"ref\":3},\"IsVisible\":false,\"Size\":[48,48],\"TransformMatrix\":[1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1]},\"animations\":{\"IsVisible\":{\"ref\":19}},\"children\":[{\"ref\":4}],\"progressBindings\":{\"IsVisible\":{\"ref\":18}}},{\"id\":3,\"type\":\"InsetClip\",\"props\":{},\"animations\":{},\"children\":[]},{\"id\":4,\"type\":\"ShapeVisual\",\"props\":{\"Size\":[48,48]},\"animations\":{},\"children\":[{\"ref\":11}]},{\"id\":5,\"type\":\"Geometry\",\"commands\":[[\"M\",48.8800011,30.9810009],[\"C\",49.1990013,29.9960003,49.7229996,29.0919991,50.4160004,28.3250008],[\"C\",50.5330009,28.1949997,50.7169991,28.1490002,50.8810005,28.2080002],[\"L\",52.5359993,28.7989998],[\"C\",52.9850006,28.9589996,53.4790001,28.7259998,53.6389999,28.2770004],[\"C\",53.6549988,28.2329998,53.6669998,28.1879997,53.6749992,28.1420002],[\"L\",53.9900017,26.4109993],[\"C\",54.0209999,26.2390003,54.1539993,26.1019993,54.3250008,26.066],[\"C\",54.8260002,25.9589996,55.3390007,25.9060001,55.8590012,25.9060001],[\"C\",56.3790016,25.9060001,56.8919983,25.9599991,57.3919983,26.066],[\"C\",57.5629997,26.1019993,57.6949997,26.2390003,57.7260017,26.4109993],[\"L\",58.0419998,28.1420002],[\"C\",58.1279984,28.6110001,58.5769997,28.9209995,59.0460014,28.8360004],[\"C\",59.0919991,28.8279991,59.137001,28.8150005,59.1809998,28.7989998],[\"L\",60.8359985,28.2080002],[\"C\",61,28.1490002,61.1850014,28.1949997,61.3019981,28.3250008],[\"C\",61.9949989,29.0919991,62.519001,29.9960003,62.8380013,30.9810009],[\"C\",62.8919983,31.1469994,62.8390007,31.3299999,62.7060013,31.4430008],[\"L\",61.3650017,32.5810013],[\"C\",61.0019989,32.8889999,60.9580002,33.4350014,61.2659988,33.7980003],[\"C\",61.2960014,33.8339996,61.3289986,33.8670006,61.3650017,33.8969994],[\"L\",62.7060013,35.0359993],[\"C\",62.8390007,35.1489983,62.8919983,35.3310013,62.8380013,35.4970016],[\"C\",62.519001,36.4819984,61.9949989,37.387001,61.3019981,38.1539993],[\"C\",61.1850014,38.2840004,61,38.3300018,60.8359985,38.2709999],[\"L\",59.1809998,37.6790009],[\"C\",58.7319984,37.519001,58.2389984,37.7519989,58.0789986,38.2010002],[\"C\",58.0629997,38.2449989,58.0499992,38.2910004,58.0419998,38.3370018],[\"L\",57.7260017,40.0680008],[\"C\",57.6949997,40.2400017,57.5629997,40.3759995,57.3919983,40.4119987],[\"C\",56.8919983,40.5180016,56.3790016,40.5730019,55.8590012,40.5730019],[\"C\",55.3390007,40.5730019,54.8260002,40.519001,54.3250008,40.4119987],[\"C\",54.1539993,40.3759995,54.0209999,40.2389984,53.9900017,40.0670013],[\"L\",53.6749992,38.3370018],[\"C\",53.5900002,37.868,53.1409988,37.5569992,52.6720009,37.6430016],[\"C\",52.6259995,37.651001,52.5800018,37.6629982,52.5359993,37.6790009],[\"L\",50.8810005,38.2709999],[\"C\",50.7169991,38.3300018,50.5330009,38.2840004,50.4160004,38.1539993],[\"C\",49.7229996,37.387001,49.1990013,36.4819984,48.8800011,35.4970016],[\"C\",48.8260002,35.3310013,48.8779984,35.1489983,49.0110016,35.0359993],[\"L\",50.3520012,33.8969994],[\"C\",50.7150002,33.5890007,50.7599983,33.0439987,50.4519997,32.6809998],[\"C\",50.4220009,32.6450005,50.3880005,32.6110001,50.3520012,32.5810013],[\"L\",49.0110016,31.4430008],[\"C\",48.8779984,31.3299999,48.8260002,31.1469994,48.8800011,30.9810009],[\"Z\"],[\"M\",49.7949982,30.9759998],[\"L\",50.9109993,31.9239998],[\"C\",50.9819984,31.9850006,51.0480003,32.0509987,51.1090012,32.1220016],[\"C\",51.7260017,32.8479996,51.637001,33.9370003,50.9109993,34.5540009],[\"L\",49.7949982,35.5019989],[\"C\",50.0470009,36.1769981,50.4099998,36.8040009,50.8689995,37.3590012],[\"L\",52.2459984,36.8670006],[\"C\",52.3339996,36.8349991,52.4249992,36.8110008,52.5169983,36.7939987],[\"C\",53.4550018,36.6230011,54.3530006,37.2439995,54.5239983,38.1819992],[\"L\",54.7859993,39.6209984],[\"C\",55.1380005,39.6800003,55.4970016,39.7099991,55.8590012,39.7099991],[\"C\",56.2210007,39.7099991,56.5789986,39.6800003,56.9309998,39.6209984],[\"L\",57.1940002,38.1819992],[\"C\",57.2109985,38.0900002,57.2340012,37.9990005,57.2659988,37.9109993],[\"C\",57.5870018,37.0139999,58.5740013,36.5460014,59.4720001,36.8670006],[\"L\",60.848999,37.3590012],[\"C\",61.3069992,36.8040009,61.6710014,36.1769981,61.9230003,35.5019989],[\"L\",60.8069992,34.5540009],[\"C\",60.7360001,34.493,60.6689987,34.4269981,60.6080017,34.355999],[\"C\",59.9910011,33.6300011,60.0810013,32.5410004,60.8069992,31.9239998],[\"L\",61.9230003,30.9759998],[\"C\",61.6710014,30.3010006,61.3069992,29.6739998,60.848999,29.1189995],[\"L\",59.4720001,29.6119995],[\"C\",59.3839989,29.6439991,59.2929993,29.6669998,59.2010002,29.684],[\"C\",58.2639999,29.8549995,57.3650017,29.2339993,57.1940002,28.2970009],[\"L\",56.9309998,26.8570004],[\"C\",56.5789986,26.7980003,56.2210007,26.7679996,55.8590012,26.7679996],[\"C\",55.4970016,26.7679996,55.1380005,26.7980003,54.7859993,26.8570004],[\"L\",54.5239983,28.2959995],[\"C\",54.507,28.3880005,54.4830017,28.4799995,54.4510002,28.5680008],[\"C\",54.1300011,29.4650002,53.1430016,29.9330006,52.2459984,29.6119995],[\"L\",50.8689995,29.1189995],[\"C\",50.4099998,29.6739998,50.0470009,30.3010006,49.7949982,30.9759998],[\"Z\"],[\"M\",53.7019997,33.2389984],[\"C\",53.7019997,32.0480003,54.6679993,31.0820007,55.8590012,31.0820007],[\"C\",57.0499992,31.0820007,58.0159988,32.0480003,58.0159988,33.2389984],[\"C\",58.0159988,34.4300003,57.0499992,35.3959999,55.8590012,35.3959999],[\"C\",54.6679993,35.3959999,53.7019997,34.4300003,53.7019997,33.2389984],[\"Z\"],[\"M\",54.5649986,33.2389984],[\"C\",54.5649986,33.9539986,55.144001,34.5330009,55.8590012,34.5330009],[\"C\",56.5740013,34.5330009,57.1529999,33.9539986,57.1529999,33.2389984],[\"C\",57.1529999,32.5239983,56.5740013,31.9449997,55.8590012,31.9449997],[\"C\",55.144001,31.9449997,54.5649986,32.5239983,54.5649986,33.2389984],[\"Z\"]],\"fillRule\":\"nonzero\"},{\"id\":6,\"type\":\"Geometry\",\"commands\":[[\"M\",48.8800011,30.9810009],[\"C\",49.1990013,29.9960003,49.7229996,29.0919991,50.4160004,28.3250008],[\"C\",50.5330009,28.1949997,50.7169991,28.1490002,50.8810005,28.2080002],[\"L\",52.5359993,28.7989998],[\"C\",52.9850006,28.9589996,53.4790001,28.7259998,53.6389999,28.2770004],[\"C\",53.6549988,28.2329998,53.6669998,28.1879997,53.6749992,28.1420002],[\"L\",53.9900017,26.4109993],[\"C\",54.0209999,26.2390003,54.1539993,26.1019993,54.3250008,26.066],[\"C\",54.8260002,25.9589996,55.3390007,25.9060001,55.8590012,25.9060001],[\"C\",56.3790016,25.9060001,56.8919983,25.9599991,57.3919983,26.066],[\"C\",57.5629997,26.1019993,57.6949997,26.2390003,57.7260017,26.4109993],[\"L\",58.0419998,28.1420002],[\"C\",58.1279984,28.6110001,58.5769997,28.9209995,59.0460014,28.8360004],[\"C\",59.0919991,28.8279991,59.137001,28.8150005,59.1809998,28.7989998],[\"L\",60.8359985,28.2080002],[\"C\",61,28.1490002,61.1850014,28.1949997,61.3019981,28.3250008],[\"C\",61.9949989,29.0919991,62.519001,29.9960003,62.8380013,30.9810009],[\"C\",62.8919983,31.1469994,62.8390007,31.3299999,62.7060013,31.4430008],[\"L\",61.3650017,32.5810013],[\"C\",61.0019989,32.8889999,60.9580002,33.4350014,61.2659988,33.7980003],[\"C\",61.2960014,33.8339996,61.3289986,33.8670006,61.3650017,33.8969994],[\"L\",62.7060013,35.0359993],[\"C\",62.8390007,35.1489983,62.8919983,35.3310013,62.8380013,35.4970016],[\"C\",62.519001,36.4819984,61.9949989,37.387001,61.3019981,38.1539993],[\"C\",61.1850014,38.2840004,61,38.3300018,60.8359985,38.2709999],[\"L\",59.1809998,37.6790009],[\"C\",58.7319984,37.519001,58.2389984,37.7519989,58.0789986,38.2010002],[\"C\",58.0629997,38.2449989,58.0499992,38.2910004,58.0419998,38.3370018],[\"L\",57.7260017,40.0680008],[\"C\",57.6949997,40.2400017,57.5629997,40.3759995,57.3919983,40.4119987],[\"C\",56.8919983,40.5180016,56.3790016,40.5730019,55.8590012,40.5730019],[\"C\",55.3390007,40.5730019,54.8260002,40.519001,54.3250008,40.4119987],[\"C\",54.1539993,40.3759995,54.0209999,40.2389984,53.9900017,40.0670013],[\"L\",53.6749992,38.3370018],[\"C\",53.5900002,37.868,53.1409988,37.5569992,52.6720009,37.6430016],[\"C\",52.6259995,37.651001,52.5800018,37.6629982,52.5359993,37.6790009],[\"L\",50.8810005,38.2709999],[\"C\",50.7169991,38.3300018,50.5330009,38.2840004,50.4160004,38.1539993],[\"C\",49.7229996,37.387001,49.1990013,36.4819984,48.8800011,35.4970016],[\"C\",48.8260002,35.3310013,48.8779984,35.1489983,49.0110016,35.0359993],[\"L\",50.3520012,33.8969994],[\"C\",50.7150002,33.5890007,50.7599983,33.0439987,50.4519997,32.6809998],[\"C\",50.4220009,32.6450005,50.3880005,32.6110001,50.3520012,32.5810013],[\"L\",49.0110016,31.4430008],[\"C\",48.8779984,31.3299999,48.8260002,31.1469994,48.8800011,30.9810009],[\"Z\"]],\"fillRule\":\"nonzero\"},{\"id\":7,\"type\":\"Geometry\",\"commands\":[[\"M\",49.7949982,30.9759998],[\"L\",50.9109993,31.9239998],[\"C\",50.9819984,31.9850006,51.0480003,32.0509987,51.1090012,32.1220016],[\"C\",51.7260017,32.8479996,51.637001,33.9370003,50.9109993,34.5540009],[\"L\",49.7949982,35.5019989],[\"C\",50.0470009,36.1769981,50.4099998,36.8040009,50.8689995,37.3590012],[\"L\",52.2459984,36.8670006],[\"C\",52.3339996,36.8349991,52.4249992,36.8110008,52.5169983,36.7939987],[\"C\",53.4550018,36.6230011,54.3530006,37.2439995,54.5239983,38.1819992],[\"L\",54.7859993,39.6209984],[\"C\",55.1380005,39.6800003,55.4970016,39.7099991,55.8590012,39.7099991],[\"C\",56.2210007,39.7099991,56.5789986,39.6800003,56.9309998,39.6209984],[\"L\",57.1940002,38.1819992],[\"C\",57.2109985,38.0900002,57.2340012,37.9990005,57.2659988,37.9109993],[\"C\",57.5870018,37.0139999,58.5740013,36.5460014,59.4720001,36.8670006],[\"L\",60.848999,37.3590012],[\"C\",61.3069992,36.8040009,61.6710014,36.1769981,61.9230003,35.5019989],[\"L\",60.8069992,34.5540009],[\"C\",60.7360001,34.493,60.6689987,34.4269981,60.6080017,34.355999],[\"C\",59.9910011,33.6300011,60.0810013,32.5410004,60.8069992,31.9239998],[\"L\",61.9230003,30.9759998],[\"C\",61.6710014,30.3010006,61.3069992,29.6739998,60.848999,29.1189995],[\"L\",59.4720001,29.6119995],[\"C\",59.3839989,29.6439991,59.2929993,29.6669998,59.2010002,29.684],[\"C\",58.2639999,29.8549995,57.3650017,29.2339993,57.1940002,28.2970009],[\"L\",56.9309998,26.8570004],[\"C\",56.5789986,26.7980003,56.2210007,26.7679996,55.8590012,26.7679996],[\"C\",55.4970016,26.7679996,55.1380005,26.7980003,54.7859993,26.8570004],[\"L\",54.5239983,28.2959995],[\"C\",54.507,28.3880005,54.4830017,28.4799995,54.4510002,28.5680008],[\"C\",54.1300011,29.4650002,53.1430016,29.9330006,52.2459984,29.6119995],[\"L\",50.8689995,29.1189995],[\"C\",50.4099998,29.6739998,50.0470009,30.3010006,49.7949982,30.9759998],[\"Z\"]],\"fillRule\":\"nonzero\"},{\"id\":8,\"type\":\"Geometry\",\"commands\":[[\"M\",53.7019997,33.2389984],[\"C\",53.7019997,32.0480003,54.6679993,31.0820007,55.8590012,31.0820007],[\"C\",57.0499992,31.0820007,58.0159988,32.0480003,58.0159988,33.2389984],[\"C\",58.0159988,34.4300003,57.0499992,35.3959999,55.8590012,35.3959999],[\"C\",54.6679993,35.3959999,53.7019997,34.4300003,53.7019997,33.2389984],[\"Z\"]],\"fillRule\":\"nonzero\"},{\"id\":9,\"type\":\"Geometry\",\"commands\":[[\"M\",54.5649986,33.2389984],[\"C\",54.5649986,33.9539986,55.144001,34.5330009,55.8590012,34.5330009],[\"C\",56.5740013,34.5330009,57.1529999,33.9539986,57.1529999,33.2389984],[\"C\",57.1529999,32.5239983,56.5740013,31.9449997,55.8590012,31.9449997],[\"C\",55.144001,31.9449997,54.5649986,32.5239983,54.5649986,33.2389984],[\"Z\"]],\"fillRule\":\"nonzero\"},{\"id\":10,\"type\":\"PathGeometry\",\"props\":{},\"animations\":{},\"children\":[],\"geometry\":{\"ref\":5}},{\"id\":11,\"type\":\"SpriteShape\",\"props\":{\"CenterPoint\":[55.8590012,33.2389984],\"Offset\":[-31.8590012,-9.23899841],\"Scale\":[3,3],\"FillBrush\":{\"ref\":12}},\"animations\":{\"RotationAngleInDegrees\":{\"ref\":14}},\"children\":[],\"geometry\":{\"ref\":10},\"progressBindings\":{\"RotationAngleInDegrees\":{\"ref\":18}}},{\"id\":12,\"type\":\"ColorBrush\",\"props\":{},\"animations\":{},\"children\":[],\"bindings\":{\"Color\":{\"expression\":\"ColorRGB(_theme.Foreground.W,_theme.Foreground.X,_theme.Foreground.Y,_theme.Foreground.Z)\",\"parameter\":\"_theme\",\"reference\":{\"ref\":0}}}},{\"id\":13,\"type\":\"StepEasingFunction\",\"props\":{\"IsInitialStepSingleFrame\":true},\"animations\":{},\"children\":[]},{\"id\":14,\"type\":\"ScalarKeyFrameAnimation\",\"props\":{\"Duration\":2},\"animations\":{},\"children\":[],\"frames\":[{\"at\":0,\"value\":0,\"easing\":{\"ref\":13}},{\"at\":0.583333313,\"value\":0,\"easing\":{\"ref\":15}},{\"at\":0.666666687,\"value\":-20,\"easing\":{\"ref\":16}},{\"at\":0.991666675,\"value\":360,\"easing\":{\"ref\":17}}]},{\"id\":15,\"type\":\"StepEasingFunction\",\"props\":{\"IsFinalStepSingleFrame\":true},\"animations\":{},\"children\":[]},{\"id\":16,\"type\":\"CubicBezierEasingFunction\",\"props\":{},\"animations\":{},\"children\":[],\"points\":[0.166999996,0.166999996,1,1]},{\"id\":17,\"type\":\"CubicBezierEasingFunction\",\"props\":{},\"animations\":{},\"children\":[],\"points\":[0,0,0,1]},{\"id\":18,\"type\":\"ExpressionAnimation\",\"props\":{},\"animations\":{},\"children\":[],\"expression\":\"_.Progress\",\"references\":{\"_\":{\"ref\":1}}},{\"id\":19,\"type\":\"BooleanKeyFrameAnimation\",\"props\":{\"Duration\":2},\"animations\":{},\"children\":[],\"frames\":[{\"at\":0.666666687,\"value\":true}]},{\"id\":20,\"type\":\"ContainerVisual\",\"props\":{\"Clip\":{\"ref\":3},\"IsVisible\":false,\"Size\":[48,48],\"TransformMatrix\":[1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1]},\"animations\":{\"IsVisible\":{\"ref\":24}},\"children\":[{\"ref\":21}],\"progressBindings\":{\"IsVisible\":{\"ref\":18}}},{\"id\":21,\"type\":\"ShapeVisual\",\"props\":{\"Size\":[48,48]},\"animations\":{},\"children\":[{\"ref\":22}]},{\"id\":22,\"type\":\"SpriteShape\",\"props\":{\"CenterPoint\":[55.8590012,33.2389984],\"Offset\":[-31.8590012,-9.23899841],\"Scale\":[3,3],\"FillBrush\":{\"ref\":12}},\"animations\":{\"RotationAngleInDegrees\":{\"ref\":23}},\"children\":[],\"geometry\":{\"ref\":10},\"progressBindings\":{\"RotationAngleInDegrees\":{\"ref\":18}}},{\"id\":23,\"type\":\"ScalarKeyFrameAnimation\",\"props\":{\"Duration\":2},\"animations\":{},\"children\":[],\"frames\":[{\"at\":0,\"value\":0,\"easing\":{\"ref\":13}},{\"at\":0.25,\"value\":0,\"easing\":{\"ref\":15}},{\"at\":0.333333343,\"value\":-20,\"easing\":{\"ref\":16}},{\"at\":0.658333361,\"value\":360,\"easing\":{\"ref\":17}}]},{\"id\":24,\"type\":\"BooleanKeyFrameAnimation\",\"props\":{\"Duration\":2},\"animations\":{},\"children\":[],\"frames\":[{\"at\":0.333333343,\"value\":true},{\"at\":0.666666687,\"value\":false}]},{\"id\":25,\"type\":\"ContainerVisual\",\"props\":{\"Clip\":{\"ref\":3},\"Size\":[48,48],\"TransformMatrix\":[1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1]},\"animations\":{\"IsVisible\":{\"ref\":29}},\"children\":[{\"ref\":26}],\"progressBindings\":{\"IsVisible\":{\"ref\":18}}},{\"id\":26,\"type\":\"ShapeVisual\",\"props\":{\"Size\":[48,48]},\"animations\":{},\"children\":[{\"ref\":27}]},{\"id\":27,\"type\":\"SpriteShape\",\"props\":{\"CenterPoint\":[55.8590012,33.2389984],\"Offset\":[-31.8590012,-9.23899841],\"Scale\":[3,3],\"FillBrush\":{\"ref\":12}},\"animations\":{\"RotationAngleInDegrees\":{\"ref\":28}},\"children\":[],\"geometry\":{\"ref\":10},\"progressBindings\":{\"RotationAngleInDegrees\":{\"ref\":18}}},{\"id\":28,\"type\":\"ScalarKeyFrameAnimation\",\"props\":{\"Duration\":2},\"animations\":{},\"children\":[],\"frames\":[{\"at\":0,\"value\":0,\"easing\":{\"ref\":15}},{\"at\":0.0833333358,\"value\":0,\"easing\":{\"ref\":15}},{\"at\":0.158333331,\"value\":-20,\"easing\":{\"ref\":16}},{\"at\":0.166666672,\"value\":0,\"easing\":{\"ref\":15}},{\"at\":0.25,\"value\":0,\"easing\":{\"ref\":15}},{\"at\":0.324999988,\"value\":-20,\"easing\":{\"ref\":16}}]},{\"id\":29,\"type\":\"BooleanKeyFrameAnimation\",\"props\":{\"Duration\":2},\"animations\":{},\"children\":[],\"frames\":[{\"at\":0.333333343,\"value\":false}]}]}")
};
//#endregion
export { e as default };

//# sourceMappingURL=animatedIconVisualData.json.js.map