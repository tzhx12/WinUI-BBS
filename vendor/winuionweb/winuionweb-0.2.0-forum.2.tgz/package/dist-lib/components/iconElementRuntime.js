import { resolveXamlValue as e, updateXamlBinding as t } from "./xamlRuntime.js";
import { frameworkLayoutStyle as n } from "./frameworkLayout.js";
import { textBrush as r, textFontWeight as i } from "./TextInline.js";
/* empty css                      */
import { computed as a, reactive as o, ref as s, watch as c } from "vue";
//#region src/components/iconElementRuntime.ts
var l = {
	Foreground: {
		type: [String, Object],
		default: ""
	},
	Width: {
		type: [String, Number],
		default: ""
	},
	Height: {
		type: [String, Number],
		default: ""
	},
	MinWidth: {
		type: [String, Number],
		default: 0
	},
	MinHeight: {
		type: [String, Number],
		default: 0
	},
	MaxWidth: {
		type: [String, Number],
		default: ""
	},
	MaxHeight: {
		type: [String, Number],
		default: ""
	},
	Margin: {
		type: [String, Number],
		default: 0
	},
	HorizontalAlignment: {
		type: String,
		default: "Stretch"
	},
	VerticalAlignment: {
		type: String,
		default: "Stretch"
	},
	Visibility: {
		type: [String, Boolean],
		default: "Visible"
	},
	Opacity: {
		type: [String, Number],
		default: 1
	},
	IsHitTestVisible: {
		type: [Boolean, String],
		default: !0
	},
	FlowDirection: {
		type: String,
		default: ""
	},
	RequestedTheme: {
		type: String,
		default: "Default"
	}
}, u = (e, t = !1) => e == null || e === "" ? t : e === !0 || e === "True" || e === "true" || e === 1 || e === "1", d = (e) => {
	let t = typeof e == "string" ? e : "";
	return t ? /Segoe (?:Fluent Icons|MDL2 Assets)|SymbolThemeFontFamily/.test(t) ? `${t}, "WinUIOnWebFontIcons"` : t : "\"Segoe Fluent Icons\", \"Segoe MDL2 Assets\", \"WinUIOnWebFontIcons\"";
}, f = i, p = (i, d, f, p = []) => {
	let m = s(null), h = o({}), g = (t) => e(t, f), _ = (e) => e in h ? h[e] : g(i[e]), v = (e) => a({
		get: () => _(e),
		set: (n) => {
			h[e] = n, t(i[e], n, f);
		}
	}), y = [...Object.keys(l), ...p];
	for (let e of y) c(() => g(i[e]), () => {
		delete h[e];
	});
	let b = a(() => {
		let e = {
			flex: "0 0 auto",
			...n(Object.fromEntries(Object.keys(l).map((e) => [e, _(e)])), f)
		}, t = _("Foreground");
		t != null && t !== "" && (e.color = r(t));
		let i = _("FlowDirection");
		return (i === "RightToLeft" || i === "LeftToRight") && (e.direction = i === "RightToLeft" ? "rtl" : "ltr"), u(_("IsHitTestVisible"), !0) || (e.pointerEvents = "none"), (_("Visibility") === !1 || _("Visibility") === "Collapsed") && (e.display = "none"), e;
	}), x = a(() => {
		let e = Object.fromEntries(Object.entries(d).filter(([e]) => ![
			"class",
			"style",
			"AutomationProperties.Name",
			"AutomationProperties.AccessibilityView"
		].includes(e)));
		e.HorizontalAlignment = _("HorizontalAlignment"), e.VerticalAlignment = _("VerticalAlignment"), e["data-stack-panel-width"] = _("Width") === "" ? "Auto" : _("Width"), e["data-stack-panel-height"] = _("Height") === "" ? "Auto" : _("Height");
		let t = g(d["AutomationProperties.Name"]);
		t && (e.role = "img", e["aria-label"] = String(t));
		let n = _("RequestedTheme");
		return (n === "Light" || n === "Dark") && (e["data-theme"] = String(n).toLowerCase(), e.class = `win-theme-scope theme-${String(n).toLowerCase()}`), e;
	}), S = {
		Element: m,
		get ActualWidth() {
			return m.value?.getBoundingClientRect().width ?? 0;
		},
		get ActualHeight() {
			return m.value?.getBoundingClientRect().height ?? 0;
		}
	};
	for (let e of y) Object.defineProperty(S, e, {
		enumerable: !0,
		configurable: !0,
		get: () => _(e),
		set: (n) => {
			h[e] = n, t(i[e], n, f);
		}
	});
	return {
		Element: m,
		property: v,
		read: _,
		resolve: g,
		layoutStyle: b,
		rootAttrs: x,
		api: S
	};
};
//#endregion
export { u as iconBoolean, l as iconElementProps, d as iconFontFamily, f as iconFontWeight, p as useIconElement };

//# sourceMappingURL=iconElementRuntime.js.map