import { alignment as e, cssLength as t } from "./layout.js";
import { normalizeXamlNodes as n, resolveXamlResourceObject as r, resolveXamlValue as i, updateXamlBinding as a, xamlNameScopeKey as o, xamlScopeKey as ee } from "./xamlRuntime.js";
import { frameworkLayoutStyle as s } from "./frameworkLayout.js";
import { createImageSourceModel as c, imageUri as te } from "./imageSource.js";
import ne from "./Grid.vue.js";
import { useI18n as re } from "./i18n/index.js";
import { xamlResourceDictionaryKey as ie } from "./Page.vue_vue_type_script_lang.js";
import ae from "./TextBlock.vue.js";
import oe from "./FontIcon.vue.js";
import se from "./Ellipse.vue.js";
import { initialsFromContactObject as ce, initialsFromDisplayName as le } from "./personPictureInitials.js";
import { PersonPictureBadgeImageSource as ue, PersonPictureProfilePicture as de, personPictureSourceKey as fe } from "./personPictureProperties.js";
import { Fragment as pe, cloneVNode as me, computed as l, defineComponent as he, getCurrentInstance as ge, h as _e, inject as ve, isVNode as ye, onBeforeUnmount as be, onMounted as xe, provide as u, reactive as d, ref as f, shallowRef as p, useAttrs as Se, useSlots as Ce, watch as m } from "vue";
var we = /*@__PURE__*/ he({
	ProfilePicture: de,
	BadgeImageSource: ue,
	inheritAttrs: !1,
	__name: "PersonPicture",
	props: {
		BadgeNumber: {
			type: [String, Number],
			default: 0
		},
		BadgeGlyph: {
			type: String,
			default: ""
		},
		BadgeImageSource: {
			type: [String, Object],
			default: null
		},
		BadgeText: {
			type: String,
			default: ""
		},
		IsGroup: {
			type: [Boolean, String],
			default: !1
		},
		Contact: {
			type: [Object, String],
			default: null
		},
		DisplayName: {
			type: String,
			default: ""
		},
		Initials: {
			type: String,
			default: ""
		},
		PreferSmallImage: {
			type: [Boolean, String],
			default: !1
		},
		ProfilePicture: {
			type: [String, Object],
			default: null
		},
		Width: {
			type: [String, Number],
			default: 96
		},
		Height: {
			type: [String, Number],
			default: 96
		},
		Foreground: {
			type: String,
			default: "{ThemeResource PersonPictureForegroundThemeBrush}"
		},
		Background: {
			type: String,
			default: "{ThemeResource PersonPictureEllipseFillThemeBrush}"
		},
		BorderBrush: {
			type: String,
			default: "{ThemeResource PersonPictureEllipseFillStrokeBrush}"
		},
		BorderThickness: {
			type: [String, Number],
			default: "{ThemeResource PersonPictureEllipseStrokeThickness}"
		},
		FontFamily: {
			type: String,
			default: "{ThemeResource ContentControlThemeFontFamily}"
		},
		FontWeight: {
			type: [String, Number],
			default: "SemiBold"
		},
		IsTabStop: {
			type: [Boolean, String],
			default: !1
		},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		IsHitTestVisible: {
			type: [Boolean, String],
			default: !0
		},
		HorizontalAlignment: {
			type: String,
			default: "Stretch"
		},
		VerticalAlignment: {
			type: String,
			default: "Stretch"
		},
		Margin: {
			type: [String, Number],
			default: ""
		},
		MinWidth: {
			type: [String, Number],
			default: 0
		},
		MinHeight: {
			type: [String, Number],
			default: 0
		},
		MaxWidth: {
			type: [String, Number],
			default: ""
		},
		MaxHeight: {
			type: [String, Number],
			default: ""
		},
		Visibility: {
			type: String,
			default: "Visible"
		},
		Opacity: {
			type: [String, Number],
			default: 1
		}
	},
	emits: /* @__PURE__ */ "update:BadgeNumber.update:BadgeGlyph.update:BadgeImageSource.update:BadgeText.update:IsGroup.update:Contact.update:DisplayName.update:Initials.update:PreferSmallImage.update:ProfilePicture.update:Width.update:Height.update:Foreground.update:Background.update:BorderBrush.update:BorderThickness.update:FontFamily.update:FontWeight.update:IsTabStop.update:IsEnabled.update:IsHitTestVisible.update:HorizontalAlignment.update:VerticalAlignment.update:Margin.update:MinWidth.update:MinHeight.update:MaxWidth.update:MaxHeight.update:Visibility.update:Opacity".split("."),
	setup(we, { expose: Te, emit: Ee }) {
		let h = we, De = Ee, g = ge(), _ = Se(), Oe = Ce(), { t: v } = re(), y = f(null), b = ve(ie, null);
		u(o, d({}));
		let x = d({}), S = (e) => e in x ? x[e] : h[e], C = (e) => i(e, g), w = (e) => C(S(e)), T = (e) => e === !0 || e === "True", E = Object.keys(h), D = d({
			Width: 0,
			Height: 0
		});
		for (let e of E) m(() => h[e], () => {
			delete x[e];
		});
		let O = (e) => l({
			get: () => w(e),
			set: (t) => {
				x[e] = t, (e === "Width" || e === "Height") && (D[e] += 1), a(h[e], t, g), De(`update:${e}`, t);
			}
		}), ke = l({
			get: () => z.value || null,
			set: (e) => {
				O("ProfilePicture").value = e;
			}
		}), Ae = l({
			get: () => B.value || null,
			set: (e) => {
				O("BadgeImageSource").value = e;
			}
		}), k = l(() => {
			let e = w("Contact");
			return e && typeof e == "object" ? e : null;
		}), A = l(() => String(w("DisplayName") ?? "")), j = l(() => String(w("Initials") ?? "")), M = l(() => T(w("IsGroup"))), je = l(() => T(w("IsEnabled"))), Me = l(() => T(w("IsTabStop"))), N = l(() => {
			let e = Number(w("BadgeNumber"));
			return Number.isFinite(e) ? Math.trunc(e) : 0;
		}), P = l(() => String(w("BadgeGlyph") ?? "")), F = l(() => j.value || le(A.value) || ce(k.value)), Ne = l(() => !!F.value), I = {
			ProfilePicture: p(null),
			BadgeImageSource: p(null)
		};
		u(fe, { register: (e, t) => {
			I[e].value = t;
		} });
		let L = (e) => {
			let t = typeof e == "string" ? e.match(/^\{(?:StaticResource|ThemeResource)\s+([^\s}]+)\}$/)?.[1] : void 0;
			return t ? r(t, g) ?? b?.[t] : void 0;
		}, R = (e) => {
			let t = L(e);
			if (ye(t)) return "";
			let n = t ?? C(e);
			return n && typeof n == "object" || typeof n == "string" ? n : "";
		}, Pe = he({
			name: "PersonPictureImageSources",
			setup: () => () => {
				let e = (Oe.default?.() ?? []).filter((e) => {
					let t = e.type?.__personPictureSourceProperty;
					return !t || !(t in x);
				});
				for (let [t, n] of [["ProfilePicture", S("ProfilePicture")], ["BadgeImageSource", S("BadgeImageSource")]]) {
					let r = L(n);
					if (ye(r)) {
						let n = t === "ProfilePicture" ? de : ue;
						e.push(_e(n, null, { default: () => [me(r)] }));
					}
				}
				return _e(pe, n(e, g));
			}
		}), z = l(() => "ProfilePicture" in x ? R(S("ProfilePicture")) : I.ProfilePicture.value?.model ?? R(S("ProfilePicture"))), B = l(() => "BadgeImageSource" in x ? R(S("BadgeImageSource")) : I.BadgeImageSource.value?.model ?? R(S("BadgeImageSource"))), V = (e) => te(e && typeof e == "object" ? e.UriSource : e, g, b), H = p(null), U = 0, W = null, Fe = () => {
			U += 1, W &&= (W.onload = null, W.onerror = null, W.removeAttribute("src"), null);
		}, Ie = l(() => {
			let e = k.value;
			return e ? T(w("PreferSmallImage")) && e.SmallDisplayPicture ? e.SmallDisplayPicture : e.LargeDisplayPicture || e.SmallDisplayPicture || e.SourceDisplayPicture || e.Thumbnail || null : null;
		}), G, K = null, Le = () => {
			Fe();
			let e = U, t = k.value, n = t?.Id, r = !!(K && t && (G || n) && G === n);
			K = t, G = n, r || (H.value = null);
			let i = Ie.value, a = V(i);
			if (!a || typeof window > "u") {
				H.value = a ? i : null;
				return;
			}
			let o = new window.Image();
			W = o, o.onload = () => {
				if (e !== U) return;
				let t = c();
				t.UriSource = a, t.DecodePixelType = "Logical", o.naturalHeight < o.naturalWidth ? t.DecodePixelHeight = Z.value : t.DecodePixelWidth = Z.value, t.__state.pixelWidth = o.naturalWidth, t.__state.pixelHeight = o.naturalHeight, H.value = t, W = null;
			}, o.onerror = () => {
				e === U && (W = null);
			}, o.src = a;
		};
		m(k, Le, {
			immediate: !0,
			deep: !0
		});
		let Re = l(() => V(z.value) ? z.value : H.value), ze = l(() => !!V(Re.value)), q = l(() => M.value ? "Group" : ze.value ? "Photo" : Ne.value ? "Initials" : "NoPhotoOrInitials"), J = l(() => V(B.value) ? "image" : N.value === 0 ? P.value ? "glyph" : "none" : N.value > 0 ? "number" : "none"), Be = l(() => J.value === "none" ? "NoBadge" : J.value === "image" ? "BadgeWithImageSource" : "BadgeWithoutImageSource"), Ve = l(() => N.value > 99 ? "99+" : String(N.value)), Y = (e) => {
			let t = C(e);
			if (t === "" || t == null || t === "Auto") return;
			let n = Number(t);
			return Number.isFinite(n) && n >= 0 ? n : void 0;
		}, X = f(Math.min(Y(h.Width) ?? 96, Y(h.Height) ?? 96)), Z = l(() => {
			let e = Math.max(Y(S("MinWidth")) ?? 0, Y(S("MinHeight")) ?? 0), t = Math.min(Y(S("MaxWidth")) ?? Infinity, Y(S("MaxHeight")) ?? Infinity);
			return Math.max(e, Math.min(X.value, t));
		});
		m([
			() => Y(S("Width")),
			() => Y(S("Height")),
			() => D.Width,
			() => D.Height
		], ([e, t, n, r], [i, a, o, ee]) => {
			let s = e !== i || n !== o, c = s && (t !== a || r !== ee) ? Math.min(e ?? Z.value, t ?? Z.value) : s ? e : t;
			c !== void 0 && (X.value = c);
		});
		let He = f(Z.value), Ue = f(Z.value), Q = null;
		xe(() => {
			if (!y.value) return;
			let e = () => {
				if (!y.value) return;
				let e = y.value.getBoundingClientRect().width, t = y.value.getBoundingClientRect().height;
				He.value = e, Ue.value = t, e !== t && e > 0 && t > 0 && (X.value = Math.min(e, t));
			};
			e(), typeof ResizeObserver < "u" && (Q = new ResizeObserver(e), Q.observe(y.value));
		}), be(() => {
			Fe(), Q?.disconnect(), Q = null;
		});
		let $ = l(() => String(w("FontFamily") || "var(--ContentControlThemeFontFamily)")), We = l(() => ({
			SemiBold: "600",
			Normal: "400",
			Bold: "700",
			Light: "300"
		})[String(w("FontWeight"))] ?? String(w("FontWeight"))), Ge = l(() => ({
			ActualInitials: F.value,
			ActualImageBrush: ze.value ? {
				ImageSource: Re.value,
				Stretch: "UniformToFill"
			} : null
		})), Ke = d({
			get Size() {
				return Z.value;
			},
			get BadgeSize() {
				return Z.value * .5;
			},
			get InitialsFontSize() {
				return Math.max(1, Z.value * .42);
			},
			get BadgeFontSize() {
				return Math.max(1, Z.value * .3);
			},
			get Background() {
				return w("Background");
			},
			get BorderBrush() {
				return w("BorderBrush");
			},
			get BorderThickness() {
				return w("BorderThickness");
			},
			get Foreground() {
				return w("Foreground");
			},
			get ContentFontFamily() {
				return $.value;
			},
			get FontFamily() {
				return q.value === "Group" || q.value === "NoPhotoOrInitials" ? "var(--SymbolThemeFontFamily)" : $.value;
			},
			get FontWeight() {
				return We.value;
			},
			get DisplayedText() {
				return q.value === "Group" ? "" : q.value === "NoPhotoOrInitials" ? "" : F.value;
			},
			get PhotoFill() {
				return Ge.value.ActualImageBrush;
			},
			get BadgeImageBrush() {
				return J.value === "image" ? {
					ImageSource: B.value,
					Stretch: "UniformToFill"
				} : null;
			},
			get BadgeImageOpacity() {
				return J.value === "image" ? C("{ThemeResource PersonPictureEllipseBadgeImageSourceStrokeOpacity}") : 0;
			},
			get BadgeVisibility() {
				return J.value === "none" ? "Collapsed" : "Visible";
			},
			get BadgeNumberVisibility() {
				return J.value === "number" ? "Visible" : "Collapsed";
			},
			get BadgeNumberText() {
				return Ve.value;
			},
			get BadgeGlyph() {
				return J.value === "glyph" ? P.value : "";
			}
		});
		u(ee, { Template: Ke });
		let qe = l(() => Object.fromEntries(Object.entries(_).filter(([e]) => ![
			"class",
			"style",
			"AutomationProperties.Name",
			"AutomationProperties.AccessibilityView"
		].includes(e)))), Je = l(() => {
			let n = s(Object.fromEntries(E.map((e) => [e, S(e)])), g);
			return delete n.background, delete n.borderColor, delete n.borderWidth, {
				...n,
				width: t(Z.value),
				height: t(Z.value),
				flex: "0 0 auto",
				color: String(w("Foreground") || ""),
				fontFamily: $.value,
				fontWeight: We.value,
				justifySelf: e(w("HorizontalAlignment"), "horizontal"),
				alignSelf: e(w("VerticalAlignment"), "vertical"),
				visibility: w("Visibility") === "Hidden" ? "hidden" : void 0,
				pointerEvents: T(w("IsHitTestVisible")) ? void 0 : "none"
			};
		}), Ye = l(() => {
			let e = C(_["AutomationProperties.Name"]);
			if (e) return String(e);
			let t = M.value ? v("control.personpicture.group") : String(k.value?.DisplayName || A.value || j.value || v("control.personpicture.person")), n = String(w("BadgeText") ?? "");
			return N.value > 0 ? v(n ? "control.personpicture.badge-items-text" : N.value === 1 ? "control.personpicture.badge-item" : "control.personpicture.badge-items", {
				name: t,
				count: N.value,
				text: n
			}) : P.value || V(B.value) ? v(n ? "control.personpicture.badge-icon-text" : "control.personpicture.badge-icon", {
				name: t,
				text: n
			}) : t;
		});
		Te({
			...Object.fromEntries(E.map((e) => [e, O(e)])),
			BadgeNumber: O("BadgeNumber"),
			BadgeGlyph: O("BadgeGlyph"),
			BadgeImageSource: Ae,
			BadgeText: O("BadgeText"),
			IsGroup: O("IsGroup"),
			Contact: O("Contact"),
			DisplayName: O("DisplayName"),
			Initials: O("Initials"),
			PreferSmallImage: O("PreferSmallImage"),
			ProfilePicture: ke,
			Width: l({
				get: () => Z.value,
				set: (e) => {
					O("Width").value = e;
				}
			}),
			Height: l({
				get: () => Z.value,
				set: (e) => {
					O("Height").value = e;
				}
			}),
			ActualWidth: He,
			ActualHeight: Ue,
			TemplateSettings: Ge
		});
		let Xe = {
			props: h,
			emit: De,
			instance: g,
			attrs: _,
			slots: Oe,
			t: v,
			root: y,
			resources: b,
			overrides: x,
			raw: S,
			value: C,
			read: w,
			boolean: T,
			publicProperties: E,
			dimensionRevisions: D,
			property: O,
			profilePicture: ke,
			badgeImage: Ae,
			contact: k,
			displayName: A,
			initials: j,
			isGroup: M,
			isEnabled: je,
			isTabStop: Me,
			badgeNumber: N,
			badgeGlyph: P,
			actualInitials: F,
			hasInitials: Ne,
			sourceRegistrations: I,
			sourceResource: L,
			sourceModel: R,
			SourceOutlet: Pe,
			explicitProfileSource: z,
			explicitBadgeSource: B,
			uriOf: V,
			contactImage: H,
			get loadGeneration() {
				return U;
			},
			set loadGeneration(e) {
				U = e;
			},
			get imageLoader() {
				return W;
			},
			set imageLoader(e) {
				W = e;
			},
			cancelContactImage: Fe,
			contactCandidate: Ie,
			get previousContactId() {
				return G;
			},
			set previousContactId(e) {
				G = e;
			},
			get previousContact() {
				return K;
			},
			set previousContact(e) {
				K = e;
			},
			loadContactImage: Le,
			actualProfileSource: Re,
			hasPhoto: ze,
			commonState: q,
			badgeKind: J,
			badgeState: Be,
			badgeNumberText: Ve,
			finiteDimension: Y,
			requestedSize: X,
			size: Z,
			actualWidth: He,
			actualHeight: Ue,
			get observer() {
				return Q;
			},
			set observer(e) {
				Q = e;
			},
			contentFontFamily: $,
			fontWeight: We,
			templateSettings: Ge,
			template: Ke,
			rootAttrs: qe,
			rootStyle: Je,
			automationLabel: Ye,
			Ellipse: se,
			FontIcon: oe,
			Grid: ne,
			TextBlock: ae
		};
		return Object.defineProperty(Xe, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), Xe;
	}
});
//#endregion
export { we as default };

//# sourceMappingURL=PersonPicture.vue_vue_type_script_setup_true_lang.js.map