//#region src/components/swipeInteractionTracker.ts
var e = (e, t) => Math.max(t.minimum, Math.min(t.maximum, e)), t = -Math.log(.9) / (1e3 / 60), n = .024, r = .05, i = .001, a = class {
	readPosition;
	writePosition;
	frame = 0;
	generation = 0;
	finish;
	constructor(e, t) {
		this.readPosition = e, this.writePosition = t;
	}
	get Position() {
		return this.readPosition();
	}
	NaturalRestingPosition(e) {
		return this.Position + e / t;
	}
	TryUpdatePosition(t, n) {
		this.writePosition(e(t, n));
	}
	Cancel() {
		this.generation += 1, cancelAnimationFrame(this.frame);
		let e = this.finish;
		this.finish = void 0, e?.(!1);
	}
	Settle(t, a, o) {
		this.Cancel();
		let s = this.generation, c = e(t, o), l = this.Position - c, u = performance.now(), d = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
		return new Promise((t) => {
			this.finish = t;
			let f = () => {
				this.writePosition(c), this.finish = void 0, t(!0);
			}, p = (t) => {
				if (s !== this.generation) return;
				if (d) {
					f();
					return;
				}
				let m = Math.max(0, t - u), h = n, g = Math.exp(-.024 * m), _ = a + h * l, v = (l + _ * m) * g, y = (a - h * _ * m) * g;
				this.writePosition(e(c + v, o)), Math.abs(v) <= r && Math.abs(y) <= i ? f() : this.frame = requestAnimationFrame(p);
			};
			this.frame = requestAnimationFrame(p);
		});
	}
};
//#endregion
export { a as BrowserSwipeInteractionTracker };

//# sourceMappingURL=swipeInteractionTracker.js.map