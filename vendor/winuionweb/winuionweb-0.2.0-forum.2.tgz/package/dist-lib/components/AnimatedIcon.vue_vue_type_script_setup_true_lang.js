import { resolveXamlValue as e, updateXamlBinding as t } from "./xamlRuntime.js";
import { frameworkLayoutStyle as n } from "./frameworkLayout.js";
import r from "./BitmapIcon.vue.js";
import i from "./SymbolIcon.vue.js";
import a from "./PathIcon.vue.js";
import o from "./FontIcon.vue.js";
import { getAnimatedIconVisualSource as s } from "./animatedIconVisuals.js";
import { GetState as c, SetState as l, findAnimatedIconStateAncestor as ee, subscribeAnimatedIconState as te } from "./animatedIconRuntime.js";
import { Fragment as ne, computed as u, defineComponent as d, getCurrentInstance as re, h as ie, isVNode as ae, onBeforeUnmount as oe, onMounted as se, ref as f, shallowReactive as ce, shallowRef as le, useAttrs as ue, useSlots as de, watch as p } from "vue";
//#region src/components/AnimatedIcon.vue?vue&type=script&setup=true&lang.ts
var fe = d({
	name: "AnimatedIcon.Source",
	__animatedIconProperty: "Source",
	setup() {
		return () => null;
	}
}), pe = d({
	name: "AnimatedIcon.FallbackIconSource",
	__animatedIconProperty: "FallbackIconSource",
	setup() {
		return () => null;
	}
}), me = /*@__PURE__*/ d({
	Source: fe,
	FallbackIconSource: pe,
	SetState: l,
	GetState: c,
	name: "AnimatedIcon",
	inheritAttrs: !1,
	__name: "AnimatedIcon",
	props: {
		Source: {
			type: null,
			default: void 0
		},
		FallbackIconSource: {
			type: null,
			default: void 0
		},
		Foreground: {
			type: String,
			default: ""
		},
		MirroredWhenRightToLeft: {
			type: [Boolean, String],
			default: !1
		},
		FlowDirection: {
			type: String,
			default: ""
		},
		Width: {
			type: [String, Number],
			default: ""
		},
		Height: {
			type: [String, Number],
			default: ""
		},
		MinWidth: {
			type: [String, Number],
			default: ""
		},
		MinHeight: {
			type: [String, Number],
			default: ""
		},
		MaxWidth: {
			type: [String, Number],
			default: ""
		},
		MaxHeight: {
			type: [String, Number],
			default: ""
		},
		Margin: {
			type: [String, Number],
			default: ""
		},
		HorizontalAlignment: {
			type: String,
			default: "Stretch"
		},
		VerticalAlignment: {
			type: String,
			default: "Stretch"
		},
		Visibility: {
			type: String,
			default: "Visible"
		},
		IsHitTestVisible: {
			type: [Boolean, String],
			default: !0
		},
		Opacity: {
			type: [String, Number],
			default: 1
		}
	},
	emits: [
		"update:Source",
		"update:FallbackIconSource",
		"update:Foreground",
		"update:MirroredWhenRightToLeft"
	],
	setup(me, { expose: he, emit: ge }) {
		let m = me, _e = ge, h = ue(), ve = de(), g = re(), _ = f(null), v = (t) => e(t, g), y = ce({}), b = (e) => e in y ? y[e] : v(m[e]), x = (e) => u({
			get: () => e === "Source" ? D.value : e === "FallbackIconSource" ? O.value && {
				kind: O.value.kind,
				...O.value.props
			} : b(e),
			set: (n) => {
				y[e] = n, t(m[e], n, g), _e(`update:${e}`, n);
			}
		});
		for (let e of [
			"Source",
			"FallbackIconSource",
			"Foreground",
			"MirroredWhenRightToLeft"
		]) p(() => v(m[e]), () => {
			delete y[e];
		});
		let S = le({
			sourceName: "",
			fallback: null
		}), C = (e) => {
			let t = Array.isArray(e.children) ? e.children : e.children?.default?.();
			return Array.isArray(t) ? t.filter(ae) : ae(t) ? [t] : [];
		}, w = (e) => e.flatMap((e) => e.type === ne ? w(C(e)) : [e]), T = (e) => E(e).replace(/^.*:/, ""), E = (e) => {
			if (typeof e == "string") return e;
			if (!e || typeof e != "object") return "";
			let t = e;
			return String(t.__animatedIconVisualSourceName ?? t.__animatedVisualSourceName ?? t.name ?? t.type ?? t.$type ?? t.__name ?? "");
		}, ye = (e, t) => {
			if (!e || !t) return e === t;
			let n = Object.keys(e.props);
			return e.kind === t.kind && n.length === Object.keys(t.props).length && n.every((n) => e.props[n] === t.props[n]);
		}, be = d({
			name: "AnimatedIconDeclarationOutlet",
			setup() {
				return () => {
					let e = "", t = null;
					for (let n of w(ve.default?.() ?? [])) {
						let r = T(n.type), i = n.type?.__animatedIconProperty ?? (r === "AnimatedIcon.Source" ? "Source" : r === "AnimatedIcon.FallbackIconSource" ? "FallbackIconSource" : void 0), a = w(C(n))[0];
						/^Animated.*VisualSource$/.test(r) && (e = r), i === "Source" && a && (e = T(a.type)), i === "FallbackIconSource" && a && (t = {
							kind: a.type?.__iconSourceKind ?? E(a.type).replace(/Source$/, ""),
							props: { ...a.props }
						});
					}
					return (e !== S.value.sourceName || !ye(t, S.value.fallback)) && (S.value = {
						sourceName: e,
						fallback: t
					}), null;
				};
			}
		}), D = u(() => {
			let e = "Source" in y || m.Source !== void 0 ? b("Source") : S.value.sourceName;
			if (e && typeof e == "object" && typeof e.render == "function") return e;
			let t = E(e).replace(/^.*:/, "");
			if (!/^Animated(?:Accept|Back|ChevronDownSmall|ChevronRightDownSmall|ChevronUpDownSmall|Find|GlobalNavigationButton|Settings)VisualSource$/.test(t)) return null;
			try {
				return s(t) ?? null;
			} catch {
				return null;
			}
		}), O = u(() => {
			if (!("FallbackIconSource" in y) && m.FallbackIconSource === void 0) return S.value.fallback;
			let e = b("FallbackIconSource");
			if (!e || typeof e != "object") return null;
			let t = e;
			return {
				kind: String(t.__iconSourceKind ?? t.kind ?? E(t).replace(/Source$/, "")),
				props: t
			};
		}), xe = d({
			name: "AnimatedIconFallbackOutlet",
			setup() {
				return () => {
					let e = O.value;
					if (!e) return null;
					let t = {
						SymbolIcon: i,
						FontIcon: o,
						PathIcon: a,
						BitmapIcon: r
					}[e.kind];
					return t ? ie(t, Object.fromEntries(Object.entries(e.props).map(([e, t]) => [e, v(t)]))) : null;
				};
			}
		}), k = f(0), A = f(""), Se = f(""), j = f(!1), M = null, N = null, P = null, F = 0, I = 1, L = 0, R = [], z = !1, B = f(!1), V = null, H = null, U = null, W = null, G = f(0), K = (e) => Math.max(0, Math.min(1, e)), q = () => {
			F += 1, P !== null && cancelAnimationFrame(P), P = null, j.value = !1;
		}, J = () => {
			P = null, j.value = !1;
			let e = R.shift();
			e !== void 0 && Z(e);
		}, Y = (e, t) => {
			q();
			let n = e === null ? k.value : K(e), r = K(t);
			L = r, e !== null && (I = Math.abs(t - e));
			let i = (D.value?.duration ?? 0) * I * 1e3;
			if (e !== null && (k.value = n), i < 20 || B.value) {
				k.value = r, J();
				return;
			}
			j.value = !0;
			let a = F, o = performance.now(), s = (e) => {
				if (z || a !== F) return;
				let t = Math.min(1, Math.max(0, (e - o) / i));
				k.value = n + (r - n) * t, t < 1 ? P = requestAnimationFrame(s) : J();
			};
			P = requestAnimationFrame(s);
		}, X = (e) => {
			q(), k.value = K(e), L = k.value, J();
		};
		function Z(e) {
			let t = A.value;
			Se.value = t, A.value = e;
			let n = D.value;
			if (!n) {
				q(), J();
				return;
			}
			let r = n.markers, i = `${t}To${e}`, a = r[`${i}_Start`], o = r[`${i}_End`];
			if (a !== void 0 && o !== void 0) {
				Y(a, o);
				return;
			}
			if (o !== void 0) {
				X(o);
				return;
			}
			if (a !== void 0) {
				X(a);
				return;
			}
			if (r[i] !== void 0) {
				X(r[i]);
				return;
			}
			if (r[e] !== void 0) {
				X(r[e]);
				return;
			}
			let s = Object.keys(r).sort().find((t) => t.includes(`To${e}_End`));
			if (s) {
				X(r[s]);
				return;
			}
			let c = e.trim();
			c && /^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$/.test(c) ? Y(null, Number(c)) : X(0);
		}
		let Ce = (e) => {
			M = e, !(N !== null || z) && (N = requestAnimationFrame(() => {
				N = null;
				let e = M;
				if (M = null, !(e === null || z)) if (j.value) if (R.length >= 4) {
					let t = R.shift();
					R.push(e), t !== void 0 && Z(t);
				} else R.push(e);
				else Z(e);
			}));
		}, we = u(() => Object.fromEntries(Object.entries(h).filter(([e]) => e !== "AnimatedIcon.State"))), Te = u(() => `0 0 ${D.value?.size.width ?? 48} ${D.value?.size.height ?? 48}`), Ee = u(() => D.value?.render(k.value, String(b("Foreground") || "currentColor")) ?? ""), Q = (e) => e != null && e !== "" && e !== "Auto", De = (e) => {
			let t = String(e ?? "").trim();
			return /^\d+(?:\.\d+)?(?:px)?$/.test(t) ? Number.parseFloat(t) : null;
		}, Oe = u(() => {
			let e = D.value, t = v(m.Width), r = v(m.Height), i = De(t), a = De(r);
			return {
				...e ? {
					width: !Q(t) && a !== null ? `${a * e.size.width / e.size.height}px` : `${e.size.width}px`,
					height: !Q(r) && i !== null ? `${i * e.size.height / e.size.width}px` : Q(t) ? "auto" : `${e.size.height}px`,
					aspectRatio: `${e.size.width} / ${e.size.height}`
				} : {},
				...n(m, g),
				pointerEvents: v(m.IsHitTestVisible) === !1 || v(m.IsHitTestVisible) === "False" ? "none" : void 0,
				color: b("Foreground") ? String(b("Foreground")) : void 0,
				direction: b("FlowDirection") === "RightToLeft" ? "rtl" : b("FlowDirection") === "LeftToRight" ? "ltr" : void 0
			};
		}), ke = u(() => {
			G.value;
			let e = b("FlowDirection") || (_.value && getComputedStyle(_.value).direction === "rtl" ? "RightToLeft" : "LeftToRight"), t = b("MirroredWhenRightToLeft");
			return { transform: e === "RightToLeft" && t !== !0 && t !== "True" ? "scaleX(-1)" : void 0 };
		});
		p(() => v(h["AnimatedIcon.State"]), (e) => {
			e !== void 0 && _.value && l(_.value, e);
		});
		let $ = () => {
			B.value = V?.matches ?? !1, B.value && j.value && (q(), k.value = L, J());
		};
		p(D, (e, t) => {
			e !== t && (q(), R.length = 0, e && A.value ? Z(A.value) : e || (k.value = 0));
		}), se(() => {
			let e = _.value;
			if (!e) return;
			V = window.matchMedia("(prefers-reduced-motion: reduce)"), B.value = V.matches, V.addEventListener("change", $);
			let t = v(h["AnimatedIcon.State"]);
			t !== void 0 && l(e, t), H = ee(e), !c(e) && H && l(e, c(H)), A.value = c(e), U = te(e, (t) => {
				t.Target === e ? Ce(t.State) : (H ||= ee(e), t.Target === H && l(e, t.State));
			}), A.value && Ce(A.value), W = new MutationObserver(() => {
				G.value += 1;
			});
			let n = e;
			for (; n;) W.observe(n, {
				attributes: !0,
				attributeFilter: [
					"dir",
					"class",
					"style"
				]
			}), n = n.parentElement;
			G.value += 1;
		}), oe(() => {
			z = !0, N !== null && cancelAnimationFrame(N), q(), R.length = 0, U?.(), W?.disconnect(), V?.removeEventListener("change", $);
		}), he({
			Source: x("Source"),
			FallbackIconSource: x("FallbackIconSource"),
			Foreground: x("Foreground"),
			MirroredWhenRightToLeft: x("MirroredWhenRightToLeft"),
			Element: u(() => _.value),
			$el: u(() => _.value)
		});
		let Ae = {
			Source: fe,
			FallbackIconSource: pe,
			props: m,
			emit: _e,
			attrs: h,
			slots: ve,
			instance: g,
			rootElement: _,
			resolve: v,
			overrides: y,
			propertyValue: b,
			dependencyProperty: x,
			declaration: S,
			childrenOf: C,
			flatten: w,
			localTypeName: T,
			typeName: E,
			sameFallback: ye,
			DeclarationOutlet: be,
			visualSource: D,
			fallbackSource: O,
			FallbackOutlet: xe,
			progress: k,
			currentState: A,
			previousState: Se,
			isPlaying: j,
			get pendingState() {
				return M;
			},
			set pendingState(e) {
				M = e;
			},
			get pendingFrame() {
				return N;
			},
			set pendingFrame(e) {
				N = e;
			},
			get playbackFrame() {
				return P;
			},
			set playbackFrame(e) {
				P = e;
			},
			get playbackGeneration() {
				return F;
			},
			set playbackGeneration(e) {
				F = e;
			},
			get previousSegmentLength() {
				return I;
			},
			set previousSegmentLength(e) {
				I = e;
			},
			get segmentEnd() {
				return L;
			},
			set segmentEnd(e) {
				L = e;
			},
			queuedStates: R,
			get disposed() {
				return z;
			},
			set disposed(e) {
				z = e;
			},
			reducedMotion: B,
			get motionQuery() {
				return V;
			},
			set motionQuery(e) {
				V = e;
			},
			get watchedAncestor() {
				return H;
			},
			set watchedAncestor(e) {
				H = e;
			},
			get unsubscribeState() {
				return U;
			},
			set unsubscribeState(e) {
				U = e;
			},
			get directionObserver() {
				return W;
			},
			set directionObserver(e) {
				W = e;
			},
			directionRevision: G,
			clampProgress: K,
			cancelPlayback: q,
			completePlayback: J,
			playSegment: Y,
			jumpTo: X,
			transitionTo: Z,
			requestState: Ce,
			elementAttrs: we,
			viewBox: Te,
			visualMarkup: Ee,
			explicitLength: Q,
			numericLength: De,
			iconStyle: Oe,
			visualStyle: ke,
			onReducedMotion: $
		};
		return Object.defineProperty(Ae, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), Ae;
	}
});
//#endregion
export { me as default };

//# sourceMappingURL=AnimatedIcon.vue_vue_type_script_setup_true_lang.js.map