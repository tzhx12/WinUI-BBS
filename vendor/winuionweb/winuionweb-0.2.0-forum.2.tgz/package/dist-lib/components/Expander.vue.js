import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./Expander.vue_vue_type_script_setup_true_lang.js";
import { createBlock as n, createCommentVNode as r, createSlots as i, createVNode as a, mergeProps as o, openBlock as s, withCtx as c } from "vue";
//#region src/components/Expander.vue
function l(e, t, l, u, d, f) {
	return s(), n(u.ExpanderBase, o({ ref: "expanderBase" }, e.$attrs, {
		Header: l.Header,
		Content: l.Content,
		Description: l.Description,
		HeaderIcon: l.HeaderIcon,
		IsExpanded: l.IsExpanded,
		ExpandDirection: l.ExpandDirection,
		Padding: l.Padding,
		Background: l.Background,
		BorderBrush: l.BorderBrush,
		BorderThickness: l.BorderThickness,
		CornerRadius: l.CornerRadius,
		IsEnabled: l.IsEnabled,
		HorizontalContentAlignment: l.HorizontalContentAlignment,
		VerticalContentAlignment: l.VerticalContentAlignment,
		Width: l.Width,
		MinWidth: l.MinWidth,
		Height: l.Height,
		MaxWidth: l.MaxWidth,
		HorizontalAlignment: l.HorizontalAlignment,
		VerticalAlignment: l.VerticalAlignment,
		"onUpdate:IsExpanded": t[0] ||= (t) => e.$emit("update:IsExpanded", t),
		onExpanding: u.forwardExpanding,
		onCollapsed: u.forwardCollapsed
	}), i({
		default: c(() => [u.contentNodes.length ? (s(), n(u.ContentOutlet, { key: 0 })) : r("", !0)]),
		_: 2
	}, [
		u.headerNodes.length ? {
			name: "Header",
			fn: c(() => [a(u.HeaderOutlet)]),
			key: "0"
		} : void 0,
		u.descriptionNodes.length ? {
			name: "Description",
			fn: c(() => [a(u.DescriptionOutlet)]),
			key: "1"
		} : void 0,
		u.headerIconNodes.length ? {
			name: "HeaderIcon",
			fn: c(() => [a(u.HeaderIconOutlet)]),
			key: "2"
		} : void 0,
		u.headerControlsNodes.length ? {
			name: "HeaderControls",
			fn: c(() => [a(u.HeaderControlsOutlet)]),
			key: "3"
		} : void 0
	]), 1040, [
		"Header",
		"Content",
		"Description",
		"HeaderIcon",
		"IsExpanded",
		"ExpandDirection",
		"Padding",
		"Background",
		"BorderBrush",
		"BorderThickness",
		"CornerRadius",
		"IsEnabled",
		"HorizontalContentAlignment",
		"VerticalContentAlignment",
		"Width",
		"MinWidth",
		"Height",
		"MaxWidth",
		"HorizontalAlignment",
		"VerticalAlignment"
	]);
}
var u = /*#__PURE__*/ e(t, [["render", l], ["__file", "Expander.vue"]]);
//#endregion
export { u as default };

//# sourceMappingURL=Expander.vue.js.map