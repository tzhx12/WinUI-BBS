import { boolValue as e } from "./layout.js";
import { normalizeXamlNodes as t, resolveXamlValue as n, updateXamlBinding as r, xamlNameScopeKey as i } from "./xamlRuntime.js";
import { frameworkLayoutStyle as a } from "./frameworkLayout.js";
import { arrangeParallaxChild as o, computeParallaxTranslation as s, measureParallaxAxis as c, parallaxChildLayoutKey as l, resolveParallaxOffsets as u } from "./parallaxRuntime.js";
import { Comment as d, Fragment as f, Text as ee, cloneVNode as te, computed as p, defineComponent as m, getCurrentInstance as ne, h as re, inject as ie, isRef as ae, isVNode as oe, nextTick as se, onBeforeUnmount as ce, onMounted as le, onUpdated as ue, provide as de, ref as h, shallowReactive as fe, shallowRef as pe, toRaw as me, useSlots as he, watch as g } from "vue";
//#region src/components/ParallaxView.vue?vue&type=script&setup=true&lang.ts
var ge = m({
	name: "ParallaxView.Child",
	__parallaxChild: !0,
	setup(e, { slots: t }) {
		return () => re(f, t.default?.());
	}
}), _e = /*@__PURE__*/ m({
	Child: ge,
	__name: "ParallaxView",
	props: {
		Child: {},
		Source: { default: null },
		HorizontalShift: { default: 0 },
		VerticalShift: { default: 0 },
		HorizontalSourceStartOffset: { default: 0 },
		HorizontalSourceEndOffset: { default: 0 },
		VerticalSourceStartOffset: { default: 0 },
		VerticalSourceEndOffset: { default: 0 },
		HorizontalSourceOffsetKind: { default: "Relative" },
		VerticalSourceOffsetKind: { default: "Relative" },
		IsHorizontalShiftClamped: {
			type: [Boolean, String],
			default: !0
		},
		IsVerticalShiftClamped: {
			type: [Boolean, String],
			default: !0
		},
		MaxHorizontalShiftRatio: { default: 1 },
		MaxVerticalShiftRatio: { default: 1 },
		Width: {},
		Height: {},
		MinWidth: {},
		MinHeight: {},
		MaxWidth: {},
		MaxHeight: {},
		Margin: {},
		HorizontalAlignment: { default: "Stretch" },
		VerticalAlignment: { default: "Stretch" },
		Visibility: { default: "Visible" },
		IsHitTestVisible: {
			type: [Boolean, String],
			default: !0
		},
		Opacity: { default: 1 }
	},
	setup(re, { expose: _e }) {
		let _ = re, v = ne(), ve = ie(i, {}), ye = he(), y = fe({}), b = (e) => e in y ? y[e] : n(_[e], v), x = (e) => {
			let t = Number(b(e));
			return Number.isFinite(t) ? t : 0;
		}, be = p(() => Object.fromEntries(Object.keys(_).map((e) => [e, b(e)]))), xe = p(() => {
			let e = a(be.value, v);
			return k.value.horizontal && (e.width = `${A.value.width}px`), k.value.vertical && (e.height = `${A.value.height}px`), e;
		}), S = h(null), C = h(null), Se = pe(null), w = h({
			width: 0,
			height: 0
		}), T = h(null), E = h(null), D = h({
			x: 0,
			y: 0,
			width: 0,
			height: 0
		}), O = h({
			x: 0,
			y: 0
		}), k = h({
			horizontal: !1,
			vertical: !1
		}), A = h({
			width: 0,
			height: 0
		}), j = (e, t) => {
			let n = Number(b(e ? "MinWidth" : "MinHeight")), r = b(e ? "MaxWidth" : "MaxHeight"), i = I(r) ? Infinity : Number(r);
			return c((e ? k.value.horizontal : k.value.vertical) ? Infinity : e ? w.value.width : w.value.height, t, Number.isFinite(n) ? n : 0, i);
		}, M = p(() => ({
			width: j(!0, 0).availableSize + Math.abs(x("HorizontalShift")),
			height: j(!1, 0).availableSize + Math.abs(x("VerticalShift"))
		})), N = pe(null), P = null, Ce = () => {
			let e = [], n, r = (t) => {
				for (let i of t) i.type === f && Array.isArray(i.children) ? r(i.children) : i.type?.__parallaxChild || i.type === "ParallaxView.Child" ? n = Array.isArray(i.children) ? i.children : i.children?.default?.() ?? [] : i.type !== d && !(i.type === ee && !String(i.children ?? "").trim()) && e.push(i);
			};
			if ("Child" in y || _.Child !== void 0) {
				let t = b("Child");
				if (oe(t)) e.push(t);
				else if (t?.$?.vnode) e.push(t.$.vnode);
				else if (t) {
					let n = De(t);
					n?.__vueParentComponent?.vnode && e.push(n.__vueParentComponent.vnode);
				}
			} else r(ye.default?.() ?? []);
			return t(n ?? e, v).find((e) => e.type !== d && !(e.type === ee && !String(e.children ?? "").trim())) ?? null;
		}, we = m({
			name: "ParallaxViewChildOutlet",
			setup: () => () => {
				let e = Ce();
				return (e?.type !== P?.type || e?.key !== P?.key) && (T.value = null, E.value = null), P = e, N.value = e, e ? te(e, { ref: (e) => {
					Se.value = e;
				} }, !0) : null;
			}
		});
		de(l, {
			availableSize: M,
			arrangedSize: E,
			isDirectChild: (e) => e?.parent?.type === we,
			reportDesiredSize: (e) => {
				T.value?.width === e.width && T.value?.height === e.height || (T.value = e, Z());
			}
		});
		let Te = p(() => ({
			left: `${D.value.x}px`,
			top: `${D.value.y}px`,
			width: `${D.value.width}px`,
			height: `${D.value.height}px`,
			transform: `translate3d(${O.value.x}px, ${O.value.y}px, 0)`
		})), F = (e, t) => n(N.value?.props?.[e] ?? t, v), I = (e) => e == null || e === "" || e === "Auto" || !Number.isFinite(Number(e)), Ee = (e) => {
			let t = e.parentElement, n = t ? getComputedStyle(t) : null, r = t?.classList.contains("win-stack-panel"), i = r && n?.flexDirection === "row", a = {
				horizontal: !1,
				vertical: !1
			};
			for (let n of ["horizontal", "vertical"]) {
				if (!I(b(n === "horizontal" ? "Width" : "Height"))) continue;
				if (r && (n === "horizontal" ? i : !i)) {
					a[n] = !0;
					continue;
				}
				let o = n === "horizontal" ? "width" : "height", s = n === "horizontal" ? "minWidth" : "minHeight", c = n === "horizontal" ? "maxWidth" : "maxHeight", l = [
					e.style[o],
					e.style[s],
					e.style[c]
				];
				e.style[o] = "100%", e.style[s] = "0", e.style[c] = "none";
				let u = t?.style[o];
				a[n] = !(u && u !== "auto" && /^0(?:px|%)?$/.test(u)) && (n === "horizontal" ? e.clientWidth : e.clientHeight) === 0, e.style[o] = l[0], e.style[s] = l[1], e.style[c] = l[2];
			}
			return a;
		}, L = () => {
			let e = S.value;
			if (!e || G) return;
			let t = Ee(e);
			(t.horizontal !== k.value.horizontal || t.vertical !== k.value.vertical) && (k.value = t);
			let n = {
				width: e.clientWidth,
				height: e.clientHeight
			};
			(n.width !== w.value.width || n.height !== w.value.height) && (w.value = { ...n });
			let r = C.value?.firstElementChild;
			r !== X && (X && K?.unobserve(X), X = r, r && K?.observe(r)), T.value === null && C.value && (C.value.style.width = Number.isFinite(M.value.width) ? `${M.value.width}px` : "max-content", C.value.style.height = Number.isFinite(M.value.height) ? `${M.value.height}px` : "auto");
			let i = T.value ?? {
				width: I(F("Width", void 0)) ? r?.offsetWidth || (Number.isFinite(M.value.width) ? M.value.width : 0) : Number(F("Width", 0)),
				height: I(F("Height", void 0)) ? r?.offsetHeight || (Number.isFinite(M.value.height) ? M.value.height : 0) : Number(F("Height", 0))
			}, a = {
				width: j(!0, i.width).desiredSize,
				height: j(!1, i.height).desiredSize
			};
			(a.width !== A.value.width || a.height !== A.value.height) && (A.value = a), I(b("Width")) && (e.style.width = t.horizontal ? `${a.width}px` : "100%"), I(b("Height")) && (e.style.height = t.vertical ? `${a.height}px` : "100%"), n.width = e.clientWidth, n.height = e.clientHeight, (n.width !== w.value.width || n.height !== w.value.height) && (w.value = { ...n });
			let s = o({
				width: n.width,
				height: n.height,
				desiredWidth: i.width,
				desiredHeight: i.height,
				horizontalShift: x("HorizontalShift"),
				verticalShift: x("VerticalShift"),
				horizontalAlignment: String(F("HorizontalAlignment", "Stretch")),
				verticalAlignment: String(F("VerticalAlignment", "Stretch")),
				autoWidth: I(F("Width", void 0)),
				autoHeight: I(F("Height", void 0))
			});
			Object.keys(s).some((e) => s[e] !== D.value[e]) && (D.value = s), (E.value?.width !== s.width || E.value?.height !== s.height) && (E.value = {
				width: s.width,
				height: s.height
			}), C.value && (C.value.style.width = `${s.width}px`, C.value.style.height = `${s.height}px`), U();
		}, R = (e) => ae(e) ? e.value : e, z = null, B = p(() => R(b("Source"))), De = (e) => {
			let t = Object.keys(ve).find((t) => me(R(ve[t])) === me(e));
			if (!t) return null;
			let n = S.value?.parentElement;
			for (; n;) {
				let e = Array.from(n.querySelectorAll("[data-xaml-ref]")).find((e) => e.getAttribute("data-xaml-ref") === t);
				if (e) return e;
				n = n.parentElement;
			}
			return null;
		}, V = (e) => {
			if (e = R(e), !e || typeof e != "object") return null;
			let t = e instanceof HTMLElement ? null : e;
			if (t && R(t.ScrollView)) return V(R(t.ScrollView));
			let n = e instanceof HTMLElement ? e : R(t?.ScrollPresenter) ?? R(t?.scrollViewerRef) ?? t?.$el ?? De(e);
			if (!(n instanceof HTMLElement)) return null;
			let r = n.matches(".win-scroll-viewer-viewport, .win-scroll-presenter") ? n : n.querySelector(".win-scroll-viewer-viewport, .win-scroll-presenter");
			return r ? {
				viewport: r,
				content: r.querySelector(".scroll-content"),
				control: t,
				scrollPresenter: r.classList.contains("win-scroll-presenter"),
				root: r.closest(".win-scroll-viewer, .win-scroll-view") ?? n
			} : null;
		}, Oe = () => {
			let e = Number(R(z?.control?.ZoomFactor));
			if (Number.isFinite(e) && e > 0) return e;
			let t = z?.content ? getComputedStyle(z.content).transform : "";
			if (t && t !== "none") {
				let e = new DOMMatrixReadOnly(t).a;
				if (e > 0) return e;
			}
			return 1;
		}, H = (e, t) => {
			(O.value.x !== e || O.value.y !== t) && (O.value = {
				x: e,
				y: t
			});
			let n = `translate3d(${e}px, ${t}px, 0)`;
			C.value && C.value.style.transform !== n && (C.value.style.transform = n);
		}, U = () => {
			let t = z;
			if (!t || !S.value || !N.value) {
				H(0, 0);
				return;
			}
			let n = Oe(), r = t.viewport.contains(S.value), i = S.value.getBoundingClientRect(), a = t.content?.getBoundingClientRect(), o = t.viewport.getBoundingClientRect(), c = (R(t.control?.ZoomMode) ?? t.root.getAttribute("ZoomMode")) === "Enabled" || t.viewport.closest(".zoom-mode-enabled") !== null, l = (l) => {
				let d = l === "Horizontal", f = d ? t.viewport.clientWidth : t.viewport.clientHeight, ee = t.content ? d ? t.content.offsetWidth : t.content.offsetHeight : (d ? t.viewport.scrollWidth : t.viewport.scrollHeight) / n, te = f * (t.scrollPresenter || c ? 1 : .1), p = a ? (d ? i.left - a.left : i.top - a.top) / n : (d ? i.left - o.left + t.viewport.scrollLeft : i.top - o.top + t.viewport.scrollTop) / n, m = u({
					kind: b(`${l}SourceOffsetKind`) === "Absolute" || b(`${l}SourceOffsetKind`) === 0 ? "Absolute" : "Relative",
					startOffset: x(`${l}SourceStartOffset`),
					endOffset: x(`${l}SourceEndOffset`),
					viewportSize: f,
					contentSize: ee,
					zoomFactor: n,
					underpan: te,
					overpan: te,
					insideSource: r,
					parallaxOffset: p,
					parallaxSize: d ? w.value.width : w.value.height
				});
				return s({
					position: d ? t.viewport.scrollLeft : t.viewport.scrollTop,
					...m,
					shift: x(`${l}Shift`),
					maxRatio: x(`Max${l}ShiftRatio`),
					clamped: e(b(`Is${l}ShiftClamped`))
				});
			};
			H(l("Horizontal"), l("Vertical"));
		}, W, G = !1, K, q, J, Y, X = null;
		function Z() {
			G || W !== void 0 || (W = requestAnimationFrame(() => {
				W = void 0, L();
			}));
		}
		let Q = () => {
			z?.viewport.removeEventListener("scroll", U), q?.disconnect(), J?.disconnect(), z = null, H(0, 0);
		}, $ = () => {
			if (!G && (Q(), z = V(B.value), z)) {
				if (z.viewport.addEventListener("scroll", U, { passive: !0 }), typeof ResizeObserver < "u") {
					q = new ResizeObserver(Z);
					for (let e of new Set([
						z.root,
						z.viewport,
						z.content
					])) e && q.observe(e);
				}
				J = new MutationObserver((e) => {
					if (e.every((e) => e.target === S.value || C.value?.contains(e.target))) return;
					let t = V(B.value);
					(t?.viewport !== z?.viewport || t?.content !== z?.content) && $(), Z();
				}), J.observe(z.root, {
					childList: !0,
					subtree: !0,
					attributes: !0,
					attributeFilter: [
						"style",
						"class",
						"ZoomMode"
					]
				}), L();
			}
		};
		function ke() {
			b("HorizontalSourceOffsetKind") !== "Absolute" && x("HorizontalShift") !== 0 && U();
		}
		function Ae() {
			b("VerticalSourceOffsetKind") !== "Absolute" && x("VerticalShift") !== 0 && U();
		}
		let je = {
			RefreshAutomaticHorizontalOffsets: ke,
			RefreshAutomaticVerticalOffsets: Ae,
			ActualWidth: p(() => w.value.width),
			ActualHeight: p(() => w.value.height)
		};
		for (let e of Object.keys(_)) je[e] = p({
			get: () => e === "Child" && _.Child === void 0 && !("Child" in y) ? Se.value : b(e),
			set: (t) => {
				y[e] = t, r(_[e], t, v);
			}
		});
		_e(je), g(() => ({ ..._ }), (e, t) => {
			for (let n of Object.keys(e)) e[n] !== t?.[n] && delete y[n];
		}), g(B, () => {
			Q(), se($);
		}, { flush: "post" }), g(be, Z, { deep: !1 }), g(() => [R(B.value?.ZoomFactor), R(B.value?.ZoomMode)], U), g(N, () => {
			se(Z);
		}), le(() => {
			typeof ResizeObserver < "u" && (K = new ResizeObserver(Z), S.value && K.observe(S.value)), Y = new MutationObserver(Z), C.value && Y.observe(C.value, {
				childList: !0,
				subtree: !0,
				attributes: !0,
				attributeFilter: [
					"HorizontalAlignment",
					"VerticalAlignment",
					"Width",
					"Height"
				]
			}), window.addEventListener("resize", Z), se(() => {
				L(), $();
			});
		}), ue(Z), ce(() => {
			G = !0, Q(), K?.disconnect(), Y?.disconnect(), window.removeEventListener("resize", Z), W !== void 0 && cancelAnimationFrame(W);
		});
		let Me = {
			ParallaxViewChild: ge,
			props: _,
			instance: v,
			names: ve,
			slots: ye,
			overrides: y,
			property: b,
			number: x,
			effectiveProps: be,
			rootStyle: xe,
			rootRef: S,
			childHostRef: C,
			childControl: Se,
			actualSize: w,
			desiredSize: T,
			arrangedSize: E,
			childRect: D,
			translation: O,
			infiniteAxes: k,
			measuredDesiredSize: A,
			measureAxis: j,
			availableSize: M,
			childNode: N,
			get renderedChildNode() {
				return P;
			},
			set renderedChildNode(e) {
				P = e;
			},
			resolveChildNode: Ce,
			ChildOutlet: we,
			childStyle: Te,
			childProperty: F,
			autoSize: I,
			measureInfiniteAxes: Ee,
			updateLayout: L,
			unwrap: R,
			get scrollSource() {
				return z;
			},
			set scrollSource(e) {
				z = e;
			},
			resolvedSource: B,
			findNamedElement: De,
			resolveSource: V,
			zoomFactor: Oe,
			applyTranslation: H,
			updateParallax: U,
			get layoutFrame() {
				return W;
			},
			set layoutFrame(e) {
				W = e;
			},
			get disposed() {
				return G;
			},
			set disposed(e) {
				G = e;
			},
			get layoutObserver() {
				return K;
			},
			set layoutObserver(e) {
				K = e;
			},
			get sourceObserver() {
				return q;
			},
			set sourceObserver(e) {
				q = e;
			},
			get sourceMutationObserver() {
				return J;
			},
			set sourceMutationObserver(e) {
				J = e;
			},
			get childObserver() {
				return Y;
			},
			set childObserver(e) {
				Y = e;
			},
			get observedChild() {
				return X;
			},
			set observedChild(e) {
				X = e;
			},
			queueLayout: Z,
			detachSource: Q,
			attachSource: $,
			RefreshAutomaticHorizontalOffsets: ke,
			RefreshAutomaticVerticalOffsets: Ae,
			publicProperties: je
		};
		return Object.defineProperty(Me, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), Me;
	}
});
//#endregion
export { ge as ParallaxViewChild, _e as default };

//# sourceMappingURL=ParallaxView.vue_vue_type_script_setup_true_lang.js.map