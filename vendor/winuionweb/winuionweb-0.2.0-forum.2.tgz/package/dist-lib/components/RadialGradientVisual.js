import { cssColor as e } from "./brushCore.js";
import { defineComponent as t, h as n, render as r, shallowRef as i, useId as a, watchEffect as o } from "vue";
//#region src/components/RadialGradientVisual.ts
var s = (e) => !!(e && typeof e == "object" && e.__radialGradient), c = (t, r, i) => {
	let { X: a, Y: o } = t.Center, { X: s, Y: c } = t.GradientOrigin, l = Math.max(0, t.RadiusX), u = Math.max(0, t.RadiusY), d = Array.from(t.GradientStops).sort((e, t) => e.Offset - t.Offset), f = d.length === 0 ? "transparent" : d.length === 1 || l === 0 || u === 0 ? e(d.at(-1).Color) : `url(#${r})`;
	return {
		definition: n("radialGradient", {
			id: r,
			gradientUnits: i || t.MappingMode === "Absolute" ? "userSpaceOnUse" : "objectBoundingBox",
			r: 1,
			cx: a / (l || 1),
			cy: o / (u || 1),
			fx: s / (l || 1),
			fy: c / (u || 1),
			gradientTransform: i ? `translate(${i.X} ${i.Y}) scale(${l * (t.MappingMode === "Absolute" ? 1 : i.Width)} ${u * (t.MappingMode === "Absolute" ? 1 : i.Height)})` : `scale(${l} ${u})`,
			spreadMethod: t.SpreadMethod.toLowerCase(),
			"color-interpolation": t.InterpolationSpace === "RgbLinear" ? "linearRGB" : "sRGB"
		}, d.map((t) => n("stop", {
			offset: Math.max(0, Math.min(1, t.Offset)),
			"stop-color": e(t.Color)
		}))),
		paint: f,
		opacity: t.Opacity
	};
}, l = (e, t) => {
	let { definition: r, paint: i, opacity: a } = c(e, t);
	return n("svg", {
		class: "win-radial-gradient-visual",
		width: "100%",
		height: "100%",
		viewBox: e.MappingMode === "Absolute" ? void 0 : "0 0 1 1",
		preserveAspectRatio: "none",
		"aria-hidden": "true",
		focusable: "false",
		style: {
			position: "absolute",
			inset: "0",
			display: "block",
			pointerEvents: "none",
			overflow: "hidden",
			opacity: a
		}
	}, [n("defs", [r]), n("rect", {
		width: "100%",
		height: "100%",
		fill: i
	})]);
}, u = t({
	name: "RadialGradientVisual",
	props: { Brush: {
		type: Object,
		required: !0
	} },
	setup(e) {
		let t = `radial-${a().replace(/[^\w-]/g, "")}`;
		return () => l(e.Brush, t);
	}
}), d = /* @__PURE__ */ new WeakMap(), f = 0, p = (e, t) => {
	let n = d.get(e);
	if (n) {
		s(t) ? n.brush.value = t : (n.dispose(), d.delete(e));
		return;
	}
	if (!s(t)) return;
	let a = document.createElement("span");
	a.className = "win-radial-gradient-background";
	let c = e.style.position, u = e.style.isolation, p = getComputedStyle(e).position === "static";
	p && (e.style.position = "relative"), e.style.isolation = "isolate", a.setAttribute("aria-hidden", "true"), Object.assign(a.style, {
		position: "absolute",
		inset: "0",
		pointerEvents: "none",
		overflow: "hidden",
		borderRadius: "inherit",
		zIndex: "-1"
	}), e.insertBefore(a, e.firstChild);
	let m = i(t), h = `radial-background-${++f}`, g = o(() => {
		s(m.value) && r(l(m.value, h), a);
	});
	d.set(e, {
		brush: m,
		dispose: () => {
			g(), r(null, a), a.remove(), p && e.style.position === "relative" && (e.style.position = c), e.style.isolation === "isolate" && (e.style.isolation = u);
		}
	});
}, m = {
	mounted: (e, t) => p(e, t.value),
	updated: (e, t) => p(e, t.value),
	beforeUnmount: (e) => {
		d.get(e)?.dispose(), d.delete(e);
	}
};
//#endregion
export { u as default, s as isRadialGradientBrush, c as radialGradientPaint, m as vRadialGradientBrush };

//# sourceMappingURL=RadialGradientVisual.js.map