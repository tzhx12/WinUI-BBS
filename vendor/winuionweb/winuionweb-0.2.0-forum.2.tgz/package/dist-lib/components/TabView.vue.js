import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./TabView.vue_vue_type_script_setup_true_lang.js";
import { Fragment as n, createBlock as r, createCommentVNode as i, createElementBlock as a, createElementVNode as o, createVNode as s, mergeProps as c, normalizeStyle as l, openBlock as u, renderList as d } from "vue";
//#region src/components/TabView.vue
var f = [
	"dir",
	"data-theme",
	"aria-disabled"
], p = {
	ref: "headerRef",
	class: "win-tab-view-left-content-presenter",
	"data-part": "LeftContentPresenter"
}, m = {
	key: 0,
	class: "win-tab-view-scroll-button-container is-decrease"
}, h = ["disabled", "aria-label"], g = {
	ref: "itemsPresenterRef",
	class: "win-tab-view-items-presenter",
	role: "tablist",
	"data-part": "TabsItemsPresenter"
}, _ = {
	key: 1,
	class: "win-tab-view-scroll-button-container is-increase"
}, v = ["disabled", "aria-label"], y = {
	key: 0,
	ref: "addContainerRef",
	class: "win-tab-view-add-container"
}, b = ["disabled", "aria-label"], x = {
	ref: "footerRef",
	class: "win-tab-view-right-content-presenter",
	"data-part": "RightContentPresenter"
}, S = {
	ref: "footerContentRef",
	class: "win-tab-view-right-content-content"
}, C = ["id"];
function w(e, t, w, T, E, D) {
	return u(), a("div", c({ ref: "rootRef" }, T.rootAttrs, {
		class: ["win-tab-view", [
			T.attrs.class,
			T.requestedTheme ? `theme-${T.requestedTheme}` : "",
			{
				"is-disabled": !T.enabled,
				"win-theme-scope": T.requestedTheme,
				"is-dragging": T.activeTabViewDrag?.Source === T.endpoint
			}
		]],
		style: [T.attrs.style, T.rootStyle],
		dir: T.direction,
		"data-theme": T.requestedTheme,
		"aria-disabled": !T.enabled,
		onKeydown: T.keyDown
	}), [
		s(T.ResourcesOutlet),
		o("div", {
			ref: "stripRef",
			class: "win-tab-view-tab-container-grid",
			"data-part": "TabContainerGrid",
			onPointerenter: t[4] ||= (e) => T.stripHovered = T.isHoverPointer(e),
			onPointerleave: T.leaveStrip,
			onLostpointercapture: t[5] ||= (e) => T.pendingPointer = null,
			onDragenter: T.nativeDragOver,
			onDragover: T.nativeDragOver,
			onDrop: T.nativeDrop,
			onDragleave: T.nativeDragLeave,
			onWheel: T.stripWheel
		}, [
			o("div", p, [s(T.HeaderOutlet)], 512),
			o("div", {
				ref: "listRef",
				class: "win-tab-view-list-view",
				"data-part": "TabListView",
				style: l(T.listStyle)
			}, [
				T.overflow ? (u(), a("div", m, [o("button", {
					ref: "scrollDecreaseButtonRef",
					class: "win-tab-view-scroll-button",
					type: "button",
					tabindex: "-1",
					disabled: !T.enabled || T.scrollOffset <= 0,
					"aria-label": T.t("TabViewScrollDecreaseButtonTooltip"),
					"data-part": "ScrollDecreaseButton",
					onPointerdown: t[0] ||= (e) => T.beginScrollRepeat(e, -1),
					onPointerup: T.endScrollRepeat,
					onPointercancel: T.endScrollRepeat,
					onLostpointercapture: T.endScrollRepeat,
					onClick: t[1] ||= (e) => T.scrollClick(-1)
				}, [s(T.FontIcon, {
					class: "win-tab-view-glyph",
					Glyph: "",
					MirroredWhenRightToLeft: "True",
					FontSize: "{ThemeResource TabViewItemScrollButonFontSize}",
					FontFamily: "{ThemeResource SymbolThemeFontFamily}"
				})], 40, h)])) : i("", !0),
				o("div", {
					ref: "scrollerRef",
					class: "win-tab-view-scroll-viewer",
					"data-part": "ScrollViewer",
					onScrollPassive: T.updateScroll
				}, [o("div", g, [
					t[6] ||= o("div", {
						class: "win-tab-view-items-edge",
						"aria-hidden": "true"
					}, null, -1),
					(u(!0), a(n, null, d(T.entries, (e) => (u(), r(T.ItemHost, {
						key: e.Key,
						Entry: e
					}, null, 8, ["Entry"]))), 128)),
					t[7] ||= o("div", {
						class: "win-tab-view-items-edge",
						"aria-hidden": "true"
					}, null, -1)
				], 512), T.dropIndex >= 0 ? (u(), a("div", {
					key: 0,
					class: "win-tab-view-drop-indicator",
					style: l({ left: `${T.dropIndex < T.entries.length ? T.elements.get(T.entries[T.dropIndex]?.Key)?.offsetLeft ?? 4 : (T.scrollerRef?.scrollWidth ?? 4) - 4}px` }),
					"aria-hidden": "true"
				}, null, 4)) : i("", !0)], 544),
				T.overflow ? (u(), a("div", _, [o("button", {
					ref: "scrollIncreaseButtonRef",
					class: "win-tab-view-scroll-button",
					type: "button",
					tabindex: "-1",
					disabled: !T.enabled || T.scrollOffset >= T.scrollMaximum - 1,
					"aria-label": T.t("TabViewScrollIncreaseButtonTooltip"),
					"data-part": "ScrollIncreaseButton",
					onPointerdown: t[2] ||= (e) => T.beginScrollRepeat(e, 1),
					onPointerup: T.endScrollRepeat,
					onPointercancel: T.endScrollRepeat,
					onLostpointercapture: T.endScrollRepeat,
					onClick: t[3] ||= (e) => T.scrollClick(1)
				}, [s(T.FontIcon, {
					class: "win-tab-view-glyph",
					Glyph: "",
					MirroredWhenRightToLeft: "True",
					FontSize: "{ThemeResource TabViewItemScrollButonFontSize}",
					FontFamily: "{ThemeResource SymbolThemeFontFamily}"
				})], 40, v)])) : i("", !0)
			], 4),
			T.property("IsAddTabButtonVisible") === !1 ? i("", !0) : (u(), a("div", y, [o("button", {
				ref: "addButtonRef",
				class: "win-tab-view-add-button",
				type: "button",
				"data-part": "AddButton",
				disabled: !T.commandEnabled,
				"aria-label": T.t("TabViewAddButtonName"),
				onClick: T.add
			}, [...t[8] ||= [o("span", { class: "win-tab-view-glyph" }, "", -1)]], 8, b)], 512)),
			o("div", x, [o("div", S, [s(T.FooterOutlet)], 512)], 512)
		], 544),
		o("div", {
			ref: "contentRef",
			class: "win-tab-view-content-presenter",
			"data-part": "TabContentPresenter",
			id: T.panelId(T.selectedKey),
			role: "tabpanel",
			style: l(T.contentStyle)
		}, [s(T.ContentOutlet)], 12, C),
		s(T.TabViewTemplateToolTip, {
			Owner: T.addButtonRef,
			Content: T.t("TabViewAddButtonTooltip"),
			IsEnabled: T.commandEnabled
		}, null, 8, [
			"Owner",
			"Content",
			"IsEnabled"
		]),
		s(T.TabViewTemplateToolTip, {
			Owner: T.scrollDecreaseButtonRef,
			Content: T.t("TabViewScrollDecreaseButtonTooltip"),
			IsEnabled: T.enabled && T.scrollOffset > 0
		}, null, 8, [
			"Owner",
			"Content",
			"IsEnabled"
		]),
		s(T.TabViewTemplateToolTip, {
			Owner: T.scrollIncreaseButtonRef,
			Content: T.t("TabViewScrollIncreaseButtonTooltip"),
			IsEnabled: T.enabled && T.scrollOffset < T.scrollMaximum - 1
		}, null, 8, [
			"Owner",
			"Content",
			"IsEnabled"
		])
	], 16, f);
}
var T = /*#__PURE__*/ e(t, [["render", w], ["__file", "TabView.vue"]]);
//#endregion
export { T as default };

//# sourceMappingURL=TabView.vue.js.map