import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./MediaTransportControls.vue_vue_type_script_lang.js";
//#region src/components/MediaTransportControls.vue
var n = /*#__PURE__*/ e(t, [["__file", "MediaTransportControls.vue"]]);
//#endregion
export { n as default };

//# sourceMappingURL=MediaTransportControls.vue.js.map