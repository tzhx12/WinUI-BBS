import { normalizeXamlNodes as e, resolveXamlResourceObject as t, updateXamlBinding as n } from "./xamlRuntime.js";
import { iconElementProps as r, useIconElement as i } from "./iconElementRuntime.js";
import a from "./Grid.vue.js";
import { IconSourceProperty as o, createIconSourceElementVNode as s, iconSourceContextKey as c, iconSourceKind as l } from "./IconSource.js";
import { Fragment as u, cloneVNode as d, computed as f, defineComponent as p, getCurrentInstance as m, h, isVNode as g, provide as _, ref as v, shallowRef as y, useAttrs as b, useSlots as x, watch as S } from "vue";
var C = /*@__PURE__*/ p({
	IconSource: o,
	inheritAttrs: !1,
	__name: "IconSourceElement",
	props: {
		...r,
		IconSource: {
			type: [String, Object],
			default: null
		}
	},
	setup(r, { expose: o }) {
		let C = r, w = b(), T = x(), E = m(), D = i(C, w, E), O = v();
		S(() => D.resolve(C.IconSource), () => {
			O.value = void 0;
		});
		let k = D.Element, A = y(null);
		_(c, (e) => {
			A.value = e;
		});
		let j = f(() => {
			let e = O.value === void 0 ? C.IconSource : O.value, n = D.resolve(e), r = typeof e == "string" ? e.match(/^\{(?:StaticResource|ThemeResource)\s+([^\s}]+)\}$/)?.[1] : void 0;
			return r ? t(r, E) ?? n : n;
		}), M = (e) => Array.isArray(e.children) ? e.children.filter(g) : e.children?.default?.() ?? [], N = (e) => e.flatMap((e) => e.type === u ? N(M(e)) : l(e) ? [e] : (e.type.__iconSourceProperty, N(M(e)))), P = p({ setup: () => () => g(j.value) ? h(u, e([d(j.value)], E)) : j.value || O.value !== void 0 ? null : h(u, e(N(T.default?.() ?? []), E)) }), F = f(() => A.value ?? (!g(j.value) && j.value && typeof j.value == "object" ? j.value : null)), I = p({ setup: () => () => F.value ? s(F.value) : null });
		Object.defineProperty(D.api, "IconSource", {
			enumerable: !0,
			configurable: !0,
			get: () => F.value,
			set: (e) => {
				O.value = e, n(C.IconSource, e, E);
			}
		}), o(D.api);
		let L = {
			props: C,
			attrs: w,
			slots: T,
			instance: E,
			icon: D,
			sourceOverride: O,
			Element: k,
			registeredSource: A,
			sourceInput: j,
			children: M,
			declarations: N,
			SourceOutlet: P,
			source: F,
			IconOutlet: I,
			Grid: a
		};
		return Object.defineProperty(L, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), L;
	}
});
//#endregion
export { C as default };

//# sourceMappingURL=IconSourceElement.vue_vue_type_script_setup_true_lang.js.map