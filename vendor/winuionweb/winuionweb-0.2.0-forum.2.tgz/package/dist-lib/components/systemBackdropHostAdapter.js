import { SystemBackdrop as e, cloneSystemBackdropConfig as t, toSystemBackdropConfig as n } from "./systemBackdrop.js";
//#region src/components/systemBackdropHostAdapter.ts
var r = Symbol.for("WinUI.SystemBackdropHostAdapter"), i = (e) => e === "Dark" ? "#202020" : "#F3F3F3", a = class extends Error {
	Code;
	constructor(e, t, n) {
		super(t, n), this.Code = e, this.name = "SystemBackdropWindowError";
	}
}, o, s = 0, c = /* @__PURE__ */ new WeakSet(), l = (e, t) => e === t || e !== null && t !== null && [
	"Type",
	"Kind",
	"FallbackColor",
	"TintColor",
	"TintOpacity",
	"LuminosityOpacity"
].every((n) => e[n] === t[n]), u = {
	NativeSystemBackdrop: !1,
	SupportedMaterials: [],
	ExtendsContentIntoTitleBar: !1
}, d = (e) => ({
	Content: e,
	Background: e.style.background,
	Color: e.style.color,
	State: e.dataset.systemBackdropState
}), f = (e) => {
	let t = e.Content;
	e.OwnedBackground !== void 0 && t.style.background === e.OwnedBackground && (t.style.background = e.Background), e.OwnedColor !== void 0 && t.style.color === e.OwnedColor && (t.style.color = e.Color), e.OwnedState !== void 0 && t.dataset.systemBackdropState === e.OwnedState && (e.State === void 0 ? delete t.dataset.systemBackdropState : t.dataset.systemBackdropState = e.State);
}, p = (e, t) => e.Content === t ? !1 : (e.Styles && f(e.Styles), e.Content = t, e.Styles = d(t), e.Revision++, !0), m = (e, t) => {
	for (let [n, r] of [...e.Listeners]) n !== t && r();
};
function h(e, t, n, r) {
	let i = /* @__PURE__ */ new Set(), a = (e) => {
		for (let t of [...i]) t(e);
	}, o = () => a({
		Type: "Activated",
		IsInputActive: !0
	}), l = () => a({
		Type: "Activated",
		IsInputActive: !1
	}), u = () => a({ Type: "Closed" }), d = n.document, f = () => {
		n.addEventListener("focus", o), n.addEventListener("blur", l), d = n.document;
	};
	f();
	let p = t === "Window" ? window.setInterval(() => {
		if (n.closed) u();
		else try {
			n.document === d ? h.Content.ownerDocument !== d && a({ Type: "ConfigurationChanged" }) : (f(), a({ Type: "ConfigurationChanged" }));
		} catch {}
	}, 500) : void 0, m = () => {
		n.removeEventListener("focus", o), n.removeEventListener("blur", l), p !== void 0 && window.clearInterval(p), i.clear();
	}, h = {
		Id: r ?? `browser-backdrop-${++s}`,
		Content: e,
		Window: n,
		Kind: t,
		Subscribe(e) {
			return i.add(e), () => {
				i.delete(e), i.size || m();
			};
		},
		SetContentElement(e) {
			this.Content = e, f();
		},
		Activate() {
			t === "Window" && !n.closed && n.focus();
		},
		Close() {
			if (m(), t === "Window" && (n.closed || n.close(), n.closed)) {
				let e = n.__winuiBackdropWindowContextsV1?.get(this.Id);
				if (e) {
					for (let t of [...e.Listeners.values()]) t();
					e.Listeners.clear(), e.Release();
				}
			}
		},
		Dispose() {
			m();
		}
	};
	return t === "Window" && c.add(h), h;
}
function g(e = window) {
	return {
		CreateWindow(t) {
			let n = Math.max(320, Math.min(4096, Math.round(t.width ?? 640))), r = Math.max(240, Math.min(4096, Math.round(t.height ?? 480))), i = e.open("about:blank", "_blank", `popup=yes,width=${n},height=${r}`);
			if (!i) throw new a("PopupBlocked", "The browser blocked the sample window.");
			let o = i.document;
			o.title = t.title, o.documentElement.lang = e.document.documentElement.lang;
			for (let t of e.document.head.querySelectorAll("style, link[rel=\"stylesheet\"]")) {
				let e = t.cloneNode(!0);
				e.tagName === "LINK" && (e.href = t.href), o.head.appendChild(e);
			}
			Object.assign(o.documentElement.style, {
				height: "100%",
				overflow: "hidden"
			}), Object.assign(o.body.style, {
				margin: "0",
				width: "100%",
				height: "100%",
				overflow: "hidden",
				background: "transparent"
			});
			let s = o.createElement("div");
			return s.className = "win-system-backdrop-window-content win-theme-scope", Object.assign(s.style, {
				width: "100%",
				height: "100%",
				minWidth: "0",
				minHeight: "0",
				overflow: "auto",
				boxSizing: "border-box"
			}), o.body.appendChild(s), h(s, "Window", i);
		},
		AttachWindow(e, t) {
			let n = e.ownerDocument.defaultView;
			if (!n || n.closed) throw new a("HostUnavailable", "The existing backdrop window is unavailable.");
			return h(e, "Window", n, t.id);
		},
		ConnectSurface(e) {
			let t = e.ownerDocument.defaultView;
			if (!t) throw new a("HostUnavailable", "The backdrop surface has no window.");
			return h(e, "Surface", t);
		},
		GetCapabilities: () => u,
		ApplyBackdrop: (e, t) => t === null
	};
}
var _ = (e) => e === "Light" ? "Light" : e === "Dark" ? "Dark" : "Default", v = (e) => ({
	...e,
	RequestedBackdrop: t(e.RequestedBackdrop),
	AppliedBackdrop: t(e.AppliedBackdrop)
}), y = (e) => {
	let t = e.trim(), n = t.match(/^#([\da-f]{2})([\da-f]{6})$/i);
	return n ? `rgba(${Number.parseInt(n[2].slice(0, 2), 16)}, ${Number.parseInt(n[2].slice(2, 4), 16)}, ${Number.parseInt(n[2].slice(4, 6), 16)}, ${Number.parseInt(n[1], 16) / 255})` : t;
};
async function b(r, o, s, u = !0) {
	let h = r.Window ?? r.Content.ownerDocument.defaultView, g = (e) => (h?.console ?? console).error(e), b = () => h ? [
		"(prefers-color-scheme: dark)",
		"(forced-colors: active)",
		"(prefers-reduced-transparency: reduce)"
	].map((e) => h.matchMedia(e)) : [], x = b(), S = /* @__PURE__ */ new Set(), C = r.Kind === "Window" ? !0 : h?.document.hasFocus() ?? !0, w = _(s.theme), T = n(s.backdrop), E = !1, D = !1, O, k, A, j, M = Promise.resolve({
		Status: "Fallback",
		RequestedBackdrop: T,
		AppliedBackdrop: null,
		RequestedTheme: w,
		Theme: "Light",
		IsInputActive: C
	}), N = {
		Status: "Fallback",
		RequestedBackdrop: T,
		AppliedBackdrop: null,
		RequestedTheme: w,
		Theme: "Light",
		IsInputActive: C
	}, P = d(r.Content), F = {}, I, L = !1, R = () => {
		for (let e of [...S]) try {
			e(v(N));
		} catch (e) {
			g(e);
		}
	}, z = () => w === "Light" || w === "Dark" ? w : x[0]?.matches ? "Dark" : "Light", B = () => {
		let e = z();
		return {
			Theme: e,
			IsInputActive: C,
			IsHighContrast: x[1]?.matches ?? !1,
			IsTransparencyEnabled: !(x[2]?.matches ?? !1),
			IsEnergySaverEnabled: !1,
			FallbackColor: i(e)
		};
	}, V = (e) => e === r.Content ? !1 : (c.has(r) || f(P), P = d(e), r.Content = e, r.SetContentElement?.(e), x.forEach((e) => e.removeEventListener("change", q)), x = b(), x.forEach((e) => e.addEventListener("change", q)), !0), H = () => {
		if (!I || E) return !1;
		let e = I.Content ? V(I.Content) : !1, n = w !== I.Theme || !l(T, I.Backdrop);
		return w = I.Theme, l(T, I.Backdrop) || (j && l(j.ToConfig(), I.Backdrop) ? T = t(I.Backdrop) : Q(I.Backdrop)), e || n;
	}, ee = () => {
		if (h?.closed) {
			X(!1).catch(g);
			return;
		}
		H() && G(!1);
	}, U = () => {
		if (!c.has(r) || !h || E) return;
		let e = h, n = e.__winuiBackdropWindowContextsV1 ??= /* @__PURE__ */ new Map(), i = n.get(r.Id);
		if (!i || i.Document !== h.document) {
			let e = r.Id;
			i = {
				Document: h.document,
				Theme: w,
				Backdrop: t(T),
				Listeners: /* @__PURE__ */ new Map(),
				Revision: 0,
				Release() {
					this.Listeners.size || (this.Styles && f(this.Styles), n.get(e) === this && n.delete(e), this.Content = void 0, this.Styles = void 0);
				}
			}, n.set(r.Id, i);
		}
		return i !== I && (I && I.Document !== h.document && I.Listeners.clear(), I?.Listeners.delete(F), I?.Release(), I = i), i.Listeners.set(F, ee), (!i.Content || !L && !u) && r.Content.ownerDocument === h.document && (p(i, r.Content), m(i, F)), L = !0, H();
	}, W = () => {
		if (!I) return;
		let e = I.Theme !== w || !l(I.Backdrop, T);
		r.Content.ownerDocument === I.Document && (e = p(I, r.Content) || e), I.Theme = w, I.Backdrop = t(T), e && (I.Revision++, m(I, F));
	}, G = (e = !0) => {
		e && U();
		let n = I, i = n?.Revision, a = t(T), s = w, c = B();
		return M = M.catch(() => v(N)).then(async () => {
			if (E || n && (n !== I || n.Revision !== i)) return v(N);
			let e, t, l = null, u = !1;
			try {
				let t = await o.GetConfiguration?.(r);
				t && (c = {
					...c,
					...Object.fromEntries(Object.entries(t).filter(([, e]) => e !== void 0)),
					...s === "Default" ? {} : { Theme: s }
				});
				let n = await o.GetCapabilities(r);
				u = n.NativeSystemBackdrop;
				let i = !a || n.SupportedMaterials.includes(a.Type) && (a.Type !== "Mica" || !n.SupportedMicaKinds || n.SupportedMicaKinds.includes(a.Kind)) && (a.Type !== "DesktopAcrylic" || !n.SupportedDesktopAcrylicKinds || n.SupportedDesktopAcrylicKinds.includes(a.Kind));
				if (a && !n.NativeSystemBackdrop ? e = "NativeBackdropUnavailable" : a && c.IsHighContrast ? e = "HighContrast" : a && !c.IsTransparencyEnabled ? e = "TransparencyDisabled" : a && c.IsEnergySaverEnabled ? e = "EnergySaver" : a && !i ? e = "MaterialUnsupported" : a && !c.IsInputActive && (e = "Inactive"), E || (await o.SetTheme?.(r, s), E)) return v(N);
				let d = n.NativeSystemBackdrop && i ? a : null;
				await o.ApplyBackdrop(r, d, c) ? l = e ? null : a : (e ||= "MaterialUnsupported", await o.ApplyBackdrop(r, null, c));
			} catch (n) {
				e = "HostError", t = n;
				try {
					await o.ApplyBackdrop(r, null, c);
				} catch {}
			}
			if (E || n && (n !== I || n.Revision !== i)) return v(N);
			let d = !!(a && !l), f = !n || n.Content === r.Content, p = n?.Styles ?? P;
			f && (r.Content.style.background = d ? c.IsHighContrast ? "Canvas" : c.FallbackColor ? y(c.FallbackColor) : "transparent" : "transparent", r.Content.style.color = u && c.IsHighContrast ? "CanvasText" : "", p.OwnedBackground = r.Content.style.background, p.OwnedColor = r.Content.style.color), f && r.Kind === "Window" && (r.Content.classList.toggle("theme-dark", c.Theme === "Dark"), r.Content.classList.toggle("theme-light", c.Theme === "Light"), r.Content.dataset.theme = c.Theme.toLowerCase());
			let m = u && c.IsHighContrast;
			return f && (r.Content.dataset.systemBackdropState = m ? "HighContrast" : d ? "Fallback" : "Active", p.OwnedState = r.Content.dataset.systemBackdropState), N = {
				Status: m ? "HighContrast" : d ? "Fallback" : "Active",
				RequestedBackdrop: a,
				AppliedBackdrop: l,
				RequestedTheme: s,
				Theme: c.Theme,
				IsInputActive: c.IsInputActive,
				...e ? { Reason: e } : {},
				...t === void 0 ? {} : { Error: t }
			}, R(), v(N);
		}), M;
	}, K = () => {
		U() && G(!1);
	}, q = () => {
		G();
	};
	x.forEach((e) => e.addEventListener("change", q));
	let J, Y = async () => {
		D || (D = !0, await r.Close());
	}, X = (e) => {
		if (O) return e ? O.then(Y) : O;
		let t, n;
		return O = new Promise((e, r) => {
			t = e, n = r;
		}), E = !0, N = {
			...N,
			Status: "Closed",
			AppliedBackdrop: null
		}, R(), S.clear(), x.forEach((e) => e.removeEventListener("change", q)), s.signal?.removeEventListener("abort", $), A?.(), I?.Listeners.delete(F), I?.Release(), I = void 0, J?.(), (async () => {
			await M.catch(() => void 0);
			try {
				await o.ApplyBackdrop(r, null, B());
			} finally {
				!c.has(r) && (r.Kind === "Surface" || !e) && f(P);
				try {
					await k?.();
				} finally {
					try {
						await r.Dispose?.();
					} finally {
						(e || r.Kind === "Surface") && await Y();
					}
				}
			}
		})().then(t, n), O;
	}, Z = {
		Id: r.Id,
		NativeAssociationToken: r.NativeAssociationToken,
		TitleBarHost: r.TitleBarHost,
		get Content() {
			return K(), r.Content;
		},
		Window: r.Window ?? null,
		get State() {
			return K(), v(N);
		},
		SetSystemBackdrop(e) {
			return E ? Promise.resolve(v(N)) : (U(), Q(e), W(), G(!1));
		},
		SetTheme(e) {
			return E ? Promise.resolve(v(N)) : (U(), w = _(e), W(), G(!1));
		},
		SetContentElement(e) {
			return E ? Promise.resolve(v(N)) : e.ownerDocument.defaultView === h ? (U(), V(e), x.forEach((e) => e.removeEventListener("change", q)), x = b(), x.forEach((e) => e.addEventListener("change", q)), I || U(), W(), G(!1)) : Promise.reject(/* @__PURE__ */ TypeError("Window.Content must belong to the host window."));
		},
		Subscribe(e) {
			return E || S.add(e), e(v(N)), () => S.delete(e);
		},
		async Activate() {
			if (!(E || r.Kind !== "Window")) if (r.Activate) await r.Activate();
			else if (r.Window && h && !h.closed && typeof h.focus == "function") h.focus();
			else throw new a("HostUnavailable", "The host cannot activate this native window.");
		},
		Dispose: () => X(!1),
		Close: () => X(!0)
	}, Q = (t) => {
		A?.(), T = n(t);
		let r = t instanceof e ? t : void 0;
		j = r, A = r?.Subscribe(() => {
			U(), j === r && (T = r.ToConfig(), W(), G(!1));
		});
	}, $ = () => {
		X(u).catch(g);
	};
	try {
		if (s.signal?.aborted) throw new a("HostUnavailable", "The backdrop host connection was cancelled.");
		if (Q(s.backdrop), s.signal?.addEventListener("abort", $, { once: !0 }), J = r.Subscribe?.((e) => {
			if (e.Type === "Closed") {
				X(!1).catch(g);
				return;
			}
			e.Type === "Activated" && (C = e.IsInputActive ?? !0), q();
		}), E && J?.(), await G(), E) throw new a("HostUnavailable", "The backdrop host closed before content mounted.");
		let e = s.mountContent?.(r.Content, Z);
		if (typeof e == "function" && (k = e), E) throw new a("HostUnavailable", "The backdrop host closed before content mounted.");
		return Z;
	} catch (e) {
		throw await X(u), e instanceof a ? e : new a("MountFailed", "The sample content could not be mounted.", { cause: e });
	}
}
function x(e, t) {
	return t.aborted ? Promise.reject(t.reason) : new Promise((n, r) => {
		let i = () => r(t.reason);
		t.addEventListener("abort", i, { once: !0 }), e.then(n, r).finally(() => t.removeEventListener("abort", i));
	});
}
async function S(e, t = {}) {
	if (!e.isConnected) throw new a("HostUnavailable", "The backdrop surface must be in the live visual tree.");
	if (t.signal?.aborted) throw new a("HostUnavailable", "The backdrop surface connection was cancelled.");
	let n = t.adapter ?? o, r = n?.ConnectSurface ? n : g(e.ownerDocument.defaultView ?? window), i = Promise.resolve(r.ConnectSurface(e)), s;
	try {
		s = await (t.signal ? x(i, t.signal) : i);
	} catch (e) {
		throw t.signal?.aborted ? (i.then(async (e) => {
			try {
				await e.Dispose?.();
			} finally {
				await e.Close();
			}
		}).catch(() => void 0), new a("HostUnavailable", "The backdrop surface connection was cancelled.", { cause: e })) : e;
	}
	if (!e.isConnected || t.signal?.aborted) {
		try {
			await s.Dispose?.();
		} finally {
			await s.Close();
		}
		throw new a("HostUnavailable", "The backdrop surface left the live visual tree.");
	}
	return b(s, r, t);
}
//#endregion
export { S as createSystemBackdropSurface, r as systemBackdropHostAdapterKey };

//# sourceMappingURL=systemBackdropHostAdapter.js.map