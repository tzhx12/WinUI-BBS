import { resolveXamlHandler as e, resolveXamlValue as t } from "./xamlRuntime.js";
import { createImageSourceModel as n, imageNumber as r, imageSourceContextKey as i, imageUri as a } from "./imageSource.js";
import { xamlResourceDictionaryKey as o } from "./Page.vue_vue_type_script_lang.js";
import { defineComponent as s, getCurrentInstance as c, inject as l, onBeforeUnmount as u, useAttrs as d, watch as f } from "vue";
//#region src/components/SvgImageSource.vue?vue&type=script&setup=true&lang.ts
var p = /*@__PURE__*/ s({
	inheritAttrs: !1,
	__name: "SvgImageSource",
	props: {
		UriSource: {
			type: [String, Object],
			default: ""
		},
		RasterizePixelWidth: {
			type: [Number, String],
			default: 0
		},
		RasterizePixelHeight: {
			type: [Number, String],
			default: 0
		}
	},
	emits: ["Opened", "OpenFailed"],
	setup(s, { expose: p, emit: m }) {
		let h = s, g = m, _ = c(), v = d(), y = l(i, null), b = l(o, null), x = n("SvgImageSource");
		f(() => [a(h.UriSource, _, b), ...[h.RasterizePixelWidth, h.RasterizePixelHeight].map((e) => t(e, _))], (e) => {
			x.UriSource = typeof e[0] == "string" ? e[0] : "", x.RasterizePixelWidth = r(e[1]), x.RasterizePixelHeight = r(e[2]);
		}, { immediate: !0 }), y?.({
			model: x,
			opened: (t) => {
				g("Opened", x, t), e(v.Opened, _)?.(x, t);
			},
			failed: (t) => {
				g("OpenFailed", x, t), e(v.OpenFailed, _)?.(x, t);
			}
		}), p(x), u(() => y?.(null));
		let S = {
			props: h,
			emit: g,
			instance: _,
			attrs: v,
			register: y,
			resources: b,
			model: x
		};
		return Object.defineProperty(S, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), S;
	}
});
//#endregion
export { p as default };

//# sourceMappingURL=SvgImageSource.vue_vue_type_script_setup_true_lang.js.map