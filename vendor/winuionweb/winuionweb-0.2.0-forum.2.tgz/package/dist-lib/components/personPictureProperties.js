import { imageSourceContextKey as e } from "./imageSource.js";
import { Fragment as t, defineComponent as n, h as r, inject as i, provide as a } from "vue";
//#region src/components/personPictureProperties.ts
var o = Symbol("winui-person-picture-image-source"), s = (s) => n({
	name: `PersonPicture.${s}`,
	__personPictureSourceProperty: s,
	setup(n, { slots: c }) {
		let l = i(o, null);
		return a(e, (e) => l?.register(s, e)), () => r(t, c.default?.());
	}
}), c = s("ProfilePicture"), l = s("BadgeImageSource");
//#endregion
export { l as PersonPictureBadgeImageSource, c as PersonPictureProfilePicture, o as personPictureSourceKey };

//# sourceMappingURL=personPictureProperties.js.map