import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./AutoSuggestBox.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                                   */
import { Fragment as n, Teleport as r, createBlock as i, createCommentVNode as a, createElementBlock as o, createElementVNode as s, createVNode as c, normalizeClass as l, normalizeStyle as u, openBlock as d, renderList as f, toDisplayString as p, withCtx as m, withDirectives as h, withModifiers as g } from "vue";
//#region src/components/AutoSuggestBox.vue
var _ = {
	key: 0,
	class: "win-asb-header"
}, v = {
	ref: "anchorRef",
	class: "win-asb-anchor"
}, y = {
	key: 1,
	class: "win-asb-description"
}, b = { class: "win-asb-results" }, x = [
	"id",
	"disabled",
	"aria-selected",
	"onClick"
], S = {
	key: 1,
	class: "win-asb-item-title"
};
function C(e, t, C, w, T, E) {
	return d(), o("div", {
		ref: "rootRef",
		class: l(["win-auto-suggest-box", {
			"is-suggestion-open-down": w.isOpen && w.openDirection === "down",
			"is-suggestion-open-up": w.isOpen && w.openDirection === "up"
		}]),
		style: u(w.rootStyle)
	}, [
		w.resolvedHeader || w.propertyNodes.Header.length ? (d(), o("div", _, [c(w.HeaderOutlet)])) : a("", !0),
		s("div", v, [c(w.TextBoxTemplate, null, {
			default: m(() => [c(w.TextBox, {
				class: "win-asb-textbox",
				Background: "{x:Bind TextBoxBackground, Mode=OneWay}",
				Text: "{x:Bind AutoSuggestText, Mode=OneWay}",
				PlaceholderText: "{x:Bind AutoSuggestPlaceholder, Mode=OneWay}",
				IsEnabled: "{x:Bind AutoSuggestEnabled, Mode=OneWay}",
				DesiredCandidateWindowAlignment: "{x:Bind AutoSuggestCandidateAlignment, Mode=OneWay}",
				TextChanged: "OnTextBoxTextChanged",
				GotFocus: "OnTextBoxGotFocus",
				LostFocus: "OnTextBoxLostFocus",
				TextCompositionStarted: "OnTextCompositionStarted",
				TextCompositionEnded: "OnTextCompositionEnded"
			})]),
			_: 1
		})], 512),
		w.resolvedDescription || w.propertyNodes.Description.length ? (d(), o("div", y, [c(w.DescriptionOutlet)])) : a("", !0),
		(d(), i(r, { to: "body" }, [w.isOpen && w.suggestionItems.length ? h((d(), o("div", {
			key: 0,
			ref: "popupRef",
			class: l(["win-asb-popup win-theme-scope", [w.openDirection === "up" ? "opens-up" : "opens-down", w.popupThemeClass]]),
			style: u([w.popupStyle, w.suggestionsBackgroundStyle]),
			id: w.popupId,
			onPointerdown: t[0] ||= g(() => {}, ["prevent"]),
			role: "listbox"
		}, [c(w.ScrollViewer, {
			class: "win-asb-popup-scroll",
			VerticalScrollMode: "Auto",
			VerticalScrollBarVisibility: "Auto",
			HorizontalScrollMode: "Disabled",
			HorizontalScrollBarVisibility: "Disabled"
		}, {
			default: m(() => [s("div", b, [(d(!0), o(n, null, f(w.suggestionItems, (e, t) => (d(), o("button", {
				key: `${w.getItemText(e)}-${t}`,
				class: l(["win-asb-item", {
					"is-highlighted": w.highlightedIndex === t,
					"is-disabled": w.isNoResultsItem(e)
				}]),
				type: "button",
				role: "option",
				id: `${w.popupId}-${t}`,
				tabindex: "-1",
				disabled: w.isNoResultsItem(e),
				"aria-selected": w.highlightedIndex === t,
				onClick: (e) => w.onSuggestionClick(t)
			}, [w.hasItemTemplate ? (d(), i(w.ItemRenderer, {
				key: 0,
				Item: e,
				Index: t
			}, null, 8, ["Item", "Index"])) : (d(), o("span", S, p(w.getItemLabel(e)), 1))], 10, x))), 128))])]),
			_: 1
		})], 38)), [[
			w.vAcrylicBrush,
			w.suggestionsBackgroundStyle,
			void 0,
			{ "host-backdrop": !0 }
		], [w.vThemeShadow, { Translation: 32 }]]) : a("", !0)]))
	], 6);
}
var w = /*#__PURE__*/ e(t, [
	["render", C],
	["__scopeId", "data-v-bedf548e"],
	["__file", "AutoSuggestBox.vue"]
]);
//#endregion
export { w as default };

//# sourceMappingURL=AutoSuggestBox.vue.js.map