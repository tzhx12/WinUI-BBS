import { attachedValue as e, cssLength as t, useLayoutObserver as n } from "./layout.js";
import { normalizeXamlNodes as r } from "./xamlRuntime.js";
import { frameworkLayoutStyle as i } from "./frameworkLayout.js";
import { layoutResourceChildren as a } from "./layoutResources.js";
import { collectXamlResources as o, useXamlBrushResources as s } from "./xamlBrushResources.js";
import { brushProperty as c, isBrushProperty as l, useBrushProperty as u } from "./brushProperties.js";
import { vAcrylicBrush as d } from "./acrylicBrushVisual.js";
import { vRadialGradientBrush as f } from "./RadialGradientVisual.js";
import { Fragment as p, computed as m, defineComponent as h, getCurrentInstance as g, h as _, ref as v, useAttrs as y, useSlots as b } from "vue";
//#region src/components/Canvas.vue?vue&type=script&setup=true&lang.ts
var x = h({
	name: "Canvas.Resources",
	__canvasResources: !0,
	setup() {
		return () => null;
	}
}), S = /*@__PURE__*/ h({
	Resources: x,
	Background: c("Canvas", "Background"),
	inheritAttrs: !1,
	__name: "Canvas",
	props: {
		Width: {
			type: [String, Number],
			default: ""
		},
		Height: {
			type: [String, Number],
			default: ""
		},
		MinWidth: {
			type: [String, Number],
			default: 0
		},
		MinHeight: {
			type: [String, Number],
			default: 0
		},
		MaxWidth: {
			type: [String, Number],
			default: ""
		},
		MaxHeight: {
			type: [String, Number],
			default: ""
		},
		Background: {
			type: [String, Object],
			default: ""
		},
		Margin: {
			type: [String, Number],
			default: 0
		},
		HorizontalAlignment: {
			type: String,
			default: "Stretch"
		},
		VerticalAlignment: {
			type: String,
			default: "Stretch"
		},
		Visibility: {
			type: String,
			default: "Visible"
		},
		IsHitTestVisible: {
			type: [String, Boolean],
			default: !0
		},
		Opacity: {
			type: [String, Number],
			default: 1
		}
	},
	setup(c, { expose: S }) {
		S();
		let C = c, w = v(null), T = y(), E = b(), D = g(), O = s(D), k = () => {
			let e = {}, t = (n) => {
				for (let r of n) r.type === p && Array.isArray(r.children) ? t(r.children) : r.type?.__canvasResources && o(Array.isArray(r.children) ? r.children : r.children?.default?.() ?? [], e);
			};
			t(E.default?.() ?? []), O.sync(e);
		}, A = u("Background", () => C.Background, () => E.default?.() ?? [], D), j = m(() => ({
			...i(C, D),
			...A.style.value
		})), M = () => (k(), j.value), N = h({ setup() {
			return () => _(p, r(a(E.default?.() ?? [], "__canvasResources").filter((e) => !l(e)), D));
		} });
		n(w, () => {
			if (w.value) for (let n of Array.from(w.value.children)) {
				let r = n;
				r.classList.contains("win-acrylic-visual") || r.classList.contains("win-radial-gradient-background") || r.classList.contains("win-theme-shadow-visual") || (r.style.position = "absolute", r.style.left = t(e(r, "Canvas.Left") ?? 0), r.style.top = t(e(r, "Canvas.Top") ?? 0), r.style.zIndex = String(Number(e(r, "Canvas.ZIndex") ?? 0) || 0));
			}
		});
		let P = {
			CanvasResources: x,
			props: C,
			root: w,
			attrs: T,
			slots: E,
			instance: D,
			brushResources: O,
			syncBrushResources: k,
			backgroundBrush: A,
			rootStyle: j,
			resolveRootStyle: M,
			ChildrenOutlet: N,
			get vAcrylicBrush() {
				return d;
			},
			get vRadialGradientBrush() {
				return f;
			}
		};
		return Object.defineProperty(P, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), P;
	}
});
//#endregion
export { x as CanvasResources, S as default };

//# sourceMappingURL=Canvas.vue_vue_type_script_setup_true_lang.js.map