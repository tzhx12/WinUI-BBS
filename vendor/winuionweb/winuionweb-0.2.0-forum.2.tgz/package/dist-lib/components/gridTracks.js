//#region src/components/gridTracks.ts
var e = (e, t) => {
	if (e === "" || e == null) return t;
	let n = Number(e);
	return Number.isFinite(n) ? Math.max(0, n) : t;
}, t = (t, n) => {
	let r = Array.isArray(t) ? t : t && typeof t == "object" ? [t] : String(t ?? "").split(/[,;]/).map((e) => e.trim()).filter(Boolean);
	return (r.length ? r : ["*"]).map((t) => {
		let r = typeof t == "object" && t ? t : void 0, i = r?.[n], a = String(r ? i == null || i === "" ? "*" : i : t ?? "*").trim(), o = e(r?.[`Min${n}`], 0), s = Math.max(o, e(r?.[`Max${n}`], Infinity));
		if (/^auto$/i.test(a)) return {
			unit: "auto",
			value: 0,
			min: o,
			max: s
		};
		let c = a.match(/^(\d+(?:\.\d+)?)?\s*\*$/);
		return c ? {
			unit: "star",
			value: c[1] === void 0 ? 1 : Number(c[1]),
			min: o,
			max: s
		} : {
			unit: "pixel",
			value: Math.max(o, Math.min(s, e(a, 0))),
			min: o,
			max: s
		};
	});
}, n = (e) => e.unit === "pixel" ? `${e.value}px` : e.unit === "auto" ? `minmax(${e.min}px, max-content)` : `minmax(${e.min}px, ${e.value}fr)`, r = (e, t, n) => {
	let r = e.map((e, t) => e.unit === "pixel" ? e.value : e.unit === "auto" ? Math.max(e.min, Math.min(e.max, n[t] ?? e.min)) : 0), i = t - r.reduce((e, t) => e + t, 0), a = e.map((e, t) => ({
		track: e,
		index: t
	})).filter(({ track: e }) => e.unit === "star");
	for (; a.length;) {
		let e = a.reduce((e, { track: t }) => e + t.value, 0), t = a.filter(({ track: t }) => (e ? Math.max(0, i) * t.value / e : 0) < t.min || t.value === 0), n = t.length ? t : a.filter(({ track: t }) => Math.max(0, i) * t.value / e > t.max);
		if (!n.length) {
			for (let { track: t, index: n } of a) r[n] = Math.max(0, i) * t.value / e;
			break;
		}
		for (let { track: t, index: a } of n) {
			let n = e ? Math.max(0, i) * t.value / e : 0;
			r[a] = Math.max(t.min, Math.min(t.max, n)), i -= r[a];
		}
		let o = new Set(n.map(({ index: e }) => e));
		a = a.filter(({ index: e }) => !o.has(e));
	}
	return r;
};
//#endregion
export { r as constrainedStarSizes, n as gridTrackCss, t as parseGridTracks };

//# sourceMappingURL=gridTracks.js.map