import { normalizeXamlVNode as e, resolveXamlHandler as t, resolveXamlValue as n, updateXamlBinding as r, xamlScopeKey as i } from "./xamlRuntime.js";
import { useI18n as a } from "./i18n/index.js";
import { xamlResourceDictionaryKey as o } from "./Page.vue_vue_type_script_lang.js";
import { DataTemplate as ee, StackLayout as te, getVNodeChildren as ne } from "./CollectionProperties.js";
import re from "./FontIcon.vue.js";
import { isHoverPointer as ie } from "./pointerInput.js";
import ae from "./ScrollViewer.vue.js";
import oe from "./Border.vue.js";
import se from "./Button.vue.js";
import ce from "./StackPanel.vue.js";
import le from "./ItemsRepeater.vue.js";
import { computed as s, defineComponent as ue, getCurrentInstance as de, h as fe, inject as pe, nextTick as me, onBeforeUnmount as he, onMounted as ge, provide as _e, proxyRefs as ve, ref as c, shallowRef as ye, useAttrs as be, watch as l } from "vue";
//#region src/components/PipsPager.vue?vue&type=script&setup=true&lang.ts
var xe = /*@__PURE__*/ ue({
	inheritAttrs: !1,
	__name: "PipsPager",
	props: {
		NumberOfPages: {
			type: [Number, String],
			default: -1
		},
		SelectedPageIndex: {
			type: [Number, String],
			default: 0
		},
		MaxVisiblePips: {
			type: [Number, String],
			default: 5
		},
		Orientation: {
			type: String,
			default: "Horizontal"
		},
		PreviousButtonVisibility: {
			type: String,
			default: "Collapsed"
		},
		NextButtonVisibility: {
			type: String,
			default: "Collapsed"
		},
		PreviousButtonStyle: {
			type: [String, Object],
			default: "{StaticResource PipsPagerPreviousPageButtonStyle}"
		},
		NextButtonStyle: {
			type: [String, Object],
			default: "{StaticResource PipsPagerNextPageButtonStyle}"
		},
		SelectedPipStyle: {
			type: [String, Object],
			default: "{StaticResource PipsPagerSelectedPipButtonStyle}"
		},
		NormalPipStyle: {
			type: [String, Object],
			default: "{StaticResource PipsPagerNormalPipButtonStyle}"
		},
		WrapMode: {
			type: String,
			default: "None"
		},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		IsTabStop: {
			type: [Boolean, String],
			default: !1
		},
		Background: {
			type: String,
			default: "Transparent"
		},
		Width: {
			type: [Number, String],
			default: ""
		},
		Height: {
			type: [Number, String],
			default: ""
		},
		MinWidth: {
			type: [Number, String],
			default: ""
		},
		MinHeight: {
			type: [Number, String],
			default: ""
		},
		MaxWidth: {
			type: [Number, String],
			default: ""
		},
		MaxHeight: {
			type: [Number, String],
			default: ""
		},
		Margin: {
			type: [Number, String],
			default: ""
		},
		HorizontalAlignment: {
			type: String,
			default: "Left"
		},
		VerticalAlignment: {
			type: String,
			default: "Top"
		},
		FlowDirection: {
			type: String,
			default: "LeftToRight"
		}
	},
	emits: ["SelectedIndexChanged", "update:SelectedPageIndex"],
	setup(xe, { expose: Se, emit: Ce }) {
		let we = ue({
			name: "PipsPagerTemplateButton",
			inheritAttrs: !1,
			setup(t, { attrs: r, slots: i }) {
				let a = de();
				return () => e(fe(se, Object.fromEntries(Object.entries(r).map(([e, t]) => [e, typeof t == "string" && t.startsWith("{") ? n(t, a) : t])), i), a);
			}
		}), u = xe, Te = Ce, d = de(), f = be(), { t: p } = a(), Ee = pe(o, null), m = ye({}), h = (e) => n(e in m.value ? m.value[e] : u[e], d), g = (e, t) => {
			let n = Number(h(e));
			return Number.isFinite(n) ? Math.trunc(n) : t;
		}, _ = s(() => g("NumberOfPages", -1)), v = s(() => Math.max(0, g("MaxVisiblePips", 5))), y = s(() => h("Orientation") === "Vertical" ? "Vertical" : "Horizontal"), De = s(() => `orientation-${y.value.toLowerCase()}`), b = s(() => h("IsEnabled") !== !1 && String(h("IsEnabled")).toLowerCase() !== "false"), Oe = s(() => h("FlowDirection") === "RightToLeft" ? "rtl" : "ltr"), x = s(() => String(h("PreviousButtonVisibility"))), S = s(() => String(h("NextButtonVisibility"))), C = s(() => h("WrapMode") === "Wrap" && _.value > 1), w = c(null), ke = c(null), Ae = c(null), T = c(Math.max(0, g("SelectedPageIndex", 0))), E = s(() => _.value > 0 ? Math.min(T.value, _.value - 1) : T.value), D = c(Math.max(v.value, T.value + 1)), O = s(() => _.value === 0 || v.value === 0 ? 0 : _.value > 0 ? _.value : D.value), k = s(() => Math.min(O.value, v.value)), A = c(!1), j = c(!1), M = !1, N, P = 0, F = s(() => O.value > 0 && (E.value > 0 || C.value)), I = s(() => O.value > 0 && (_.value < 0 || E.value < _.value - 1 || C.value)), L = s(() => b.value && F.value), R = s(() => b.value && I.value), z = s(() => A.value || j.value), je = s(() => F.value && (x.value === "Visible" || x.value === "VisibleOnPointerOver" && z.value)), Me = s(() => I.value && (S.value === "Visible" || S.value === "VisibleOnPointerOver" && z.value)), Ne = s(() => !je.value), Pe = s(() => !Me.value), Fe = s(() => String(n(f["AutomationProperties.Name"], d) || p("PipsPagerNameText"))), Ie = s(() => p("PipsPagerPreviousPageButtonText")), Le = s(() => p("PipsPagerNextPageButtonText")), Re = s(() => Object.fromEntries(Object.entries(f).filter(([e]) => !["SelectedIndexChanged", "AutomationProperties.Name"].includes(e)))), ze = (e) => typeof e == "string" ? e.match(/^\{\s*(?:StaticResource|ThemeResource)\s+([^\s}]+)\s*\}$/)?.[1] : void 0, Be = (e) => {
			let t = e === "previous" || e === "next";
			return {
				Width: t ? 24 : y.value === "Horizontal" ? 12 : 24,
				Height: t || y.value === "Horizontal" ? 24 : 12,
				Background: "Transparent",
				BorderBrush: "Transparent",
				BorderThickness: 1,
				CornerRadius: 4,
				Foreground: `var(--PipsPager${t ? "NavigationButton" : "SelectionIndicator"}Foreground${e === "selected" ? "Selected" : ""}, var(--ControlStrongFillColorDefaultBrush, var(--ctrl-strong-fill)))`,
				Content: e === "previous" ? "" : e === "next" ? "" : "",
				FontSize: t ? 8 : e === "selected" ? 6 : 4,
				FontFamily: "var(--SymbolThemeFontFamily, \"Segoe Fluent Icons\")"
			};
		}, B = (e, t, r = /* @__PURE__ */ new Set()) => {
			let i = ze(e), a = i ? Ee?.[i] : e && typeof e == "object" ? e : void 0, o = Be(t);
			if (!a || i && r.has(i)) return o;
			i && r.add(i), a.props?.BasedOn && Object.assign(o, B(a.props.BasedOn, t, r));
			for (let e of ne(a)) {
				let t = e.props?.Property;
				typeof t == "string" && (o[t] = n(e.props?.Value, d));
			}
			return o;
		}, V = (e) => {
			let t = e in m.value ? m.value[e] : u[e];
			return typeof t == "string" && /^\{\s*(?:x:Bind|Binding)\b/.test(t) ? n(t, d) : t;
		}, H = s(() => B(V("NormalPipStyle"), "normal")), U = s(() => B(V("SelectedPipStyle"), "selected")), Ve = s(() => B(V("PreviousButtonStyle"), "previous")), He = s(() => B(V("NextButtonStyle"), "next")), W = (e, t, n) => {
			let r = Number(e[t]);
			return Number.isFinite(r) && r >= 0 ? r : n;
		}, G = s(() => W(H.value, y.value === "Horizontal" ? "Width" : "Height", 12)), K = s(() => W(U.value, y.value === "Horizontal" ? "Width" : "Height", 12)), q = s(() => k.value === 0 ? 0 : G.value * (k.value - 1) + K.value), Ue = s(() => O.value === 0 ? 0 : Math.max(W(H.value, y.value === "Horizontal" ? "Height" : "Width", 24), W(U.value, y.value === "Horizontal" ? "Height" : "Width", 24))), We = s(() => y.value === "Horizontal" ? q.value : Ue.value), Ge = s(() => y.value === "Horizontal" ? Ue.value : q.value), Ke = s(() => Array.from({ length: O.value }, (e, t) => {
			let n = {
				Index: t,
				get IsSelected() {
					return t === E.value;
				},
				get IsEnabled() {
					return b.value;
				},
				get Name() {
					return p("PipsPagerPageText", { page: t + 1 });
				},
				PositionInSet: t + 1,
				get SizeOfSet() {
					return _.value > 0 ? _.value : void 0;
				},
				get TabIndex() {
					return t === E.value && b.value ? 0 : -1;
				}
			};
			for (let e of [
				"Width",
				"Height",
				"Background",
				"Foreground",
				"BorderBrush",
				"BorderThickness",
				"CornerRadius",
				"Content",
				"FontSize",
				"FontFamily"
			]) Object.defineProperty(n, e, {
				enumerable: !0,
				get: () => (t === E.value ? U.value : H.value)[e]
			});
			return n;
		})), J = (e) => {
			if (!(e == null || e === "" || e === "Auto")) return typeof e == "number" || /^-?\d+(?:\.\d+)?$/.test(String(e)) ? `${e}px` : String(e);
		}, qe = (e) => {
			if (e == null || e === "") return;
			let t = String(e).split(",").map((e) => J(e.trim()));
			return t.length === 2 ? `${t[1]} ${t[0]}` : t.length === 4 ? `${t[1]} ${t[2]} ${t[3]} ${t[0]}` : t[0];
		}, Je = s(() => ({
			flex: "0 0 auto",
			width: J(h("Width")),
			height: J(h("Height")),
			minWidth: J(h("MinWidth")),
			minHeight: J(h("MinHeight")),
			maxWidth: J(h("MaxWidth")),
			maxHeight: J(h("MaxHeight")),
			margin: qe(h("Margin")),
			background: String(h("Background") || "transparent"),
			justifySelf: {
				Left: "start",
				Center: "center",
				Right: "end",
				Stretch: "stretch"
			}[String(h("HorizontalAlignment"))],
			alignSelf: {
				Left: "flex-start",
				Center: "center",
				Right: "flex-end",
				Stretch: "stretch"
			}[String(h("HorizontalAlignment"))]
		})), Y = async (e = !0) => {
			let t = ++P;
			if (await me(), t !== P || !O.value) return;
			let n = Math.max(0, E.value * G.value + K.value / 2 - q.value / 2), r = ke.value, i = y.value === "Horizontal" ? Math.max(0, r?.ScrollableWidth ?? 0) : Math.max(0, r?.ScrollableHeight ?? 0), a = Math.min(n, i);
			r?.ChangeView?.(y.value === "Horizontal" ? a : 0, y.value === "Vertical" ? a : 0, null, !e);
		}, X = () => {
			if (_.value >= 0 || v.value === 0) return;
			let e = Math.max(E.value + 1, v.value);
			e > D.value ? D.value = e : E.value === D.value - 1 && (D.value += 1);
		}, Z = (e, n = !1) => {
			if (n && (!b.value || !O.value)) return;
			let i = Number(e);
			if (!Number.isFinite(i)) return;
			let a = _.value > 0 ? Math.min(Math.max(0, Math.trunc(i)), _.value - 1) : Math.max(0, Math.trunc(i));
			if (a === T.value) return;
			T.value = a, X(), r(u.SelectedPageIndex, a, d), Te("update:SelectedPageIndex", a);
			let o = Object.freeze({});
			Te("SelectedIndexChanged", $, o), f.onSelectedIndexChanged || t(f.SelectedIndexChanged, d)?.($, o), Y();
		}, Ye = () => {
			L.value && Z(C.value && E.value === 0 ? _.value - 1 : E.value - 1, !0);
		}, Xe = () => {
			R.value && Z(C.value && E.value === _.value - 1 ? 0 : E.value + 1, !0);
		}, Ze = (e, t) => {
			Z((e.Element ?? t.OriginalEvent?.currentTarget)?.dataset.pageIndex, !0);
		}, Qe = (e) => {
			A.value = ie(e);
		}, $e = (e) => {
			let t = w.value?.getBoundingClientRect();
			(!t || e.clientX <= t.left + 1 || e.clientX >= t.right - 1 || e.clientY <= t.top + 1 || e.clientY >= t.bottom - 1) && (A.value = !1);
		}, et = () => {
			A.value = !1, M = !1;
		}, tt = (e) => {
			ie(e) || (A.value = !1), M = !0, j.value = !1;
		}, nt = () => {
			j.value = !M, M = !1;
		}, rt = (e) => {
			w.value?.contains(e.relatedTarget) || (j.value = !1);
		}, it = (e) => {
			if (!b.value || ![
				"ArrowLeft",
				"ArrowRight",
				"ArrowUp",
				"ArrowDown"
			].includes(e.key)) return;
			let t = e.key === "ArrowLeft" || e.key === "ArrowUp" ? -1 : 1, n = y.value === "Horizontal" && Oe.value === "rtl" ? -t : t, r = e.target?.closest("[data-page-index]"), i = Math.max(0, Math.min(O.value - 1, Number(r?.dataset.pageIndex ?? E.value) + n));
			e.preventDefault(), M = !1, j.value = !0;
			let a = Ae.value?.GetOrCreateElement?.(i);
			(a?.matches?.("button") ? a : a?.querySelector?.("button"))?.focus({ preventScroll: !0 });
		};
		_e(i, {
			orientation: y,
			previousVisibility: x,
			nextVisibility: S,
			previousHidden: Ne,
			nextHidden: Pe,
			previousEnabled: L,
			nextEnabled: R,
			previousLabel: Ie,
			nextLabel: Le,
			previousStyle: Ve,
			nextStyle: He,
			viewportWidth: We,
			viewportHeight: Ge,
			pipItems: Ke,
			OnPreviousButtonClicked: Ye,
			OnNextButtonClicked: Xe,
			OnPipClicked: Ze
		}), l(() => g("SelectedPageIndex", 0), (e) => Z(e)), l([_, v], () => {
			_.value >= 0 && T.value >= _.value && Z(Math.max(0, _.value - 1)), X(), Y(!1);
		}), l([
			y,
			G,
			K,
			k
		], () => {
			Y(!1);
		});
		let Q = (e) => s({
			get: () => h(e),
			set: (t) => {
				m.value = {
					...m.value,
					[e]: t
				};
			}
		}), at = {
			NumberOfPages: Q("NumberOfPages"),
			SelectedPageIndex: s({
				get: () => E.value,
				set: (e) => Z(e)
			}),
			MaxVisiblePips: Q("MaxVisiblePips"),
			Orientation: Q("Orientation"),
			PreviousButtonVisibility: Q("PreviousButtonVisibility"),
			NextButtonVisibility: Q("NextButtonVisibility"),
			PreviousButtonStyle: Q("PreviousButtonStyle"),
			NextButtonStyle: Q("NextButtonStyle"),
			SelectedPipStyle: Q("SelectedPipStyle"),
			NormalPipStyle: Q("NormalPipStyle"),
			WrapMode: Q("WrapMode"),
			IsEnabled: Q("IsEnabled"),
			TemplateSettings: s(() => ({ PipsPagerItems: Array.from({ length: O.value }, (e, t) => t + 1) }))
		}, $ = ve(at);
		Se(at), ge(() => {
			X(), Y(!1), N = new ResizeObserver(() => {
				Y(!1);
			}), w.value && N.observe(w.value);
		}), he(() => {
			++P, N?.disconnect();
		});
		let ot = {
			Button: we,
			props: u,
			emit: Te,
			instance: d,
			attrs: f,
			t: p,
			resources: Ee,
			overrides: m,
			value: h,
			integer: g,
			numberOfPages: _,
			maxVisiblePips: v,
			orientation: y,
			orientationClass: De,
			isEnabled: b,
			flowDirection: Oe,
			previousVisibility: x,
			nextVisibility: S,
			canWrap: C,
			rootRef: w,
			scrollViewerRef: ke,
			repeaterRef: Ae,
			currentIndex: T,
			selectedIndex: E,
			infiniteItemCount: D,
			pageCount: O,
			visibleCount: k,
			isPointerOver: A,
			isFocused: j,
			get pointerFocus() {
				return M;
			},
			set pointerFocus(e) {
				M = e;
			},
			get resizeObserver() {
				return N;
			},
			set resizeObserver(e) {
				N = e;
			},
			get scrollRevision() {
				return P;
			},
			set scrollRevision(e) {
				P = e;
			},
			canGoPrevious: F,
			canGoNext: I,
			previousEnabled: L,
			nextEnabled: R,
			pointerVisibilityActive: z,
			previousVisible: je,
			nextVisible: Me,
			previousHidden: Ne,
			nextHidden: Pe,
			pagerLabel: Fe,
			previousLabel: Ie,
			nextLabel: Le,
			forwardedAttrs: Re,
			resourceKey: ze,
			styleDefaults: Be,
			styleProperties: B,
			styleSource: V,
			normalStyle: H,
			selectedStyle: U,
			previousStyle: Ve,
			nextStyle: He,
			dimension: W,
			normalMainSize: G,
			selectedMainSize: K,
			viewportMainSize: q,
			viewportCrossSize: Ue,
			viewportWidth: We,
			viewportHeight: Ge,
			pipItems: Ke,
			cssLength: J,
			thickness: qe,
			rootStyle: Je,
			ScrollToSelectedPip: Y,
			growInfiniteItems: X,
			SetSelectedPageIndex: Z,
			OnPreviousButtonClicked: Ye,
			OnNextButtonClicked: Xe,
			OnPipClicked: Ze,
			OnPointerEntered: Qe,
			OnPointerExited: $e,
			OnPointerCanceled: et,
			OnPointerPressed: tt,
			OnGotFocus: nt,
			OnLostFocus: rt,
			OnKeyDown: it,
			dependencyProperty: Q,
			exposed: at,
			sender: $,
			Border: oe,
			FontIcon: re,
			ItemsRepeater: le,
			ScrollViewer: ae,
			StackPanel: ce,
			get DataTemplate() {
				return ee;
			},
			get StackLayout() {
				return te;
			}
		};
		return Object.defineProperty(ot, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), ot;
	}
});
//#endregion
export { xe as default };

//# sourceMappingURL=PipsPager.vue_vue_type_script_setup_true_lang.js.map