import { cloneXamlVNodeWithDefaults as e } from "./xamlRuntime.js";
import { defineComponent as t } from "vue";
//#region src/components/breadcrumbBarTemplate.ts
var n = Symbol("WinUI.BreadcrumbBarItemContext"), r = t({
	name: "BreadcrumbBarItem.ContentTemplate",
	__breadcrumbBarItemProperty: "ContentTemplate",
	setup() {
		return () => null;
	}
}), i = (t) => t.map((t) => {
	if (!t || typeof t != "object") return t;
	let n = t.type, r = typeof n == "string" ? n : n?.name || n?.__name || n?.__file?.split(/[\\/]/).pop()?.replace(/\.vue$/, ""), a = {};
	if (r === "TextBlock" && !("Style" in (t.props ?? {}))) {
		for (let e of [
			"FontFamily",
			"FontSize",
			"FontWeight"
		]) e in (t.props ?? {}) || (a[e] = "inherit");
		a.FontSize && !("LineHeight" in (t.props ?? {})) && !("TextLineBounds" in (t.props ?? {})) && (a.LineHeight = "inherit");
	}
	let o = e(t, a);
	if (Array.isArray(t.children)) o.children = i(t.children);
	else if (t.children && typeof t.children == "object") {
		let e = { ...t.children };
		for (let [t, n] of Object.entries(e)) typeof n == "function" && (e[t] = (...e) => {
			let t = n(...e);
			return i(Array.isArray(t) ? t : t ? [t] : []);
		});
		o.children = e;
	}
	return o;
});
//#endregion
export { r as ContentTemplate, n as breadcrumbBarItemContextKey, i as inheritBreadcrumbTextFonts };

//# sourceMappingURL=breadcrumbBarTemplate.js.map