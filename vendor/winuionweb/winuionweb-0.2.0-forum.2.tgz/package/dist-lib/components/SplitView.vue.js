import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./SplitView.vue_vue_type_script_setup_true_lang.js";
/* empty css                                              */
import { createCommentVNode as n, createElementBlock as r, createElementVNode as i, createVNode as a, mergeProps as o, normalizeStyle as s, openBlock as c, withCtx as l, withDirectives as u } from "vue";
//#region src/components/SplitView.vue
var d = [
	"data-display-mode",
	"data-pane-placement",
	"data-pane-state",
	"data-visual-state",
	"tabindex",
	"aria-disabled",
	"inert"
], f = ["aria-hidden", "inert"], p = {
	key: 0,
	class: "split-view-hc-pane-border",
	"data-template-part": "HCPaneBorder",
	"aria-hidden": "true"
};
function m(e, t, m, h, g, _) {
	return u((c(), r("div", o({ ref: "root" }, h.rootAttrs, {
		class: ["win-split-view", [h.attrs.class, { "placement-right": h.panePlacement === "Right" }]],
		style: [h.attrs.style, h.rootStyle],
		"data-display-mode": h.displayMode,
		"data-pane-placement": h.panePlacement,
		"data-pane-state": h.phase,
		"data-visual-state": h.visualState,
		tabindex: h.boolValue(h.resolve(h.props.IsTabStop)) ? 0 : -1,
		"aria-disabled": h.enabled ? void 0 : !0,
		inert: h.enabled ? void 0 : !0,
		onKeydown: h.onKeyDown
	}), [u((c(), r("div", {
		ref: "paneRoot",
		class: "split-view-pane-root",
		"data-template-part": "PaneRoot",
		style: s(h.paneStyle),
		"aria-hidden": h.paneVisible ? void 0 : !0,
		inert: h.paneVisible ? void 0 : !0,
		tabindex: "-1"
	}, [a(h.Border, { class: "split-view-pane-presenter" }, {
		default: l(() => [a(h.PaneOutlet)]),
		_: 1
	}), h.highContrast && h.paneVisible ? (c(), r("div", p)) : n("", !0)], 12, f)), [[
		h.vAcrylicBrush,
		h.paneBackgroundStyle,
		void 0,
		{ "host-backdrop": !0 }
	]]), i("div", {
		ref: "contentRoot",
		class: "split-view-content-root",
		"data-template-part": "ContentRoot",
		style: s(h.contentStyle)
	}, [a(h.Border, { class: "split-view-content-presenter" }, {
		default: l(() => [a(h.ContentOutlet)]),
		_: 1
	}), h.lightDismissVisible ? (c(), r("div", {
		key: 0,
		ref: "lightDismissLayer",
		class: "split-view-light-dismiss-layer",
		"data-template-part": "LightDismissLayer",
		style: s(h.lightDismissStyle),
		"aria-hidden": "true",
		onPointerdown: h.blockDismissPointer,
		onPointerup: h.onLightDismissReleased
	}, null, 36)) : n("", !0)], 4)], 16, d)), [[h.vAcrylicBrush, h.backgroundStyle]]);
}
var h = /*#__PURE__*/ e(t, [["render", m], ["__file", "SplitView.vue"]]);
//#endregion
export { h as default };

//# sourceMappingURL=SplitView.vue.js.map