import { materializeXamlVNode as e, normalizeXamlNodes as t, resolveXamlHandler as n, resolveXamlValue as r, updateXamlBinding as i, xamlScopeKey as a } from "./xamlRuntime.js";
import { frameworkLayoutStyle as ee } from "./frameworkLayout.js";
import { flyoutInputContextKey as te } from "./flyoutInput.js";
import { useI18n as ne } from "./i18n/index.js";
import { xamlResourceDictionaryKey as re } from "./Page.vue_vue_type_script_lang.js";
import { getVNodeChildren as o } from "./CollectionProperties.js";
import s from "./TextBlock.vue.js";
import c from "./ContentPresenter.vue.js";
import ie from "./Button.vue.js";
import { ContentTemplate as l, breadcrumbBarItemContextKey as ae, inheritBreadcrumbTextFonts as oe } from "./breadcrumbBarTemplate.js";
import { Fragment as u, computed as d, defineComponent as f, getCurrentInstance as p, h as m, inject as h, isVNode as g, onBeforeUnmount as se, onMounted as ce, provide as le, ref as _, useAttrs as ue, useSlots as de, watch as v } from "vue";
var y = /*@__PURE__*/ f({
	ContentTemplate: l,
	name: "BreadcrumbBarItem",
	inheritAttrs: !1,
	__name: "BreadcrumbBarItem",
	props: {
		Content: {
			type: null,
			default: void 0
		},
		ContentTemplate: {
			type: null,
			default: void 0
		},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		FlowDirection: {
			type: String,
			default: ""
		},
		Background: {
			type: [String, Object],
			default: ""
		},
		BorderBrush: {
			type: [String, Object],
			default: ""
		},
		BorderThickness: {
			type: [String, Number],
			default: 0
		},
		Foreground: {
			type: [String, Object],
			default: ""
		},
		FontFamily: {
			type: String,
			default: ""
		},
		FontSize: {
			type: [String, Number],
			default: ""
		},
		FontWeight: {
			type: [String, Number],
			default: "Normal"
		},
		CornerRadius: {
			type: [String, Number],
			default: ""
		},
		HorizontalAlignment: {
			type: String,
			default: "Stretch"
		},
		VerticalAlignment: {
			type: String,
			default: "Center"
		},
		HorizontalContentAlignment: {
			type: String,
			default: "Stretch"
		},
		VerticalContentAlignment: {
			type: String,
			default: "Center"
		},
		Width: {
			type: [String, Number],
			default: ""
		},
		Height: {
			type: [String, Number],
			default: ""
		},
		MinWidth: {
			type: [String, Number],
			default: 0
		},
		MinHeight: {
			type: [String, Number],
			default: 0
		},
		MaxWidth: {
			type: [String, Number],
			default: ""
		},
		MaxHeight: {
			type: [String, Number],
			default: ""
		},
		Margin: {
			type: [String, Number],
			default: ""
		},
		Visibility: {
			type: String,
			default: "Visible"
		},
		IsTabStop: {
			type: [Boolean, String],
			default: !0
		}
	},
	emits: [
		"GotFocus",
		"KeyDown",
		"update:Content",
		"update:ContentTemplate",
		"update:IsEnabled",
		"update:FlowDirection"
	],
	setup(l, { expose: y, emit: fe }) {
		let b = l, x = fe, S = p(), C = ue(), w = de(), T = h(ae, null), E = h(te, null), D = h(re, null), O = h(a, {}), { t: k } = ne(), A = _(null), j = f({
			name: "BreadcrumbBarTemplateButton",
			inheritAttrs: !1,
			setup(e, { attrs: t, slots: i }) {
				let a = p();
				return () => m(ie, {
					...Object.fromEntries(Object.entries(t).map(([e, t]) => e === "Click" ? [e, n(t, a)] : [e, typeof t == "string" ? r(t, a) : t])),
					IsEnabled: B.value,
					Padding: "1,3",
					BorderThickness: String(P("BorderThickness") || 0),
					BorderBrush: String(P("BorderBrush") || "transparent"),
					FontFamily: String(P("FontFamily") || "var(--ContentControlThemeFontFamily, Segoe UI Variable, Segoe UI, sans-serif)"),
					FontSize: String(P("FontSize") || "var(--BreadcrumbBarItemThemeFontSize, var(--ControlContentThemeFontSize, 14px))"),
					FontWeight: String(P("FontWeight") || "Normal"),
					CornerRadius: String(P("CornerRadius") || "var(--ControlCornerRadius, 4px)"),
					Click: q
				}, i);
			}
		}), M = _({}), N = (e) => r(e, S), P = (e) => e in M.value ? M.value[e] : N(b[e]), F = (e) => d({
			get: () => P(e),
			set: (t) => {
				M.value = {
					...M.value,
					[e]: t
				}, i(b[e], t, S), x(`update:${e}`, t);
			}
		}), I = F("Content"), L = F("ContentTemplate"), R = F("IsEnabled"), z = F("FlowDirection");
		for (let e of [
			"Content",
			"ContentTemplate",
			"IsEnabled",
			"FlowDirection"
		]) v(() => N(b[e]), () => {
			let t = { ...M.value };
			delete t[e], M.value = t;
		});
		let B = d(() => R.value !== !1 && T?.enabled !== !1), V = d(() => T?.type === "LastItem"), H = d(() => T?.type === "Ellipsis"), U = d(() => T?.type === "EllipsisDropDown"), W = d(() => !!T?.hidden), G = d(() => String(z.value) === "RightToLeft" || T?.direction === "rtl" ? "rtl" : "ltr"), pe = d(() => !B.value || W.value || P("IsTabStop") === !1 ? -1 : T?.tabIndex ?? 0), me = d(() => H.value ? k("text.more") : String(N(C["AutomationProperties.Name"]) ?? "")), he = d(() => Object.fromEntries(Object.entries(C).filter(([e]) => ![
			"class",
			"style",
			"Click",
			"GotFocus",
			"KeyDown",
			"AutomationProperties.Name"
		].includes(e)))), ge = d(() => {
			let e = { ...ee(b, S) };
			U.value && (e.alignSelf = e.justifySelf || "stretch"), delete e.background, delete e.borderWidth, delete e.borderColor;
			let t = P("Background");
			t && (e["--breadcrumb-background"] = String(t));
			for (let [t, n] of [
				["Foreground", "--breadcrumb-item-foreground"],
				["FontFamily", "fontFamily"],
				["FontSize", "fontSize"],
				["FontWeight", "fontWeight"]
			]) {
				let r = P(t);
				r !== "" && r !== void 0 && (e[n] = t === "FontSize" && !Number.isNaN(Number(r)) ? `${r}px` : r === "Normal" ? "normal" : r == null ? void 0 : String(r));
			}
			return e;
		}), K = d(() => {
			let e = L.value, t = "ContentTemplate" in M.value ? M.value.ContentTemplate : b.ContentTemplate, n = typeof t == "string" ? t.match(/^\{(?:StaticResource|ThemeResource)\s+([^}]+)\}$/)?.[1] : null, r = n ? D?.[n] : null;
			if (r) return o(r);
			if (g(e)) return o(e);
			if (Array.isArray(e)) return e;
			let i = w.default?.() ?? [], a = i.find((e) => e.type?.__breadcrumbBarItemProperty === "ContentTemplate" || e.type === "BreadcrumbBarItem.ContentTemplate");
			return a ? o(a) : i.filter((e) => !e.type?.__breadcrumbBarItemProperty);
		}), _e = f({
			name: "BreadcrumbBarItemContentPresenter",
			setup() {
				let n = p();
				return () => {
					let r = I.value, i = K.value;
					return i.length ? m(u, t(e(oe(i), r, n), n)) : g(r) ? m(u, t([r], n)) : m(s, {
						class: "win-breadcrumb-item-content",
						Text: r && typeof r == "object" && r.toString === Object.prototype.toString ? "" : String(r ?? ""),
						LineHeight: "20",
						TextWrapping: "NoWrap"
					});
				};
			}
		}), q = () => {
			!B.value || W.value || T?.activate?.();
		}, ve = (e) => {
			T?.gotFocus?.(e), n(C.GotFocus, S)?.(S?.proxy, e), x("GotFocus", S?.proxy, e);
		}, ye = (e) => {
			if (B.value) {
				if (e.key === "Enter" || e.key === " ") {
					e.preventDefault(), e.stopPropagation(), e.repeat || q();
					return;
				}
				T?.keyDown?.(e), n(C.KeyDown, S)?.(S?.proxy, e), x("KeyDown", S?.proxy, e);
			}
		}, J = _(!1), Y = _(!1), X = null, Z = (e) => X !== null && X !== e.pointerId ? !1 : (X = e.pointerId, !0), Q = (e) => {
			e && "pointerId" in e && X !== null && X !== e.pointerId || (J.value = !1, Y.value = !1, X = null);
		}, be = (e) => {
			if (e.pointerType === "touch") {
				Y.value = !1;
				return;
			}
			if (U.value && E && !E.allowsHover(e) || !U.value || !B.value || !Z(e)) return;
			let t = A.value?.getBoundingClientRect();
			if (t && (e.clientX < t.left || e.clientX > t.right || e.clientY < t.top || e.clientY > t.bottom)) {
				Q(e);
				return;
			}
			Y.value = !0;
		}, xe = (e) => {
			e.pointerType === "touch" && Q(), !(!U.value || !B.value || e.pointerType === "mouse" && e.button !== 0 || !Z(e)) && (J.value = !0, A.value?.focus({ preventScroll: !0 }));
		}, Se = (e) => {
			if (!U.value || !B.value || !Z(e)) return;
			let t = A.value?.getBoundingClientRect(), n = J.value && (!t || e.clientX >= t.left && e.clientX <= t.right && e.clientY >= t.top && e.clientY <= t.bottom);
			J.value = !1, X = null, n && q();
		}, Ce = (e) => {
			U.value && e.detail === 0 && q();
		};
		v(B, (e) => {
			e || Q();
		}), v(() => T?.flyoutOpen, (e) => {
			U.value && !e && Q();
		}), ce(() => window.addEventListener("blur", Q)), se(() => window.removeEventListener("blur", Q)), le(a, {
			...O,
			BreadcrumbButtonVisibility: d(() => !V.value && !U.value ? "Visible" : "Collapsed"),
			BreadcrumbTemplate: {
				get IsEnabled() {
					return B.value;
				},
				get ContentPadding() {
					return U.value ? "0" : "1,3";
				},
				get BorderThickness() {
					return P("BorderThickness") || 0;
				},
				get BorderBrush() {
					return P("BorderBrush") || "transparent";
				},
				get FontFamily() {
					return P("FontFamily") || "var(--ContentControlThemeFontFamily, Segoe UI Variable, Segoe UI, sans-serif)";
				},
				get FontSize() {
					return P("FontSize") || "var(--BreadcrumbBarItemThemeFontSize, var(--ControlContentThemeFontSize, 14px))";
				},
				get FontWeight() {
					return String(P("FontWeight") || "Normal");
				},
				get CornerRadius() {
					return P("CornerRadius") || "var(--ControlCornerRadius, 4px)";
				},
				get HorizontalContentAlignment() {
					return P("HorizontalContentAlignment") || "Stretch";
				},
				get VerticalContentAlignment() {
					return P("VerticalContentAlignment") || "Center";
				},
				get ChevronGlyph() {
					return G.value === "rtl" ? "" : "";
				},
				OnClick: q
			}
		}), y({
			Element: A,
			Content: I,
			ContentTemplate: L,
			IsEnabled: R,
			FlowDirection: z,
			Focus: () => !B.value || W.value ? !1 : (A.value?.focus({ preventScroll: !0 }), document.activeElement === A.value)
		});
		let $ = {
			props: b,
			emit: x,
			instance: S,
			attrs: C,
			slots: w,
			context: T,
			flyoutInput: E,
			resources: D,
			inheritedScope: O,
			t: k,
			rootRef: A,
			Button: j,
			overrides: M,
			resolve: N,
			property: P,
			dependencyProperty: F,
			Content: I,
			ContentTemplateProperty: L,
			IsEnabled: R,
			FlowDirection: z,
			isEnabled: B,
			isCurrent: V,
			isEllipsis: H,
			isDropDown: U,
			isHidden: W,
			flowDirection: G,
			tabIndex: pe,
			automationName: me,
			rootAttrs: he,
			layoutStyle: ge,
			templateNodes: K,
			ContentOutlet: _e,
			activate: q,
			onGotFocus: ve,
			onKeyDown: ye,
			isPressed: J,
			isPointerOver: Y,
			get trackedPointerId() {
				return X;
			},
			set trackedPointerId(e) {
				X = e;
			},
			acceptsPointer: Z,
			clearPointer: Q,
			onPointerEnter: be,
			onPointerDown: xe,
			onPointerUp: Se,
			onAccessibleClick: Ce,
			ContentPresenter: c,
			TextBlock: s
		};
		return Object.defineProperty($, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), $;
	}
});
//#endregion
export { y as default };

//# sourceMappingURL=BreadcrumbBarItem.vue_vue_type_script_setup_true_lang.js.map