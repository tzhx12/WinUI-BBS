import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./ScrollViewer.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                                 */
import { createCommentVNode as n, createElementBlock as r, createElementVNode as i, createVNode as a, normalizeClass as o, normalizeStyle as s, openBlock as c, withDirectives as l } from "vue";
//#region src/components/ScrollViewer.vue
var u = ["tabindex", "aria-disabled"], d = {
	key: 2,
	class: "scrollbar-corner"
};
function f(e, t, f, p, m, h) {
	return l((c(), r("div", {
		ref: "rootRef",
		class: o(["win-scroll-viewer", [`zoom-mode-${p.effectiveZoomMode.toLowerCase()}`, {
			"is-disabled": !p.effectiveIsEnabled,
			scrolling: p.isScrolling,
			zooming: p.isZooming,
			"has-vertical-scrollbar": p.hasVerticalScrollBar,
			"has-horizontal-scrollbar": p.hasHorizontalScrollBar
		}]]),
		style: s(p.scrollViewerStyle),
		onPointerenter: p.handleViewerPointerEnter,
		onPointermove: p.handleViewerPointerMove,
		onPointerleave: p.handleViewerPointerLeave
	}, [
		i("div", {
			ref: "scrollViewerRef",
			class: "win-scroll-viewer-viewport",
			style: s(p.viewportStyle),
			tabindex: p.effectiveIsTabStop ? 0 : -1,
			"aria-disabled": !p.effectiveIsEnabled || void 0,
			onScroll: p.handleScroll,
			onWheel: p.handleWheel,
			onKeydown: p.handleKeyDown,
			onTouchstart: p.handleTouchStart,
			onTouchmove: p.handleTouchMove,
			onTouchend: p.handleTouchEnd,
			onTouchcancel: p.handleTouchEnd
		}, [i("div", {
			ref: "contentRef",
			class: "scroll-content",
			style: s(p.contentStyle)
		}, [a(p.ContentOutlet)], 4)], 44, u),
		p.hasVerticalScrollBar ? (c(), r("div", {
			key: 0,
			class: o(["viewer-scrollbar-host viewer-scrollbar-host-vertical", { "has-cross-scrollbar": p.hasHorizontalScrollBar }])
		}, [a(p.ScrollBar, {
			Orientation: "Vertical",
			SmallChange: "16",
			LargeChange: "{x:Bind ScrollBars.Vertical.ViewportSize, Mode=OneWay}",
			Minimum: "0",
			Maximum: "{x:Bind ScrollBars.Vertical.Maximum, Mode=OneWay}",
			ViewportSize: "{x:Bind ScrollBars.Vertical.ViewportSize, Mode=OneWay}",
			Value: "{x:Bind ScrollBars.Vertical.Value, Mode=OneWay}",
			IndicatorMode: "{x:Bind ScrollBars.IndicatorMode, Mode=OneWay}",
			IsEnabled: "{x:Bind ScrollBars.IsEnabled, Mode=OneWay}",
			Scroll: "VerticalScrollBar_Scroll"
		})], 2)) : n("", !0),
		p.hasHorizontalScrollBar ? (c(), r("div", {
			key: 1,
			class: o(["viewer-scrollbar-host viewer-scrollbar-host-horizontal", { "has-cross-scrollbar": p.hasVerticalScrollBar }])
		}, [a(p.ScrollBar, {
			Orientation: "Horizontal",
			SmallChange: "16",
			LargeChange: "{x:Bind ScrollBars.Horizontal.ViewportSize, Mode=OneWay}",
			Minimum: "0",
			Maximum: "{x:Bind ScrollBars.Horizontal.Maximum, Mode=OneWay}",
			ViewportSize: "{x:Bind ScrollBars.Horizontal.ViewportSize, Mode=OneWay}",
			Value: "{x:Bind ScrollBars.Horizontal.Value, Mode=OneWay}",
			IndicatorMode: "{x:Bind ScrollBars.IndicatorMode, Mode=OneWay}",
			IsEnabled: "{x:Bind ScrollBars.IsEnabled, Mode=OneWay}",
			Scroll: "HorizontalScrollBar_Scroll"
		})], 2)) : n("", !0),
		p.hasVerticalScrollBar && p.hasHorizontalScrollBar ? (c(), r("div", d)) : n("", !0)
	], 38)), [[p.vAcrylicBrush, p.backgroundStyle]]);
}
var p = /*#__PURE__*/ e(t, [
	["render", f],
	["__scopeId", "data-v-33777b70"],
	["__file", "ScrollViewer.vue"]
]);
//#endregion
export { p as default };

//# sourceMappingURL=ScrollViewer.vue.js.map