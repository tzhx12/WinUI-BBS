import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./BitmapImage.vue_vue_type_script_setup_true_lang.js";
//#region src/components/BitmapImage.vue
function n(e, t, n, r, i, a) {
	return null;
}
var r = /*#__PURE__*/ e(t, [["render", n], ["__file", "BitmapImage.vue"]]);
//#endregion
export { r as default };

//# sourceMappingURL=BitmapImage.vue.js.map