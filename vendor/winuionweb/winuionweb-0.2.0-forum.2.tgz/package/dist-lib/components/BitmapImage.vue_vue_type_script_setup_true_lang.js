import { resolveXamlHandler as e, resolveXamlValue as t } from "./xamlRuntime.js";
import { createImageSourceModel as n, imageBoolean as r, imageNumber as i, imageSourceContextKey as a, imageUri as o } from "./imageSource.js";
import { xamlResourceDictionaryKey as s } from "./Page.vue_vue_type_script_lang.js";
import { defineComponent as c, getCurrentInstance as l, inject as u, onBeforeUnmount as d, useAttrs as f, watch as p } from "vue";
//#region src/components/BitmapImage.vue?vue&type=script&setup=true&lang.ts
var m = /*@__PURE__*/ c({
	inheritAttrs: !1,
	__name: "BitmapImage",
	props: {
		UriSource: {
			type: [String, Object],
			default: ""
		},
		AutoPlay: {
			type: [Boolean, String],
			default: !0
		},
		DecodePixelWidth: {
			type: [Number, String],
			default: 0
		},
		DecodePixelHeight: {
			type: [Number, String],
			default: 0
		},
		DecodePixelType: {
			type: String,
			default: "Physical"
		}
	},
	emits: ["ImageOpened", "ImageFailed"],
	setup(c, { expose: m, emit: h }) {
		let g = c, _ = h, v = l(), y = f(), b = u(a, null), x = u(s, null), S = n("BitmapImage");
		p(() => [o(g.UriSource, v, x), ...[
			g.AutoPlay,
			g.DecodePixelWidth,
			g.DecodePixelHeight,
			g.DecodePixelType
		].map((e) => t(e, v))], (e) => {
			S.UriSource = typeof e[0] == "string" ? e[0] : "", S.AutoPlay = r(e[1]), S.DecodePixelWidth = Math.floor(i(e[2])), S.DecodePixelHeight = Math.floor(i(e[3])), S.DecodePixelType = e[4] === "Logical" ? "Logical" : "Physical";
		}, { immediate: !0 }), b?.({
			model: S,
			opened: (t) => {
				_("ImageOpened", S, t), e(y.ImageOpened, v)?.(S, t);
			},
			failed: (t) => {
				_("ImageFailed", S, t), e(y.ImageFailed, v)?.(S, t);
			}
		}), m(S), d(() => b?.(null));
		let C = {
			props: g,
			emit: _,
			instance: v,
			attrs: y,
			register: b,
			resources: x,
			model: S
		};
		return Object.defineProperty(C, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), C;
	}
});
//#endregion
export { m as default };

//# sourceMappingURL=BitmapImage.vue_vue_type_script_setup_true_lang.js.map