//#region src/components/dropDownButtonResources.ts
var e = {
	DropDownButtonForegroundSecondary: "var(--DropDownButtonForegroundSecondary)",
	DropDownButtonForegroundSecondaryPointerOver: "var(--DropDownButtonForegroundSecondaryPointerOver)",
	DropDownButtonForegroundSecondaryPressed: "var(--DropDownButtonForegroundSecondaryPressed)",
	DefaultDropDownButtonStyle: "DefaultDropDownButtonStyle"
};
//#endregion
export { e as dropDownButtonResources };

//# sourceMappingURL=dropDownButtonResources.js.map