import { cssLength as e, xamlThickness as t } from "./layout.js";
import { swipeControlResources as n } from "./swipeControlResources.js";
import { materializeXamlVNode as r, normalizeXamlNodes as i, resolveXamlResourceObject as a, resolveXamlValue as o, xamlControlIdentityKey as s, xamlItemContextKey as c } from "./xamlRuntime.js";
import { frameworkLayoutStyle as l } from "./frameworkLayout.js";
import { symbolGlyphs as ee } from "./symbolGlyphs.js";
import { xamlResourceDictionaryKey as te } from "./Page.vue_vue_type_script_lang.js";
import { SwipeItemsCollection as ne, observeSwipeItemsChanging as re } from "./SwipeItemsCollection.js";
import { createSwipeItemReader as ie, readSwipeItems as ae, swipeBrush as oe, swipeChildren as u, swipeControlProperties as se, swipeNodeName as ce, swipeNodes as le, swipeProperty as ue } from "./SwipeControlProperties.js";
import { BrowserSwipeInteractionTracker as de } from "./swipeInteractionTracker.js";
import { Fragment as fe, cloneVNode as pe, computed as d, defineComponent as me, getCurrentInstance as he, h as ge, inject as _e, isVNode as ve, nextTick as ye, onBeforeUnmount as be, onMounted as xe, provide as Se, ref as f, toRaw as Ce, unref as we, useAttrs as Te, useSlots as Ee, watch as De } from "vue";
var Oe = /*@__PURE__*/ me({
	...se,
	inheritAttrs: !1,
	__name: "SwipeControl",
	props: {
		LeftItems: {
			type: [Object, String],
			default: void 0
		},
		RightItems: {
			type: [Object, String],
			default: void 0
		},
		TopItems: {
			type: [Object, String],
			default: void 0
		},
		BottomItems: {
			type: [Object, String],
			default: void 0
		},
		Content: { default: void 0 },
		ContentTemplate: { default: void 0 },
		DataContext: { default: void 0 },
		Background: {
			type: [Object, String],
			default: "Transparent"
		},
		BorderBrush: {
			type: [Object, String],
			default: "Transparent"
		},
		BorderThickness: {
			type: [Number, String],
			default: 0
		},
		CornerRadius: {
			type: [Number, String],
			default: 0
		},
		Padding: {
			type: [Number, String],
			default: 0
		},
		Margin: {
			type: [Number, String],
			default: 0
		},
		Width: {
			type: [Number, String],
			default: ""
		},
		Height: {
			type: [Number, String],
			default: ""
		},
		MinWidth: {
			type: [Number, String],
			default: 88
		},
		MinHeight: {
			type: [Number, String],
			default: 40
		},
		MaxWidth: {
			type: [Number, String],
			default: ""
		},
		MaxHeight: {
			type: [Number, String],
			default: ""
		},
		HorizontalAlignment: {
			type: String,
			default: "Stretch"
		},
		VerticalAlignment: {
			type: String,
			default: "Stretch"
		},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		IsTabStop: {
			type: [Boolean, String],
			default: !1
		},
		Visibility: {
			type: String,
			default: "Visible"
		},
		"AutomationProperties.Name": {
			type: String,
			default: ""
		}
	},
	emits: [
		"PointerEntered",
		"PointerExited",
		"ContextRequested"
	],
	setup(se, { expose: Oe, emit: ke }) {
		let p = se, Ae = ke, m = he(), je = Te(), Me = Ee(), h = _e(te, {}), Ne = _e(c, void 0), g = /* @__PURE__ */ new Map(), Pe = f(0), Fe = f(0), _ = d(() => {
			if (Pe.value, g.has("DataContext")) return g.get("DataContext");
			let e = o(p.DataContext, m);
			return e === void 0 ? we(Ne) : e;
		}), Ie = () => {
			let e = _.value;
			return {
				...e && typeof e == "object" ? e : {},
				item: e,
				Item: e,
				DataContext: e
			};
		}, v = (e) => o(e, m, Ie()), y = (e) => (Pe.value, g.has(e) ? g.get(e) : v(p[e])), Le = (e) => e === !0 || String(e).toLowerCase() === "true", b = d(() => Le(y("IsEnabled"))), Re = d(() => Le(y("IsTabStop"))), ze = d(() => y("AutomationProperties.Name")), x = d(() => le(Me.default?.() ?? [])), Be = d(() => {
			let e = x.value.find((e) => ue(e) === "Content");
			return e ? u(e) : x.value.filter((e) => !ue(e));
		}), S = f(), Ve = d(() => {
			let e = x.value.find((e) => ue(e) === "ContentTemplate");
			if (e && !g.has("ContentTemplate") && p.ContentTemplate === void 0) return u(e)[0];
			let t = g.has("ContentTemplate") ? g.get("ContentTemplate") : p.ContentTemplate, n = C(t);
			return n ? h[n] ?? a(n, m) : v(t);
		}), He = {
			get Text() {
				return S.value ?? v(Be.value[0]?.props?.Text);
			},
			set Text(e) {
				S.value = String(e ?? "");
			},
			get Element() {
				return Ye.value?.querySelector("[data-part=\"ContentPresenter\"]")?.firstElementChild;
			}
		}, Ue = me({
			name: "SwipeControlContentPresenter",
			setup() {
				let e = he(), t = d(() => {
					let e = y("Content");
					return e === void 0 ? _.value : e;
				});
				return Se(c, t), () => {
					let n = y("Content"), a = Ve.value;
					if (ve(a) && ce(a) === "DataTemplate") return ge(fe, i(r(u(a), t.value, m), e));
					if (n !== void 0) return ve(n) ? i([pe(n)], e) : n === null || typeof n == "object" ? "" : String(n);
					let o = Be.value.map((e, t) => {
						let n = pe(e);
						return S.value !== void 0 && t === 0 && (n.props = {
							...n.props,
							Text: S.value
						}), n;
					}), s = _.value;
					return i(s === void 0 ? o : r(o, s, m), e);
				};
			}
		}), We = ie(m), Ge = /* @__PURE__ */ new Map(), Ke = (e) => {
			let t = pe(e);
			t.props = Object.fromEntries(Object.entries(e.props ?? {}).map(([e, t]) => [e, typeof t == "string" && /^\{\s*(x:Bind|Binding)\b/.test(t) ? v(t) : t]));
			let n = u(e).map(Ke);
			return n.length && (t.children = { default: () => n }), t;
		};
		function C(e) {
			return typeof e == "string" ? e.match(/^\{\s*StaticResource\s+([^}]+)\}$/)?.[1]?.trim() : void 0;
		}
		let qe = (e, t) => {
			let n = We(_.value === void 0 ? e : Ke(e), t), r = C(e.props?.IconSource), i = r && h[r];
			if (i) {
				let e = Object.fromEntries(Object.entries(i.props ?? {}).filter(([e]) => !e.startsWith("x:")).map(([e, t]) => [e, v(t)])), a = JSON.stringify([r, e]), o = `${t}:IconSource`;
				Ge.get(o) !== a && (n.IconSource = e, Ge.set(o, a));
			}
			for (let r of ["Background", "Foreground"]) {
				let i = C(e.props?.[r]), a = i && h[i];
				if (!a) continue;
				let o = oe(a, m), s = JSON.stringify([i, o]), c = `${t}:${r}`;
				Ge.get(c) !== s && (n[r] = o, Ge.set(c, s));
			}
			return n;
		}, w = d(() => {
			let e = {};
			for (let t of [
				"Left",
				"Right",
				"Top",
				"Bottom"
			]) {
				let n = `${t}Items`, r = x.value.find((e) => ue(e) === n), i = g.has(n) ? g.get(n) : p[n], o = C(i), s = o ? h[o] : void 0, c = g.has(n) || i !== void 0 ? s : r ? u(r)[0] : void 0, l = c && ce(c) === "SwipeItems" ? ae(c, t, m, qe) : o ? a(o, m) : y(n);
				if (l != null) {
					if (!(l instanceof ne)) throw TypeError("SwipeControl item properties require a SwipeItems collection.");
					e[t] = l;
				}
			}
			if ((e.Left?.Size || e.Right?.Size) && (e.Top?.Size || e.Bottom?.Size)) throw Error("SwipeControl cannot mix horizontal and vertical SwipeItems.");
			return e;
		}), T = f(), Je = f(), Ye = f(), E = f(0), Xe = f(0), Ze = f(0), D = f(), O = f(0), k = f(!1), A = f(!1), j = f("idle"), Qe = d(() => D.value ? w.value[D.value] : void 0), M = d(() => Qe.value?.Mode ?? "Reveal"), N = d(() => Qe.value ? Array.from(Qe.value) : []), P = d(() => !w.value.Top?.Size && !w.value.Bottom?.Size), F = d(() => M.value === "Execute" ? P.value ? E.value : Xe.value : Ze.value), $e = d(() => Math.abs(O.value) > Math.min(Math.max(0, F.value - 1), 100)), I = () => D.value === "Left" || D.value === "Top" ? 1 : -1, et = d(() => {
			let t = Object.fromEntries(Object.keys(p).map((e) => [e, y(e)])), n = t.HorizontalAlignment === "Stretch" && (t.Width === "" || t.Width === void 0 || t.Width === null || t.Width === "Auto"), r = String(t.Margin ?? 0).split(",").map((t) => e(t.trim())), i = r[0] || "0px", a = r.length === 4 ? r[2] || "0px" : i;
			return {
				...l({
					...t,
					Background: void 0,
					BorderBrush: void 0,
					BorderThickness: void 0,
					Padding: void 0,
					CornerRadius: void 0
				}, m),
				...n ? { width: `calc(100% - ${i} - ${a})` } : {},
				touchAction: b.value ? P.value ? "pan-y" : "pan-x" : "auto"
			};
		}), tt = (e) => {
			let t = C(g.has(e) ? g.get(e) : p[e]);
			return oe(t && h[t] ? h[t] : y(e), m);
		}, nt = d(() => ({
			background: tt("Background"),
			borderColor: tt("BorderBrush"),
			borderWidth: t(y("BorderThickness")),
			padding: t(y("Padding")),
			borderRadius: String(y("CornerRadius")).split(",").map((t) => e(t.trim())).join(" "),
			pointerEvents: b.value ? void 0 : "none"
		})), rt = d(() => ({ transform: P.value ? `translate3d(${O.value}px,0,0)` : `translate3d(0,${O.value}px,0)` })), it = d(() => {
			let e = k.value || A.value || j.value !== "idle";
			return {
				visibility: e ? "visible" : "hidden",
				pointerEvents: e ? "auto" : "none"
			};
		}), at = (e) => n[e], ot = d(() => {
			let e = Math.max(0, E.value - Math.abs(O.value)), t = Math.max(0, Xe.value - Math.abs(O.value)), n = D.value === "Left" || D.value === "Top" ? N.value.at(-1) : N.value[0], r = {
				Left: `inset(0 ${e}px 0 0)`,
				Right: `inset(0 0 0 ${e}px)`,
				Top: `inset(0 0 ${t}px 0)`,
				Bottom: `inset(${t}px 0 0 0)`
			};
			return {
				background: D.value && M.value === "Reveal" ? n?.Background ?? at("SwipeItemBackground") : void 0,
				clipPath: D.value ? r[D.value] : void 0,
				visibility: D.value ? "visible" : "hidden"
			};
		}), st = d(() => {
			let e = M.value === "Execute", t = $e.value ? "SwipeItemPostThresholdExecuteBackground" : "SwipeItemPreThresholdExecuteBackground";
			return {
				flexDirection: P.value ? "row" : "column",
				width: e || !P.value ? "100%" : "max-content",
				height: e || P.value ? "100%" : "max-content",
				background: e ? N.value[0]?.Background ?? at(t) : void 0,
				transform: e ? P.value ? `translate3d(${(O.value - I() * E.value) / 2}px,0,0)` : `translate3d(0,${(O.value - I() * Xe.value) / 2}px,0)` : void 0
			};
		}), ct = (e) => {
			let t = M.value === "Execute" ? $e.value ? "SwipeItemPostThresholdExecuteForeground" : "SwipeItemPreThresholdExecuteForeground" : "SwipeItemForeground";
			return {
				background: M.value === "Execute" ? "transparent" : e.Background ?? at("SwipeItemBackground"),
				color: e.Foreground ?? at(t)
			};
		}, lt = (e) => (Fe.value, Ce(e.Command)), ut = (e) => e.Text ?? lt(e)?.Label ?? "", dt = (e) => lt(e)?.Description, ft = (e) => b.value, pt = (e) => e.IconSource ?? lt(e)?.IconSource, mt = (e) => {
			let t = pt(e);
			return typeof t == "object" ? t?.UriSource : typeof t == "string" && /^(https?:|data:)/.test(t) ? t : void 0;
		}, ht = (e) => {
			let t = pt(e);
			if (typeof t != "object") return mt(e) ? void 0 : t;
			let n = ee[t?.Symbol ?? ""]?.[1];
			return t?.Glyph ?? (n === void 0 ? void 0 : String.fromCodePoint(n));
		}, gt = (e) => {
			let t = pt(e);
			return typeof t == "object" ? { fontFamily: t?.FontFamily } : {};
		}, _t = (e) => ({ "--swipe-item-bitmap-source": `url(\"${mt(e)}\")` }), vt = () => M.value === "Execute" && N.value[0]?.BehaviorOnInvoked === "RemainOpen" && k.value, L, yt = /* @__PURE__ */ new WeakSet(), bt = (e) => {
			if (!b.value || !e.isPrimary || e.button !== 0) return;
			let t = e.currentTarget;
			yt.delete(t), L = {
				id: e.pointerId,
				x: e.clientX,
				y: e.clientY,
				element: t,
				moved: !1
			}, t.setPointerCapture(e.pointerId);
		}, xt = (e) => {
			L?.id === e.pointerId && Math.hypot(e.clientX - L.x, e.clientY - L.y) >= 5 && (L.moved = !0);
		}, R = (e = !1) => {
			let t = L;
			L = void 0, t && ((e || t.moved) && yt.add(t.element), t.element.hasPointerCapture(t.id) && t.element.releasePointerCapture(t.id));
		}, St = (e) => {
			L?.id === e.pointerId && (xt(e), R());
		}, Ct = (e) => {
			L?.id === e.pointerId && R(!0);
		}, wt = (e) => {
			L?.id === e.pointerId && R(!0);
		}, Tt = (e, t) => {
			let n = t.currentTarget;
			if (t.detail !== 0 && yt.has(n)) {
				yt.delete(n);
				return;
			}
			It(e);
		}, z, B = 0, V = !1, H = !1, U = !1, W, G = new de(() => O.value, (e) => {
			O.value = e;
		}), K = () => I() > 0 ? {
			minimum: 0,
			maximum: F.value
		} : {
			minimum: -F.value,
			maximum: 0
		}, q = () => {
			E.value = T.value?.clientWidth ?? 0, Xe.value = T.value?.clientHeight ?? 0, Ze.value = P.value ? Je.value?.scrollWidth ?? 0 : Je.value?.scrollHeight ?? 0;
		}, Et = () => {
			G.Cancel(), j.value = "idle";
		}, Dt = async (e, t, n = 0) => {
			let r = B;
			j.value = t;
			let i = await G.Settle(e, n, K());
			return i && r === B && !U && (j.value = "idle"), i && r === B && !U;
		}, J = () => {
			let e = z?.id;
			z = void 0, A.value = !1, e !== void 0 && T.value?.hasPointerCapture(e) && T.value.releasePointerCapture(e);
		};
		function Y() {
			let e = ++B;
			if (R(!0), J(), Et(), k.value = !1, !D.value || O.value === 0) {
				D.value = void 0, O.value = 0;
				return;
			}
			Dt(0, "closing").then((t) => {
				t && e === B && !z && !k.value && (D.value = void 0);
			});
		}
		let Ot = () => {
			B += 1, R(!0), J(), Et(), k.value = !1, O.value = 0, D.value = void 0;
		}, X = () => {
			vt() || Y();
		}, kt = (e) => P.value ? e.clientX : e.clientY, At = (e) => {
			!b.value || e.button !== 0 || z || !e.isPrimary || H || vt() || e.target instanceof Element && e.target.closest(".swipe-item") || (B += 1, Et(), z = {
				id: e.pointerId,
				x: e.clientX,
				y: e.clientY,
				offset: O.value,
				requestedOffset: O.value,
				opened: k.value,
				last: e.timeStamp,
				position: kt(e),
				velocity: 0
			});
		}, jt = (e) => {
			let t = z;
			if (!t || t.id !== e.pointerId) return;
			let n = e.clientX - t.x, r = e.clientY - t.y, i = P.value ? n : r;
			if (!A.value) {
				if (Math.abs(i) < 5) return;
				if (Math.abs(P.value ? r : n) > Math.abs(i)) {
					J();
					return;
				}
				let t = P.value ? i > 0 ? "Left" : "Right" : i > 0 ? "Top" : "Bottom";
				if (!D.value) {
					if (!w.value[t]?.Size) {
						J();
						return;
					}
					D.value = t;
				}
				A.value = !0, T.value?.setPointerCapture(e.pointerId), document.dispatchEvent(new CustomEvent("winui-swipe-interaction", { detail: Z })), q();
			}
			if (t.requestedOffset = t.offset + i, !t.opened && t.requestedOffset * I() < 0) {
				let e = P.value ? t.requestedOffset > 0 ? "Left" : "Right" : t.requestedOffset > 0 ? "Top" : "Bottom";
				w.value[e]?.Size && (D.value = e);
			}
			G.TryUpdatePosition(t.requestedOffset, K()), ye(() => {
				z !== t || !A.value || U || (q(), G.TryUpdatePosition(t.requestedOffset, K()));
			});
			let a = e.timeStamp - t.last;
			a > 0 && (t.velocity = (kt(e) - t.position) / a), t.position = kt(e), t.last = e.timeStamp, e.preventDefault();
		}, Mt = async (e) => {
			let t = z;
			if (!t || t.id !== e.pointerId) return;
			let n = B, r = A.value, i = e.timeStamp - t.last < 100 ? t.velocity : 0;
			if (r && (t.requestedOffset = t.offset + (P.value ? e.clientX - t.x : e.clientY - t.y)), J(), !r) {
				t.opened && X();
				return;
			}
			if (V = !0, await ye(), n !== B || U || !b.value || !D.value) return;
			q(), G.TryUpdatePosition(t.requestedOffset, K());
			let a = G.NaturalRestingPosition(i), o = a * I(), s = t.opened ? F.value : Math.min(F.value, 100), c = F.value > 0 && o >= s;
			if (a * O.value < 0) {
				Ot();
				return;
			}
			if (!c) {
				Y();
				return;
			}
			let l = N.value[0], ee = M.value === "Execute";
			k.value = !0, !(!await Dt(I() * F.value, "opening", i) || n !== B || U || !b.value || !k.value) && ee && l && N.value.includes(l) && It(l);
		}, Nt = (e) => {
			z?.id === e.pointerId && Y();
		}, Pt = (e) => {
			z?.id === e.pointerId && Y();
		}, Ft = (e) => {
			(!b.value || e.detail !== 0 && V) && (V = !1, e.preventDefault(), e.stopImmediatePropagation());
		};
		function It(e) {
			if (!(H || !ft(e) || j.value !== "idle" || !N.value.includes(e))) {
				H = !0;
				try {
					e.Invoked?.(e, { SwipeControl: Z });
					let t = lt(e);
					(t?.CanExecute?.(e.CommandParameter) ?? !0) && t?.Execute(e.CommandParameter), (e.BehaviorOnInvoked ?? "Auto") !== "RemainOpen" && Y();
				} finally {
					H = !1;
				}
			}
		}
		let Lt = (e, t) => {
			g.set(e, t), Pe.value += 1;
		}, Z = {
			Close: Y,
			get Content() {
				let e = y("Content");
				return e === void 0 ? He : e;
			},
			set Content(e) {
				S.value = void 0, Lt("Content", e);
			},
			get ContentTemplate() {
				return Ve.value;
			},
			set ContentTemplate(e) {
				Lt("ContentTemplate", e);
			},
			get DataContext() {
				return _.value;
			},
			set DataContext(e) {
				Lt("DataContext", e);
			},
			get Element() {
				return T.value;
			}
		};
		Object.defineProperty(Z, s, { value: !0 });
		for (let e of Object.keys(p)) e in Z || Object.defineProperty(Z, e, {
			enumerable: !0,
			get: () => e.endsWith("Items") ? w.value[e.replace("Items", "")] ?? null : e === "IsEnabled" ? b.value : e === "IsTabStop" ? Re.value : y(e),
			set: (t) => {
				if (e.endsWith("Items") && t != null && !(t instanceof ne)) throw TypeError("SwipeControl item properties require a SwipeItems collection.");
				if (e.endsWith("Items") && t instanceof ne) {
					let n = e.replace("Items", ""), r = {
						...w.value,
						[n]: t
					};
					if ((r.Left?.Size || r.Right?.Size) && (r.Top?.Size || r.Bottom?.Size)) throw TypeError("SwipeControl cannot mix horizontal and vertical SwipeItems.");
				}
				Lt(e, t), (e.endsWith("Items") || e === "IsEnabled") && Y();
			}
		});
		Oe(Z);
		let Rt = (e) => {
			V = !1, M.value === "Reveal" && (k.value || j.value === "opening") && !T.value?.contains(e.target) && X();
		}, zt = (e) => {
			z && !T.value?.contains(e.target) && jt(e);
		}, Bt = (e) => {
			e.detail !== Z && (k.value || j.value === "opening") && X();
		}, Vt = () => {
			M.value === "Reveal" && (k.value || j.value === "opening") && X();
		}, Ht = () => {
			R(!0), z ? Y() : M.value === "Reveal" && (k.value || j.value === "opening") && X();
		}, Ut = () => {
			document.hidden && Ht();
		}, Wt = (e) => {
			if (!b.value) return;
			let t = {
				OriginalSource: e.target,
				Position: {
					X: e.clientX,
					Y: e.clientY
				},
				Handled: !1,
				TryGetPosition(t) {
					let n = (t instanceof HTMLElement ? t : t?.Element)?.getBoundingClientRect();
					return {
						X: e.clientX - (n?.left ?? 0),
						Y: e.clientY - (n?.top ?? 0)
					};
				}
			};
			Ae("ContextRequested", Z, t), t.Handled && e.preventDefault();
		};
		De(b, (e) => {
			e || Y();
		});
		let Gt = {}, Kt = {}, Q = [], $ = [];
		De(() => Object.values(w.value).flatMap((e) => Array.from(e, (e) => Ce(e.Command))), (e) => {
			for (let e of $) e();
			$ = [];
			for (let t of new Set(e.filter(Boolean))) {
				let e = () => {
					Fe.value += 1;
				};
				t?.addEventListener?.("CanExecuteChanged", e), t?.addEventListener?.("PropertyChanged", e), $.push(() => {
					t?.removeEventListener?.("CanExecuteChanged", e), t?.removeEventListener?.("PropertyChanged", e);
				});
			}
			Fe.value += 1;
		}, {
			immediate: !0,
			flush: "sync"
		}), De(() => ({
			collections: w.value,
			vectors: Object.values(w.value).map((e) => ({
				Mode: e.Mode,
				items: Array.from(e)
			}))
		}), ({ collections: e }) => {
			for (let e of Q) e();
			Q = [], Kt = e;
			for (let t of new Set(Object.values(e))) t instanceof ne && Q.push(re(t, Gt, (e) => {
				let n = (n) => {
					let r = Kt[n];
					return r === t ? e : r?.Size ?? 0;
				};
				if ((n("Left") || n("Right")) && (n("Top") || n("Bottom"))) throw TypeError("SwipeControl cannot mix horizontal and vertical SwipeItems.");
			}));
			D.value && !e[D.value]?.Size && Ot(), ye(() => {
				U || (q(), z && A.value ? G.TryUpdatePosition(z.requestedOffset, K()) : k.value && j.value === "idle" && (O.value = I() * F.value));
			});
		}, {
			deep: !0,
			immediate: !0,
			flush: "sync"
		});
		for (let e of Object.keys(p)) De(() => p[e], () => {
			g.delete(e), e === "Content" && (S.value = void 0), Pe.value += 1;
		});
		xe(() => {
			W = new ResizeObserver(() => {
				q(), z && A.value ? G.TryUpdatePosition(z.requestedOffset, K()) : k.value && j.value === "idle" && (O.value = I() * F.value);
			}), T.value && W.observe(T.value), Je.value && W.observe(Je.value), q(), document.addEventListener("pointerdown", Rt, !0), document.addEventListener("keydown", Vt, !0), document.addEventListener("winui-swipe-interaction", Bt), document.addEventListener("visibilitychange", Ut), window.addEventListener("pointerup", Mt), window.addEventListener("pointermove", zt), window.addEventListener("pointercancel", Nt), window.addEventListener("blur", Ht);
		}), be(() => {
			U = !0, B += 1, R(!0), J(), Et(), W?.disconnect();
			for (let e of Q) e();
			for (let e of $) e();
			document.removeEventListener("pointerdown", Rt, !0), document.removeEventListener("keydown", Vt, !0), document.removeEventListener("winui-swipe-interaction", Bt), document.removeEventListener("visibilitychange", Ut), window.removeEventListener("pointerup", Mt), window.removeEventListener("pointermove", zt), window.removeEventListener("pointercancel", Nt), window.removeEventListener("blur", Ht);
		});
		let qt = {
			props: p,
			emit: Ae,
			instance: m,
			attrs: je,
			slots: Me,
			dictionary: h,
			itemContext: Ne,
			assignments: g,
			revision: Pe,
			commandRevision: Fe,
			dataContext: _,
			bindingScope: Ie,
			resolve: v,
			readProperty: y,
			isTrue: Le,
			enabled: b,
			tabStop: Re,
			automationName: ze,
			nodes: x,
			contentNodes: Be,
			contentText: S,
			contentTemplate: Ve,
			contentApi: He,
			ContentOutlet: Ue,
			readItem: We,
			resourceItemSources: Ge,
			scopedItemNode: Ke,
			staticResourceKey: C,
			materializedResourceItem: qe,
			collections: w,
			root: T,
			panel: Je,
			contentRoot: Ye,
			width: E,
			height: Xe,
			panelExtent: Ze,
			side: D,
			offset: O,
			open: k,
			interacting: A,
			phase: j,
			activeCollection: Qe,
			mode: M,
			currentItems: N,
			horizontal: P,
			extent: F,
			thresholdReached: $e,
			sign: I,
			rootStyle: et,
			brush: tt,
			presenterStyle: nt,
			contentTransform: rt,
			inputEaterStyle: it,
			resource: at,
			underlayStyle: ot,
			panelStyle: st,
			itemStyle: ct,
			itemCommand: lt,
			itemLabel: ut,
			itemDescription: dt,
			itemEnabled: ft,
			icon: pt,
			iconUri: mt,
			iconGlyph: ht,
			iconStyle: gt,
			bitmapStyle: _t,
			remainOpen: vt,
			get itemPointer() {
				return L;
			},
			set itemPointer(e) {
				L = e;
			},
			ignoredItemClicks: yt,
			itemPointerDown: bt,
			itemPointerMove: xt,
			releaseItemPointer: R,
			itemPointerUp: St,
			itemPointerCancel: Ct,
			itemPointerCaptureLost: wt,
			itemClicked: Tt,
			get pointer() {
				return z;
			},
			set pointer(e) {
				z = e;
			},
			get operation() {
				return B;
			},
			set operation(e) {
				B = e;
			},
			get suppressDragClick() {
				return V;
			},
			set suppressDragClick(e) {
				V = e;
			},
			get invoking() {
				return H;
			},
			set invoking(e) {
				H = e;
			},
			get disposed() {
				return U;
			},
			set disposed(e) {
				U = e;
			},
			get resizeObserver() {
				return W;
			},
			set resizeObserver(e) {
				W = e;
			},
			tracker: G,
			bounds: K,
			measure: q,
			stopAnimation: Et,
			animateTo: Dt,
			release: J,
			Close: Y,
			closeWithoutAnimation: Ot,
			dismiss: X,
			coordinate: kt,
			pointerDown: At,
			pointerMove: jt,
			pointerUp: Mt,
			pointerCancel: Nt,
			captureLost: Pt,
			suppressClick: Ft,
			invoke: It,
			assignProperty: Lt,
			exposed: Z,
			outsidePointer: Rt,
			outsidePointerMove: zt,
			otherInteraction: Bt,
			keyDown: Vt,
			cancelInteraction: Ht,
			visibilityChanged: Ut,
			contextRequested: Wt,
			collectionOwner: Gt,
			get observedCollections() {
				return Kt;
			},
			set observedCollections(e) {
				Kt = e;
			},
			get collectionSubscriptions() {
				return Q;
			},
			set collectionSubscriptions(e) {
				Q = e;
			},
			get commandSubscriptions() {
				return $;
			},
			set commandSubscriptions(e) {
				$ = e;
			}
		};
		return Object.defineProperty(qt, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), qt;
	}
});
//#endregion
export { Oe as default };

//# sourceMappingURL=SwipeControl.vue_vue_type_script_setup_true_lang.js.map