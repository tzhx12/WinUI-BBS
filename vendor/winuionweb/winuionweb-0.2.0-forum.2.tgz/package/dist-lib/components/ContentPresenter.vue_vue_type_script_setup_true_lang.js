import { alignment as e, applyContentPresenterChildren as t, useLayoutObserver as n } from "./layout.js";
import { clampOpacity as r, cssColor as i } from "./brushCore.js";
import { normalizeXamlNodes as a, resolveXamlValue as o, xamlTemplateComponent as s } from "./xamlRuntime.js";
import { getVNodeChildren as c } from "./CollectionProperties.js";
import l from "./Border.vue.js";
import { Fragment as u, computed as d, defineComponent as f, getCurrentInstance as p, h as m, isVNode as h, ref as g, useSlots as _ } from "vue";
//#region src/components/ContentPresenter.vue?vue&type=script&setup=true&lang.ts
var v = /*@__PURE__*/ f({
	inheritAttrs: !1,
	__name: "ContentPresenter",
	props: {
		Content: {
			type: null,
			default: ""
		},
		ContentTemplate: {
			type: null,
			default: void 0
		},
		ContentTransitions: {
			type: null,
			default: void 0
		},
		Foreground: {
			type: [String, Object],
			default: ""
		},
		HorizontalContentAlignment: {
			type: String,
			default: "Stretch"
		},
		VerticalContentAlignment: {
			type: String,
			default: "Stretch"
		}
	},
	setup(v, { expose: y }) {
		y();
		let b = v, x = p(), S = _(), C = g(null), w = (e) => {
			if (e instanceof HTMLElement) C.value = e;
			else {
				let t = e;
				C.value = t?.Element ?? t?.$el ?? null;
			}
		};
		n(C, () => {
			C.value && t(C.value, o(b.HorizontalContentAlignment, x), o(b.VerticalContentAlignment, x));
		});
		let T = d(() => o(b.Content, x)), E = d(() => o(b.ContentTemplate, x)), D = d(() => {
			let e = o(b.Foreground, x);
			if (e) {
				if (typeof e == "object" && "Color" in e) {
					let t = i(e.Color), n = "Opacity" in e ? e.Opacity : void 0;
					return n === void 0 || n === 1 ? t : `color-mix(in srgb, ${t} ${r(n) * 100}%, transparent)`;
				}
				return i(e);
			}
		}), O = {
			props: b,
			instance: x,
			slots: S,
			root: C,
			registerRoot: w,
			resolvedContent: T,
			resolvedTemplate: E,
			foreground: D,
			ContentOutlet: f({ setup: () => () => {
				if (S.default) return m(u, a(S.default(), x));
				let e = E.value;
				if (h(e)) {
					let t = e.type;
					return s((t?.name ?? t?.__name) === "DataTemplate" ? c(e) : [e], T.value, x);
				}
				if (typeof e == "function") return e(T.value);
				let t = T.value;
				return h(t) ? m(u, a([t], x)) : typeof t == "string" || typeof t == "number" ? String(t) : null;
			} }),
			contentStyle: d(() => ({
				color: D.value,
				justifyItems: e(o(b.HorizontalContentAlignment, x), "horizontal"),
				alignItems: e(o(b.VerticalContentAlignment, x), "vertical")
			})),
			Border: l
		};
		return Object.defineProperty(O, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), O;
	}
});
//#endregion
export { v as default };

//# sourceMappingURL=ContentPresenter.vue_vue_type_script_setup_true_lang.js.map