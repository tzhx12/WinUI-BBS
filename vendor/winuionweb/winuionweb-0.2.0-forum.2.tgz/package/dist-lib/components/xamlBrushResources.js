import { xamlBrushResourceKey as e } from "./brushCore.js";
import { resolveXamlValue as t } from "./xamlRuntime.js";
import { Fragment as n, cloneVNode as r, computed as i, inject as a, onBeforeUnmount as o, provide as s, shallowReactive as c, shallowRef as l, unref as u } from "vue";
//#region src/components/xamlBrushResources.ts
var d = (e) => Array.isArray(e.children) ? e.children : e.children?.default?.() ?? [], f = (e) => {
	let t = e.props?.["x:Key"] ?? e.props?.["x:Name"];
	return typeof t == "string" ? t.trim() : "";
}, p = (e, t) => {
	if (e === t) return !0;
	if (!e || !t || e.type !== t.type) return !1;
	let n = e.props ?? {}, r = t.props ?? {}, i = (e) => Object.keys(e).filter((e) => e !== "ref" && !e.startsWith("onVnode") && !e.startsWith("onUpdate:")), a = i(n), o = i(r);
	if (a.length !== o.length || !a.every((e) => Object.prototype.hasOwnProperty.call(r, e) && Object.is(n[e], r[e]))) return !1;
	if (e.type.__xamlBrush && e.children === t.children) return !0;
	if (typeof e.children == "string" || typeof t.children == "string") return e.children === t.children;
	let s = d(e), c = d(t);
	return s.length === c.length && s.every((e, t) => p(e, c[t]));
}, m = (e, t, i = "") => {
	for (let a of e) {
		if (!a || typeof a != "object") continue;
		if (a.type === n) {
			m(d(a), t, i);
			continue;
		}
		let e = a.type;
		if (e.__xamlThemeDictionaries) {
			for (let e of d(a)) m(d(e), t, f(e));
			continue;
		}
		if (e.__xamlResourceDictionary) {
			m(d(a), t, i);
			continue;
		}
		let o = f(a);
		o && (t[i ? `${i}:${o}` : o] = i ? r(a, { __xamlResourceTheme: i }) : a);
	}
}, h = (n, r) => {
	let d = a(e, {}), m = c({});
	s(e, i(() => ({
		...u(d),
		...m
	})));
	let h = /* @__PURE__ */ new Map(), g = /* @__PURE__ */ new Map();
	return o(() => {
		if (h.forEach((e) => e.dispose()), h.clear(), r) for (let [e, t] of g) r[e] === t && delete r[e];
		g.clear();
	}), { sync: (e) => {
		let i = Object.fromEntries(Object.entries(e).filter(([, e]) => {
			let t = e.type;
			return t.__xamlBrush || t.__xamlDependencyObject;
		}));
		for (let [e, t] of h) {
			let n = i[e];
			n?.type === t.type && n.type.__createXamlResource === t.factory || (t.dispose(), h.delete(e));
		}
		let a = {}, o = /* @__PURE__ */ new Map();
		for (let [e, r] of Object.entries(i)) {
			let i = r.type.__createXamlResource;
			if (!i) continue;
			let s = h.get(e);
			if (!s) {
				let a = l(r), o = [];
				s = {
					node: a,
					type: r.type,
					factory: i,
					value: i((e) => t(a.value.props?.[e], n), {
						instance: n,
						Node: () => a.value,
						Dispose: (e) => o.push(e)
					}),
					dispose: () => o.forEach((e) => e())
				}, h.set(e, s);
			}
			p(s.node.value, r) || (s.node.value = r);
			let c = f(r), u = String(r.props?.__xamlResourceTheme ?? "");
			if (u) {
				let e = a[c] ??= { __xamlThemeResource: !0 };
				e[u] = s.value, u === "Default" && o.set(c, s.value);
			} else a[c] = s.value, o.set(c, s.value);
		}
		for (let e of Object.keys(m)) e in a || delete m[e];
		for (let [e, t] of Object.entries(a)) {
			let n = t;
			if (n?.__xamlThemeResource) {
				let t = m[e], r = t?.__xamlThemeResource ? t : c({ __xamlThemeResource: !0 });
				for (let e of Object.keys(r)) e in n || delete r[e];
				for (let [e, t] of Object.entries(n)) r[e] !== t && (r[e] = t);
				m[e] !== r && (m[e] = r);
			} else m[e] !== t && (m[e] = t);
		}
		if (r) {
			for (let [e, t] of g) !o.has(e) && r[e] === t && delete r[e];
			for (let [e, t] of o) r[e] !== t && (r[e] = t);
			g.clear(), o.forEach((e, t) => g.set(t, e));
		}
	} };
};
//#endregion
export { m as collectXamlResources, h as useXamlBrushResources, f as xamlResourceKey, p as xamlResourceNodesEqual };

//# sourceMappingURL=xamlBrushResources.js.map