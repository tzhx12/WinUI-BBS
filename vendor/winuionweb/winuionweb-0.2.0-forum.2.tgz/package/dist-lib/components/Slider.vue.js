import { alignment as e, boolValue as t, cssLength as n, xamlThickness as r } from "./layout.js";
import { normalizeXamlNodes as i, resolveXamlHandler as ee, resolveXamlResourceObject as te, resolveXamlValue as ne, updateXamlBinding as a, xamlScopeKey as re } from "./xamlRuntime.js";
import o from "../_virtual/_plugin-vue_export-helper.js";
import ie from "./Grid.vue.js";
import ae from "./TextBlock.vue.js";
import oe from "./Border.vue.js";
import se from "./ColumnDefinition.vue.js";
import ce from "./RowDefinition.vue.js";
import { SliderHeaderProperty as le } from "./inlineControlProperties.js";
import ue from "./ToolTip.vue.js";
import de from "./Ellipse.vue.js";
/* empty css                                           */
import { Fragment as s, computed as c, createBlock as fe, createCommentVNode as pe, createElementBlock as l, createElementVNode as u, createVNode as d, defineComponent as me, getCurrentInstance as he, h as ge, inject as _e, isVNode as ve, mergeProps as ye, nextTick as be, normalizeClass as f, normalizeStyle as p, onBeforeUnmount as xe, onMounted as Se, openBlock as m, provide as Ce, reactive as we, ref as h, renderList as g, unref as Te, useAttrs as Ee, useSlots as De, watch as _, withCtx as v, withModifiers as y } from "vue";
//#region src/components/Slider.vue
var Oe = /*@__PURE__*/ Object.assign({ Header: le }, {
	name: "Slider",
	inheritAttrs: !1
}, {
	__name: "Slider",
	props: {
		Value: {
			type: [Number, String],
			default: 0
		},
		Minimum: {
			type: [Number, String],
			default: 0
		},
		Maximum: {
			type: [Number, String],
			default: 100
		},
		SmallChange: {
			type: [Number, String],
			default: 1
		},
		LargeChange: {
			type: [Number, String],
			default: 10
		},
		StepFrequency: {
			type: [Number, String],
			default: 1
		},
		Header: {
			type: [
				String,
				Number,
				Object
			],
			default: ""
		},
		Orientation: {
			type: String,
			default: "Horizontal"
		},
		IsDirectionReversed: {
			type: [Boolean, String],
			default: !1
		},
		TickFrequency: {
			type: [Number, String],
			default: 0
		},
		TickPlacement: {
			type: String,
			default: "None"
		},
		SnapsTo: {
			type: String,
			default: "StepValues"
		},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		IsThumbToolTipEnabled: {
			type: [Boolean, String],
			default: !0
		},
		ThumbToolTipValueConverter: {
			type: [
				String,
				Function,
				Object
			],
			default: null
		},
		Width: {
			type: [String, Number],
			default: ""
		},
		Height: {
			type: [String, Number],
			default: ""
		},
		MinWidth: {
			type: [String, Number],
			default: 0
		},
		MinHeight: {
			type: [String, Number],
			default: 0
		},
		MaxWidth: {
			type: [String, Number],
			default: ""
		},
		MaxHeight: {
			type: [String, Number],
			default: ""
		},
		Margin: {
			type: [String, Number],
			default: 0
		},
		Padding: {
			type: [String, Number],
			default: 0
		},
		CornerRadius: {
			type: [String, Number],
			default: "{ThemeResource SliderTrackCornerRadius}"
		},
		Background: {
			type: [String, Object],
			default: "{ThemeResource SliderTrackFill}"
		},
		Foreground: {
			type: [String, Object],
			default: "{ThemeResource SliderTrackValueFill}"
		},
		HorizontalAlignment: {
			type: String,
			default: "Stretch"
		},
		VerticalAlignment: {
			type: String,
			default: "Stretch"
		},
		FlowDirection: {
			type: String,
			default: ""
		},
		RequestedTheme: {
			type: String,
			default: "Default"
		},
		Visibility: {
			type: String,
			default: "Visible"
		},
		IsHitTestVisible: {
			type: [Boolean, String],
			default: !0
		},
		IsTabStop: {
			type: [Boolean, String],
			default: !0
		},
		TabIndex: {
			type: [Number, String],
			default: 0
		},
		IsFocusEngagementEnabled: {
			type: [Boolean, String],
			default: !0
		}
	},
	emits: [
		"update:Value",
		"update:SnapsTo",
		"update:Minimum",
		"update:Maximum",
		"update:SmallChange",
		"update:LargeChange",
		"update:StepFrequency",
		"update:TickFrequency",
		"update:IsEnabled",
		"update:IsThumbToolTipEnabled",
		"update:Orientation",
		"update:IsDirectionReversed",
		"update:TickPlacement",
		"update:Header",
		"update:Width",
		"update:Height",
		"ValueChanged"
	],
	setup(o, { expose: fe, emit: pe }) {
		let l = o, u = pe, d = Ee(), ye = De(), f = he(), p = _e("winuiTheme", null), m = (e) => ne(e, f), g = we({}), v = (e) => e in g ? g[e] : m(l[e]), y = (e, t = 0) => Number.isFinite(Number(e)) ? Number(e) : t, Oe = h(null), b = h(null), x = h(null), S = h(null), C = h(null), w = h(null), ke = h(!1), Ae = h("mouse"), T = h(null), E = h(!1), D = h(!1), je = h(!1), O = h(!1), k = h(!1), Me = h(!1), A = h(100), Ne = h(!1), j = c(() => y(v("Minimum"))), M = c(() => Math.max(j.value, y(v("Maximum"), 100))), N = (e) => Math.max(j.value, Math.min(M.value, y(e, j.value))), Pe = c(() => N(m(l.Value))), P = c(() => N(w.value ?? Pe.value)), Fe = c(() => N(C.value ?? P.value)), F = c(() => v("Orientation") === "Vertical" ? "Vertical" : "Horizontal"), I = c(() => t(v("IsEnabled"))), Ie = c(() => I.value && t(v("IsThumbToolTipEnabled"))), Le = c(() => t(m(l.IsTabStop))), Re = c(() => y(m(l.TabIndex))), L = c(() => t(v("IsDirectionReversed"))), R = c(() => L.value !== Ne.value), ze = c(() => F.value === "Horizontal" ? R.value : L.value), Be = c(() => Math.max(0, y(v("StepFrequency"), 1))), z = c(() => Math.max(0, y(v("TickFrequency")))), B = c(() => String(v("TickPlacement"))), Ve = c(() => T.value ?? m(l.SnapsTo)), He = c(() => Ve.value === "Ticks"), V = c(() => v("Header") ?? ""), Ue = c(() => m(d["AutomationProperties.Name"])), We = c(() => {
			let e = [], t = (n) => {
				for (let r of n) r?.type === s && Array.isArray(r.children) ? t(r.children) : r?.type?.__sliderHeaderProperty && e.push(...r.children?.default?.() || []);
			};
			return t(ye.default?.() || []), i(e, f);
		}), Ge = c(() => We.value.length > 0), Ke = c(() => V.value && typeof V.value == "object" && ("render" in V.value || "setup" in V.value)), qe = c(() => Ge.value || ve(V.value) || Ke.value), Je = me({ setup: () => () => Ge.value ? ge(s, We.value) : ve(V.value) ? ge(s, i([V.value], f)) : Ke.value ? ge(V.value) : null }), Ye = c(() => ["Light", "Dark"].includes(m(l.RequestedTheme)) ? String(m(l.RequestedTheme)).toLowerCase() : Te(p)), Xe = c(() => ["light", "dark"].includes(Ye.value) ? `win-theme-scope theme-${Ye.value}` : "");
		Ce("winuiTheme", Ye);
		let Ze = c(() => Object.fromEntries(Object.entries(d).filter(([e]) => ![
			"class",
			"style",
			"ValueChanged",
			"onValueChanged"
		].includes(e) && !e.startsWith("onUpdate:")))), Qe = c(() => {
			let i = {
				margin: r(m(l.Margin)),
				justifySelf: e(m(l.HorizontalAlignment), "horizontal"),
				alignSelf: e(m(l.VerticalAlignment), "vertical")
			};
			for (let e of [
				"Width",
				"Height",
				"MinWidth",
				"MinHeight",
				"MaxWidth",
				"MaxHeight"
			]) {
				let t = v(e);
				t !== "" && t !== "Auto" && (i[e[0].toLowerCase() + e.slice(1)] = n(t));
			}
			return i.direction = m(l.FlowDirection) === "RightToLeft" ? "rtl" : m(l.FlowDirection) === "LeftToRight" ? "ltr" : void 0, i.display = m(l.Visibility) === "Collapsed" ? "none" : void 0, i.pointerEvents = t(m(l.IsHitTestVisible)) ? void 0 : "none", F.value === "Vertical" && !v("Width") && (i.width = "32px"), F.value === "Vertical" && !v("Height") && (i.height = "100px"), [d.style, i];
		}), $e = c(() => I.value ? O.value ? "Pressed" : E.value ? "PointerOver" : "" : "Disabled"), H = (e, t = $e.value) => m(`{ThemeResource ${e}${t}}`), et = c(() => ({
			"--slider-track-fill": $e.value ? H("SliderTrackFill") : m(l.Background),
			"--slider-value-fill": $e.value ? H("SliderTrackValueFill") : m(l.Foreground),
			"--slider-tick-fill": H("SliderTickBarFill", I.value ? "" : "Disabled"),
			"--slider-inline-tick-fill": m("{ThemeResource SliderInlineTickBarFill}"),
			"--slider-track-radius": n(m(l.CornerRadius))
		})), tt = c(() => M.value === j.value ? 0 : (Fe.value - j.value) / (M.value - j.value)), nt = c(() => ze.value ? 1 - tt.value : tt.value), rt = c(() => Math.max(0, A.value - 18) * tt.value), it = c(() => Math.max(0, A.value - 18) * nt.value), at = c(() => F.value === "Vertical" ? {
			height: `${rt.value}px`,
			top: L.value ? 0 : "auto",
			bottom: L.value ? "auto" : 0
		} : {
			width: `${rt.value}px`,
			left: R.value ? "auto" : 0,
			right: R.value ? 0 : "auto"
		}), ot = c(() => z.value > 0 && ["Outside", "TopLeft"].includes(B.value)), st = c(() => z.value > 0 && [
			"Outside",
			"BottomRight",
			"Inline"
		].includes(B.value)), ct = c(() => {
			if (!ot.value && !st.value) return [];
			let e = (M.value - j.value) / z.value, t = Math.max(1, Math.ceil(20 * e / Math.max(1, A.value - 18)));
			return Array.from({ length: Math.min(1e3, Math.floor(e / t) + 1) }, (e, n) => j.value + n * z.value * t);
		}), lt = (e) => {
			let t = M.value === j.value ? 0 : (e - j.value) / (M.value - j.value), n = 8.5 + Math.max(0, A.value - 18) * (ze.value ? 1 - t : t);
			return F.value === "Vertical" ? { bottom: `${n}px` } : { left: `${n}px` };
		}, ut = (e, t) => {
			let n = N(e);
			if (!(t > 0)) return n;
			let r = Math.min(M.value, Math.ceil(n / t) * t), i = Math.max(j.value, Math.floor(n / t) * t);
			return Number(N(r - n < n - i - 1e-10 ? r : i).toPrecision(14));
		}, dt = (e) => ut(e, He.value ? z.value : Be.value), U = (e) => {
			let t = N(e), n = P.value;
			if (w.value = t, a(l.Value, t, f), u("update:Value", t), n !== t) {
				let e = {
					OldValue: n,
					NewValue: t
				}, r = f?.exposeProxy ?? f?.proxy;
				u("ValueChanged", r, e), ee(d.ValueChanged, f)?.(r, e);
			}
		}, ft = c(() => {
			let e = l.ThumbToolTipValueConverter, t = typeof e == "string" ? e.match(/^\{(?:StaticResource|ThemeResource)\s+([^\s}]+)\}$/)?.[1] : null, n = t ? te(t, f) : m(e);
			if (n) try {
				let e = typeof n == "function" ? n(P.value) : n.Convert?.(P.value, {
					Name: "String",
					Kind: "Primitive"
				}, f?.exposeProxy ?? f?.proxy, document.documentElement.lang);
				if (e !== void 0) return e === null ? "" : String(typeof e == "object" ? e.Text ?? e.Content ?? "" : e);
			} catch {}
			let r = 0, i = Be.value;
			for (; r < 4 && Math.abs(i - Math.round(i)) > 1e-5;) r++, i *= 10;
			return P.value.toFixed(r);
		}), pt = we({
			Header: V,
			Padding: c(() => m(l.Padding)),
			ToolTipOpen: ke,
			ToolTipEnabled: Ie,
			ToolTipContent: ft,
			ToolTipTarget: c(() => x.value),
			ToolTipPlacement: c(() => F.value === "Vertical" ? "Left" : "Top"),
			ToolTipOffset: c(() => Ae.value === "touch" ? 44 : Ae.value === "keyboard" ? 12 : 20),
			ThumbBackground: c(() => H("SliderThumbBackground")),
			FirstRow: c(() => F.value === "Horizontal" ? 14 : "*"),
			MiddleRow: c(() => "Auto"),
			LastRow: c(() => F.value === "Horizontal" ? 14 : it.value),
			FirstColumn: c(() => F.value === "Horizontal" ? it.value : 14),
			MiddleColumn: c(() => "Auto"),
			LastColumn: c(() => F.value === "Horizontal" ? "*" : 14),
			TrackRow: c(() => +(F.value === "Horizontal")),
			TrackColumn: c(() => F.value === "Horizontal" ? 0 : 1),
			TrackRowSpan: c(() => F.value === "Horizontal" ? 1 : 3),
			TrackColumnSpan: c(() => F.value === "Horizontal" ? 3 : 1),
			DecreaseRow: c(() => F.value === "Horizontal" ? 1 : L.value ? 0 : 2),
			DecreaseColumn: c(() => F.value === "Horizontal" ? 0 : 1),
			DecreaseRowSpan: c(() => F.value === "Horizontal" ? 1 : 3),
			DecreaseColumnSpan: c(() => F.value === "Horizontal" ? 3 : 1),
			ThumbRow: c(() => F.value === "Horizontal" ? 0 : 1),
			ThumbColumn: c(() => +(F.value === "Horizontal")),
			ThumbRowSpan: c(() => F.value === "Horizontal" ? 3 : 1),
			ThumbColumnSpan: c(() => F.value === "Horizontal" ? 1 : 3),
			TickRowSpan: c(() => F.value === "Horizontal" ? 1 : 3),
			TickColumnSpan: c(() => F.value === "Horizontal" ? 3 : 1),
			LastTickRow: c(() => F.value === "Horizontal" ? B.value === "Inline" ? 1 : 2 : 0),
			LastTickColumn: c(() => F.value === "Horizontal" ? 0 : B.value === "Inline" ? 1 : 2)
		});
		Ce(re, { SliderTemplate: pt });
		let W = (e = !0, t = "mouse") => {
			Ae.value = t, Ie.value && S.value?.show?.(e);
		}, G = () => S.value?.hide?.(), mt = (e) => {
			E.value = e.pointerType !== "touch", e.pointerType === "touch" && W(!0, "touch");
		}, ht = (e) => {
			E.value = !1, e.pointerType === "touch" && !O.value && !k.value && G();
		}, gt = (e) => {
			D.value = e.pointerType !== "touch", !O.value && !k.value && W(e.pointerType === "touch", e.pointerType === "touch" ? "touch" : "mouse");
		}, _t = () => {
			D.value = !1, !O.value && !k.value && G();
		}, vt = () => {
			b.value?.matches(":focus-visible") && (k.value = !0, W(!0, "keyboard"));
		}, yt = () => {
			k.value = !1, G();
		}, K = null, q = null, J = 0, bt = (e) => {
			let t = b.value.getBoundingClientRect(), n = F.value === "Vertical" ? t.height : t.width, r = F.value === "Vertical" ? t.bottom - e.clientY + J : e.clientX - t.left - J, i = Math.max(0, Math.min(1, (r - 9) / Math.max(1, n - 18)));
			C.value = j.value + (ze.value ? 1 - i : i) * (M.value - j.value), U(dt(C.value));
		}, xt = () => {
			window.removeEventListener("pointermove", St, !0), window.removeEventListener("pointerup", Ct, !0), window.removeEventListener("pointercancel", Tt, !0), window.removeEventListener("blur", Et);
		}, Y = () => {
			let e = K, t = q;
			K = null, q = null, J = 0, C.value = null, Me.value = !1, O.value = !1, je.value = !1, xt(), t?.hasPointerCapture?.(e) && t.releasePointerCapture(e), G();
		}, St = (e) => {
			e.pointerId === K && (e.preventDefault(), bt(e));
		}, Ct = (e) => {
			e.pointerId === K && (bt(e), Y());
		}, wt = () => {
			E.value = !1, D.value = !1, Y();
		}, Tt = (e) => {
			e.pointerId === K && wt();
		}, Et = () => {
			k.value = !1, wt();
		}, Dt = (e) => {
			e.pointerId === K && (E.value = !1, D.value = !1, Y());
		}, Ot = (e, t) => {
			if (!I.value || e.button !== 0 || K !== null) return;
			e.pointerType === "touch" && (E.value = !1, D.value = !1), e.preventDefault(), e.stopPropagation(), k.value = !1, b.value.focus({ preventScroll: !0 }), k.value = !1, O.value = !0, je.value = t, Me.value = !0, K = e.pointerId, q = t ? x.value : b.value;
			let n = x.value.getBoundingClientRect();
			J = t ? F.value === "Vertical" ? e.clientY - (n.top + n.height / 2) : e.clientX - (n.left + n.width / 2) : 0, window.addEventListener("pointermove", St, {
				capture: !0,
				passive: !1
			}), window.addEventListener("pointerup", Ct, !0), window.addEventListener("pointercancel", Tt, !0), window.addEventListener("blur", Et);
			try {
				q.setPointerCapture(K);
			} catch {}
			t || bt(e), W(!0, e.pointerType === "touch" ? "touch" : "mouse");
		}, kt = (e) => Ot(e, !1), At = (e) => Ot(e, !0), X = (e) => {
			let t = He.value ? z.value : Math.max(0, y(v("SmallChange"), 1));
			t > 0 && U(!e && P.value === M.value && Math.abs(P.value / t - Math.round(P.value / t)) > 1e-10 ? Math.floor(P.value / t) * t : ut(P.value + (e ? t : -t), t));
		}, jt = (e) => {
			if (!(!I.value || e.defaultPrevented || e.altKey || e.ctrlKey || e.metaKey)) {
				if (e.key === "Home") U(j.value);
				else if (e.key === "End") U(M.value);
				else if (e.key === "ArrowRight") X(!R.value);
				else if (e.key === "ArrowLeft") X(R.value);
				else if (e.key === "ArrowUp") X(!L.value);
				else if (e.key === "ArrowDown") X(L.value);
				else return;
				e.preventDefault(), k.value = !0, C.value = null, W(!0, "keyboard");
			}
		}, Mt = () => {
			b.value && (A.value = F.value === "Vertical" ? b.value.clientHeight : b.value.clientWidth, Ne.value = getComputedStyle(b.value).direction === "rtl", ke.value && S.value?.updatePosition?.());
		}, Z, Q = null, $ = 0, Nt = c(() => I.value ? je.value ? "Pressed" : D.value ? "PointerOver" : "Normal" : "Disabled"), Pt = async (e = !0) => {
			let t = ++$;
			await be();
			let n = x.value?.querySelector(".SliderInnerThumb");
			if (!n) return;
			let r = getComputedStyle(n).transform;
			Q?.cancel();
			let i = `scale(${Nt.value === "Pressed" ? .71 : Nt.value === "Normal" ? .86 : 1.167})`;
			if (!e) {
				n.style.transform = i;
				return;
			}
			let ee = getComputedStyle(Oe.value), te = ["Normal", "Disabled"].includes(Nt.value) ? "ControlFastAnimationDuration" : "ControlNormalAnimationDuration", ne = ee.getPropertyValue(`--${te}`).trim(), a = matchMedia("(prefers-reduced-motion: reduce)").matches ? 1 : parseFloat(ne) * (ne.endsWith("ms") ? 1 : 1e3) || (te === "ControlFastAnimationDuration" ? 167 : 250), re = ee.getPropertyValue("--ControlFastOutSlowInKeySpline").trim() || "cubic-bezier(0, 0, 0, 1)", o = n.animate([{ transform: r }, { transform: i }], {
				duration: a,
				easing: re,
				fill: "forwards"
			});
			Q = o;
			try {
				await o.finished;
			} catch {
				return;
			}
			t === $ && (n.style.transform = i, o.cancel(), Q = null);
		};
		Se(() => {
			Mt(), Pt(!1), Z = new ResizeObserver(Mt), Z.observe(b.value);
		}), xe(() => {
			Y(), Z?.disconnect(), $++, Q?.cancel();
		}), _(Nt, () => Pt()), _(Pe, (e) => {
			w.value = e;
		}, { immediate: !0 }), _(() => m(l.SnapsTo), () => {
			T.value = null;
		}), _([j, M], () => {
			P.value !== w.value && U(P.value);
		}), _([
			F,
			L,
			() => m(l.FlowDirection)
		], () => {
			Y(), be(Mt);
		}), _(I, (e) => {
			e || (Y(), E.value = !1, D.value = !1, k.value = !1);
		}), _(Ie, (e) => {
			e || G();
		}), _([Fe, ft], () => {
			ke.value && be(() => S.value?.updatePosition?.());
		});
		let Ft = c({
			get: () => P.value,
			set: U
		}), It = {};
		for (let e of [
			"Minimum",
			"Maximum",
			"SmallChange",
			"LargeChange",
			"StepFrequency",
			"TickFrequency",
			"IsEnabled",
			"IsThumbToolTipEnabled",
			"Orientation",
			"IsDirectionReversed",
			"TickPlacement",
			"Header",
			"Width",
			"Height"
		]) It[e] = c({
			get: () => v(e),
			set: (t) => {
				g[e] = m(t), a(l[e], g[e], f), u(`update:${e}`, g[e]);
			}
		}), _(() => m(l[e]), () => {
			delete g[e];
		});
		let Lt = c({
			get: () => Ve.value,
			set: (e) => {
				T.value = e === "Ticks" ? "Ticks" : "StepValues", a(l.SnapsTo, T.value, f), u("update:SnapsTo", T.value);
			}
		}), Rt = (e) => I.value ? (b.value?.focus({ preventScroll: !0 }), k.value = e === "Keyboard", k.value && W(!0, "keyboard"), !0) : !1;
		fe({
			...It,
			Value: Ft,
			SnapsTo: Lt,
			IntermediateValue: Fe,
			IsDragging: Me,
			Element: Oe,
			Focus: Rt
		});
		let zt = {
			props: l,
			emit: u,
			attrs: d,
			slots: ye,
			instance: f,
			inheritedTheme: p,
			value: m,
			localProperties: g,
			property: v,
			number: y,
			rootRef: Oe,
			trackRef: b,
			thumbRef: x,
			thumbToolTipRef: S,
			intermediateValue: C,
			localValue: w,
			toolTipOpen: ke,
			toolTipInputMode: Ae,
			localSnapsTo: T,
			isPointerOver: E,
			isThumbPointerOver: D,
			isThumbPressed: je,
			isPressed: O,
			isKeyboardFocused: k,
			isDragging: Me,
			measuredLength: A,
			isRtl: Ne,
			minimum: j,
			maximum: M,
			clamp: N,
			externalValue: Pe,
			currentValue: P,
			visualValue: Fe,
			orientation: F,
			isEnabled: I,
			isToolTipEnabled: Ie,
			isTabStop: Le,
			tabIndex: Re,
			reversed: L,
			horizontalReversed: R,
			physicalReversed: ze,
			stepFrequency: Be,
			tickFrequency: z,
			tickPlacement: B,
			snapsTo: Ve,
			snapsToTicks: He,
			header: V,
			automationName: Ue,
			headerNodes: We,
			hasHeaderElement: Ge,
			headerIsComponent: Ke,
			hasHeaderVisual: qe,
			HeaderOutlet: Je,
			theme: Ye,
			themeClass: Xe,
			forwardedAttrs: Ze,
			rootStyle: Qe,
			state: $e,
			resource: H,
			sliderStyle: et,
			thumbLength: 18,
			minTickGap: 20,
			ratio: tt,
			physicalRatio: nt,
			decreaseSize: rt,
			thumbLeadingExtent: it,
			fillStyle: at,
			showTopLeftTicks: ot,
			showBottomRightTicks: st,
			ticks: ct,
			tickStyle: lt,
			closestStep: ut,
			snap: dt,
			publishValue: U,
			toolTipContent: ft,
			SliderTemplate: pt,
			showToolTip: W,
			hideToolTip: G,
			onPointerEnter: mt,
			onPointerLeave: ht,
			onThumbPointerEnter: gt,
			onThumbPointerLeave: _t,
			onFocus: vt,
			onBlur: yt,
			get pointerId() {
				return K;
			},
			set pointerId(e) {
				K = e;
			},
			get captureElement() {
				return q;
			},
			set captureElement(e) {
				q = e;
			},
			get grabOffset() {
				return J;
			},
			set grabOffset(e) {
				J = e;
			},
			updateFromPointer: bt,
			removePointerListeners: xt,
			finishPointer: Y,
			onWindowPointerMove: St,
			onWindowPointerUp: Ct,
			cancelPointer: wt,
			onWindowPointerCancel: Tt,
			onWindowBlur: Et,
			onPointerCaptureLost: Dt,
			beginPointer: Ot,
			onPointerDown: kt,
			onThumbPointerDown: At,
			step: X,
			onKeyDown: jt,
			measure: Mt,
			get resizeObserver() {
				return Z;
			},
			set resizeObserver(e) {
				Z = e;
			},
			get thumbAnimation() {
				return Q;
			},
			set thumbAnimation(e) {
				Q = e;
			},
			get thumbAnimationSequence() {
				return $;
			},
			set thumbAnimationSequence(e) {
				$ = e;
			},
			thumbState: Nt,
			updateThumbState: Pt,
			Value: Ft,
			publicProperties: It,
			SnapsTo: Lt,
			Focus: Rt,
			get SliderHeaderProperty() {
				return le;
			},
			computed: c,
			defineComponent: me,
			Fragment: s,
			getCurrentInstance: he,
			h: ge,
			inject: _e,
			isVNode: ve,
			nextTick: be,
			onBeforeUnmount: xe,
			onMounted: Se,
			provide: Ce,
			reactive: we,
			ref: h,
			unref: Te,
			useAttrs: Ee,
			useSlots: De,
			watch: _,
			Grid: ie,
			RowDefinition: ce,
			ColumnDefinition: se,
			Border: oe,
			Ellipse: de,
			TextBlock: ae,
			ToolTip: ue,
			get alignment() {
				return e;
			},
			get boolValue() {
				return t;
			},
			get cssLength() {
				return n;
			},
			get xamlThickness() {
				return r;
			},
			get normalizeXamlNodes() {
				return i;
			},
			get resolveXamlHandler() {
				return ee;
			},
			get resolveXamlResourceObject() {
				return te;
			},
			get resolveXamlValue() {
				return ne;
			},
			get updateXamlBinding() {
				return a;
			},
			get xamlScopeKey() {
				return re;
			}
		};
		return Object.defineProperty(zt, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), zt;
	}
}), b = {
	key: 0,
	class: "win-slider-header HeaderContentPresenter",
	"Grid.Row": "0"
}, x = [
	"tabindex",
	"aria-label",
	"aria-valuemin",
	"aria-valuemax",
	"aria-valuenow",
	"aria-orientation",
	"aria-disabled"
];
function S(e, t, n, r, i, ee) {
	return m(), l("div", ye({ ref: "rootRef" }, r.forwardedAttrs, {
		class: ["win-slider-root", [
			r.attrs.class,
			r.themeClass,
			{ "is-disabled": !r.isEnabled }
		]],
		style: r.rootStyle
	}), [d(r.Grid, {
		class: "win-slider-layout",
		Padding: "{x:Bind SliderTemplate.Padding, Mode=OneWay}"
	}, {
		default: v(() => [
			d(r.Grid.RowDefinitions, null, {
				default: v(() => [d(r.RowDefinition, { Height: "Auto" }), d(r.RowDefinition, { Height: "*" })]),
				_: 1
			}),
			r.hasHeaderVisual ? (m(), l("div", b, [d(r.HeaderOutlet)])) : r.header === "" ? pe("", !0) : (m(), fe(r.TextBlock, {
				key: 1,
				class: "win-slider-header HeaderContentPresenter",
				"Grid.Row": "0",
				Text: "{x:Bind SliderTemplate.Header, Mode=OneWay}",
				TextWrapping: "Wrap"
			})),
			d(r.Border, {
				class: "win-slider-focus-border FocusBorder",
				"Grid.Row": "1",
				CornerRadius: "{ThemeResource ControlCornerRadius}",
				IsHitTestVisible: "False"
			}),
			u("div", {
				ref: "trackRef",
				class: f(["win-slider SliderContainer", {
					vertical: r.orientation === "Vertical",
					"is-pointer-over": r.isPointerOver,
					"is-pressed": r.isPressed,
					"is-keyboard-focused": r.isKeyboardFocused
				}]),
				"Grid.Row": "1",
				style: p(r.sliderStyle),
				role: "slider",
				tabindex: r.isEnabled && r.isTabStop ? r.tabIndex : -1,
				"aria-label": r.automationName || r.header || void 0,
				"aria-valuemin": r.minimum,
				"aria-valuemax": r.maximum,
				"aria-valuenow": r.currentValue,
				"aria-orientation": r.orientation.toLowerCase(),
				"aria-disabled": !r.isEnabled,
				onKeydown: r.onKeyDown,
				onFocus: r.onFocus,
				onBlur: r.onBlur,
				onPointerdown: r.onPointerDown,
				onPointerenter: r.onPointerEnter,
				onPointerleave: r.onPointerLeave,
				onLostpointercapture: r.onPointerCaptureLost
			}, [d(r.Grid, { class: f(["win-slider-template", r.orientation === "Vertical" ? "VerticalTemplate" : "HorizontalTemplate"]) }, {
				default: v(() => [
					d(r.Grid.RowDefinitions, null, {
						default: v(() => [
							d(r.RowDefinition, { Height: "{x:Bind SliderTemplate.FirstRow, Mode=OneWay}" }),
							d(r.RowDefinition, { Height: "{x:Bind SliderTemplate.MiddleRow, Mode=OneWay}" }),
							d(r.RowDefinition, { Height: "{x:Bind SliderTemplate.LastRow, Mode=OneWay}" })
						]),
						_: 1
					}),
					d(r.Grid.ColumnDefinitions, null, {
						default: v(() => [
							d(r.ColumnDefinition, { Width: "{x:Bind SliderTemplate.FirstColumn, Mode=OneWay}" }),
							d(r.ColumnDefinition, { Width: "{x:Bind SliderTemplate.MiddleColumn, Mode=OneWay}" }),
							d(r.ColumnDefinition, { Width: "{x:Bind SliderTemplate.LastColumn, Mode=OneWay}" })
						]),
						_: 1
					}),
					u("div", {
						"Grid.Row": "{x:Bind SliderTemplate.TrackRow, Mode=OneWay}",
						"Grid.Column": "{x:Bind SliderTemplate.TrackColumn, Mode=OneWay}",
						"Grid.RowSpan": "{x:Bind SliderTemplate.TrackRowSpan, Mode=OneWay}",
						"Grid.ColumnSpan": "{x:Bind SliderTemplate.TrackColumnSpan, Mode=OneWay}",
						class: f(["win-slider-track", r.orientation === "Vertical" ? "VerticalTrackRect" : "HorizontalTrackRect"])
					}, null, 2),
					u("div", {
						"Grid.Row": "{x:Bind SliderTemplate.DecreaseRow, Mode=OneWay}",
						"Grid.Column": "{x:Bind SliderTemplate.DecreaseColumn, Mode=OneWay}",
						"Grid.RowSpan": "{x:Bind SliderTemplate.DecreaseRowSpan, Mode=OneWay}",
						"Grid.ColumnSpan": "{x:Bind SliderTemplate.DecreaseColumnSpan, Mode=OneWay}",
						class: f(["win-slider-fill", r.orientation === "Vertical" ? "VerticalDecreaseRect" : "HorizontalDecreaseRect"]),
						style: p(r.fillStyle)
					}, null, 6),
					r.showTopLeftTicks ? (m(), l("div", {
						key: 0,
						"Grid.Row": "0",
						"Grid.Column": "0",
						"Grid.ColumnSpan": "{x:Bind SliderTemplate.TickColumnSpan, Mode=OneWay}",
						"Grid.RowSpan": "{x:Bind SliderTemplate.TickRowSpan, Mode=OneWay}",
						class: f(["win-slider-ticks top-left", r.orientation === "Vertical" ? "LeftTickBar" : "TopTickBar"])
					}, [(m(!0), l(s, null, g(r.ticks, (e) => (m(), l("span", {
						key: e,
						class: "win-slider-tick",
						style: p(r.tickStyle(e))
					}, null, 4))), 128))], 2)) : pe("", !0),
					r.showBottomRightTicks ? (m(), l("div", {
						key: 1,
						"Grid.Row": "{x:Bind SliderTemplate.LastTickRow, Mode=OneWay}",
						"Grid.Column": "{x:Bind SliderTemplate.LastTickColumn, Mode=OneWay}",
						"Grid.ColumnSpan": "{x:Bind SliderTemplate.TickColumnSpan, Mode=OneWay}",
						"Grid.RowSpan": "{x:Bind SliderTemplate.TickRowSpan, Mode=OneWay}",
						class: f(["win-slider-ticks bottom-right", [r.orientation === "Vertical" ? "RightTickBar" : "BottomTickBar", { inline: r.tickPlacement === "Inline" }]])
					}, [(m(!0), l(s, null, g(r.ticks, (e) => (m(), l("span", {
						key: e,
						class: "win-slider-tick",
						style: p(r.tickStyle(e))
					}, null, 4))), 128))], 2)) : pe("", !0),
					u("div", {
						ref: "thumbRef",
						"Grid.Row": "{x:Bind SliderTemplate.ThumbRow, Mode=OneWay}",
						"Grid.Column": "{x:Bind SliderTemplate.ThumbColumn, Mode=OneWay}",
						"Grid.RowSpan": "{x:Bind SliderTemplate.ThumbRowSpan, Mode=OneWay}",
						"Grid.ColumnSpan": "{x:Bind SliderTemplate.ThumbColumnSpan, Mode=OneWay}",
						class: f(["win-slider-thumb", [r.orientation === "Vertical" ? "VerticalThumb" : "HorizontalThumb", {
							"is-pointer-over": r.isThumbPointerOver,
							"is-pressed": r.isThumbPressed
						}]]),
						onPointerdown: y(r.onThumbPointerDown, ["stop"]),
						onPointerenter: r.onThumbPointerEnter,
						onPointerleave: r.onThumbPointerLeave,
						onLostpointercapture: r.onPointerCaptureLost
					}, [d(r.Border, {
						class: "win-slider-outer-thumb",
						Margin: "-2",
						BorderThickness: "1",
						Background: "{ThemeResource SliderOuterThumbBackground}",
						BorderBrush: "{ThemeResource SliderThumbBorderBrush}",
						CornerRadius: "{ThemeResource SliderThumbCornerRadius}"
					}, {
						default: v(() => [d(r.Ellipse, {
							class: "win-slider-inner-thumb SliderInnerThumb",
							Width: "{ThemeResource SliderInnerThumbWidth}",
							Height: "{ThemeResource SliderInnerThumbHeight}",
							Fill: "{x:Bind SliderTemplate.ThumbBackground, Mode=OneWay}"
						})]),
						_: 1
					})], 34)
				]),
				_: 1
			}, 8, ["class"])], 46, x)
		]),
		_: 1
	}), d(r.ToolTip, {
		ref: "thumbToolTipRef",
		IsOpen: "{x:Bind SliderTemplate.ToolTipOpen, Mode=TwoWay}",
		IsEnabled: "{x:Bind SliderTemplate.ToolTipEnabled, Mode=OneWay}",
		Placement: "{x:Bind SliderTemplate.ToolTipPlacement, Mode=OneWay}",
		PlacementTarget: "{x:Bind SliderTemplate.ToolTipTarget, Mode=OneWay}",
		HorizontalOffset: "{x:Bind SliderTemplate.ToolTipOffset, Mode=OneWay}",
		VerticalOffset: "{x:Bind SliderTemplate.ToolTipOffset, Mode=OneWay}",
		Padding: "8,3,8,5",
		FontSize: "15"
	}, {
		default: v(() => [d(r.ToolTip.Content, null, {
			default: v(() => [d(r.TextBlock, {
				Text: "{x:Bind SliderTemplate.ToolTipContent, Mode=OneWay}",
				FontSize: "15",
				FontWeight: "Normal"
			})]),
			_: 1
		})]),
		_: 1
	}, 512)], 16);
}
var C = /*#__PURE__*/ o(Oe, [["render", S], ["__file", "Slider.vue"]]);
//#endregion
export { C as default };

//# sourceMappingURL=Slider.vue.js.map