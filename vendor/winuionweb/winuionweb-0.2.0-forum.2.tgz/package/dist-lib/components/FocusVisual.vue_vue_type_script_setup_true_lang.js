import { computed as e, defineComponent as t } from "vue";
//#region src/components/FocusVisual.vue?vue&type=script&setup=true&lang.ts
var n = /*@__PURE__*/ t({
	__name: "FocusVisual",
	props: {
		Margin: { default: -3 },
		CornerRadius: { default: 4 },
		TargetBorderThickness: { default: 1 },
		PrimaryThickness: { default: 2 },
		SecondaryThickness: { default: 1 }
	},
	setup(t, { expose: n }) {
		n();
		let r = t, i = (e, t) => {
			let n = String(e ?? "").split(/[ ,]+/).filter(Boolean).map((e) => Number.parseFloat(e));
			return !n.length || n.some((e) => !Number.isFinite(e)) ? [t] : n;
		}, a = (e, t) => e.length === 1 ? [
			e[0],
			e[0],
			e[0],
			e[0]
		] : e.length === 2 ? t === "radius" ? [
			e[0],
			e[1],
			e[0],
			e[1]
		] : [
			e[1],
			e[0],
			e[1],
			e[0]
		] : t === "radius" ? e.length >= 4 ? [
			e[0],
			e[1],
			e[2],
			e[3]
		] : [
			e[0],
			e[0],
			e[0],
			e[0]
		] : e.length >= 4 ? [
			e[1],
			e[2],
			e[3],
			e[0]
		] : [
			e[0],
			e[0],
			e[0],
			e[0]
		], o = (e) => `${Number(e.toFixed(3))}px`, s = {
			props: r,
			numbers: i,
			expandQuad: a,
			px: o,
			focusStyle: e(() => {
				let [e, t, n, s] = a(i(r.Margin, -3), "thickness"), [c, l, u, d] = a(i(r.CornerRadius, 4), "radius"), [f, p, m, h] = a(i(r.TargetBorderThickness, 1), "thickness"), [g, _, v, y] = a(i(r.PrimaryThickness, 2), "thickness"), [b, x, S, C] = a(i(r.SecondaryThickness, 1), "thickness"), w = (e, t, n) => Math.max(0, e - (t + n) / 2), T = [
					w(c, e, s),
					w(l, e, t),
					w(u, n, t),
					w(d, n, s)
				].map(o).join(" "), E = [
					c,
					l,
					u,
					d
				].map(o).join(" ");
				return {
					inset: `${o(e - f)} ${o(t - p)} ${o(n - m)} ${o(s - h)}`,
					borderWidth: `${o(g)} ${o(_)} ${o(v)} ${o(y)}`,
					borderRadius: T,
					"--focus-visual-inner-inset": `${o(-e - g)} ${o(-t - _)} ${o(-n - v)} ${o(-s - y)}`,
					"--focus-visual-inner-border-width": `${o(b)} ${o(x)} ${o(S)} ${o(C)}`,
					"--focus-visual-inner-radius": E
				};
			})
		};
		return Object.defineProperty(s, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), s;
	}
});
//#endregion
export { n as default };

//# sourceMappingURL=FocusVisual.vue_vue_type_script_setup_true_lang.js.map