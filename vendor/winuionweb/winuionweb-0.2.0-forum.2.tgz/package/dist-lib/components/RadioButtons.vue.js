import { resolveXamlHandler as e, resolveXamlValue as t, updateXamlBinding as n } from "./xamlRuntime.js";
import r from "../_virtual/_plugin-vue_export-helper.js";
import { useI18n as i } from "./i18n/index.js";
import a from "./TextBlock.vue.js";
import o from "./RadioButton.vue.js";
import { Fragment as s, computed as c, createBlock as l, createCommentVNode as u, createElementBlock as d, createElementVNode as f, getCurrentInstance as p, nextTick as m, normalizeClass as h, normalizeStyle as g, onMounted as _, openBlock as v, provide as y, ref as b, renderList as x, renderSlot as S, useAttrs as C, useSlots as w, watch as T } from "vue";
//#region src/components/RadioButtons.vue
var E = {
	__name: "RadioButtons",
	props: {
		Header: {
			type: [String, Number],
			default: ""
		},
		ItemsSource: {
			type: [Array, String],
			default: () => []
		},
		SelectedIndex: {
			type: [Number, String],
			default: void 0
		},
		SelectedItem: {
			type: null,
			default: void 0
		},
		MaxColumns: {
			type: [Number, String],
			default: 1
		},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		Margin: {
			type: String,
			default: ""
		},
		DisplayMemberPath: {
			type: [String, Number],
			default: ""
		}
	},
	emits: [
		"update:SelectedIndex",
		"update:SelectedItem",
		"SelectionChanged"
	],
	setup(r, { expose: l, emit: u }) {
		let d = Symbol.for("WinUIonWeb.RadioButtons"), f = r, h = u, g = p(), v = C(), x = w(), S = `win-radio-buttons-${g.uid}`, E = /* @__PURE__ */ new Map(), D = b(0), O = c(() => {
			let e = (t) => (Array.isArray(t) ? t : [t]).flatMap((t) => t ? t.type === s ? e(t.children) : (typeof t.type == "string" ? t.type : t.type?.name ?? t.type?.__name) === "RadioButton" ? [{ ...t.props }] : [] : []);
			return e(x.default?.() ?? []);
		}), { t: k } = i(), A = c(() => t(f.Header, g)), j = c(() => t(f.IsEnabled, g) !== !1), M = c(() => {
			let e = [], t = (e) => {
				if (e == null) return "";
				if (Array.isArray(e)) return e.map(t).join("");
				if (typeof e == "string" || typeof e == "number") return String(e);
				if (typeof e != "object") return "";
				let n = e.children;
				if (typeof n == "string" || typeof n == "number") return String(n);
				if (n && typeof n == "object" && typeof n.default == "function") try {
					return t(n.default());
				} catch {
					return "";
				}
				return t(n);
			}, n = (r) => {
				if (r) {
					if (Array.isArray(r)) {
						r.forEach(n);
						return;
					}
					if (typeof r == "object") {
						let i = r.type, a = typeof i == "string" ? i : i?.name || i?.__name || "";
						if (i === s) {
							n(r.children);
							return;
						}
						if (i?.__xamlString || a === "x:String") {
							let n = r.props?.["x:Uid"], i = n ? k(String(n)) : t(r).trim();
							i && e.push(i);
						}
					}
				}
			};
			return n(x.default?.()), e;
		}), N = c(() => {
			let e = t(f.ItemsSource, g);
			return Array.isArray(e) && e.length ? e : M.value;
		}), P = c(() => {
			let e = t(f.SelectedIndex, g);
			return e === void 0 || e === "" ? void 0 : Number(e);
		}), F = b(P.value ?? -1), I = 0, L = !1, R = (e) => e === "" || e == null ? "" : typeof e == "string" && e.trim() !== "" && !Number.isNaN(Number(e.trim())) ? `${Number(e.trim())}px` : typeof e == "number" ? `${e}px` : e, z = (e) => {
			if (!e) return "";
			let t = String(e).split(",").map((e) => R(Number.isNaN(Number(e.trim())) ? e.trim() : Number(e.trim())));
			return t.length === 1 ? t[0] : t.length === 2 ? `${t[1]} ${t[0]}` : t.length === 4 ? `${t[1]} ${t[2]} ${t[3]} ${t[0]}` : e;
		}, B = (e) => {
			let t = {
				Blue: "text.blue",
				Green: "text.green",
				Red: "text.red",
				Yellow: "text.yellow",
				White: "text.white",
				Black: "sample.black",
				StepValues: "sample.step-values",
				Ticks: "sample.ticks"
			}[String(e)];
			return t ? k(t) : String(e);
		}, V = (e, t) => t ? t.split(".").reduce((e, t) => e?.[t], e) : e, H = c(() => N.value.map((e) => {
			if (typeof e == "string" || typeof e == "number") return {
				Text: B(e),
				Value: e
			};
			let n = t(f.DisplayMemberPath, g), r = n ? V(e, n) : e.Text ?? e.Content ?? e.label ?? e.Name ?? e.Value;
			return {
				...e,
				Text: r == null ? "" : String(r),
				Value: e.Value ?? e
			};
		})), U = c(() => F.value), W = c(() => f.Margin ? { margin: z(t(f.Margin, g)) } : {}), G = c(() => {
			let e = Math.max(1, Number(t(f.MaxColumns, g)) || 1);
			return { gridTemplateColumns: e > 1 ? `repeat(${e}, max-content)` : "max-content" };
		}), K = (e) => {
			if (D.value, !(e < 0)) return H.value.length ? H.value[e]?.Value : E.get(e)?.getItem() ?? O.value[e];
		}, q = c(() => K(U.value)), J = {
			get SelectedIndex() {
				return U.value;
			},
			set SelectedIndex(e) {
				X(Number(e), !1);
			},
			get SelectedItem() {
				return q.value;
			},
			set SelectedItem(e) {
				Z(e);
			},
			get Header() {
				return A.value;
			},
			get IsEnabled() {
				return j.value;
			}
		}, Y = (t) => {
			let r = K(t), i = q.value, a = U.value;
			h("update:SelectedIndex", a), h("update:SelectedItem", i), n(f.SelectedIndex, a, g), n(f.SelectedItem, i, g);
			let o = {
				SelectedIndex: a,
				SelectedItem: i,
				AddedItems: i === void 0 ? [] : [i],
				RemovedItems: r === void 0 ? [] : [r]
			};
			h("SelectionChanged", J, o), e(v.SelectionChanged, g)?.(J, o);
		}, X = (e, t = !0) => {
			if (t && (!j.value || E.get(e)?.isEnabled() === !1)) return;
			let n = H.value.length || O.value.length, r = Number.isInteger(e) && e >= 0 && e < n ? e : -1;
			if (r === U.value) return;
			let i = U.value;
			F.value = r, L && Y(i);
		}, Z = (e) => {
			let t = H.value.length || O.value.length;
			X(Array.from({ length: t }, (e, t) => t).find((t) => Object.is(K(t), e)) ?? -1, !1);
		}, Q = (e, t) => {
			let n = {
				ArrowDown: 1,
				ArrowUp: -1,
				ArrowRight: 1,
				ArrowLeft: -1
			}[t.key];
			if (n === void 0 || (t.preventDefault(), !j.value)) return;
			let r = t.key === "ArrowLeft" || t.key === "ArrowRight", i = E.get(e)?.getBounds(), a = [...E.entries()].filter(([t, n]) => t !== e && n.isEnabled());
			a = r && i ? a.filter(([, e]) => {
				let t = e.getBounds();
				return t && t.top < i.bottom && t.bottom > i.top && (n > 0 ? t.left >= i.right : t.right <= i.left);
			}).sort(([, e], [, t]) => Math.abs(e.getBounds().left - i.left) - Math.abs(t.getBounds().left - i.left)) : a.filter(([t]) => n > 0 ? t > e : t < e).sort(([e], [t]) => n > 0 ? e - t : t - e);
			let o = a[0];
			o && (o[1].focus(), t.ctrlKey || X(o[0]));
		};
		T(P, (e) => {
			e !== void 0 && X(e, !1);
		}), T(() => t(f.SelectedItem, g), (e) => {
			e !== void 0 && Z(e);
		}), _(async () => {
			await m(), P.value === void 0 && f.SelectedItem !== void 0 && Z(t(f.SelectedItem, g));
			let e = H.value.length || O.value.length;
			U.value >= e && (F.value = -1), L = !0, U.value >= 0 && Y(-1);
		}), y(d, {
			name: S,
			isEnabled: j,
			selectedIndex: U,
			register: (e) => {
				let t = I++;
				return E.set(t, e), D.value++, t;
			},
			unregister: (e) => {
				E.delete(e), D.value++;
			},
			initialize: (e) => {
				U.value < 0 && P.value === void 0 && X(e, !1);
			},
			tabIndex: (e) => {
				D.value;
				let t = [...E.entries()].find(([, e]) => e.isEnabled());
				return e === (U.value >= 0 ? U.value : t?.[0]) ? 0 : -1;
			},
			navigate: Q,
			select: X
		}), l({
			SelectedIndex: c({
				get: () => U.value,
				set: (e) => X(Number(e), !1)
			}),
			SelectedItem: c({
				get: () => q.value,
				set: Z
			}),
			Header: A,
			IsEnabled: j
		});
		let $ = {
			radioButtonsGroupKey: d,
			props: f,
			emit: h,
			instance: g,
			attrs: v,
			slots: x,
			groupName: S,
			registeredItems: E,
			registrationVersion: D,
			inlineRadioItems: O,
			t: k,
			resolvedHeader: A,
			resolvedIsEnabled: j,
			inlineItems: M,
			resolvedItemsSource: N,
			resolvedSelectedIndex: P,
			internalSelectedIndex: F,
			get nextSlotIndex() {
				return I;
			},
			set nextSlotIndex(e) {
				I = e;
			},
			get isLoaded() {
				return L;
			},
			set isLoaded(e) {
				L = e;
			},
			cssLength: R,
			xamlThickness: z,
			localizedString: B,
			GetPathValue: V,
			normalizedItems: H,
			selectedIndexValue: U,
			rootStyle: W,
			itemsStyle: G,
			itemAt: K,
			selectedItemValue: q,
			eventSender: J,
			notifySelection: Y,
			select: X,
			selectItem: Z,
			navigate: Q,
			computed: c,
			Fragment: s,
			getCurrentInstance: p,
			nextTick: m,
			onMounted: _,
			provide: y,
			ref: b,
			useAttrs: C,
			useSlots: w,
			watch: T,
			RadioButton: o,
			TextBlock: a,
			get useI18n() {
				return i;
			},
			get resolveXamlHandler() {
				return e;
			},
			get resolveXamlValue() {
				return t;
			},
			get updateXamlBinding() {
				return n;
			}
		};
		return Object.defineProperty($, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), $;
	}
};
function D(e, t, n, r, i, a) {
	return v(), d("div", {
		class: h(["win-radio-buttons", { "is-disabled": !r.resolvedIsEnabled }]),
		style: g(r.rootStyle)
	}, [r.resolvedHeader ? (v(), l(r.TextBlock, {
		key: 0,
		class: "win-radio-buttons-header",
		Text: r.resolvedHeader
	}, null, 8, ["Text"])) : u("", !0), f("div", {
		class: "win-radio-buttons-items",
		style: g(r.itemsStyle)
	}, [(v(!0), d(s, null, x(r.normalizedItems, (e, t) => (v(), l(r.RadioButton, {
		key: t,
		Content: e.Text,
		IsChecked: r.selectedIndexValue === t,
		IsEnabled: r.resolvedIsEnabled
	}, null, 8, [
		"Content",
		"IsChecked",
		"IsEnabled"
	]))), 128)), r.normalizedItems.length === 0 ? S(e.$slots, "default", { key: 0 }) : u("", !0)], 4)], 6);
}
var O = /*#__PURE__*/ r(E, [["render", D], ["__file", "RadioButtons.vue"]]);
//#endregion
export { O as default };

//# sourceMappingURL=RadioButtons.vue.js.map