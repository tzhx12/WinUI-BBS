import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./VariableSizedWrapGrid.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                                          */
import { createElementBlock as n, createVNode as r, normalizeStyle as i, openBlock as a } from "vue";
//#region src/components/VariableSizedWrapGrid.vue
var o = ["HorizontalAlignment", "VerticalAlignment"];
function s(e, t, s, c, l, u) {
	return a(), n("div", {
		ref: "root",
		class: "win-variable-sized-wrap-grid",
		style: i(c.rootStyle),
		HorizontalAlignment: c.resolve(c.props.HorizontalAlignment),
		VerticalAlignment: c.resolve(c.props.VerticalAlignment)
	}, [r(c.XamlChildren)], 12, o);
}
var c = /*#__PURE__*/ e(t, [
	["render", s],
	["__scopeId", "data-v-ae61215b"],
	["__file", "VariableSizedWrapGrid.vue"]
]);
//#endregion
export { c as default };

//# sourceMappingURL=VariableSizedWrapGrid.vue.js.map