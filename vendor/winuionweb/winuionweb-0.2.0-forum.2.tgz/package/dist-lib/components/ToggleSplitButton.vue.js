import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./ToggleSplitButton.vue_vue_type_script_setup_true_lang.js";
import { createBlock as n, createCommentVNode as r, mergeProps as i, openBlock as a, renderSlot as o, withCtx as s } from "vue";
//#region src/components/ToggleSplitButton.vue
function c(e, t, c, l, u, d) {
	return a(), n(l.SplitButton, i({ ref: "split" }, l.splitAttrs, {
		class: "win-toggle-split-button",
		"aria-pressed": l.IsChecked,
		IsEnabled: "{x:Bind IsEnabled}",
		Content: "{x:Bind Content}",
		ContentTemplate: "{x:Bind ContentTemplate}",
		ContentTransitions: "{x:Bind ContentTransitions}",
		Flyout: "{x:Bind Flyout}",
		RequestedTheme: "{x:Bind RequestedTheme}",
		Click: "OnSplitClick"
	}), {
		default: s(() => [l.hasContent ? o(e.$slots, "default", { key: 0 }) : r("", !0)]),
		_: 3
	}, 16, ["aria-pressed"]);
}
var l = /*#__PURE__*/ e(t, [["render", c], ["__file", "ToggleSplitButton.vue"]]);
//#endregion
export { l as default };

//# sourceMappingURL=ToggleSplitButton.vue.js.map