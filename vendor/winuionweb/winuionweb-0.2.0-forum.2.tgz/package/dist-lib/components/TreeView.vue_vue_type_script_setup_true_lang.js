import { useAcrylicBrushStyle as e } from "./AcrylicBrush.js";
import { materializeXamlVNode as t, resolveXamlHandler as n, resolveXamlValue as r, xamlItemContextKey as i, xamlScopeKey as a } from "./xamlRuntime.js";
import { vAcrylicBrush as o } from "./acrylicBrushVisual.js";
import { xamlResourceDictionaryKey as s } from "./Page.vue_vue_type_script_lang.js";
import { CollectionItemContainerStyle as c, CollectionItemContainerStyleSelector as l, CollectionItemContainerTransitions as u, CollectionItemTemplate as d, CollectionItemTemplateSelector as f, getCollectionProperty as ee, getVNodeChildren as p } from "./CollectionProperties.js";
import te from "./ScrollViewer.vue.js";
import { scrollViewerTemplateBindings as ne } from "./scrollViewerTemplateBindings.js";
import re from "./CheckBox.vue.js";
import { attachSecondaryTouchScrollDuringDrag as ie, scrollByTouchDelta as ae, scrollableAncestors as oe } from "./pointerDragTouchScroll.js";
import { Fragment as m, computed as h, defineComponent as se, getCurrentInstance as ce, h as g, inject as le, markRaw as ue, nextTick as de, onBeforeUnmount as fe, onMounted as pe, provide as me, ref as _, shallowRef as he, useAttrs as ge, useSlots as _e, watch as ve } from "vue";
//#region src/components/TreeView.vue?vue&type=script&setup=true&lang.ts
var ye = se({
	name: "TreeViewItem",
	__treeViewItem: !0,
	setup(e, { slots: t }) {
		return () => g(m, t.default?.());
	}
}), be = se({
	name: "TreeView.RootNodes",
	__treeViewProperty: "rootNodes",
	setup(e, { slots: t }) {
		return () => g(m, t.default?.());
	}
}), xe = se({
	name: "TreeViewNode",
	__treeViewNode: !0,
	setup(e, { slots: t }) {
		return () => g(m, t.default?.());
	}
}), Se = se({
	name: "TreeViewNode.Children",
	__treeViewProperty: "children",
	setup(e, { slots: t }) {
		return () => g(m, t.default?.());
	}
}), v = null, Ce = Symbol("WinUIonWeb.TreeViewNodeVectorState"), y = /*@__PURE__*/ se({
	ItemTemplate: d,
	ItemTemplateSelector: f,
	ItemContainerStyle: c,
	ItemContainerStyleSelector: l,
	ItemContainerTransitions: u,
	RootNodes: be,
	__name: "TreeView",
	props: {
		ItemsSource: { default: void 0 },
		RootNodes: { default: void 0 },
		SelectionMode: { default: "Single" },
		CanDragItems: {
			type: [Boolean, String],
			default: !0
		},
		CanReorderItems: {
			type: [Boolean, String],
			default: !0
		},
		AllowDrop: {
			type: [Boolean, String],
			default: !0
		},
		SelectedItem: { default: void 0 },
		SelectedItems: { default: void 0 },
		ItemTemplate: { default: () => "" },
		ItemTemplateSelector: { default: () => "" },
		ItemContainerStyle: { default: void 0 },
		ItemContainerStyleSelector: { default: void 0 },
		ItemContainerTransitions: { default: void 0 },
		FlowDirection: { default: "LeftToRight" },
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		HorizontalAlignment: { default: "Stretch" },
		VerticalAlignment: { default: "Stretch" },
		HorizontalContentAlignment: { default: "Stretch" },
		VerticalContentAlignment: { default: "Center" },
		Width: { default: "" },
		Height: { default: "" },
		MinWidth: { default: "" },
		MinHeight: { default: "" },
		MaxWidth: { default: "" },
		MaxHeight: { default: "" },
		Margin: { default: "" },
		Padding: { default: "" },
		Background: { default: "" },
		BorderBrush: { default: "" },
		BorderThickness: { default: "" },
		CornerRadius: { default: "" }
	},
	emits: [
		"ItemInvoked",
		"SelectionChanged",
		"Expanding",
		"Collapsed",
		"DragItemsStarting",
		"DragItemsCompleted",
		"DragOver",
		"Drop",
		"update:ItemsSource",
		"update:RootNodes",
		"update:SelectedItem",
		"update:SelectedItems"
	],
	setup(c, { expose: l, emit: u }) {
		let d = se({
			name: "TreeViewItemScope",
			props: { Node: {
				type: Object,
				required: !0
			} },
			setup(e, { slots: t }) {
				return me(a, { IsChecked: h(() => e.Node.SelectionState === "Selected" ? !0 : e.Node.SelectionState === "PartialSelected" ? null : !1) }), () => g(m, t.default?.());
			}
		}), f = c, y = u, we = _e(), Te = ge(), b = ce(), Ee = le(a, {}), De = ne((e) => Te[e], b);
		me(a, {
			...Ee,
			ScrollSettings: De,
			get ScrollTemplateIsEnabled() {
				return C.value;
			}
		});
		let Oe = le(s, null), x = _(), ke = _(), S = (e) => {
			let t = r(e, b);
			if (t === "" || t == null) return "";
			let n = String(t).trim();
			return /^-?\d+(?:\.\d+)?$/.test(n) ? `${Number(n)}px` : n;
		}, Ae = (e) => {
			let t = r(e, b);
			if (t === "" || t == null) return "";
			let n = String(t).split(",").map((e) => S(e.trim())).filter(Boolean);
			return n.length === 1 ? n[0] : n.length === 2 ? `${n[1]} ${n[0]}` : n.length === 4 ? `${n[1]} ${n[2]} ${n[3]} ${n[0]}` : "";
		}, C = h(() => r(f.IsEnabled, b) !== !1), w = h(() => {
			let e = String(r(f.SelectionMode, b) ?? "Single");
			return e === "None" || e === "Multiple" ? e : "Single";
		}), je = _("UnSelected"), Me = h(() => r(f.CanDragItems, b) === !0 && C.value), Ne = h(() => r(f.CanReorderItems, b) === !0), Pe = h(() => r(f.AllowDrop, b) === !0), Fe = h(() => r(f.FlowDirection, b) === "RightToLeft" ? "rtl" : "ltr"), Ie = (e, t) => {
			let n = String(r(e, b) ?? "");
			return t === "horizontal" ? {
				Left: "start",
				Center: "center",
				Right: "end",
				Stretch: "stretch"
			}[n] : {
				Top: "start",
				Center: "center",
				Bottom: "end",
				Stretch: "stretch"
			}[n];
		}, Le = e(() => f.Background || void 0, b), Re = h(() => ({
			width: S(f.Width) || void 0,
			height: S(f.Height) || void 0,
			minWidth: S(f.MinWidth) || void 0,
			minHeight: S(f.MinHeight) || void 0,
			maxWidth: S(f.MaxWidth) || void 0,
			maxHeight: S(f.MaxHeight) || void 0,
			margin: Ae(f.Margin) || void 0,
			...Le.value,
			borderColor: r(f.BorderBrush, b) || void 0,
			borderWidth: Ae(f.BorderThickness) || void 0,
			borderStyle: Ae(f.BorderThickness) ? "solid" : void 0,
			borderRadius: S(f.CornerRadius) || void 0,
			justifySelf: Ie(f.HorizontalAlignment, "horizontal") || void 0,
			alignSelf: Ie(f.VerticalAlignment, "vertical") || void 0,
			direction: Fe.value
		})), ze = h(() => ({ padding: Ae(f.Padding) || void 0 })), Be = he(we.default?.() ?? []), Ve = (e) => {
			if (typeof e != "string") return "";
			let t = e.trim().match(/^\{\s*StaticResource\s+([^\s}]+)\s*\}$/i);
			return t ? t[1] : e.trim().match(/^var\(--([^,)]+)\)$/)?.[1] ?? "";
		}, He = (e) => {
			let t = Ve(e);
			if (t) return t;
			let n = r(e, b);
			return typeof n == "string" ? Ve(n) || n.trim() : "";
		}, Ue = (e) => {
			let t = e?.type;
			return typeof t == "string" ? t : t?.name || t?.__name || "";
		}, We = (e) => {
			let t = e?.props, n = t?.["x:Key"] ?? t?.["x:key"] ?? t?.Key ?? t?.key;
			return typeof n == "string" ? n : "";
		}, Ge = (e) => e.flatMap((e) => e ? e.type === m || /DataTemplateSelector$/i.test(Ue(e)) ? Ge(p(e)) : [e] : []), Ke = h(() => {
			let e = Ve(r(f.ItemTemplate, b));
			if (e && Oe?.[e]) return p(Oe[e]);
			for (let t of Be.value) {
				if (ee(t) !== "itemTemplate") continue;
				let n = Ge(p(t)).filter((e) => /DataTemplate$/i.test(Ue(e)));
				return n.length ? p((e ? n.find((t) => We(t) === e) : n[0]) ?? n[0]) : p(t);
			}
			return [];
		}), qe = h(() => {
			let e = He(f.ItemTemplateSelector), t = e ? Oe?.[e] : null;
			if (!t) return null;
			let n = t.props ?? {}, r = [];
			for (let [e, t] of Object.entries(n)) {
				if (/^(x:Key|x:key|Key|key)$/.test(e)) continue;
				let n = He(t);
				n && r.push({
					Name: e,
					Key: n
				});
			}
			return r.length ? r : null;
		}), Je = (e) => {
			let t = qe.value;
			if (!t) return null;
			let n = e;
			if (n && typeof n == "object" && "Type" in n) {
				let e = String(n.Type), r = t.find((t) => t.Name.toLowerCase().startsWith(e.toLowerCase()));
				if (r) return r;
			}
			return t[0];
		}, Ye = (e) => {
			let t = e ? Oe?.[e] : null;
			if (!t) return null;
			let n = t, r = /DataTemplate$/i.test(Ue(n)) ? p(n) : [n];
			return r.length ? r : null;
		}, Xe = (e) => {
			let t = r(f.ItemTemplateSelector, b);
			if (t && typeof t.SelectTemplateCore == "function") {
				let n = He(t.SelectTemplateCore(e, k));
				if (n) {
					let e = Ye(n);
					if (e) return e;
				}
			}
			let n = Je(e);
			if (n) {
				let e = Ye(n.Key);
				if (e) return e;
			}
			return Ke.value;
		}, Ze = (e) => {
			let t = e;
			return !!(t?.type && t.type.__treeViewItem);
		}, Qe = (e) => {
			let n = Xe(e);
			if (!n.length) return null;
			let r = t(n, e, b);
			return (Array.isArray(r) ? r : [r]).find(Ze) ?? null;
		}, $e = (e) => {
			let t = e;
			if (t && typeof t == "object") {
				if (Array.isArray(t.Children)) return t.Children;
				if (Array.isArray(t.ItemsSource)) return t.ItemsSource;
			}
			return [];
		}, et = (e) => {
			let t = e;
			return t && typeof t == "object" && "Content" in t ? r(t.Content, b) : e;
		}, tt = (e) => e, nt = (e, t) => {
			let n = t?.props ?? {};
			if (n.IsExpanded !== void 0) return r(n.IsExpanded, b) === !0;
			let i = e;
			return i && typeof i == "object" && "IsExpanded" in i ? r(i.IsExpanded, b) === !0 : !1;
		}, rt = (e, t, n) => {
			let i = t?.props ?? {};
			if (i[n] !== void 0) return r(i[n], b) === !0;
			let a = e;
			return a && typeof a == "object" && n in a ? r(a[n], b) === !0 : !1;
		}, it = (e) => (Object.prototype.hasOwnProperty.call(e, "Append") || Object.defineProperties(e, {
			Size: {
				configurable: !0,
				enumerable: !1,
				get() {
					return this.length;
				}
			},
			Count: {
				configurable: !0,
				enumerable: !1,
				get() {
					return this.length;
				}
			},
			GetAt: {
				configurable: !0,
				enumerable: !1,
				value(e) {
					return this[e];
				}
			},
			SetAt: {
				configurable: !0,
				enumerable: !1,
				value(e, t) {
					let n = this[Ce];
					n?.replaceAt ? n.replaceAt(e, t) : this.splice(e, 1, t);
				}
			},
			InsertAt: {
				configurable: !0,
				enumerable: !1,
				value(e, t) {
					this.splice(e, 0, t);
				}
			},
			RemoveAt: {
				configurable: !0,
				enumerable: !1,
				value(e) {
					this.splice(e, 1);
				}
			},
			Append: {
				configurable: !0,
				enumerable: !1,
				value(e) {
					this.push(e);
				}
			},
			Add: {
				configurable: !0,
				enumerable: !1,
				value(e) {
					this.push(e);
				}
			},
			Insert: {
				configurable: !0,
				enumerable: !1,
				value(e, t) {
					this.splice(e, 0, t);
				}
			},
			Remove: {
				configurable: !0,
				enumerable: !1,
				value(e) {
					let t = this.indexOf(e);
					return t < 0 ? !1 : (this.splice(t, 1), !0);
				}
			},
			Contains: {
				configurable: !0,
				enumerable: !1,
				value(e) {
					return this.includes(e);
				}
			},
			IndexOf: {
				configurable: !0,
				enumerable: !1,
				value(e) {
					return this.indexOf(e);
				}
			},
			RemoveAtEnd: {
				configurable: !0,
				enumerable: !1,
				value() {
					this.pop();
				}
			},
			Clear: {
				configurable: !0,
				enumerable: !1,
				value() {
					this.splice(0, this.length);
				}
			},
			ReplaceAll: {
				configurable: !0,
				enumerable: !1,
				value(e) {
					let t = this[Ce];
					t?.replaceAll ? t.replaceAll(e) : this.splice(0, this.length, ...e);
				}
			}
		}), e), at = () => {}, ot = 0, st = /* @__PURE__ */ new Set(), ct = !1, lt = (e) => {
			ot || (st.add(e), !ct && (ct = !0, queueMicrotask(() => {
				ct = !1;
				let e = [...st];
				st.clear();
				for (let t of e) at(t);
			})));
		}, ut = (e) => !!(e && typeof e == "object" && Array.isArray(e.Children) && "SelectionState" in e && "SourceItem" in e), dt = (e) => e[Ce], ft = (e, t, n) => {
			let r = dt(e);
			r && (r.owner = Ot, r.parent = t, r.isContentMode = n, r.changed = () => lt(t), r.normalize = (e, r) => {
				let i = t ? t.Depth + 1 : 0, a = t?.IsContentMode ?? xt.value.isContentMode ?? n, o = ut(e) ? e : _t(e, t, i, a);
				if (ut(e)) {
					let e = dt(o.Children)?.owner;
					for (let e = t; e; e = e.Parent) if (e === o) throw Error("A TreeViewNode cannot be inserted into its own subtree.");
					let n = o.Parent ? o.Parent.Children : T.value, i = n.indexOf(o);
					i >= 0 && n !== r ? n.splice(i, 1) : i >= 0 && Array.prototype.splice.call(r, i, 1), pt(o, a), (e !== Ot || o.IsContentMode !== a) && ti(o, a);
				}
				return o.Parent = t, ht(o, i), gt(o, t), o;
			});
		};
		function pt(e, t) {
			ft(e.Children, e, t);
			for (let n of e.Children) pt(n, t);
		}
		let mt = (e, t, n) => {
			let r = e, i = Array.prototype.push, a = Array.prototype.pop, o = Array.prototype.shift, s = Array.prototype.unshift, c = Array.prototype.splice, l = ue({
				owner: Ot,
				parent: t,
				isContentMode: n,
				normalize: (e) => e,
				changed: () => {}
			});
			l.restoreSnapshot = (e) => c.call(r, 0, r.length, ...e), Object.defineProperty(r, Ce, {
				configurable: !1,
				enumerable: !1,
				value: l
			}), ft(r, t, n);
			let u = (e) => dt(r)?.normalize(e, r), d = (e) => {
				!e || r.includes(e) || (e.Parent = null, ht(e, -1));
			}, f = () => {
				let e = dt(r)?.parent;
				e && r.length === 0 && e.IsExpanded && On(e), dt(r)?.changed();
			};
			return l.replaceAt = (e, t) => {
				let n = c.call(r, e, 1);
				for (let e of n) d(e);
				let i = u(t);
				c.call(r, e, 0, i), f();
			}, l.replaceAll = (e) => {
				let t = dt(r)?.parent, n = Array.from(e), a = c.call(r, 0, r.length);
				a.length && t?.IsExpanded && On(t);
				for (let e of a) d(e);
				let o = n.map(u);
				i.apply(r, o), f();
			}, Object.defineProperties(r, {
				push: {
					configurable: !0,
					enumerable: !1,
					value: (...e) => {
						let t = i.apply(r, e.map(u));
						return f(), t;
					}
				},
				pop: {
					configurable: !0,
					enumerable: !1,
					value: () => {
						let e = a.call(r);
						return d(e), f(), e;
					}
				},
				shift: {
					configurable: !0,
					enumerable: !1,
					value: () => {
						let e = o.call(r);
						return d(e), f(), e;
					}
				},
				unshift: {
					configurable: !0,
					enumerable: !1,
					value: (...e) => {
						let t = s.apply(r, e.map(u));
						return f(), t;
					}
				},
				splice: {
					configurable: !0,
					enumerable: !1,
					value: (e, t, ...n) => {
						let i = n.map(u), a = t === void 0 ? c.call(r, e) : c.call(r, e, t, ...i);
						for (let e of a) d(e);
						return f(), a;
					}
				}
			}), it(r), new Proxy(r, {
				set(e, t, n) {
					if (t === "length") {
						let r = Number(n) !== e.length, i = Number(n) < e.length ? e.slice(Number(n)) : [], a = Reflect.set(e, t, n);
						for (let e of i) d(e);
						return r && f(), a;
					}
					if (/^\d+$/.test(String(t))) {
						let r = Number(t);
						if (r < e.length) return l.replaceAt?.(r, n), !0;
						let i = e[Number(t)], a = Reflect.set(e, t, u(n));
						return i && i !== n && d(i), f(), a;
					}
					return Reflect.set(e, t, n);
				},
				deleteProperty(e, t) {
					if (!/^\d+$/.test(String(t))) return Reflect.deleteProperty(e, t);
					let n = Number(t);
					if (n < 0 || n >= e.length) return !0;
					let r = c.call(e, n, 1);
					for (let e of r) d(e);
					return f(), !0;
				}
			});
		};
		function ht(e, t) {
			e.Depth = t;
			for (let n of e.Children) n.Parent = e, ht(n, t + 1);
		}
		function gt(e, t) {
			let n = O([e]);
			if (w.value === "None") {
				for (let e of n) R(e, "UnSelected");
				return;
			}
			if (w.value === "Multiple") {
				R(e, t ? t.SelectionState : je.value);
				return;
			}
			let r = n.find((e) => e.SelectionState === "Selected");
			if (r) {
				for (let e of I.value) e !== r && R(e, "UnSelected");
				for (let e of n) R(e, e === r ? "Selected" : "UnSelected");
			}
		}
		let _t = (e, n, i, a) => {
			let o = a ? e : et(e), s = $e(e), c = {
				SourceItem: e,
				Item: null,
				Content: o,
				PresenterContent: o,
				Children: [],
				ChildrenSource: s,
				Parent: n,
				IsExpanded: !1,
				HasUnrealizedChildren: !1,
				get HasChildren() {
					return this.Children.length > 0 || this.HasUnrealizedChildren;
				},
				SelectionState: "UnSelected",
				Depth: i,
				IsContentMode: a,
				Key: e,
				Template: null,
				Context: tt(e),
				ContainerProps: {}
			};
			c.Item = a ? c.Content : c, c.Context = a ? tt(e) : c.Item, c.Children = mt([], c, a), !a && s.length && (c.Children = mt(s.map((e) => _t(e, c, i + 1, !1)), c, !1));
			let l = !a && s.length > 0, u = Qe(c.Context), d = u?.props ?? {}, f = r(d.ItemsSource, b), ee = Array.isArray(f) ? f : s, te = l && (f === void 0 || f === c.Children || ee === s), ne = r(d.Content, b);
			if (c.ContainerProps = d, c.PresenterContent = ne === void 0 ? o : ne, c.IsExpanded = nt(e, u), c.HasUnrealizedChildren = rt(e, u, "HasUnrealizedChildren"), u) {
				let e = p(u);
				e.length && (c.Template = t(e, c.Context, b));
			}
			return a ? c.Children = mt(ee.map((e) => _t(e, c, i + 1, !0)), c, !0) : !te && ee.length && (c.Children = mt(ee.map((e) => ut(e) ? e : _t(e, c, i + 1, !1)), c, !1)), c;
		}, vt = /* @__PURE__ */ new Map(), yt = null, bt = (e, t) => {
			let n = vt.get(t);
			if (n) return n;
			let r = { ...e.props ?? {} };
			vt.set(t, r);
			let i = [];
			for (let n of p(e)) {
				let e = n?.type?.__treeViewProperty === "children" ? p(n) : [n];
				for (let n of e) n?.type?.__treeViewNode && i.push(bt(n, `${t}.${i.length}`));
			}
			return i.length && (r.Children = i), r;
		}, xt = h(() => {
			let e = r(f.ItemsSource, b);
			if (Array.isArray(e)) return {
				items: e,
				isContentMode: !0,
				collection: e
			};
			let t = r(f.RootNodes, b);
			if (Array.isArray(t)) return {
				items: t,
				isContentMode: !1,
				collection: t
			};
			for (let e of Be.value) if (e.type?.__treeViewProperty === "rootNodes") return yt ??= p(e).filter((e) => e?.type?.__treeViewNode).map((e, t) => bt(e, String(t))), {
				items: yt,
				isContentMode: !1,
				collection: yt
			};
			return {
				items: [],
				isContentMode: !1,
				collection: null
			};
		}), St = h(() => {
			let e = r(f.ItemContainerTransitions, b), t = Be.value.find((e) => ee(e) === "itemContainerTransitions"), n = e && typeof e == "object" ? p(e) : t ? p(t) : [], i = !!t || e != null && e !== "", a = n.map((e) => Ue(e).toLowerCase()), o = (e) => a.some((t) => t.includes(e.toLowerCase()));
			return {
				content: n.length ? o("contentthemetransition") : !i,
				reorder: n.length ? o("reorderthemetransition") : !i,
				entrance: n.length ? o("entrancethemetransition") : !i
			};
		}), T = _([]), Ct = !1, E = [], wt = _(0), Tt = (e) => {
			E.splice(0, E.length, ...e), wt.value += 1;
		}, D = he(null), Et = /* @__PURE__ */ new WeakMap(), Dt = 1, O = (e) => {
			let t = [], n = (e) => {
				for (let r of e) t.push(r), n(r.Children);
			};
			return n(e), t;
		}, k = {}, Ot = Symbol("WinUIonWeb.TreeViewOwner"), A = () => {}, j = null, kt = !1, At = _(0), M = () => {
			At.value += 1;
		}, jt = () => {
			let e = E.map((e) => e.SourceItem), t = /* @__PURE__ */ new Map(), n = (e) => {
				let r = t.get(e.SourceItem) ?? [];
				r.push(e), t.set(e.SourceItem, r);
				for (let t of e.Children) n(t);
			};
			for (let e of T.value) n(e);
			let r = D.value?.SourceItem, i = (e) => {
				let n = t.get(e.SourceItem)?.shift();
				n && (e.IsExpanded = n.IsExpanded, e.SelectionState = n.SelectionState);
				for (let t of e.Children) i(t);
			}, a = mt(xt.value.items.map((e) => _t(e, null, 0, xt.value.isContentMode)), null, xt.value.isContentMode);
			if (Ct) {
				ot += 1;
				try {
					Array.prototype.splice.call(T.value, 0, T.value.length, ...a);
				} finally {
					--ot;
				}
			} else T.value = a, Ct = !0;
			for (let e of T.value) i(e);
			let o = O(T.value), s = e.map((e) => o.find((t) => t.SourceItem === e && t.SelectionState === "Selected")).filter((e) => !!e);
			for (let e of o) e.SelectionState === "Selected" && !s.includes(e) && s.push(e);
			Tt(s), D.value = O(T.value).find((e) => e.SourceItem === r) ?? T.value[0] ?? null, M(), A();
		};
		ve(xt, (e) => {
			kt || j && e.items.length === j.length && e.items.every((e, t) => e === j?.[t]) || (j = null, jt());
		}, {
			immediate: !0,
			deep: !0
		});
		let Mt = h(() => {
			At.value;
			let e = [], t = (n) => {
				for (let r of n) e.push(r), r.IsExpanded && t(r.Children);
			};
			return t(T.value), e;
		}), N = h(() => (At.value, O(T.value))), P = h(() => Mt.value.map((e, t) => ({
			index: t,
			node: e,
			depth: e.Depth,
			isExpanded: e.IsExpanded,
			hasChildren: e.HasChildren,
			selectionState: e.SelectionState,
			isSelected: e.SelectionState === "Selected",
			positionInSet: (e.Parent ? e.Parent.Children : T.value).indexOf(e) + 1,
			setSize: (e.Parent ? e.Parent.Children : T.value).length
		}))), Nt = (e) => {
			let t = Et.get(e.node);
			return t || (t = Dt, Dt += 1, Et.set(e.node, t)), `win-tree-item-${t}`;
		}, Pt = (e) => e.selectionState === "Selected" ? "true" : e.selectionState === "PartialSelected" ? "mixed" : "false", Ft = (e) => {
			D.value = e.node;
		}, It = (e) => {
			C.value && (D.value = e.node, Tn(e.node));
		}, F = (e, t, n) => {
			let i = e.ContainerProps[t];
			return r(i === void 0 ? n : i, b, {
				item: e.SourceItem,
				Item: e.SourceItem
			});
		}, Lt = (e) => {
			let t = r(f.ItemContainerStyleSelector, b);
			return t && typeof t.SelectStyleCore == "function" ? t.SelectStyleCore(e.Item, k) : r(f.ItemContainerStyle, b);
		}, Rt = (e, t) => {
			if (!t || typeof t != "object") return;
			let n = t;
			n.Background !== void 0 && (e.background = String(r(n.Background, b) ?? "")), n.BorderBrush !== void 0 && (e.borderColor = String(r(n.BorderBrush, b) ?? "")), n.BorderThickness !== void 0 && (e.borderWidth = Ae(n.BorderThickness), e.borderStyle = "solid"), n.CornerRadius !== void 0 && (e.borderRadius = S(n.CornerRadius)), n.Margin !== void 0 && (e.margin = Ae(n.Margin)), n.Padding !== void 0 && (e.padding = Ae(n.Padding)), n.MinHeight !== void 0 && (e.minHeight = S(n.MinHeight)), n.Height !== void 0 && (e.height = S(n.Height)), n.MinWidth !== void 0 && (e.minWidth = S(n.MinWidth)), n.Width !== void 0 && (e.width = S(n.Width));
		}, zt = (e) => {
			let t = {};
			return Rt(t, Lt(e.node)), Rt(t, e.node.ContainerProps), t;
		}, Bt = (e) => ({
			justifyContent: Ie(F(e.node, "HorizontalContentAlignment", f.HorizontalContentAlignment), "horizontal"),
			alignItems: Ie(F(e.node, "VerticalContentAlignment", f.VerticalContentAlignment), "vertical"),
			margin: Ae(F(e.node, "Padding")) || void 0
		}), Vt = (e) => ({
			"--tree-glyph-brush": String(F(e.node, "GlyphBrush") ?? "") || void 0,
			fontSize: S(F(e.node, "GlyphSize", 8)) || "8px",
			opacity: String(F(e.node, "GlyphOpacity", 1))
		}), Ht = (e) => String(F(e.node, "CollapsedGlyph", "") ?? ""), Ut = (e) => String(F(e.node, "ExpandedGlyph", "") ?? ""), Wt = (e) => z.value && er.value > 1 && $n.value === e.node, Gt = /* @__PURE__ */ new WeakMap(), Kt = (e) => {
			let n = e.node, r = Gt.get(n);
			if (r) return r;
			let a = se({
				name: "TreeViewItemTemplate",
				setup() {
					return me(i, n.Context), () => {
						if (n.Template?.length) return g(m, n.Template);
						let e = Xe(n.SourceItem);
						if (e.length) {
							let r = t(e, n.Context, b), i = Array.isArray(r) ? r : [r], a = i.find(Ze);
							if (a) {
								let e = p(a);
								if (e.length) return g(m, e);
							} else return g(m, i);
						}
						return g("span", String(n.PresenterContent ?? ""));
					};
				}
			});
			return Gt.set(n, a), a;
		}, qt = (e) => ({
			selected: e.isSelected,
			"multi-select": w.value === "Multiple",
			"can-drag": Me.value,
			"dragging-source": z.value && Qn.value.includes(e.node),
			"drag-shrink": (z.value || B.value) && !Qn.value.includes(e.node) && e.index !== H.value,
			"reorder-target": e.index === H.value,
			"drop-before": e.index === H.value && V.value === "before",
			"drop-after": e.index === H.value && V.value === "after",
			"drop-inside": e.index === H.value && V.value === "inside"
		}), Jt = (e) => {
			let t = nr.value.get(e.index) ?? 0;
			return t ? {
				transform: `translateY(${t}px)`,
				transition: St.value.reorder ? "transform 240ms cubic-bezier(0.1, 0.9, 0.2, 1)" : "none"
			} : {};
		}, Yt = () => {
			let e = Nn(), t = [], n = ke.value ? getComputedStyle(ke.value).transform : "none", r = 0;
			if (n && n !== "none") try {
				r = new DOMMatrixReadOnly(n).m42;
			} catch {
				r = 0;
			}
			e.forEach((e, n) => {
				let i = e.getBoundingClientRect(), a = P.value[n];
				a && t.push({
					node: a.node,
					index: n,
					top: i.top - r,
					bottom: i.bottom - r,
					midY: i.top - r + i.height / 2,
					height: i.height,
					slotSize: i.height
				});
			});
			for (let e = 0; e < t.length - 1; e += 1) {
				let n = t[e + 1].top - t[e].top;
				n > 0 && (t[e].slotSize = n);
			}
			U = t, ir = x.value?.querySelector(".win-scroll-viewer-viewport") ?? null, rr = ir?.scrollTop ?? 0;
		}, Xt = () => {
			let e = ir;
			if (!e || !U.length) return;
			let t = e.scrollTop - rr;
			if (!(Math.abs(t) < .01)) {
				for (let e of U) e.top -= t, e.bottom -= t, e.midY -= t;
				rr = e.scrollTop;
			}
		}, Zt = (e, t) => (U.length || Yt(), U.map((e) => ({
			entry: e,
			index: P.value.findIndex((t) => t.node === e.node)
		})).filter(({ index: e }) => e >= 0 && !t.includes(e)).find(({ entry: t }) => e < t.midY)?.index ?? P.value.length), Qt = (e, t) => (U.length || Yt(), U.map((e) => ({
			entry: e,
			index: P.value.findIndex((t) => t.node === e.node)
		})).filter(({ index: e }) => e >= 0 && !t.includes(e)).find(({ entry: t }) => {
			let n = (e - t.top) / Math.max(1, t.height);
			return n > .2 && n < .8;
		})?.index ?? -1), $t = (e) => {
			let t = Qn.value.map((e) => P.value.findIndex((t) => t.node === e)).filter((e) => e >= 0).sort((e, t) => e - t);
			if (!t.length) return e;
			let n = t[0], r = t[t.length - 1];
			return r - n + 1 === t.length && e >= n && e <= r + 1 ? -1 : e;
		}, en = () => {
			let e = /* @__PURE__ */ new Map(), t = Qn.value.map((e) => P.value.findIndex((t) => t.node === e)).filter((e) => e >= 0).sort((e, t) => e - t);
			if (!z.value && !B.value || W < 0 || G === "inside") {
				nr.value = e;
				return;
			}
			let n = new Set(t), r = t.reduce((e, t) => {
				let n = P.value[t]?.node, r = U.find((e) => e.node === n);
				return e + (r?.slotSize ?? r?.height ?? 0);
			}, 0);
			if (!t.length && or > 0) for (let t of U) t.index >= W && e.set(t.index, or);
			else if (r > 0) {
				let i = t[0], a = t[t.length - 1];
				if (W > a) for (let t of U) !n.has(t.index) && t.index > a && t.index < W && e.set(t.index, -r);
				else if (W < i) for (let t of U) !n.has(t.index) && t.index >= W && t.index < i && e.set(t.index, r);
			}
			nr.value = e;
		}, tn = () => {
			!z.value && !B.value || (K !== void 0 && (window.clearTimeout(K), K = void 0), tr.value = W, V.value = G, H.value = ar, en());
		}, nn = (e, t, n, r = !1) => {
			let i = $t(e), a = W === i && G === t && ar === n;
			if (W = i, G = t, ar = n, t === "inside" || r) {
				tn();
				return;
			}
			a && K !== void 0 || tr.value === W && V.value === G && H.value === ar && K === void 0 || (K !== void 0 && window.clearTimeout(K), K = window.setTimeout(() => {
				K = void 0, tn();
			}, Gn));
		}, rn = () => {
			K !== void 0 && (window.clearTimeout(K), K = void 0), (z.value || B.value) && tn();
		}, an = () => {
			sr !== void 0 && window.clearTimeout(sr), cr !== void 0 && window.cancelAnimationFrame(cr), sr = void 0, cr = void 0, lr = 0, ur = 0, dr = null;
		}, on = (e) => {
			let t = ir ?? x.value?.querySelector(".win-scroll-viewer-viewport");
			if (!t) return;
			let n = t.getBoundingClientRect(), r = Math.max(0, (ke.value?.offsetHeight ?? t.scrollHeight) - t.clientHeight);
			if (!r || e >= n.top + Kn && e <= n.bottom - Kn) {
				an();
				return;
			}
			let i = e < n.top + Kn ? e - n.top : n.bottom - e, a = e < n.top + Kn ? -1 : 1;
			if (a < 0 && t.scrollTop <= 0 || a > 0 && t.scrollTop >= r) {
				an();
				return;
			}
			dr = t;
			let o = Math.max(0, Math.min(1, i / Kn));
			lr = a * (Yn - (Yn - Jn) * o), !(cr !== void 0 || sr !== void 0) && (sr = window.setTimeout(() => {
				sr = void 0, ur = 0;
				let e = (t) => {
					if (!dr || !z.value && !B.value || !lr) return an();
					let n = ur ? Math.min(50, t - ur) : 16;
					ur = t;
					let i = dr.scrollTop;
					dr.scrollTop = Math.max(0, Math.min(r, i + lr * n / 1e3)), dr.scrollTop === i ? an() : (Xt(), q && (X ? Vr(q.x, q.y) : Q && Hr(q.x, q.y)), cr = window.requestAnimationFrame(e));
				};
				cr = window.requestAnimationFrame(e);
			}, qn));
		}, sn = (e) => {
			let t = !1, n = !1;
			for (let r of e.Children) {
				let e = r.SelectionState;
				if (e === "Selected" ? t = !0 : e === "UnSelected" && (n = !0), t && n || e === "PartialSelected") return "PartialSelected";
			}
			return t ? "Selected" : "UnSelected";
		}, cn = (e, t) => {
			if (t !== "PartialSelected") if (t === "UnSelected") for (let n = e.Children.length - 1; n >= 0; --n) {
				let r = e.Children[n];
				cn(r, t), R(r, t);
			}
			else for (let n of e.Children) R(n, t), cn(n, t);
		}, ln = (e) => {
			let t = e.Parent;
			if (!t) return;
			let n = t.SelectionState, r = sn(t);
			n !== r && (R(t, r), ln(t));
		}, I = h(() => {
			wt.value;
			let e = O(T.value), t = new Set(e), n = E.filter((e) => t.has(e) && e.SelectionState === "Selected");
			for (let t of e) t.SelectionState === "Selected" && !n.includes(t) && n.push(t);
			return n;
		}), L = h(() => I.value.map((e) => e.Item)), un = 0, dn = [], fn = [], pn = () => {
			w.value !== "Single" && (un += 1, un === 1 && (dn = [], fn = []));
		}, mn = () => {
			if (w.value === "Single" || (--un, un !== 0)) return;
			let e = [...dn], t = [...fn];
			if (dn = [], fn = [], !e.length && !t.length) {
				A();
				return;
			}
			gn(e, t);
		}, R = (e, t) => {
			let n = e.SelectionState === "Selected", r = t === "Selected";
			if (e.SelectionState === t) {
				r && !E.includes(e) && (E.push(e), wt.value += 1);
				return;
			}
			if (e.SelectionState = t, n !== r) {
				if (r) E.includes(e) || E.push(e);
				else {
					let t = E.indexOf(e);
					t >= 0 && E.splice(t, 1);
				}
				wt.value += 1;
			}
			un > 0 && n !== r && (r ? dn.push(e.Item) : fn.push(e.Item));
		}, hn = (e, t) => {
			e.SelectionState !== t && (R(e, t), w.value !== "Single" && (cn(e, t), ln(e)));
		}, gn = (e, t) => {
			A();
			let r = {
				AddedItems: e,
				RemovedItems: t
			};
			y("SelectionChanged", k, r), n(Te.SelectionChanged, b)?.(k, r), y("update:SelectedItems", L.value), y("update:SelectedItem", L.value[0] ?? null);
		}, _n = (e) => {
			let t = new Set(e), n = [...L.value], r = new Set(n), i = n.filter((e) => !t.has(e)), a = e.filter((e) => !r.has(e));
			(i.length || a.length) && gn(i, a);
		}, vn = (e, t) => {
			if (w.value !== "None" && t !== (e.SelectionState === "Selected")) {
				if (w.value === "Single") {
					let n = [...L.value];
					if (t) {
						for (let t of I.value) t !== e && R(t, "UnSelected");
						R(e, "Selected"), gn([e.Item], n);
					} else R(e, "UnSelected"), gn([], [e.Item]);
					return;
				}
				pn();
				try {
					hn(e, t ? "Selected" : "UnSelected");
				} finally {
					mn();
				}
			}
		}, yn = () => {
			if (w.value === "Multiple") {
				pn();
				try {
					for (let e of T.value) hn(e, "Selected");
				} finally {
					mn();
				}
				je.value = "Selected";
			}
		}, bn = (e) => {
			let t = [], n = !1, r, i = () => Array.from(t), a = (t, r) => {
				n || e(t.filter((e) => e !== void 0), {
					removed: r.removed.filter((e) => e !== void 0),
					inserted: r.inserted.filter((e) => e !== void 0)
				});
			};
			return Object.defineProperties(t, {
				push: {
					configurable: !0,
					enumerable: !1,
					value: (...e) => {
						let t = i(), n = t.push(...e);
						return a(t, {
							removed: [],
							inserted: e
						}), n;
					}
				},
				pop: {
					configurable: !0,
					enumerable: !1,
					value: () => {
						let e = i(), t = e.pop();
						return a(e, {
							removed: t === void 0 ? [] : [t],
							inserted: []
						}), t;
					}
				},
				shift: {
					configurable: !0,
					enumerable: !1,
					value: () => {
						let e = i(), t = e.shift();
						return a(e, {
							removed: t === void 0 ? [] : [t],
							inserted: []
						}), t;
					}
				},
				unshift: {
					configurable: !0,
					enumerable: !1,
					value: (...e) => {
						let t = i(), n = t.unshift(...e);
						return a(t, {
							removed: [],
							inserted: e
						}), n;
					}
				},
				splice: {
					configurable: !0,
					enumerable: !1,
					value: (e, t, ...n) => {
						let r = i(), o = t === void 0 ? r.splice(e) : r.splice(e, t, ...n);
						return a(r, {
							removed: o,
							inserted: n
						}), o;
					}
				}
			}), it(t), r = new Proxy(t, {
				set(e, t, r) {
					if (n || t !== "length" && !/^\d+$/.test(String(t))) return Reflect.set(e, t, r);
					let o = i(), s = t === "length" && Number(r) < o.length ? o.slice(Number(r)) : /^\d+$/.test(String(t)) && Number(t) < o.length ? [o[Number(t)]] : [];
					return Reflect.set(o, t, r), a(o, {
						removed: s,
						inserted: /^\d+$/.test(String(t)) ? [r] : []
					}), !0;
				},
				deleteProperty(e, t) {
					if (n || !/^\d+$/.test(String(t))) return Reflect.deleteProperty(e, t);
					let r = i();
					return a(r, {
						removed: r.splice(Number(t), 1),
						inserted: []
					}), !0;
				}
			}), {
				vector: r,
				sync(e) {
					n = !0, Array.prototype.splice.call(t, 0, t.length, ...e), n = !1;
				}
			};
		}, xn = !1, Sn = (e, t = {
			removed: [...I.value],
			inserted: e
		}) => {
			if (xn) return;
			let n = O(T.value), r = new Set(n), i = e.filter((t, n) => r.has(t) && e.indexOf(t) === n), a = w.value === "Single" ? i.slice(-1) : i, o = [...L.value];
			if (w.value === "None") {
				A();
				return;
			}
			xn = !0, w.value === "Multiple" && pn();
			try {
				if (w.value === "Single") {
					for (let e of n) R(e, "UnSelected");
					a[0] && R(a[0], "Selected");
				} else {
					let e = t.removed.filter((e) => r.has(e)), n = t.inserted.filter((e) => r.has(e));
					for (let t of e) hn(t, "UnSelected");
					for (let e of n) hn(e, "Selected");
				}
			} finally {
				w.value === "Multiple" && mn(), xn = !1;
			}
			w.value === "Single" ? _n(o) : A();
		}, Cn = bn(Sn), wn = bn((e, t) => {
			let n = O(T.value), r = e.map((e) => n.find((t) => t.Item === e)).filter((e) => !!e), i = (e) => e.map((e) => n.find((t) => t.Item === e)).filter((e) => !!e);
			Sn(r, {
				removed: i(t.removed),
				inserted: i(t.inserted)
			});
		});
		A = () => {
			let e = I.value;
			(e.length !== E.length || e.some((e, t) => E[t] !== e)) && Tt(e), Cn.sync(e), wn.sync(e.map((e) => e.Item));
		}, A();
		let Tn = (e) => vn(e, e.SelectionState !== "Selected"), En = (e, t) => {
			let r = {
				Node: t,
				Item: t.Content
			};
			y(e === "expanding" ? "Expanding" : "Collapsed", k, r), n(Te[e === "expanding" ? "Expanding" : "Collapsed"], b)?.(k, r);
		};
		function Dn(e) {
			e.IsExpanded || !e.Children.length && !e.HasUnrealizedChildren || (e.IsExpanded = !0, M(), En("expanding", e));
		}
		function On(e) {
			if (!e.IsExpanded) return;
			let t = D.value ? br(e, D.value) : !1;
			e.IsExpanded = !1, t && (D.value = e), M(), En("collapsed", e), t && de(() => Fn(e));
		}
		let kn = (e) => {
			e.IsExpanded ? On(e) : Dn(e);
		}, An = (e, t) => {
			!C.value || !t.hasChildren || (e.preventDefault(), e.stopPropagation(), D.value = t.node, kn(t.node));
		}, jn = (e) => {
			let t = {
				InvokedItem: e,
				Handled: !1
			};
			y("ItemInvoked", k, t), n(Te.ItemInvoked, b)?.(k, t);
		}, Mn = (e) => e === "ArrowUp" || e === "ArrowDown" || e === "ArrowLeft" || e === "ArrowRight", Nn = () => Array.from(ke.value?.querySelectorAll(".win-tree-item") ?? []), Pn = (e) => {
			let t = P.value[e];
			t && (D.value = t.node, Nn()[e]?.focus());
		}, Fn = (e) => {
			let t = Mt.value.indexOf(e);
			t >= 0 && Pn(t);
		}, In = (e, t) => {
			if (!C.value) return;
			let n = t.node;
			if (Ne.value && Mn(e.key) && e.shiftKey && e.altKey && !e.ctrlKey) {
				e.preventDefault(), Ln(n, e.key);
				return;
			}
			if (Mn(e.key) && !e.shiftKey && !e.altKey && !e.ctrlKey) {
				let t = Fe.value === "rtl", r = !t && e.key === "ArrowLeft" || t && e.key === "ArrowRight", i = !t && e.key === "ArrowRight" || t && e.key === "ArrowLeft", a = !1;
				if (r ? n.IsExpanded ? (On(n), Fn(n), a = !0) : n.Parent && (Fn(n.Parent), a = !0) : i && (!n.IsExpanded && (n.Children.length || n.HasUnrealizedChildren) ? (Dn(n), a = !0) : n.Children.length && (Fn(n.Children[0]), a = !0)), a) {
					e.preventDefault();
					return;
				}
			}
			if (e.key === " " && w.value === "Multiple") {
				e.preventDefault(), Tn(n);
				return;
			}
			if (e.key === "Enter") {
				e.preventDefault(), jn(n.Item);
				return;
			}
			if (e.key === "ArrowDown" || e.key === "ArrowUp") {
				let n = t.index + (e.key === "ArrowDown" ? 1 : -1);
				n >= 0 && n < P.value.length && (e.preventDefault(), Pn(n));
				return;
			}
			if (e.key === " " && w.value === "Single") {
				e.preventDefault(), vn(n, !0);
				return;
			}
			if (e.key === "Home" || e.key === "End") {
				e.preventDefault(), Pn(e.key === "Home" ? 0 : P.value.length - 1);
				return;
			}
			if (e.key === "PageDown" || e.key === "PageUp") {
				e.preventDefault();
				let n = x.value?.querySelector(".win-scroll-viewer-viewport"), r = n ? Math.max(1, Math.floor(n.clientHeight / 32)) : 5, i = e.key === "PageDown" ? r : -r, a = Math.min(P.value.length - 1, Math.max(0, t.index + i)), o = Nn()[a];
				o?.focus(), o?.scrollIntoView({ block: "nearest" });
			}
		}, Ln = (e, t) => {
			let n = e.Parent ? e.Parent.Children : T.value, r = n.indexOf(e);
			if (r < 0) return;
			let i = t === "ArrowUp" || t === "ArrowLeft" && r !== 0, a = t === "ArrowDown" || t === "ArrowRight";
			if (i) {
				if (r <= 0) return;
				n.splice(r, 1), n.splice(r - 1, 0, e);
			} else if (a) {
				if (r >= n.length - 1) return;
				n.splice(r, 1), n.splice(r + 1, 0, e);
			} else return;
			e.IsExpanded && On(e), M(), Bn(), de(() => Fn(e));
		}, Rn = (e, t) => e.length === t.length && e.every((e, n) => e === t[n]), zn = (e) => {
			let t = e.IsContentMode ? e.Content : e.SourceItem;
			if (t && typeof t == "object") {
				let n = t, r = e.Children.map(zn), i = Array.isArray(n.Children) ? n.Children : Array.isArray(n.ItemsSource) ? n.ItemsSource : null;
				i ? (Rn(i, r) || i.splice(0, i.length, ...r), e.ChildrenSource = i) : r.length && (e.ChildrenSource = r, n.Children = r);
			}
			return t;
		}, Bn = () => {
			kt = !0;
			let e = T.value.map(zn), t = xt.value.collection;
			t && t !== e && !Rn(t, e) && t.splice(0, t.length, ...e), j = t ?? e, y(xt.value.isContentMode ? "update:ItemsSource" : "update:RootNodes", j), de(() => {
				kt = !1, j = null;
			});
		};
		at = (e) => {
			if (e) {
				for (let t of e.Children) ht(t, e.Depth + 1);
				w.value === "Multiple" && (R(e, sn(e)), ln(e));
			} else for (let e of T.value) ht(e, 0);
			D.value && !O(T.value).includes(D.value) && (D.value = e ?? Mt.value[0] ?? null), M(), A(), Bn();
		};
		let Vn = Symbol("winuionweb-treeview-drag-owner"), Hn = "winuionweb-treeview-pointer-drag-over", Un = "winuionweb-treeview-pointer-drag-leave", Wn = "winuionweb-treeview-pointer-drop", Gn = 200, Kn = 100, qn = 50, Jn = 150, Yn = 1500, Xn = 1e3, z = _(!1), B = _(!1), Zn = _([]), Qn = _([]), $n = he(null), er = _(0), tr = _(-1), V = _(null), H = _(-1), nr = _(/* @__PURE__ */ new Map()), U = [], rr = 0, ir = null, W = -1, G = null, ar = -1, K, or = 0, q = null, sr, cr, lr = 0, ur = 0, dr = null, J = he(null), Y = _(!1), X = null, fr = null, Z = null, pr = null, Q = null, mr = 0, hr, gr = null, _r, vr = () => {
			_r !== void 0 && window.clearTimeout(_r), _r = void 0;
		}, $ = () => {
			hr !== void 0 && window.clearTimeout(hr), hr = void 0, gr = null;
		}, yr = (e) => {
			e !== gr && ($(), !(!e || e.IsExpanded || !e.Children.length && !e.HasUnrealizedChildren) && (gr = e, hr = window.setTimeout(() => {
				hr = void 0, gr === e && !e.IsExpanded && Dn(e), gr = null;
			}, Xn)));
		}, br = (e, t) => {
			let n = t.Parent;
			for (; n;) {
				if (n === e) return !0;
				n = n.Parent;
			}
			return !1;
		}, xr = (e) => e.filter((t) => !e.some((e) => e !== t && br(e, t))), Sr = (e) => (e?.nodes ?? []).filter((e) => !!(e && typeof e == "object")), Cr = (e, t) => !Sr(t).some((t) => t === e || br(t, e)), wr = null, Tr = () => {
			let e = O(T.value);
			return {
				detached: [],
				collections: new Map([T.value, ...e.map((e) => e.Children)].map((e) => [e, [...e]])),
				nodeStates: new Map(e.map((e) => [e, {
					parent: e.Parent,
					depth: e.Depth,
					isExpanded: e.IsExpanded,
					selectionState: e.SelectionState,
					presentation: {
						Item: e.Item,
						Context: e.Context,
						IsContentMode: e.IsContentMode,
						PresenterContent: e.PresenterContent,
						ContainerProps: e.ContainerProps,
						Template: e.Template,
						HasUnrealizedChildren: e.HasUnrealizedChildren
					}
				}])),
				selectionOrder: [...E],
				activeNode: D.value,
				originSelectionState: je.value
			};
		}, Er = () => {
			wr ??= Tr();
		}, Dr = () => {
			wr = null;
		}, Or = (e) => {
			for (let [t, n] of e.collections) dt(t)?.restoreSnapshot?.(n);
			for (let [t, n] of e.nodeStates) t.Parent = n.parent, t.Depth = n.depth, t.IsExpanded = n.isExpanded, t.SelectionState = n.selectionState, Object.assign(t, n.presentation), Gt.delete(t);
			for (let e of T.value) pt(e, e.IsContentMode);
			Tt(e.selectionOrder), D.value = e.activeNode, je.value = e.originSelectionState, M(), A();
		}, kr = () => {
			let e = wr;
			wr = null, e && Or(e);
		}, Ar = (e) => {
			let t = e, n = t.Parent, r = n ? n.Children : T.value, i = r.indexOf(t);
			return i < 0 ? !1 : (wr && !wr.detached.some((e) => e.node === t) && wr.detached.push({
				node: t,
				siblings: r,
				index: i,
				parent: n,
				depth: t.Depth
			}), r.splice(i, 1), w.value === "Multiple" && n?.Children.length && (R(n, sn(n)), ln(n)), !0);
		}, jr = (e, t, r) => {
			let i = {
				Items: e,
				DropResult: t,
				NewParentItem: r
			};
			y("DragItemsCompleted", k, i), n(Te.DragItemsCompleted, b)?.(k, i);
		}, Mr = (e, t) => {
			let n = [...L.value], r = {
				owner: Vn,
				nodes: [...e],
				items: t,
				beginTransaction: Er,
				commitTransaction: Dr,
				rollbackTransaction: kr,
				detach: Ar,
				commitSource: () => {
					D.value && !O(T.value).includes(D.value) && (D.value = Mt.value[0] ?? null), M();
					try {
						_n(n);
					} finally {
						Bn();
					}
				},
				complete: (e, t) => {
					if (!r.completed) {
						r.completed = !0;
						try {
							e === "None" ? kr() : Dr(), jr(r.items, e, t);
						} finally {
							r.cleanup();
						}
					}
				},
				cleanup: () => $r(),
				completed: !1
			};
			return r;
		}, Nr = (e, t) => {
			let r = [...I.value], i = w.value === "Multiple" && r.length > 0, a = i && r.length > 1 ? r : [e.node], o = xr(i ? r : [e.node]), s = a.map((e) => e.Item), c = {
				Items: s,
				Cancel: !1,
				Data: t
			};
			if (y("DragItemsStarting", k, c), n(Te.DragItemsStarting, b)?.(k, c), c.Cancel || !o.length) return null;
			Er();
			try {
				if (!i) for (let e of o) e.IsExpanded && On(e);
				return Zn.value = o, Qn.value = P.value.filter((e) => o.some((t) => e.node === t || br(t, e.node))).map((e) => e.node), $n.value = e.node, er.value = i ? a.length : 1, z.value = !0, Mr(o, s);
			} catch (e) {
				throw kr(), $r(), e;
			}
		}, Pr = () => en(), Fr = () => {
			an(), K !== void 0 && (window.clearTimeout(K), K = void 0), W = -1, G = null, ar = -1, tr.value = -1, V.value = null, H.value = -1, B.value = !1, Q = null, $(), en();
		}, Ir = (e, t) => {
			let n = U.find((t) => t.node === e.node);
			if (!n) return;
			let r = (t - n.top) / Math.max(1, n.height), i = r < .2 ? "before" : r > .8 ? "after" : "inside";
			nn(i === "after" ? e.index + 1 : e.index, i, e.index), yr(i === "inside" ? e.node : null);
		}, Lr = (e) => {
			if (er.value <= 1 || e.querySelector(".win-tree-drag-count")) return;
			let t = e.querySelector(".win-tree-multiselect-slot");
			if (!t) return;
			let n = document.createElement("span");
			n.className = "win-tree-drag-count", n.setAttribute("aria-hidden", "true"), n.textContent = String(er.value), t.appendChild(n);
		}, Rr = (e, t, n = !1) => {
			let r = J.value;
			if (!r || Y.value || !Me.value || !n && Math.hypot(e.clientX - r.startX, e.clientY - r.startY) < 8) return;
			vr();
			let i = r.source, a = Nr(t, null);
			if (!a) {
				J.value = null;
				return;
			}
			Y.value = !0, Yt(), de(() => {
				Y.value && Yt();
			}), W = -1, G = null, ar = -1, or = 0;
			let o = i.cloneNode(!0);
			o.querySelectorAll("[id]").forEach((e) => e.removeAttribute("id")), o.removeAttribute("id"), o.classList.remove("dragging-source", "reorder-target"), o.classList.add("win-tree-drag-preview"), o.style.pointerEvents = "none", Lr(o);
			let s = i.getBoundingClientRect();
			Object.assign(o.style, {
				width: `${s.width}px`,
				height: `${s.height}px`,
				margin: "0",
				left: "0",
				top: "0"
			}), document.body.appendChild(o), fr = o, o.style.transform = `translate3d(${e.clientX - r.grabX}px, ${e.clientY - r.grabY}px, 0)`, X = {
				session: a,
				clientX: e.clientX,
				clientY: e.clientY,
				accepted: !1,
				dropResult: "None",
				newParentItem: null
			};
		}, zr = (e, t) => {
			let n = x.value;
			if (n) {
				let r = n.getBoundingClientRect();
				if (e >= r.left && e <= r.right && t >= r.top && t <= r.bottom) return n;
			}
			let r = document.elementsFromPoint(e, t);
			for (let e of r) {
				let t = e.closest(".win-tree-view");
				if (t) return t;
			}
			return null;
		}, Br = (e, t) => {
			U.length || Yt();
			let n = ke.value?.getBoundingClientRect();
			if (n && (e < n.left || e > n.right)) return null;
			for (let e of U) {
				let n = P.value.findIndex((t) => t.node === e.node);
				if (!(n < 0) && t >= e.top && t <= e.bottom) {
					let e = Nn()[n], t = P.value[n];
					if (t) return {
						entry: t,
						element: e
					};
				}
			}
			return null;
		}, Vr = (e, t) => {
			let n = X;
			if (!n) return;
			n.clientX = e, n.clientY = t, q = {
				x: e,
				y: t
			};
			let r = zr(e, t), i = Z;
			Z && Z !== r && (Z.dispatchEvent(new CustomEvent(Un, { detail: n })), Z = null, $()), r && (n.accepted = !1, r.dispatchEvent(new CustomEvent(Hn, { detail: n })), !n.accepted && i === r && r.dispatchEvent(new CustomEvent(Un, { detail: n })), Z = n.accepted ? r : null, B.value = !!Z && !z.value);
		}, Hr = (e, t) => {
			let n = Q;
			if (!n) return !1;
			U.length || Yt();
			let r = Br(e, t);
			if (!r) {
				if (!U.length) return nn(0, "after", -1, !0), $(), !0;
				let e = U[0], n = U[U.length - 1];
				return t < e.top ? (nn(e.index, "before", e.index, !0), H.value = e.index, !0) : t > n.bottom ? (nn(n.index + 1, "after", n.index, !0), H.value = n.index, !0) : (nn(-1, null, -1, !0), $(), !1);
			}
			return Cr(r.entry.node, n) ? (Ir(r.entry, t), !0) : (nn(-1, null, -1, !0), $(), !1);
		}, Ur = (e) => {
			let t = e.detail;
			if (!t) return;
			if (t.accepted = !1, !Pe.value || !C.value) {
				Fr();
				return;
			}
			let n = t.session.owner === Vn;
			if (n && !Ne.value) {
				Fr();
				return;
			}
			Q = t.session, q = {
				x: t.clientX,
				y: t.clientY
			}, B.value = !n, U.length || Yt(), or = n ? 0 : Math.max(1, Sr(t.session).reduce((e, t) => {
				let n = U.find((e) => e.node === t);
				return e + (n?.slotSize ?? n?.height ?? 32);
			}, 0)), t.accepted = Hr(t.clientX, t.clientY), t.accepted &&= ai("dragOver", null, x.value, "Move").AcceptedOperation === "Move", t.accepted ? on(t.clientY) : Fr(), n || (B.value = t.accepted);
		}, Wr = (e) => {
			e.detail && Fr();
		}, Gr = (e) => {
			let t = e.detail;
			if (!t || !C.value) return;
			let n = t.session.owner === Vn;
			if (!Pe.value || n && !Ne.value) return;
			Q = t.session, rn(), t.dropResult = "None", t.newParentItem = null;
			let r = {
				moved: !1,
				newParentItem: null
			};
			try {
				r = ai("drop", null, x.value, "Move").AcceptedOperation === "Move" ? ii(t.session) : r;
			} catch (e) {
				try {
					t.session.rollbackTransaction?.();
				} catch (e) {
					console.error("TreeView pointer drop rollback failed.", e);
				}
				console.error("TreeView pointer drop failed.", e);
			}
			t.dropResult = r.moved ? "Move" : "None", t.newParentItem = r.newParentItem;
		}, Kr = (e, t) => {
			if (!C.value || !e.isPrimary || e.button !== 0 || (D.value = t.node, e.target?.closest(".win-tree-chevron")) || !Me.value) return;
			let n = e.currentTarget, r = n.getBoundingClientRect();
			J.value = {
				pointerId: e.pointerId,
				pointerType: e.pointerType,
				index: t.index,
				startX: e.clientX,
				startY: e.clientY,
				grabX: e.clientX - r.left,
				grabY: e.clientY - r.top,
				source: n
			}, vr(), e.pointerType === "touch" && (_r = window.setTimeout(() => {
				J.value?.pointerId === e.pointerId && Rr(e, t, !0);
			}, 350));
			try {
				n.setPointerCapture?.(e.pointerId);
			} catch {}
		}, qr = (e, t) => {
			let n = J.value;
			if (!(!n || n.pointerId !== e.pointerId || !Me.value)) {
				if (n.touchScroll) {
					ae(n.touchScroll.chain, n.touchScroll.clientY - e.clientY), n.touchScroll.clientY = e.clientY, e.preventDefault();
					return;
				}
				if (!Y.value && n.pointerType === "touch") {
					let r = e.clientX - n.startX, i = e.clientY - n.startY;
					if (Math.abs(r) >= 8 && Math.abs(r) > Math.abs(i)) Rr(e, t);
					else if (Math.abs(i) >= 8) {
						vr();
						let t = oe(n.source);
						n.touchScroll = {
							clientY: e.clientY,
							chain: t
						}, ae(t, n.startY - e.clientY), e.preventDefault();
					}
					if (!Y.value) return;
				}
				Y.value || Rr(e, t), Y.value && (q = {
					x: e.clientX,
					y: e.clientY
				}, fr && (fr.style.transform = `translate3d(${e.clientX - n.grabX}px, ${e.clientY - n.grabY}px, 0)`), Vr(e.clientX, e.clientY), e.preventDefault());
			}
		}, Jr = () => {
			let e = J.value;
			if (e) try {
				e.source.hasPointerCapture?.(e.pointerId) && e.source.releasePointerCapture?.(e.pointerId);
			} catch {}
		}, Yr = (e) => {
			if (vr(), Y.value) {
				mr = Date.now() + 250, e && Vr(e.clientX, e.clientY);
				let t = X;
				Jr();
				try {
					Z && t && Z.dispatchEvent(new CustomEvent(Wn, { detail: t }));
				} catch (e) {
					console.error("TreeView pointer drop dispatch failed.", e);
				} finally {
					try {
						t?.session.complete(t.dropResult, t.newParentItem);
					} catch (e) {
						console.error("TreeView drag completion handler failed.", e);
					} finally {
						$r();
					}
				}
				return;
			}
			J.value?.touchScroll && (mr = Date.now() + 250), J.value = null, Y.value = !1;
		}, Xr = (e) => {
			if (vr(), !(!J.value && !Y.value)) try {
				Y.value && X?.session.complete("None", null);
			} catch (e) {
				console.error("TreeView drag cancellation handler failed.", e);
			} finally {
				Jr(), $r();
			}
		}, Zr = (e, t) => {
			e.pointerType === "mouse" && !Y.value && (J.value = null);
		}, Qr = (e) => {
			J.value?.pointerId === e.pointerId && (Y.value || (vr(), J.value = null));
		}, $r = () => {
			try {
				Z && X && Z.dispatchEvent(new CustomEvent(Un, { detail: X }));
			} catch (e) {
				console.error("TreeView drag-leave cleanup failed.", e);
			} finally {
				vr(), $(), an(), K !== void 0 && window.clearTimeout(K), K = void 0, W = -1, G = null, ar = -1, U = [], ir = null, q = null, or = 0, Z = null, Jr(), fr?.remove(), fr = null, X = null, z.value = !1, B.value = !1, Zn.value = [], Qn.value = [], $n.value = null, er.value = 0, tr.value = -1, V.value = null, H.value = -1, nr.value = /* @__PURE__ */ new Map(), J.value = null, Y.value = !1, Q = null;
			}
		}, ei = (e, t) => {
			e.Depth = t;
			for (let n of e.Children) ei(n, t + 1);
		}, ti = (e, n) => {
			e.IsContentMode = n, e.Item = n ? e.Content : e, e.Context = n ? tt(e.Content) : e;
			let i = Qe(e.Context);
			e.ContainerProps = i?.props ?? {};
			let a = r(e.ContainerProps.Content, b);
			e.PresenterContent = a === void 0 ? e.Content : a, e.HasUnrealizedChildren = rt(n ? e.Content : e.SourceItem, i, "HasUnrealizedChildren");
			let o = i ? p(i) : [];
			e.Template = o.length ? t(o, e.Context, b) : null, Gt.delete(e);
			for (let t of e.Children) ti(t, n);
		}, ni = (e, t) => {
			let n = [];
			for (let r of xr(Sr(e))) r === t || br(r, t) || e.detach(r) && (r.Parent = t, t.Children.push(r), ei(r, t.Depth + 1), n.push(r));
			return n.length && Dn(t), n;
		}, ri = (e, t, n) => {
			let r = t.Parent ? t.Parent.Children : T.value;
			if (!r.includes(t)) return [];
			let i = xr(Sr(e)).filter((e) => e !== t && !br(e, t)).filter((t) => e.detach(t)), a = r.indexOf(t) + +!n;
			for (let e of i) r.splice(a, 0, e), a += 1, e.Parent = t.Parent, ei(e, t.Depth);
			return i;
		}, ii = (e) => {
			let t = tr.value, n = V.value;
			if (!C.value || t < 0 || !n) return {
				moved: !1,
				newParentItem: null
			};
			let r = e.owner === Vn, i = [...L.value], a = xr(Sr(e)), o = new Map(a.map((e) => {
				let t = e.Parent ? e.Parent.Children : r ? T.value : [];
				return [e, {
					parent: e.Parent,
					index: t.indexOf(e)
				}];
			})), s = P.value[n === "after" ? t - 1 : t]?.node;
			if (P.value.length && (!s || !Cr(s, e))) return {
				moved: !1,
				newParentItem: null
			};
			let c = r ? null : Tr();
			e.beginTransaction?.();
			let l = [], u = null, d = !1;
			try {
				if (s) n === "inside" ? (l = ni(e, s), u = s.Item) : (l = ri(e, s, n === "before"), u = s.Parent?.Item ?? null);
				else {
					l = xr(Sr(e)).filter((t) => e.detach(t));
					for (let e of l) e.Parent = null, T.value.push(e), ei(e, 0);
				}
				if (!l.length) return e.rollbackTransaction?.(), c && Or(c), {
					moved: !1,
					newParentItem: null
				};
				for (let e of l) ti(e, xt.value.isContentMode);
				if (d = !r || l.some((e) => {
					let t = o.get(e), n = e.Parent ? e.Parent.Children : T.value;
					return !t || t.parent !== e.Parent || t.index !== n.indexOf(e);
				}), !d) return e.rollbackTransaction?.(), c && Or(c), {
					moved: !1,
					newParentItem: null
				};
				if (w.value === "Multiple") {
					for (let e of l) {
						let t = e.Parent?.SelectionState ?? "UnSelected";
						R(e, t), cn(e, t);
					}
					for (let e of l) ln(e);
				} else if (w.value === "Single") {
					let e = O(l).find((e) => e.SelectionState === "Selected");
					if (e) {
						for (let t of N.value) t !== e && R(t, "UnSelected");
						R(e, "Selected");
					}
				} else for (let e of O(l)) R(e, "UnSelected");
				e.commitTransaction?.();
			} catch {
				try {
					c && Or(c);
				} finally {
					e.rollbackTransaction?.();
				}
				return {
					moved: !1,
					newParentItem: null
				};
			}
			try {
				try {
					r || e.commitSource();
				} finally {
					M();
					try {
						_n(i);
					} finally {
						Bn();
					}
				}
			} catch (e) {
				console.error("TreeView drop notification failed after the move was committed.", e);
			}
			return {
				moved: !0,
				newParentItem: u
			};
		}, ai = (e, t, r, i) => {
			let a = {
				DataTransfer: t,
				AcceptedOperation: i,
				OriginalSource: r
			};
			return y(e === "dragOver" ? "DragOver" : "Drop", k, a), n(Te[e === "dragOver" ? "DragOver" : "Drop"], b)?.(k, a), a;
		}, oi = (e) => {
			let t = v;
			if (!t || !C.value || !Pe.value) return null;
			let n = t.owner === Vn;
			return n && !Ne.value || !n && !Pe.value ? null : (Q = t, q = {
				x: e.clientX,
				y: e.clientY
			}, Hr(e.clientX, e.clientY) ? ai("dragOver", e.dataTransfer, e.target, "Move").AcceptedOperation === "Move" ? (e.preventDefault(), on(e.clientY), e.dataTransfer && (e.dataTransfer.dropEffect = "move"), B.value = !n, t) : (Q = null, tr.value = -1, V.value = null, H.value = -1, $(), Pr(), e.dataTransfer && (e.dataTransfer.dropEffect = "none"), null) : (Fr(), null));
		}, si = (e) => {
			oi(e);
		}, ci = (e) => {
			let t = e.relatedTarget;
			t instanceof Node && x.value?.contains(t) || Fr();
		}, li = (e) => {
			let t = v;
			if (!t) return;
			e.preventDefault(), e.stopPropagation();
			let n = t.owner === Vn, r = {
				moved: !1,
				newParentItem: null
			};
			try {
				C.value && Pe.value && (!n || Ne.value) && (Q = t, rn(), r = ai("drop", e.dataTransfer, e.target, "Move").AcceptedOperation === "Move" ? ii(t) : r);
			} catch (e) {
				try {
					t.rollbackTransaction?.();
				} catch (e) {
					console.error("TreeView native drop rollback failed.", e);
				}
				console.error("TreeView native drop failed.", e);
			} finally {
				try {
					t.complete(r.moved ? "Move" : "None", r.newParentItem);
				} catch (e) {
					console.error("TreeView drag completion handler failed.", e);
				} finally {
					v === t && (v = null);
					try {
						t.cleanup();
					} finally {
						$r();
					}
				}
			}
		}, ui = (e) => {
			e.defaultPrevented || oi(e);
		}, di = (e) => {
			e.defaultPrevented || !v || li(e);
		}, fi = (e, t) => {
			if (!Me.value || !e.dataTransfer) {
				e.preventDefault();
				return;
			}
			D.value = t.node;
			let n = Nr(t, e.dataTransfer);
			if (!n) {
				e.preventDefault();
				return;
			}
			pr = n, v = n, e.dataTransfer.effectAllowed = "move", e.dataTransfer.setData("text/plain", String(t.node.Content ?? ""));
			let r = e.currentTarget, i = r.cloneNode(!0);
			i.querySelectorAll("[id]").forEach((e) => e.removeAttribute("id")), i.removeAttribute("id"), i.classList.remove("dragging-source", "reorder-target"), i.classList.add("win-tree-drag-preview"), Lr(i);
			let a = r.getBoundingClientRect();
			Object.assign(i.style, {
				width: `${a.width}px`,
				height: `${a.height}px`,
				margin: "0",
				left: "-10000px",
				top: "0",
				transform: "none"
			}), document.body.appendChild(i), e.dataTransfer.setDragImage(i, Math.max(0, e.clientX - a.left), Math.max(0, e.clientY - a.top)), window.setTimeout(() => i.remove(), 0);
		}, pi = (e) => {
			let t = pr;
			mr = Date.now() + 250;
			try {
				t && !t.completed && t.complete("None", null);
			} catch (e) {
				console.error("TreeView native drag cancellation handler failed.", e);
			} finally {
				v === t && (v = null), pr = null, $r();
			}
		}, mi = (e, t) => {
			!C.value || z.value || Date.now() < mr || e.target?.closest(".win-tree-chevron") || (jn(t.node.Item), w.value === "Single" && vn(t.node, !0));
		}, hi = (e) => {
			let t = J.value;
			!t || t.pointerId !== e.pointerId || !Y.value || (fr && (fr.style.transform = `translate3d(${e.clientX - t.grabX}px, ${e.clientY - t.grabY}px, 0)`), Vr(e.clientX, e.clientY));
		}, gi = (e) => {
			J.value?.pointerId === e.pointerId && Yr(e);
		}, _i = (e) => {
			J.value?.pointerId === e.pointerId && Xr();
		}, vi = () => {
			let e = pr;
			try {
				Y.value && X?.session.complete("None", null);
			} catch (e) {
				console.error("TreeView pointer drag cancellation handler failed.", e);
			}
			try {
				e && !e.completed && e.complete("None", null);
			} catch (e) {
				console.error("TreeView native drag cancellation handler failed.", e);
			} finally {
				v === e && (v = null), pr = null, $r();
			}
		}, yi = (e) => {
			e.key !== "Escape" || !J.value && !pr || (e.preventDefault(), vi());
		}, bi = () => {
			document.visibilityState === "hidden" && vi();
		}, xi = !1, Si;
		pe(() => {
			let e = x.value;
			e?.addEventListener(Hn, Ur), e?.addEventListener(Un, Wr), e?.addEventListener(Wn, Gr), document.addEventListener("pointermove", hi), document.addEventListener("pointerup", gi), document.addEventListener("pointercancel", _i), document.addEventListener("keydown", yi, !0), document.addEventListener("visibilitychange", bi), window.addEventListener("blur", vi), Si = ie(() => Y.value, () => J.value?.pointerId), xi = !0;
		}), fe(() => {
			Si?.(), Si = void 0, $(), xi &&= (document.removeEventListener("pointermove", hi), document.removeEventListener("pointerup", gi), document.removeEventListener("pointercancel", _i), document.removeEventListener("keydown", yi, !0), document.removeEventListener("visibilitychange", bi), window.removeEventListener("blur", vi), !1);
			let e = x.value;
			e?.removeEventListener(Hn, Ur), e?.removeEventListener(Un, Wr), e?.removeEventListener(Wn, Gr), vi();
		});
		let Ci = h(() => I.value[0] ?? null), wi = (e) => {
			if (!e) return null;
			let t = Mt.value.indexOf(e);
			return t >= 0 ? Nn()[t] ?? null : null;
		}, Ti = (e) => {
			let t = e instanceof Element ? e.closest(".win-tree-item") : null;
			if (!t) return null;
			let n = Nn().indexOf(t);
			return n >= 0 ? Mt.value[n] ?? null : null;
		};
		Object.defineProperties(k, {
			RootNodes: {
				enumerable: !0,
				get: () => T.value
			},
			SelectedNodes: {
				enumerable: !0,
				get: () => Cn.vector
			},
			SelectedItems: {
				enumerable: !0,
				get: () => wn.vector
			},
			SelectedNode: {
				enumerable: !0,
				get: () => Ci.value,
				set: (e) => {
					let t = e && typeof e == "object" && "Item" in e ? e : N.value.find((t) => t.Item === e) ?? null;
					t && vn(t, !0);
				}
			},
			SelectedItem: {
				enumerable: !0,
				get: () => Ci.value?.Item ?? null,
				set: (e) => {
					if (e == null) {
						let e = [...L.value];
						for (let e of [...I.value]) R(e, "UnSelected");
						e.length && gn([], e);
						return;
					}
					let t = N.value.find((t) => t.Item === e);
					t && vn(t, !0);
				}
			},
			NodeFromContainer: {
				enumerable: !0,
				value: Ti
			},
			ContainerFromNode: {
				enumerable: !0,
				value: wi
			},
			ItemFromContainer: {
				enumerable: !0,
				value: (e) => Ti(e)?.Item ?? null
			},
			ContainerFromItem: {
				enumerable: !0,
				value: (e) => wi(N.value.find((t) => t.Item === e) ?? null)
			}
		}), Object.assign(k, {
			SelectAll: yn,
			Expand: Dn,
			Collapse: On
		}), ve(w, (e) => {
			if (e === "None" && N.value.some((e) => e.SelectionState !== "UnSelected")) {
				let e = [...L.value];
				for (let e of N.value) R(e, "UnSelected");
				e.length && gn([], e);
			} else if (e === "Single" && I.value.length > 1) {
				let [e, ...t] = I.value;
				for (let t of N.value) R(t, t === e ? "Selected" : "UnSelected");
				gn([], t.map((e) => e.Item));
			}
		}, { immediate: !0 }), ve(() => r(f.SelectedItem, b), (e) => {
			if (e === void 0) return;
			if (e === null) {
				let e = [...L.value];
				if (!e.length) return;
				for (let e of [...I.value]) R(e, "UnSelected");
				gn([], e);
				return;
			}
			let t = N.value.find((t) => t.Item === e);
			t && t.SelectionState !== "Selected" && vn(t, !0);
		}, { immediate: !0 }), ve(() => r(f.SelectedItems, b), (e) => {
			if (!Array.isArray(e) || w.value !== "Multiple") return;
			let t = new Set(e), n = new Set(L.value);
			if (t.size === n.size && [...t].every((e) => n.has(e))) return;
			let r = xr(e.map((e) => N.value.find((t) => t.Item === e)).filter((e) => !!e));
			pn();
			try {
				for (let e of T.value) hn(e, "UnSelected");
				for (let e of r) hn(e, "Selected");
			} finally {
				mn();
			}
		}, {
			immediate: !0,
			deep: !0
		}), l(k);
		let Ei = {
			XamlTreeViewItem: ye,
			TreeViewRootNodes: be,
			XamlTreeViewNode: xe,
			TreeViewNodeChildren: Se,
			get activeNativeTreeDrag() {
				return v;
			},
			set activeNativeTreeDrag(e) {
				v = e;
			},
			treeNodeVectorStateKey: Ce,
			TreeViewItemScope: d,
			props: f,
			emit: y,
			slots: we,
			attrs: Te,
			instance: b,
			inheritedScrollTemplateScope: Ee,
			ScrollSettings: De,
			pageResources: Oe,
			containerRef: x,
			listRef: ke,
			cssLength: S,
			xamlThickness: Ae,
			isEnabled: C,
			selectionMode: w,
			rootSelectionState: je,
			canDragItems: Me,
			canReorderItems: Ne,
			allowDrop: Pe,
			direction: Fe,
			alignment: Ie,
			backgroundStyle: Le,
			rootStyle: Re,
			contentPaddingStyle: ze,
			slotNodes: Be,
			templateResourceKey: Ve,
			resourceNameOf: He,
			typeNameOf: Ue,
			templateNodeKey: We,
			flattenSelectorNodes: Ge,
			itemTemplateNodes: Ke,
			selectorBranches: qe,
			selectorBranchFor: Je,
			templateNodesForKey: Ye,
			templateNodesFor: Xe,
			isTreeViewItemNode: Ze,
			treeViewItemRoot: Qe,
			childItemsFrom: $e,
			contentOf: et,
			itemContext: tt,
			declaredExpanded: nt,
			declaredFlag: rt,
			publishVectorSurface: it,
			get notifyNodeVectorChanged() {
				return at;
			},
			set notifyNodeVectorChanged(e) {
				at = e;
			},
			get suppressNodeVectorNotifications() {
				return ot;
			},
			set suppressNodeVectorNotifications(e) {
				ot = e;
			},
			pendingNodeVectorParents: st,
			get nodeVectorNotificationScheduled() {
				return ct;
			},
			set nodeVectorNotificationScheduled(e) {
				ct = e;
			},
			queueNodeVectorChanged: lt,
			isTreeNode: ut,
			vectorStateOf: dt,
			configureNodeVectorOwner: ft,
			rehomeNodeVectorOwner: pt,
			createNodeVector: mt,
			reindexNode: ht,
			reconcileAdoptedSelection: gt,
			buildNode: _t,
			declaredNodeCache: vt,
			get declaredRootItems() {
				return yt;
			},
			set declaredRootItems(e) {
				yt = e;
			},
			declaredNodeData: bt,
			rootSource: xt,
			transitionState: St,
			nodes: T,
			get rootNodesVectorInitialized() {
				return Ct;
			},
			set rootNodesVectorInitialized(e) {
				Ct = e;
			},
			selectionOrder: E,
			selectionOrderVersion: wt,
			replaceSelectionOrder: Tt,
			activeNode: D,
			nodeIds: Et,
			get nextNodeId() {
				return Dt;
			},
			set nextNodeId(e) {
				Dt = e;
			},
			allNodesFrom: O,
			treeViewApi: k,
			treeNodeVectorOwner: Ot,
			get syncSelectionVectors() {
				return A;
			},
			set syncSelectionVectors(e) {
				A = e;
			},
			get emittedSource() {
				return j;
			},
			set emittedSource(e) {
				j = e;
			},
			get synchronizingSource() {
				return kt;
			},
			set synchronizingSource(e) {
				kt = e;
			},
			treeVersion: At,
			bumpTree: M,
			rebuild: jt,
			flatNodes: Mt,
			allNodes: N,
			rows: P,
			rowId: Nt,
			checkboxAriaValue: Pt,
			onRowFocus: Ft,
			onMultiSelectClick: It,
			containerValue: F,
			selectedContainerStyle: Lt,
			applyContainerStyle: Rt,
			presenterStyle: zt,
			contentStyle: Bt,
			glyphStyle: Vt,
			collapsedGlyph: Ht,
			expandedGlyph: Ut,
			isPrimaryMultiDragRow: Wt,
			itemComponentCache: Gt,
			itemComponent: Kt,
			rowClasses: qt,
			rowStyle: Jt,
			cacheTreeDragLayout: Yt,
			shiftCachedTreeDragLayoutForScroll: Xt,
			treeDragInsertIndex: Zt,
			treeDragOverIndexAt: Qt,
			normalizeTreeInsertSlot: $t,
			updateTreeReorderOffsets: en,
			applyTreeLiveReorder: tn,
			scheduleTreeLiveReorder: nn,
			flushTreeLiveReorder: rn,
			stopTreeEdgeScroll: an,
			updateTreeEdgeScroll: on,
			selectionStateBasedOnChildren: sn,
			updateSelectionStateOfDescendants: cn,
			updateSelectionStateOfAncestors: ln,
			selectedNodeList: I,
			selectedItems: L,
			get selectionTracking() {
				return un;
			},
			set selectionTracking(e) {
				un = e;
			},
			get addedSelectedItems() {
				return dn;
			},
			set addedSelectedItems(e) {
				dn = e;
			},
			get removedSelectedItems() {
				return fn;
			},
			set removedSelectedItems(e) {
				fn = e;
			},
			beginSelectionChanges: pn,
			endSelectionChanges: mn,
			applyNodeSelection: R,
			updateSelection: hn,
			raiseSelectionChanged: gn,
			raiseSelectionDiff: _n,
			selectNode: vn,
			selectAll: yn,
			createProjectedVector: bn,
			get applyingPublicSelection() {
				return xn;
			},
			set applyingPublicSelection(e) {
				xn = e;
			},
			applySelectedNodes: Sn,
			selectedNodesProjection: Cn,
			selectedItemsProjection: wn,
			toggleNode: Tn,
			raiseNodeEvent: En,
			Expand: Dn,
			Collapse: On,
			toggleExpand: kn,
			onChevronPointerDown: An,
			raiseItemInvoked: jn,
			isDirectionalKey: Mn,
			rowElements: Nn,
			focusRowAt: Pn,
			focusNode: Fn,
			onRowKeyDown: In,
			reorderByKeyboard: Ln,
			sameIdentitySequence: Rn,
			projectNode: zn,
			emitSourceChange: Bn,
			pointerDragOwner: Vn,
			pointerDragOverEvent: Hn,
			pointerDragLeaveEvent: Un,
			pointerDropEvent: Wn,
			DRAG_THRESHOLD: 8,
			TOUCH_DRAG_HOLD_DELAY: 350,
			LIVE_REORDER_DELAY: 200,
			EDGE_SCROLL_SIZE: 100,
			EDGE_SCROLL_DELAY: 50,
			EDGE_SCROLL_MIN_SPEED: 150,
			EDGE_SCROLL_MAX_SPEED: Yn,
			DRAG_OVER_EXPAND_DELAY: Xn,
			isDragging: z,
			isExternalDragOver: B,
			dragNodes: Zn,
			dragVisualNodes: Qn,
			primaryDragNode: $n,
			dragItemCount: er,
			dropSlot: tr,
			dropMode: V,
			dragOverIndex: H,
			reorderOffsets: nr,
			get cachedDragLayout() {
				return U;
			},
			set cachedDragLayout(e) {
				U = e;
			},
			get dragLayoutScrollTop() {
				return rr;
			},
			set dragLayoutScrollTop(e) {
				rr = e;
			},
			get dragScrollViewport() {
				return ir;
			},
			set dragScrollViewport(e) {
				ir = e;
			},
			get pendingDropSlot() {
				return W;
			},
			set pendingDropSlot(e) {
				W = e;
			},
			get pendingDropMode() {
				return G;
			},
			set pendingDropMode(e) {
				G = e;
			},
			get pendingDragOverIndex() {
				return ar;
			},
			set pendingDragOverIndex(e) {
				ar = e;
			},
			get liveReorderTimer() {
				return K;
			},
			set liveReorderTimer(e) {
				K = e;
			},
			get externalDragHeight() {
				return or;
			},
			set externalDragHeight(e) {
				or = e;
			},
			get latestPointerPosition() {
				return q;
			},
			set latestPointerPosition(e) {
				q = e;
			},
			get edgeScrollStartTimer() {
				return sr;
			},
			set edgeScrollStartTimer(e) {
				sr = e;
			},
			get edgeScrollFrame() {
				return cr;
			},
			set edgeScrollFrame(e) {
				cr = e;
			},
			get edgeScrollVelocity() {
				return lr;
			},
			set edgeScrollVelocity(e) {
				lr = e;
			},
			get edgeScrollLastTime() {
				return ur;
			},
			set edgeScrollLastTime(e) {
				ur = e;
			},
			get edgeScrollViewport() {
				return dr;
			},
			set edgeScrollViewport(e) {
				dr = e;
			},
			pointerDrag: J,
			pointerDragActive: Y,
			get pointerDragDetail() {
				return X;
			},
			set pointerDragDetail(e) {
				X = e;
			},
			get dragPreviewElement() {
				return fr;
			},
			set dragPreviewElement(e) {
				fr = e;
			},
			get pointerDropTarget() {
				return Z;
			},
			set pointerDropTarget(e) {
				Z = e;
			},
			get nativeDragSession() {
				return pr;
			},
			set nativeDragSession(e) {
				pr = e;
			},
			get targetDragSession() {
				return Q;
			},
			set targetDragSession(e) {
				Q = e;
			},
			get suppressClickUntil() {
				return mr;
			},
			set suppressClickUntil(e) {
				mr = e;
			},
			get expandTimer() {
				return hr;
			},
			set expandTimer(e) {
				hr = e;
			},
			get pendingExpandNode() {
				return gr;
			},
			set pendingExpandNode(e) {
				gr = e;
			},
			get touchDragTimer() {
				return _r;
			},
			set touchDragTimer(e) {
				_r = e;
			},
			clearTouchDragTimer: vr,
			clearExpandTimer: $,
			armExpandTimer: yr,
			isAncestorOf: br,
			subtreeRoots: xr,
			sessionNodes: Sr,
			canDropOn: Cr,
			get sourceDragTransaction() {
				return wr;
			},
			set sourceDragTransaction(e) {
				wr = e;
			},
			captureDragTransaction: Tr,
			beginSourceDragTransaction: Er,
			commitSourceDragTransaction: Dr,
			restoreDragTransaction: Or,
			rollbackSourceDragTransaction: kr,
			detachOwnedNode: Ar,
			raiseDragCompleted: jr,
			createDragSession: Mr,
			beginSourceDrag: Nr,
			updateReorderOffsets: Pr,
			clearDropFeedback: Fr,
			resolveDropTarget: Ir,
			addDragCountToPreview: Lr,
			startPointerDrag: Rr,
			treeViewAtPoint: zr,
			rowAtPoint: Br,
			updatePointerDropTarget: Vr,
			trackPointerOverPoint: Hr,
			onPointerTreeDragOver: Ur,
			onPointerTreeDragLeave: Wr,
			onPointerTreeDrop: Gr,
			onRowPointerDown: Kr,
			onRowPointerMove: qr,
			releasePointerCapture: Jr,
			onRowPointerUp: Yr,
			onRowPointerCancel: Xr,
			onRowPointerLeave: Zr,
			onRowLostPointerCapture: Qr,
			resetDrag: $r,
			reindex: ei,
			adoptNodeMode: ti,
			moveNodesInto: ni,
			insertNodesAt: ri,
			applyDrop: ii,
			raiseDragEvent: ai,
			acceptNativeDragAt: oi,
			onViewportDragOver: si,
			onViewportDragLeave: ci,
			onViewportDrop: li,
			onRootDragOver: ui,
			onRootDrop: di,
			onNativeDragStart: fi,
			onNativeDragEnd: pi,
			onRowClick: mi,
			onGlobalPointerMove: hi,
			onGlobalPointerUp: gi,
			onGlobalPointerCancel: _i,
			cancelActiveInteractions: vi,
			onGlobalKeyDown: yi,
			onVisibilityChange: bi,
			get globalListenersAttached() {
				return xi;
			},
			set globalListenersAttached(e) {
				xi = e;
			},
			get detachSecondaryTouchScroll() {
				return Si;
			},
			set detachSecondaryTouchScroll(e) {
				Si = e;
			},
			selectedNode: Ci,
			rowForNode: wi,
			nodeForContainer: Ti,
			ScrollViewer: te,
			CheckBox: re,
			get vAcrylicBrush() {
				return o;
			}
		};
		return Object.defineProperty(Ei, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), Ei;
	}
});
//#endregion
export { Se as TreeViewNodeChildren, be as TreeViewRootNodes, ye as XamlTreeViewItem, xe as XamlTreeViewNode, y as default };

//# sourceMappingURL=TreeView.vue_vue_type_script_setup_true_lang.js.map