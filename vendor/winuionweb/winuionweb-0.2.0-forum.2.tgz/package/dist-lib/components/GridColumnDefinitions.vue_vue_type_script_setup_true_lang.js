import e from "./GridDefinitions.vue.js";
import { defineComponent as t } from "vue";
//#region src/components/GridColumnDefinitions.vue?vue&type=script&setup=true&lang.ts
var n = /*@__PURE__*/ t({
	__name: "GridColumnDefinitions",
	setup(t, { expose: n }) {
		n();
		let r = { GridDefinitions: e };
		return Object.defineProperty(r, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), r;
	}
});
//#endregion
export { n as default };

//# sourceMappingURL=GridColumnDefinitions.vue_vue_type_script_setup_true_lang.js.map