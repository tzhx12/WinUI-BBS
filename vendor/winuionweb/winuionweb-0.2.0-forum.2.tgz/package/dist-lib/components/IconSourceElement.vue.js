import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./IconSourceElement.vue_vue_type_script_setup_true_lang.js";
import { createElementBlock as n, createVNode as r, mergeProps as i, openBlock as a, withCtx as o } from "vue";
//#region src/components/IconSourceElement.vue
function s(e, t, s, c, l, u) {
	return a(), n("span", i({ ref: "Element" }, c.icon.rootAttrs.value, {
		class: ["win-icon-element win-icon-source-element", c.attrs.class],
		style: [c.attrs.style, c.icon.layoutStyle.value]
	}), [r(c.Grid, {
		Background: "Transparent",
		class: "win-icon-grid"
	}, {
		default: o(() => [r(c.IconOutlet)]),
		_: 1
	}), r(c.SourceOutlet)], 16);
}
var c = /*#__PURE__*/ e(t, [["render", s], ["__file", "IconSourceElement.vue"]]);
//#endregion
export { c as default };

//# sourceMappingURL=IconSourceElement.vue.js.map