//#region src/components/menuFlyoutContext.ts
var e = Symbol("WinUI.MenuFlyoutPresenter");
//#endregion
export { e as menuFlyoutPresenterContextKey };

//# sourceMappingURL=menuFlyoutContext.js.map