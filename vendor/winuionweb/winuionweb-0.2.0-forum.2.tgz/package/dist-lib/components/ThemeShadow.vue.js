import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./ThemeShadow.vue_vue_type_script_lang.js";
//#region src/components/ThemeShadow.vue
var n = /*#__PURE__*/ e(t, [["__file", "ThemeShadow.vue"]]);
//#endregion
export { n as default };

//# sourceMappingURL=ThemeShadow.vue.js.map