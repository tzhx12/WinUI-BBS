import { alignment as e, cssLength as t, xamlThickness as n } from "./layout.js";
import { useAcrylicBrushStyle as r } from "./AcrylicBrush.js";
import { eventNames as i, normalizeXamlNodes as a, resolveXamlHandler as o, resolveXamlValue as s, updateXamlBinding as ee, xamlScopeKey as te } from "./xamlRuntime.js";
import { brushProperty as ne, useBrushProperty as re } from "./brushProperties.js";
import { vAcrylicBrush as ie } from "./acrylicBrushVisual.js";
import { useI18n as ae } from "./i18n/index.js";
import { textCommandFlyout as oe } from "./textCommandFlyout.js";
import { xamlResourceDictionaryKey as se } from "./Page.vue_vue_type_script_lang.js";
import { getVNodeChildren as ce } from "./CollectionProperties.js";
import { isHoverPointer as le } from "./pointerInput.js";
import ue from "./ScrollViewer.vue.js";
import { textInputTemplateKey as de } from "./textInputTemplate.js";
import { scrollViewerTemplateBindings as fe } from "./scrollViewerTemplateBindings.js";
import pe from "./ContentPresenter.vue.js";
import { Fragment as c, cloneVNode as me, computed as l, defineComponent as u, getCurrentInstance as he, h as d, inject as ge, nextTick as f, onBeforeUnmount as _e, onMounted as ve, provide as ye, ref as p, useAttrs as be, useSlots as xe, watch as m } from "vue";
//#region src/components/TextBox.vue?vue&type=script&setup=true&lang.ts
var h = (e) => u({
	name: `TextBox.${e}`,
	__textInputProperty: e,
	setup: () => () => null
}), Se = h("Header"), Ce = h("HeaderTemplate"), we = h("Description"), Te = h("ContextFlyout"), Ee = h("SelectionFlyout"), De = /*@__PURE__*/ u({
	Background: ne("TextBox", "Background"),
	Header: Se,
	HeaderTemplate: Ce,
	Description: we,
	ContextFlyout: Te,
	SelectionFlyout: Ee,
	inheritAttrs: !1,
	__name: "TextBox",
	props: {
		Text: {},
		PlaceholderText: { default: "" },
		Header: { default: () => "" },
		HeaderTemplate: {},
		ContextFlyout: {},
		SelectionFlyout: {},
		Description: { default: "" },
		AcceptsReturn: {
			type: [Boolean, String],
			default: !1
		},
		IsReadOnly: {
			type: [Boolean, String],
			default: !1
		},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		ShowDeleteButton: {
			type: [Boolean, String],
			default: !0
		},
		MaxLength: { default: 0 },
		TextWrapping: { default: "NoWrap" },
		TextAlignment: { default: "Left" },
		IsSpellCheckEnabled: {
			type: [Boolean, String],
			default: !0
		},
		IsTextPredictionEnabled: {
			type: [Boolean, String],
			default: !0
		},
		InputScope: { default: "Default" },
		CharacterCasing: { default: "Normal" },
		SelectionHighlightColor: { default: "" },
		DesiredCandidateWindowAlignment: { default: "Default" },
		IsColorFontEnabled: {
			type: [Boolean, String],
			default: !0
		},
		PreventKeyboardDisplayOnProgrammaticFocus: {
			type: [Boolean, String],
			default: !1
		},
		FontFamily: { default: "" },
		FontSize: { default: "" },
		FontStyle: { default: "Normal" },
		FontWeight: { default: "" },
		Foreground: { default: "" },
		Background: { default: "" },
		BorderBrush: { default: "" },
		BorderThickness: { default: 1 },
		Padding: { default: "" },
		CornerRadius: { default: 4 },
		PlaceholderForeground: { default: "" },
		CharacterSpacing: { default: 0 },
		Width: { default: "" },
		Height: { default: "" },
		Margin: { default: "" },
		HorizontalAlignment: { default: "" },
		VerticalAlignment: { default: "" },
		MinWidth: { default: "" },
		MaxWidth: { default: "" },
		MinHeight: { default: "" },
		MaxHeight: { default: "" }
	},
	emits: [
		"update:Text",
		"BeforeTextChanging",
		"TextChanging",
		"TextChanged",
		"SelectionChanged",
		"SelectionChanging",
		"GotFocus",
		"LostFocus",
		"KeyDown",
		"Paste",
		"CuttingToClipboard",
		"CopyingToClipboard",
		"ContextMenuOpening",
		"CandidateWindowBoundsChanged",
		"TextCompositionStarted",
		"TextCompositionChanged",
		"TextCompositionEnded"
	],
	setup(ne, { expose: De, emit: Oe }) {
		let { t: g } = ae(), _ = he(), v = be(), ke = xe(), y = (e) => {
			let t = (n) => n.flatMap((n) => n.type === c ? t(ce(n)) : n.type?.__textInputProperty === e ? ce(n) : []);
			return a(t(ke.default?.() ?? []), _);
		}, Ae = l(() => y("Header")), je = ge(se, {}), Me = l(() => {
			let e = y("HeaderTemplate")[0];
			if (e) return e;
			let t = String(S.HeaderTemplate ?? "").match(/^\{(?:StaticResource|ThemeResource)\s+([^}]+)\}$/)?.[1];
			return t && je[t] ? je[t] : s(S.HeaderTemplate, _);
		}), Ne = l(() => y("Description")), Pe = u({ setup: () => () => Ae.value.length ? d(c, Ae.value) : d(pe, {
			Content: Be.value,
			ContentTemplate: Me.value
		}) }), Fe = u({ setup: () => () => d(c, Ne.value) }), b = ge(de, null), Ie = u({ setup: () => () => d(c, [b?.Field?.({
			Focused: ht,
			Blurred: X,
			PointerEntered: bt,
			PointerExited: xt
		})]) }), Le = u({ setup: () => () => d(c, [b?.Actions?.()]) }), Re = l(() => Object.fromEntries(Object.entries(v).filter(([e]) => !e.startsWith("ScrollViewer.") && !i.has(e) && !e.startsWith("AutomationProperties.")))), x = fe((e) => v[e], _, {
			HorizontalScrollMode: "Auto",
			VerticalScrollMode: "Auto",
			HorizontalScrollBarVisibility: "Hidden",
			VerticalScrollBarVisibility: "Hidden",
			IsDeferredScrollingEnabled: !1
		}), ze = ge(te, {});
		ye(te, Object.assign(Object.create(ze), {
			ScrollSettings: x,
			TextBoxScrollEnabled: l(() => !G.value)
		}));
		let S = ne, C = p({}), w = new Proxy(S, { get: (e, t) => typeof t == "string" && t in C.value ? C.value[t] : s(Reflect.get(e, t), _) }), Be = l(() => s(w.Header, _)), Ve = l(() => s(w.Description, _)), He = l(() => {
			let e = s(v["AutomationProperties.Name"], _) || Be.value;
			return e == null ? void 0 : String(e);
		}), Ue = l(() => {
			let e = s(w.Text, _);
			return e == null ? "" : String(e);
		}), We = Oe, T = (e, t) => {
			let n = _?.exposeProxy ?? _?.exposed ?? _?.proxy, r = t ?? {
				OriginalSource: D.value,
				Handled: !1
			}, i = _?.vnode.props?.[`on${e}`];
			if (i) for (let e of Array.isArray(i) ? i : [i]) typeof e == "function" && e(n, r);
			else We(e, n, r), o(v[e], _)?.(n, r);
		}, E = p(null), Ge = p(62), Ke = p(0), qe = l(() => Ge.value + 2 + (b?.ActionsWidth?.() ?? 0) + (b?.ReserveDeleteButtonWidth ?? 0));
		m(qe, (e) => b?.DesiredWidthChanged?.(e), { immediate: !0 });
		let D = p(null), O, k, A = p(!1), j = p(!1), M = !1, N, P = p(!1), Je = p(Ue.value), F = p([]), I = p([]), Ye = p(""), L = p(!1), R = p(null), Xe = p("Context"), z = p(null), B = p(null), Ze = u({ setup: () => () => d(c, ["ContextFlyout", "SelectionFlyout"].flatMap((e) => y(e).map((t) => me(t, { ref: (t) => {
			e === "ContextFlyout" ? z.value = t : B.value = t;
		} }, !0)))) }), V = 0, H = p(!1), Qe = p(null), U = p({
			start: 0,
			length: 0,
			text: ""
		}), W = l(() => Je.value), G = l(() => !w.IsEnabled), $e = re("Background", () => w.Background, () => ke.default?.() ?? [], _), et = r(() => G.value || A.value || P.value ? void 0 : $e.value.value, _), tt = l(() => W.value.length > 0), nt = l(() => !b?.HideDeleteButton && w.ShowDeleteButton && tt.value && !w.AcceptsReturn && !w.IsReadOnly && w.IsEnabled && A.value && Ke.value > (Number(w.FontSize) || 14) * 5), rt = l(() => {
			switch (w.InputScope) {
				case "Number":
				case "NumericPin":
				case "Digits": return "numeric";
				case "TelephoneNumber": return "tel";
				case "EmailNameOrAddress":
				case "EmailSmtpAddress": return "email";
				case "Url": return "url";
				case "Search": return "search";
				case "CurrencyAmount":
				case "CurrencyAmountAndSymbol":
				case "Decimal": return "decimal";
				default: return "text";
			}
		}), it = l(() => w.IsTextPredictionEnabled ? "on" : "off"), at = l(() => (w.TextAlignment || "Left").toLowerCase()), K = (e) => {
			if (!(e === void 0 || e === "")) return t(e);
		}, ot = l(() => {
			let t = {};
			w.Padding !== "" && (t["--textbox-padding"] = n(w.Padding)), t["--textbox-natural-width"] = `${Ge.value}px`, t["--textbox-radius"] = K(w.CornerRadius), t["--textbox-border-thickness"] = n(w.BorderThickness);
			let r = String(w.BorderThickness).split(",").map((e) => Number.parseFloat(e) || 0);
			t["--textbox-helper-margin-top"] = `${-(r[1] ?? r[0] ?? 1)}px`, t["--textbox-helper-margin-bottom"] = `${-(r[3] ?? r[1] ?? r[0] ?? 1)}px`, t["--textbox-helper-margin-right"] = `${-(r[2] ?? r[0] ?? 1)}px`, w.BorderBrush && (t["--textbox-border-top"] = w.BorderBrush, t["--textbox-border-bottom"] = w.BorderBrush), w.PlaceholderForeground && (t["--textbox-placeholder-foreground"] = w.PlaceholderForeground), w.SelectionHighlightColor && (t["--textbox-selection-background"] = w.SelectionHighlightColor), w.Width !== "" && (t.width = K(w.Width)), w.Height !== "" && (t.height = K(w.Height)), w.Margin !== "" && (t.margin = n(w.Margin)), w.HorizontalAlignment && (t.justifySelf = e(w.HorizontalAlignment, "horizontal")), w.VerticalAlignment && (t.alignSelf = e(w.VerticalAlignment, "vertical"));
			let i = K(w.MinWidth === "" ? 64 : w.MinWidth);
			return t.minWidth = i ? `min(max(${i}, ${qe.value}px), 100%)` : void 0, w.MaxWidth !== "" && (t.maxWidth = K(w.MaxWidth)), w.MinHeight !== "" && (t.minHeight = K(w.MinHeight)), w.MaxHeight !== "" && (t.maxHeight = K(w.MaxHeight)), t;
		}), st = l(() => {
			let e = { textAlign: at.value };
			return w.FontFamily && (e.fontFamily = w.FontFamily), w.FontSize !== "" && (e.fontSize = K(w.FontSize)), w.FontStyle && w.FontStyle !== "Normal" && (e.fontStyle = w.FontStyle.toLowerCase()), w.FontWeight !== "" && (e.fontWeight = {
				Normal: 400,
				SemiBold: 600,
				Bold: 700,
				Light: 300
			}[String(w.FontWeight)] ?? w.FontWeight), w.Foreground && (e.color = w.Foreground), w.CharacterSpacing && (e.letterSpacing = `${w.CharacterSpacing / 1e3}em`), w.AcceptsReturn && (e.whiteSpace = w.TextWrapping === "NoWrap" ? "pre" : "pre-wrap", e.overflowWrap = w.TextWrapping === "WrapWholeWords" ? "normal" : "break-word"), e;
		}), ct = l(() => F.value.length > 0), lt = l(() => I.value.length > 0), ut = l(() => {
			let e = [], t = U.value.length > 0, n = W.value.length > 0, r = !w.IsReadOnly && w.IsEnabled, i = r && Ye.value.length > 0;
			return t && (r && e.push({
				Text: g("text.cut"),
				Icon: "",
				Value: "cut"
			}), e.push({
				Text: g("text.copy"),
				Icon: "",
				Value: "copy"
			})), i && e.push({
				Text: g("text.paste"),
				Icon: "",
				Value: "paste"
			}), r && ct.value && e.push({
				Text: g("text.undo"),
				Icon: "",
				Value: "undo"
			}), r && lt.value && e.push({
				Text: g("text.redo"),
				Icon: "",
				Value: "redo"
			}), n && e.push({
				Text: g("text.select-all"),
				Icon: "",
				Value: "selectAll"
			}), e;
		}), dt = (e) => {
			F.value.at(-1) !== e && (F.value.push(e), I.value = []);
		}, q = (e, t, n = {}) => {
			let r = W.value;
			r !== e && (n.undo && dt(r), Je.value = e, T("TextChanging", { IsContentChanging: !0 }), We("update:Text", e), ee(S.Text, e, _), T("TextChanged"));
		}, J = () => {
			let e = D.value;
			if (!e) return;
			let t = e.closest(".win-scroll-viewer-viewport");
			if (!t || t.clientWidth === 0) return;
			let n = getComputedStyle(e), r = document.createElement("canvas").getContext("2d"), i = 0;
			r && (r.font = `${n.fontStyle} ${n.fontWeight} ${n.fontSize} ${n.fontFamily}`, i = e.value.split("\n").reduce((e, t) => Math.max(e, r.measureText(t).width), 0));
			let a = (parseFloat(n.paddingLeft) || 0) + (parseFloat(n.paddingRight) || 0);
			if (r) {
				let t = r.measureText(String(w.PlaceholderText ?? "")).width, o = (parseFloat(n.letterSpacing) || 0) * Math.max(0, (e.value || w.PlaceholderText || "").length - 1);
				Ge.value = Math.max(62, Math.ceil(Math.max(i, t) + o + a + 1));
			}
			let o = x.HorizontalScrollMode !== "Disabled" && x.HorizontalScrollBarVisibility !== "Disabled", s = w.AcceptsReturn && w.TextWrapping !== "NoWrap";
			e.style.width = `${s || !o ? t.clientWidth : Math.max(t.clientWidth, Math.ceil(i + a + 1))}px`, e instanceof HTMLTextAreaElement && (e.style.height = "auto", e.style.height = `${e.scrollHeight}px`), e.scrollLeft = 0, e.scrollTop = 0;
		}, ft = () => {
			let e = D.value;
			if (!e || document.activeElement !== e) return;
			let t = e.closest(".win-scroll-viewer-viewport");
			if (!t) return;
			let n = Gt((e.selectionDirection === "backward" ? e.selectionStart : e.selectionEnd) ?? 0), r = t.getBoundingClientRect(), i = getComputedStyle(e), a = parseFloat(i.paddingLeft) || 0, o = parseFloat(i.paddingTop) || 0;
			x.HorizontalScrollMode !== "Disabled" && x.HorizontalScrollBarVisibility !== "Disabled" && (n.x < r.left + a ? t.scrollLeft += n.x - r.left - a : n.x + n.width > r.right - 6 && (t.scrollLeft += n.x + n.width - r.right + 6)), x.VerticalScrollMode !== "Disabled" && x.VerticalScrollBarVisibility !== "Disabled" && (n.y < r.top + o ? t.scrollTop += n.y - r.top - o : n.y + n.height > r.bottom - 6 && (t.scrollTop += n.y + n.height - r.bottom + 6));
		}, Y = () => {
			k !== void 0 && cancelAnimationFrame(k), k = requestAnimationFrame(() => {
				k = void 0, J(), ft();
			});
		};
		m(Ue, (e) => {
			if (j.value) {
				N = e;
				return;
			}
			Je.value !== e && q(e, "ProgrammaticChange"), f(J);
		}), m(S, () => {
			C.value = {};
		}), m(G, (e) => {
			e && (P.value = !1, A.value = !1, R.value?.Hide?.(), D.value?.blur());
		}), m(() => [
			w.AcceptsReturn,
			w.TextWrapping,
			w.FontFamily,
			w.FontSize,
			w.FontWeight,
			w.CharacterSpacing
		], () => void f(J));
		let pt = (e) => {
			let t = e;
			return w.CharacterCasing === "Upper" && (t = t.toUpperCase()), w.CharacterCasing === "Lower" && (t = t.toLowerCase()), w.MaxLength > 0 && t.length > w.MaxLength && (t = t.slice(0, w.MaxLength)), t;
		}, mt = (e) => {
			if (j.value || e.isComposing) return;
			let t = e.target, n = pt(t.value), r = {
				NewText: n,
				Cancel: !1
			};
			if (T("BeforeTextChanging", r), r.Cancel) {
				t.value = W.value;
				return;
			}
			t.value !== n && (t.value = n), q(n, "UserInput", { undo: !0 }), J(), Y();
		}, ht = () => {
			A.value = !0, Z(), T("GotFocus"), J(), Y();
		}, X = () => {
			L.value || H.value || A.value && (A.value = !1, Z("Default"), T("LostFocus"));
		}, gt = () => {
			let e = D.value;
			e && e.style.setProperty("-ms-ime-align", w.DesiredCandidateWindowAlignment === "BottomEdge" ? "after" : "auto");
		}, Z = (e = w.DesiredCandidateWindowAlignment) => {
			gt();
			let t = D.value;
			if (!t) return;
			let n = (t.closest(".win-textbox-border") ?? t).getBoundingClientRect(), r = {
				x: n.x,
				y: n.y,
				top: n.top,
				bottom: n.bottom,
				left: n.left,
				right: n.right,
				width: n.width,
				height: n.height
			};
			window.chrome?.webview?.postMessage?.({
				source: "WinUIonWeb",
				type: "desiredCandidateWindowAlignmentChanged",
				DesiredCandidateWindowAlignment: e,
				TextEditControlBounds: r,
				devicePixelRatio: window.devicePixelRatio,
				visualViewport: window.visualViewport ? {
					offsetLeft: window.visualViewport.offsetLeft,
					offsetTop: window.visualViewport.offsetTop,
					scale: window.visualViewport.scale
				} : null
			});
		}, _t = () => {
			j.value = !0, N = void 0, Mt(), Z(), T("TextCompositionStarted");
		}, vt = () => {
			Z(), T("TextCompositionChanged");
		}, yt = () => {
			j.value = !1;
			let e = N;
			N = void 0, D.value && mt({ target: D.value }), e !== void 0 && e !== W.value && q(e, "ProgrammaticChange"), T("TextCompositionEnded");
		};
		m(() => w.DesiredCandidateWindowAlignment, () => {
			f(() => {
				gt(), A.value && Z();
			});
		});
		let bt = (e) => {
			P.value = le(e);
		}, xt = () => {
			P.value = !1;
		}, St = (e) => {
			let t = j.value || e.isComposing || e.keyCode === 229;
			t || b?.KeyDown?.(e);
			let n = {
				Key: e.key,
				OriginalSource: D.value,
				Handled: e.defaultPrevented
			};
			if (T("KeyDown", n), n.Handled) {
				e.preventDefault();
				return;
			}
			if (t) {
				M = !0, e.stopPropagation();
				return;
			}
			M = !1, (e.ctrlKey || e.metaKey) && !w.IsReadOnly && (e.key.toLowerCase() === "z" && (e.preventDefault(), e.shiftKey ? Yt() : Jt()), e.key.toLowerCase() === "y" && (e.preventDefault(), Yt())), e.key === "Enter" && !w.AcceptsReturn && e.preventDefault(), Y();
		}, Ct = (e) => {
			(j.value || e.isComposing || e.keyCode === 229 || M) && (M = !1, e.stopPropagation());
		}, Q = () => {
			let e = D.value;
			if (!e) return {
				start: 0,
				length: 0,
				text: ""
			};
			let t = e.selectionStart ?? 0, n = e.selectionEnd ?? 0, r = Math.min(t, n), i = Math.max(t, n);
			return {
				start: r,
				length: i - r,
				text: e.value.substring(r, i)
			};
		}, $ = p({
			start: 0,
			length: 0,
			text: ""
		}), wt = !1, Tt = () => {
			if (wt || j.value) return;
			let e = Q();
			if (e.start === $.value.start && e.length === $.value.length) return;
			let t = {
				SelectionStart: e.start,
				SelectionLength: e.length,
				Cancel: !1
			};
			if (T("SelectionChanging", t), t.Cancel) {
				wt = !0, D.value?.setSelectionRange($.value.start, $.value.start + $.value.length), queueMicrotask(() => {
					wt = !1;
				});
				return;
			}
			$.value = e, T("SelectionChanged"), Y();
		}, Et = (e) => {
			let t = { Handled: !1 };
			T("CuttingToClipboard", t), t.Handled && e.preventDefault();
		}, Dt = (e) => {
			let t = { Handled: !1 };
			T("CopyingToClipboard", t), t.Handled && e.preventDefault();
		}, Ot = (e) => {
			let t = { Handled: !1 };
			T("Paste", t), t.Handled && e.preventDefault();
		}, kt = async () => {
			try {
				return await navigator.clipboard?.readText() ?? "";
			} catch {
				return "";
			}
		}, At = async (e) => {
			if (e.preventDefault(), G.value) return;
			let t = {
				Handled: !1,
				CursorLeft: e.offsetX,
				CursorTop: e.offsetY
			};
			if (T("ContextMenuOpening", t), t.Handled || w.ContextFlyout === null) return;
			D.value?.focus({ preventScroll: !0 }), Xe.value = "Context";
			let n = z.value ?? w.ContextFlyout;
			if (n?.ShowAt && D.value) {
				let t = D.value.getBoundingClientRect();
				n.ShowAt(D.value, { Position: {
					X: e.clientX - t.left,
					Y: e.clientY - t.top
				} });
				return;
			}
			let r = ++V;
			if (L.value = !1, U.value = Q(), Ye.value = await kt(), r !== V || !D.value?.isConnected || G.value || document.activeElement !== D.value || !ut.value.length) return;
			let i = e.clientX, a = e.clientY;
			Qe.value = {
				x: i,
				y: a,
				top: a,
				bottom: a,
				left: i,
				right: i,
				width: 0,
				height: 0
			}, H.value = !0, L.value = !0, await f();
			let o = D.value;
			o && R.value?.ShowAt?.(o, { Position: {
				X: e.clientX - o.getBoundingClientRect().left,
				Y: e.clientY - o.getBoundingClientRect().top
			} });
		}, jt = async (e) => {
			if (e.button !== 0 || !["touch", "pen"].includes(e.pointerType) || j.value || G.value || w.SelectionFlyout === null || (U.value = Q(), !U.value.length || !D.value)) return;
			Xe.value = "Selection";
			let t = B.value ?? w.SelectionFlyout;
			if (t?.ShowAt) {
				t.ShowAt(D.value, { ShowMode: "Transient" });
				return;
			}
			let n = ++V, r = { ...U.value };
			Ye.value = await kt(), await f();
			let i = Q();
			n !== V || !D.value?.isConnected || document.activeElement !== D.value || i.start !== r.start || i.length !== r.length || (L.value = !0, R.value?.ShowAt?.(D.value, {
				ShowMode: "Transient",
				Placement: "TopEdgeAlignedLeft"
			}));
		}, Mt = () => {
			V++, L.value = !1, H.value = !1, R.value?.Hide?.(!1), z.value?.Hide?.(!1), B.value?.Hide?.(!1);
		}, Nt = (e) => e instanceof Element && !!e.closest(".win-commandbar-flyout,.win-menu-flyout,.win-flyout"), Pt = (e) => !(e instanceof Element) || !E.value ? !1 : e.closest(".win-number-compact-popup") && E.value.closest(".win-number-box")?.contains(document.activeElement) ? !0 : !!e.closest(".win-asb-popup") && !!E.value.closest(".win-auto-suggest-box")?.contains(document.activeElement), Ft = (e) => {
			let t = e.target;
			if (!(!E.value || !t)) {
				if (E.value.contains(t)) {
					e.button === 0 && t === D.value && Mt();
					return;
				}
				Nt(e.target) || Pt(e.target) || (Mt(), D.value?.blur(), A.value && X());
			}
		}, It = (e) => {
			!E.value?.contains(e.target) && !Nt(e.target) && !Pt(e.target) && (Mt(), A.value && X());
		}, Lt = () => {
			q("", "ProgrammaticChange", { undo: !0 }), requestAnimationFrame(() => {
				D.value?.focus(), J();
			});
		}, Rt = () => {
			V++, L.value = !1, R.value?.Hide?.(), f(() => {
				Ht(), requestAnimationFrame(() => {
					H.value = !1;
				});
			});
		}, zt = () => {
			L.value = !1, H.value = !1, document.activeElement !== D.value && X();
		}, Bt = (e) => {
			if (!e.Value) return;
			let t = e.Value;
			Rt(), t === "cut" && en(), t === "copy" && $t(), t === "paste" && Qt(), t === "undo" && Jt(), t === "redo" && Yt(), t === "selectAll" && Ut();
		}, Vt = oe(R, () => ut.value, Bt, zt, () => ({ ShowMode: Xe.value === "Selection" ? "Transient" : "Standard" })), Ht = (e = {}) => {
			D.value?.focus({ preventScroll: w.PreventKeyboardDisplayOnProgrammaticFocus || e.preventScroll });
		}, Ut = () => {
			D.value?.select(), Tt();
		}, Wt = (e, t) => {
			let n = D.value;
			if (!n) return;
			let r = Math.max(0, Math.min(e, n.value.length)), i = Math.max(r, Math.min(r + t, n.value.length));
			n.setSelectionRange(r, i), Tt();
		}, Gt = (e, t = !1) => {
			let n = D.value;
			if (!n || typeof document > "u") return {
				x: 0,
				y: 0,
				width: 0,
				height: 0
			};
			let r = n.getBoundingClientRect(), i = getComputedStyle(n), a = Math.max(0, Math.min(e, n.value.length)), o = parseFloat(i.lineHeight) || 20, s = document.createElement("div");
			for (let e of [
				"fontFamily",
				"fontSize",
				"fontStyle",
				"fontWeight",
				"lineHeight",
				"letterSpacing",
				"textAlign",
				"overflowWrap",
				"wordBreak",
				"paddingTop",
				"paddingRight",
				"paddingBottom",
				"paddingLeft",
				"boxSizing"
			]) s.style[e] = i[e];
			Object.assign(s.style, {
				position: "fixed",
				visibility: "hidden",
				pointerEvents: "none",
				top: "0",
				left: "0",
				width: `${n.clientWidth}px`,
				whiteSpace: w.AcceptsReturn && w.TextWrapping !== "NoWrap" ? "pre-wrap" : "pre"
			}), s.textContent = n.value.slice(0, a);
			let ee = document.createElement("span");
			ee.textContent = "​", s.append(ee), document.body.append(s);
			let te = ee.getBoundingClientRect(), ne = {
				x: r.left + te.left - n.scrollLeft + +!!t,
				y: r.top + te.top - n.scrollTop,
				width: 1,
				height: o
			};
			return s.remove(), ne;
		}, Kt = (e) => {
			if (!D.value) return;
			let t = Q();
			qt(t.start, t.length, e);
		}, qt = (e, t, n) => {
			let r = D.value;
			if (!r || w.IsReadOnly || G.value) return;
			let i = Math.max(0, Math.min(e, r.value.length)), a = Math.max(0, Math.min(t, r.value.length - i)), o = pt(r.value.slice(0, i) + n + r.value.slice(i + a)), s = {
				NewText: o,
				Cancel: !1
			};
			T("BeforeTextChanging", s), !s.Cancel && (r.value = o, q(o, "ProgrammaticChange", { undo: !0 }), requestAnimationFrame(J));
		}, Jt = () => {
			if (w.IsReadOnly || G.value || !F.value.length) return;
			let e = F.value.pop() ?? "";
			I.value.push(W.value), q(e, "ProgrammaticChange"), requestAnimationFrame(J);
		}, Yt = () => {
			if (w.IsReadOnly || G.value || !I.value.length) return;
			let e = I.value.pop() ?? "";
			F.value.push(W.value), q(e, "ProgrammaticChange"), requestAnimationFrame(J);
		}, Xt = () => {
			let e = Q();
			e.text && navigator.clipboard?.writeText(e.text);
		}, Zt = () => {
			let e = Q();
			e.text && (navigator.clipboard?.writeText(e.text), Kt(""));
		}, Qt = async () => {
			let e = { Handled: !1 };
			if (T("Paste", e), e.Handled || w.IsReadOnly || G.value) return;
			let t = await kt();
			t !== void 0 && Kt(t);
		}, $t = () => {
			let e = { Handled: !1 };
			T("CopyingToClipboard", e), !e.Handled && U.value.text && navigator.clipboard?.writeText(U.value.text);
		}, en = () => {
			let e = { Handled: !1 };
			T("CuttingToClipboard", e), !(e.Handled || w.IsReadOnly || G.value) && U.value.text && (navigator.clipboard?.writeText(U.value.text), qt(U.value.start, U.value.length, ""));
		};
		ve(() => {
			document.addEventListener("pointerdown", Ft, !0), document.addEventListener("focusin", It, !0), gt(), f(() => {
				J();
				let e = D.value?.closest(".win-scroll-viewer-viewport");
				O = new ResizeObserver(() => {
					Ke.value = E.value?.querySelector(".win-textbox-border")?.getBoundingClientRect().width ?? 0, J();
				}), E.value && O.observe(E.value), e && O.observe(e);
			});
		}), _e(() => {
			document.removeEventListener("pointerdown", Ft, !0), document.removeEventListener("focusin", It, !0), V++, O?.disconnect(), k !== void 0 && cancelAnimationFrame(k), A.value && Z("Default"), F.value = [], I.value = [], L.value = !1, H.value = !1;
		}), De({
			get Element() {
				return D.value;
			},
			get IsEnabled() {
				return w.IsEnabled;
			},
			set IsEnabled(e) {
				C.value.IsEnabled = e;
			},
			get IsReadOnly() {
				return w.IsReadOnly;
			},
			set IsReadOnly(e) {
				C.value.IsReadOnly = e;
			},
			get AcceptsReturn() {
				return w.AcceptsReturn;
			},
			set AcceptsReturn(e) {
				C.value.AcceptsReturn = e;
			},
			get TextWrapping() {
				return w.TextWrapping;
			},
			set TextWrapping(e) {
				C.value.TextWrapping = e;
			},
			get Text() {
				return W.value;
			},
			set Text(e) {
				let t = e == null ? "" : String(e);
				t !== W.value && (q(t, "ProgrammaticChange"), f(J));
			},
			Focus: Ht,
			get ContextFlyout() {
				return w.ContextFlyout === void 0 ? z.value ?? R.value : w.ContextFlyout;
			},
			set ContextFlyout(e) {
				C.value.ContextFlyout = e;
			},
			get SelectionFlyout() {
				return w.SelectionFlyout === void 0 ? B.value ?? R.value : w.SelectionFlyout;
			},
			set SelectionFlyout(e) {
				C.value.SelectionFlyout = e;
			},
			SelectAll: Ut,
			Select: Wt,
			GetRectFromCharacterIndex: Gt,
			Undo: Jt,
			Redo: Yt,
			CopySelectionToClipboard: Xt,
			CutSelectionToClipboard: Zt,
			PasteFromClipboard: Qt,
			get CanUndo() {
				return ct.value;
			},
			get CanRedo() {
				return lt.value;
			},
			get SelectedText() {
				return Q().text;
			},
			set SelectedText(e) {
				Kt(e);
			},
			get SelectionStart() {
				return Q().start;
			},
			set SelectionStart(e) {
				Wt(e, Q().length);
			},
			get SelectionLength() {
				return Q().length;
			},
			set SelectionLength(e) {
				Wt(Q().start, e);
			}
		});
		let tn = {
			textBoxProperty: h,
			TextBoxHeader: Se,
			TextBoxHeaderTemplate: Ce,
			TextBoxDescription: we,
			TextBoxContextFlyout: Te,
			TextBoxSelectionFlyout: Ee,
			t: g,
			instance: _,
			attrs: v,
			slots: ke,
			propertyNodes: y,
			headerNodes: Ae,
			resources: je,
			headerTemplate: Me,
			descriptionNodes: Ne,
			HeaderOutlet: Pe,
			DescriptionOutlet: Fe,
			inputTemplate: b,
			FieldOutlet: Ie,
			ActionsOutlet: Le,
			forwardedAttrs: Re,
			ScrollSettings: x,
			inheritedScrollTemplateScope: ze,
			rawProps: S,
			propertyOverrides: C,
			props: w,
			resolvedHeader: Be,
			resolvedDescription: Ve,
			automationName: He,
			resolvedText: Ue,
			emit: We,
			dispatch: T,
			rootRef: E,
			naturalFieldWidth: Ge,
			surfaceWidth: Ke,
			naturalControlWidth: qe,
			fieldRef: D,
			get editorResizeObserver() {
				return O;
			},
			set editorResizeObserver(e) {
				O = e;
			},
			get caretFrame() {
				return k;
			},
			set caretFrame(e) {
				k = e;
			},
			isFocused: A,
			isComposing: j,
			get compositionKeyUpPending() {
				return M;
			},
			set compositionKeyUpPending(e) {
				M = e;
			},
			get pendingCompositionText() {
				return N;
			},
			set pendingCompositionText(e) {
				N = e;
			},
			isHovered: P,
			localText: Je,
			undoStack: F,
			redoStack: I,
			clipboardText: Ye,
			contextMenuOpen: L,
			contextMenuRef: R,
			flyoutKind: Xe,
			customContextFlyout: z,
			customSelectionFlyout: B,
			CustomFlyouts: Ze,
			get contextRequest() {
				return V;
			},
			set contextRequest(e) {
				V = e;
			},
			isRestoringContextMenuFocus: H,
			contextMenuAnchor: Qe,
			contextSelection: U,
			currentText: W,
			isDisabled: G,
			backgroundBrush: $e,
			backgroundStyle: et,
			hasText: tt,
			showDeleteButton: nt,
			inputMode: rt,
			textPredictionAttr: it,
			resolvedTextAlign: at,
			cssSize: K,
			rootStyle: ot,
			fieldStyle: st,
			canUndo: ct,
			canRedo: lt,
			contextMenuItems: ut,
			pushUndo: dt,
			emitTextValue: q,
			resizeTextarea: J,
			scrollCaretIntoView: ft,
			scheduleCaretIntoView: Y,
			normalizeInput: pt,
			onInput: mt,
			onFocus: ht,
			onBlur: X,
			applyLegacyCandidateWindowAlignment: gt,
			requestCandidateWindowAlignment: Z,
			onCompositionStart: _t,
			onCompositionChanged: vt,
			onCompositionEnd: yt,
			onPointerEnter: bt,
			onPointerLeave: xt,
			onKeydown: St,
			onKeyup: Ct,
			readSelection: Q,
			lastSelection: $,
			get restoringSelection() {
				return wt;
			},
			set restoringSelection(e) {
				wt = e;
			},
			onSelect: Tt,
			onCuttingToClipboard: Et,
			onCopyingToClipboard: Dt,
			onPaste: Ot,
			readClipboardText: kt,
			onContextMenu: At,
			onSelectionPointerUp: jt,
			dismissTextMenus: Mt,
			isMenuTarget: Nt,
			isOwnedPopupTarget: Pt,
			onDocumentPointerDown: Ft,
			onDocumentFocusIn: It,
			clearText: Lt,
			closeContextMenu: Rt,
			onContextMenuClosed: zt,
			onContextMenuSelect: Bt,
			ContextMenu: Vt,
			focus: Ht,
			selectAll: Ut,
			select: Wt,
			getRectFromCharacterIndex: Gt,
			replaceSelectedText: Kt,
			replaceTextRange: qt,
			undo: Jt,
			redo: Yt,
			copySelectionToClipboard: Xt,
			cutSelectionToClipboard: Zt,
			pasteFromClipboard: Qt,
			copyContextSelectionToClipboard: $t,
			cutContextSelectionToClipboard: en,
			ScrollViewer: ue,
			get vAcrylicBrush() {
				return ie;
			}
		};
		return Object.defineProperty(tn, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), tn;
	}
});
//#endregion
export { Te as TextBoxContextFlyout, we as TextBoxDescription, Se as TextBoxHeader, Ce as TextBoxHeaderTemplate, Ee as TextBoxSelectionFlyout, De as default };

//# sourceMappingURL=TextBox.vue_vue_type_script_setup_true_lang.js.map