import { primitiveResourceScope as e, xamlPrimitiveResourceKey as t } from "./xamlPrimitives.js";
import { uiSettings as n } from "./uiSettings.js";
import { normalizeXamlNodes as r, resolveXamlHandler as i, resolveXamlValue as a, updateXamlBinding as o, xamlScopeKey as ee } from "./xamlRuntime.js";
import te from "./Grid.vue.js";
import ne from "./Viewbox.vue.js";
import { useI18n as re } from "./i18n/index.js";
import ie from "./TextBlock.vue.js";
import ae from "./FontIcon.vue.js";
import { animatedIconVisualSourceComponents as oe } from "./animatedIconVisuals.js";
import se from "./AnimatedIcon.vue.js";
import ce from "./ContentPresenter.vue.js";
import le from "./Button.vue.js";
import ue from "./ColumnDefinition.vue.js";
import { FontIconSource as de } from "./IconSource.js";
import fe from "./IconSourceElement.vue.js";
import { titleBarBrushAliases as pe, titleBarHighContrastBrushAliases as me, titleBarResources as he } from "./titleBarResources.js";
import { IsDragRegionProperty as ge, findTitleBarInteractableElements as _e, getIsDragRegion as ve, setIsDragRegion as s } from "./TitleBarDragRegion.js";
import { connectTitleBarWindowHost as ye, createFrameworkTitleBarWindowHost as be, getTitleBarHostPadding as xe, titleBarHostAdapterKey as Se } from "./titleBarHostAdapter.js";
import { TitleBarContent as Ce, TitleBarIconSource as we, TitleBarLeftHeader as Te, TitleBarResources as Ee, TitleBarRightHeader as De } from "./TitleBarProperties.js";
import { Comment as Oe, Fragment as ke, Text as Ae, cloneVNode as je, computed as c, defineComponent as Me, getCurrentInstance as Ne, h as l, inject as Pe, isVNode as Fe, nextTick as u, onBeforeUnmount as Ie, onMounted as Le, provide as Re, proxyRefs as ze, ref as d, shallowRef as Be, useAttrs as Ve, useSlots as He, watch as f } from "vue";
var Ue = /*@__PURE__*/ Me({
	components: {
		"animatedvisuals:AnimatedBackVisualSource": oe.AnimatedBackVisualSource,
		"animatedvisuals:AnimatedGlobalNavigationButtonVisualSource": oe.AnimatedGlobalNavigationButtonVisualSource
	},
	IconSource: we,
	LeftHeader: Te,
	Content: Ce,
	RightHeader: De,
	Resources: Ee,
	GetIsDragRegion: ve,
	SetIsDragRegion: s,
	IsDragRegionProperty: ge,
	inheritAttrs: !1,
	__name: "TitleBar",
	props: {
		Title: {
			type: String,
			default: ""
		},
		Subtitle: {
			type: String,
			default: ""
		},
		IconSource: {
			type: [String, Object],
			default: null
		},
		IsBackButtonVisible: {
			type: [Boolean, String],
			default: !1
		},
		IsBackButtonEnabled: {
			type: [Boolean, String],
			default: !0
		},
		IsPaneToggleButtonVisible: {
			type: [Boolean, String],
			default: !1
		},
		IsPaneOpen: {
			type: [Boolean, String],
			default: !0
		},
		IsCaptionButtonsVisible: {
			type: [Boolean, String],
			default: !1
		},
		CaptionButtonsFramework: {
			type: String,
			default: ""
		},
		LeftHeader: {
			type: null,
			default: null
		},
		Content: {
			type: null,
			default: null
		},
		RightHeader: {
			type: null,
			default: null
		},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		FlowDirection: {
			type: String,
			default: "LeftToRight"
		},
		Visibility: {
			type: String,
			default: "Visible"
		},
		AutoRefreshDragRegions: {
			type: [Boolean, String],
			default: !1
		},
		PreferredHeightOption: {
			type: String,
			default: "Standard"
		},
		Background: {
			type: String,
			default: ""
		},
		Foreground: {
			type: String,
			default: ""
		},
		Width: {
			type: [String, Number],
			default: ""
		},
		Height: {
			type: [String, Number],
			default: ""
		},
		MinWidth: {
			type: [String, Number],
			default: ""
		},
		MinHeight: {
			type: [String, Number],
			default: ""
		},
		MaxWidth: {
			type: [String, Number],
			default: ""
		},
		MaxHeight: {
			type: [String, Number],
			default: ""
		},
		Margin: {
			type: [String, Number],
			default: ""
		},
		HorizontalAlignment: {
			type: String,
			default: ""
		},
		VerticalAlignment: {
			type: String,
			default: ""
		}
	},
	emits: [
		"BackRequested",
		"PaneToggleRequested",
		"LayoutUpdated",
		"CaptionButtonRequested",
		"MinimizeRequested",
		"MaximizeRequested",
		"CloseRequested"
	],
	setup(oe, { expose: ge, emit: ve }) {
		let { t: s } = re(), Ce = He(), we = Pe(Se, null), Te = d(!1), Ee = c(() => Te.value || n.IsHighContrast), De = c(() => Ee.value ? me : pe), Ue = {
			SystemControlForegroundBaseHighBrush: "CanvasText",
			SystemControlHighlightAltBaseHighBrush: "HighlightText",
			SystemControlDisabledBaseMediumLowBrush: "GrayText",
			SystemControlBackgroundBaseLowBrush: "Canvas",
			SystemControlHighlightListLowBrush: "Highlight",
			SystemControlHighlightListMediumBrush: "Highlight"
		}, We = oe, p = ve, m = Ne(), h = Ve(), g = Be({}), _ = new Proxy(We, { get: (e, t) => a(t in g.value ? g.value[t] : Reflect.get(e, t), m) }), Ge = c(() => Object.fromEntries(Object.entries(h).filter(([e]) => ![
			"BackRequested",
			"PaneToggleRequested",
			"LayoutUpdated",
			"CaptionButtonRequested",
			"MinimizeRequested",
			"MaximizeRequested",
			"CloseRequested"
		].includes(e)))), Ke = c(() => Je(Ce.default?.() ?? [])), qe = (e) => Array.isArray(e.children) ? e.children : e.children?.default?.() ?? [], Je = (e) => e.flatMap((e) => e.type === ke ? Je(qe(e)) : e.type === Oe || e.type === Ae && !String(e.children ?? "").trim() ? [] : [e]), Ye = (e) => e.type?.__titleBarProperty, v = (e) => Ke.value.filter((t) => Ye(t) === e).flatMap(qe), Xe = () => Ke.value.filter((e) => !Ye(e)), Ze = Pe(t, null), Qe = e(() => Ke.value.filter((e) => Ye(e) === "Resources"), Ze), $e = c(() => ({
			...he,
			...Qe.value
		}));
		Re(t, $e);
		let y = (e) => {
			if ($e.value[e] !== void 0) return $e.value[e];
			let t = De.value[e] ?? e, n = a(`{ThemeResource ${t}}`, m);
			return Ee.value && n === `var(--${t})` ? Ue[t] ?? n : n;
		}, et = c(() => _.IconSource), tt = c(() => _.FlowDirection), nt = c(() => _.IsEnabled !== !1), rt = (e) => e in g.value ? _[e] !== null : v(e).length > 0 || _[e] !== null, it = c(() => rt("IconSource")), at = c(() => rt("LeftHeader")), ot = c(() => rt("RightHeader")), st = Me({ setup: () => () => l(fe, {
			ref: Mt,
			IconSource: _.IconSource
		}, { default: () => _.IconSource || "IconSource" in g.value ? [] : r(v("IconSource"), m) }) }), ct = Me({
			props: { element: {
				type: Object,
				required: !0
			} },
			setup(e) {
				let t = d(null), n, r = null, i = null, a = () => {
					n && n.parentNode === t.value && (r ? r.insertBefore(n, i?.parentNode === r ? i : null) : n.remove()), n = void 0, r = i = null;
				}, o = () => {
					let o = e.element;
					!t.value || o === n || (a(), n = o, r = o.parentNode, i = o.nextSibling, t.value.appendChild(o));
				};
				return Le(o), f(() => e.element, o, { flush: "post" }), Ie(a), () => l("span", {
					ref: t,
					style: { display: "contents" }
				});
			}
		}), lt = (e) => Me({ setup: () => () => {
			let t = e in g.value ? [] : e === "Content" ? v("Content").length ? v("Content") : Xe() : v(e);
			if (t.length) return l(ke, r(t.map((e) => je(e)), m));
			let n = _[e], i = n, a = i?.nodeType === 1 ? i : i?.Element ?? i?.$el;
			return a?.nodeType === 1 ? l(ct, { element: a }) : Fe(n) ? l(ke, r([n], m)) : typeof n == "string" || typeof n == "number" ? String(n) : null;
		} }), ut = lt("LeftHeader"), dt = lt("RightHeader"), ft = lt("Content"), pt = c(() => !it.value && !at.value ? 0 : y(gt.value === vt.value ? "TitleBarLeftHeaderPaddingWidth" : "TitleBarHeaderNegativeInsetPaddingWidth")), mt = c(() => _.Title), ht = c(() => _.Subtitle), gt = c(() => _.IsBackButtonVisible === !0), _t = c(() => _.IsBackButtonEnabled === !0), vt = c(() => _.IsPaneToggleButtonVisible === !0), yt = c(() => _.IsCaptionButtonsVisible === !0 || typeof _.IsCaptionButtonsVisible == "string" && _.IsCaptionButtonsVisible.toLowerCase() === "true"), bt = c(() => {
			if (!yt.value) return null;
			let e = _.CaptionButtonsFramework;
			return e === "Tauri" || e === "Electron" ? e : null;
		}), xt = c(() => _.IsPaneOpen !== !1), St = c(() => nt.value && _t.value), Ct = c(() => s("text.back")), wt = c(() => s(xt.value ? "text.close-navigation" : "text.open-navigation")), Tt = c(() => y("TitleBarContentHorizontalAlignment")), Et = c(() => S.value ? "Stretch" : y("TitleBarContentVerticalAlignment")), Dt = c(() => S.value ? y("TitleBarCompactContentMargin") : 0), Ot = () => {
			!nt.value || !_t.value || !gt.value || (p("BackRequested", $, null), m?.vnode.props?.onBackRequested || i(h.BackRequested, m)?.($, null));
		}, kt = () => {
			!nt.value || !vt.value || (p("PaneToggleRequested", $, null), m?.vnode.props?.onPaneToggleRequested || i(h.PaneToggleRequested, m)?.($, null));
		};
		Re(ee, {
			...Pe(ee, {}),
			Title: mt,
			Subtitle: ht,
			IconSource: et,
			HeaderInset: pt,
			IsEnabled: nt,
			IsPaneOpen: xt,
			BackButtonEnabled: St,
			BackLabel: Ct,
			PaneLabel: wt,
			ContentAlignment: Tt,
			ContentVerticalAlignment: Et,
			ContentMargin: Dt,
			requestBack: Ot,
			requestPaneToggle: kt
		});
		let At = (e) => {
			let t = (e) => {
				if (e && typeof e == "object" && e.nodeType === 1) return e;
				if (!e || typeof e != "object") return null;
				let n = e;
				return t(n.Element) ?? t(n.$el);
			};
			return t(e);
		}, b = d(null), jt = (e) => {
			b.value = At(e);
		}, Mt = d(null), x = d(null), Nt = (e) => {
			x.value = At(e);
		}, Pt = d(!1), S = d(!1), C = d(!1), w = d(null), T = yt, Ft = d(!1), It = d(!1), E = d({
			Button: null,
			State: "normal"
		}), Lt = d({
			Button: null,
			State: "normal"
		}), Rt = d(null), zt = d(null), Bt = d(null), Vt = d(null), Ht = d(null), Ut = d(!1), Wt = Be({}), Gt = c(() => E.value.State === "normal" ? Lt.value : E.value), Kt = c(() => Gt.value.State === "pointerOver" ? Gt.value.Button : null), qt = c(() => ({
			minimize: s("text.minimize"),
			maximize: It.value ? s("text.restore") : s("text.maximize"),
			close: s("text.close")
		})), Jt = () => {
			let e = b.value;
			if (!Ut.value || !e || !R) return;
			let t = e.getBoundingClientRect(), n = {
				left: `${t.right - 138}px`,
				top: `${t.top}px`,
				height: `${t.height}px`
			}, r = R.getComputedStyle(e);
			for (let e of [
				"--TitleBarCaptionButtonForeground",
				"--TitleBarCaptionButtonPressedForeground",
				"--TitleBarCaptionButtonInactiveForeground",
				"--SubtleFillColorSecondaryBrush",
				"--SubtleFillColorTertiaryBrush",
				"--subtle-secondary",
				"--subtle-tertiary"
			]) {
				let t = r.getPropertyValue(e).trim();
				t && (n[e] = t);
			}
			Wt.value = n;
		}, Yt = d(0), Xt = "", D = "", O = null, k = null, A = null, j = null, Zt, Qt = [], M = null, N = 0, P = 0, F = -1, I = -1, L = -1, R = null, z = null, B = null, $t, V, H, U, en, W, tn = 0, G = 0, K, q, nn = () => {
			Te.value = !!q?.matches;
		}, J = !1, rn = c(() => "Content" in g.value ? _.Content !== null : v("Content").length > 0 || Xe().length > 0 || _.Content !== null), an = c(() => rn.value || at.value || ot.value), on = c(() => {
			let e = _.Height;
			if (typeof e == "number" && Number.isFinite(e)) return e;
			if (typeof e == "string") {
				let t = e.match(/^\s*(-?(?:\d+(?:\.\d*)?|\.\d+))(?:px)?\s*$/i);
				if (t) return Number(t[1]);
			}
			return null;
		}), sn = c(() => on.value === 32 ? "Standard" : on.value === 46 || _.PreferredHeightOption === "Tall" ? "Tall" : "Standard"), cn = c(() => _.Title !== ""), ln = c(() => _.Subtitle !== ""), un = c(() => _.IsBackButtonVisible !== _.IsPaneToggleButtonVisible), dn = c(() => ({
			"is-expanded-height": an.value,
			"is-compact-height": !an.value,
			"is-compact": S.value,
			"is-deactivated": Pt.value,
			"is-narrow": C.value,
			"has-caption-controls": T.value,
			"is-negative-inset-spacing": un.value
		})), Y = (e) => e === "" || e == null ? "" : typeof e == "string" && e.trim() !== "" && !Number.isNaN(Number(e.trim())) ? `${Number(e.trim())}px` : typeof e == "number" ? `${e}px` : String(e), fn = (e) => {
			if (e === "" || e == null) return "";
			let t = String(e).split(",").map((e) => Y(e.trim()));
			return t.length === 1 ? t[0] ?? "" : t.length === 2 ? `${t[1]} ${t[0]}` : t.length === 4 ? `${t[1]} ${t[2]} ${t[3]} ${t[0]}` : String(e);
		}, pn = (e) => ({
			Left: "start",
			Center: "center",
			Right: "end",
			Stretch: "stretch"
		})[e] ?? "center", mn = (e) => ({
			Top: "start",
			Center: "center",
			Bottom: "end",
			Stretch: "stretch"
		})[e] ?? "center", hn = c(() => {
			let e = {};
			for (let t of Object.keys(De.value)) e[`--${t}`] = y(t);
			e["--TitleBarCaptionButtonForeground"] = String(y("TitleBarBackButtonForeground")), e["--TitleBarCaptionButtonPressedForeground"] = String(y("TitleBarBackButtonForegroundPressed")), e["--TitleBarCaptionButtonInactiveForeground"] = String(y("TitleBarDeactivatedForegroundBrush"));
			for (let t of [
				"TitleBarLeftPaddingWidth",
				"TitleBarRightPaddingWidth",
				"TitleBarMinDragRegionWidth",
				"TitleBarBackButtonWidth",
				"TitleBarPaneToggleButtonWidth"
			]) Qe.value[t] !== void 0 && (e[`--${t}`] = Y(Qe.value[t]));
			if (w.value) {
				let { LeftInset: t, RightInset: n } = w.value, r = _.FlowDirection === "RightToLeft";
				e["--TitleBarLeftPaddingWidth"] = Y(r ? n : t), e["--TitleBarRightPaddingWidth"] = Y(r ? t : n), T.value || (e.clipPath = `inset(0 ${n}px 0 ${t}px)`);
			}
			e["--TitleBarLeftHeaderPaddingWidth"] = Y(pt.value);
			for (let t of [
				"TitleBarIconMaxWidth",
				"TitleBarIconMaxHeight",
				"TitleBarTitleMinWidth",
				"TitleBarSubtitleMinWidth"
			]) e[`--${t}`] = Y(y(t));
			for (let t of [
				"TitleBarIconMargin",
				"TitleBarTitleMargin",
				"TitleBarSubtitleMargin",
				"TitleBarCompactContentMargin"
			]) e[`--${t}`] = fn(y(t));
			return e["--TitleBarDeactivatedOpacity"] = String(y("TitleBarDeactivatedOpacity")), e.height = Y(_.Height !== "" && _.Height !== void 0 && _.Height !== null ? _.Height : y(sn.value === "Tall" ? "TitleBarExpandedHeight" : "TitleBarCompactHeight")), e.gridTemplateColumns = T.value ? "var(--TitleBarLeftPaddingWidth, 2px) auto auto auto var(--TitleBarLeftHeaderPaddingWidth, 14px) auto auto auto minmax(0, 1fr) auto var(--TitleBarMinDragRegionWidth, 48px) 46px 46px 46px 0px" : "var(--TitleBarLeftPaddingWidth, 2px) auto auto auto var(--TitleBarLeftHeaderPaddingWidth, 14px) auto auto auto minmax(0, 1fr) auto var(--TitleBarMinDragRegionWidth, 48px) var(--TitleBarRightPaddingWidth, 0px)", e.gridTemplateRows = "minmax(0, 1fr)", T.value && (e["--TitleBarRightPaddingWidth"] = "0px"), _.FlowDirection === "RightToLeft" && !T.value && (e.direction = "rtl"), _.Visibility === "Collapsed" && (e.display = "none"), _.Width !== "" && (e.width = Y(_.Width)), _.MinWidth !== "" && (e.minWidth = Y(_.MinWidth)), _.MinHeight !== "" && (e.minHeight = Y(_.MinHeight)), _.MaxWidth !== "" && (e.maxWidth = Y(_.MaxWidth)), _.MaxHeight !== "" && (e.maxHeight = Y(_.MaxHeight)), _.Margin !== "" && (e.margin = fn(_.Margin)), _.HorizontalAlignment !== "" && (e.justifySelf = pn(_.HorizontalAlignment)), _.VerticalAlignment !== "" && (e.alignSelf = mn(_.VerticalAlignment)), _.Background !== "" && (e.background = _.Background), _.Foreground !== "" && (e.color = _.Foreground, e["--TitleBarForegroundBrush"] = _.Foreground), e;
		}), gn = () => {
			!z || _.Title === "" || z.GetTitle() !== _.Title && (D = _.Title, z.SetTitle(_.Title));
		}, _n = () => {
			z && D && z.GetTitle() === D && z.SetTitle(Xt), D = "";
		}, vn = () => {
			let e = b.value, t = x.value;
			if (!e || !t) return;
			let n = t.querySelector(".win-titlebar-content-presenter"), r = e.getBoundingClientRect().width, i = S.value, a = C.value;
			if (C.value = r < 480, r <= 0) return;
			let o = t.clientWidth, ee = n?.scrollWidth ?? t.scrollWidth;
			if (!(r !== F || Math.abs(o - I) > .5 || Math.abs(ee - L) > .5)) return i !== S.value || a !== C.value;
			let te = F < 0 || Math.abs(r - F) > .5;
			return F = r, I = o, L = ee, !P && o > 0 && ee > o + 1 ? (P = r, S.value = !0) : S.value && te && r >= P && (P = 0, S.value = !1), i !== S.value || a !== C.value;
		}, X = () => {
			J || N || (N = (R ?? window).requestAnimationFrame(() => {
				if (N = 0, J) return;
				let e = vn();
				Jt(), Q(), e && Sn();
			}));
		}, yn = () => {
			let e = b.value;
			if (!e || J) return;
			Jt();
			let t = e.getBoundingClientRect(), n = z?.GetTitleBarInsets?.() ?? null, r = xe({
				X: t.x,
				Y: t.y,
				Width: t.width,
				Height: t.height
			}, R?.innerWidth ?? 0, n);
			w.value?.LeftInset === r?.LeftInset && w.value?.RightInset === r?.RightInset || (w.value = r, P = 0, F = -1, I = -1, L = -1, S.value = !1, u(X));
		}, bn = () => {
			j &&= (j.disconnect(), null);
		}, xn = () => {
			bn();
			let e = x.value;
			e && (j = new (R?.MutationObserver ?? MutationObserver)((e) => {
				_.AutoRefreshDragRegions && e.some((e) => e.type === "childList") && Z();
			}), j.observe(e, {
				childList: !0,
				subtree: !0,
				characterData: !0
			}));
		}, Z = () => {
			let e = b.value;
			if (!e) return;
			let t = _e(e);
			Qt = t;
			let n = new Set(t);
			for (let t of e.querySelectorAll("[data-titlebar-passthrough]")) n.has(t) || t.removeAttribute("data-titlebar-passthrough");
			for (let e of t) e.hasAttribute("data-titlebar-passthrough") || e.setAttribute("data-titlebar-passthrough", "");
			Q(), Yt.value += 1;
		}, Q = () => {
			if (!z?.SetDragRegions) return;
			let e = b.value;
			if (!e) return;
			let t = e.getBoundingClientRect(), n = (e) => {
				let n = e.getBoundingClientRect(), r = Math.max(t.left + (w.value?.LeftInset ?? 0), n.left), i = Math.max(t.top, n.top), a = T.value ? 0 : w.value?.RightInset ?? 0;
				return {
					X: r,
					Y: i,
					Width: Math.max(0, Math.min(t.right - a, n.right) - r),
					Height: Math.max(0, Math.min(t.bottom, n.bottom) - i)
				};
			}, r = e.querySelector(".win-titlebar-icon");
			A && M !== r && (M && A.unobserve(M), r && A.observe(r), M = r);
			let i = T.value ? {
				...zt.value ? { minimize: n(zt.value) } : {},
				...Bt.value ? { maximize: n(Bt.value) } : {},
				...Vt.value ? { close: n(Vt.value) } : {}
			} : void 0;
			z?.SetDragRegions?.({
				Caption: n(e),
				Passthrough: Qt.filter((e) => e.isConnected).map(n).filter((e) => e.Width > 0 && e.Height > 0),
				Icon: r ? n(r) : null,
				CaptionButtons: i
			});
		}, Sn = () => {
			J || (p("LayoutUpdated", $, null), m?.vnode.props?.onLayoutUpdated || i(h.LayoutUpdated, m)?.($, null));
		}, Cn = () => {
			Pt.value = !1, Q();
		}, wn = () => {
			Pt.value = !0, Q();
		}, Tn = (e) => Gt.value.Button === e ? Gt.value.State : "normal", En = (e, t, n) => {
			if (n?.pointerType === "touch") {
				t === "pressed" ? E.value = {
					Button: e,
					State: "pressed"
				} : E.value.Button === e && (E.value = {
					Button: null,
					State: "normal"
				});
				return;
			}
			t === "normal" ? E.value.Button === e && (E.value = {
				Button: null,
				State: "normal"
			}) : E.value = {
				Button: e,
				State: t
			};
		}, Dn = async () => {
			if (B?.IsMaximized) try {
				It.value = await B.IsMaximized();
			} catch (e) {
				R?.console.error("Unable to read window maximize state:", e);
			}
		}, On = () => {
			let e = ++G;
			V?.(), V = void 0, H?.(), H = void 0, U?.(), U = void 0;
			let t = B, n = bt.value, r = yt.value && n && R ? be(R, n, z) : null;
			if (B = r, Lt.value = {
				Button: null,
				State: "normal"
			}, Ft.value = !1, t?.SetCaptionButtonHitTestMode && t !== r && Promise.resolve(t.SetCaptionButtonHitTestMode("Web")).catch((e) => R?.console.error("Unable to clear title bar Snap Layout hit testing:", e)), r && (Dn(), r.SubscribeStateChanged && Promise.resolve(r.SubscribeStateChanged(() => {
				Dn();
			})).then((t) => {
				J || e !== G ? t() : V = t;
			}).catch((e) => R?.console.error("Unable to watch caption button state:", e)), r.SubscribeCaptionButtonState && Promise.resolve(r.SubscribeCaptionButtonState((t) => {
				J || e !== G || (E.value = {
					Button: null,
					State: "normal"
				}, Lt.value = t);
			})).then((t) => {
				J || e !== G ? t() : H = t;
			}).catch((e) => R?.console.error("Unable to watch native caption pointer state:", e)), r.SubscribeCaptionButtonAction && Promise.resolve(r.SubscribeCaptionButtonAction((t) => {
				!J && e === G && jn(t);
			})).then((t) => {
				J || e !== G ? t() : U = t;
			}).catch((e) => R?.console.error("Unable to watch native caption actions:", e)), r.SetCaptionButtonHitTestMode)) {
				let t = !!r.SubscribeCaptionButtonAction;
				Promise.resolve(r.SetCaptionButtonHitTestMode(t ? "NativeSnap" : "Web")).then(() => {
					!J && e === G && (Ft.value = t);
				}).catch((e) => R?.console.error("Unable to enable title bar Snap Layout hit testing:", e));
			}
		}, kn = Promise.resolve(), An = () => {
			let e = z;
			if (!e?.SetPreferredHeightOption) return;
			let t = sn.value, n = ++tn;
			kn = kn.catch(() => void 0).then(async () => {
				J || n !== tn || await e.SetPreferredHeightOption?.(t);
			}).catch((e) => R?.console.error("Unable to set title bar height:", e));
		}, jn = async (e) => {
			if (!(!T.value || Rt.value)) {
				Rt.value = e, Ht.value = null;
				try {
					e === "minimize" ? B?.Minimize ? await B.Minimize() : (p("MinimizeRequested", $, null), m?.vnode.props?.onMinimizeRequested || i(h.MinimizeRequested, m)?.($, null)) : e === "maximize" ? (B?.ToggleMaximize ? await B.ToggleMaximize() : (p("MaximizeRequested", $, null), m?.vnode.props?.onMaximizeRequested || i(h.MaximizeRequested, m)?.($, null)), await Dn()) : B?.Close ? await B.Close() : (p("CloseRequested", $, null), m?.vnode.props?.onCloseRequested || i(h.CloseRequested, m)?.($, null)), B || (p("CaptionButtonRequested", e, $, null), m?.vnode.props?.onCaptionButtonRequested || i(h.CaptionButtonRequested, m)?.(e, $, null));
				} catch (t) {
					R?.console.error(`Unable to ${e} the window:`, t);
				} finally {
					Rt.value = null;
				}
			}
		};
		f(Kt, (e) => {
			W !== void 0 && R?.clearTimeout(W), W = void 0, Ht.value = null, e && (W = (R ?? window).setTimeout(() => {
				Ht.value = Kt.value === e ? e : null, W = void 0;
			}, 600));
		}), Le(async () => {
			b.value && (R = b.value.ownerDocument.defaultView ?? window, q = R.matchMedia?.("(forced-colors: active)"), nn(), q?.addEventListener("change", nn), z = ye(b.value, we), Ut.value = !!(z && T.value), Jt(), An(), On(), yn(), en = z?.SubscribeTitleBarInsets?.(yn), z?.GetTitleBarInsets && !en && (K = yn, R.addEventListener("resize", K)), Pt.value = !(z?.IsInputActive?.() ?? b.value.ownerDocument.hasFocus()), Xt = z?.GetTitle() ?? "", gn(), $t = z?.SubscribeActivation?.((e) => {
				e ? Cn() : wn();
			}), $t || (O = Cn, k = wn, R.addEventListener("focus", O), R.addEventListener("blur", k)), b.value.addEventListener("winui-titlebar-drag-region-changed", Z), Zt = new R.MutationObserver(Z), Zt.observe(b.value, {
				attributes: !0,
				subtree: !0,
				attributeFilter: ["titlebar.isdragregion"]
			}), await u(), !J && (vn(), Z(), Sn(), x.value && xn(), R?.ResizeObserver && (A = new R.ResizeObserver(X), b.value && A.observe(b.value), Q())));
		}), f([yt, bt], () => {
			!R || !z || (On(), u(Z));
		}, { flush: "post" }), Ie(() => {
			J = !0, W !== void 0 && R?.clearTimeout(W), O && R?.removeEventListener("focus", O), k && R?.removeEventListener("blur", k), A && A.disconnect(), $t?.(), V?.(), H?.(), U?.(), en?.(), K && R?.removeEventListener("resize", K), q?.removeEventListener("change", nn), Zt?.disconnect(), b.value?.removeEventListener("winui-titlebar-drag-region-changed", Z), z?.ClearDragRegions?.(), G += 1, T.value && B?.SetCaptionButtonHitTestMode && Promise.resolve(B.SetCaptionButtonHitTestMode("Web")).catch((e) => R?.console.error("Unable to clear title bar Snap Layout hit testing:", e)), Ft.value = !1, tn += 1, R?.cancelAnimationFrame(N), bn(), _n();
		}), f(() => _.Title, (e, t) => {
			t !== "" && e === "" ? _n() : gn();
		}), f(() => _.AutoRefreshDragRegions, (e) => {
			x.value && xn(), e && Z();
		}), f(rn, (e) => {
			e ? (F = -1, I = -1, L = -1, u(() => {
				vn(), xn();
			})) : (bn(), P = 0, F = -1, I = -1, L = -1, S.value = !1);
		}), f(S, () => {
			u(Z);
		}, { flush: "post" }), f([
			mt,
			ht,
			gt,
			_t,
			vt,
			at,
			ot,
			it
		], () => {
			u(() => {
				X(), Z();
			});
		}, { flush: "post" }), f(() => _.FlowDirection, () => {
			u(X);
		}), f(sn, () => {
			An(), u(X);
		});
		let Mn = (e) => c({
			get: () => e in g.value || _[e] !== null ? _[e] : e === "IconSource" ? Mt.value?.IconSource ?? null : v(e)[0] ?? _[e],
			set: (t) => {
				g.value = {
					...g.value,
					[e]: t
				}, o(We[e], t, m);
			}
		});
		for (let e of Object.keys(We)) f(() => a(We[e], m), () => {
			if (e in g.value) {
				let t = { ...g.value };
				delete t[e], g.value = t;
			}
		});
		let $ = ze({
			Element: b,
			isCompact: S,
			isNarrow: C,
			...Object.fromEntries([
				"Title",
				"Subtitle",
				"IconSource",
				"LeftHeader",
				"Content",
				"RightHeader",
				"IsBackButtonVisible",
				"IsBackButtonEnabled",
				"IsPaneToggleButtonVisible",
				"IsPaneOpen",
				"IsCaptionButtonsVisible",
				"CaptionButtonsFramework",
				"AutoRefreshDragRegions",
				"PreferredHeightOption",
				"FlowDirection"
			].map((e) => [e, Mn(e)])),
			ResolvedHeightOption: sn,
			TemplateSettings: c(() => ({ IconElement: it.value ? Mt.value : null })),
			RecomputeDragRegions: Z
		});
		ge($);
		let Nn = {
			t: s,
			slots: Ce,
			hostAdapter: we,
			forcedHighContrast: Te,
			highContrast: Ee,
			brushAliases: De,
			highContrastColors: Ue,
			xamlProps: We,
			emit: p,
			instance: m,
			attrs: h,
			overrides: g,
			props: _,
			rootAttrs: Ge,
			slotNodes: Ke,
			children: qe,
			flatten: Je,
			property: Ye,
			propertyNodes: v,
			defaultContent: Xe,
			inheritedResources: Ze,
			localResources: Qe,
			resources: $e,
			resource: y,
			IconSource: et,
			FlowDirection: tt,
			IsEnabled: nt,
			hasProperty: rt,
			hasIcon: it,
			hasLeftHeader: at,
			hasRightHeader: ot,
			IconElementOutlet: st,
			ElementOutlet: ct,
			outlet: lt,
			LeftHeaderOutlet: ut,
			RightHeaderOutlet: dt,
			ContentOutlet: ft,
			HeaderInset: pt,
			Title: mt,
			Subtitle: ht,
			IsBackButtonVisible: gt,
			IsBackButtonEnabled: _t,
			IsPaneToggleButtonVisible: vt,
			IsCaptionButtonsVisible: yt,
			configuredCaptionButtonsFramework: bt,
			IsPaneOpen: xt,
			BackButtonEnabled: St,
			BackLabel: Ct,
			PaneLabel: wt,
			ContentAlignment: Tt,
			ContentVerticalAlignment: Et,
			ContentMargin: Dt,
			requestBack: Ot,
			requestPaneToggle: kt,
			elementFromRef: At,
			rootRef: b,
			registerRoot: jt,
			iconElementRef: Mt,
			contentAreaRef: x,
			registerContentArea: Nt,
			isDeactivated: Pt,
			isCompact: S,
			isNarrow: C,
			captionPadding: w,
			captionControlsVisible: T,
			nativeCaptionHitTestEnabled: Ft,
			windowIsMaximized: It,
			captionPointerState: E,
			nativeCaptionPointerState: Lt,
			captionActionInFlight: Rt,
			minimizeCaptionButton: zt,
			maximizeCaptionButton: Bt,
			closeCaptionButton: Vt,
			tooltipButton: Ht,
			captionButtonsPortaled: Ut,
			captionButtonHostStyle: Wt,
			effectiveCaptionPointerState: Gt,
			hoveredCaptionButton: Kt,
			captionLabels: qt,
			updateCaptionButtonHost: Jt,
			dragRegionRevision: Yt,
			NARROW_TITLEBAR_WIDTH: 480,
			get defaultDocumentTitle() {
				return Xt;
			},
			set defaultDocumentTitle(e) {
				Xt = e;
			},
			get lastAppliedTitle() {
				return D;
			},
			set lastAppliedTitle(e) {
				D = e;
			},
			get focusHandler() {
				return O;
			},
			set focusHandler(e) {
				O = e;
			},
			get blurHandler() {
				return k;
			},
			set blurHandler(e) {
				k = e;
			},
			get resizeObserver() {
				return A;
			},
			set resizeObserver(e) {
				A = e;
			},
			get contentObserver() {
				return j;
			},
			set contentObserver(e) {
				j = e;
			},
			get attachedPropertyObserver() {
				return Zt;
			},
			set attachedPropertyObserver(e) {
				Zt = e;
			},
			get interactableElements() {
				return Qt;
			},
			set interactableElements(e) {
				Qt = e;
			},
			get observedIcon() {
				return M;
			},
			set observedIcon(e) {
				M = e;
			},
			get compactMeasureFrame() {
				return N;
			},
			set compactMeasureFrame(e) {
				N = e;
			},
			get compactModeThresholdWidth() {
				return P;
			},
			set compactModeThresholdWidth(e) {
				P = e;
			},
			get lastMeasuredWidth() {
				return F;
			},
			set lastMeasuredWidth(e) {
				F = e;
			},
			get lastMeasuredContentAvailableWidth() {
				return I;
			},
			set lastMeasuredContentAvailableWidth(e) {
				I = e;
			},
			get lastMeasuredContentDesiredWidth() {
				return L;
			},
			set lastMeasuredContentDesiredWidth(e) {
				L = e;
			},
			get ownerWindow() {
				return R;
			},
			set ownerWindow(e) {
				R = e;
			},
			get windowHost() {
				return z;
			},
			set windowHost(e) {
				z = e;
			},
			get captionActionHost() {
				return B;
			},
			set captionActionHost(e) {
				B = e;
			},
			get unsubscribeActivation() {
				return $t;
			},
			set unsubscribeActivation(e) {
				$t = e;
			},
			get unsubscribeWindowState() {
				return V;
			},
			set unsubscribeWindowState(e) {
				V = e;
			},
			get unsubscribeCaptionState() {
				return H;
			},
			set unsubscribeCaptionState(e) {
				H = e;
			},
			get unsubscribeCaptionAction() {
				return U;
			},
			set unsubscribeCaptionAction(e) {
				U = e;
			},
			get unsubscribeInsets() {
				return en;
			},
			set unsubscribeInsets(e) {
				en = e;
			},
			get tooltipTimer() {
				return W;
			},
			set tooltipTimer(e) {
				W = e;
			},
			get preferredHeightRevision() {
				return tn;
			},
			set preferredHeightRevision(e) {
				tn = e;
			},
			get captionHostRevision() {
				return G;
			},
			set captionHostRevision(e) {
				G = e;
			},
			get insetResizeHandler() {
				return K;
			},
			set insetResizeHandler(e) {
				K = e;
			},
			get contrastQuery() {
				return q;
			},
			set contrastQuery(e) {
				q = e;
			},
			contrastChanged: nn,
			get disposed() {
				return J;
			},
			set disposed(e) {
				J = e;
			},
			hasContent: rn,
			hasExpandedHeight: an,
			explicitHeight: on,
			resolvedCaptionHeightOption: sn,
			showTitle: cn,
			showSubtitle: ln,
			isNegativeInsetSpacing: un,
			rootClasses: dn,
			cssLength: Y,
			xamlThickness: fn,
			alignment: pn,
			verticalAlignment: mn,
			rootStyle: hn,
			updateWindowTitle: gn,
			resetWindowTitle: _n,
			updateCompactMode: vn,
			scheduleCompactModeUpdate: X,
			updatePadding: yn,
			stopContentObserver: bn,
			startContentObserver: xn,
			recomputeDragRegions: Z,
			updateDragRegions: Q,
			notifyLayoutUpdated: Sn,
			onFocus: Cn,
			onBlur: wn,
			captionButtonState: Tn,
			setCaptionButtonPointer: En,
			refreshWindowMaximized: Dn,
			syncCaptionActionHost: On,
			get preferredHeightTask() {
				return kn;
			},
			set preferredHeightTask(e) {
				kn = e;
			},
			syncPreferredHeightOption: An,
			activateCaptionButton: jn,
			dependencyProperty: Mn,
			publicApi: $,
			Grid: te,
			Button: le,
			ColumnDefinition: ue,
			ContentPresenter: ce,
			Viewbox: ne,
			TextBlock: ie,
			AnimatedIcon: se,
			FontIcon: ae,
			get FontIconSource() {
				return de;
			}
		};
		return Object.defineProperty(Nn, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), Nn;
	}
});
//#endregion
export { Ue as default };

//# sourceMappingURL=TitleBar.vue_vue_type_script_setup_true_lang.js.map