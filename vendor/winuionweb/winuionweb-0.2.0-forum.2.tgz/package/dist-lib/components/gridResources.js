import { defineComponent as e } from "vue";
//#region src/components/gridResources.ts
var t = e({
	name: "Grid.Resources",
	__gridResourcesProperty: !0,
	setup: () => () => null
});
e({
	name: "Style",
	__gridStyleDefinition: !0,
	setup: () => () => null
}), e({
	name: "Setter",
	__gridStyleSetter: !0,
	setup: () => () => null
});
//#endregion
export { t as GridResources };

//# sourceMappingURL=gridResources.js.map