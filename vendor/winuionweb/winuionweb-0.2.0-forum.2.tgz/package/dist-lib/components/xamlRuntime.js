import { informationControlResources as e } from "./informationControlResources.js";
import { buttonResources as t } from "./buttonResources.js";
import { dropDownButtonResources as n } from "./dropDownButtonResources.js";
import { appBarResources as r } from "./appBarResources.js";
import { commandBarResources as i } from "./commandBarResources.js";
import { xamlPrimitiveResourceKey as a } from "./xamlPrimitives.js";
import { navigationViewResources as o } from "./navigationViewResources.js";
import { breadcrumbBarResources as s } from "./breadcrumbBarResources.js";
import { menuFlyoutResources as c } from "./menuFlyoutResources.js";
import { menuBarResources as l } from "./menuBarResources.js";
import { pivotResources as u } from "./pivotResources.js";
import { selectorBarResources as d } from "./selectorBarResources.js";
import { tabViewResources as f } from "./tabViewResources.js";
import { swipeControlResources as p } from "./swipeControlResources.js";
import { textControlResources as m } from "./textControlResources.js";
import { resolveAcrylicResource as h } from "./AcrylicBrush.js";
import { Fragment as g, cloneVNode as _, getCurrentInstance as v, h as y, isRef as b } from "vue";
//#region src/components/xamlRuntime.ts
var x = Symbol("WinUIonWeb.xamlScope"), S = Symbol("WinUIonWeb.xamlNameScope"), C = Symbol("WinUIonWeb.xamlControlIdentity"), w = Symbol("WinUIonWeb.xamlItemContext"), T = new Set(/* @__PURE__ */ "arguments.eval.await.yield.class.function.var.let.const.if.else.return.switch.case.default.delete.new.this.super.typeof.void.in.instanceof.true.false.null.undefined".split(".")), E = new Set(/* @__PURE__ */ "TextCompositionStarted.TextCompositionChanged.TextCompositionEnded.PaneToggleRequested.SuggestionChosen.PasswordChanged.PasswordChanging.BeforeTextChanging.TextChanging.SelectionChanging.IsTextTrimmedChanged.Paste.CopyingToClipboard.CuttingToClipboard.ContextMenuOpening.TextCompositionStarted.TextCompositionChanged.TextCompositionEnded.CandidateWindowBoundsChanged.Unloaded.ExecuteRequested.CanExecuteRequested.CanExecuteChanged.ContainerContentChanging.LayoutUpdated.Click.Checked.Unchecked.Indeterminate.SelectionChanged.Invoked.AddTabButtonClick.TabCloseRequested.CloseRequested.TabItemsChanged.TabDragStarting.TabDragCompleted.TabDroppedOutside.TabStripDragOver.TabStripDrop.TabTearOutWindowRequested.TabTearOutRequested.ExternalTornOutTabsDropping.ExternalTornOutTabsDropped.BringIntoViewRequested.PivotItemLoading.PivotItemLoaded.PivotItemUnloading.PivotItemUnloaded.Selected.Select.ValueChanged.TextChanged.TextSubmitted.IsCheckedChanged.IsOnChanged.Toggled.DropDownOpened.DropDownClosed.Opening.Opened.Closing.Closed.PaneOpening.PaneOpened.PaneClosing.PaneClosed.BackRequested.DisplayModeChanged.Navigating.Navigated.NavigationFailed.NavigationStopped.Expanding.Expanded.Collapsing.Collapsed.DateChanged.SelectedDateChanged.SelectedDatesChanged.TimeChanged.SelectedTimeChanged.CalendarViewDayItemChanging.ColorChanged.QuerySubmitted.ItemClick.ItemClicked.GettingFocus.KeyDown.GotFocus.LostFocus.ElementPrepared.ElementClearing.ElementIndexChanged.ViewChanged.ViewChanging.PointerMoved.PointerPressed.PointerReleased.PointerEntered.PointerExited.PointerCanceled.PointerCaptureLost.KeyUp.Tapped.Loaded.ItemInvoked.DragItemsStarting.DragItemsCompleted.DragOver.Drop.RefreshRequested.RefreshStateChanged.PreviewFailed.MediaOpened.MediaFailed.MediaEnded.IsFullWindowChanged.PrimaryButtonClick.SecondaryButtonClick.CloseButtonClick.ActionButtonClick.ContextRequested.DynamicOverflowItemsChanging.ImageOpened.ImageFailed.OpenFailed.ActualPlacementChanged.SelectedIndexChanged.DirectManipulationStarted.DirectManipulationCompleted.ViewChangeStarted.ViewChangeCompleted.ExtentChanged.StateChanged.ScrollStarting.ZoomStarting.ScrollAnimationStarting.ZoomAnimationStarting.ScrollCompleted.ZoomCompleted.AnchorRequested.BringingIntoView".split(".")), D = (e) => `on${e}`, O = /* @__PURE__ */ new WeakMap(), k = (e, t) => {
	let n = _(e, {
		...t,
		...e.props
	});
	return O.set(n, {
		...t,
		...O.get(e) ?? e.props
	}), n;
}, A = /* @__PURE__ */ new WeakMap(), j = new Set(/* @__PURE__ */ "GalleryItemsGrid,HomeHeaderTile,HorizontalScrollContainer,SwitchPresenter,Run,Hyperlink,Span,Paragraph,Bold,Italic,Underline,InlineUIContainer,TextHighlighter,TextRange,RichTextBlockOverflow,SampleCodePresenter,PasswordBox,AnimatedIcon,TitleBar,AcrylicBrush,SolidColorBrush,ParallaxView,MenuBar,MenuBarItem,UserControl,XamlUICommand,StandardUICommand,MenuFlyout,MenuFlyoutPresenter,MenuFlyoutItem,ToggleMenuFlyoutItem,RadioMenuFlyoutItem,MenuFlyoutSubItem,SplitMenuFlyoutItem,MenuFlyoutSeparator,KeyboardAccelerator,AutoSuggestBox,Border,BreadcrumbBar,BreadcrumbBarItem,Button,CalendarView,CalendarDatePicker,CheckBox,ColorPicker,ComboBox,ItemsControl,ContentDialog,ControlExample,ControlExampleSubstitution,DropDownButton,Expander,ExpanderBase,Flyout,CaptureElement,MediaPlayerElement,MediaTransportControls,PersonPicture,AppBarButton,AppBarToggleButton,AppBarSeparator,CommandBar,CommandBarFlyout,BitmapIcon,PathIcon,FontIcon,ImageIcon,IconSourceElement,FontIconSource,SymbolIconSource,BitmapIconSource,PathIconSource,ImageIconSource,HyperlinkButton,Ellipse,Image,BitmapImage,SvgImageSource,Popup,RadioButton,RadioButtons,Rating,Rectangle,RepeatButton,RichEditBox,RichTextBlock,SelectorBar,SelectorBarItem,Slider,NumberBox,ProgressBar,ProgressRing,SplitButton,SplitView,SymbolIcon,TeachingTip,TextBlock,TextBox,ToggleButton,ToggleSplitButton,ToggleSwitch,ToolTip,FlipView,GridView,ItemsRepeater,ItemsView,ListView,RefreshContainer,RefreshVisualizer,TreeView,DatePicker,TimePicker,DateTimePickerFlyout,PickerColumn,ItemsStackPanel,Grid,Canvas,RelativePanel,Border,ColumnDefinition,RowDefinition,Slider.Header,StackPanel,VariableSizedWrapGrid,Viewbox,PipsPager,ScrollView,ScrollPresenter,ScrollViewer,SemanticZoom,CollectionViewSource,Line,Polyline,Path,Path.Data,GeometryGroup,GeometryGroup.Children,LineGeometry,EllipseGeometry,RectangleGeometry,RadialGradientBrush,GradientStop,ThemeShadow,SystemBackdropElement,MicaBackdrop,DesktopAcrylicBackdrop,InfoBadge,InfoBar,InfoBarPanel,NavigationView,NavigationViewItem,Frame,Pivot,PivotItem,SwipeControl,SwipeItems,SwipeItem,TabView,TabViewItem".split(",")), M = (e) => {
	if (!e || typeof e != "object") return "";
	let t = e;
	return t.name || t.__name || t.__file?.split(/[\\/]/).pop()?.replace(/\.vue$/, "") || "";
}, N = new Set([
	"GalleryItemsGrid",
	"HomeHeaderTile",
	"PageHeader",
	"TabContentSampleControl"
]), P = (e) => {
	let t = e.__name ?? "";
	return t !== "Page" && /Page\d*$/.test(t) || N.has(t);
}, F = (e) => b(e) ? e.value : e, I = (e) => {
	if (typeof e != "string") return e;
	let t = e.trim().match(/^#([\da-f]{8})$/i);
	if (!t) return e;
	let n = t[1], r = Number.parseInt(n.slice(0, 2), 16) / 255;
	return `rgba(${Number.parseInt(n.slice(2, 4), 16)}, ${Number.parseInt(n.slice(4, 6), 16)}, ${Number.parseInt(n.slice(6, 8), 16)}, ${Number(r.toFixed(4))})`;
}, L = (e) => {
	let t = {}, n = (e) => {
		if (!e) return;
		let n = [];
		try {
			n = Object.keys(e);
		} catch {
			return;
		}
		for (let r of n) if (!(r in t)) try {
			Object.defineProperty(t, r, {
				configurable: !0,
				enumerable: !0,
				get: () => F(e[r]),
				set: (e) => Object.defineProperty(t, r, {
					configurable: !0,
					enumerable: !0,
					writable: !0,
					value: e
				})
			});
		} catch {}
	}, r = e?.parent ?? null;
	for (; r;) P(r.type) && n(r.setupState), r = r.parent;
	let i = e?.parent?.provides?.[x];
	n(i);
	let a = e?.parent?.provides?.[S];
	n(a);
	let o = e?.appContext.config.globalProperties;
	if (o) {
		let e = [];
		try {
			e = Object.keys(o);
		} catch {
			e = [];
		}
		for (let n of e) if (!(n !== "$t" && n in t)) try {
			t[n] = F(o[n]);
		} catch {}
		try {
			typeof o.$t == "function" && (t.$t = o.$t);
		} catch {}
	}
	return typeof t.$t == "function" && !t.t && (t.t = t.$t), t;
}, R = (e) => V(e).expression, z = (e) => e.trim().match(/^\{\s*(?:ThemeResource|StaticResource)\s+([^\s}]+)\s*\}$/i)?.[1] ?? "", B = Object.freeze({
	ListViewItemMinWidth: 88,
	ListViewItemMinHeight: 40,
	TeachingTipTailShortSideLength: 8,
	TeachingTipTailMargin: 10
}), ee = (e) => e ? `var(--${{
	OverlayCornerRadius: "OverlayCornerRadius",
	SurfaceStrokeColorDefaultBrush: "SurfaceStrokeColorDefaultBrush",
	SurfaceStrokeColorFlyoutBrush: "SurfaceStrokeColorFlyoutBrush",
	LayerFillColorAltBrush: "LayerFillColorAltBrush",
	SolidBackgroundFillColorBaseBrush: "SolidBackgroundFillColorBaseBrush",
	SolidBackgroundFillColorTertiaryBrush: "SolidBackgroundFillColorTertiaryBrush",
	SmokeFillColorDefaultBrush: "SmokeFillColorDefaultBrush"
}[e] ?? e})` : "", V = (e) => {
	let t = e.match(/^\{(?:x:Bind|Binding)(?:\s+([\s\S]*?))?\}$/);
	if (!t) return {
		expression: e,
		twoWay: !1,
		converter: "",
		converterParameter: ""
	};
	let n = t[1] ?? "", r = [], i = 0, a = 0, o = "";
	for (let e = 0; e < n.length; e += 1) {
		let t = n[e];
		if (o) {
			t === o && n[e - 1] !== "\\" && (o = "");
			continue;
		}
		t === "\"" || t === "'" ? o = t : "{([".includes(t) ? a += 1 : "})]".includes(t) ? --a : t === "," && a === 0 && (r.push(n.slice(i, e).trim()), i = e + 1);
	}
	r.push(n.slice(i).trim());
	let s = {};
	for (let e of r) {
		let t = e.match(/^(Mode|Converter|ConverterParameter|ElementName|Path)\s*=\s*([\s\S]*)$/);
		t && (s[t[1]] = t[2].trim());
	}
	let c = s.Path ?? (/^(?:Mode|Converter|ConverterParameter|ElementName)\s*=/.test(r[0] ?? "") ? "" : r[0] ?? "");
	return {
		expression: s.ElementName ? `${s.ElementName}${c ? "." + c : ""}` : c,
		twoWay: s.Mode === "TwoWay",
		converter: s.Converter ?? "",
		converterParameter: s.ConverterParameter ?? ""
	};
}, H = (e, t, n, r = !1) => {
	if (!e.converter) return t;
	let i = z(e.converter) ?? e.converter, a = W(i, L(n)), o = r ? a?.ConvertBack : a?.Convert;
	if (typeof o == "function") {
		let r = e.converterParameter ? K(e.converterParameter, n) : null;
		return o.call(a, t, null, r, null);
	}
	return i === "nullableBooleanToBooleanConverter" ? t === !0 : t;
}, U = (e) => e.replace(/^\((?:x:Double|x:Int32|x:String)\)/, "").replace(/\?\./g, ".").split(".").map((e) => e.trim()).filter(Boolean), W = (e, t) => {
	let n = e.trim(), r = n.match(/^\(\s*\(\s*[A-Za-z_]\w*:[A-Za-z_]\w*(?:\.[A-Za-z_]\w*)*\s*\)\s*([A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*)*)\s*\)([\s\S]*)$/);
	r && (n = `${r[1]}${r[2]}`);
	let i = n.match(/^\(\s*x:(Int32|Double|String)\s*\)\s*([\s\S]+)$/);
	if (i) {
		let e = W(i[2], t);
		if (e == null) return e;
		if (i[1] === "String") return String(e);
		let n = Number(e);
		return Number.isFinite(n) ? i[1] === "Int32" ? Math.trunc(n) : n : void 0;
	}
	if (n === "sys:DateTime.Now.TimeOfDay") {
		let e = /* @__PURE__ */ new Date();
		return e.getHours() * 36e5 + e.getMinutes() * 6e4 + e.getSeconds() * 1e3 + e.getMilliseconds();
	}
	if (n === "x:True" || n === "True") return !0;
	if (n === "x:False" || n === "False") return !1;
	if (n === "x:Null" || n === "Null") return null;
	let a = n.match(/^([A-Za-z_]\w*):([A-Za-z_]\w*)(\.[\s\S]+)$/);
	if (a && (n = `${a[1]}.${a[2]}${a[3]}`), /^-?\d+(?:\.\d+)?$/.test(n)) return Number(n);
	if (/^'.*'$|^".*"$/.test(n)) return n.slice(1, -1);
	let o = n.match(/^\$?t\(\s*(['"])(.*?)\1\s*\)$/s);
	if (o && typeof (t.$t ?? t.t) == "function") return (t.$t ?? t.t)(o[2]);
	let s = n.match(/^(.*)\.Equals\((x:)?(True|False|Null)\)$/);
	if (s) {
		let e = W(s[1], t), n = W(`${s[2] ?? ""}${s[3]}`, t);
		return F(e) === n;
	}
	let c = n.match(/^(.*)\.ToString\(\)$/);
	if (c) return String(F(W(c[1], t)) ?? "");
	if (n.startsWith("String(") && n.endsWith(")")) return String(F(W(n.slice(7, -1), t)) ?? "");
	if (/^[A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*)*$/.test(n)) {
		let [e, ...r] = U(n), i = t[e];
		for (let e of r) {
			if (i = F(i), i == null) return;
			if (e === "Count" && Array.isArray(i)) {
				i = i.length;
				continue;
			}
			(e === "IsChecked" || e === "Value") && [
				"boolean",
				"number",
				"string"
			].includes(typeof i) || (i = i[e]);
		}
		return F(i);
	}
	if (/[$A-Za-z_(]/.test(n)) try {
		let e = n.replace(/\bx:(True|False|Null)\b/g, (e, t) => t === "True" ? "true" : t === "False" ? "false" : "null"), r = Object.entries(t).filter(([e]) => /^[A-Za-z_$][\w$]*$/.test(e) && !T.has(e)), i = F(Function(...r.map(([e]) => e), `return (${e})`)(...r.map(([, e]) => e)));
		if (i !== void 0) return i;
	} catch {}
	let l = n.match(/^([A-Za-z_$][\w$]*)/);
	if (!l) return;
	let u = t[l[1]];
	n = n.slice(l[0].length);
	for (let e of U(n)) {
		if (u = F(u), u == null) return;
		if (e === "Count" && Array.isArray(u)) {
			u = u.length;
			continue;
		}
		(e === "IsChecked" || e === "Value") && (typeof u == "boolean" || typeof u == "number" || typeof u == "string") || (u = u[e]);
	}
	return F(u);
}, G = (e) => {
	let t = e.trim();
	return /^\$t\s*\(/.test(t) || /^t\s*\(/.test(t) || /^\$\{\s*t\s*\(/.test(t);
}, K = (g, _, v, y = !1) => {
	if (typeof g != "string") return g;
	if (g === "True") return !0;
	if (g === "False") return !1;
	let b = g.trim(), x = z(b);
	if (x) {
		let g = h(x, _);
		if (g !== void 0) return g;
		if (/^\{\s*StaticResource\b/.test(b)) {
			let e = _?.parent?.provides?.[S];
			if (e && Object.prototype.hasOwnProperty.call(e, x)) return F(e[x]);
		}
		return F(_?.provides?.[a])?.[x] ?? t[x] ?? n[x] ?? r[x] ?? i[x] ?? o[x] ?? s[x] ?? c[x] ?? l[x] ?? u[x] ?? d[x] ?? f[x] ?? p[x] ?? m[x] ?? e[x] ?? B[x] ?? ee(x);
	}
	let C = R(g), w = G(b) ? b.replace(/^\$\{\s*/, "").replace(/\s*\}$/, "") : C;
	if (!w.trim() && /^\{\s*(?:x:Bind|Binding)\b/.test(b) && v && Object.prototype.hasOwnProperty.call(v, "item")) return v.item;
	if (w === g && !g.includes("{") && !G(g)) return y ? g : I(g);
	let T;
	try {
		let e = L(_);
		if (v) for (let [t, n] of Object.entries(v)) e[t] = F(n);
		T = W(w, e);
	} catch {
		T = void 0;
	}
	if (T !== void 0 || V(g).converter) {
		let e = H(V(g), T, _);
		return y ? e : I(e);
	}
	if (!(/^\{\s*(?:x:Bind|Binding)\b/.test(g) || G(g))) return y ? g : I(g);
}, q = (e, t, n) => {
	if (!e || typeof e != "object") return e;
	if (Array.isArray(e)) return e.map((e) => q(e, t, n));
	let r = e, i = typeof r.type == "string" ? r.type.split(".").pop()?.replace(/^[A-Z]/, (e) => e.toLowerCase()) : void 0, a = r.type?.__collectionProperty ?? r.type?.__controlExampleProperty ?? r.type?.__swipeProperty ?? i, o = O.get(r), s = r.props ? { ...r.props } : o ? { ...o } : void 0;
	if (s) {
		if (o) for (let [e, t] of Object.entries(o)) typeof t != "string" || !t.includes("{") && !G(t) || (s[e] === void 0 || s[e] === null) && (s[e] = t);
		let e = {
			item: t,
			Item: t
		};
		t && typeof t == "object" && Object.assign(e, t), M(r.type) === "Grid" && s.HorizontalAlignment === void 0 && t && typeof t == "object" && "MsgAlignment" in t && (s.HorizontalAlignment = t.MsgAlignment);
		for (let [i, a] of Object.entries(s)) if (!(i === "key" || i === "ref" || i.startsWith("on"))) {
			if (E.has(i)) {
				s[`on${i}`] = Q(a, n, {
					item: t,
					Item: t,
					...t && typeof t == "object" ? t : {}
				}), delete s[i];
				continue;
			}
			if (typeof a == "string" && (a.includes("{") || G(a))) {
				if ((M(r.type) === "SwipeControl" && [
					"LeftItems",
					"RightItems",
					"TopItems",
					"BottomItems",
					"ContentTemplate"
				].includes(i) || M(r.type) === "SwipeItem" && [
					"IconSource",
					"Background",
					"Foreground"
				].includes(i)) && z(a)) continue;
				s[i] = K(a, n, e, i === "Text");
			}
		}
	}
	if (a === "itemTemplate" || a === "groupHeaderTemplate" || a === "ContentTemplate") return _(r, s, !0);
	let c = r.children;
	if (Array.isArray(c)) c = c.map((e) => q(e, t, n));
	else if (c && typeof c == "object") {
		let e = { ...c };
		for (let [r, i] of Object.entries(e)) typeof i == "function" && (e[r] = (...e) => q(i(...e), t, n));
		c = e;
	}
	let l = _(r, s, !0);
	return l.children = c, l;
}, J = (e, t, n) => y(g, q(e, t, n) ?? []), Y = (e, t, n) => {
	let r = U(e);
	if (!r.length) return;
	let i = n;
	for (; i;) {
		if (Object.prototype.hasOwnProperty.call(i.setupState, r[0])) {
			let e = i.setupState;
			for (let t = 0; t < r.length - 1; t += 1) {
				let n = r[t];
				if (e = F(e[n]), e == null) return;
			}
			let n = r[r.length - 1], a = e, o = a[n];
			b(o) ? o.value = t : b(a) ? a.value = t : a[n] = t;
			return;
		}
		i = i.parent;
	}
	for (i = n; i;) {
		let e = i.provides?.[S];
		if (e && Object.prototype.hasOwnProperty.call(e, r[0])) {
			let n = F(e[r[0]]);
			for (let e = 1; e < r.length - 1; e += 1) if (n = F(n?.[r[e]]), n == null) return;
			let i = r[r.length - 1], a = n;
			if (!a) return;
			let o = a[i];
			b(o) ? o.value = t : a[i] = t;
			return;
		}
		i = i.parent;
	}
	for (i = n?.parent ?? null; i;) {
		let e = i.provides?.[x];
		if (e && Object.prototype.hasOwnProperty.call(e, r[0])) {
			let n = e;
			for (let e = 0; e < r.length - 1; e += 1) if (n = F(n?.[r[e]]), n == null) return;
			let i = n, a = i[r[r.length - 1]];
			b(a) ? a.value = t : i[r[r.length - 1]] = t;
			return;
		}
		i = i.parent;
	}
}, X = (e, t, n) => {
	if (typeof e != "string") return;
	let r = V(e);
	r.twoWay && Y(r.expression, H(r, t, n, !0), n);
}, Z = (e, t, n) => {
	let r = e.trim(), i = W(r, t);
	if (typeof i == "function") return (...e) => i(...e);
	let a = r.match(/^([A-Za-z_$][\w$]*)\((.*)\)$/s);
	if (!a || typeof t[a[1]] != "function") return;
	let o = a[2].trim();
	try {
		let e = Object.entries(t).filter(([e]) => /^[A-Za-z_$][\w$]*$/.test(e) && !T.has(e)), r = o ? Function(...e.map(([e]) => e), "$event", `return [${o}]`)(...e.map(([, e]) => e), n) : [];
		return (...e) => t[a[1]](...r, ...e);
	} catch {
		return (...e) => t[a[1]](...e);
	}
}, Q = (e, t, n) => {
	if (typeof e == "function") return e;
	if (typeof e != "string") return;
	let r = R(e), i = L(t);
	n && Object.assign(i, n);
	let a = r.match(/^([A-Za-z_$][\w$]*)\s*=\s*\$event(?:\.([A-Za-z_$][\w$]*))?(?:\s*(===|!==|==|!=)\s*(['"]?[^\s'"]+['"]?))?$/);
	if (a) return (e) => {
		let n = e;
		if (a[2] && (n = n?.[a[2]]), a[3]) {
			let e = a[4]?.replace(/^['"]|['"]$/g, ""), t = e === "true" ? !0 : e === "false" ? !1 : Number.isNaN(Number(e)) ? e : Number(e);
			n = a[3] === "===" ? n === t : a[3] === "!==" ? n !== t : a[3] === "==" ? n == t : n != t;
		}
		Y(a[1], n, t);
	};
	let o = r.match(/^([A-Za-z_$][\w$]*)\s*=\s*(['"].*['"])$/s);
	return o ? () => Y(o[1], o[2].slice(1, -1), t) : Z(r, i, void 0);
}, $ = (e, t) => {
	if (M(e.type) === "DataTemplate") return e;
	let n = { ...e.props ?? {} }, r = O.get(e) ?? { ...n };
	O.set(e, r);
	for (let [i, a] of Object.entries(r)) if (!(i.startsWith("on") || i === "key" || i === "class" || i === "style")) {
		if (i === "ref" || /^x:name$/i.test(i)) {
			if (typeof a == "string" && a.trim() && (n["data-xaml-ref"] = a.trim()), /^x:name$/i.test(i) && typeof a == "string" && a.trim()) {
				let e = t?.provides?.[S];
				if (e) {
					let t = a.trim(), r = (n) => {
						let r = n.component, i = r?.exposed;
						if (i) {
							if (i[C]) {
								e[t] !== i && (e[t] = i);
								return;
							}
							let n = A.get(i);
							n || (n = new Proxy(i, {
								get(e, t, r) {
									return t === "ClearValue" && !Reflect.has(e, t) ? (e) => e?.ClearValue?.(n) : F(Reflect.get(e, t, r));
								},
								set(e, t, n, r) {
									let i = Reflect.get(e, t, r);
									return b(i) && !b(n) ? (i.value = n, !0) : Reflect.set(e, t, n, r);
								}
							}), A.set(i, n)), e[t] !== n && (e[t] = n);
							return;
						}
						e[t] = r?.exposeProxy ?? r?.proxy ?? n.el ?? void 0;
					}, i = n.onVnodeMounted, o = n.onVnodeUpdated, s = n.onVnodeBeforeUnmount;
					n.onVnodeMounted = (e) => {
						typeof i == "function" && i(e), r(e);
					}, n.onVnodeUpdated = (e, t) => {
						typeof o == "function" && o(e, t), r(e);
					}, n.onVnodeBeforeUnmount = (n) => {
						typeof s == "function" && s(n), delete e[t];
					};
				}
			}
			/^x:name$/i.test(i) && delete n[i];
			continue;
		}
		if (E.has(i)) {
			let o = {
				PointerMoved: "onPointermove",
				PointerPressed: "onPointerdown",
				PointerReleased: "onPointerup",
				PointerEntered: "onPointerenter",
				PointerExited: "onPointerleave",
				PointerCanceled: "onPointercancel",
				PointerCaptureLost: "onLostpointercapture",
				GotFocus: "onFocusin",
				LostFocus: "onFocusout",
				KeyDown: "onKeydown",
				KeyUp: "onKeyup"
			}, s = ["GridView", "ListView"].includes(M(e.type)) && ["GotFocus", "LostFocus"].includes(i), c = s || typeof e.type == "string" || [
				"Border",
				"Grid",
				"StackPanel",
				"Line",
				"Polyline",
				"Path"
			].includes(M(e.type)), l = i === "Click" && M(e.type) === "Button", u = l ? i : c && o[i] ? o[i] : D(i);
			n[u] = (...n) => {
				let o = Q(a, t, t?.provides?.[S]);
				if (s) return o?.(e.component?.exposeProxy ?? e.component?.proxy, n[0]);
				let c = t?.provides?.[S], l = String(r["x:Name"] ?? r["x:name"] ?? ""), u = c?.[l] ?? e.component?.exposeProxy ?? e.component?.proxy;
				return [
					"TextBox",
					"PasswordBox",
					"AutoSuggestBox",
					"RichEditBox",
					"RichTextBlock"
				].includes(M(e.type)) && n.length < 2 ? o?.(u, n[0] ?? {
					OriginalSource: u,
					Handled: !1
				}) : i === "ValueChanged" && M(e.type) === "NumberBox" && n.length === 1 ? o?.(u, n[0]) : i === "ValueChanged" && M(e.type) === "Slider" && l && c?.[l] && n.length >= 2 || i === "SelectionChanged" && M(e.type) === "ComboBox" && l && c?.[l] && n.length >= 2 ? o?.(u, ...n.slice(1)) : o?.(...n);
			}, l || delete n[i];
			continue;
		}
		if (typeof a == "string" && a.startsWith("{")) {
			let r = V(a), o = K(a, t, t?.provides?.[S]);
			if (/^RelativePanel\./.test(i) && o && typeof o == "object") {
				let e = o.$el ?? o, t = typeof e.getAttribute == "function" ? e.getAttribute("data-xaml-ref") : void 0;
				t && (o = t);
			}
			let s = z(a) && [
				"ItemTemplate",
				"GroupHeaderTemplate",
				"MenuItemTemplate",
				"MenuItemTemplateSelector",
				"MenuItemContainerStyle",
				"MenuItemContainerStyleSelector",
				"HeaderTemplate",
				"PaneToggleButtonStyle",
				"Command",
				"Flyout",
				"ItemContainerStyle"
			].includes(i), c = z(a) && [
				"Background",
				"PaneBackground",
				"Fill",
				"Stroke",
				"Shadow"
			].includes(i) && j.has(M(e.type)), l = z(a) && [
				"CalendarView",
				"CalendarDatePicker",
				"DatePicker",
				"TimePicker"
			].includes(M(e.type)) && [
				"Style",
				"HeaderTemplate",
				"CalendarViewStyle"
			].includes(i), u = z(a) && (M(e.type) === "InfoBadge" && i === "Style" || M(e.type) === "InfoBar" && i === "CloseButtonStyle"), d = z(a) && M(e.type) === "Flyout" && i === "FlyoutPresenterStyle", f = z(a) && M(e.type) === "ScrollViewer" && i === "Template", p = z(a) && ["Pivot", "PivotItem"].includes(M(e.type)) && [
				"TitleTemplate",
				"HeaderTemplate",
				"LeftHeaderTemplate",
				"RightHeaderTemplate",
				"ContentTemplate",
				"ItemTemplate"
			].includes(i), m = z(a) && ["TabView", "TabViewItem"].includes(M(e.type)) && [
				"TabItemTemplate",
				"TabItemTemplateSelector",
				"TabStripHeaderTemplate",
				"TabStripFooterTemplate",
				"HeaderTemplate",
				"ContentTemplate",
				"IconSource",
				"ContextFlyout",
				"ToolTipService.ToolTip"
			].includes(i), h = z(a) && M(e.type) === "PipsPager" && [
				"PreviousButtonStyle",
				"NextButtonStyle",
				"SelectedPipStyle",
				"NormalPipStyle"
			].includes(i), g = z(a) && (M(e.type) === "Image" && i === "Source" || M(e.type) === "PersonPicture" && ["ProfilePicture", "BadgeImageSource"].includes(i) || ["BitmapImage", "SvgImageSource"].includes(M(e.type)) && i === "UriSource"), _ = z(a) && (M(e.type) === "SwipeControl" && [
				"LeftItems",
				"RightItems",
				"TopItems",
				"BottomItems",
				"ContentTemplate"
			].includes(i) || M(e.type) === "SwipeItem" && [
				"IconSource",
				"Background",
				"Foreground"
			].includes(i)), v = !!(e.type?.__collectionProperty || e.type?.__navigationProperty || e.type?.__tabViewProperty || e.type?.__swipeProperty);
			n[i] = c || v || l || u || d || f || p || m || h || g || _ ? a : typeof e.type == "string" || /^(Grid|Canvas|RelativePanel)\./.test(i) || z(a) && !s || !j.has(M(e.type)) ? o : a, r.twoWay && !i.includes(".") && (n[`onUpdate:${i}`] = (e) => X(a, e, t));
		}
		if (typeof e.type == "string" && (i === "Background" || i === "BorderBrush" || i === "Foreground")) {
			let e = K(a, t), r = typeof n.style == "object" && n.style !== null ? { ...n.style } : {};
			i === "Background" && (r.background = e), i === "BorderBrush" && (r.borderColor = e), i === "Foreground" && (r.color = e), n.style = r, delete n[i];
		}
		typeof e.type == "string" && i === "Source" && (n.src = K(a, t), delete n[i]);
	}
	if (Array.isArray(e.children) && (e.children = e.children.map((e) => e && typeof e == "object" && "type" in e ? $(e, t) : e)), e.children && typeof e.children == "object" && !Array.isArray(e.children)) {
		let n = { ...e.children };
		for (let [e, r] of Object.entries(n)) typeof r == "function" && (n[e] = (...e) => {
			let n = r(...e);
			return Array.isArray(n) ? n.map((e) => e && typeof e == "object" && "type" in e ? $(e, t) : e) : n;
		});
		e.children = n;
	}
	return e.props = Object.keys(n).length || e.props ? n : e.props, e;
}, te = (e, t) => {
	if (!(typeof e != "string" || !e.trim())) try {
		let n = L(t), r = e.trim();
		return Object.prototype.hasOwnProperty.call(n, r) ? n[r] : void 0;
	} catch {
		return;
	}
}, ne = (e, t = v()) => e.map((e) => $(e, t));
//#endregion
export { k as cloneXamlVNodeWithDefaults, E as eventNames, q as materializeXamlVNode, ne as normalizeXamlNodes, $ as normalizeXamlVNode, Q as resolveXamlHandler, te as resolveXamlResourceObject, K as resolveXamlValue, X as updateXamlBinding, I as xamlColor, C as xamlControlIdentityKey, w as xamlItemContextKey, S as xamlNameScopeKey, x as xamlScopeKey, J as xamlTemplateComponent };

//# sourceMappingURL=xamlRuntime.js.map