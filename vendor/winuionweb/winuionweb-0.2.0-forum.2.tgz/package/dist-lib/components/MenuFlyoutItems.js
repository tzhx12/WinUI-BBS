import { __exportAll as e } from "../_virtual/_rolldown/runtime.js";
import { cssLength as t, xamlThickness as n } from "./layout.js";
import { materializeXamlVNode as r, normalizeXamlNodes as i, resolveXamlHandler as a, resolveXamlValue as o, updateXamlBinding as s, xamlItemContextKey as ee, xamlScopeKey as te } from "./xamlRuntime.js";
import { frameworkLayoutStyle as ne } from "./frameworkLayout.js";
import c from "./SymbolIcon.vue.js";
import { useUICommand as re } from "./uiCommandRuntime.js";
import { getVNodeChildren as ie } from "./CollectionProperties.js";
import ae from "./TextBlock.vue.js";
import oe from "./FontIcon.vue.js";
import { menuFlyoutPresenterContextKey as se } from "./menuFlyoutContext.js";
import ce from "./MenuFlyoutPresenter.js";
/* empty css                        */
import { Fragment as le, computed as l, defineComponent as u, getCurrentInstance as ue, h as d, inject as f, isVNode as de, onBeforeUnmount as fe, onMounted as pe, proxyRefs as me, ref as p, shallowReactive as he, watch as m } from "vue";
//#region src/components/MenuFlyoutItems.ts
var h = /* @__PURE__ */ e({
	KeyboardAccelerator: () => ve,
	MenuFlyoutItem: () => C,
	MenuFlyoutItemIcon: () => _,
	MenuFlyoutItemKeyboardAccelerators: () => v,
	MenuFlyoutItemsProperty: () => ge,
	MenuFlyoutPresenterStyleProperty: () => _e,
	MenuFlyoutSeparator: () => O,
	MenuFlyoutSubItem: () => E,
	MenuFlyoutSubItemItems: () => y,
	RadioMenuFlyoutItem: () => T,
	SplitMenuFlyoutItem: () => D,
	ToggleMenuFlyoutItem: () => w
}), g = (e, t) => u({
	name: `${t === "flyout" ? "MenuFlyout" : "MenuFlyoutItem"}.${e}`,
	...t === "flyout" ? { __menuFlyoutProperty: e } : { __menuFlyoutItemProperty: e },
	setup() {
		return () => null;
	}
}), ge = g("Items", "flyout"), _e = g("MenuFlyoutPresenterStyle", "flyout"), _ = g("Icon", "item"), v = g("KeyboardAccelerators", "item"), y = g("Items", "item"), ve = u({
	name: "KeyboardAccelerator",
	__keyboardAccelerator: !0,
	props: {
		Key: {
			type: String,
			default: ""
		},
		Modifiers: {
			type: [String, Array],
			default: ""
		},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		}
	},
	setup() {
		return () => null;
	}
}), b = {
	Text: {
		type: [String, Number],
		default: void 0
	},
	Icon: {
		type: null,
		default: void 0
	},
	Tag: {
		type: null,
		default: void 0
	},
	DataContext: {
		type: null,
		default: void 0
	},
	Command: {
		type: null,
		default: void 0
	},
	CommandParameter: {
		type: null,
		default: void 0
	},
	IsEnabled: {
		type: [Boolean, String],
		default: !0
	},
	IsChecked: {
		type: [Boolean, String],
		default: !1
	},
	GroupName: {
		type: String,
		default: ""
	},
	KeyboardAccelerators: {
		type: [Array, String],
		default: void 0
	},
	KeyboardAcceleratorTextOverride: {
		type: String,
		default: ""
	},
	KeyboardAcceleratorPlacementMode: {
		type: String,
		default: "Hidden"
	},
	PreventDismissOnPointer: {
		type: [Boolean, String],
		default: !1
	},
	Items: {
		type: [Array, String],
		default: void 0
	},
	Foreground: {
		type: [String, Object],
		default: ""
	},
	Background: {
		type: [String, Object],
		default: ""
	},
	BorderBrush: {
		type: [String, Object],
		default: ""
	},
	BorderThickness: {
		type: [String, Number],
		default: 0
	},
	Padding: {
		type: [String, Number],
		default: ""
	},
	CornerRadius: {
		type: [String, Number],
		default: ""
	},
	FontFamily: {
		type: String,
		default: ""
	},
	FontSize: {
		type: [String, Number],
		default: ""
	},
	FontWeight: {
		type: [String, Number],
		default: ""
	},
	HorizontalContentAlignment: {
		type: String,
		default: "Stretch"
	},
	VerticalContentAlignment: {
		type: String,
		default: "Center"
	},
	Width: {
		type: [String, Number],
		default: ""
	},
	Height: {
		type: [String, Number],
		default: ""
	},
	MinWidth: {
		type: [String, Number],
		default: 0
	},
	MinHeight: {
		type: [String, Number],
		default: 0
	},
	MaxWidth: {
		type: [String, Number],
		default: ""
	},
	MaxHeight: {
		type: [String, Number],
		default: ""
	},
	Margin: {
		type: [String, Number],
		default: ""
	},
	HorizontalAlignment: {
		type: String,
		default: "Stretch"
	},
	VerticalAlignment: {
		type: String,
		default: "Stretch"
	},
	FlowDirection: {
		type: String,
		default: ""
	},
	Visibility: {
		type: String,
		default: "Visible"
	},
	IsTabStop: {
		type: [Boolean, String],
		default: !0
	}
}, x = (e) => e !== !1 && e !== "False", ye = /* @__PURE__ */ new Set(), be = (e) => e.type?.__menuFlyoutItemProperty, xe = (e) => Array.isArray(e) ? e.filter(de) : de(e) ? [e] : [], S = (e) => Object.assign(u({
	name: e,
	__menuFlyoutItem: !0,
	__menuFlyoutItemKind: e,
	inheritAttrs: !1,
	props: b,
	emits: [
		"Click",
		"Checked",
		"Unchecked",
		...Object.keys(b).map((e) => `update:${e}`)
	],
	setup(u, { attrs: h, slots: g, emit: ge, expose: _e }) {
		let _ = ue(), v = f(se, null), y = f(te, {}), ve = f(ee, void 0), S = p(null), C = p(null), w = p(!1), T = p(!1), E = p(null), D = p(!1), O = he({}), k = (e) => o(e, _), A = (e) => e in O ? O[e] : k(u[e]), j = (e, t) => {
			O[e] = t, s(u[e], t, _), ge(`update:${e}`, t);
		}, M = Object.fromEntries(Object.keys(b).map((e) => [e, l({
			get: () => A(e),
			set: (t) => j(e, t)
		})]));
		for (let e of Object.keys(b)) m(() => k(u[e]), () => {
			delete O[e];
		});
		let N = re(() => A("Command")), P = l(() => String(A("Text") ?? N.value?.Label ?? "")), Se = l(() => A("Visibility") !== "Collapsed"), F = l(() => x(A("IsEnabled")) && (N.value?.CanExecute?.(A("CommandParameter")) ?? !0) !== !1), I = l(() => x(A("IsChecked"))), Ce = l(() => String(A("GroupName") ?? "")), L = e === "ToggleMenuFlyoutItem", R = e === "RadioMenuFlyoutItem", z = e === "MenuFlyoutSubItem" || e === "SplitMenuFlyoutItem", B = e === "SplitMenuFlyoutItem", we = l(() => {
			if (B) return F.value ? D.value && !C.value?.IsDelayCloseTimerRunning ? "SubMenuOpened" : T.value && E.value ? E.value === "primary" ? "PrimaryPressed" : "SecondaryPressed" : w.value && E.value ? E.value === "primary" ? "PrimaryPointerOver" : "SecondaryPointerOver" : "Normal" : "Disabled";
		}), Te = l(() => g.default?.() ?? []), Ee = (e) => ie(Te.value.find((t) => be(t) === e) ?? { children: [] }), De = l(() => i(Ee("Icon"), _).map((e) => r(e, ve, _))), Oe = l(() => De.value.length > 0 || !!A("Icon") || !!N.value?.IconSource), ke = l(() => {
			let e = Ee("KeyboardAccelerators");
			if (e.length) return e.map((e) => Object.fromEntries(Object.entries(e.props ?? {}).map(([e, t]) => [e, k(t)])));
			let t = A("KeyboardAccelerators") ?? N.value?.KeyboardAccelerators;
			return Array.isArray(t) ? t : [];
		}), Ae = (e) => new Set(Array.isArray(e) ? e.map(String) : String(e ?? "").split(/[,+\s]+/).filter(Boolean)), je = l(() => {
			let e = A("KeyboardAcceleratorTextOverride");
			if (e) return String(e);
			let t = ke.value.find((e) => x(e.IsEnabled ?? !0));
			if (!t) return "";
			let n = Ae(t.Modifiers);
			return [
				...n.has("Control") ? ["Ctrl"] : [],
				...n.has("Shift") ? ["Shift"] : [],
				...n.has("Menu") || n.has("Alt") ? ["Alt"] : [],
				...n.has("Windows") ? ["Win"] : [],
				String(t.Key ?? "")
			].join("+");
		}), Me = l(() => {
			let e = F.value ? T.value ? "Pressed" : w.value ? "PointerOver" : "" : "Disabled";
			return `var(--${L || R ? "ToggleMenuFlyoutItem" : "MenuFlyoutItem"}KeyboardAcceleratorTextForeground${e}, var(--${F.value ? "text-secondary" : "text-disabled"}))`;
		}), V, H = null, U = null, W = !1, G = null, K = () => {
			V !== void 0 && window.clearTimeout(V), V = void 0;
		}, q = () => {
			T.value = !1, w.value = !1, E.value = null, H = null, U = null, G = null, K();
		}, J = (e = !1) => {
			K(), C.value?.Hide(e), D.value = !1;
		}, Y = async (e = !1) => {
			!F.value || !z || !S.value || (K(), v?.CloseSiblings(Z), await C.value?.ShowAt(S.value, {
				Placement: "Right",
				AllowFocusOnInteraction: e
			}));
		}, Ne = l({
			get: () => A("DataContext") ?? ve ?? y.DataContext?.value ?? y.DataContext ?? y.Item?.value ?? y.Item ?? y.item?.value ?? y.item,
			set: (e) => j("DataContext", e)
		}), Pe = l(() => String(k(h["x:Name"] ?? h.Name ?? h["data-xaml-ref"] ?? _?.vnode.props?.["x:Name"] ?? "") ?? "")), Fe = () => (B ? S.value?.querySelector(".win-menu-flyout-split-primary") : S.value)?.focus({ preventScroll: !0 }), Ie = l({
			get: () => C.value?.Items ?? [],
			set: (e) => j("Items", e)
		}), X = me({
			...M,
			Name: Pe,
			Items: z ? Ie : M.Items,
			DataContext: Ne,
			Element: S,
			Focus: Fe
		}), Le = (e, t = {}) => {
			let n = _?.vnode.props?.[`on${e}`];
			for (let e of Array.isArray(n) ? n : n ? [n] : []) typeof e == "function" && e(X, t);
			a(h[e], _)?.(X, t);
		}, Re = (e) => {
			I.value !== e && (j("IsChecked", e), Le(e ? "Checked" : "Unchecked", {
				OriginalSource: X,
				Handled: !1
			}));
		}, ze = () => {
			!R || !I.value || ye.forEach((e) => {
				e !== Z && e.GroupName.value === Ce.value && e.SetChecked(!1);
			});
		}, Be = (e) => {
			if (!(!F.value || !Se.value)) {
				if (z && !B) {
					Y(e instanceof KeyboardEvent);
					return;
				}
				L && Re(!I.value), R && (Re(!0), ze()), Le("Click", {
					OriginalSource: X,
					Handled: !1
				}), N.value?.Execute?.(A("CommandParameter")), q(), x(A("PreventDismissOnPointer")) || v?.Dismiss();
			}
		}, Z = {
			Element: S,
			IsEnabled: F,
			IsVisible: Se,
			HasIcon: Oe,
			IsCheckItem: L || R,
			IsRadioItem: R,
			GroupName: Ce,
			IsChecked: I,
			Text: P,
			AcceleratorText: je,
			SetChecked: Re,
			Invoke: Be,
			OpenSubmenu: (e) => {
				Y(e);
			},
			CloseSubmenu: J,
			ClearPointer: q,
			Focus: Fe,
			HasSubmenu: z,
			Api: X,
			MatchesAccelerator(e) {
				return ke.value.some((t) => {
					let n = Ae(t.Modifiers), r = String(t.Key ?? ""), i = r === "Space" ? " " : r === "Back" ? "Backspace" : r;
					return x(t.IsEnabled ?? !0) && i.toLowerCase() === e.key.toLowerCase() && e.ctrlKey === n.has("Control") && e.shiftKey === n.has("Shift") && e.altKey === (n.has("Menu") || n.has("Alt")) && e.metaKey === n.has("Windows");
				});
			}
		}, Q = (e, t = !0) => {
			!F.value || !v?.CanHover(e) || (w.value = !0, B && (E.value = t ? "secondary" : "primary"), v.CancelPendingClose(), B && (t ? C.value?.CancelPendingClose?.() : (K(), D.value && C.value?.DelayClose?.())), z && t && !D.value && V === void 0 && (V = window.setTimeout(() => {
				Y();
			}, 400)), (!z || !t) && v.CloseSiblings(Z));
		}, Ve = (e) => {
			e.pointerType === "touch" && (w.value = !1), !(!F.value || e.button !== 0) && (B && (E.value = e.target?.closest(".win-menu-flyout-split-secondary") ? "secondary" : "primary"), W = !1, T.value = !0, H = e.pointerId, U = {
				x: e.clientX,
				y: e.clientY
			});
		}, He = (e, t = !0) => {
			H === e.pointerId && e.pointerType === "touch" && U && Math.hypot(e.clientX - U.x, e.clientY - U.y) > 10 && (T.value = !1, W = !0), Q(e, t);
		}, Ue = () => {
			W = !0, q();
		}, $ = () => {
			q(), D.value && C.value?.DelayClose?.();
		}, We = (e, t = !1) => {
			if (W) {
				W = !1, e.preventDefault();
				return;
			}
			if (t) {
				if (!F.value) return;
				D.value ? J() : Y(!1);
			} else Be(e);
		}, Ge = (e, t = !1) => {
			if (B && F.value) {
				let n = v?.FlowDirection.value === "rtl" ? "ArrowLeft" : "ArrowRight", r = v?.FlowDirection.value === "rtl" ? "ArrowRight" : "ArrowLeft";
				if (!t && [n, "ArrowDown"].includes(e.key) || t && [r, "ArrowUp"].includes(e.key)) {
					e.preventDefault(), e.stopPropagation(), G = null, T.value = !1, S.value?.querySelector(t ? ".win-menu-flyout-split-primary" : ".win-menu-flyout-split-secondary")?.focus({ preventScroll: !0 });
					return;
				}
			}
			if (!["Enter", " "].includes(e.key)) {
				G = null, T.value = !1;
				return;
			}
			if (F.value && (e.preventDefault(), e.stopPropagation(), !e.repeat)) {
				if (t || z && !B) {
					Y(!0);
					return;
				}
				G = e.key, B && (E.value = t ? "secondary" : "primary"), T.value = !0;
			}
		}, Ke = (e) => {
			if (!["Enter", " "].includes(e.key)) return;
			e.preventDefault(), e.stopPropagation();
			let t = G === e.key && T.value && H === null;
			G = null, T.value = !1, t && Be(e);
		}, qe = l(() => ({
			...ne(Object.fromEntries(Object.keys(b).map((e) => [e, A(e)])), _),
			padding: n(A("Padding") || (v?.NarrowPadding.value === !1 ? "11,8,11,9" : "11,4,11,5")),
			fontFamily: A("FontFamily") || void 0,
			fontSize: A("FontSize") ? t(A("FontSize")) : void 0,
			fontWeight: A("FontWeight") || void 0,
			borderRadius: A("CornerRadius") ? t(A("CornerRadius")) : void 0,
			borderWidth: n(A("BorderThickness")),
			borderColor: A("BorderBrush") || void 0,
			"--menu-item-background": A("Background") || void 0,
			"--menu-item-foreground": A("Foreground") || void 0
		})), Je = () => {
			if (De.value.length) return De.value;
			let e = A("Icon") ?? N.value?.IconSource;
			if (de(e)) return [e];
			if (e && typeof e == "object") {
				let t = e;
				return [t.Glyph ? d(oe, {
					Glyph: t.Glyph,
					FontSize: 20
				}) : d(c, {
					Symbol: t.Symbol ?? "",
					FontSize: 20
				})];
			}
			return e ? [d(c, {
				Symbol: String(e),
				FontSize: 20
			})] : [];
		}, Ye = () => [v?.ContainsCheckItems.value ? d("span", {
			class: ["win-menu-flyout-check-slot", { "is-checked": I.value && (L || R) }],
			"aria-hidden": !0
		}, L || R ? [d(oe, {
			Glyph: R ? "" : "",
			FontSize: 12,
			Foreground: "inherit"
		})] : void 0) : null, v?.ContainsIconItems.value ? d("span", {
			class: "win-menu-flyout-icon-viewbox",
			"aria-hidden": !0
		}, d("span", { class: "win-menu-flyout-icon-content" }, Je())) : null], Xe = () => [
			...Ye(),
			d(ae, {
				class: "win-menu-flyout-label",
				Text: P.value,
				Foreground: "inherit",
				FontFamily: "inherit",
				FontSize: "inherit",
				FontWeight: "inherit",
				LineHeight: 20,
				TextTrimming: "Clip",
				TextWrapping: "NoWrap"
			}),
			z ? d(oe, {
				class: "win-menu-flyout-chevron",
				Glyph: "",
				FontFamily: "{ThemeResource SymbolThemeFontFamily}",
				FontSize: 12,
				Margin: "{StaticResource MenuFlyoutItemChevronMargin}",
				MirroredWhenRightToLeft: "True",
				Foreground: "inherit",
				"aria-hidden": !0
			}) : je.value ? d(ae, {
				class: ["win-menu-flyout-accelerator", { "is-toggle-accelerator": L || R }],
				Text: je.value,
				FontFamily: "var(--ContentControlThemeFontFamily, Segoe UI Variable, Segoe UI, sans-serif)",
				FontSize: 12,
				FontWeight: "Normal",
				LineHeight: 16,
				Margin: L || R ? "24,0,0,0" : "24,4,0,0",
				MinWidth: v?.AcceleratorMinWidth.value ?? 0,
				Foreground: Me.value,
				"aria-hidden": !0
			}) : null
		], Ze = l(() => {
			let e = Ee("Items");
			return i(e.length ? e : u.Items === void 0 ? Te.value.filter((e) => !be(e)) : xe(A("Items")), _);
		}), Qe = {
			Options: () => v?.Options() ?? {},
			Raise: (e) => {
				e === "Opened" && (D.value = !0), (e === "Closing" || e === "Closed") && (D.value = !1);
			}
		};
		return pe(() => {
			v?.Register(Z), R && ye.add(Z), ze();
		}), fe(() => {
			K(), v?.Unregister(Z), ye.delete(Z);
		}), m([I, Ce], ze), m(F, (e) => {
			e || (S.value?.contains(document.activeElement) && v?.FocusRelative(Z, 1), q(), J());
		}), m(Se, (e) => {
			e || (S.value?.contains(document.activeElement) && v?.FocusRelative(Z, 1), q(), J());
		}), m(() => v?.IsOpen.value, (e) => {
			e || (q(), J());
		}), _e({
			...M,
			Name: Pe,
			Items: z ? Ie : M.Items,
			DataContext: Ne,
			Element: S,
			Focus: Fe
		}), () => d(le, [d(B ? "div" : "button", {
			ref: S,
			class: [
				"win-menu-flyout-item",
				h.class,
				{
					"is-pointer-over": !B && w.value,
					"is-pressed": !B && T.value,
					"is-disabled": !F.value,
					"is-checked": I.value,
					"is-open": D.value,
					"is-split": B,
					"is-subitem": z && !B,
					"is-toggle": L,
					"is-radio": R
				}
			],
			"data-visual-state": we.value,
			style: [h.style, qe.value],
			type: B ? void 0 : "button",
			role: R ? "menuitemradio" : L ? "menuitemcheckbox" : "menuitem",
			tabindex: x(A("IsTabStop")) ? -1 : void 0,
			disabled: B ? void 0 : !F.value,
			"aria-disabled": !F.value || void 0,
			"aria-checked": R || L ? I.value : void 0,
			"aria-haspopup": z ? "menu" : void 0,
			"aria-expanded": z ? D.value : void 0,
			"aria-label": k(h["AutomationProperties.Name"]) || void 0,
			dir: A("FlowDirection") === "RightToLeft" ? "rtl" : void 0,
			onPointerenter: B ? void 0 : (e) => Q(e),
			onPointermove: B ? void 0 : (e) => He(e),
			onPointerleave: $,
			onPointerdown: Ve,
			onPointerup: () => {
				T.value = !1, H = null, U = null;
			},
			onPointercancel: Ue,
			onLostpointercapture: () => {
				H !== null && Ue();
			},
			onClick: B ? void 0 : We,
			onKeydown: B ? void 0 : Ge,
			onKeyup: B ? void 0 : Ke,
			onBlur: () => {
				G = null, T.value = !1;
			}
		}, B ? [
			d("button", {
				class: "win-menu-flyout-split-primary",
				type: "button",
				tabindex: -1,
				disabled: !F.value,
				"aria-label": P.value,
				onClick: (e) => We(e),
				onKeydown: (e) => Ge(e),
				onKeyup: Ke,
				onPointerenter: (e) => {
					e.stopPropagation(), Q(e, !1);
				},
				onPointermove: (e) => {
					e.stopPropagation(), He(e, !1);
				},
				onPointerleave: $
			}),
			d("span", {
				class: "win-menu-flyout-split-divider",
				"aria-hidden": !0
			}),
			d("button", {
				class: "win-menu-flyout-split-secondary",
				type: "button",
				tabindex: -1,
				disabled: !F.value,
				"aria-label": P.value,
				"aria-haspopup": "menu",
				"aria-expanded": D.value,
				onClick: (e) => We(e, !0),
				onKeydown: (e) => Ge(e, !0),
				onPointerenter: (e) => {
					e.stopPropagation(), Q(e, !0);
				},
				onPointermove: (e) => {
					e.stopPropagation(), He(e, !0);
				},
				onPointerleave: $
			}),
			d("div", {
				class: "win-menu-flyout-split-content",
				"aria-hidden": !0
			}, Xe())
		] : Xe()), z ? d(ce, {
			ref: C,
			Owner: Qe,
			IsSubmenu: !0
		}, { default: () => Ze.value }) : null]);
	}
}), {
	Icon: _,
	KeyboardAccelerators: v,
	Items: y
}), C = S("MenuFlyoutItem"), w = S("ToggleMenuFlyoutItem"), T = S("RadioMenuFlyoutItem"), E = S("MenuFlyoutSubItem"), D = S("SplitMenuFlyoutItem"), O = u({
	name: "MenuFlyoutSeparator",
	__menuFlyoutItem: !0,
	__menuFlyoutItemKind: "MenuFlyoutSeparator",
	inheritAttrs: !1,
	props: {
		Background: {
			type: String,
			default: ""
		},
		Padding: {
			type: [String, Number],
			default: "-4,1,-4,1"
		},
		Margin: {
			type: [String, Number],
			default: ""
		},
		Visibility: {
			type: String,
			default: "Visible"
		}
	},
	setup(e, { attrs: t, expose: r }) {
		let i = ue(), a = f(se, null), s = p(null), ee = l(() => o(e.Visibility, i) !== "Collapsed"), te = l(() => {
			let t = n(o(e.Margin, i)) || "0px", r = t.split(/\s+/), a = r[0];
			return {
				margin: t,
				minHeight: `max(0px, calc(0px - (${a}) - (${r[2] ?? a})))`,
				display: ee.value ? void 0 : "none"
			};
		}), ne = me({
			Element: s,
			Background: l(() => o(e.Background, i)),
			Visibility: l(() => o(e.Visibility, i))
		}), c = {
			Element: s,
			IsEnabled: l(() => !1),
			IsVisible: ee,
			HasIcon: l(() => !1),
			IsCheckItem: !1,
			IsRadioItem: !1,
			GroupName: l(() => ""),
			IsChecked: l(() => !1),
			Text: l(() => ""),
			AcceleratorText: l(() => ""),
			SetChecked() {},
			Invoke() {},
			MatchesAccelerator: () => !1,
			OpenSubmenu() {},
			CloseSubmenu() {},
			ClearPointer() {},
			Focus() {},
			HasSubmenu: !1,
			Api: ne
		};
		return pe(() => a?.Register(c)), fe(() => a?.Unregister(c)), r({
			Element: s,
			Background: l(() => o(e.Background, i)),
			Visibility: l(() => o(e.Visibility, i))
		}), () => d("div", {
			ref: s,
			class: ["win-menu-flyout-separator", t.class],
			role: "separator",
			style: [t.style, te.value]
		}, d("div", {
			class: "win-menu-flyout-separator-line",
			style: {
				margin: n(o(e.Padding, i)),
				background: o(e.Background, i) || void 0
			}
		}));
	}
});
//#endregion
export { C as MenuFlyoutItem, _ as MenuFlyoutItemIcon, v as MenuFlyoutItemKeyboardAccelerators, ge as MenuFlyoutItemsProperty, h as MenuFlyoutItems_exports, _e as MenuFlyoutPresenterStyleProperty, O as MenuFlyoutSeparator, y as MenuFlyoutSubItemItems };

//# sourceMappingURL=MenuFlyoutItems.js.map