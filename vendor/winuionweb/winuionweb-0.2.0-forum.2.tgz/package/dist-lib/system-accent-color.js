import { connectSystemAccentColorHost as e, createBrowserSystemAccentColorHostAdapter as t } from "./components/systemAccentColorHostAdapter.js";
export { e as connectSystemAccentColorHost, t as createBrowserSystemAccentColorHostAdapter };
