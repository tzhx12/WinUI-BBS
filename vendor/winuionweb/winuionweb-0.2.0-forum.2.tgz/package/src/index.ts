import type { App } from 'vue'
import { registerWinUIComponents } from './components/register'
import { installPointerInput } from './components/pointerInput'
import { createI18n, i18nKey, type I18n } from './components/i18n'
import './styles/theme.css'
import './styles/buttonResources.css'
import './styles/dropDownButtonResources.css'
import './styles/pivot.css'
import './styles/swipe.css'
import './styles/animations.css'
import './styles/icons.css'

// Named component imports need the same input policy as the global plugin.
installPointerInput()

export interface WinUIOnWebOptions {
  locale?: string
  i18n?: I18n
}

export const WinUIOnWeb = {
  install(app: App, options: WinUIOnWebOptions = {}): void {
    registerWinUIComponents(app)
    const locale = options.locale ?? (typeof navigator === 'undefined' ? 'en-US' : navigator.language)
    const i18n = options.i18n ?? createI18n(locale)
    app.provide(i18nKey, i18n)
    app.config.globalProperties.$t = i18n.t
  }
}

export default WinUIOnWeb
export { registerWinUIComponents }
export { DataTemplate } from './components/CollectionProperties'
export { MenuFlyoutItem, MenuFlyoutSeparator } from './components/MenuFlyoutItems'
export { createI18n, i18nKey, normalizeLocale, useI18n } from './components/i18n'
export type { I18n, Locale, ResourceBundle, ResourceMap } from './components/i18n'
export { xamlNameScopeKey, xamlScopeKey } from './components/xamlRuntime'
export { loadWinUIIconFont } from './components/iconFont'
export type { WinUIIconFontSource } from './components/iconFont'
export { connectSystemAccentColorHost, createBrowserSystemAccentColorHostAdapter } from './systemAccentColor'
export type { SystemAccentColorHostAdapter, SystemAccentColorHostTarget, SystemAccentColorPalette } from './systemAccentColor'

// Named exports support local registration and TypeScript-aware imports.
export { default as AnimatedIcon } from './components/AnimatedIcon.vue'
export { default as AnimatedVisualPlayer } from './components/AnimatedVisualPlayer.vue'
export { default as AnnotatedScrollBar } from './components/AnnotatedScrollBar.vue'
export { default as AppBarButton } from './components/AppBarButton.vue'
export { default as AppBarSeparator } from './components/AppBarSeparator.vue'
export { default as AppBarToggleButton } from './components/AppBarToggleButton.vue'
export { default as AutoSuggestBox } from './components/AutoSuggestBox.vue'
export { default as BitmapIcon } from './components/BitmapIcon.vue'
export { default as BitmapImage } from './components/BitmapImage.vue'
export { default as Border } from './components/Border.vue'
export { default as BreadcrumbBar } from './components/BreadcrumbBar.vue'
export { default as BreadcrumbBarItem } from './components/BreadcrumbBarItem.vue'
export { default as Button } from './components/Button.vue'
export { default as CalendarDatePicker } from './components/CalendarDatePicker.vue'
export { default as CalendarView } from './components/CalendarView.vue'
export { default as Canvas } from './components/Canvas.vue'
export { default as CaptureElement } from './components/CaptureElement.vue'
export { default as Case } from './components/Case.vue'
export { default as CheckBox } from './components/CheckBox.vue'
export { default as ColorPicker } from './components/ColorPicker.vue'
export { default as ColumnDefinition } from './components/ColumnDefinition.vue'
export { default as ComboBox } from './components/ComboBox.vue'
export { default as CommandBar } from './components/CommandBar.vue'
export { default as CommandBarFlyout } from './components/CommandBarFlyout.vue'
export { default as ContentDialog } from './components/ContentDialog.vue'
export { default as ContentPresenter } from './components/ContentPresenter.vue'
export { default as DatePicker } from './components/DatePicker.vue'
export { default as DateTimePickerFlyout } from './components/DateTimePickerFlyout.vue'
export { default as DropDownButton } from './components/DropDownButton.vue'
export { default as Ellipse } from './components/Ellipse.vue'
export { default as Expander } from './components/Expander.vue'
export { default as ExpanderBase } from './components/ExpanderBase.vue'
export { default as FlipView } from './components/FlipView.vue'
export { default as Flyout } from './components/Flyout.vue'
export { default as FlyoutAnimation } from './components/FlyoutAnimation.vue'
export { default as FocusVisual } from './components/FocusVisual.vue'
export { default as FontIcon } from './components/FontIcon.vue'
export { default as Frame } from './components/Frame.vue'
export { default as Grid } from './components/Grid.vue'
export { default as GridColumnDefinitions } from './components/GridColumnDefinitions.vue'
export { default as GridDefinitions } from './components/GridDefinitions.vue'
export { default as GridRowDefinitions } from './components/GridRowDefinitions.vue'
export { default as GridView } from './components/GridView.vue'
export { default as HyperlinkButton } from './components/HyperlinkButton.vue'
export { default as IconSourceElement } from './components/IconSourceElement.vue'
export { default as Image } from './components/Image.vue'
export { default as ImageIcon } from './components/ImageIcon.vue'
export { default as InfoBadge } from './components/InfoBadge.vue'
export { default as InfoBar } from './components/InfoBar.vue'
export { default as InfoBarPanel } from './components/InfoBarPanel.vue'
export { default as ItemContainer } from './components/ItemContainer.vue'
export { default as ItemsControl } from './components/ItemsControl.vue'
export { default as ItemsRepeater } from './components/ItemsRepeater.vue'
export { default as ItemsRepeaterScrollHost } from './components/ItemsRepeaterScrollHost.vue'
export { default as ItemsView } from './components/ItemsView.vue'
export { default as ListBox } from './components/ListBox.vue'
export { default as ListView } from './components/ListView.vue'
export { default as MediaPlayerElement } from './components/MediaPlayerElement.vue'
export { default as MediaTransportControls } from './components/MediaTransportControls.vue'
export { default as MenuBar } from './components/MenuBar.vue'
export { default as MenuBarItem } from './components/MenuBarItem.vue'
export { default as MenuFlyout } from './components/MenuFlyout.vue'
export { default as NavigationView } from './components/NavigationView.vue'
export { default as NumberBox } from './components/NumberBox.vue'
export { default as Page } from './components/Page.vue'
export { default as ParallaxView } from './components/ParallaxView.vue'
export { default as PasswordBox } from './components/PasswordBox.vue'
export { default as PathIcon } from './components/PathIcon.vue'
export { default as PersonPicture } from './components/PersonPicture.vue'
export { default as PickerColumn } from './components/PickerColumn.vue'
export { default as PipsPager } from './components/PipsPager.vue'
export { default as Pivot } from './components/Pivot.vue'
export { default as PivotItem } from './components/PivotItem.vue'
export { default as Popup } from './components/Popup.vue'
export { default as ProgressBar } from './components/ProgressBar.vue'
export { default as ProgressRing } from './components/ProgressRing.vue'
export { default as RadialGradientBrush } from './components/RadialGradientBrush.vue'
export { default as RadioButton } from './components/RadioButton.vue'
export { default as RadioButtons } from './components/RadioButtons.vue'
export { default as Rating } from './components/Rating.vue'
export { default as Rectangle } from './components/Rectangle.vue'
export { default as RefreshContainer } from './components/RefreshContainer.vue'
export { default as RefreshVisualizer } from './components/RefreshVisualizer.vue'
export { default as RelativePanel } from './components/RelativePanel.vue'
export { default as RepeatButton } from './components/RepeatButton.vue'
export { default as RichEditBox } from './components/RichEditBox.vue'
export { default as RichTextBlock } from './components/RichTextBlock.vue'
export { default as RichTextBlockOverflow } from './components/RichTextBlockOverflow.vue'
export { default as RowDefinition } from './components/RowDefinition.vue'
export { default as ScrollBar } from './components/ScrollBar.vue'
export { default as ScrollView } from './components/ScrollView.vue'
export { default as ScrollViewer } from './components/ScrollViewer.vue'
export { default as SelectorBar } from './components/SelectorBar.vue'
export { default as SelectorBarItem } from './components/SelectorBarItem.vue'
export { default as SemanticZoom } from './components/SemanticZoom.vue'
export { default as SettingsCard } from './components/SettingsCard.vue'
export { default as Slider } from './components/Slider.vue'
export { default as SplitButton } from './components/SplitButton.vue'
export { default as SplitView } from './components/SplitView.vue'
export { default as StackPanel } from './components/StackPanel.vue'
export { default as SvgImageSource } from './components/SvgImageSource.vue'
export { default as SwipeControl } from './components/SwipeControl.vue'
export { default as SwitchPresenter } from './components/SwitchPresenter.vue'
export { default as SymbolIcon } from './components/SymbolIcon.vue'
export { default as SystemBackdropElement } from './components/SystemBackdropElement.vue'
export { default as TabView } from './components/TabView.vue'
export { default as TabViewItem } from './components/TabViewItem.vue'
export { default as TeachingTip } from './components/TeachingTip.vue'
export { default as TextBlock } from './components/TextBlock.vue'
export { default as TextBox } from './components/TextBox.vue'
export { default as ThemeShadow } from './components/ThemeShadow.vue'
export { default as TimePicker } from './components/TimePicker.vue'
export { default as TitleBar } from './components/TitleBar.vue'
export { AcrylicBrush, createAcrylicMaterialStyle, createAcrylicResource, resolveAcrylicResource, resolveBrushStyle, styleFromResolvedBrush, useAcrylicBrushStyle } from './components/AcrylicBrush'
export type { AcrylicMaterialStyleOptions, AcrylicMaterialTheme } from './components/AcrylicBrush'
export { createAcrylicMaterialLayer, createAcrylicNoiseLayer, mountAcrylicMaterialLayer, mountAcrylicNoiseLayer, vAcrylicBackdrop, vAcrylicBrush } from './components/acrylicBrushVisual'
export type { AcrylicMaterialLayer, AcrylicNoiseLayer } from './components/acrylicBrushVisual'
export { isAcrylicResource } from './components/acrylicResources'
export {
  configureTitleBarWindowHost,
  connectTitleBarWindowHost,
  createBrowserTitleBarWindowHost,
  getTitleBarHostPadding,
  nativeTitleBarMetricsToCssPixels,
  registerTitleBarWindowHost,
  setTitleBarHostAdapter,
  titleBarHostAdapterKey,
} from './components/titleBarHostAdapter'
export type {
  NativeTitleBarMetrics,
  TitleBarCaptionButton,
  TitleBarCaptionButtonState,
  TitleBarCaptionButtonsFramework,
  TitleBarCaptionHitTestMode,
  TitleBarDragRegions,
  TitleBarHeightOption,
  TitleBarHostAdapter,
  TitleBarInsets,
  TitleBarRegion,
  TitleBarWindowConfiguration,
  TitleBarWindowControls,
  TitleBarWindowHost,
} from './components/titleBarHostAdapter'
export { default as ToggleButton } from './components/ToggleButton.vue'
export { default as ToggleSplitButton } from './components/ToggleSplitButton.vue'
export { default as ToggleSwitch } from './components/ToggleSwitch.vue'
export { default as ToolTip } from './components/ToolTip.vue'
export { default as ToolTipService } from './components/ToolTipService.vue'
export { default as TreeView } from './components/TreeView.vue'
export { default as VariableSizedWrapGrid } from './components/VariableSizedWrapGrid.vue'
export { default as Viewbox } from './components/Viewbox.vue'
