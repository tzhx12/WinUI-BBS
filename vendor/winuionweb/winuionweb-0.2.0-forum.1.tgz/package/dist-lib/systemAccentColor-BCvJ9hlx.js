//#region src/components/systemAccentColorHostAdapter.ts
var e = [
	["AccentColor", "--winui-system-accent-color"],
	["LightThemeAccentColor", "--winui-system-accent-color-light"],
	["DarkThemeAccentColor", "--winui-system-accent-color-dark"],
	["LightThemeTextColor", "--winui-system-accent-text-light"],
	["DarkThemeTextColor", "--winui-system-accent-text-dark"],
	["AccentColorLight1", "--winui-system-accent-light-1"],
	["AccentColorLight2", "--winui-system-accent-light-2"],
	["AccentColorLight3", "--winui-system-accent-light-3"],
	["AccentColorDark1", "--winui-system-accent-dark-1"],
	["AccentColorDark2", "--winui-system-accent-dark-2"],
	["AccentColorDark3", "--winui-system-accent-dark-3"]
], t = [
	"--winui-system-accent-hover-light",
	"--winui-system-accent-pressed-light",
	"--winui-system-accent-hover-dark",
	"--winui-system-accent-pressed-dark",
	"--winui-system-accent-text-secondary-light",
	"--winui-system-accent-text-secondary-dark"
], n = [...e.map(([, e]) => e), ...t], r = /* @__PURE__ */ new WeakMap();
function i(e) {
	let t = e.trim().match(/^#([\da-f]{3}|[\da-f]{6})$/i)?.[1];
	if (t) {
		let e = t.length === 3 ? [...t].map((e) => e + e).join("") : t;
		return [
			0,
			2,
			4
		].map((t) => Number.parseInt(e.slice(t, t + 2), 16));
	}
	let n = e.trim().match(/^rgba?\(\s*(\d+(?:\.\d+)?)\s*,\s*(\d+(?:\.\d+)?)\s*,\s*(\d+(?:\.\d+)?)(?:\s*,\s*[\d.]+)?\s*\)$/i);
	return n ? [
		Number(n[1]),
		Number(n[2]),
		Number(n[3])
	] : void 0;
}
function a(e, t) {
	let n = i(e);
	if (n) return n;
	let r = t.ownerDocument, a = r.defaultView;
	if (!a) return;
	let o = r.createElement("span");
	o.style.cssText = "position:fixed;visibility:hidden;pointer-events:none", o.style.color = e, r.documentElement.appendChild(o);
	let s = a.getComputedStyle(o).color;
	return o.remove(), i(s);
}
function o(e, t, n) {
	let r = a(e, n);
	return r ? `rgba(${r.join(", ")}, ${t})` : void 0;
}
function s(e, t, n, r) {
	let i = a(e, r);
	if (i) return `rgb(${i.map((e, r) => Math.round(e * (1 - n) + t[r] * n)).join(", ")})`;
}
function c(e) {
	let t = i(e);
	if (!t) return;
	let n = t.map((e) => {
		let t = e / 255;
		return t <= .04045 ? t / 12.92 : ((t + .055) / 1.055) ** 2.4;
	}).reduce((e, t, n) => e + t * [
		.2126,
		.7152,
		.0722
	][n], 0);
	return 1.05 / (n + .05) >= (n + .05) / .05 ? "#FFFFFF" : "#000000";
}
function l(e, t) {
	let n = t.ownerDocument.defaultView?.CSS;
	return n?.supports ? n.supports("color", e) : e.trim().length > 0;
}
function u(e) {
	let t = e ?? (typeof window > "u" ? void 0 : window);
	if (!t) return {
		Read: () => null,
		Subscribe: () => () => void 0
	};
	let n = () => {
		let e = t.document;
		if (!t.CSS?.supports?.("color", "AccentColor")) return;
		let n = e.createElement("span");
		n.style.cssText = "position:fixed;visibility:hidden;pointer-events:none;color:AccentColor", (e.body ?? e.documentElement).appendChild(n);
		let r = t.getComputedStyle(n).color.trim();
		return n.remove(), r && l(r, e.documentElement) ? r : void 0;
	}, r = n(), i, a = /* @__PURE__ */ new Set(), o = () => {
		let e = n();
		if (e === r) return;
		r = e;
		let t = e ? { AccentColor: e } : null;
		for (let e of [...a]) e(t);
	}, s = () => {
		i !== void 0 && t.clearInterval(i), i = void 0, t.document.removeEventListener("visibilitychange", o), t.removeEventListener("focus", o), t.removeEventListener("pageshow", o);
	};
	return {
		Read: () => (r = n(), r ? { AccentColor: r } : null),
		Subscribe(e) {
			return a.add(e), i === void 0 && (t.document.addEventListener("visibilitychange", o), t.addEventListener("focus", o), t.addEventListener("pageshow", o), i = t.setInterval(() => {
				t.document.visibilityState !== "hidden" && o();
			}, 1500)), () => {
				a.delete(e), a.size || s();
			};
		}
	};
}
function d(e, t = document.documentElement) {
	r.get(t)?.();
	let i = new Map(n.map((e) => [e, {
		value: t.style.getPropertyValue(e),
		priority: t.style.getPropertyPriority(e)
	}])), u = !1, d = (e) => {
		if (u) return;
		for (let e of n) t.style.removeProperty(e);
		if (!e) return;
		let r = e.AccentColor?.trim();
		if (!r || !l(r, t)) return;
		let i = e.LightThemeAccentColor?.trim(), d = e.DarkThemeAccentColor?.trim(), f = i && l(i, t) ? i : r, p = d && l(d, t) ? d : void 0;
		t.style.setProperty("--winui-system-accent-color", r), t.style.setProperty("--winui-system-accent-color-light", f), p && t.style.setProperty("--winui-system-accent-color-dark", p);
		let m = (e) => {
			let n = a(e, t);
			return n ? `rgb(${n.join(", ")})` : e;
		}, h = e.LightThemeTextColor?.trim() || c(m(f)), g = e.DarkThemeTextColor?.trim() || (p ? c(m(p)) : void 0);
		h && l(h, t) && t.style.setProperty("--winui-system-accent-text-light", h), g && l(g, t) && t.style.setProperty("--winui-system-accent-text-dark", g);
		let _ = [
			["--winui-system-accent-hover-light", o(f, .9, t)],
			["--winui-system-accent-pressed-light", o(f, .8, t)],
			["--winui-system-accent-hover-dark", p ? o(p, .9, t) : void 0],
			["--winui-system-accent-pressed-dark", p ? o(p, .8, t) : void 0],
			["--winui-system-accent-text-secondary-light", o(h ?? "#FFFFFF", .7, t)],
			["--winui-system-accent-text-secondary-dark", o(g ?? "#000000", .7, t)],
			["--winui-system-accent-light-1", e.AccentColorLight1?.trim() || s(r, [
				255,
				255,
				255
			], .2, t)],
			["--winui-system-accent-light-2", e.AccentColorLight2?.trim() || s(r, [
				255,
				255,
				255
			], .4, t)],
			["--winui-system-accent-light-3", e.AccentColorLight3?.trim() || s(r, [
				255,
				255,
				255
			], .6, t)],
			["--winui-system-accent-dark-1", e.AccentColorDark1?.trim() || s(r, [
				0,
				0,
				0
			], .14, t)],
			["--winui-system-accent-dark-2", e.AccentColorDark2?.trim() || s(r, [
				0,
				0,
				0
			], .32, t)],
			["--winui-system-accent-dark-3", e.AccentColorDark3?.trim() || s(r, [
				0,
				0,
				0
			], .5, t)]
		];
		for (let [e, n] of _) n && l(n, t) && t.style.setProperty(e, n);
	};
	d(e.Read());
	let f = e.Subscribe(d), p = () => {
		if (!u) {
			u = !0, f();
			for (let e of n) {
				t.style.removeProperty(e);
				let n = i.get(e);
				n?.value && t.style.setProperty(e, n.value, n.priority);
			}
			r.get(t) === p && r.delete(t);
		}
	};
	return r.set(t, p), p;
}
//#endregion
export { u as n, d as t };

//# sourceMappingURL=systemAccentColor-BCvJ9hlx.js.map