import { n as e, t } from "./systemAccentColor-BCvJ9hlx.js";
export { t as connectSystemAccentColorHost, e as createBrowserSystemAccentColorHostAdapter };
