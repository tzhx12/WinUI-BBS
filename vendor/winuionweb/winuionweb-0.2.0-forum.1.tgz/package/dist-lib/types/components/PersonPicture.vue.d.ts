import { PersonPictureProfilePicture, PersonPictureBadgeImageSource } from './personPictureProperties';
export { PersonPictureProfilePicture, PersonPictureBadgeImageSource };
declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    BadgeNumber: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    BadgeGlyph: {
        type: StringConstructor;
        default: string;
    };
    BadgeImageSource: {
        type: (StringConstructor | ObjectConstructor)[];
        default: null;
    };
    BadgeText: {
        type: StringConstructor;
        default: string;
    };
    IsGroup: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    Contact: {
        type: (StringConstructor | ObjectConstructor)[];
        default: null;
    };
    DisplayName: {
        type: StringConstructor;
        default: string;
    };
    Initials: {
        type: StringConstructor;
        default: string;
    };
    PreferSmallImage: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    ProfilePicture: {
        type: (StringConstructor | ObjectConstructor)[];
        default: null;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    Foreground: {
        type: StringConstructor;
        default: string;
    };
    Background: {
        type: StringConstructor;
        default: string;
    };
    BorderBrush: {
        type: StringConstructor;
        default: string;
    };
    BorderThickness: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    FontFamily: {
        type: StringConstructor;
        default: string;
    };
    FontWeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    IsTabStop: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsHitTestVisible: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
    Opacity: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
}>, {
    BadgeNumber: import("vue").WritableComputedRef<unknown, unknown>;
    BadgeGlyph: import("vue").WritableComputedRef<unknown, unknown>;
    BadgeImageSource: import("vue").WritableComputedRef<{} | null, {} | null>;
    BadgeText: import("vue").WritableComputedRef<unknown, unknown>;
    IsGroup: import("vue").WritableComputedRef<unknown, unknown>;
    Contact: import("vue").WritableComputedRef<unknown, unknown>;
    DisplayName: import("vue").WritableComputedRef<unknown, unknown>;
    Initials: import("vue").WritableComputedRef<unknown, unknown>;
    PreferSmallImage: import("vue").WritableComputedRef<unknown, unknown>;
    ProfilePicture: import("vue").WritableComputedRef<{} | null, {} | null>;
    Width: import("vue").WritableComputedRef<number, number>;
    Height: import("vue").WritableComputedRef<number, number>;
    ActualWidth: import("vue").Ref<number, number>;
    ActualHeight: import("vue").Ref<number, number>;
    TemplateSettings: import("vue").ComputedRef<{
        ActualInitials: string;
        ActualImageBrush: {
            ImageSource: unknown;
            Stretch: string;
        } | null;
    }>;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:Foreground": (...args: any[]) => void;
    "update:IsEnabled": (...args: any[]) => void;
    "update:IsTabStop": (...args: any[]) => void;
    "update:Visibility": (...args: any[]) => void;
    "update:Background": (...args: any[]) => void;
    "update:BorderBrush": (...args: any[]) => void;
    "update:BorderThickness": (...args: any[]) => void;
    "update:Margin": (...args: any[]) => void;
    "update:Width": (...args: any[]) => void;
    "update:Height": (...args: any[]) => void;
    "update:MinWidth": (...args: any[]) => void;
    "update:MinHeight": (...args: any[]) => void;
    "update:MaxWidth": (...args: any[]) => void;
    "update:MaxHeight": (...args: any[]) => void;
    "update:FontFamily": (...args: any[]) => void;
    "update:FontWeight": (...args: any[]) => void;
    "update:HorizontalAlignment": (...args: any[]) => void;
    "update:VerticalAlignment": (...args: any[]) => void;
    "update:Opacity": (...args: any[]) => void;
    "update:IsHitTestVisible": (...args: any[]) => void;
    "update:BadgeNumber": (...args: any[]) => void;
    "update:BadgeGlyph": (...args: any[]) => void;
    "update:BadgeImageSource": (...args: any[]) => void;
    "update:BadgeText": (...args: any[]) => void;
    "update:IsGroup": (...args: any[]) => void;
    "update:Contact": (...args: any[]) => void;
    "update:DisplayName": (...args: any[]) => void;
    "update:Initials": (...args: any[]) => void;
    "update:PreferSmallImage": (...args: any[]) => void;
    "update:ProfilePicture": (...args: any[]) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    BadgeNumber: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    BadgeGlyph: {
        type: StringConstructor;
        default: string;
    };
    BadgeImageSource: {
        type: (StringConstructor | ObjectConstructor)[];
        default: null;
    };
    BadgeText: {
        type: StringConstructor;
        default: string;
    };
    IsGroup: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    Contact: {
        type: (StringConstructor | ObjectConstructor)[];
        default: null;
    };
    DisplayName: {
        type: StringConstructor;
        default: string;
    };
    Initials: {
        type: StringConstructor;
        default: string;
    };
    PreferSmallImage: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    ProfilePicture: {
        type: (StringConstructor | ObjectConstructor)[];
        default: null;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    Foreground: {
        type: StringConstructor;
        default: string;
    };
    Background: {
        type: StringConstructor;
        default: string;
    };
    BorderBrush: {
        type: StringConstructor;
        default: string;
    };
    BorderThickness: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    FontFamily: {
        type: StringConstructor;
        default: string;
    };
    FontWeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    IsTabStop: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsHitTestVisible: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
    Opacity: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
}>> & Readonly<{
    "onUpdate:Foreground"?: ((...args: any[]) => any) | undefined;
    "onUpdate:IsEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:IsTabStop"?: ((...args: any[]) => any) | undefined;
    "onUpdate:Visibility"?: ((...args: any[]) => any) | undefined;
    "onUpdate:Background"?: ((...args: any[]) => any) | undefined;
    "onUpdate:BorderBrush"?: ((...args: any[]) => any) | undefined;
    "onUpdate:BorderThickness"?: ((...args: any[]) => any) | undefined;
    "onUpdate:Margin"?: ((...args: any[]) => any) | undefined;
    "onUpdate:Width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:Height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:MinWidth"?: ((...args: any[]) => any) | undefined;
    "onUpdate:MinHeight"?: ((...args: any[]) => any) | undefined;
    "onUpdate:MaxWidth"?: ((...args: any[]) => any) | undefined;
    "onUpdate:MaxHeight"?: ((...args: any[]) => any) | undefined;
    "onUpdate:FontFamily"?: ((...args: any[]) => any) | undefined;
    "onUpdate:FontWeight"?: ((...args: any[]) => any) | undefined;
    "onUpdate:HorizontalAlignment"?: ((...args: any[]) => any) | undefined;
    "onUpdate:VerticalAlignment"?: ((...args: any[]) => any) | undefined;
    "onUpdate:Opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:IsHitTestVisible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:BadgeNumber"?: ((...args: any[]) => any) | undefined;
    "onUpdate:BadgeGlyph"?: ((...args: any[]) => any) | undefined;
    "onUpdate:BadgeImageSource"?: ((...args: any[]) => any) | undefined;
    "onUpdate:BadgeText"?: ((...args: any[]) => any) | undefined;
    "onUpdate:IsGroup"?: ((...args: any[]) => any) | undefined;
    "onUpdate:Contact"?: ((...args: any[]) => any) | undefined;
    "onUpdate:DisplayName"?: ((...args: any[]) => any) | undefined;
    "onUpdate:Initials"?: ((...args: any[]) => any) | undefined;
    "onUpdate:PreferSmallImage"?: ((...args: any[]) => any) | undefined;
    "onUpdate:ProfilePicture"?: ((...args: any[]) => any) | undefined;
}>, {
    Width: string | number;
    Height: string | number;
    MinWidth: string | number;
    MaxWidth: string | number;
    MinHeight: string | number;
    MaxHeight: string | number;
    Margin: string | number;
    HorizontalAlignment: string;
    VerticalAlignment: string;
    Foreground: string;
    Opacity: string | number;
    IsEnabled: string | boolean;
    Background: string;
    BorderBrush: string;
    BorderThickness: string | number;
    IsTabStop: string | boolean;
    FontFamily: string;
    FontWeight: string | number;
    ProfilePicture: string | Record<string, any>;
    BadgeImageSource: string | Record<string, any>;
    Visibility: string;
    IsHitTestVisible: string | boolean;
    Contact: string | Record<string, any>;
    BadgeNumber: string | number;
    BadgeGlyph: string;
    BadgeText: string;
    IsGroup: string | boolean;
    DisplayName: string;
    Initials: string;
    PreferSmallImage: string | boolean;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
