import { type PropType } from 'vue';
declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    TabWidthMode: {
        type: PropType<unknown>;
        default: unknown;
    };
    CloseButtonOverlayMode: {
        type: PropType<unknown>;
        default: unknown;
    };
    TabStripHeader: {
        type: PropType<unknown>;
        default: unknown;
    };
    TabStripHeaderTemplate: {
        type: PropType<unknown>;
        default: unknown;
    };
    TabStripFooter: {
        type: PropType<unknown>;
        default: unknown;
    };
    TabStripFooterTemplate: {
        type: PropType<unknown>;
        default: unknown;
    };
    IsAddTabButtonVisible: {
        type: PropType<unknown>;
        default: unknown;
    };
    AddTabButtonCommand: {
        type: PropType<unknown>;
        default: unknown;
    };
    AddTabButtonCommandParameter: {
        type: PropType<unknown>;
        default: unknown;
    };
    TabItemsSource: {
        type: PropType<unknown>;
        default: unknown;
    };
    TabItemTemplate: {
        type: PropType<unknown>;
        default: unknown;
    };
    TabItemTemplateSelector: {
        type: PropType<unknown>;
        default: unknown;
    };
    CanDragTabs: {
        type: PropType<unknown>;
        default: unknown;
    };
    CanReorderTabs: {
        type: PropType<unknown>;
        default: unknown;
    };
    AllowDropTabs: {
        type: PropType<unknown>;
        default: unknown;
    };
    CanTearOutTabs: {
        type: PropType<unknown>;
        default: unknown;
    };
    SelectedIndex: {
        type: PropType<unknown>;
        default: unknown;
    };
    SelectedItem: {
        type: PropType<unknown>;
        default: unknown;
    };
    IsEnabled: {
        type: PropType<unknown>;
        default: unknown;
    };
    IsTabStop: {
        type: PropType<unknown>;
        default: unknown;
    };
    Visibility: {
        type: PropType<unknown>;
        default: unknown;
    };
    Background: {
        type: PropType<unknown>;
        default: unknown;
    };
    Foreground: {
        type: PropType<unknown>;
        default: unknown;
    };
    BorderBrush: {
        type: PropType<unknown>;
        default: unknown;
    };
    BorderThickness: {
        type: PropType<unknown>;
        default: unknown;
    };
    CornerRadius: {
        type: PropType<unknown>;
        default: unknown;
    };
    Margin: {
        type: PropType<unknown>;
        default: unknown;
    };
    Padding: {
        type: PropType<unknown>;
        default: unknown;
    };
    Width: {
        type: PropType<unknown>;
        default: unknown;
    };
    Height: {
        type: PropType<unknown>;
        default: unknown;
    };
    MinWidth: {
        type: PropType<unknown>;
        default: unknown;
    };
    MinHeight: {
        type: PropType<unknown>;
        default: unknown;
    };
    MaxWidth: {
        type: PropType<unknown>;
        default: unknown;
    };
    MaxHeight: {
        type: PropType<unknown>;
        default: unknown;
    };
    HorizontalAlignment: {
        type: PropType<unknown>;
        default: unknown;
    };
    VerticalAlignment: {
        type: PropType<unknown>;
        default: unknown;
    };
    RequestedTheme: {
        type: PropType<unknown>;
        default: unknown;
    };
    FlowDirection: {
        type: PropType<unknown>;
        default: unknown;
    };
    Opacity: {
        type: PropType<unknown>;
        default: unknown;
    };
    IsHitTestVisible: {
        type: PropType<unknown>;
        default: unknown;
    };
}>, Record<string | symbol, any>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    SelectionChanged: (...args: any[]) => void;
    AddTabButtonClick: (...args: any[]) => void;
    TabCloseRequested: (...args: any[]) => void;
    TabItemsChanged: (...args: any[]) => void;
    TabDragStarting: (...args: any[]) => void;
    TabDragCompleted: (...args: any[]) => void;
    TabDroppedOutside: (...args: any[]) => void;
    TabStripDragOver: (...args: any[]) => void;
    TabStripDrop: (...args: any[]) => void;
    TabTearOutWindowRequested: (...args: any[]) => void;
    TabTearOutRequested: (...args: any[]) => void;
    ExternalTornOutTabsDropping: (...args: any[]) => void;
    ExternalTornOutTabsDropped: (...args: any[]) => void;
    Loaded: (...args: any[]) => void;
    "update:SelectedItem": (...args: any[]) => void;
    "update:SelectedIndex": (...args: any[]) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    TabWidthMode: {
        type: PropType<unknown>;
        default: unknown;
    };
    CloseButtonOverlayMode: {
        type: PropType<unknown>;
        default: unknown;
    };
    TabStripHeader: {
        type: PropType<unknown>;
        default: unknown;
    };
    TabStripHeaderTemplate: {
        type: PropType<unknown>;
        default: unknown;
    };
    TabStripFooter: {
        type: PropType<unknown>;
        default: unknown;
    };
    TabStripFooterTemplate: {
        type: PropType<unknown>;
        default: unknown;
    };
    IsAddTabButtonVisible: {
        type: PropType<unknown>;
        default: unknown;
    };
    AddTabButtonCommand: {
        type: PropType<unknown>;
        default: unknown;
    };
    AddTabButtonCommandParameter: {
        type: PropType<unknown>;
        default: unknown;
    };
    TabItemsSource: {
        type: PropType<unknown>;
        default: unknown;
    };
    TabItemTemplate: {
        type: PropType<unknown>;
        default: unknown;
    };
    TabItemTemplateSelector: {
        type: PropType<unknown>;
        default: unknown;
    };
    CanDragTabs: {
        type: PropType<unknown>;
        default: unknown;
    };
    CanReorderTabs: {
        type: PropType<unknown>;
        default: unknown;
    };
    AllowDropTabs: {
        type: PropType<unknown>;
        default: unknown;
    };
    CanTearOutTabs: {
        type: PropType<unknown>;
        default: unknown;
    };
    SelectedIndex: {
        type: PropType<unknown>;
        default: unknown;
    };
    SelectedItem: {
        type: PropType<unknown>;
        default: unknown;
    };
    IsEnabled: {
        type: PropType<unknown>;
        default: unknown;
    };
    IsTabStop: {
        type: PropType<unknown>;
        default: unknown;
    };
    Visibility: {
        type: PropType<unknown>;
        default: unknown;
    };
    Background: {
        type: PropType<unknown>;
        default: unknown;
    };
    Foreground: {
        type: PropType<unknown>;
        default: unknown;
    };
    BorderBrush: {
        type: PropType<unknown>;
        default: unknown;
    };
    BorderThickness: {
        type: PropType<unknown>;
        default: unknown;
    };
    CornerRadius: {
        type: PropType<unknown>;
        default: unknown;
    };
    Margin: {
        type: PropType<unknown>;
        default: unknown;
    };
    Padding: {
        type: PropType<unknown>;
        default: unknown;
    };
    Width: {
        type: PropType<unknown>;
        default: unknown;
    };
    Height: {
        type: PropType<unknown>;
        default: unknown;
    };
    MinWidth: {
        type: PropType<unknown>;
        default: unknown;
    };
    MinHeight: {
        type: PropType<unknown>;
        default: unknown;
    };
    MaxWidth: {
        type: PropType<unknown>;
        default: unknown;
    };
    MaxHeight: {
        type: PropType<unknown>;
        default: unknown;
    };
    HorizontalAlignment: {
        type: PropType<unknown>;
        default: unknown;
    };
    VerticalAlignment: {
        type: PropType<unknown>;
        default: unknown;
    };
    RequestedTheme: {
        type: PropType<unknown>;
        default: unknown;
    };
    FlowDirection: {
        type: PropType<unknown>;
        default: unknown;
    };
    Opacity: {
        type: PropType<unknown>;
        default: unknown;
    };
    IsHitTestVisible: {
        type: PropType<unknown>;
        default: unknown;
    };
}>> & Readonly<{
    onSelectionChanged?: ((...args: any[]) => any) | undefined;
    onAddTabButtonClick?: ((...args: any[]) => any) | undefined;
    onTabCloseRequested?: ((...args: any[]) => any) | undefined;
    onTabItemsChanged?: ((...args: any[]) => any) | undefined;
    onTabDragStarting?: ((...args: any[]) => any) | undefined;
    onTabDragCompleted?: ((...args: any[]) => any) | undefined;
    onTabDroppedOutside?: ((...args: any[]) => any) | undefined;
    onTabStripDragOver?: ((...args: any[]) => any) | undefined;
    onTabStripDrop?: ((...args: any[]) => any) | undefined;
    onTabTearOutWindowRequested?: ((...args: any[]) => any) | undefined;
    onTabTearOutRequested?: ((...args: any[]) => any) | undefined;
    onExternalTornOutTabsDropping?: ((...args: any[]) => any) | undefined;
    onExternalTornOutTabsDropped?: ((...args: any[]) => any) | undefined;
    onLoaded?: ((...args: any[]) => any) | undefined;
    "onUpdate:SelectedItem"?: ((...args: any[]) => any) | undefined;
    "onUpdate:SelectedIndex"?: ((...args: any[]) => any) | undefined;
}>, {
    Width: unknown;
    Height: unknown;
    MinWidth: unknown;
    MaxWidth: unknown;
    MinHeight: unknown;
    MaxHeight: unknown;
    Margin: unknown;
    Padding: unknown;
    HorizontalAlignment: unknown;
    VerticalAlignment: unknown;
    Foreground: unknown;
    Opacity: unknown;
    IsEnabled: unknown;
    Background: unknown;
    BorderBrush: unknown;
    BorderThickness: unknown;
    CornerRadius: unknown;
    IsTabStop: unknown;
    RequestedTheme: unknown;
    SelectedItem: unknown;
    TabItemTemplate: unknown;
    TabItemTemplateSelector: unknown;
    TabStripHeaderTemplate: unknown;
    TabStripFooterTemplate: unknown;
    Visibility: unknown;
    IsHitTestVisible: unknown;
    FlowDirection: unknown;
    TabStripHeader: unknown;
    TabStripFooter: unknown;
    SelectedIndex: unknown;
    TabWidthMode: unknown;
    CloseButtonOverlayMode: unknown;
    IsAddTabButtonVisible: unknown;
    AddTabButtonCommand: unknown;
    AddTabButtonCommandParameter: unknown;
    TabItemsSource: unknown;
    CanDragTabs: unknown;
    CanReorderTabs: unknown;
    AllowDropTabs: unknown;
    CanTearOutTabs: unknown;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
