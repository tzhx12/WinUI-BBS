export declare const ToggleSplitButtonFlyout: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const ToggleSplitButtonContent: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: __VLS_WithSlots<import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    Content: {
        type: null;
        default: string;
    };
    ContentTemplate: {
        type: null;
        default: undefined;
    };
    ContentTransitions: {
        type: null;
        default: undefined;
    };
    Flyout: {
        type: null;
        default: undefined;
    };
    IsChecked: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    RequestedTheme: {
        type: StringConstructor;
        default: string;
    };
}>, {
    IsChecked: boolean;
    IsEnabled: boolean;
    RequestedTheme: string;
    ContentTemplate: any;
    ContentTransitions: any;
    Name: {};
    Content: any;
    Flyout: any;
    Element: any;
    Focus: () => any;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    Click: (...args: any[]) => void;
    IsCheckedChanged: (...args: any[]) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    Content: {
        type: null;
        default: string;
    };
    ContentTemplate: {
        type: null;
        default: undefined;
    };
    ContentTransitions: {
        type: null;
        default: undefined;
    };
    Flyout: {
        type: null;
        default: undefined;
    };
    IsChecked: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    RequestedTheme: {
        type: StringConstructor;
        default: string;
    };
}>> & Readonly<{
    onClick?: ((...args: any[]) => any) | undefined;
    onIsCheckedChanged?: ((...args: any[]) => any) | undefined;
}>, {
    IsEnabled: string | boolean;
    RequestedTheme: string;
    Flyout: any;
    IsChecked: string | boolean;
    ContentTemplate: any;
    Content: any;
    ContentTransitions: any;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>, {
    default?: (props: {}) => any;
}>;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
