import { type InjectionKey } from 'vue';
import { type ImageSourceRegistration } from './imageSource';
type PersonPictureSourceName = 'ProfilePicture' | 'BadgeImageSource';
export declare const personPictureSourceKey: InjectionKey<{
    register: (name: PersonPictureSourceName, source: ImageSourceRegistration | null) => void;
}>;
export declare const PersonPictureProfilePicture: import("vue").DefineComponent<{}, () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const PersonPictureBadgeImageSource: import("vue").DefineComponent<{}, () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export {};
