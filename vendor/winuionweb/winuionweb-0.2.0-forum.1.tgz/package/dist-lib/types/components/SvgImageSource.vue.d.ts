import { type ImageEventArgs } from './imageSource';
declare const __VLS_export: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    UriSource: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    RasterizePixelWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    RasterizePixelHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
}>, import("./imageSource").ImageSourceModel, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    Opened: (sender: unknown, args: ImageEventArgs) => any;
    OpenFailed: (sender: unknown, args: ImageEventArgs) => any;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    UriSource: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    RasterizePixelWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    RasterizePixelHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
}>> & Readonly<{
    onOpened?: ((sender: unknown, args: ImageEventArgs) => any) | undefined;
    onOpenFailed?: ((sender: unknown, args: ImageEventArgs) => any) | undefined;
}>, {
    UriSource: string | Record<string, any>;
    RasterizePixelWidth: string | number;
    RasterizePixelHeight: string | number;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
declare const _default: typeof __VLS_export;
export default _default;
