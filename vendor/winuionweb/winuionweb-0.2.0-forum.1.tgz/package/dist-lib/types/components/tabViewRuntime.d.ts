export type TabViewDataPackage = {
    Properties: Record<string, unknown>;
    RequestedOperation: string;
    SetText: (text: string) => void;
    SetData: (format: string, value: unknown) => void;
    GetView: () => TabViewDataView;
};
export type TabViewDataView = {
    Properties: Record<string, unknown>;
    AvailableFormats: string[];
    Contains: (format: string) => boolean;
    GetTextAsync: () => Promise<string>;
    GetDataAsync: (format: string) => Promise<unknown>;
};
export declare const createTabViewDataPackage: () => TabViewDataPackage;
export type TabViewDragSession = {
    Source: TabViewDragEndpoint;
    Key: unknown;
    Item: unknown;
    Tab: unknown;
    Data: TabViewDataPackage;
    Controller: AbortController;
    Native: boolean;
    NativeDragToken?: string;
    NativeDropObserved?: boolean;
    CanLeaveSource: boolean;
    PointerId?: number;
    X: number;
    Y: number;
    Target: TabViewDragEndpoint | null;
    DropIndex: number;
    Ghost?: HTMLElement;
};
export type TabViewDragEndpoint = {
    Id: string;
    Element: () => HTMLElement | null;
    CanAccept: (session: TabViewDragSession) => boolean;
    Over: (session: TabViewDragSession, event: Event | null) => boolean;
    Leave: () => void;
    Drop: (session: TabViewDragSession, event: Event | null) => Promise<string>;
    Complete: (session: TabViewDragSession, result: string, cancelled: boolean) => void;
};
export declare const activeTabViewDrag: import("vue").ShallowRef<TabViewDragSession | null, TabViewDragSession | null>;
export declare const registerTabViewDragEndpoint: (endpoint: TabViewDragEndpoint) => () => void;
export declare const startTabViewDrag: (session: TabViewDragSession) => void;
export declare const moveTabViewDrag: (x: number, y: number, event?: Event | null) => void;
export declare const endTabViewDrag: (event?: Event | null, result?: string) => Promise<void>;
export declare const cancelTabViewDrag: () => void;
