import { type VNode } from 'vue';
export declare const MenuBarItemsProperty: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: {
    new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("vue").ExtractPropTypes<{
        Items: {
            type: (StringConstructor | ArrayConstructor | ObjectConstructor)[];
            default: undefined;
        };
        IsEnabled: {
            type: (StringConstructor | BooleanConstructor)[];
            default: boolean;
        };
        Visibility: {
            type: StringConstructor;
            default: string;
        };
        RequestedTheme: {
            type: StringConstructor;
            default: string;
        };
    }>> & Readonly<{
        "onUpdate:IsEnabled"?: ((...args: any[]) => any) | undefined;
        "onUpdate:Visibility"?: ((...args: any[]) => any) | undefined;
        "onUpdate:Items"?: ((...args: any[]) => any) | undefined;
    }>, () => VNode<import("vue").RendererNode, import("vue").RendererElement, {
        [key: string]: any;
    }>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, ("update:IsEnabled" | "update:Visibility" | "update:Items")[], import("vue").PublicProps, {
        IsEnabled: string | boolean;
        RequestedTheme: string;
        Visibility: string;
        Items: string | unknown[] | Record<string, any>;
    }, true, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
        P: {};
        B: {};
        D: {};
        C: {};
        M: {};
        Defaults: {};
    }, Readonly<import("vue").ExtractPropTypes<{
        Items: {
            type: (StringConstructor | ArrayConstructor | ObjectConstructor)[];
            default: undefined;
        };
        IsEnabled: {
            type: (StringConstructor | BooleanConstructor)[];
            default: boolean;
        };
        Visibility: {
            type: StringConstructor;
            default: string;
        };
        RequestedTheme: {
            type: StringConstructor;
            default: string;
        };
    }>> & Readonly<{
        "onUpdate:IsEnabled"?: ((...args: any[]) => any) | undefined;
        "onUpdate:Visibility"?: ((...args: any[]) => any) | undefined;
        "onUpdate:Items"?: ((...args: any[]) => any) | undefined;
    }>, () => VNode<import("vue").RendererNode, import("vue").RendererElement, {
        [key: string]: any;
    }>, {}, {}, {}, {
        IsEnabled: string | boolean;
        RequestedTheme: string;
        Visibility: string;
        Items: string | unknown[] | Record<string, any>;
    }>;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
    Items: {
        type: (StringConstructor | ArrayConstructor | ObjectConstructor)[];
        default: undefined;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
    RequestedTheme: {
        type: StringConstructor;
        default: string;
    };
}>> & Readonly<{
    "onUpdate:IsEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:Visibility"?: ((...args: any[]) => any) | undefined;
    "onUpdate:Items"?: ((...args: any[]) => any) | undefined;
}>, () => VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, ("update:IsEnabled" | "update:Visibility" | "update:Items")[], "update:IsEnabled" | "update:Visibility" | "update:Items", {
    IsEnabled: string | boolean;
    RequestedTheme: string;
    Visibility: string;
    Items: string | unknown[] | Record<string, any>;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & {
    Items: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
};
