export declare const IsDragRegionProperty: Readonly<{
    Owner: "TitleBar";
    Name: "IsDragRegion";
    ClearValue: (target: DragRegionElement) => void;
}>;
type DragRegionElement = HTMLElement | {
    Element?: HTMLElement;
    $el?: HTMLElement;
} | null | undefined;
export declare function setIsDragRegion(target: DragRegionElement, value: boolean | null | undefined): void;
export declare function getIsDragRegion(target: DragRegionElement): boolean | null;
export declare function clearIsDragRegion(element: DragRegionElement): void;
export declare const SetIsDragRegion: typeof setIsDragRegion;
export declare const GetIsDragRegion: typeof getIsDragRegion;
/** FindInteractableElements follows TitleBar.cpp's attached-property inheritance. */
export declare function findTitleBarInteractableElements(root: HTMLElement): HTMLElement[];
export {};
