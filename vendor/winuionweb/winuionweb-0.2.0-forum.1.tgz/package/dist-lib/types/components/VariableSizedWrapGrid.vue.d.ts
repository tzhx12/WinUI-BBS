export declare const VariableSizedWrapGridResources: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    Orientation: {
        type: StringConstructor;
        default: string;
    };
    ItemWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    ItemHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MaximumRowsOrColumns: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    HorizontalChildrenAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalChildrenAlignment: {
        type: StringConstructor;
        default: string;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Background: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
}>, {
    Orientation: import("vue").WritableComputedRef<string, string>;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:Orientation": (...args: any[]) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    Orientation: {
        type: StringConstructor;
        default: string;
    };
    ItemWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    ItemHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MaximumRowsOrColumns: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    HorizontalChildrenAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalChildrenAlignment: {
        type: StringConstructor;
        default: string;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Background: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
}>> & Readonly<{
    "onUpdate:Orientation"?: ((...args: any[]) => any) | undefined;
}>, {
    Width: string | number;
    Height: string | number;
    MinWidth: string | number;
    MaxWidth: string | number;
    MinHeight: string | number;
    MaxHeight: string | number;
    Margin: string | number;
    HorizontalAlignment: string;
    VerticalAlignment: string;
    Background: string | Record<string, any>;
    Orientation: string;
    ItemWidth: string | number;
    ItemHeight: string | number;
    MaximumRowsOrColumns: string | number;
    HorizontalChildrenAlignment: string;
    VerticalChildrenAlignment: string;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
