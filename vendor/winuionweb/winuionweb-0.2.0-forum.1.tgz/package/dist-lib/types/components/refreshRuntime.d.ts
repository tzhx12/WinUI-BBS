import { type UnwrapNestedRefs } from 'vue';
export declare const refreshContextKey: unique symbol;
export type RefreshPullDirection = 'LeftToRight' | 'TopToBottom' | 'RightToLeft' | 'BottomToTop';
export type RefreshVisualizerOrientation = 'Auto' | 'Normal' | 'Rotate90DegreesCounterclockwise' | 'Rotate270DegreesCounterclockwise';
export type RefreshVisualizerState = 'Idle' | 'Peeking' | 'Interacting' | 'Pending' | 'Refreshing';
export interface RefreshRequestedEventArgs {
    GetDeferral: () => {
        Complete: () => void;
    };
}
export interface RefreshStateChangedEventArgs {
    OldState: RefreshVisualizerState;
    NewState: RefreshVisualizerState;
}
export declare const DEFAULT_EXECUTION_RATIO = 0.8;
export declare const FALLBACK_EXECUTION_RATIO = 1;
export declare const DEFAULT_PULL_DIMENSION_SIZE = 100;
export declare const INITIAL_OFFSET_THRESHOLD = 1;
export declare const REFRESH_ANIMATION_DURATION = 100;
export declare const REFRESH_VISUALIZER_OVERPAN_RATIO = 0.4;
export declare const isVerticalPull: (direction: RefreshPullDirection) => direction is "TopToBottom" | "BottomToTop";
/** Pull directions whose content travels along the negative axis. */
export declare const isFarPull: (direction: RefreshPullDirection) => direction is "RightToLeft" | "BottomToTop";
export declare const isVerticalOrientation: (orientation: RefreshVisualizerOrientation, direction: RefreshPullDirection) => boolean;
/**
 * Raise a RefreshRequested event with the official deferral accounting.
 *
 * RefreshVisualizer::RaiseRefreshRequested and
 * RefreshContainer::RaiseRefreshRequested both wrap a single Deferral in a
 * RefreshRequestedEventArgs that counts the deferrals handlers take. They
 * increment the count before dispatching and decrement it afterwards, so a
 * handler that never asks for a deferral lets the refresh finish as soon as the
 * event returns, while any handler holding one keeps the refresh running until
 * every deferral is released. Each deferral can only be released once.
 */
export declare const raiseRefreshRequested: (dispatch: (args: RefreshRequestedEventArgs) => void, onCompleted: () => void) => void;
export interface RefreshVisualizerHandle {
    readonly publicInstance: unknown;
    /** IRefreshInfoProvider.InteractionRatioChanged. */
    setInteractionRatio: (ratio: number) => void;
    /** IRefreshInfoProvider.IsInteractingForRefreshChanged. */
    setIsInteractingForRefresh: (value: boolean) => void;
    /** IRefreshVisualizerPrivate.SetInternalPullDirection. */
    setInternalPullDirection: (direction: RefreshPullDirection) => void;
    RequestRefresh: () => void;
}
export interface RefreshContext extends UnwrapNestedRefs<{
    pullDirection: RefreshPullDirection;
    /** RefreshVisualizer.State; the container reads it to place its presenter. */
    state: RefreshVisualizerState;
    /** IRefreshInfoProvider.ExecutionRatio; the container is the provider. */
    executionRatio: number;
    /** Size of the visualizer along the pull axis, in pixels. */
    visualizerSize: number;
    /** Size of the visualizer's root, used by the icon's parallax translation. */
    visualizerRootSize: number;
    /** Registered by the mounted visualizer; null while it is absent. */
    visualizerHandle: RefreshVisualizerHandle | null;
}> {
    /** IRefreshInfoProvider.InteractionRatioChanged. */
    publishInteractionRatio: (ratio: number) => void;
    /** IRefreshInfoProvider.IsInteractingForRefreshChanged. */
    publishIsInteractingForRefresh: (value: boolean) => void;
    /**
     * RefreshContainer::OnVisualizerRefreshRequested. The visualizer raises its
     * own RefreshRequested and the container, having subscribed, takes a deferral
     * on it before re-raising to its own handlers.
     */
    containerRefreshRequested: ((args: RefreshRequestedEventArgs) => void) | null;
    /** Notifies the container that the visualizer's state changed. */
    containerStateChanged: ((oldState: RefreshVisualizerState, newState: RefreshVisualizerState) => void) | null;
}
export declare const createRefreshContext: (options?: {
    pullDirection?: RefreshPullDirection;
    executionRatio?: number;
}) => RefreshContext;
export declare const clamp: (value: number, minimum: number, maximum: number) => number;
