export declare const menuFlyoutResources: Record<string, unknown>;
