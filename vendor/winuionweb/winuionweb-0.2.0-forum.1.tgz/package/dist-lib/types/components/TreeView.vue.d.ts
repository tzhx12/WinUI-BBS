import type { VNode } from 'vue';
/**
 * `<TreeViewItem>` is a valid DataTemplate root in official XAML. WinUI treats
 * such a template as supplying the container itself, so the element carries the
 * item's Content, ItemsSource, IsExpanded and HasUnrealizedChildren. It renders
 * as a fragment: the TreeView reads these properties from the materialized
 * template and drives the real container visuals.
 */
export declare const XamlTreeViewItem: import("vue").DefineComponent<{}, () => VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
/**
 * `<TreeView.RootNodes>` holds `<TreeViewNode>` elements. Both are structural:
 * the TreeView consumes the declarative node tree instead of rendering it.
 */
export declare const TreeViewRootNodes: import("vue").DefineComponent<{}, () => VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const XamlTreeViewNode: import("vue").DefineComponent<{}, () => VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
/** `<TreeViewNode.Children>` holds further `<TreeViewNode>` elements. */
export declare const TreeViewNodeChildren: import("vue").DefineComponent<{}, () => VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: import("vue").DefineComponent<{
    ItemsSource?: unknown[] | string;
    RootNodes?: unknown[] | string;
    SelectionMode?: ("None" | "Single" | "Multiple") | string;
    CanDragItems?: boolean | string;
    CanReorderItems?: boolean | string;
    AllowDrop?: boolean | string;
    SelectedItem?: unknown;
    SelectedItems?: unknown[] | string;
    ItemTemplate?: unknown;
    ItemTemplateSelector?: unknown;
    ItemContainerStyle?: unknown;
    ItemContainerStyleSelector?: unknown;
    ItemContainerTransitions?: unknown;
    FlowDirection?: string;
    IsEnabled?: boolean | string;
    HorizontalAlignment?: string;
    VerticalAlignment?: string;
    HorizontalContentAlignment?: string;
    VerticalContentAlignment?: string;
    Width?: string | number;
    Height?: string | number;
    MinWidth?: string | number;
    MinHeight?: string | number;
    MaxWidth?: string | number;
    MaxHeight?: string | number;
    Margin?: string | number;
    Padding?: string | number;
    Background?: string | object;
    BorderBrush?: string;
    BorderThickness?: string | number;
    CornerRadius?: string | number;
}, Record<string, unknown>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    SelectionChanged: (...args: any[]) => void;
    Expanding: (...args: any[]) => void;
    Collapsed: (...args: any[]) => void;
    ItemInvoked: (...args: any[]) => void;
    DragItemsStarting: (...args: any[]) => void;
    DragItemsCompleted: (...args: any[]) => void;
    DragOver: (...args: any[]) => void;
    Drop: (...args: any[]) => void;
    "update:ItemsSource": (...args: any[]) => void;
    "update:RootNodes": (...args: any[]) => void;
    "update:SelectedItem": (...args: any[]) => void;
    "update:SelectedItems": (...args: any[]) => void;
}, string, import("vue").PublicProps, Readonly<{
    ItemsSource?: unknown[] | string;
    RootNodes?: unknown[] | string;
    SelectionMode?: ("None" | "Single" | "Multiple") | string;
    CanDragItems?: boolean | string;
    CanReorderItems?: boolean | string;
    AllowDrop?: boolean | string;
    SelectedItem?: unknown;
    SelectedItems?: unknown[] | string;
    ItemTemplate?: unknown;
    ItemTemplateSelector?: unknown;
    ItemContainerStyle?: unknown;
    ItemContainerStyleSelector?: unknown;
    ItemContainerTransitions?: unknown;
    FlowDirection?: string;
    IsEnabled?: boolean | string;
    HorizontalAlignment?: string;
    VerticalAlignment?: string;
    HorizontalContentAlignment?: string;
    VerticalContentAlignment?: string;
    Width?: string | number;
    Height?: string | number;
    MinWidth?: string | number;
    MinHeight?: string | number;
    MaxWidth?: string | number;
    MaxHeight?: string | number;
    Margin?: string | number;
    Padding?: string | number;
    Background?: string | object;
    BorderBrush?: string;
    BorderThickness?: string | number;
    CornerRadius?: string | number;
}> & Readonly<{
    onSelectionChanged?: ((...args: any[]) => any) | undefined;
    onExpanding?: ((...args: any[]) => any) | undefined;
    onCollapsed?: ((...args: any[]) => any) | undefined;
    onItemInvoked?: ((...args: any[]) => any) | undefined;
    onDragItemsStarting?: ((...args: any[]) => any) | undefined;
    onDragItemsCompleted?: ((...args: any[]) => any) | undefined;
    onDragOver?: ((...args: any[]) => any) | undefined;
    onDrop?: ((...args: any[]) => any) | undefined;
    "onUpdate:ItemsSource"?: ((...args: any[]) => any) | undefined;
    "onUpdate:RootNodes"?: ((...args: any[]) => any) | undefined;
    "onUpdate:SelectedItem"?: ((...args: any[]) => any) | undefined;
    "onUpdate:SelectedItems"?: ((...args: any[]) => any) | undefined;
}>, {
    Width: string | number;
    Height: string | number;
    MinWidth: string | number;
    MaxWidth: string | number;
    MinHeight: string | number;
    MaxHeight: string | number;
    Margin: string | number;
    Padding: string | number;
    HorizontalAlignment: string;
    VerticalAlignment: string;
    IsEnabled: boolean | string;
    Background: string | object;
    BorderBrush: string;
    BorderThickness: string | number;
    CornerRadius: string | number;
    HorizontalContentAlignment: string;
    VerticalContentAlignment: string;
    SelectedItem: undefined;
    ItemTemplate: string;
    ItemContainerStyle: undefined;
    FlowDirection: string;
    ItemsSource: unknown[] | string;
    RootNodes: unknown[] | string;
    SelectionMode: ("None" | "Single" | "Multiple") | string;
    CanDragItems: boolean | string;
    CanReorderItems: boolean | string;
    AllowDrop: boolean | string;
    SelectedItems: unknown[] | string;
    ItemTemplateSelector: string;
    ItemContainerStyleSelector: undefined;
    ItemContainerTransitions: undefined;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, false, {}, any>;
