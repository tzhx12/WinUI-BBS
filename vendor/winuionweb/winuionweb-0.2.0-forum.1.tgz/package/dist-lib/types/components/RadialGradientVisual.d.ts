import { type Directive, type PropType } from 'vue';
import type { RadialGradientBrushValue } from './RadialGradientBrush.vue';
export declare const isRadialGradientBrush: (value: unknown) => value is RadialGradientBrushValue;
export interface RadialGradientPaintBounds {
    X: number;
    Y: number;
    Width: number;
    Height: number;
}
export declare const radialGradientPaint: (brush: RadialGradientBrushValue, id: string, bounds?: RadialGradientPaintBounds) => {
    definition: import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
        [key: string]: any;
    }>;
    paint: string;
    opacity: number;
};
declare const _default: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    Brush: {
        type: PropType<RadialGradientBrushValue>;
        required: true;
    };
}>, () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    Brush: {
        type: PropType<RadialGradientBrushValue>;
        required: true;
    };
}>> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export default _default;
export declare const vRadialGradientBrush: Directive<HTMLElement, unknown>;
