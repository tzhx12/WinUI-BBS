import { type PropType } from 'vue';
import { pivotItemIdentityKey } from './PivotProperties';
declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    Header: {
        type: PropType<unknown>;
        default: unknown;
    };
    Content: {
        type: PropType<unknown>;
        default: unknown;
    };
    ContentTemplate: {
        type: PropType<unknown>;
        default: unknown;
    };
    Background: {
        type: PropType<unknown>;
        default: unknown;
    };
    Foreground: {
        type: PropType<unknown>;
        default: unknown;
    };
    Margin: {
        type: PropType<unknown>;
        default: unknown;
    };
    Padding: {
        type: PropType<unknown>;
        default: unknown;
    };
    HorizontalContentAlignment: {
        type: PropType<unknown>;
        default: unknown;
    };
    VerticalContentAlignment: {
        type: PropType<unknown>;
        default: unknown;
    };
    IsEnabled: {
        type: PropType<unknown>;
        default: unknown;
    };
    IsTabStop: {
        type: PropType<unknown>;
        default: unknown;
    };
    Visibility: {
        type: PropType<unknown>;
        default: unknown;
    };
    Width: {
        type: PropType<unknown>;
        default: unknown;
    };
    Height: {
        type: PropType<unknown>;
        default: unknown;
    };
    MinWidth: {
        type: PropType<unknown>;
        default: unknown;
    };
    MinHeight: {
        type: PropType<unknown>;
        default: unknown;
    };
    MaxWidth: {
        type: PropType<unknown>;
        default: unknown;
    };
    MaxHeight: {
        type: PropType<unknown>;
        default: unknown;
    };
    HorizontalAlignment: {
        type: PropType<unknown>;
        default: unknown;
    };
    VerticalAlignment: {
        type: PropType<unknown>;
        default: unknown;
    };
    Opacity: {
        type: PropType<unknown>;
        default: unknown;
    };
    IsHitTestVisible: {
        type: PropType<unknown>;
        default: unknown;
    };
    AccessKey: {
        type: PropType<unknown>;
        default: unknown;
    };
}>, {
    [pivotItemIdentityKey]: string;
    readonly ActualWidth: number;
    readonly ActualHeight: number;
    Focus(): boolean;
    InvokeAccessKey(): void;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    Header: {
        type: PropType<unknown>;
        default: unknown;
    };
    Content: {
        type: PropType<unknown>;
        default: unknown;
    };
    ContentTemplate: {
        type: PropType<unknown>;
        default: unknown;
    };
    Background: {
        type: PropType<unknown>;
        default: unknown;
    };
    Foreground: {
        type: PropType<unknown>;
        default: unknown;
    };
    Margin: {
        type: PropType<unknown>;
        default: unknown;
    };
    Padding: {
        type: PropType<unknown>;
        default: unknown;
    };
    HorizontalContentAlignment: {
        type: PropType<unknown>;
        default: unknown;
    };
    VerticalContentAlignment: {
        type: PropType<unknown>;
        default: unknown;
    };
    IsEnabled: {
        type: PropType<unknown>;
        default: unknown;
    };
    IsTabStop: {
        type: PropType<unknown>;
        default: unknown;
    };
    Visibility: {
        type: PropType<unknown>;
        default: unknown;
    };
    Width: {
        type: PropType<unknown>;
        default: unknown;
    };
    Height: {
        type: PropType<unknown>;
        default: unknown;
    };
    MinWidth: {
        type: PropType<unknown>;
        default: unknown;
    };
    MinHeight: {
        type: PropType<unknown>;
        default: unknown;
    };
    MaxWidth: {
        type: PropType<unknown>;
        default: unknown;
    };
    MaxHeight: {
        type: PropType<unknown>;
        default: unknown;
    };
    HorizontalAlignment: {
        type: PropType<unknown>;
        default: unknown;
    };
    VerticalAlignment: {
        type: PropType<unknown>;
        default: unknown;
    };
    Opacity: {
        type: PropType<unknown>;
        default: unknown;
    };
    IsHitTestVisible: {
        type: PropType<unknown>;
        default: unknown;
    };
    AccessKey: {
        type: PropType<unknown>;
        default: unknown;
    };
}>> & Readonly<{}>, {
    Width: unknown;
    Height: unknown;
    MinWidth: unknown;
    MaxWidth: unknown;
    MinHeight: unknown;
    MaxHeight: unknown;
    Margin: unknown;
    Padding: unknown;
    HorizontalAlignment: unknown;
    VerticalAlignment: unknown;
    Foreground: unknown;
    Opacity: unknown;
    AccessKey: unknown;
    IsEnabled: unknown;
    Header: unknown;
    Background: unknown;
    HorizontalContentAlignment: unknown;
    VerticalContentAlignment: unknown;
    IsTabStop: unknown;
    ContentTemplate: unknown;
    Visibility: unknown;
    Content: unknown;
    IsHitTestVisible: unknown;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
