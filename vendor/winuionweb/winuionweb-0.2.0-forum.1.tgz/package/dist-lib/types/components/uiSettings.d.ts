export declare const uiSettings: {
    AutoHideScrollBars: boolean;
    AdvancedEffectsEnabled: boolean;
    AreEffectsFast: boolean;
    EnergySaverStatus: boolean;
    IsHighContrast: boolean;
};
export type UISettingsMaterialPolicy = Partial<{
    AutoHideScrollBars: boolean;
    AdvancedEffectsEnabled: boolean;
    AreEffectsFast: boolean;
    EnergySaverStatus: boolean;
    IsHighContrast: boolean;
}>;
/** Native UISettings/PowerManager policy shared by every in-app material. */
export interface UISettingsHostAdapter {
    Read(): UISettingsMaterialPolicy;
    Subscribe(listener: (policy: UISettingsMaterialPolicy) => void): () => void;
}
export declare function setUISettingsHostAdapter(adapter: UISettingsHostAdapter | undefined): () => void;
