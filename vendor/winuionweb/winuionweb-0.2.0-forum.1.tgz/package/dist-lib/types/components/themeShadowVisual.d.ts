import { type Directive } from 'vue';
import { type ThemeShadowValue } from './themeShadowRuntime';
export interface ThemeShadowVisualOptions {
    Shadow?: ThemeShadowValue | null;
    Translation: number | string | {
        X?: number;
        Y?: number;
        Z?: number;
    };
    Theme?: unknown;
    CornerRadius?: number | string;
    Enabled?: boolean;
    Caster?: HTMLElement;
}
type CasterOwner = object | symbol;
export declare const clearThemeShadowVisual: (element: HTMLElement, owner?: CasterOwner) => void;
export declare const setThemeShadowVisual: (element: HTMLElement, options: ThemeShadowVisualOptions | null | undefined, owner?: CasterOwner) => void;
export declare const vThemeShadow: Directive<HTMLElement, ThemeShadowVisualOptions | null | undefined>;
export {};
