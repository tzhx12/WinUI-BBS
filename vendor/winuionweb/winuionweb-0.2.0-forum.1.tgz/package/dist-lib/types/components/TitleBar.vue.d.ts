import { type PropType } from 'vue';
declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    Title: {
        type: StringConstructor;
        default: string;
    };
    Subtitle: {
        type: StringConstructor;
        default: string;
    };
    IconSource: {
        type: (StringConstructor | ObjectConstructor)[];
        default: null;
    };
    IsBackButtonVisible: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsBackButtonEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsPaneToggleButtonVisible: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    /** Used to keep the navigation toggle label aligned with NavigationView state. */
    IsPaneOpen: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    /** Adds Web-rendered minimize, maximize/restore and close buttons. */
    IsCaptionButtonsVisible: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    /** Optional built-in host bridge; read only while IsCaptionButtonsVisible is true. */
    CaptionButtonsFramework: {
        type: StringConstructor;
        default: string;
    };
    LeftHeader: {
        type: PropType<unknown>;
        default: null;
    };
    Content: {
        type: PropType<unknown>;
        default: null;
    };
    RightHeader: {
        type: PropType<unknown>;
        default: null;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    FlowDirection: {
        type: StringConstructor;
        default: string;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
    AutoRefreshDragRegions: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    /** The control owns its Standard/Tall variant; hosts translate it to window geometry. */
    PreferredHeightOption: {
        type: StringConstructor;
        default: string;
    };
    Background: {
        type: StringConstructor;
        default: string;
    };
    Foreground: {
        type: StringConstructor;
        default: string;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
}>, {
    ResolvedHeightOption: "Standard" | "Tall";
    TemplateSettings: {
        IconElement: import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("vue").ExtractPropTypes<{
            IconSource: {
                type: (StringConstructor | ObjectConstructor)[];
                default: null;
            };
            Foreground: {
                type: (StringConstructor | ObjectConstructor)[];
                default: string;
            };
            Width: {
                type: (NumberConstructor | StringConstructor)[];
                default: string;
            };
            Height: {
                type: (NumberConstructor | StringConstructor)[];
                default: string;
            };
            MinWidth: {
                type: (NumberConstructor | StringConstructor)[];
                default: number;
            };
            MinHeight: {
                type: (NumberConstructor | StringConstructor)[];
                default: number;
            };
            MaxWidth: {
                type: (NumberConstructor | StringConstructor)[];
                default: string;
            };
            MaxHeight: {
                type: (NumberConstructor | StringConstructor)[];
                default: string;
            };
            Margin: {
                type: (NumberConstructor | StringConstructor)[];
                default: number;
            };
            HorizontalAlignment: {
                type: StringConstructor;
                default: string;
            };
            VerticalAlignment: {
                type: StringConstructor;
                default: string;
            };
            Visibility: {
                type: (StringConstructor | BooleanConstructor)[];
                default: string;
            };
            Opacity: {
                type: (NumberConstructor | StringConstructor)[];
                default: number;
            };
            IsHitTestVisible: {
                type: (StringConstructor | BooleanConstructor)[];
                default: boolean;
            };
            FlowDirection: {
                type: StringConstructor;
                default: string;
            };
            RequestedTheme: {
                type: StringConstructor;
                default: string;
            };
        }>> & Readonly<{}>, Record<string, unknown>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, import("vue").PublicProps, {
            Width: string | number;
            Height: string | number;
            MinWidth: string | number;
            MaxWidth: string | number;
            MinHeight: string | number;
            MaxHeight: string | number;
            Margin: string | number;
            HorizontalAlignment: string;
            VerticalAlignment: string;
            Foreground: string | Record<string, any>;
            Opacity: string | number;
            IconSource: string | Record<string, any>;
            RequestedTheme: string;
            Visibility: string | boolean;
            IsHitTestVisible: string | boolean;
            FlowDirection: string;
        }, true, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
            P: {};
            B: {};
            D: {};
            C: {};
            M: {};
            Defaults: {};
        }, Readonly<import("vue").ExtractPropTypes<{
            IconSource: {
                type: (StringConstructor | ObjectConstructor)[];
                default: null;
            };
            Foreground: {
                type: (StringConstructor | ObjectConstructor)[];
                default: string;
            };
            Width: {
                type: (NumberConstructor | StringConstructor)[];
                default: string;
            };
            Height: {
                type: (NumberConstructor | StringConstructor)[];
                default: string;
            };
            MinWidth: {
                type: (NumberConstructor | StringConstructor)[];
                default: number;
            };
            MinHeight: {
                type: (NumberConstructor | StringConstructor)[];
                default: number;
            };
            MaxWidth: {
                type: (NumberConstructor | StringConstructor)[];
                default: string;
            };
            MaxHeight: {
                type: (NumberConstructor | StringConstructor)[];
                default: string;
            };
            Margin: {
                type: (NumberConstructor | StringConstructor)[];
                default: number;
            };
            HorizontalAlignment: {
                type: StringConstructor;
                default: string;
            };
            VerticalAlignment: {
                type: StringConstructor;
                default: string;
            };
            Visibility: {
                type: (StringConstructor | BooleanConstructor)[];
                default: string;
            };
            Opacity: {
                type: (NumberConstructor | StringConstructor)[];
                default: number;
            };
            IsHitTestVisible: {
                type: (StringConstructor | BooleanConstructor)[];
                default: boolean;
            };
            FlowDirection: {
                type: StringConstructor;
                default: string;
            };
            RequestedTheme: {
                type: StringConstructor;
                default: string;
            };
        }>> & Readonly<{}>, Record<string, unknown>, {}, {}, {}, {
            Width: string | number;
            Height: string | number;
            MinWidth: string | number;
            MaxWidth: string | number;
            MinHeight: string | number;
            MaxHeight: string | number;
            Margin: string | number;
            HorizontalAlignment: string;
            VerticalAlignment: string;
            Foreground: string | Record<string, any>;
            Opacity: string | number;
            IconSource: string | Record<string, any>;
            RequestedTheme: string;
            Visibility: string | boolean;
            IsHitTestVisible: string | boolean;
            FlowDirection: string;
        }> | null;
    };
    RecomputeDragRegions: () => void;
    Element: HTMLElement | null;
    isCompact: boolean;
    isNarrow: boolean;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    PaneToggleRequested: (...args: any[]) => void;
    LayoutUpdated: (...args: any[]) => void;
    CloseRequested: (...args: any[]) => void;
    BackRequested: (...args: any[]) => void;
    CaptionButtonRequested: (...args: any[]) => void;
    MinimizeRequested: (...args: any[]) => void;
    MaximizeRequested: (...args: any[]) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    Title: {
        type: StringConstructor;
        default: string;
    };
    Subtitle: {
        type: StringConstructor;
        default: string;
    };
    IconSource: {
        type: (StringConstructor | ObjectConstructor)[];
        default: null;
    };
    IsBackButtonVisible: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsBackButtonEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsPaneToggleButtonVisible: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    /** Used to keep the navigation toggle label aligned with NavigationView state. */
    IsPaneOpen: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    /** Adds Web-rendered minimize, maximize/restore and close buttons. */
    IsCaptionButtonsVisible: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    /** Optional built-in host bridge; read only while IsCaptionButtonsVisible is true. */
    CaptionButtonsFramework: {
        type: StringConstructor;
        default: string;
    };
    LeftHeader: {
        type: PropType<unknown>;
        default: null;
    };
    Content: {
        type: PropType<unknown>;
        default: null;
    };
    RightHeader: {
        type: PropType<unknown>;
        default: null;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    FlowDirection: {
        type: StringConstructor;
        default: string;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
    AutoRefreshDragRegions: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    /** The control owns its Standard/Tall variant; hosts translate it to window geometry. */
    PreferredHeightOption: {
        type: StringConstructor;
        default: string;
    };
    Background: {
        type: StringConstructor;
        default: string;
    };
    Foreground: {
        type: StringConstructor;
        default: string;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
}>> & Readonly<{
    onPaneToggleRequested?: ((...args: any[]) => any) | undefined;
    onLayoutUpdated?: ((...args: any[]) => any) | undefined;
    onCloseRequested?: ((...args: any[]) => any) | undefined;
    onBackRequested?: ((...args: any[]) => any) | undefined;
    onCaptionButtonRequested?: ((...args: any[]) => any) | undefined;
    onMinimizeRequested?: ((...args: any[]) => any) | undefined;
    onMaximizeRequested?: ((...args: any[]) => any) | undefined;
}>, {
    Width: string | number;
    Height: string | number;
    MinWidth: string | number;
    MaxWidth: string | number;
    MinHeight: string | number;
    MaxHeight: string | number;
    Margin: string | number;
    HorizontalAlignment: string;
    VerticalAlignment: string;
    Foreground: string;
    IconSource: string | Record<string, any>;
    IsEnabled: string | boolean;
    Background: string;
    Visibility: string;
    Content: null;
    FlowDirection: string;
    Title: string;
    LeftHeader: null;
    RightHeader: null;
    IsPaneOpen: string | boolean;
    Subtitle: string;
    IsBackButtonVisible: string | boolean;
    IsBackButtonEnabled: string | boolean;
    IsPaneToggleButtonVisible: string | boolean;
    IsCaptionButtonsVisible: string | boolean;
    CaptionButtonsFramework: string;
    AutoRefreshDragRegions: string | boolean;
    PreferredHeightOption: string;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
