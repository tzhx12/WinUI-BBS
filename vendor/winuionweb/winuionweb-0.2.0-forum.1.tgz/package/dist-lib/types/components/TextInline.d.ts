import { type ComponentInternalInstance, type VNode } from 'vue';
export declare const textProperty: (owner: string, property: string) => import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const TextBlockInlines: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const TextBlockTextHighlighters: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const RichTextBlockBlocks: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const RichTextBlockTextHighlighters: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const SpanInlines: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const ParagraphInlines: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const InlineUIContainerChild: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const TextHighlighterRanges: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const TextHighlighter: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const TextRange: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const textNodeChildren: (node: VNode) => VNode[];
export declare const textPropertyName: (node: VNode) => string | undefined;
export declare const textContentNodes: (nodes: VNode[], property: "Inlines" | "Blocks" | "Child") => VNode[];
export declare const textBrush: (value: unknown) => string;
export declare const textFontWeight: (value: unknown) => string | number;
export declare const Run: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    Text: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    CharacterSpacing: (NumberConstructor | StringConstructor)[];
    FontFamily: StringConstructor;
    FontSize: (NumberConstructor | StringConstructor)[];
    FontStretch: StringConstructor;
    FontStyle: StringConstructor;
    FontWeight: (NumberConstructor | StringConstructor)[];
    Foreground: (StringConstructor | ObjectConstructor)[];
    TextDecorations: StringConstructor;
    FlowDirection: StringConstructor;
    Language: StringConstructor;
    IsTextScaleFactorEnabled: (StringConstructor | BooleanConstructor)[];
}>, () => VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    Text: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    CharacterSpacing: (NumberConstructor | StringConstructor)[];
    FontFamily: StringConstructor;
    FontSize: (NumberConstructor | StringConstructor)[];
    FontStretch: StringConstructor;
    FontStyle: StringConstructor;
    FontWeight: (NumberConstructor | StringConstructor)[];
    Foreground: (StringConstructor | ObjectConstructor)[];
    TextDecorations: StringConstructor;
    FlowDirection: StringConstructor;
    Language: StringConstructor;
    IsTextScaleFactorEnabled: (StringConstructor | BooleanConstructor)[];
}>> & Readonly<{}>, {
    Text: string | number;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const Span: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    CharacterSpacing: (NumberConstructor | StringConstructor)[];
    FontFamily: StringConstructor;
    FontSize: (NumberConstructor | StringConstructor)[];
    FontStretch: StringConstructor;
    FontStyle: StringConstructor;
    FontWeight: (NumberConstructor | StringConstructor)[];
    Foreground: (StringConstructor | ObjectConstructor)[];
    TextDecorations: StringConstructor;
    FlowDirection: StringConstructor;
    Language: StringConstructor;
    IsTextScaleFactorEnabled: (StringConstructor | BooleanConstructor)[];
}>, () => VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    CharacterSpacing: (NumberConstructor | StringConstructor)[];
    FontFamily: StringConstructor;
    FontSize: (NumberConstructor | StringConstructor)[];
    FontStretch: StringConstructor;
    FontStyle: StringConstructor;
    FontWeight: (NumberConstructor | StringConstructor)[];
    Foreground: (StringConstructor | ObjectConstructor)[];
    TextDecorations: StringConstructor;
    FlowDirection: StringConstructor;
    Language: StringConstructor;
    IsTextScaleFactorEnabled: (StringConstructor | BooleanConstructor)[];
}>> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const Bold: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    CharacterSpacing: (NumberConstructor | StringConstructor)[];
    FontFamily: StringConstructor;
    FontSize: (NumberConstructor | StringConstructor)[];
    FontStretch: StringConstructor;
    FontStyle: StringConstructor;
    FontWeight: (NumberConstructor | StringConstructor)[];
    Foreground: (StringConstructor | ObjectConstructor)[];
    TextDecorations: StringConstructor;
    FlowDirection: StringConstructor;
    Language: StringConstructor;
    IsTextScaleFactorEnabled: (StringConstructor | BooleanConstructor)[];
}>, () => VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    CharacterSpacing: (NumberConstructor | StringConstructor)[];
    FontFamily: StringConstructor;
    FontSize: (NumberConstructor | StringConstructor)[];
    FontStretch: StringConstructor;
    FontStyle: StringConstructor;
    FontWeight: (NumberConstructor | StringConstructor)[];
    Foreground: (StringConstructor | ObjectConstructor)[];
    TextDecorations: StringConstructor;
    FlowDirection: StringConstructor;
    Language: StringConstructor;
    IsTextScaleFactorEnabled: (StringConstructor | BooleanConstructor)[];
}>> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const Italic: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    CharacterSpacing: (NumberConstructor | StringConstructor)[];
    FontFamily: StringConstructor;
    FontSize: (NumberConstructor | StringConstructor)[];
    FontStretch: StringConstructor;
    FontStyle: StringConstructor;
    FontWeight: (NumberConstructor | StringConstructor)[];
    Foreground: (StringConstructor | ObjectConstructor)[];
    TextDecorations: StringConstructor;
    FlowDirection: StringConstructor;
    Language: StringConstructor;
    IsTextScaleFactorEnabled: (StringConstructor | BooleanConstructor)[];
}>, () => VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    CharacterSpacing: (NumberConstructor | StringConstructor)[];
    FontFamily: StringConstructor;
    FontSize: (NumberConstructor | StringConstructor)[];
    FontStretch: StringConstructor;
    FontStyle: StringConstructor;
    FontWeight: (NumberConstructor | StringConstructor)[];
    Foreground: (StringConstructor | ObjectConstructor)[];
    TextDecorations: StringConstructor;
    FlowDirection: StringConstructor;
    Language: StringConstructor;
    IsTextScaleFactorEnabled: (StringConstructor | BooleanConstructor)[];
}>> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const Underline: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    CharacterSpacing: (NumberConstructor | StringConstructor)[];
    FontFamily: StringConstructor;
    FontSize: (NumberConstructor | StringConstructor)[];
    FontStretch: StringConstructor;
    FontStyle: StringConstructor;
    FontWeight: (NumberConstructor | StringConstructor)[];
    Foreground: (StringConstructor | ObjectConstructor)[];
    TextDecorations: StringConstructor;
    FlowDirection: StringConstructor;
    Language: StringConstructor;
    IsTextScaleFactorEnabled: (StringConstructor | BooleanConstructor)[];
}>, () => VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    CharacterSpacing: (NumberConstructor | StringConstructor)[];
    FontFamily: StringConstructor;
    FontSize: (NumberConstructor | StringConstructor)[];
    FontStretch: StringConstructor;
    FontStyle: StringConstructor;
    FontWeight: (NumberConstructor | StringConstructor)[];
    Foreground: (StringConstructor | ObjectConstructor)[];
    TextDecorations: StringConstructor;
    FlowDirection: StringConstructor;
    Language: StringConstructor;
    IsTextScaleFactorEnabled: (StringConstructor | BooleanConstructor)[];
}>> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const Paragraph: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    CharacterSpacing: (NumberConstructor | StringConstructor)[];
    FontFamily: StringConstructor;
    FontSize: (NumberConstructor | StringConstructor)[];
    FontStretch: StringConstructor;
    FontStyle: StringConstructor;
    FontWeight: (NumberConstructor | StringConstructor)[];
    Foreground: (StringConstructor | ObjectConstructor)[];
    TextDecorations: StringConstructor;
    FlowDirection: StringConstructor;
    Language: StringConstructor;
    IsTextScaleFactorEnabled: (StringConstructor | BooleanConstructor)[];
}>, () => VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    CharacterSpacing: (NumberConstructor | StringConstructor)[];
    FontFamily: StringConstructor;
    FontSize: (NumberConstructor | StringConstructor)[];
    FontStretch: StringConstructor;
    FontStyle: StringConstructor;
    FontWeight: (NumberConstructor | StringConstructor)[];
    Foreground: (StringConstructor | ObjectConstructor)[];
    TextDecorations: StringConstructor;
    FlowDirection: StringConstructor;
    Language: StringConstructor;
    IsTextScaleFactorEnabled: (StringConstructor | BooleanConstructor)[];
}>> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const LineBreak: import("vue").DefineComponent<{}, () => VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const InlineUIContainer: import("vue").DefineComponent<{}, () => VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const restoreInlineInteractions: (root: ParentNode) => void;
export declare const Hyperlink: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    NavigateUri: {
        type: StringConstructor;
        default: string;
    };
    Click: {
        type: (StringConstructor | FunctionConstructor)[];
        default: undefined;
    };
    UnderlineStyle: {
        type: StringConstructor;
        default: string;
    };
    CharacterSpacing: (NumberConstructor | StringConstructor)[];
    FontFamily: StringConstructor;
    FontSize: (NumberConstructor | StringConstructor)[];
    FontStretch: StringConstructor;
    FontStyle: StringConstructor;
    FontWeight: (NumberConstructor | StringConstructor)[];
    Foreground: (StringConstructor | ObjectConstructor)[];
    TextDecorations: StringConstructor;
    FlowDirection: StringConstructor;
    Language: StringConstructor;
    IsTextScaleFactorEnabled: (StringConstructor | BooleanConstructor)[];
}>, () => VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, "Click"[], "Click", import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    NavigateUri: {
        type: StringConstructor;
        default: string;
    };
    Click: {
        type: (StringConstructor | FunctionConstructor)[];
        default: undefined;
    };
    UnderlineStyle: {
        type: StringConstructor;
        default: string;
    };
    CharacterSpacing: (NumberConstructor | StringConstructor)[];
    FontFamily: StringConstructor;
    FontSize: (NumberConstructor | StringConstructor)[];
    FontStretch: StringConstructor;
    FontStyle: StringConstructor;
    FontWeight: (NumberConstructor | StringConstructor)[];
    Foreground: (StringConstructor | ObjectConstructor)[];
    TextDecorations: StringConstructor;
    FlowDirection: StringConstructor;
    Language: StringConstructor;
    IsTextScaleFactorEnabled: (StringConstructor | BooleanConstructor)[];
}>> & Readonly<{
    onClick?: ((...args: any[]) => any) | undefined;
}>, {
    Click: string | Function;
    NavigateUri: string;
    UnderlineStyle: string;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export type TextHighlighterValue = {
    Background?: unknown;
    Foreground?: unknown;
    Ranges: {
        StartIndex: number;
        Length: number;
    }[];
};
export declare const textPosition: (root: Node, index: number) => [Node, number];
export declare const readTextHighlighters: (nodes: VNode[], instance: ComponentInternalInstance | null) => TextHighlighterValue[];
export declare const createTextHighlights: (key: string) => {
    Clear: () => void;
    Update: (roots: {
        Element: HTMLElement;
        Start: number;
    }[], highlighters: TextHighlighterValue[]) => void;
};
