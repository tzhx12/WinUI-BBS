import type { App } from 'vue';
export declare function registerWinUIComponents(app: App): void;
