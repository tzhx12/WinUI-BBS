/**
 * Framework independent representations of the WinUI system backdrop APIs.
 *
 * The browser cannot sample the desktop compositor.  These objects therefore
 * describe the requested material and are intentionally free of DOM and Vue
 * dependencies.  A native host can consume the same descriptors through
 * `systemBackdropHostAdapter.ts`.
 */
export type MicaKind = 'Base' | 'BaseAlt';
export type DesktopAcrylicKind = 'Base' | 'Thin';
export type SystemBackdropType = 'Mica' | 'DesktopAcrylic';
export interface MicaBackdropConfig {
    Type: 'Mica';
    Kind: MicaKind;
    FallbackColor?: string;
    TintColor?: string;
    TintOpacity?: number;
    LuminosityOpacity?: number;
}
export interface DesktopAcrylicBackdropConfig {
    Type: 'DesktopAcrylic';
    Kind: DesktopAcrylicKind;
    FallbackColor?: string;
    TintColor?: string;
    TintOpacity?: number;
    LuminosityOpacity?: number;
}
export type SystemBackdropConfig = MicaBackdropConfig | DesktopAcrylicBackdropConfig;
export type SystemBackdropChangeListener = (backdrop: SystemBackdrop) => void;
/** Base class corresponding to Microsoft.UI.Xaml.Media.SystemBackdrop. */
export declare abstract class SystemBackdrop {
    abstract readonly Type: SystemBackdropType;
    private readonly listeners;
    protected Changed(): void;
    Subscribe(listener: SystemBackdropChangeListener): () => void;
    abstract ToConfig(): SystemBackdropConfig;
}
/** The built-in WinUI Mica material. */
export declare class MicaBackdrop extends SystemBackdrop {
    readonly Type: "Mica";
    private kind;
    get Kind(): MicaKind;
    set Kind(value: MicaKind);
    ToConfig(): MicaBackdropConfig;
}
/** The built-in WinUI Desktop Acrylic material (Base kind). */
export declare class DesktopAcrylicBackdrop extends SystemBackdrop {
    readonly Type: "DesktopAcrylic";
    ToConfig(): DesktopAcrylicBackdropConfig;
}
/**
 * Controller contracts mirror the Composition SystemBackdrops namespace.
 * Native adapters may use their appearance properties when applying a
 * descriptor.  `IsSupported` is deliberately false in the browser runtime;
 * a native host is responsible for returning its actual capability.
 */
export declare class MicaController {
    static IsSupported(): boolean;
    readonly Type: "Mica";
    Kind: MicaKind;
    FallbackColor?: string;
    TintColor?: string;
    TintOpacity?: number;
    LuminosityOpacity?: number;
    ToConfig(): MicaBackdropConfig;
}
export declare class DesktopAcrylicController {
    static IsSupported(): boolean;
    readonly Type: "DesktopAcrylic";
    Kind: DesktopAcrylicKind;
    FallbackColor?: string;
    TintColor?: string;
    TintOpacity?: number;
    LuminosityOpacity?: number;
    ToConfig(): DesktopAcrylicBackdropConfig;
}
export declare function toSystemBackdropConfig(value: unknown): SystemBackdropConfig | null;
export declare function cloneSystemBackdropConfig(value: SystemBackdropConfig | null): SystemBackdropConfig | null;
