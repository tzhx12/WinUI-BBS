export declare const SplitButtonFlyout: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const SplitButtonContent: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    Content: {
        type: null;
        default: string;
    };
    Flyout: {
        type: null;
        default: undefined;
    };
    ContentTemplate: {
        type: null;
        default: undefined;
    };
    ContentTransitions: {
        type: null;
        default: undefined;
    };
    Command: {
        type: (StringConstructor | ObjectConstructor)[];
        default: undefined;
    };
    CommandParameter: {
        default: undefined;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsTabStop: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    Background: {
        type: StringConstructor;
        default: string;
    };
    Foreground: {
        type: StringConstructor;
        default: string;
    };
    BorderBrush: {
        type: StringConstructor;
        default: string;
    };
    BorderThickness: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Padding: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    HorizontalContentAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalContentAlignment: {
        type: StringConstructor;
        default: string;
    };
    FontFamily: {
        type: StringConstructor;
        default: string;
    };
    FontSize: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    FontWeight: {
        type: StringConstructor;
        default: string;
    };
    CornerRadius: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    UseSystemFocusVisuals: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    FocusVisualMargin: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
    RequestedTheme: {
        type: StringConstructor;
        default: string;
    };
}>, {
    IsEnabled: boolean;
    RequestedTheme: string;
    ContentTemplate: any;
    ContentTransitions: any;
    Name: {};
    Content: {} | null;
    Flyout: any;
    Command: import("./uiCommandRuntime").UICommandMetadata | undefined;
    CommandParameter: unknown;
    Element: HTMLElement | null;
    IsFlyoutOpen: boolean;
    Focus: () => boolean;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    Click: (...args: any[]) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    Content: {
        type: null;
        default: string;
    };
    Flyout: {
        type: null;
        default: undefined;
    };
    ContentTemplate: {
        type: null;
        default: undefined;
    };
    ContentTransitions: {
        type: null;
        default: undefined;
    };
    Command: {
        type: (StringConstructor | ObjectConstructor)[];
        default: undefined;
    };
    CommandParameter: {
        default: undefined;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsTabStop: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    Background: {
        type: StringConstructor;
        default: string;
    };
    Foreground: {
        type: StringConstructor;
        default: string;
    };
    BorderBrush: {
        type: StringConstructor;
        default: string;
    };
    BorderThickness: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Padding: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    HorizontalContentAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalContentAlignment: {
        type: StringConstructor;
        default: string;
    };
    FontFamily: {
        type: StringConstructor;
        default: string;
    };
    FontSize: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    FontWeight: {
        type: StringConstructor;
        default: string;
    };
    CornerRadius: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    UseSystemFocusVisuals: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    FocusVisualMargin: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
    RequestedTheme: {
        type: StringConstructor;
        default: string;
    };
}>> & Readonly<{
    onClick?: ((...args: any[]) => any) | undefined;
}>, {
    Width: string | number;
    Height: string | number;
    MinWidth: string | number;
    MaxWidth: string | number;
    MinHeight: string | number;
    MaxHeight: string | number;
    Margin: string | number;
    Padding: string | number;
    HorizontalAlignment: string;
    VerticalAlignment: string;
    Foreground: string;
    Command: string | Record<string, any>;
    IsEnabled: string | boolean;
    Background: string;
    BorderBrush: string;
    BorderThickness: string | number;
    CornerRadius: string | number;
    FontSize: string | number;
    HorizontalContentAlignment: string;
    VerticalContentAlignment: string;
    UseSystemFocusVisuals: string | boolean;
    IsTabStop: string | boolean;
    FocusVisualMargin: string | number;
    FontFamily: string;
    FontWeight: string;
    RequestedTheme: string;
    Flyout: any;
    ContentTemplate: any;
    Visibility: string;
    Content: any;
    ContentTransitions: any;
    CommandParameter: undefined;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
