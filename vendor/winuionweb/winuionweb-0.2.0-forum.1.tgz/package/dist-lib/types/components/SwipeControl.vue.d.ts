import type { SwipeControlApi } from './SwipeControl.types';
declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    LeftItems: {
        type: (StringConstructor | ObjectConstructor)[];
        default: undefined;
    };
    RightItems: {
        type: (StringConstructor | ObjectConstructor)[];
        default: undefined;
    };
    TopItems: {
        type: (StringConstructor | ObjectConstructor)[];
        default: undefined;
    };
    BottomItems: {
        type: (StringConstructor | ObjectConstructor)[];
        default: undefined;
    };
    Content: {
        default: undefined;
    };
    ContentTemplate: {
        default: undefined;
    };
    DataContext: {
        default: undefined;
    };
    Background: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    BorderBrush: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    BorderThickness: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    CornerRadius: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    Padding: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsTabStop: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
    'AutomationProperties.Name': {
        type: StringConstructor;
        default: string;
    };
}>, SwipeControlApi & Record<string, unknown>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    PointerEntered: (...args: any[]) => void;
    PointerExited: (...args: any[]) => void;
    ContextRequested: (...args: any[]) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    LeftItems: {
        type: (StringConstructor | ObjectConstructor)[];
        default: undefined;
    };
    RightItems: {
        type: (StringConstructor | ObjectConstructor)[];
        default: undefined;
    };
    TopItems: {
        type: (StringConstructor | ObjectConstructor)[];
        default: undefined;
    };
    BottomItems: {
        type: (StringConstructor | ObjectConstructor)[];
        default: undefined;
    };
    Content: {
        default: undefined;
    };
    ContentTemplate: {
        default: undefined;
    };
    DataContext: {
        default: undefined;
    };
    Background: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    BorderBrush: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    BorderThickness: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    CornerRadius: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    Padding: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsTabStop: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
    'AutomationProperties.Name': {
        type: StringConstructor;
        default: string;
    };
}>> & Readonly<{
    onPointerEntered?: ((...args: any[]) => any) | undefined;
    onPointerExited?: ((...args: any[]) => any) | undefined;
    onContextRequested?: ((...args: any[]) => any) | undefined;
}>, {
    Width: string | number;
    Height: string | number;
    MinWidth: string | number;
    MaxWidth: string | number;
    MinHeight: string | number;
    MaxHeight: string | number;
    Margin: string | number;
    Padding: string | number;
    HorizontalAlignment: string;
    VerticalAlignment: string;
    IsEnabled: string | boolean;
    Background: string | Record<string, any>;
    BorderBrush: string | Record<string, any>;
    BorderThickness: string | number;
    CornerRadius: string | number;
    IsTabStop: string | boolean;
    LeftItems: string | Record<string, any>;
    RightItems: string | Record<string, any>;
    TopItems: string | Record<string, any>;
    BottomItems: string | Record<string, any>;
    ContentTemplate: undefined;
    Visibility: string;
    Content: undefined;
    DataContext: undefined;
    'AutomationProperties.Name': string;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
