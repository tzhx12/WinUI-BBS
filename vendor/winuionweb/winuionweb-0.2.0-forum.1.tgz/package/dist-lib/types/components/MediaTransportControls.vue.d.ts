/**
 * MediaPlayerElement owns the transport-control template. This declaration
 * carries the official XAML dependency properties into that template without
 * adding an extra element to the media visual tree.
 *
 * Defaults follow MediaTransportControls::SetupDefaultProperties in
 * WinUI-Reference/dxaml/xcp/dxaml/lib/MediaTransportControls_partial.cpp.
 */
export declare const mediaTransportControlDefaults: {
    readonly IsZoomButtonVisible: true;
    readonly IsZoomEnabled: true;
    readonly IsFullWindowButtonVisible: true;
    readonly IsFullWindowEnabled: true;
    readonly IsFastForwardButtonVisible: false;
    readonly IsFastForwardEnabled: false;
    readonly IsFastRewindButtonVisible: false;
    readonly IsFastRewindEnabled: false;
    readonly IsStopButtonVisible: false;
    readonly IsStopEnabled: false;
    readonly IsVolumeButtonVisible: true;
    readonly IsVolumeEnabled: true;
    readonly IsPlaybackRateButtonVisible: false;
    readonly IsPlaybackRateEnabled: false;
    readonly IsSeekBarVisible: true;
    readonly IsSeekEnabled: true;
    readonly IsCompact: false;
    readonly IsSkipForwardButtonVisible: false;
    readonly IsSkipForwardEnabled: false;
    readonly IsSkipBackwardButtonVisible: false;
    readonly IsSkipBackwardEnabled: false;
    readonly IsNextTrackButtonVisible: false;
    readonly IsPreviousTrackButtonVisible: false;
    readonly FastPlayFallbackBehaviour: "Skip";
    readonly ShowAndHideAutomatically: true;
    readonly IsRepeatEnabled: false;
    readonly IsRepeatButtonVisible: false;
};
export type MediaTransportControlProperty = keyof typeof mediaTransportControlDefaults;
declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    [k: string]: {
        type: StringConstructor | (StringConstructor | BooleanConstructor)[];
        default: boolean | "Skip";
    };
}>, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    [k: string]: {
        type: StringConstructor | (StringConstructor | BooleanConstructor)[];
        default: boolean | "Skip";
    };
}>> & Readonly<{}>, {
    [x: string]: string | boolean;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
