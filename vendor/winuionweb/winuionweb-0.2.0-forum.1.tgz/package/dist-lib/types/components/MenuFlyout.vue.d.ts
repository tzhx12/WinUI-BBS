import { type PropType, type WritableComputedRef } from 'vue';
declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    Items: {
        type: PropType<unknown>;
        default: unknown;
    };
    MenuFlyoutPresenterStyle: {
        type: PropType<unknown>;
        default: unknown;
    };
    Placement: {
        type: StringConstructor;
        default: string;
    };
    ShowMode: {
        type: StringConstructor;
        default: string;
    };
    LightDismissOverlayMode: {
        type: StringConstructor;
        default: string;
    };
    AreOpenCloseAnimationsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    ShouldConstrainToRootBounds: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    AllowFocusOnInteraction: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    AllowFocusWhenDisabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    OverlayInputPassThroughElement: {
        type: PropType<unknown>;
        default: unknown;
    };
}>, {
    Items: WritableComputedRef<{
        GetAt: (index: number) => any;
        Add: (item: unknown) => void;
        Append: (item: unknown) => void;
        InsertAt: (index: number, item: unknown) => void;
        SetAt: (index: number, item: unknown) => void;
        RemoveAt: (index: number) => void;
        RemoveAtEnd: () => void;
        Clear: () => void;
        IndexOf: (item: unknown) => any;
        ReplaceAll: (items: unknown[]) => void;
    }, unknown>;
    ShowAt: (target?: unknown, options?: Record<string, unknown>) => Promise<void>;
    Hide: (restoreFocus?: boolean) => void;
    IsOpen: import("vue").ComputedRef<any>;
    Target: import("vue").ComputedRef<any>;
    IsConstrainedToRootBounds: import("vue").ComputedRef<boolean>;
    Placement: WritableComputedRef<unknown, unknown>;
    AllowFocusOnInteraction: WritableComputedRef<unknown, unknown>;
    AllowFocusWhenDisabled: WritableComputedRef<unknown, unknown>;
    ShowMode: WritableComputedRef<unknown, unknown>;
    AreOpenCloseAnimationsEnabled: WritableComputedRef<unknown, unknown>;
    ShouldConstrainToRootBounds: WritableComputedRef<unknown, unknown>;
    LightDismissOverlayMode: WritableComputedRef<unknown, unknown>;
    MenuFlyoutPresenterStyle: WritableComputedRef<unknown, unknown>;
    OverlayInputPassThroughElement: WritableComputedRef<unknown, unknown>;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    Opening: (...args: any[]) => void;
    Opened: (...args: any[]) => void;
    Closing: (...args: any[]) => void;
    Closed: (...args: any[]) => void;
    "update:AllowFocusOnInteraction": (...args: any[]) => void;
    "update:AllowFocusWhenDisabled": (...args: any[]) => void;
    "update:Placement": (...args: any[]) => void;
    "update:ShowMode": (...args: any[]) => void;
    "update:AreOpenCloseAnimationsEnabled": (...args: any[]) => void;
    "update:ShouldConstrainToRootBounds": (...args: any[]) => void;
    "update:LightDismissOverlayMode": (...args: any[]) => void;
    "update:Items": (...args: any[]) => void;
    "update:MenuFlyoutPresenterStyle": (...args: any[]) => void;
    "update:OverlayInputPassThroughElement": (...args: any[]) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    Items: {
        type: PropType<unknown>;
        default: unknown;
    };
    MenuFlyoutPresenterStyle: {
        type: PropType<unknown>;
        default: unknown;
    };
    Placement: {
        type: StringConstructor;
        default: string;
    };
    ShowMode: {
        type: StringConstructor;
        default: string;
    };
    LightDismissOverlayMode: {
        type: StringConstructor;
        default: string;
    };
    AreOpenCloseAnimationsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    ShouldConstrainToRootBounds: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    AllowFocusOnInteraction: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    AllowFocusWhenDisabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    OverlayInputPassThroughElement: {
        type: PropType<unknown>;
        default: unknown;
    };
}>> & Readonly<{
    onOpening?: ((...args: any[]) => any) | undefined;
    onOpened?: ((...args: any[]) => any) | undefined;
    onClosing?: ((...args: any[]) => any) | undefined;
    onClosed?: ((...args: any[]) => any) | undefined;
    "onUpdate:AllowFocusOnInteraction"?: ((...args: any[]) => any) | undefined;
    "onUpdate:AllowFocusWhenDisabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:Placement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:ShowMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:AreOpenCloseAnimationsEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:ShouldConstrainToRootBounds"?: ((...args: any[]) => any) | undefined;
    "onUpdate:LightDismissOverlayMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:Items"?: ((...args: any[]) => any) | undefined;
    "onUpdate:MenuFlyoutPresenterStyle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:OverlayInputPassThroughElement"?: ((...args: any[]) => any) | undefined;
}>, {
    Placement: string;
    AllowFocusOnInteraction: string | boolean;
    AllowFocusWhenDisabled: string | boolean;
    ShowMode: string;
    AreOpenCloseAnimationsEnabled: string | boolean;
    ShouldConstrainToRootBounds: string | boolean;
    LightDismissOverlayMode: string;
    Items: unknown;
    MenuFlyoutPresenterStyle: unknown;
    OverlayInputPassThroughElement: unknown;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
