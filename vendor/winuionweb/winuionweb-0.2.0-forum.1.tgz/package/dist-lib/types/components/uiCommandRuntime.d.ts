import type { CommandIconSource, KeyboardAccelerator, UICommand } from './XamlUICommand';
export interface UICommandMetadata extends UICommand {
    Label?: string;
    Description?: string;
    AccessKey?: string;
    IconSource?: string | CommandIconSource;
    KeyboardAccelerators?: KeyboardAccelerator[];
    MatchesKeyboardEvent?: (event: KeyboardEvent) => boolean;
    addEventListener?: (name: 'CanExecuteChanged' | 'PropertyChanged', handler: (...args: any[]) => void) => void;
    removeEventListener?: (name: 'CanExecuteChanged' | 'PropertyChanged', handler: (...args: any[]) => void) => void;
}
/** Command notifications invalidate hosts even when the command is not a Vue proxy. */
export declare const useUICommand: (read: () => unknown) => import("vue").ComputedRef<UICommandMetadata | undefined>;
