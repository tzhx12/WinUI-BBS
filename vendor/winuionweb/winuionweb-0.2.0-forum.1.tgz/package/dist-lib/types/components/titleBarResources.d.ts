export declare const titleBarResources: Readonly<Record<string, unknown>>;
export declare const titleBarBrushAliases: Readonly<Record<string, string>>;
export declare const titleBarHighContrastBrushAliases: Readonly<Record<string, string>>;
