import { type VNode } from 'vue';
declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    Child: {
        type: null;
        default: undefined;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
    Stretch: {
        type: StringConstructor;
        default: string;
    };
    StretchDirection: {
        type: StringConstructor;
        default: string;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
}>, {
    Child: import("vue").WritableComputedRef<VNode<import("vue").RendererNode, import("vue").RendererElement, {
        [key: string]: any;
    }> | null, VNode<import("vue").RendererNode, import("vue").RendererElement, {
        [key: string]: any;
    }> | null>;
    Stretch: import("vue").WritableComputedRef<string, string>;
    StretchDirection: import("vue").WritableComputedRef<string, string>;
    DesiredSize: import("vue").ComputedRef<{
        width: number;
        height: number;
    }>;
    RenderSize: import("vue").Ref<{
        width: number;
        height: number;
    }, {
        width: number;
        height: number;
    } | {
        width: number;
        height: number;
    }>;
    rootRef: import("vue").Ref<HTMLElement | null, HTMLElement | null>;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:Child": (...args: any[]) => void;
    "update:Stretch": (...args: any[]) => void;
    "update:StretchDirection": (...args: any[]) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    Child: {
        type: null;
        default: undefined;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
    Stretch: {
        type: StringConstructor;
        default: string;
    };
    StretchDirection: {
        type: StringConstructor;
        default: string;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
}>> & Readonly<{
    "onUpdate:Child"?: ((...args: any[]) => any) | undefined;
    "onUpdate:Stretch"?: ((...args: any[]) => any) | undefined;
    "onUpdate:StretchDirection"?: ((...args: any[]) => any) | undefined;
}>, {
    Stretch: string;
    Width: string | number;
    Height: string | number;
    MinWidth: string | number;
    MaxWidth: string | number;
    MinHeight: string | number;
    MaxHeight: string | number;
    Margin: string | number;
    HorizontalAlignment: string;
    VerticalAlignment: string;
    Visibility: string;
    Child: any;
    StretchDirection: string;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
