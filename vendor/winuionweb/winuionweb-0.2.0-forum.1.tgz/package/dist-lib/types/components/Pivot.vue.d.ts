import { type PropType } from 'vue';
declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    Title: {
        type: PropType<unknown>;
        default: null;
    };
    TitleTemplate: {
        type: PropType<unknown>;
        default: null;
    };
    HeaderTemplate: {
        type: PropType<unknown>;
        default: null;
    };
    LeftHeader: {
        type: PropType<unknown>;
        default: null;
    };
    LeftHeaderTemplate: {
        type: PropType<unknown>;
        default: null;
    };
    RightHeader: {
        type: PropType<unknown>;
        default: null;
    };
    RightHeaderTemplate: {
        type: PropType<unknown>;
        default: null;
    };
    ItemsSource: {
        type: PropType<unknown>;
        default: null;
    };
    ItemTemplate: {
        type: PropType<unknown>;
        default: null;
    };
    ItemsPanel: {
        type: PropType<unknown>;
        default: null;
    };
    SelectedIndex: {
        type: PropType<unknown>;
        default: undefined;
    };
    SelectedItem: {
        type: PropType<unknown>;
        default: undefined;
    };
    IsLocked: {
        type: PropType<unknown>;
        default: boolean;
    };
    IsHeaderItemsCarouselEnabled: {
        type: PropType<unknown>;
        default: boolean;
    };
    HeaderFocusVisualPlacement: {
        type: PropType<unknown>;
        default: string;
    };
    IsEnabled: {
        type: PropType<unknown>;
        default: boolean;
    };
    IsTabStop: {
        type: PropType<unknown>;
        default: boolean;
    };
    Visibility: {
        type: PropType<unknown>;
        default: string;
    };
    Background: {
        type: PropType<unknown>;
        default: string;
    };
    Foreground: {
        type: PropType<unknown>;
        default: string;
    };
    Margin: {
        type: PropType<unknown>;
        default: number;
    };
    Padding: {
        type: PropType<unknown>;
        default: number;
    };
    Width: {
        type: PropType<unknown>;
        default: string;
    };
    Height: {
        type: PropType<unknown>;
        default: string;
    };
    MinWidth: {
        type: PropType<unknown>;
        default: string;
    };
    MinHeight: {
        type: PropType<unknown>;
        default: string;
    };
    MaxWidth: {
        type: PropType<unknown>;
        default: string;
    };
    MaxHeight: {
        type: PropType<unknown>;
        default: string;
    };
    HorizontalAlignment: {
        type: PropType<unknown>;
        default: string;
    };
    VerticalAlignment: {
        type: PropType<unknown>;
        default: string;
    };
    FlowDirection: {
        type: PropType<unknown>;
        default: string;
    };
    RequestedTheme: {
        type: PropType<unknown>;
        default: string;
    };
    Opacity: {
        type: PropType<unknown>;
        default: number;
    };
    IsHitTestVisible: {
        type: PropType<unknown>;
        default: boolean;
    };
}>, {
    SelectedIndex: number;
    SelectedItem: unknown;
    readonly Items: unknown[];
    readonly IsLocked: boolean;
    readonly IsHeaderItemsCarouselEnabled: boolean;
    readonly ActualWidth: number;
    readonly ActualHeight: number;
    ContainerFromIndex(index: number): unknown;
    IndexFromContainer(container: unknown): number;
    Focus(): boolean;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    SelectionChanged: (...args: any[]) => void;
    PivotItemLoading: (...args: any[]) => void;
    PivotItemLoaded: (...args: any[]) => void;
    PivotItemUnloading: (...args: any[]) => void;
    PivotItemUnloaded: (...args: any[]) => void;
    "update:SelectedItem": (...args: any[]) => void;
    "update:SelectedIndex": (...args: any[]) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    Title: {
        type: PropType<unknown>;
        default: null;
    };
    TitleTemplate: {
        type: PropType<unknown>;
        default: null;
    };
    HeaderTemplate: {
        type: PropType<unknown>;
        default: null;
    };
    LeftHeader: {
        type: PropType<unknown>;
        default: null;
    };
    LeftHeaderTemplate: {
        type: PropType<unknown>;
        default: null;
    };
    RightHeader: {
        type: PropType<unknown>;
        default: null;
    };
    RightHeaderTemplate: {
        type: PropType<unknown>;
        default: null;
    };
    ItemsSource: {
        type: PropType<unknown>;
        default: null;
    };
    ItemTemplate: {
        type: PropType<unknown>;
        default: null;
    };
    ItemsPanel: {
        type: PropType<unknown>;
        default: null;
    };
    SelectedIndex: {
        type: PropType<unknown>;
        default: undefined;
    };
    SelectedItem: {
        type: PropType<unknown>;
        default: undefined;
    };
    IsLocked: {
        type: PropType<unknown>;
        default: boolean;
    };
    IsHeaderItemsCarouselEnabled: {
        type: PropType<unknown>;
        default: boolean;
    };
    HeaderFocusVisualPlacement: {
        type: PropType<unknown>;
        default: string;
    };
    IsEnabled: {
        type: PropType<unknown>;
        default: boolean;
    };
    IsTabStop: {
        type: PropType<unknown>;
        default: boolean;
    };
    Visibility: {
        type: PropType<unknown>;
        default: string;
    };
    Background: {
        type: PropType<unknown>;
        default: string;
    };
    Foreground: {
        type: PropType<unknown>;
        default: string;
    };
    Margin: {
        type: PropType<unknown>;
        default: number;
    };
    Padding: {
        type: PropType<unknown>;
        default: number;
    };
    Width: {
        type: PropType<unknown>;
        default: string;
    };
    Height: {
        type: PropType<unknown>;
        default: string;
    };
    MinWidth: {
        type: PropType<unknown>;
        default: string;
    };
    MinHeight: {
        type: PropType<unknown>;
        default: string;
    };
    MaxWidth: {
        type: PropType<unknown>;
        default: string;
    };
    MaxHeight: {
        type: PropType<unknown>;
        default: string;
    };
    HorizontalAlignment: {
        type: PropType<unknown>;
        default: string;
    };
    VerticalAlignment: {
        type: PropType<unknown>;
        default: string;
    };
    FlowDirection: {
        type: PropType<unknown>;
        default: string;
    };
    RequestedTheme: {
        type: PropType<unknown>;
        default: string;
    };
    Opacity: {
        type: PropType<unknown>;
        default: number;
    };
    IsHitTestVisible: {
        type: PropType<unknown>;
        default: boolean;
    };
}>> & Readonly<{
    onSelectionChanged?: ((...args: any[]) => any) | undefined;
    onPivotItemLoading?: ((...args: any[]) => any) | undefined;
    onPivotItemLoaded?: ((...args: any[]) => any) | undefined;
    onPivotItemUnloading?: ((...args: any[]) => any) | undefined;
    onPivotItemUnloaded?: ((...args: any[]) => any) | undefined;
    "onUpdate:SelectedItem"?: ((...args: any[]) => any) | undefined;
    "onUpdate:SelectedIndex"?: ((...args: any[]) => any) | undefined;
}>, {
    Width: string;
    Height: string;
    MinWidth: string;
    MaxWidth: string;
    MinHeight: string;
    MaxHeight: string;
    Margin: number;
    Padding: number;
    HorizontalAlignment: string;
    VerticalAlignment: string;
    Foreground: string;
    Opacity: number;
    IsEnabled: boolean;
    Background: string;
    IsTabStop: boolean;
    RequestedTheme: string;
    SelectedItem: undefined;
    ItemTemplate: null;
    HeaderTemplate: null;
    TitleTemplate: null;
    LeftHeaderTemplate: null;
    RightHeaderTemplate: null;
    Visibility: string;
    IsHitTestVisible: boolean;
    FlowDirection: string;
    ItemsSource: null;
    Title: null;
    LeftHeader: null;
    RightHeader: null;
    ItemsPanel: null;
    SelectedIndex: undefined;
    IsLocked: boolean;
    IsHeaderItemsCarouselEnabled: boolean;
    HeaderFocusVisualPlacement: string;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
