import { type SystemBackdropConfig, type SystemBackdropType } from './systemBackdrop';
import type { TitleBarWindowHost } from './titleBarHostAdapter';
export declare const systemBackdropHostAdapterKey: unique symbol;
export type SystemBackdropTheme = 'Default' | 'Light' | 'Dark';
export type SystemBackdropFallbackReason = 'NativeBackdropUnavailable' | 'MaterialUnsupported' | 'Inactive' | 'HighContrast' | 'TransparencyDisabled' | 'EnergySaver' | 'HostError';
export type SystemBackdropTargetKind = 'Window' | 'Surface';
/** Keep unsupported desktop materials visually aligned with the Mica fallback. */
export declare const systemBackdropFallbackColor: (theme: "Light" | "Dark") => string;
type Awaitable<T> = T | Promise<T>;
export interface SystemBackdropState {
    Status: 'Active' | 'Fallback' | 'HighContrast' | 'Closed';
    RequestedBackdrop: SystemBackdropConfig | null;
    AppliedBackdrop: SystemBackdropConfig | null;
    RequestedTheme: SystemBackdropTheme;
    Theme: 'Light' | 'Dark';
    IsInputActive: boolean;
    Reason?: SystemBackdropFallbackReason;
    Error?: unknown;
}
export interface SystemBackdropConfiguration {
    Theme: 'Light' | 'Dark';
    IsInputActive: boolean;
    IsHighContrast: boolean;
    IsTransparencyEnabled: boolean;
    IsEnergySaverEnabled: boolean;
    /** Optional exact fallback supplied by the native material controller. */
    FallbackColor?: string;
}
export interface SystemBackdropCapabilities {
    /** True only when the host actually exposes the desktop compositor. */
    NativeSystemBackdrop: boolean;
    SupportedMaterials: readonly SystemBackdropType[];
    SupportedMicaKinds?: readonly ('Base' | 'BaseAlt')[];
    SupportedDesktopAcrylicKinds?: readonly ('Base' | 'Thin')[];
    /** True only when this host supports real content extension into its caption. */
    ExtendsContentIntoTitleBar?: boolean;
}
export interface SystemBackdropHostEvent {
    Type: 'Activated' | 'Closed' | 'CapabilitiesChanged' | 'ConfigurationChanged';
    IsInputActive?: boolean;
}
/** The adapter owns its actual browser/native window or backdrop surface. */
export interface SystemBackdropHostTarget {
    Id: string | number;
    /** Opaque association supplied by a native host for this existing window. */
    NativeAssociationToken?: string;
    /** Actual caption ownership and safe geometry, carried into the content runtime. */
    TitleBarHost?: TitleBarWindowHost;
    Content: HTMLElement;
    Window?: Window | null;
    Kind: SystemBackdropTargetKind;
    Subscribe?(listener: (event: SystemBackdropHostEvent) => void): () => void;
    SetContentElement?(element: HTMLElement): void;
    /** Activate the actual native window; browsers use their real focus API. */
    Activate?(): Awaitable<void>;
    Dispose?(): Awaitable<void>;
    Close(): Awaitable<void>;
}
export interface SystemBackdropWindowOptions {
    title: string;
    width?: number;
    height?: number;
    /** Native Window.ExtendsContentIntoTitleBar request, never simulated browser chrome. */
    extendsContentIntoTitleBar?: boolean;
    theme?: SystemBackdropTheme;
    backdrop?: unknown;
    adapter?: SystemBackdropHostAdapter;
    signal?: AbortSignal;
    /** React, Vue, Angular and Svelte can all mount into this stable DOM host. */
    mountContent?: (element: HTMLElement, handle: SystemBackdropWindowHandle) => void | (() => Awaitable<void>);
}
export interface SystemBackdropExistingWindowOptions extends Pick<SystemBackdropWindowOptions, 'theme' | 'backdrop' | 'adapter' | 'signal' | 'mountContent'> {
    /** The persisted identity of this window, without opening a replacement. */
    id?: string | number;
    /** Real native association only; browser window IDs are not native tokens. */
    nativeAssociationToken?: string;
}
export interface SystemBackdropHostAdapter {
    /** Invoke the actual open synchronously when browser user activation is required. */
    CreateWindow(options: SystemBackdropWindowOptions): Awaitable<SystemBackdropHostTarget>;
    /** Reconnect this content's existing window; must never open a replacement. */
    AttachWindow?(element: HTMLElement, options: SystemBackdropExistingWindowOptions): Awaitable<SystemBackdropHostTarget>;
    ConnectSurface?(element: HTMLElement): Awaitable<SystemBackdropHostTarget>;
    GetCapabilities(target: SystemBackdropHostTarget): Awaitable<SystemBackdropCapabilities>;
    /** Native accessibility, energy and transparency policy, when available. */
    GetConfiguration?(target: SystemBackdropHostTarget): Awaitable<Partial<SystemBackdropConfiguration>>;
    /** Return true only after the requested native effect has actually been applied. */
    ApplyBackdrop(target: SystemBackdropHostTarget, backdrop: SystemBackdropConfig | null, configuration: SystemBackdropConfiguration): Awaitable<boolean>;
    SetTheme?(target: SystemBackdropHostTarget, theme: SystemBackdropTheme): Awaitable<void>;
}
export interface SystemBackdropWindowHandle {
    readonly Id: string | number;
    readonly NativeAssociationToken?: string;
    readonly TitleBarHost?: TitleBarWindowHost;
    readonly Content: HTMLElement;
    readonly Window: Window | null;
    readonly State: SystemBackdropState;
    SetSystemBackdrop(backdrop: unknown): Promise<SystemBackdropState>;
    SetTheme(theme: SystemBackdropTheme): Promise<SystemBackdropState>;
    SetContentElement(element: HTMLElement): Promise<SystemBackdropState>;
    Subscribe(listener: (state: SystemBackdropState) => void): () => void;
    Activate(): Promise<void>;
    /** Release the material connection without closing an existing window. */
    Dispose(): Promise<void>;
    Close(): Promise<void>;
}
export declare class SystemBackdropWindowError extends Error {
    readonly Code: 'PopupBlocked' | 'HostUnavailable' | 'HostError' | 'MountFailed';
    constructor(Code: 'PopupBlocked' | 'HostUnavailable' | 'HostError' | 'MountFailed', message: string, options?: ErrorOptions);
}
export declare function setSystemBackdropHostAdapter(adapter: SystemBackdropHostAdapter | undefined): () => void;
export declare function getSystemBackdropHostAdapter(): SystemBackdropHostAdapter | undefined;
/** Real browser window: unavailable native materials are reported without imitation. */
export declare function createBrowserSystemBackdropHostAdapter(opener?: Window): SystemBackdropHostAdapter;
/** Create a real window; invokes the host before awaiting so popup activation survives. */
export declare function createSystemBackdropWindow(options: SystemBackdropWindowOptions): Promise<SystemBackdropWindowHandle>;
/** Restore an existing framework window after reload, without calling window.open. */
export declare function attachSystemBackdropWindow(element: HTMLElement, options?: SystemBackdropExistingWindowOptions): Promise<SystemBackdropWindowHandle>;
/** Connect only while the FrameworkElement is in the live DOM tree. */
export declare function createSystemBackdropSurface(element: HTMLElement, options?: Pick<SystemBackdropWindowOptions, 'theme' | 'backdrop' | 'adapter' | 'signal'>): Promise<SystemBackdropWindowHandle>;
export {};
