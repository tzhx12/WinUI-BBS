import { type Ref } from 'vue';
export type FlyoutAnimationOrigin = 'element' | 'edge' | 'rect' | 'center';
export type FlyoutAnimationDirection = 'top' | 'bottom' | 'left' | 'right';
export type FlyoutAnimationRect = {
    left: number;
    right: number;
    top: number;
    bottom: number;
};
export type FlyoutAnimationOriginElement = HTMLElement | string | Ref<HTMLElement | null> | null;
export type Resolvable<T> = T | (() => T);
export interface FlyoutAnimationOptions {
    Origin?: Resolvable<FlyoutAnimationOrigin>;
    Direction?: Resolvable<FlyoutAnimationDirection>;
    OriginElement?: Resolvable<FlyoutAnimationOriginElement>;
    StartRect?: Resolvable<FlyoutAnimationRect | null> | ((targetRect: DOMRect) => FlyoutAnimationRect | null);
    Duration?: Resolvable<number>;
    Easing?: Resolvable<string>;
    Margin?: Resolvable<number>;
    StripSize?: Resolvable<number>;
    RespectReducedMotion?: Resolvable<boolean>;
}
export interface FlyoutAnimationHandle {
    play: () => void;
    playReverse: () => void;
    cancel: () => void;
    isPlaying: Ref<boolean>;
}
export declare const FlyoutAnimationDefaults: {
    readonly Origin: "edge";
    readonly Direction: "top";
    readonly Duration: 800;
    readonly Easing: "cubic-bezier(0.092,1.003,0.028,0.997)";
    readonly Margin: 15;
    readonly StripSize: 36;
    readonly RespectReducedMotion: true;
};
export declare const useFlyoutAnimation: (targetRef: HTMLElement | Ref<HTMLElement | null> | (() => HTMLElement | null), options?: FlyoutAnimationOptions) => FlyoutAnimationHandle;
