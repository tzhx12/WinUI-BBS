import type { PopupBounds } from './popupRuntime';
export type TeachingTipPlacement = 'Top' | 'Bottom' | 'Left' | 'Right' | 'TopRight' | 'TopLeft' | 'BottomRight' | 'BottomLeft' | 'LeftTop' | 'LeftBottom' | 'RightTop' | 'RightBottom' | 'Center';
interface Thickness {
    left: number;
    top: number;
    right: number;
    bottom: number;
}
interface Size {
    width: number;
    height: number;
}
export declare function teachingTipThickness(value: unknown): Thickness;
export declare function teachingTipTailSide(placement: TeachingTipPlacement): 'top' | 'bottom' | 'left' | 'right';
export declare function teachingTipPlacement(target: DOMRect | null, size: Size, bounds: PopupBounds, preferred: string, margin: Thickness, heroPlacement: string, hasHero: boolean, rtl?: boolean): {
    left: number;
    top: number;
    placement: TeachingTipPlacement;
};
export {};
