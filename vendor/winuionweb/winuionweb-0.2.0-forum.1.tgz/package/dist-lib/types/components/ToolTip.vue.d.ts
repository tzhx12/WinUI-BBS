import { type ToolTipController } from './toolTipRuntime';
declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    Content: {
        type: (NumberConstructor | StringConstructor | ObjectConstructor)[];
        default: unknown;
    };
    ContentTemplate: {
        type: (StringConstructor | ObjectConstructor | FunctionConstructor)[];
        default: null;
    };
    ContentTransitions: {
        type: (StringConstructor | ArrayConstructor | ObjectConstructor)[];
        default: null;
    };
    IsOpen: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    Placement: {
        type: StringConstructor;
        default: string;
    };
    PlacementTarget: {
        type: import("vue").PropType<object | string | null>;
        default: null;
    };
    PlacementRect: {
        type: import("vue").PropType<object | string | null>;
        default: null;
    };
    HorizontalOffset: {
        type: (NumberConstructor | StringConstructor)[];
        default: undefined;
    };
    VerticalOffset: {
        type: (NumberConstructor | StringConstructor)[];
        default: undefined;
    };
    Background: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    Foreground: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    BorderBrush: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    BorderThickness: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    Padding: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    FontFamily: {
        type: StringConstructor;
        default: string;
    };
    FontSize: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    CornerRadius: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    BackgroundSizing: {
        type: StringConstructor;
        default: string;
    };
    HorizontalContentAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalContentAlignment: {
        type: StringConstructor;
        default: string;
    };
    RequestedTheme: {
        type: StringConstructor;
        default: string;
    };
}>, {
    Controller: ToolTipController;
    IsOpen: import("vue").WritableComputedRef<boolean, boolean>;
    TemplateSettings: {
        FromHorizontalOffset: number;
        FromVerticalOffset: number;
    };
    show: (immediate?: boolean) => void;
    hide: () => void;
    updatePosition: () => Promise<void>;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    Opened: (...args: any[]) => void;
    Closed: (...args: any[]) => void;
    "update:IsOpen": (...args: any[]) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    Content: {
        type: (NumberConstructor | StringConstructor | ObjectConstructor)[];
        default: unknown;
    };
    ContentTemplate: {
        type: (StringConstructor | ObjectConstructor | FunctionConstructor)[];
        default: null;
    };
    ContentTransitions: {
        type: (StringConstructor | ArrayConstructor | ObjectConstructor)[];
        default: null;
    };
    IsOpen: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    Placement: {
        type: StringConstructor;
        default: string;
    };
    PlacementTarget: {
        type: import("vue").PropType<object | string | null>;
        default: null;
    };
    PlacementRect: {
        type: import("vue").PropType<object | string | null>;
        default: null;
    };
    HorizontalOffset: {
        type: (NumberConstructor | StringConstructor)[];
        default: undefined;
    };
    VerticalOffset: {
        type: (NumberConstructor | StringConstructor)[];
        default: undefined;
    };
    Background: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    Foreground: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    BorderBrush: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    BorderThickness: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    Padding: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    FontFamily: {
        type: StringConstructor;
        default: string;
    };
    FontSize: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    CornerRadius: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    BackgroundSizing: {
        type: StringConstructor;
        default: string;
    };
    HorizontalContentAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalContentAlignment: {
        type: StringConstructor;
        default: string;
    };
    RequestedTheme: {
        type: StringConstructor;
        default: string;
    };
}>> & Readonly<{
    onOpened?: ((...args: any[]) => any) | undefined;
    onClosed?: ((...args: any[]) => any) | undefined;
    "onUpdate:IsOpen"?: ((...args: any[]) => any) | undefined;
}>, {
    Width: string | number;
    Height: string | number;
    MaxWidth: string | number;
    MaxHeight: string | number;
    Padding: string | number;
    Foreground: string | Record<string, any>;
    IsEnabled: string | boolean;
    Background: string | Record<string, any>;
    BorderBrush: string | Record<string, any>;
    BorderThickness: string | number;
    CornerRadius: string | number;
    FontSize: string | number;
    HorizontalContentAlignment: string;
    VerticalContentAlignment: string;
    BackgroundSizing: string;
    FontFamily: string;
    RequestedTheme: string;
    ContentTemplate: string | Function | Record<string, any>;
    Content: string | number | Record<string, any>;
    ContentTransitions: string | unknown[] | Record<string, any>;
    IsOpen: string | boolean;
    Placement: string;
    PlacementTarget: string | object | null;
    PlacementRect: string | object | null;
    HorizontalOffset: string | number;
    VerticalOffset: string | number;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
