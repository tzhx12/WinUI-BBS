import { type CSSProperties } from 'vue';
export interface ThemeShadowReceivers extends Iterable<unknown> {
    readonly Count: number;
    readonly Size: number;
    Add(element: unknown): void;
    Append(element: unknown): void;
    Insert(index: number, element: unknown): void;
    InsertAt(index: number, element: unknown): void;
    GetAt(index: number): unknown;
    SetAt(index: number, element: unknown): void;
    IndexOf(element: unknown): number;
    Remove(element: unknown): boolean;
    RemoveAt(index: number): void;
    RemoveAtEnd(): void;
    Clear(): void;
}
export interface ThemeShadowValue {
    readonly __xamlShadow: 'ThemeShadow';
    readonly Receivers: ThemeShadowReceivers;
    readonly IsDisposed: boolean;
    AttachCaster(element: HTMLElement): () => void;
    Dispose(): void;
}
export declare const resolveShadowElement: (value: unknown) => HTMLElement | null;
export declare const isThemeShadow: (value: unknown) => value is ThemeShadowValue;
export declare const createThemeShadow: () => ThemeShadowValue;
export interface ThemeShadowRecipe {
    Elevation: number;
    AmbientBlurRadius: number;
    DirectionalBlurRadius: number;
    AmbientYOffset: number;
    DirectionalYOffset: number;
    AmbientOpacity: number;
    DirectionalOpacity: number;
    AmbientAlpha: number;
    DirectionalAlpha: number;
    Insets: {
        Left: number;
        Top: number;
        Right: number;
        Bottom: number;
    };
}
export declare const getThemeShadowRecipe: (translationZ: unknown, theme: unknown) => ThemeShadowRecipe;
export declare const shadowCornerRadius: (value: unknown) => number;
export declare const themeShadowVisualStyle: (recipe: ThemeShadowRecipe, cornerRadius: number) => CSSProperties;
