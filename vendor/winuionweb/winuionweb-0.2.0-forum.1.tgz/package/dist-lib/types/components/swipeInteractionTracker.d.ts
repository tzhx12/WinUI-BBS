export interface SwipeTrackerBounds {
    minimum: number;
    maximum: number;
}
export declare class BrowserSwipeInteractionTracker {
    private readonly readPosition;
    private readonly writePosition;
    private frame;
    private generation;
    private finish;
    constructor(readPosition: () => number, writePosition: (position: number) => void);
    get Position(): number;
    NaturalRestingPosition(velocity: number): number;
    TryUpdatePosition(position: number, bounds: SwipeTrackerBounds): void;
    Cancel(): void;
    Settle(position: number, velocity: number, bounds: SwipeTrackerBounds): Promise<boolean>;
}
