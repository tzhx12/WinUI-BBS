import { type Ref } from 'vue';
export interface Location {
    Item: unknown;
    Bounds: {
        X: number;
        Y: number;
        Width: number;
        Height: number;
    };
    ZoomPoint?: {
        X: number;
        Y: number;
    };
}
export interface Owner {
    ToggleActiveView: (request?: {
        Item?: unknown;
        OriginalSource?: HTMLElement;
    }) => void;
    HasFocus?: () => boolean;
}
export declare const createSemanticZoomView: (root: Ref<HTMLElement | undefined>, items: () => unknown[], groups: () => unknown[], zoomedIn: boolean) => {
    SemanticZoomOwner: import("vue").ShallowRef<Owner | null, Owner | null>;
    IsActiveView: Ref<boolean, boolean>;
    IsZoomedInView: Ref<boolean, boolean>;
    InitializeViewChange(): void;
    StartViewChangeFrom(source: Location, destination: Location): void;
    StartViewChangeTo(source: Location, destination: Location): void;
    MakeVisible: (location: Location) => void;
    CompleteViewChangeFrom(_source: Location, _destination: Location): void;
    CompleteViewChangeTo(_source: Location, destination: Location): void;
    CompleteViewChange(): void;
    CanHorizontallyScroll: import("vue").ComputedRef<boolean>;
    CanVerticallyScroll: import("vue").ComputedRef<boolean>;
};
