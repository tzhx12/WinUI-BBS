export declare const needsSoftwareMediaDecoder: (source: string, video: HTMLVideoElement) => boolean;
export declare const getBrowserMediaSource: (source: string) => Promise<Blob>;
