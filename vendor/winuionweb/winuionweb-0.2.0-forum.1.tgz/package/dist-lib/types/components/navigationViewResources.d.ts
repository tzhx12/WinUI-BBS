/** Values from NavigationView_themeresources.xaml. Brushes stay theme scoped CSS variables. */
export declare const navigationViewResources: Readonly<Record<string, string | number>>;
