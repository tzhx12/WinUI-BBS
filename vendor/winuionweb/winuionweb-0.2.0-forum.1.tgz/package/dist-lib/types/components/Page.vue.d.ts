import { type VNode } from 'vue';
/**
 * Page publishes resources and RequestedTheme to its content. Explicit
 * framework-element attributes create the content host that arranges children.
 */
export declare const xamlResourceDictionaryKey: unique symbol;
declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: import("vue").DefineComponent<{}, () => VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
