export declare const textControlResources: Readonly<Record<string, unknown>>;
