export type SelectorBarStyle = Readonly<{
    Key: string;
    TargetType: 'SelectorBar' | 'SelectorBarItem';
    Setters: Readonly<Record<string, unknown>>;
}>;
export declare const tokenViewSelectorBarStyle: SelectorBarStyle;
export declare const tokenViewSelectorBarItemStyle: SelectorBarStyle;
export declare const selectorBarStyleSetter: (style: unknown, property: string, targetType: SelectorBarStyle["TargetType"]) => unknown;
export declare const selectorBarResources: Readonly<Record<string, unknown>>;
