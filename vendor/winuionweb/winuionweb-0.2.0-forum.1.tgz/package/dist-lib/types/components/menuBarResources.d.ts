export declare const menuBarResources: Readonly<Record<string, unknown>>;
