import type { ComponentInternalInstance } from 'vue';
export declare const scrollViewerTemplateBindings: (readProperty: (name: string) => unknown, instance: ComponentInternalInstance | null, defaults?: Record<string, unknown>) => Record<string, unknown>;
