/** MenuFlyoutPresenter: Border > ScrollViewer > ItemsPresenter. */
declare const _default: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    Owner: {
        type: ObjectConstructor;
        required: true;
    };
    IsSubmenu: {
        type: BooleanConstructor;
        default: boolean;
    };
}>, () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    Owner: {
        type: ObjectConstructor;
        required: true;
    };
    IsSubmenu: {
        type: BooleanConstructor;
        default: boolean;
    };
}>> & Readonly<{}>, {
    IsSubmenu: boolean;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export default _default;
