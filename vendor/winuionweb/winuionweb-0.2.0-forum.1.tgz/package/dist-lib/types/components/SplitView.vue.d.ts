import { type VNode } from 'vue';
export declare const SplitViewPane: import("vue").DefineComponent<{}, () => VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const SplitViewContent: import("vue").DefineComponent<{}, () => VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    Pane: {
        type: (NumberConstructor | StringConstructor | ObjectConstructor)[];
        default: string;
    };
    Content: {
        type: (NumberConstructor | StringConstructor | ObjectConstructor)[];
        default: string;
    };
    IsPaneOpen: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    DisplayMode: {
        type: StringConstructor;
        default: string;
    };
    PanePlacement: {
        type: StringConstructor;
        default: string;
    };
    OpenPaneLength: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    CompactPaneLength: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    PaneBackground: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    LightDismissOverlayMode: {
        type: StringConstructor;
        default: string;
    };
    Background: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    Foreground: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    BorderBrush: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    BorderThickness: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    CornerRadius: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Padding: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    HorizontalContentAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalContentAlignment: {
        type: StringConstructor;
        default: string;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    IsTabStop: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsHitTestVisible: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    Opacity: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
}>, {
    IsPaneOpen: import("vue").WritableComputedRef<unknown, unknown>;
    DisplayMode: import("vue").WritableComputedRef<unknown, unknown>;
    PanePlacement: import("vue").WritableComputedRef<unknown, unknown>;
    OpenPaneLength: import("vue").WritableComputedRef<unknown, unknown>;
    CompactPaneLength: import("vue").WritableComputedRef<unknown, unknown>;
    PaneBackground: import("vue").WritableComputedRef<unknown, unknown>;
    Background: import("vue").WritableComputedRef<unknown, unknown>;
    LightDismissOverlayMode: import("vue").WritableComputedRef<unknown, unknown>;
    TemplateSettings: import("vue").ComputedRef<{
        OpenPaneLength: number;
        NegativeOpenPaneLength: number;
        OpenPaneLengthMinusCompactLength: number;
        NegativeOpenPaneLengthMinusCompactLength: number;
        OpenPaneGridLength: number;
        CompactPaneGridLength: number;
    }>;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    PaneOpening: (...args: any[]) => void;
    PaneOpened: (...args: any[]) => void;
    PaneClosing: (...args: any[]) => void;
    PaneClosed: (...args: any[]) => void;
    "update:Background": (...args: any[]) => void;
    "update:LightDismissOverlayMode": (...args: any[]) => void;
    "update:IsPaneOpen": (...args: any[]) => void;
    "update:DisplayMode": (...args: any[]) => void;
    "update:PanePlacement": (...args: any[]) => void;
    "update:OpenPaneLength": (...args: any[]) => void;
    "update:CompactPaneLength": (...args: any[]) => void;
    "update:PaneBackground": (...args: any[]) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    Pane: {
        type: (NumberConstructor | StringConstructor | ObjectConstructor)[];
        default: string;
    };
    Content: {
        type: (NumberConstructor | StringConstructor | ObjectConstructor)[];
        default: string;
    };
    IsPaneOpen: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    DisplayMode: {
        type: StringConstructor;
        default: string;
    };
    PanePlacement: {
        type: StringConstructor;
        default: string;
    };
    OpenPaneLength: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    CompactPaneLength: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    PaneBackground: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    LightDismissOverlayMode: {
        type: StringConstructor;
        default: string;
    };
    Background: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    Foreground: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    BorderBrush: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    BorderThickness: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    CornerRadius: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Padding: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    HorizontalContentAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalContentAlignment: {
        type: StringConstructor;
        default: string;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    IsTabStop: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsHitTestVisible: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    Opacity: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
}>> & Readonly<{
    onPaneOpening?: ((...args: any[]) => any) | undefined;
    onPaneOpened?: ((...args: any[]) => any) | undefined;
    onPaneClosing?: ((...args: any[]) => any) | undefined;
    onPaneClosed?: ((...args: any[]) => any) | undefined;
    "onUpdate:Background"?: ((...args: any[]) => any) | undefined;
    "onUpdate:LightDismissOverlayMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:IsPaneOpen"?: ((...args: any[]) => any) | undefined;
    "onUpdate:DisplayMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:PanePlacement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:OpenPaneLength"?: ((...args: any[]) => any) | undefined;
    "onUpdate:CompactPaneLength"?: ((...args: any[]) => any) | undefined;
    "onUpdate:PaneBackground"?: ((...args: any[]) => any) | undefined;
}>, {
    Width: string | number;
    Height: string | number;
    MinWidth: string | number;
    MaxWidth: string | number;
    MinHeight: string | number;
    MaxHeight: string | number;
    Margin: string | number;
    Padding: string | number;
    HorizontalAlignment: string;
    VerticalAlignment: string;
    Foreground: string | Record<string, any>;
    Opacity: string | number;
    IsEnabled: string | boolean;
    Background: string | Record<string, any>;
    BorderBrush: string | Record<string, any>;
    BorderThickness: string | number;
    CornerRadius: string | number;
    HorizontalContentAlignment: string;
    VerticalContentAlignment: string;
    IsTabStop: string | boolean;
    PaneBackground: string | Record<string, any>;
    Visibility: string;
    Content: string | number | Record<string, any>;
    IsHitTestVisible: string | boolean;
    LightDismissOverlayMode: string;
    Pane: string | number | Record<string, any>;
    IsPaneOpen: string | boolean;
    DisplayMode: string;
    PanePlacement: string;
    OpenPaneLength: string | number;
    CompactPaneLength: string | number;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
