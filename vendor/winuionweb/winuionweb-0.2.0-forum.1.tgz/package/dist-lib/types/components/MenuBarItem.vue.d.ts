import { type VNode } from 'vue';
export declare const MenuBarItemItemsProperty: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: {
    new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("vue").ExtractPropTypes<{
        Title: {
            type: (NumberConstructor | StringConstructor | ObjectConstructor)[];
            default: undefined;
        };
        Items: {
            type: (StringConstructor | ArrayConstructor | ObjectConstructor)[];
            default: undefined;
        };
        IsEnabled: {
            type: (StringConstructor | BooleanConstructor)[];
            default: boolean;
        };
        IsTabStop: {
            type: (StringConstructor | BooleanConstructor)[];
            default: boolean;
        };
        Visibility: {
            type: StringConstructor;
            default: string;
        };
    }>> & Readonly<{
        "onUpdate:IsEnabled"?: ((...args: any[]) => any) | undefined;
        "onUpdate:IsTabStop"?: ((...args: any[]) => any) | undefined;
        "onUpdate:Visibility"?: ((...args: any[]) => any) | undefined;
        "onUpdate:Items"?: ((...args: any[]) => any) | undefined;
        "onUpdate:Title"?: ((...args: any[]) => any) | undefined;
    }>, () => VNode<import("vue").RendererNode, import("vue").RendererElement, {
        [key: string]: any;
    }>[], {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, ("update:IsEnabled" | "update:IsTabStop" | "update:Visibility" | "update:Items" | "update:Title")[], import("vue").PublicProps, {
        IsEnabled: string | boolean;
        IsTabStop: string | boolean;
        Visibility: string;
        Items: string | unknown[] | Record<string, any>;
        Title: string | number | Record<string, any>;
    }, true, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
        P: {};
        B: {};
        D: {};
        C: {};
        M: {};
        Defaults: {};
    }, Readonly<import("vue").ExtractPropTypes<{
        Title: {
            type: (NumberConstructor | StringConstructor | ObjectConstructor)[];
            default: undefined;
        };
        Items: {
            type: (StringConstructor | ArrayConstructor | ObjectConstructor)[];
            default: undefined;
        };
        IsEnabled: {
            type: (StringConstructor | BooleanConstructor)[];
            default: boolean;
        };
        IsTabStop: {
            type: (StringConstructor | BooleanConstructor)[];
            default: boolean;
        };
        Visibility: {
            type: StringConstructor;
            default: string;
        };
    }>> & Readonly<{
        "onUpdate:IsEnabled"?: ((...args: any[]) => any) | undefined;
        "onUpdate:IsTabStop"?: ((...args: any[]) => any) | undefined;
        "onUpdate:Visibility"?: ((...args: any[]) => any) | undefined;
        "onUpdate:Items"?: ((...args: any[]) => any) | undefined;
        "onUpdate:Title"?: ((...args: any[]) => any) | undefined;
    }>, () => VNode<import("vue").RendererNode, import("vue").RendererElement, {
        [key: string]: any;
    }>[], {}, {}, {}, {
        IsEnabled: string | boolean;
        IsTabStop: string | boolean;
        Visibility: string;
        Items: string | unknown[] | Record<string, any>;
        Title: string | number | Record<string, any>;
    }>;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
    Title: {
        type: (NumberConstructor | StringConstructor | ObjectConstructor)[];
        default: undefined;
    };
    Items: {
        type: (StringConstructor | ArrayConstructor | ObjectConstructor)[];
        default: undefined;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsTabStop: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
}>> & Readonly<{
    "onUpdate:IsEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:IsTabStop"?: ((...args: any[]) => any) | undefined;
    "onUpdate:Visibility"?: ((...args: any[]) => any) | undefined;
    "onUpdate:Items"?: ((...args: any[]) => any) | undefined;
    "onUpdate:Title"?: ((...args: any[]) => any) | undefined;
}>, () => VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>[], {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, ("update:IsEnabled" | "update:IsTabStop" | "update:Visibility" | "update:Items" | "update:Title")[], "update:IsEnabled" | "update:IsTabStop" | "update:Visibility" | "update:Items" | "update:Title", {
    IsEnabled: string | boolean;
    IsTabStop: string | boolean;
    Visibility: string;
    Items: string | unknown[] | Record<string, any>;
    Title: string | number | Record<string, any>;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & {
    Items: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
};
