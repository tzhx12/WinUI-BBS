import { type RefreshRequestedEventArgs } from './refreshRuntime';
import { RefreshContainerContent, RefreshContainerVisualizer } from './RefreshProperties';
export { RefreshContainerContent, RefreshContainerVisualizer };
declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    Visualizer: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    Content: {
        type: (NumberConstructor | StringConstructor | ObjectConstructor)[];
        default: string;
    };
    PullDirection: {
        type: StringConstructor;
        default: string;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Padding: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    HorizontalContentAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalContentAlignment: {
        type: StringConstructor;
        default: string;
    };
    Background: {
        type: StringConstructor;
        default: string;
    };
    Foreground: {
        type: StringConstructor;
        default: string;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
}>, {
    RequestRefresh: () => void;
    readonly Visualizer: {} | null;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    RefreshRequested: (sender: unknown, args: RefreshRequestedEventArgs) => any;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    Visualizer: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    Content: {
        type: (NumberConstructor | StringConstructor | ObjectConstructor)[];
        default: string;
    };
    PullDirection: {
        type: StringConstructor;
        default: string;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Padding: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    HorizontalContentAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalContentAlignment: {
        type: StringConstructor;
        default: string;
    };
    Background: {
        type: StringConstructor;
        default: string;
    };
    Foreground: {
        type: StringConstructor;
        default: string;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
}>> & Readonly<{
    onRefreshRequested?: ((sender: unknown, args: RefreshRequestedEventArgs) => any) | undefined;
}>, {
    Width: string | number;
    Height: string | number;
    MinWidth: string | number;
    MaxWidth: string | number;
    MinHeight: string | number;
    MaxHeight: string | number;
    Margin: string | number;
    Padding: string | number;
    HorizontalAlignment: string;
    VerticalAlignment: string;
    Foreground: string;
    IsEnabled: string | boolean;
    Background: string;
    HorizontalContentAlignment: string;
    VerticalContentAlignment: string;
    Visibility: string;
    Content: string | number | Record<string, any>;
    Visualizer: string | Record<string, any>;
    PullDirection: string;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
