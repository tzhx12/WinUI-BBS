/** Current Windows/UI accent palette supplied by a WebView host. */
export interface SystemAccentColorPalette {
    AccentColor: string;
    LightThemeAccentColor?: string;
    DarkThemeAccentColor?: string;
    LightThemeTextColor?: string;
    DarkThemeTextColor?: string;
    AccentColorLight1?: string;
    AccentColorLight2?: string;
    AccentColorLight3?: string;
    AccentColorDark1?: string;
    AccentColorDark2?: string;
    AccentColorDark3?: string;
}
/** Framework-neutral native/browser bridge for a live system accent color. */
export interface SystemAccentColorHostAdapter {
    Read(): SystemAccentColorPalette | null;
    Subscribe(listener: (palette: SystemAccentColorPalette | null) => void): () => void;
}
export type SystemAccentColorHostTarget = HTMLElement;
/** Read the browser's live CSS AccentColor system color when available. */
export declare function createBrowserSystemAccentColorHostAdapter(owner?: Window): SystemAccentColorHostAdapter;
/** Connect a native or browser host to the package's theme CSS. */
export declare function connectSystemAccentColorHost(adapter: SystemAccentColorHostAdapter, target?: SystemAccentColorHostTarget): () => void;
