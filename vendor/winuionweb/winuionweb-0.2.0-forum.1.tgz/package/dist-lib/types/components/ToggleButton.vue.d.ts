export declare const ToggleButtonContent: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: __VLS_WithSlots<import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    Content: {
        type: null;
        default: string;
    };
    ContentTemplate: {
        type: null;
        default: undefined;
    };
    ContentTransitions: {
        type: null;
        default: undefined;
    };
    IsChecked: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsThreeState: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    RequestedTheme: {
        type: StringConstructor;
        default: string;
    };
}>, {
    IsChecked: boolean | null;
    IsEnabled: boolean;
    IsThreeState: boolean;
    RequestedTheme: string;
    Command: import("./uiCommandRuntime").UICommandMetadata | undefined;
    CommandParameter: unknown;
    ContentTemplate: any;
    ContentTransitions: any;
    Name: {};
    Content: any;
    Element: any;
    IsPressed: any;
    Focus: () => any;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    Click: (...args: any[]) => void;
    Checked: (...args: any[]) => void;
    Unchecked: (...args: any[]) => void;
    Indeterminate: (...args: any[]) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    Content: {
        type: null;
        default: string;
    };
    ContentTemplate: {
        type: null;
        default: undefined;
    };
    ContentTransitions: {
        type: null;
        default: undefined;
    };
    IsChecked: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsThreeState: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    RequestedTheme: {
        type: StringConstructor;
        default: string;
    };
}>> & Readonly<{
    onClick?: ((...args: any[]) => any) | undefined;
    onChecked?: ((...args: any[]) => any) | undefined;
    onUnchecked?: ((...args: any[]) => any) | undefined;
    onIndeterminate?: ((...args: any[]) => any) | undefined;
}>, {
    IsEnabled: string | boolean;
    RequestedTheme: string;
    IsChecked: string | boolean;
    ContentTemplate: any;
    Content: any;
    ContentTransitions: any;
    IsThreeState: string | boolean;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>, {
    default?: (props: {}) => any;
}>;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
