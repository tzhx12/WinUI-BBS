<template>
  <button
    ref="buttonRef"
    type="button"
    v-bind="buttonAttrs"
    class="win-btn"
    :HorizontalAlignment="resolveXamlValue(props.HorizontalAlignment, instance)"
    :VerticalAlignment="resolveXamlValue(props.VerticalAlignment, instance)"
    :class="[
      styleClass,
      {
        'content-horizontal-stretch': PresenterHorizontalAlignment === 'Stretch',
        'content-vertical-stretch': PresenterVerticalAlignment === 'Stretch',
        'is-pressed': IsPressed,
        'win-theme-scope': RequestedTheme === 'Light' || RequestedTheme === 'Dark',
        'theme-light': RequestedTheme === 'Light',
        'theme-dark': RequestedTheme === 'Dark',
      },
      attrs.class
    ]"
    :style="buttonStyle"
    :disabled="isDisabled"
    :tabindex="boolValue(resolveXamlValue(props.IsTabStop, instance)) ? undefined : -1"
    @click="onNativeClick"
    @pointerenter="onPointerEntered"
    @pointerleave="onPointerExited"
    @pointerdown="onPointerPressed"
    @pointermove="onPointerMoved"
    @pointerup="onPointerReleased"
    @pointercancel="onPointerCanceled"
    @lostpointercapture="onPointerCaptureLost"
    @keydown="onKeyDown"
    @keyup="onKeyUp"
    @focusout="onLostFocus"
    @contextmenu="onContextRequested"
    @focus="onGotFocus">
    <Grid v-if="titleBarStylePrefix" x:Name="RootGrid" class="win-titlebar-button-root"
      Background="{x:Bind PresenterBackground}" CornerRadius="{x:Bind PresenterCornerRadius}">
      <ContentOutlet v-if="propertyNodes.content.length" /><ContentValueOutlet v-else />
    </Grid>
    <ContentPresenter v-else class="win-button-content-presenter"
      Background="{x:Bind PresenterBackground}" BackgroundSizing="{x:Bind PresenterBackgroundSizing}"
      BorderBrush="{x:Bind PresenterBorderBrush}" BorderThickness="{x:Bind PresenterBorderThickness}"
      Padding="{x:Bind PresenterPadding}" CornerRadius="{x:Bind PresenterCornerRadius}"
      ContentTemplate="{x:Bind ContentTemplate}" ContentTransitions="{x:Bind ContentTransitions}"
      HorizontalContentAlignment="{x:Bind PresenterHorizontalAlignment}" VerticalContentAlignment="{x:Bind PresenterVerticalAlignment}">
      <ContentOutlet v-if="propertyNodes.content.length" />
      <ContentValueOutlet v-else />
    </ContentPresenter>
    <AttachedOutlet v-if="propertyNodes.attached.length" />
    <FocusVisual
      v-if="boolValue(resolveXamlValue(props.UseSystemFocusVisuals, instance))"
      :Margin="resolveLength(props.FocusVisualMargin) === '' ? -3 : resolveLength(props.FocusVisualMargin)"
      :CornerRadius="PresenterCornerRadius"
      :TargetBorderThickness="PresenterBorderThickness" />
  </button>
  <FlyoutOutlet v-if="propertyNodes.flyout.length" />
</template>
<script lang="ts">
import { defineComponent, h } from 'vue'
import { brushProperty } from './brushProperties'
import { buttonContentProperty } from './buttonContentRuntime'

export const ButtonFlyout = defineComponent({
  name: 'Button.Flyout',
  __buttonProperty: 'flyout',
  setup(_, { slots }) {
    return () => h('span', { class: 'button-flyout-property' }, slots.default?.())
  }
})

export const ButtonContent = defineComponent({ name: 'Button.Content', __buttonProperty: 'content', setup() { return () => null } })
export const ButtonKeyboardAccelerators = defineComponent({ name: 'Button.KeyboardAccelerators', __buttonProperty: 'keyboardAccelerators', setup() { return () => null } })
export default { Flyout: ButtonFlyout, Content: ButtonContent, ContentTemplate: buttonContentProperty('Button', 'ContentTemplate'), ContentTransitions: buttonContentProperty('Button', 'ContentTransitions'), Resources: buttonContentProperty('Button', 'Resources'), KeyboardAccelerators: ButtonKeyboardAccelerators, Background: brushProperty('Button', 'Background') }
</script>
<script setup lang="ts">
import { Comment, computed, Fragment, getCurrentInstance, inject, isVNode, onBeforeUnmount, onMounted, provide, proxyRefs, ref, shallowRef, Text, useAttrs, useSlots, watch, type CSSProperties, type PropType, type StyleValue, type VNode } from 'vue';
import { normalizeXamlNodes, resolveXamlHandler, resolveXamlValue, updateXamlBinding, xamlScopeKey } from './xamlRuntime';
import ContentPresenter from './ContentPresenter.vue';
import FocusVisual from './FocusVisual.vue';
import Grid from './Grid.vue';
import { alignment, boolValue, cssLength, xamlThickness } from './layout';
import { getToolTipServiceProperty } from './ToolTipServiceProperties';
import { useAnimatedIconInput } from './animatedIconInput';
import { isHoverPointer } from './pointerInput';
import { useUICommand } from './uiCommandRuntime';
import { isBrushProperty, useBrushProperty } from './brushProperties';
import { getButtonContentProperty, useButtonContent } from './buttonContentRuntime';

defineOptions({
  inheritAttrs: false
});

const props = defineProps({
  Style: { type: String, default: '' },
  RequestedTheme: { type: String, default: 'Default' },
  Content: { type: null as unknown as PropType<unknown>, default: undefined as unknown },
  ContentTemplate: { type: null as unknown as PropType<unknown>, default: undefined as unknown },
  ContentTransitions: { type: null as unknown as PropType<unknown>, default: undefined as unknown },
  ClickMode: { type: String, default: 'Release' },
  IsTabStop: { type: [Boolean, String], default: true },
  Command: { type: [Object, String], default: undefined },
  CommandParameter: { type: null as unknown as PropType<unknown>, default: undefined as unknown },
  Flyout: { type: null as unknown as PropType<unknown>, default: undefined as unknown },
  IsEnabled: { type: [Boolean, String], default: true },
  Visibility: { type: String, default: 'Visible' },
  Background: { type: [String, Object], default: '' },
  BackgroundSizing: { type: String, default: '' },
  Foreground: { type: String, default: '' },
  BorderBrush: { type: String, default: '' },
  BorderThickness: { type: [String, Number], default: '' },
  Padding: { type: String, default: '' },
  Margin: { type: String, default: '' },
  Width: { type: [String, Number], default: '' },
  Height: { type: [String, Number], default: '' },
  MaxWidth: { type: [String, Number], default: '' },
  MaxHeight: { type: [String, Number], default: '' },
  MinWidth: { type: [String, Number], default: '' },
  MinHeight: { type: [String, Number], default: '' },
  HorizontalAlignment: { type: String, default: 'Left' },
  VerticalAlignment: { type: String, default: 'Center' },
  HorizontalContentAlignment: { type: String, default: '' },
  VerticalContentAlignment: { type: String, default: '' },
  FontFamily: { type: String, default: '' },
  FontWeight: { type: String, default: '' },
  FontSize: { type: [String, Number], default: '' },
  UseSystemFocusVisuals: { type: [Boolean, String], default: true },
  FocusVisualMargin: { type: [String, Number], default: '' },
  CornerRadius: { type: [String, Number], default: '' }
});

const emit = defineEmits(['Click', 'GotFocus', 'LostFocus', 'KeyDown', 'KeyUp', 'ContextRequested', 'PointerEntered', 'PointerExited', 'PointerMoved', 'PointerPressed', 'PointerReleased', 'PointerCanceled', 'PointerCaptureLost']);

const attrs = useAttrs();
const instance = getCurrentInstance();
const slots = useSlots();
const { ContentTemplate, ContentTransitions, renderTemplate } = useButtonContent(props, () => slots.default?.() ?? [], instance);
const backgroundBrush = useBrushProperty('Background', () => props.Background, () => slots.default?.() ?? [], instance);
const buttonRef = ref<HTMLElement | null>(null);
const iconInput = useAnimatedIconInput();
const IsPressed = ref(false);
const IsPointerOver = ref(false);
let activePointer: number | null = null;
let keyPressed = '';
let suppressClick = false;
watch(buttonRef, element => iconInput.Attach(element), { flush: 'post' });
type PointerEventName = 'PointerEntered' | 'PointerExited' | 'PointerMoved' | 'PointerPressed' | 'PointerReleased' | 'PointerCanceled' | 'PointerCaptureLost';
const pointerDeviceTypes: Record<string, string> = { mouse: 'Mouse', touch: 'Touch', pen: 'Pen' };
const pointerEvent = (name: PointerEventName, event: PointerEvent, feedback: (event: PointerEvent) => void) => {
  feedback(event);
  const sender = publicApi;
  const args = {
    OriginalSource: sender, OriginalEvent: event, Handled: false,
    Pointer: { PointerId: event.pointerId, PointerDeviceType: pointerDeviceTypes[event.pointerType] || 'Mouse' },
    GetCurrentPoint: (relativeTo?: HTMLElement | { Element?: HTMLElement }) => {
      const element = relativeTo instanceof HTMLElement ? relativeTo : relativeTo?.Element;
      const bounds = element?.getBoundingClientRect();
      return { Position: { X: event.clientX - (bounds?.left ?? 0), Y: event.clientY - (bounds?.top ?? 0) }, IsInContact: event.buttons > 0 };
    }
  };
  emit(name, sender, args);
  if (attrs[name] && !instance?.vnode.props?.[`on${name}`]) resolveXamlHandler(attrs[name], instance)?.(sender, args);
  if (args.Handled) { event.preventDefault(); event.stopPropagation(); }
};
const onPointerEntered = (event: PointerEvent) => {
  IsPointerOver.value = isHoverPointer(event);
  if (activePointer !== null && event.buttons > 0) IsPressed.value = true;
  pointerEvent('PointerEntered', event, iconInput.PointerEntered);
  if (isHoverPointer(event) && !isDisabled.value && resolveXamlValue(props.ClickMode, instance) === 'Hover') onClick(event);
};
const onPointerExited = (event: PointerEvent) => { IsPointerOver.value = false; IsPressed.value = false; pointerEvent('PointerExited', event, iconInput.PointerExited); };
const clearPressed = () => {
  const pointer = activePointer;
  activePointer = null; IsPressed.value = false; keyPressed = '';
  if (pointer !== null && buttonRef.value?.hasPointerCapture?.(pointer)) {
    try { buttonRef.value.releasePointerCapture(pointer); } catch { }
  }
};
const onPointerPressed = (event: PointerEvent) => {
  if (!isHoverPointer(event)) IsPointerOver.value = false;
  if (!isDisabled.value && event.button === 0 && resolveXamlValue(props.ClickMode, instance) !== 'Hover') {
    suppressClick = false;
    activePointer = event.pointerId;
    IsPressed.value = true;
    buttonRef.value?.setPointerCapture?.(event.pointerId);
    if (resolveXamlValue(props.ClickMode, instance) === 'Press') { onClick(event); suppressClick = true; }
  }
  pointerEvent('PointerPressed', event, iconInput.PointerPressed);
};
const pointerInside = (event: PointerEvent) => { const bounds = buttonRef.value?.getBoundingClientRect(); return bounds && event.clientX >= bounds.left && event.clientX <= bounds.right && event.clientY >= bounds.top && event.clientY <= bounds.bottom; };
const onPointerMoved = (event: PointerEvent) => { if (event.pointerId === activePointer) { IsPressed.value = Boolean(pointerInside(event)); IsPointerOver.value = isHoverPointer(event) && IsPressed.value; } pointerEvent('PointerMoved', event, () => {}); };
const onPointerReleased = (event: PointerEvent) => { if (activePointer !== null && !pointerInside(event)) suppressClick = true; clearPressed(); if (!isHoverPointer(event)) IsPointerOver.value = false; pointerEvent('PointerReleased', event, iconInput.PointerReleased); };
const onPointerCanceled = (event: PointerEvent) => { clearPressed(); if (!isHoverPointer(event)) IsPointerOver.value = false; suppressClick = true; pointerEvent('PointerCanceled', event, iconInput.PointerExited); };
const onPointerCaptureLost = (event: PointerEvent) => { clearPressed(); if (!isHoverPointer(event)) IsPointerOver.value = false; pointerEvent('PointerCaptureLost', event, iconInput.PointerExited); };
const command = useUICommand(() => resolveXamlValue(props.Command, instance));
const commandParameter = computed(() => resolveXamlValue(props.CommandParameter, instance));
const onContextRequested = (event: MouseEvent) => {
  if (isDisabled.value || (!attrs.ContextRequested && !instance?.vnode.props?.onContextRequested)) return;
  const sender = publicApi;
  const args = {
    OriginalSource: sender,
    OriginalEvent: event,
    Handled: false,
    PointerPosition: { X: event.clientX, Y: event.clientY },
    TryGetPosition: (relativeTo?: { Element?: HTMLElement } | HTMLElement) => {
      const element = relativeTo instanceof HTMLElement ? relativeTo : relativeTo?.Element;
      const bounds = element?.getBoundingClientRect();
      return { X: event.clientX - (bounds?.left ?? 0), Y: event.clientY - (bounds?.top ?? 0) };
    }
  };
  emit('ContextRequested', sender, args);
  if (attrs.ContextRequested && !instance?.vnode.props?.onContextRequested) {
    resolveXamlHandler(attrs.ContextRequested, instance)?.(sender, args);
  }
  event.preventDefault();
};
const flyoutController = shallowRef<unknown>(null);
const sourceFlyout = computed(() => resolveXamlValue(props.Flyout, instance));
const localFlyout = shallowRef<unknown>(undefined);
watch(sourceFlyout, () => { localFlyout.value = undefined; });
provide('buttonFlyoutAnchor', buttonRef);
provide('buttonFlyoutController', flyoutController);

const propertyNodes = computed(() => {
  const content: VNode[] = [];
  const flyout: VNode[] = [];
  const attached: VNode[] = [];
  const keyboardAccelerators: VNode[] = [];
  const collect = (nodes: VNode[]) => { for (const node of nodes) {
    if (node.type === Comment || node.type === Text && !String(node.children ?? '').trim()) continue;
    if (isBrushProperty(node) || getButtonContentProperty(node)) continue;
    if (node.type === Fragment && Array.isArray(node.children)) { collect(node.children as VNode[]); continue; }
    const type = node?.type;
    const property = type && typeof type === 'object'
      ? (type as { __buttonProperty?: string }).__buttonProperty
      : undefined;
    if (getToolTipServiceProperty(node)) {
      attached.push(node);
    } else if (property === 'flyout' || property === 'content' || property === 'keyboardAccelerators') {
      const slot = node.children && typeof node.children === 'object'
        ? (node.children as { default?: () => VNode[] }).default
        : undefined;
      if (slot) (property === 'flyout' ? flyout : property === 'content' ? content : keyboardAccelerators).push(...slot());
    } else {
      content.push(node);
    }
  } };
  collect(slots.default?.() ?? []);
  const definition = localFlyout.value === undefined ? sourceFlyout.value : localFlyout.value;
  if (localFlyout.value !== undefined) flyout.length = 0;
  if (!flyout.length && isVNode(definition)) flyout.push(definition);
  return { content, flyout, attached, keyboardAccelerators };
});

const ContentOutlet = defineComponent({
  name: 'ButtonContentOutlet',
  setup() {
    return () => {
      const templated = renderTemplate(localContent.value === undefined ? resolvedContent.value : localContent.value);
      if (templated) return templated;
      if (localContent.value !== undefined) return typeof localContent.value === 'string' || typeof localContent.value === 'number'
        ? h('span', { class: 'win-button-default-text' }, String(localContent.value))
        : h(Fragment, isVNode(localContent.value) ? normalizeXamlNodes([localContent.value], instance) : []);
      const nodes = normalizeXamlNodes(propertyNodes.value.content, instance);
      return nodes.every(node => node.type === Text)
        ? h('span', { class: 'win-button-default-text' }, nodes.map(node => String(node.children ?? '')).join(''))
        : h(Fragment, nodes);
    };
  }
});

const FlyoutOutlet = defineComponent({
  name: 'ButtonFlyoutOutlet',
  setup() {
    return () => h(Fragment, propertyNodes.value.flyout);
  }
});
const ContentValueOutlet = defineComponent({ setup: () => () => {
  const value = resolvedContent.value;
  return renderTemplate(value) ?? (isVNode(value) ? h(Fragment, normalizeXamlNodes([value], instance)) : typeof value === 'string' || typeof value === 'number' ? h('span', { class: 'win-button-default-text' }, String(value)) : null);
} });
const AttachedOutlet = defineComponent({ setup: () => () => h(Fragment, propertyNodes.value.attached) });

const buttonAttrs = computed<Record<string, unknown>>(() => {
  const rest = { ...attrs };
  delete rest.class;
  delete rest.style;
  delete rest.disabled;
  delete rest.Click;
  delete rest.GotFocus;
  delete rest.ContextRequested;
  for (const name of ['LostFocus', 'KeyDown', 'KeyUp', 'PointerEntered', 'PointerExited', 'PointerMoved', 'PointerPressed', 'PointerReleased', 'PointerCanceled', 'PointerCaptureLost']) delete rest[name];
  const findAttr = (name: string) => Object.keys(rest).find((key) => key.toLowerCase() === name.toLowerCase());
  const toolTipKey = findAttr('ToolTipService.ToolTip');
  const automationKey = findAttr('AutomationProperties.Name');
  const toolTipValue = toolTipKey ? rest[toolTipKey] : undefined;
  const automationValue = automationKey ? rest[automationKey] : undefined;
  if (toolTipKey) delete rest[toolTipKey];
  if (automationKey) delete rest[automationKey];
  const toolTip = toolTipKey || propertyNodes.value.attached.length
    ? resolveXamlValue(toolTipValue, instance) : command.value?.Description;
  const automationName = resolveXamlValue(automationValue, instance);
  if (toolTip !== undefined && toolTip !== null && toolTip !== '') rest['tooltipservice.tooltip'] = String(toolTip);
  if (automationName !== undefined && automationName !== null && automationName !== '') rest['aria-label'] = String(automationName);
  return rest;
});

const resolvedIsEnabled = computed(() => resolveXamlValue(props.IsEnabled, instance));
const commandCanExecute = computed(() => command.value?.CanExecute?.(commandParameter.value) ?? true);
const localIsEnabled = ref<boolean | undefined>(undefined);
watch(resolvedIsEnabled, () => { localIsEnabled.value = undefined; });
const IsEnabled = computed({
  get: () => (localIsEnabled.value ?? boolValue(resolvedIsEnabled.value)) && commandCanExecute.value,
  set: (value: boolean) => {
    localIsEnabled.value = Boolean(value);
    updateXamlBinding(props.IsEnabled, Boolean(value), instance);
  }
});
const isCollapsed = computed(() => String(resolveXamlValue(props.Visibility, instance)).toLowerCase() === 'collapsed');
const sourceContent = computed(() => props.Content === undefined ? command.value?.Label ?? '' : resolveXamlValue(props.Content, instance));
const sourceRequestedTheme = computed(() => String(resolveXamlValue(props.RequestedTheme, instance)));
const localRequestedTheme = ref<string | undefined>();
watch(sourceRequestedTheme, () => { localRequestedTheme.value = undefined; });
const RequestedTheme = computed({ get: () => localRequestedTheme.value ?? sourceRequestedTheme.value, set: value => { localRequestedTheme.value = value; updateXamlBinding(props.RequestedTheme, value, instance); } });
const localContent = shallowRef<unknown>(undefined);
watch(sourceContent, () => { localContent.value = undefined; });
const resolvedContent = computed({ get: () => localContent.value === undefined ? sourceContent.value : localContent.value, set: value => { localContent.value = value; updateXamlBinding(props.Content, value, instance); } });
const resolvedStyle = computed(() => String(resolveXamlValue(props.Style, instance) || ''));
const titleBarStylePrefix = computed(() => resolvedStyle.value.includes('TitleBarBackButtonStyle') ? 'TitleBarBackButton'
  : resolvedStyle.value.includes('TitleBarPaneToggleButtonStyle') ? 'TitleBarPaneToggleButton' : '');
const isDisabled = computed(() => !IsEnabled.value);
watch(isDisabled, () => { clearPressed(); iconInput.Refresh(); }, { flush: 'post' });
const exposedContent = computed({ get: () => localContent.value !== undefined ? localContent.value : propertyNodes.value.content[0] ?? resolvedContent.value, set: value => { resolvedContent.value = value; } });
const Flyout = computed({ get: () => localFlyout.value !== undefined && !isVNode(localFlyout.value) ? localFlyout.value : flyoutController.value ?? (isVNode(sourceFlyout.value) ? null : sourceFlyout.value), set: value => { localFlyout.value = value; updateXamlBinding(props.Flyout, value, instance); } });
const publicApi = proxyRefs({ Element: buttonRef, Flyout, IsEnabled, RequestedTheme,
  Name: computed(() => attrs['data-xaml-ref'] ?? attrs['x:Name'] ?? attrs.Name ?? ''),
  Content: exposedContent, ContentTemplate, ContentTransitions, Command: command, CommandParameter: commandParameter, IsPressed, IsPointerOver,
  Focus: () => { buttonRef.value?.focus(); return !isDisabled.value; } });
defineExpose(publicApi);
const PresenterHorizontalAlignment = computed(() => resolveXamlValue(props.HorizontalContentAlignment, instance) || 'Center');
const PresenterVerticalAlignment = computed(() => resolveXamlValue(props.VerticalContentAlignment, instance) || 'Center');
const PresenterBackground = computed(() => backgroundBrush.value.value && typeof backgroundBrush.value.value === 'object'
  && !isDisabled.value && !IsPressed.value && !IsPointerOver.value ? backgroundBrush.value.value : 'var(--ButtonBackgroundCurrent)');
const PresenterBackgroundSizing = computed(() => resolveXamlValue(props.BackgroundSizing, instance) || (resolvedStyle.value.includes('AccentButtonStyle') ? 'OuterBorderEdge' : 'InnerBorderEdge'));
const PresenterBorderBrush = computed(() => 'var(--ButtonBorderBrushCurrent)');
const resolveLength = (value: unknown): string | number | undefined => resolveXamlValue(value, instance) as string | number | undefined;
const PresenterBorderThickness = computed(() => resolveLength(props.BorderThickness) === '' ? 1 : resolveLength(props.BorderThickness));
const PresenterPadding = computed(() => resolveXamlValue(props.Padding, instance) || '11,5,11,6');
const PresenterCornerRadius = computed(() => resolveLength(props.CornerRadius) === '' ? 4 : resolveLength(props.CornerRadius));
const inheritedScope = inject(xamlScopeKey, {});
provide(xamlScopeKey, { ...inheritedScope, ContentTemplate, ContentTransitions, PresenterHorizontalAlignment, PresenterVerticalAlignment, PresenterBackground, PresenterBackgroundSizing, PresenterBorderBrush, PresenterBorderThickness, PresenterPadding, PresenterCornerRadius });

const contentAlignments: Record<string, NonNullable<CSSProperties['justifyContent'] & CSSProperties['alignItems']>> = {
  Left: 'flex-start',
  Center: 'center',
  Right: 'flex-end',
  Stretch: 'stretch',
  Top: 'flex-start',
  Bottom: 'flex-end'
};
const contentAlignment = (value: unknown) => contentAlignments[String(value)] ?? '';

const styleClass = computed(() => {
  return {
    DefaultButtonStyle: !resolvedStyle.value || resolvedStyle.value.includes('DefaultButtonStyle'),
    AccentButtonStyle: resolvedStyle.value.includes('AccentButtonStyle'),
    SubtleButtonStyle: resolvedStyle.value.includes('SubtleButtonStyle'),
    'win-titlebar-template-button': Boolean(titleBarStylePrefix.value)
  };
});

const buttonStyle = computed(() => {
  const style: CSSProperties & Record<string, string | number | undefined> = {};
  const value = (key: keyof typeof props) => resolveXamlValue(props[key], instance);
  if (titleBarStylePrefix.value) {
    for (const state of ['', 'PointerOver', 'Pressed', 'Disabled']) {
      style[`--ButtonBackground${state}`] = `var(--${titleBarStylePrefix.value}Background${state})`;
      style[`--ButtonForeground${state}`] = `var(--${titleBarStylePrefix.value}Foreground${state})`;
      style[`--ButtonBorderBrush${state}`] = 'transparent';
    }
    style['--ButtonBorderThemeThickness'] = '0px';
    style['--ButtonPresenterBorderThickness'] = '0px';
    style.width = cssLength(resolveXamlValue(`{ThemeResource ${titleBarStylePrefix.value}Width}`, instance));
    style.margin = '2px';
  }
  if (backgroundBrush.value.value) style['--ButtonBackground'] = typeof backgroundBrush.value.value === 'object' ? 'transparent' : String(backgroundBrush.value.value);
  if (props.Foreground) style['--ButtonForeground'] = String(value('Foreground') ?? '');
  if (props.BorderThickness !== '') {
    style['--ButtonPresenterBorderThickness'] = xamlThickness(value('BorderThickness'));
  }
  if (props.BorderBrush) {
    const borderBrush = String(value('BorderBrush') ?? '');
    style['--ButtonBorderBrush'] = borderBrush;
    // Keep elevation brushes as separate top, side and bottom colors.
    if (!/(?:linear-gradient|(?:Accent)?ControlElevationBorderBrush|(?:DateTime|Date|Time)Picker(?:Flyout)?ButtonBorderBrush)/i.test(borderBrush)) {
      style['--ButtonBorderBrushSide'] = borderBrush;
      style['--ButtonBorderBrushTop'] = borderBrush;
      style['--ButtonBorderBrushBottom'] = borderBrush;
    }
  }
  const margin = resolveXamlValue(props.Margin, instance);
  if (margin !== undefined && margin !== null && margin !== '') style.margin = xamlThickness(margin);
  if (props.Width !== '') style.width = cssLength(value('Width'));
  if (props.Height !== '') style.height = cssLength(value('Height'));
  if (props.MaxWidth !== '') style.maxWidth = cssLength(value('MaxWidth'));
  if (props.MaxHeight !== '') style.maxHeight = cssLength(value('MaxHeight'));
  if (props.MinWidth !== '') style.minWidth = cssLength(value('MinWidth'));
  if (props.MinHeight !== '') style.minHeight = cssLength(value('MinHeight'));
  if (props.HorizontalAlignment) style.justifySelf = alignment(value('HorizontalAlignment'), 'horizontal');
  if (props.VerticalAlignment) style.alignSelf = alignment(value('VerticalAlignment'), 'vertical');
  if (props.HorizontalContentAlignment) {
    style.justifyContent = value('HorizontalContentAlignment') === 'Stretch'
      ? 'flex-start'
      : contentAlignment(value('HorizontalContentAlignment'));
  }
  if (props.VerticalContentAlignment) style.alignItems = contentAlignment(value('VerticalContentAlignment'));
  if (props.FontFamily) style.fontFamily = String(value('FontFamily') ?? '');
  if (props.FontWeight) style.fontWeight = value('FontWeight') === 'SemiBold' ? 600 : String(value('FontWeight') ?? '');
  if (props.FontSize !== '') style.fontSize = cssLength(value('FontSize'));
  if (props.CornerRadius !== '') style['--ButtonCornerRadius'] = xamlThickness(value('CornerRadius'));
  if (isCollapsed.value) style.display = 'none';

  return [attrs.style as StyleValue, style];
});

const onClick = (_event: MouseEvent | KeyboardEvent) => {
  if (isDisabled.value || isCollapsed.value) return;
  const sender = publicApi;
  const args = { OriginalSource: sender, OriginalEvent: _event, Handled: false };
  // Vue folds Click and click into the same listener key but warns on the
  // official event casing. Dispatch that listener without changing the API.
  const listener = instance?.vnode.props?.onClick;
  for (const callback of Array.isArray(listener) ? listener : [listener]) {
    if (typeof callback === 'function') callback(sender, args);
  }
  if (!listener) resolveXamlHandler(attrs.Click, instance)?.(sender, args);
  const currentCommand = command.value;
  const parameter = commandParameter.value;
  if (currentCommand?.CanExecute?.(parameter) ?? true) currentCommand?.Execute(parameter);
  if (typeof KeyboardEvent !== 'undefined' && _event instanceof KeyboardEvent || !propertyNodes.value.flyout.length) void (Flyout.value as { ShowAt?: (anchor: HTMLElement | null) => unknown } | null)?.ShowAt?.(buttonRef.value);
};
const onNativeClick = (event: MouseEvent) => {
  if (suppressClick) { suppressClick = false; return; }
  if (resolveXamlValue(props.ClickMode, instance) !== 'Hover') onClick(event);
};
const keyNames: Record<string, string> = { ' ': 'Space', ArrowDown: 'Down', ArrowUp: 'Up', ArrowLeft: 'Left', ArrowRight: 'Right' };
const raiseKey = (name: 'KeyDown' | 'KeyUp', event: KeyboardEvent) => {
  const sender = publicApi;
  const args = { OriginalSource: sender, OriginalEvent: event, Key: keyNames[event.key] ?? event.key, Handled: false };
  emit(name, sender, args);
  resolveXamlHandler(attrs[name], instance)?.(sender, args);
  if (args.Handled) event.preventDefault();
  return args.Handled;
};
const onKeyDown = (event: KeyboardEvent) => {
  iconInput.KeyDown(event);
  if (raiseKey('KeyDown', event)) return;
  if (isDisabled.value || resolveXamlValue(props.ClickMode, instance) === 'Hover') return;
  if (event.key !== ' ' && event.key !== 'Enter') { keyPressed = ''; IsPressed.value = false; return; }
  event.preventDefault();
  if (event.repeat || keyPressed || activePointer !== null) return;
  keyPressed = event.key;
  IsPressed.value = true;
  if (resolveXamlValue(props.ClickMode, instance) === 'Press') onClick(event);
};
const onKeyUp = (event: KeyboardEvent) => {
  iconInput.KeyUp(event);
  if (raiseKey('KeyUp', event)) { clearPressed(); return; }
  if (isDisabled.value || resolveXamlValue(props.ClickMode, instance) === 'Hover') return;
  if (event.key !== ' ' && event.key !== 'Enter') return;
  event.preventDefault();
  const invoke = keyPressed === event.key && IsPressed.value;
  clearPressed();
  if (invoke && resolveXamlValue(props.ClickMode, instance) === 'Release') onClick(event);
};
const onLostFocus = (event: FocusEvent) => {
  clearPressed(); suppressClick = false; iconInput.LostFocus(event);
  const sender = publicApi;
  const args = { OriginalSource: sender, OriginalEvent: event, Handled: false };
  emit('LostFocus', sender, args); resolveXamlHandler(attrs.LostFocus, instance)?.(sender, args);
};
const onAccelerator = (event: KeyboardEvent) => {
  if (event.defaultPrevented || event.repeat || isDisabled.value || isCollapsed.value) return;
  const currentCommand = command.value;
  for (const node of propertyNodes.value.keyboardAccelerators) {
    const definition = node.props ?? {};
    const key = String(resolveXamlValue(definition.Key, instance) ?? '');
    const modifiers = String(resolveXamlValue(definition.Modifiers, instance) ?? 'None').split(/[ ,]+/);
    const matches = key.toLowerCase() === event.key.toLowerCase()
      && event.ctrlKey === modifiers.includes('Control') && event.altKey === modifiers.includes('Menu')
      && event.shiftKey === modifiers.includes('Shift') && event.metaKey === modifiers.includes('Windows');
    if (matches && boolValue(resolveXamlValue(definition.IsEnabled ?? true, instance))) {
      event.preventDefault(); onClick(event); return;
    }
  }
  if (currentCommand && 'MatchesKeyboardEvent' in currentCommand
    && typeof currentCommand.MatchesKeyboardEvent === 'function' && currentCommand.MatchesKeyboardEvent(event)) {
    event.preventDefault();
    onClick(event);
  }
};
const onWindowBlur = () => { clearPressed(); suppressClick = false; iconInput.Refresh(); };
onMounted(() => { document.addEventListener('keydown', onAccelerator); window.addEventListener('blur', onWindowBlur); });
onBeforeUnmount(() => { document.removeEventListener('keydown', onAccelerator); window.removeEventListener('blur', onWindowBlur); });
const onGotFocus = (event: FocusEvent) => {
  const sender = publicApi;
  const args = { OriginalSource: sender, OriginalEvent: event, Handled: false };
  emit('GotFocus', sender, args);
  resolveXamlHandler(attrs.GotFocus, instance)?.(sender, args);
};
</script>
<style>
  .win-btn {
    position: relative;
    box-sizing: border-box;
    border-left: var(--ButtonBorderThemeThickness) solid var(--ButtonBorderBrushCurrent);
    border-top: var(--ButtonBorderThemeThickness) solid var(--ButtonBorderBrushTopCurrent);
    border-right: var(--ButtonBorderThemeThickness) solid var(--ButtonBorderBrushCurrent);
    border-bottom: var(--ButtonBorderThemeThickness) solid var(--ButtonBorderBrushBottomCurrent);
    border-radius: var(--ButtonCornerRadius);
    padding: var(--ButtonPadding, 5px 11px 6px);
    font-family: var(--ContentControlThemeFontFamily, 'Segoe UI Variable', 'Segoe UI', system-ui, sans-serif);
    font-size: var(--ControlContentThemeFontSize, 14px);
    font-weight: normal;
    min-height: 0;
    min-width: 0;
    max-width: 100%;
    height: auto;
    background: padding-box var(--ButtonBackgroundCurrent);
    color: var(--ButtonForegroundCurrent);
    cursor: default;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 0;
    line-height: 19px;
    transition: background-color 83ms linear;
    outline: none;
    user-select: none;
    --ButtonPadding: 5px 11px 6px;
    --ButtonBorderThemeThickness: 1px;
    --ButtonCornerRadius: 4px;
    --ButtonBorderBrushTop: var(--ButtonControlElevationBorderBrushTop, var(--ButtonBorderBrushDefaultTop, var(--ButtonControlStrokeColorDefaultBrush, var(--ControlStrokeColorDefaultBrush, currentColor))));
    --ButtonBorderBrushBottom: var(--ButtonControlElevationBorderBrushBottom, var(--ButtonBorderBrushDefaultBottom, var(--ButtonControlStrokeColorDefaultBrush, var(--ControlStrokeColorDefaultBrush, currentColor))));
    --ButtonBorderBrushPointerOverTop: var(--ButtonBorderBrushTop);
    --ButtonBorderBrushPointerOverBottom: var(--ButtonBorderBrushBottom);
    --ButtonBorderBrushPressedTop: var(--ButtonBorderBrushPressed);
    --ButtonBorderBrushPressedBottom: var(--ButtonBorderBrushPressed);
    --ButtonBorderBrushDisabledTop: var(--ButtonBorderBrushDisabled);
    --ButtonBorderBrushDisabledBottom: var(--ButtonBorderBrushDisabled);
    --ButtonBorderBrushSide: var(--ButtonControlElevationBorderBrushSide, var(--ButtonControlStrokeColorDefaultBrush, var(--ControlStrokeColorDefaultBrush, currentColor)));
    --ButtonBorderBrushSidePointerOver: var(--ButtonBorderBrushSide);
    --ButtonBorderBrushSidePressed: var(--ButtonBorderBrushPressed, var(--ButtonBorderBrushSide));
    --ButtonBorderBrushSideDisabled: var(--ButtonBorderBrushDisabled, var(--ButtonBorderBrushSide));
    --ButtonBorderBrushSideCurrent: var(--ButtonBorderBrushSide);
    --ButtonBackgroundCurrent: var(--ButtonBackground);
    --ButtonForegroundCurrent: var(--ButtonForeground);
    --ButtonBorderBrushCurrent: var(--ButtonBorderBrush);
    --ButtonBorderBrushTopCurrent: var(--ButtonBorderBrushTop);
    --ButtonBorderBrushBottomCurrent: var(--ButtonBorderBrushBottom);
  }

    .win-btn:hover {
      --ButtonBackgroundCurrent: var(--ButtonBackgroundPointerOver);
      --ButtonForegroundCurrent: var(--ButtonForegroundPointerOver);
      --ButtonBorderBrushCurrent: var(--ButtonBorderBrushPointerOver);
      --ButtonBorderBrushSideCurrent: var(--ButtonBorderBrushSidePointerOver);
      --ButtonBorderBrushTopCurrent: var(--ButtonBorderBrushPointerOverTop);
      --ButtonBorderBrushBottomCurrent: var(--ButtonBorderBrushPointerOverBottom);
    }

    .win-btn:active, .win-btn.is-pressed {
      --ButtonBackgroundCurrent: var(--ButtonBackgroundPressed);
      --ButtonForegroundCurrent: var(--ButtonForegroundPressed);
      --ButtonBorderBrushCurrent: var(--ButtonBorderBrushPressed);
      --ButtonBorderBrushSideCurrent: var(--ButtonBorderBrushSidePressed);
      --ButtonBorderBrushTopCurrent: var(--ButtonBorderBrushPressedTop);
      --ButtonBorderBrushBottomCurrent: var(--ButtonBorderBrushPressedBottom);
    }

    .win-btn:disabled {
      --ButtonBackgroundCurrent: var(--ButtonBackgroundDisabled);
      --ButtonForegroundCurrent: var(--ButtonForegroundDisabled);
      --ButtonBorderBrushCurrent: var(--ButtonBorderBrushDisabled);
      --ButtonBorderBrushSideCurrent: var(--ButtonBorderBrushSideDisabled);
      --ButtonBorderBrushTopCurrent: var(--ButtonBorderBrushDisabledTop);
      --ButtonBorderBrushBottomCurrent: var(--ButtonBorderBrushDisabledBottom);
      cursor: default;
      pointer-events: none;
    }

    .win-btn.AccentButtonStyle {
      --ButtonBackground: var(--AccentButtonBackground);
      --ButtonBackgroundPointerOver: var(--AccentButtonBackgroundPointerOver);
      --ButtonBackgroundPressed: var(--AccentButtonBackgroundPressed);
      --ButtonBackgroundDisabled: var(--AccentButtonBackgroundDisabled);
      --ButtonForeground: var(--AccentButtonForeground);
      --ButtonForegroundPointerOver: var(--AccentButtonForegroundPointerOver);
      --ButtonForegroundPressed: var(--AccentButtonForegroundPressed);
      --ButtonForegroundDisabled: var(--AccentButtonForegroundDisabled);
      --ButtonBorderBrush: var(--AccentButtonBorderBrush);
      --ButtonBorderBrushPointerOver: var(--AccentButtonBorderBrushPointerOver);
      --ButtonBorderBrushPressed: var(--AccentButtonBorderBrushPressed);
      --ButtonBorderBrushDisabled: var(--AccentButtonBorderBrushDisabled);
      --ButtonBorderBrushSide: var(--ButtonAccentControlElevationBorderBrushSide, var(--ControlStrokeColorOnAccentDefaultBrush, var(--ButtonControlStrokeColorDefaultBrush, currentColor)));
      --ButtonBorderBrushSidePointerOver: var(--ButtonAccentControlElevationBorderBrushSide, var(--ControlStrokeColorOnAccentDefaultBrush, var(--ButtonControlStrokeColorDefaultBrush, currentColor)));
      --ButtonBorderBrushSidePressed: var(--AccentButtonBorderBrushPressed);
      --ButtonBorderBrushSideDisabled: var(--AccentButtonBorderBrushDisabled);
      --ButtonBorderBrushTop: var(--ButtonAccentControlElevationBorderBrushTop, var(--AccentButtonBorderBrushDefault, var(--ControlStrokeColorOnAccentDefaultBrush, currentColor)));
      --ButtonBorderBrushBottom: var(--ButtonAccentControlElevationBorderBrushBottom, var(--AccentButtonBorderBrushDefaultBottom, var(--ControlStrokeColorOnAccentSecondaryBrush, var(--ControlStrokeColorOnAccentDefaultBrush, currentColor))));
    }

  .win-btn .win-text-block {
      color: inherit;
    }
  .win-button-default-text {
    display: block; min-width: 0; max-width: 100%; overflow: hidden;
    white-space: nowrap; text-overflow: ellipsis; line-height: inherit;
  }

  .win-btn {
    border: 0;
    padding: 0;
    background: transparent;
  }
  .win-btn::after {
    content: "";
    position: absolute;
    inset: 0;
    box-sizing: border-box;
    border-style: solid;
    border-width: var(--ButtonPresenterBorderThickness, var(--ButtonBorderThemeThickness, 1px));
    border-color: var(--ButtonBorderBrushSideCurrent);
    border-top-color: var(--ButtonBorderBrushTopCurrent);
    border-bottom-color: var(--ButtonBorderBrushBottomCurrent);
    border-radius: inherit;
    pointer-events: none;
    z-index: 1;
  }
  .win-button-content-presenter {
    position: relative;
    width: 100%; height: 100%; min-width: 0; min-height: 0; color: inherit;
    border-color: transparent !important;
    transition: background-color 83ms linear;
  }
  .win-btn.win-titlebar-template-button { transition: none; line-height: 16px; }
  .win-titlebar-button-root { width: 100%; height: 100%; min-width: 0; min-height: 0; align-items: center; justify-items: center; }
  .win-btn.content-horizontal-stretch > * {
    flex: 1 1 auto;
    min-width: 0;
  }

  .win-btn.content-horizontal-stretch > .win-grid {
    flex: 1 1 0%;
    width: 100%;
  }

  .win-btn.content-vertical-stretch > * {
    align-self: stretch;
  }

  .win-btn.content-vertical-stretch > .win-grid {
    height: 100%;
  }

    .win-btn.SubtleButtonStyle {
      --ButtonBackground: var(--SubtleButtonBackground);
      --ButtonBackgroundPointerOver: var(--SubtleButtonBackgroundPointerOver);
      --ButtonBackgroundPressed: var(--SubtleButtonBackgroundPressed);
      --ButtonBackgroundDisabled: var(--SubtleButtonBackgroundDisabled);
      --ButtonForeground: var(--SubtleButtonForeground);
      --ButtonForegroundPointerOver: var(--SubtleButtonForegroundPointerOver);
      --ButtonForegroundPressed: var(--SubtleButtonForegroundPressed);
      --ButtonForegroundDisabled: var(--SubtleButtonForegroundDisabled);
      --ButtonBorderBrush: var(--SubtleButtonBorderBrush);
      --ButtonBorderBrushTop: var(--SubtleButtonBorderBrush);
      --ButtonBorderBrushBottom: var(--SubtleButtonBorderBrush);
      --ButtonBorderBrushSide: var(--SubtleButtonBorderBrush);
      --ButtonBorderBrushSidePointerOver: var(--SubtleButtonBorderBrushPointerOver);
      --ButtonBorderBrushSidePressed: var(--SubtleButtonBorderBrushPressed);
      --ButtonBorderBrushSideDisabled: var(--SubtleButtonBorderBrushDisabled);
      --ButtonBorderBrushPointerOverTop: var(--SubtleButtonBorderBrushPointerOver);
      --ButtonBorderBrushPointerOverBottom: var(--SubtleButtonBorderBrushPointerOver);
      --ButtonBorderBrushPressedTop: var(--SubtleButtonBorderBrushPressed);
      --ButtonBorderBrushPressedBottom: var(--SubtleButtonBorderBrushPressed);
      --ButtonBorderBrushDisabledTop: var(--SubtleButtonBorderBrushDisabled);
      --ButtonBorderBrushDisabledBottom: var(--SubtleButtonBorderBrushDisabled);
    }

  .win-btn {
    white-space: nowrap;
  }

</style>
