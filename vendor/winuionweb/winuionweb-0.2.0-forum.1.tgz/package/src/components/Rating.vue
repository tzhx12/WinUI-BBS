<template>
  <div
    ref="rootRef"
    class="win-rating-control"
    :class="stateClasses"
    :style="rootStyle"
    role="slider"
    :aria-valuemin="0"
    :aria-valuemax="effectiveMax"
    :aria-valuenow="ariaValue"
    :aria-readonly="resolvedIsReadOnly"
    :aria-disabled="!isEnabled"
    :aria-label="automationName"
    :tabindex="isEnabled ? 0 : -1"
    @keydown="onKeyDown">
    <div class="win-rating-caption-stack">
      <div
        ref="itemsRef"
        class="win-rating-background-stack"
        @pointerenter="onPointerEnter"
        @pointermove="onPointerMove"
        @pointerleave="onPointerLeave"
        @pointercancel="onPointerCancel"
        @lostpointercapture="onPointerCaptureLost"
        @pointerdown="onPointerDown"
        @pointerup="onPointerUp">
        <span
          v-for="index in itemIndexes"
          :key="`background-${index}`"
          class="win-rating-item win-rating-background-item"
          aria-hidden="true">
          <span class="win-rating-glyph">&#xE734;</span>
        </span>
      </div>

      <TextBlock
        v-if="resolvedCaption"
        class="win-rating-caption"
        Text="{x:Bind RatingCaption}" />
    </div>

    <div class="win-rating-foreground-presenter" aria-hidden="true">
      <div class="win-rating-foreground-outer">
        <div class="win-rating-foreground-stack">
          <span
            v-for="index in itemIndexes"
            :key="`foreground-${index}`"
            class="win-rating-item win-rating-foreground-item"
            :style="foregroundItemStyle(index)">
            <span class="win-rating-glyph">&#xE735;</span>
          </span>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed, getCurrentInstance, provide, ref, useAttrs, watch } from 'vue';
import TextBlock from './TextBlock.vue';
import { resolveXamlHandler, resolveXamlValue, updateXamlBinding, xamlScopeKey } from './xamlRuntime';
import { isHoverPointer } from './pointerInput';

const noValueSetSentinel = -1;

const props = defineProps({
  Value: { type: [Number, String], default: noValueSetSentinel },
  MaxRating: { type: [Number, String], default: 5 },
  PlaceholderValue: { type: [Number, String], default: noValueSetSentinel },
  Caption: { type: String, default: '' },
  InitialSetValue: { type: [Number, String], default: 1 },
  IsClearEnabled: { type: [Boolean, String], default: true },
  IsReadOnly: { type: [Boolean, String], default: false },
  IsEnabled: { type: [Boolean, String], default: true },
  Width: { type: [String, Number], default: '' },
  modelValue: { type: Number, default: undefined },
  max: { type: Number, default: undefined },
  disabled: { type: Boolean, default: false }
});
const instance = getCurrentInstance();
const attrs = useAttrs();
const rootRef = ref(null);
const captionOverride = ref(undefined);
const placeholderOverride = ref(undefined);
const captionSource = computed(() => resolveXamlValue(props.Caption, instance));
watch(captionSource, () => { captionOverride.value = undefined; });
const resolvedCaption = computed(() => captionOverride.value ?? captionSource.value);
const automationName = computed(() => resolveXamlValue(attrs['AutomationProperties.Name'], instance));
const RatingCaption = computed(() => resolvedCaption.value);
const resolvedValue = computed(() => resolveXamlValue(props.Value, instance));
const resolvedMaxRating = computed(() => resolveXamlValue(props.MaxRating, instance));
const placeholderSourceValue = computed(() => resolveXamlValue(props.PlaceholderValue, instance));
watch(placeholderSourceValue, () => { placeholderOverride.value = undefined; });
const resolvedPlaceholderValue = computed(() => placeholderOverride.value ?? placeholderSourceValue.value);
const resolvedInitialSetValue = computed(() => resolveXamlValue(props.InitialSetValue, instance));
const resolvedIsClearEnabled = computed(() => resolveXamlValue(props.IsClearEnabled, instance) !== false);
const resolvedIsReadOnly = computed(() => resolveXamlValue(props.IsReadOnly, instance) === true);
const resolvedIsEnabled = computed(() => resolveXamlValue(props.IsEnabled, instance) !== false);

const emit = defineEmits(['update:Value', 'ValueChanged', 'update:modelValue']);

const itemsRef = ref(null);
const isPointerOver = ref(false);
const isPointerDown = ref(false);
const pointerRating = ref(0);
const internalValue = ref(noValueSetSentinel);

const toNumber = (value, fallback = 0) => {
  const number = Number(value);
  return Number.isFinite(number) ? number : fallback;
};

const cssLength = (value) => {
  if (value === '' || value === undefined || value === null) return '';
  if (typeof value === 'string' && value.trim() !== '' && !Number.isNaN(Number(value.trim()))) return `${Number(value.trim())}px`;
  return typeof value === 'number' ? `${value}px` : value;
};

const coerceRatingValue = (value) => {
  const number = toNumber(value, noValueSetSentinel);
  if (number < 0) return noValueSetSentinel;
  if (number <= 1) return 1;
  if (number > effectiveMax.value) return effectiveMax.value;
  return number;
};

const effectiveMax = computed(() => Math.max(1, Math.trunc(toNumber(props.max ?? resolvedMaxRating.value, 5))));
const isEnabled = computed(() => resolvedIsEnabled.value && !props.disabled);
const actualValue = computed(() => internalValue.value);
const placeholderValue = computed(() => coerceRatingValue(resolvedPlaceholderValue.value));
const placeholderSource = computed(() => {
  const binding = String(props.PlaceholderValue ?? '');
  const match = binding.match(/^\{(?:x:Bind|Binding)\s+([A-Za-z_$][\w$]*)\./);
  if (!match) return null;
  return resolveXamlValue(`{x:Bind ${match[1]}}`, instance) || null;
});
const placeholderSourceIsDragging = computed(() => Boolean(placeholderSource.value?.IsDragging));
const initialSetValue = computed(() => Math.max(1, Math.min(effectiveMax.value, Math.trunc(toNumber(resolvedInitialSetValue.value, 1)))));
const itemIndexes = computed(() => Array.from({ length: effectiveMax.value }, (_, index) => index + 1));

watch(
  () => [props.modelValue, resolvedValue.value, effectiveMax.value],
  () => {
    internalValue.value = coerceRatingValue(props.modelValue ?? resolvedValue.value);
  },
  { immediate: true }
);

// WinUI displays the coerced dependency-property value while a bound Slider
// is being dragged. The TwoWay source is updated when the interaction ends,
// which lets the thumb move freely and then returns values below one to 1.0.
watch([placeholderValue, resolvedPlaceholderValue, placeholderSourceIsDragging], ([value, rawValue, isDragging]) => {
  if (!isDragging && value > noValueSetSentinel && value !== rawValue) {
    updateXamlBinding(props.PlaceholderValue, value, instance);
  }
}, { immediate: true });

const displayedValue = computed(() => {
  if (isPointerOver.value && !resolvedIsReadOnly.value && isEnabled.value) return Math.max(0, Math.min(effectiveMax.value, pointerRating.value));
  if (actualValue.value > noValueSetSentinel) return actualValue.value;
  if (placeholderValue.value > noValueSetSentinel) return placeholderValue.value;
  return 0;
});

const visualState = computed(() => {
  if (!isEnabled.value) return 'disabled';
  if (isPointerOver.value && !resolvedIsReadOnly.value) {
    return actualValue.value > noValueSetSentinel ? 'pointer-over-set' : 'pointer-over-placeholder';
  }
  if (actualValue.value > noValueSetSentinel) return 'set';
  if (placeholderValue.value > noValueSetSentinel) return 'placeholder';
  return 'unset';
});

const stateClasses = computed(() => ({
  'is-readonly': resolvedIsReadOnly.value,
  'is-disabled': !isEnabled.value,
  [`state-${visualState.value}`]: true
}));

const ariaValue = computed(() => Math.max(0, actualValue.value));
const rootStyle = computed(() => (props.Width !== '' ? { width: cssLength(props.Width) } : {}));

const foregroundItemStyle = (index) => {
  const amount = Math.max(0, Math.min(1, displayedValue.value - (index - 1)));
  return { clipPath: `inset(0 ${100 - amount * 100}% 0 0)` };
};

const pointerRatingFromEvent = (event) => {
  const rect = itemsRef.value?.getBoundingClientRect();
  if (!rect || rect.width <= 0) return 0;
  const ratio = (event.clientX - rect.left) / rect.width;
  return Math.max(0, Math.min(effectiveMax.value, Math.ceil(ratio * effectiveMax.value)));
};

const updatePointerRating = (event) => {
  pointerRating.value = pointerRatingFromEvent(event);
};

const commitRating = (newRating, originatedFromMouse = false) => {
  const oldValue = actualValue.value;
  const boundedRating = Math.max(0, Math.min(effectiveMax.value, newRating));
  let nextValue = oldValue;

  if (oldValue > noValueSetSentinel || boundedRating !== 0) {
    if (!resolvedIsClearEnabled.value && boundedRating <= 0) {
      nextValue = 1;
    } else if (boundedRating === oldValue && resolvedIsClearEnabled.value && (boundedRating !== effectiveMax.value || originatedFromMouse)) {
      nextValue = noValueSetSentinel;
    } else if (boundedRating > 0) {
      nextValue = boundedRating;
    } else {
      nextValue = noValueSetSentinel;
    }
  }

  if (nextValue !== oldValue) {
    internalValue.value = nextValue;
    updateXamlBinding(props.Value, nextValue, instance);
    emit('update:Value', nextValue);
    emit('update:modelValue', nextValue);
    const args = { OldValue: oldValue, NewValue: nextValue };
    emit('ValueChanged', publicApi, args);
    if (!instance?.vnode.props?.onValueChanged) resolveXamlHandler(attrs.ValueChanged, instance)?.(publicApi, args);
  }
};

const publicApi = {
  get Value() { return internalValue.value; },
  set Value(value) {
    const oldValue = internalValue.value;
    const nextValue = coerceRatingValue(value);
    if (oldValue === nextValue) return;
    internalValue.value = nextValue;
    updateXamlBinding(props.Value, internalValue.value, instance);
    emit('update:Value', internalValue.value);
    const args = { OldValue: oldValue, NewValue: nextValue };
    emit('ValueChanged', publicApi, args);
    if (!instance?.vnode.props?.onValueChanged) resolveXamlHandler(attrs.ValueChanged, instance)?.(publicApi, args);
  },
  get Caption() { return resolvedCaption.value; },
  set Caption(value) {
    captionOverride.value = String(value ?? '');
    updateXamlBinding(props.Caption, captionOverride.value, instance);
  },
  get PlaceholderValue() { return placeholderValue.value; },
  set PlaceholderValue(value) {
    placeholderOverride.value = coerceRatingValue(value);
    updateXamlBinding(props.PlaceholderValue, placeholderOverride.value, instance);
  },
  get IsReadOnly() { return resolvedIsReadOnly.value; },
  get IsClearEnabled() { return resolvedIsClearEnabled.value; },
  get IsEnabled() { return isEnabled.value; },
  get Element() { return rootRef.value; }
};
defineExpose(publicApi);

provide(xamlScopeKey, { RatingCaption });

const changeRatingBy = (change, originatedFromMouse = false) => {
  if (change === 0) return;

  let ratingValue;
  if (actualValue.value !== noValueSetSentinel) {
    if (Math.trunc(actualValue.value) !== actualValue.value) {
      ratingValue = change === -1 ? Math.trunc(actualValue.value) : Math.trunc(actualValue.value) + change;
    } else {
      ratingValue = actualValue.value + change;
    }
  } else {
    ratingValue = initialSetValue.value;
  }

  commitRating(ratingValue, originatedFromMouse);
};

const onPointerEnter = (event) => {
  if (!isEnabled.value || resolvedIsReadOnly.value) return;
  isPointerOver.value = isHoverPointer(event);
  updatePointerRating(event);
};

const onPointerMove = (event) => {
  if (!isEnabled.value || resolvedIsReadOnly.value) return;
  updatePointerRating(event);
};

const onPointerLeave = () => {
  if (isPointerDown.value) return;
  isPointerOver.value = false;
};

const onPointerCancel = (event) => {
  isPointerDown.value = false;
  if (itemsRef.value?.hasPointerCapture?.(event.pointerId)) {
    itemsRef.value.releasePointerCapture(event.pointerId);
  }
  isPointerOver.value = false;
};

const onPointerCaptureLost = () => {
  isPointerDown.value = false;
};

const onPointerDown = (event) => {
  if (!isEnabled.value || resolvedIsReadOnly.value) return;
  if (!isHoverPointer(event)) isPointerOver.value = false;
  isPointerDown.value = true;
  itemsRef.value?.setPointerCapture?.(event.pointerId);
};

const onPointerUp = (event) => {
  if (!isEnabled.value || resolvedIsReadOnly.value) return;
  const rating = pointerRatingFromEvent(event);
  commitRating(rating, true);
  isPointerDown.value = false;
  if (itemsRef.value?.hasPointerCapture?.(event.pointerId)) {
    itemsRef.value.releasePointerCapture(event.pointerId);
  }
  isPointerOver.value = isHoverPointer(event) && (itemsRef.value?.matches(':hover') ?? false);
  if (isPointerOver.value) updatePointerRating(event);
};

const onKeyDown = (event) => {
  if (!isEnabled.value || resolvedIsReadOnly.value) return;

  let handled = true;
  switch (event.key) {
    case 'ArrowLeft':
    case 'ArrowDown':
      changeRatingBy(-1);
      break;
    case 'ArrowRight':
    case 'ArrowUp':
      changeRatingBy(1);
      break;
    case 'Home':
      commitRating(0);
      break;
    case 'End':
      commitRating(effectiveMax.value);
      break;
    default:
      handled = false;
      break;
  }

  if (handled) event.preventDefault();
};
</script>

<style>
.win-rating-control {
  --rating-font-size: 32px;
  --rating-actual-size: 16px;
  --rating-item-spacing: 8px;
  --rating-unselected-foreground: var(--text-secondary);
  --rating-selected-foreground: var(--accent-base);
  --rating-placeholder-foreground: var(--text-primary);
  --rating-pointer-placeholder-foreground: var(--control-alt-fill-color-tertiary, rgba(0, 0, 0, 0.0578));
  --rating-disabled-selected-foreground: var(--text-disabled);

  position: relative;
  display: inline-flex;
  align-items: center;
  min-height: 32px;
  height: 32px;
  color: var(--text-primary);
  user-select: none;
  outline: none;
}

.win-rating-caption-stack {
  display: flex;
  align-items: center;
  height: 32px;
}

.win-rating-background-stack,
.win-rating-foreground-stack {
  display: flex;
  align-items: flex-start;
  gap: var(--rating-item-spacing);
}

.win-rating-background-stack {
  height: var(--rating-actual-size);
  background: transparent;
  cursor: pointer;
  touch-action: none;
}

.win-rating-item {
  position: relative;
  display: block;
  flex: 0 0 var(--rating-actual-size);
  width: var(--rating-actual-size);
  height: var(--rating-actual-size);
  overflow: hidden;
  color: currentColor;
  pointer-events: none;
}

.win-rating-glyph {
  position: absolute;
  top: -8px;
  left: -8px;
  display: block;
  width: var(--rating-font-size);
  height: var(--rating-font-size);
  font-size: var(--rating-font-size);
  line-height: var(--rating-font-size);
  font-weight: 400;
  transform: scale(0.5);
  transform-origin: center center;
}

.win-rating-background-item {
  color: var(--rating-unselected-foreground);
}

.win-rating-foreground-presenter {
  position: absolute;
  top: 8px;
  left: 0;
  height: var(--rating-actual-size);
  pointer-events: none;
}

.win-rating-foreground-outer {
  overflow: visible;
}

.win-rating-foreground-stack {
  margin: 0;
}

.win-rating-foreground-item {
  color: var(--rating-selected-foreground);
}

.win-rating-caption {
  margin: 0 0 0 12px;
  color: var(--text-secondary);
  font-size: 12px;
  line-height: 16px;
  min-height: 16px;
  align-self: center;
}

.win-rating-control.state-placeholder .win-rating-foreground-item {
  color: var(--rating-placeholder-foreground);
}

.win-rating-control.state-pointer-over-placeholder .win-rating-foreground-item,
.win-rating-control.state-unset .win-rating-foreground-item {
  color: var(--rating-pointer-placeholder-foreground);
}

.win-rating-control.state-disabled .win-rating-foreground-item {
  color: var(--rating-disabled-selected-foreground);
}

.win-rating-control.is-readonly .win-rating-background-stack,
.win-rating-control.is-disabled .win-rating-background-stack {
  cursor: default;
}

.win-rating-control.is-disabled {
  pointer-events: none;
}

.example-theme-wrapper.theme-dark .win-rating-control,
.win-theme-scope.theme-dark .win-rating-control {
  --rating-pointer-placeholder-foreground: var(--control-alt-fill-color-tertiary, rgba(255, 255, 255, 0.0419));
}

</style>
