import { cssColor as e, isSolidColorBrush as t } from "./brushCore.js";
import { resolveBrushStyle as n } from "./AcrylicBrush.js";
import { resolveXamlValue as r, updateXamlBinding as i } from "./xamlRuntime.js";
import a from "../_virtual/_plugin-vue_export-helper.js";
import o from "./TextBlock.vue.js";
import { animatedIconVisualSourceComponents as s } from "./animatedIconVisuals.js";
import ee from "./AnimatedIcon.vue.js";
import { useAnimatedIconInput as te } from "./animatedIconInput.js";
import { FontIconSource as ne } from "./IconSource.js";
/* empty css                                                                 */
import { Fragment as c, computed as l, createBlock as u, createCommentVNode as d, createElementBlock as f, createElementVNode as p, createTextVNode as m, createVNode as h, getCurrentInstance as g, nextTick as _, normalizeClass as v, normalizeStyle as y, onBeforeUnmount as re, onMounted as b, openBlock as x, ref as S, renderSlot as C, toDisplayString as w, useSlots as T, watch as E, withCtx as D } from "vue";
//#region src/components/ExpanderBase.vue
var O = {
	__name: "ExpanderBase",
	props: {
		Header: {
			type: [String, Number],
			default: ""
		},
		Content: {
			type: [String, Number],
			default: ""
		},
		Description: {
			type: [String, Number],
			default: ""
		},
		HeaderIcon: {
			type: String,
			default: ""
		},
		HeaderTemplate: {
			type: [
				Object,
				Function,
				String
			],
			default: null
		},
		HeaderTemplateSelector: {
			type: [
				Object,
				Function,
				String
			],
			default: null
		},
		IsExpanded: {
			type: [Boolean, String],
			default: !1
		},
		ExpandDirection: {
			type: [String, Number],
			default: "Down"
		},
		Padding: {
			type: [String, Number],
			default: "16"
		},
		Background: {
			type: [String, Object],
			default: "{ThemeResource ExpanderContentBackground}"
		},
		BorderBrush: {
			type: [String, Object],
			default: "{ThemeResource ExpanderContentBorderBrush}"
		},
		BorderThickness: {
			type: [String, Number],
			default: ""
		},
		CornerRadius: {
			type: [String, Number],
			default: "{ThemeResource ControlCornerRadius}"
		},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		HorizontalContentAlignment: {
			type: String,
			default: "Stretch"
		},
		VerticalContentAlignment: {
			type: String,
			default: "Stretch"
		},
		Width: {
			type: [String, Number],
			default: ""
		},
		MinWidth: {
			type: [String, Number],
			default: ""
		},
		Height: {
			type: [String, Number],
			default: ""
		},
		MaxWidth: {
			type: [String, Number],
			default: ""
		},
		HorizontalAlignment: {
			type: String,
			default: ""
		},
		VerticalAlignment: {
			type: String,
			default: ""
		}
	},
	emits: [
		"update:IsExpanded",
		"Expanding",
		"Collapsed"
	],
	setup(a, { expose: c, emit: u }) {
		let d = s.AnimatedChevronUpDownSmallVisualSource, f = a, p = u, m = T(), h = g(), v = (e) => e === !0 || String(e).toLowerCase() === "true", y = l(() => v(r(f.IsExpanded, h))), x = l(() => v(r(f.IsEnabled, h))), C = l(() => r(f.ExpandDirection, h) || "Down"), w = l(() => r(f.Padding, h)), D = l(() => r(f.HorizontalContentAlignment, h)), O = l(() => r(f.VerticalContentAlignment, h)), k = S(y.value), A = S(k.value), j = S(null), M, N, P = 0, F = async (e) => {
			let t = ++P;
			clearTimeout(N);
			let n = j.value && A.value ? getComputedStyle(j.value).transform : null;
			if (M?.cancel(), A.value = !0, await _(), t !== P || !j.value) return;
			let r = j.value, i = `translateY(${r.getBoundingClientRect().height * (C.value === "Up" ? 1 : -1)}px)`, a = n && n !== "none" ? n : e ? i : "translateY(0px)", o = e ? 333 : 167;
			M = r.animate([{ transform: a }, { transform: e ? "translateY(0px)" : i }], {
				duration: o,
				easing: e ? "cubic-bezier(0, 0, 0, 1)" : "cubic-bezier(1, 1, 0, 1)",
				fill: "forwards"
			}), e ? M.onfinish = () => {
				t === P && M?.cancel();
			} : N = setTimeout(() => {
				t === P && (A.value = !1, M?.cancel());
			}, C.value === "Up" ? 200 : 167);
		};
		re(() => {
			P += 1, clearTimeout(N), M?.cancel();
		});
		let I = S(null), L = te(!1, (e) => {
			let t = k.value !== (C.value === "Up");
			return `${e === "Disabled" ? "Normal" : e}${t ? "On" : "Off"}`;
		});
		b(() => L.Attach(I.value)), E([
			k,
			C,
			x
		], L.Refresh, { flush: "post" }), E(x, (e) => {
			e || L.Reset();
		});
		let R = l(() => r(f.Header, h)), z = l(() => r(f.Content, h)), B = l(() => r(f.Description, h)), V = l(() => r(f.HeaderIcon, h)), H = l(() => !!V.value || !!m.HeaderIcon), U = l(() => !!m.HeaderControls), ie = l(() => !!R.value || !!B.value || H.value || !!m.Header || !!m.Description || U.value), ae = l(() => String(V.value || "").trim().startsWith("<")), W = (e) => e === "" || e == null ? "" : typeof e == "string" && e.trim() !== "" && !Number.isNaN(Number(e.trim())) ? `${Number(e.trim())}px` : typeof e == "number" ? `${e}px` : e, G = (e) => {
			let t = W(e);
			if (!t || t === "auto") return "";
			let n = typeof e == "number" ? e : typeof e == "string" && e.trim() !== "" && !Number.isNaN(Number(e.trim())) ? Number(e.trim()) : null;
			return n === null ? `calc(${t} - 2px)` : `${Math.max(n - 2, 0)}px`;
		}, K = (e) => {
			if (e === "" || e == null) return "";
			let t = String(e).split(",").map((e) => {
				let t = e.trim();
				return W(Number.isNaN(Number(t)) ? t : Number(t));
			});
			return t.length === 1 ? t[0] : t.length === 2 ? `${t[1]} ${t[0]}` : t.length === 4 ? `${t[1]} ${t[2]} ${t[3]} ${t[0]}` : String(e);
		}, q = (e) => ({
			Left: "flex-start",
			Center: "center",
			Right: "flex-end",
			Stretch: "stretch"
		})[e] ?? "stretch", J = (e) => ({
			Top: "flex-start",
			Center: "center",
			Bottom: "flex-end",
			Stretch: "flex-start"
		})[e] ?? "flex-start", Y = (e) => ({
			Top: "flex-start",
			Center: "center",
			Bottom: "flex-end",
			Stretch: "stretch"
		})[e] ?? "stretch", X = (e) => ({
			Left: "start",
			Center: "center",
			Right: "end",
			Stretch: "stretch"
		})[e] ?? "stretch", oe = l(() => ({
			...n(f.Background, h),
			borderColor: se(r(f.BorderBrush, h)),
			...f.BorderThickness === "" ? {} : { borderWidth: K(r(f.BorderThickness, h)) },
			padding: K(w.value),
			alignItems: q(D.value),
			justifyContent: J(O.value)
		})), se = (n) => t(n) ? `color-mix(in srgb, ${e(n.Color)} ${n.Opacity * 100}%, transparent)` : n == null ? void 0 : e(n), ce = l(() => {
			let e = {}, t = String(r(f.CornerRadius, h) ?? "4").split(",").map((e) => W(e.trim())), n = t.length === 4 ? t : [
				t[0],
				t[0],
				t[0],
				t[0]
			];
			if (e["--win-expander-corner-radius"] = n.join(" "), e["--win-expander-top-corner-radius"] = `${n[0]} ${n[1]} 0 0`, e["--win-expander-bottom-corner-radius"] = `0 0 ${n[2]} ${n[3]}`, f.Height !== "") {
				let t = W(f.Height);
				if (t) {
					e.minHeight = t;
					let n = G(f.Height);
					n && (e["--win-expander-header-height"] = n);
				}
			}
			return f.Width !== "" && (e.width = W(f.Width)), f.MinWidth !== "" && (e.minWidth = W(f.MinWidth)), f.MaxWidth !== "" && (e.maxWidth = W(f.MaxWidth)), f.HorizontalAlignment && (e.justifySelf = X(f.HorizontalAlignment)), f.VerticalAlignment && (e.alignSelf = Y(f.VerticalAlignment)), e;
		});
		E(y, (e) => {
			k.value = e;
		}), E(k, (e) => {
			let t = h?.vnode.props?.[e ? "onExpanding" : "onCollapsed"];
			for (let e of Array.isArray(t) ? t : [t]) typeof e == "function" && e(h?.exposeProxy ?? h?.proxy, null);
			F(e);
		}), E(C, () => {
			A.value && F(k.value);
		});
		let le = [
			"button",
			"a[href]",
			"input",
			"select",
			"textarea",
			"summary",
			"[contenteditable=\"\"]",
			"[contenteditable=\"true\"]",
			"[role=\"button\"]",
			"[role=\"checkbox\"]",
			"[role=\"link\"]",
			"[role=\"menuitem\"]",
			"[role=\"menuitemcheckbox\"]",
			"[role=\"menuitemradio\"]",
			"[role=\"option\"]",
			"[role=\"radio\"]",
			"[role=\"switch\"]",
			"[role=\"tab\"]",
			"[role=\"textbox\"]",
			"[tabindex]:not([tabindex=\"-1\"])"
		].join(","), Z = (e) => {
			let t = e.target, n = e.currentTarget;
			if (!t?.closest || !n?.contains) return !1;
			let r = t.closest(le);
			return !!(r && r !== n && n.contains(r));
		}, ue = (e) => {
			!x.value || e.defaultPrevented || Z(e) || $();
		}, de = (e) => {
			!x.value || e.defaultPrevented || Z(e) || (L.KeyDown(e), !(e.repeat || e.key !== "Enter" && e.key !== " ") && (e.preventDefault(), $()));
		}, Q = (e) => {
			let t = v(e);
			t !== k.value && (k.value = t, p("update:IsExpanded", t), i(f.IsExpanded, t, h));
		}, $ = () => {
			x.value && Q(!k.value);
		};
		c({
			get IsExpanded() {
				return k.value;
			},
			set IsExpanded(e) {
				Q(e);
			}
		});
		let fe = {
			AnimatedChevronUpDownSmallVisualSource: d,
			props: f,
			emit: p,
			slots: m,
			instance: h,
			xamlBoolean: v,
			resolvedIsExpanded: y,
			isEnabled: x,
			resolvedExpandDirection: C,
			resolvedPadding: w,
			resolvedHorizontalContentAlignment: D,
			resolvedVerticalContentAlignment: O,
			isExpandedState: k,
			contentVisible: A,
			contentRef: j,
			get contentAnimation() {
				return M;
			},
			set contentAnimation(e) {
				M = e;
			},
			get collapseTimer() {
				return N;
			},
			set collapseTimer(e) {
				N = e;
			},
			get transitionVersion() {
				return P;
			},
			set transitionVersion(e) {
				P = e;
			},
			animateContent: F,
			headerRef: I,
			AnimatedGlyphInput: L,
			resolvedHeader: R,
			resolvedContent: z,
			resolvedDescription: B,
			resolvedHeaderIcon: V,
			hasHeaderIcon: H,
			hasHeaderControls: U,
			hasHeaderContent: ie,
			isHeaderIconMarkup: ae,
			cssLength: W,
			expanderHeaderHeight: G,
			xamlThickness: K,
			flexAlignment: q,
			flexDistribution: J,
			selfAlignment: Y,
			justifySelfAlignment: X,
			contentStyle: oe,
			brushColor: se,
			rootStyle: ce,
			interactiveHeaderSelector: le,
			isInteractiveHeaderChild: Z,
			onHeaderClick: ue,
			onHeaderKeyDown: de,
			setIsExpanded: Q,
			toggleExpanded: $,
			computed: l,
			getCurrentInstance: g,
			nextTick: _,
			onBeforeUnmount: re,
			onMounted: b,
			ref: S,
			useSlots: T,
			watch: E,
			AnimatedIcon: ee,
			get FontIconSource() {
				return ne;
			},
			get animatedIconVisualSourceComponents() {
				return s;
			},
			get useAnimatedIconInput() {
				return te;
			},
			TextBlock: o,
			get resolveXamlValue() {
				return r;
			},
			get updateXamlBinding() {
				return i;
			},
			get resolveBrushStyle() {
				return n;
			},
			get cssColor() {
				return e;
			},
			get isSolidColorBrush() {
				return t;
			}
		};
		return Object.defineProperty(fe, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), fe;
	}
}, k = [
	"aria-expanded",
	"aria-disabled",
	"tabindex"
], A = { class: "win-expander-header-main" }, j = {
	key: 0,
	class: "win-expander-header-icon icon",
	"aria-hidden": "true"
}, M = ["innerHTML"], N = { class: "win-expander-header-content" }, P = {
	key: 0,
	class: "win-expander-header-controls"
}, F = {
	class: "win-expander-chevron",
	"aria-hidden": "true"
}, I = ["aria-hidden", "inert"], L = { class: "win-expander-inner" };
function R(e, t, n, r, i, a) {
	return x(), f("div", {
		class: v(["win-expander", {
			"is-expanded": r.isExpandedState,
			"is-disabled": !r.isEnabled,
			"expand-up": r.resolvedExpandDirection === "Up",
			"has-header-content": r.hasHeaderContent,
			"has-header-controls": r.hasHeaderControls
		}]),
		style: y(r.rootStyle)
	}, [p("div", {
		ref: "headerRef",
		class: "win-expander-header",
		onClick: r.onHeaderClick,
		onKeydown: r.onHeaderKeyDown,
		onPointerenter: t[0] ||= (...e) => r.AnimatedGlyphInput.PointerEntered && r.AnimatedGlyphInput.PointerEntered(...e),
		onPointerleave: t[1] ||= (...e) => r.AnimatedGlyphInput.PointerExited && r.AnimatedGlyphInput.PointerExited(...e),
		onPointerdown: t[2] ||= (...e) => r.AnimatedGlyphInput.PointerPressed && r.AnimatedGlyphInput.PointerPressed(...e),
		onPointerup: t[3] ||= (...e) => r.AnimatedGlyphInput.PointerReleased && r.AnimatedGlyphInput.PointerReleased(...e),
		onPointercancel: t[4] ||= (...e) => r.AnimatedGlyphInput.PointerExited && r.AnimatedGlyphInput.PointerExited(...e),
		onLostpointercapture: t[5] ||= (...e) => r.AnimatedGlyphInput.PointerReleased && r.AnimatedGlyphInput.PointerReleased(...e),
		onKeyup: t[6] ||= (...e) => r.AnimatedGlyphInput.KeyUp && r.AnimatedGlyphInput.KeyUp(...e),
		onBlur: t[7] ||= (...e) => r.AnimatedGlyphInput.LostFocus && r.AnimatedGlyphInput.LostFocus(...e),
		"aria-expanded": r.isExpandedState,
		"aria-disabled": !r.isEnabled,
		role: "button",
		tabindex: r.isEnabled ? 0 : -1
	}, [
		p("div", A, [r.hasHeaderIcon ? (x(), f("span", j, [C(e.$slots, "HeaderIcon", {}, () => [r.isHeaderIconMarkup ? (x(), f("span", {
			key: 0,
			innerHTML: r.resolvedHeaderIcon
		}, null, 8, M)) : (x(), f(c, { key: 1 }, [m(w(r.resolvedHeaderIcon), 1)], 64))])])) : d("", !0), p("div", N, [C(e.$slots, "Header", {}, () => [r.resolvedHeader ? (x(), u(r.TextBlock, {
			key: 0,
			class: "win-expander-header-text",
			Text: r.resolvedHeader,
			FontSize: "14",
			LineHeight: "20",
			TextWrapping: "Wrap"
		}, null, 8, ["Text"])) : d("", !0)]), C(e.$slots, "Description", {}, () => [r.resolvedDescription ? (x(), u(r.TextBlock, {
			key: 0,
			class: "win-expander-description",
			Text: r.resolvedDescription,
			FontSize: "var(--SettingsCardDescriptionFontSize, 12px)",
			LineHeight: "16",
			Foreground: "var(--TextFillColorSecondaryBrush, var(--text-secondary))",
			TextWrapping: "Wrap"
		}, null, 8, ["Text"])) : d("", !0)])])]),
		r.hasHeaderControls ? (x(), f("div", P, [C(e.$slots, "HeaderControls")])) : d("", !0),
		p("span", F, [h(r.AnimatedIcon, {
			class: "win-expander-arrow",
			"x:Name": "ExpandCollapseChevron",
			Width: "12",
			Height: "12",
			Foreground: "{ThemeResource ExpanderChevronForeground}",
			HorizontalAlignment: "Center",
			VerticalAlignment: "Center",
			"AutomationProperties.AccessibilityView": "Raw"
		}, {
			default: D(() => [h(r.AnimatedIcon.Source, null, {
				default: D(() => [h(r.AnimatedChevronUpDownSmallVisualSource)]),
				_: 1
			}), h(r.AnimatedIcon.FallbackIconSource, null, {
				default: D(() => [h(r.FontIconSource, {
					Glyph: "",
					FontFamily: "{ThemeResource SymbolThemeFontFamily}",
					FontSize: "12",
					IsTextScaleFactorEnabled: "False"
				})]),
				_: 1
			})]),
			_: 1
		})])
	], 40, k), p("div", {
		class: "win-expander-grid",
		style: y({ display: r.contentVisible ? "" : "none" }),
		"aria-hidden": !r.isExpandedState,
		inert: !r.isExpandedState
	}, [p("div", L, [p("div", {
		ref: "contentRef",
		class: "win-expander-content",
		style: y(r.contentStyle)
	}, [C(e.$slots, "default", {}, () => [m(w(r.resolvedContent), 1)])], 4)])], 12, I)], 6);
}
var z = /*#__PURE__*/ a(O, [
	["render", R],
	["__scopeId", "data-v-98f8f806"],
	["__file", "ExpanderBase.vue"]
]);
//#endregion
export { z as default };

//# sourceMappingURL=ExpanderBase.vue.js.map