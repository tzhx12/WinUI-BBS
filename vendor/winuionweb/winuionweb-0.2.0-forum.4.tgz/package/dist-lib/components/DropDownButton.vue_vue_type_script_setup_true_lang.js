import { boolValue as e } from "./layout.js";
import { normalizeXamlNodes as t, resolveXamlHandler as n, resolveXamlResourceObject as r, resolveXamlValue as i, updateXamlBinding as a, xamlScopeKey as o } from "./xamlRuntime.js";
import { brushProperty as s, isBrushProperty as ee, useBrushProperty as te } from "./brushProperties.js";
import ne from "./Grid.vue.js";
import { useUICommand as re } from "./uiCommandRuntime.js";
import { getToolTipServiceProperty as ie } from "./ToolTipServiceProperties.js";
import { xamlResourceDictionaryKey as ae } from "./Page.vue_vue_type_script_lang.js";
import { animatedIconVisualSourceComponents as oe } from "./animatedIconVisuals.js";
import se from "./AnimatedIcon.vue.js";
import ce from "./ContentPresenter.vue.js";
import { buttonContentProperty as c, getButtonContentProperty as le, useButtonContent as ue } from "./buttonContentRuntime.js";
import de from "./Button.vue.js";
import fe from "./ColumnDefinition.vue.js";
import { FontIconSource as pe } from "./IconSource.js";
import { DropDownButtonContent as l, DropDownButtonFlyout as u, DropDownButtonKeyboardAccelerators as d, getDropDownButtonProperty as me } from "./DropDownButtonProperties.js";
import { Comment as he, Fragment as f, Text as ge, computed as p, defineComponent as m, getCurrentInstance as _e, h, inject as g, isVNode as _, onBeforeUnmount as ve, onMounted as ye, provide as be, proxyRefs as xe, ref as Se, shallowRef as v, useAttrs as Ce, useSlots as we, watch as y } from "vue";
var b = /*@__PURE__*/ m({
	Content: l,
	Flyout: u,
	KeyboardAccelerators: d,
	ContentTemplate: c("DropDownButton", "ContentTemplate"),
	ContentTransitions: c("DropDownButton", "ContentTransitions"),
	Resources: c("DropDownButton", "Resources"),
	Background: s("DropDownButton", "Background"),
	name: "DropDownButton",
	inheritAttrs: !1,
	__name: "DropDownButton",
	props: {
		Content: {
			type: null,
			default: void 0
		},
		ContentTemplate: {
			type: null,
			default: void 0
		},
		ContentTransitions: {
			type: null,
			default: void 0
		},
		Flyout: {
			type: null,
			default: null
		},
		Command: {
			type: [Object, String],
			default: void 0
		},
		CommandParameter: { default: void 0 },
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		IsTabStop: {
			type: [Boolean, String],
			default: !0
		},
		ClickMode: {
			type: String,
			default: "Release"
		},
		RequestedTheme: {
			type: String,
			default: "Default"
		},
		Visibility: {
			type: String,
			default: "Visible"
		},
		Background: {
			type: [String, Object],
			default: ""
		},
		Foreground: {
			type: String,
			default: ""
		},
		BorderBrush: {
			type: String,
			default: ""
		},
		BackgroundSizing: {
			type: String,
			default: "InnerBorderEdge"
		},
		BorderThickness: {
			type: [String, Number],
			default: 1
		},
		CornerRadius: {
			type: [String, Number],
			default: 4
		},
		Padding: {
			type: [String, Number],
			default: "11,5,11,6"
		},
		Margin: {
			type: [String, Number],
			default: 0
		},
		Width: {
			type: [String, Number],
			default: ""
		},
		Height: {
			type: [String, Number],
			default: ""
		},
		MinWidth: {
			type: [String, Number],
			default: 0
		},
		MinHeight: {
			type: [String, Number],
			default: 0
		},
		MaxWidth: {
			type: [String, Number],
			default: ""
		},
		MaxHeight: {
			type: [String, Number],
			default: ""
		},
		HorizontalAlignment: {
			type: String,
			default: "Left"
		},
		VerticalAlignment: {
			type: String,
			default: "Center"
		},
		HorizontalContentAlignment: {
			type: String,
			default: "Center"
		},
		VerticalContentAlignment: {
			type: String,
			default: "Center"
		},
		FontFamily: {
			type: String,
			default: "{ThemeResource ContentControlThemeFontFamily}"
		},
		FontSize: {
			type: [String, Number],
			default: 14
		},
		FontWeight: {
			type: String,
			default: "Normal"
		},
		UseSystemFocusVisuals: {
			type: [Boolean, String],
			default: !0
		},
		FocusVisualMargin: {
			type: [String, Number],
			default: -3
		}
	},
	emits: [
		"Click",
		"GotFocus",
		"LostFocus",
		"KeyDown",
		"KeyUp",
		"ContextRequested",
		"PointerEntered",
		"PointerExited",
		"PointerMoved",
		"PointerPressed",
		"PointerReleased",
		"PointerCanceled",
		"PointerCaptureLost"
	],
	setup(s, { expose: c, emit: l }) {
		let u = s, d = l, b = _e(), x = Ce(), S = we(), C = Se(null), w = p(() => C.value?.Element ?? null), T = (e) => i(e, b), E = (e) => T(e), D = (e) => T(e), O = g(ae, {}), { ContentTemplate: k, ContentTransitions: A, renderTemplate: j } = ue(u, () => S.default?.() ?? [], b), M = te("Background", () => u.Background, () => S.default?.() ?? [], b), Te = p(() => M.value.value), N = re(() => T(u.Command)), P = p(() => T(u.CommandParameter)), F = v(void 0), I = p(() => u.Content === void 0 ? N.value?.Label ?? "" : T(u.Content)), L = p({
			get: () => F.value === void 0 ? I.value : F.value,
			set: (e) => {
				F.value = e, a(u.Content, e, b);
			}
		});
		y(I, () => {
			F.value = void 0;
		});
		let R = (e) => {
			let t = p(() => T(u[e])), n = v(void 0);
			return y(t, () => {
				n.value = void 0;
			}), p({
				get: () => n.value === void 0 ? t.value : n.value,
				set: (t) => {
					n.value = t, a(u[e], t, b);
				}
			});
		}, z = R("IsEnabled"), B = R("RequestedTheme"), V = p({
			get: () => e(z.value) && (N.value?.CanExecute?.(P.value) ?? !0),
			set: (t) => {
				z.value = e(t);
			}
		}), Ee = p(() => e(T(u.IsTabStop))), De = p(() => e(T(u.UseSystemFocusVisuals))), Oe = p(() => String(T(u.ClickMode))), H = (e) => Array.isArray(e.children) ? e.children : e.children?.default?.() ?? [], U = p(() => {
			let e = {
				content: [],
				flyout: [],
				attached: [],
				keyboardAccelerators: [],
				resources: []
			}, t = (n) => {
				for (let r of n) {
					if (r.type === he || r.type === ge && !String(r.children ?? "").trim()) continue;
					if (r.type === f) {
						t(H(r));
						continue;
					}
					if (ee(r)) continue;
					let n = le(r);
					if (n) {
						n === "Resources" && e.resources.push(...H(r));
						continue;
					}
					let i = me(r);
					i ? e[i].push(...H(r)) : ie(r) ? e.attached.push(r) : e.content.push(r);
				}
			};
			return t(S.default?.() ?? []), e;
		}), W = p(() => {
			let e = (t) => t.flatMap((t) => {
				let n = t.type;
				return t.type === f || (typeof n == "string" ? n : n?.name ?? n?.__name) === "ResourceDictionary" ? e(H(t)) : [t];
			});
			return Object.fromEntries(e(U.value.resources).filter((e) => e.props?.["x:Key"]).map((e) => [e.props["x:Key"], e]));
		}), G = p(() => {
			let e = typeof u.Flyout == "string" ? u.Flyout.match(/^\{(?:StaticResource|ThemeResource)\s+([^}]+)\}$/)?.[1] : void 0;
			return e ? W.value[e] ?? O[e] ?? r(e, b) : T(u.Flyout);
		}), K = v(void 0), q = p(() => K.value === void 0 ? U.value.flyout.length ? h(f, t(U.value.flyout, b)) : G.value : K.value), J = p({
			get: () => C.value?.Flyout ?? (_(q.value) ? null : q.value),
			set: (e) => {
				J.value?.Hide?.(), K.value = e, a(u.Flyout, e, b);
			}
		}), ke = p(() => !!J.value?.IsOpen), Ae = m({ setup: () => () => {
			let e = j(L.value);
			if (e) return e;
			let n = F.value === void 0 ? t(U.value.content, b) : [];
			return n.length ? n.every((e) => e.type === ge) ? h("span", { class: "win-button-default-text" }, n.map((e) => String(e.children ?? "")).join("")) : h(f, n) : _(L.value) ? h(f, t([L.value], b)) : typeof L.value == "string" || typeof L.value == "number" ? h("span", { class: "win-button-default-text" }, String(L.value)) : null;
		} }), je = m({ setup: () => () => h(f, U.value.attached) }), Y = (e, t, r = {}) => {
			let i = Object.assign(r, {
				OriginalSource: Z,
				OriginalEvent: t,
				Handled: r.Handled ?? !1
			}), a = b?.vnode.props?.[`on${e}`];
			if (e === "Click") for (let e of Array.isArray(a) ? a : [a]) typeof e == "function" && e(Z, i);
			else d(e, Z, i);
			return a || n(x[e], b)?.(Z, i), i.Handled && (t.preventDefault(), t.stopPropagation()), i;
		}, Me = (e, t) => Y("Click", t.OriginalEvent, t), X = (e) => (t, n) => Y(e, n.OriginalEvent, n), Ne = p(() => x.ContextRequested || b?.vnode.props?.onContextRequested ? X("ContextRequested") : void 0), Pe = p(() => !!C.value?.IsPressed), Fe = p(() => !!C.value?.IsPointerOver), Ie = p({
			get: () => F.value === void 0 ? U.value.content[0] ?? L.value : L.value,
			set: (e) => {
				L.value = e;
			}
		}), Z = xe({
			Element: w,
			Name: p(() => x["data-xaml-ref"] ?? x["x:Name"] ?? x.Name ?? ""),
			Content: Ie,
			ContentTemplate: k,
			ContentTransitions: A,
			IsEnabled: V,
			RequestedTheme: B,
			Command: N,
			CommandParameter: P,
			Flyout: J,
			IsPressed: Pe,
			IsPointerOver: Fe,
			Focus: () => V.value ? (w.value?.focus(), !!w.value) : !1
		});
		c(Z);
		let Le = p(() => E(u.Padding)), Re = p(() => D(u.BorderThickness)), ze = p(() => D(u.CornerRadius)), Be = p(() => E(u.BackgroundSizing)), Ve = p(() => E(u.HorizontalContentAlignment)), He = p(() => E(u.VerticalContentAlignment)), Ue = oe.AnimatedChevronDownSmallVisualSource, We = p(() => {
			let e = { ...x };
			for (let t of [
				"class",
				"style",
				"Click",
				"GotFocus",
				"LostFocus",
				"KeyDown",
				"KeyUp",
				"ContextRequested",
				"PointerEntered",
				"PointerExited",
				"PointerMoved",
				"PointerPressed",
				"PointerReleased",
				"PointerCanceled",
				"PointerCaptureLost"
			]) delete e[t];
			let t = T(e["AutomationProperties.Name"]);
			delete e["AutomationProperties.Name"], t && (e["aria-label"] = String(t));
			let n = T(e["ToolTipService.ToolTip"]) || N.value?.Description;
			return delete e["ToolTipService.ToolTip"], n && (e["tooltipservice.tooltip"] = String(n)), e;
		}), Ge = () => {
			!V.value || T(u.Visibility) === "Collapsed" || (w.value ? w.value.click() : J.value?.ShowAt?.(null));
		}, Q = (t) => {
			if (!(t.defaultPrevented || t.repeat || !V.value) && !N.value?.MatchesKeyboardEvent?.(t)) for (let n of U.value.keyboardAccelerators) {
				let r = n.props ?? {}, i = String(T(r.Key) ?? ""), a = String(T(r.Modifiers) ?? "None").split(/[ ,]+/);
				if (i.toLowerCase() === t.key.toLowerCase() && t.ctrlKey === a.includes("Control") && t.altKey === a.includes("Menu") && t.shiftKey === a.includes("Shift") && t.metaKey === a.includes("Windows") && e(T(r.IsEnabled ?? !0))) {
					t.preventDefault(), Ge();
					return;
				}
			}
		};
		y(V, (e) => {
			e || J.value?.Hide?.();
		}), ye(() => document.addEventListener("keydown", Q)), ve(() => {
			document.removeEventListener("keydown", Q), J.value?.Hide?.();
		}), be(o, {
			...g(o, {}),
			Content: L,
			ContentTemplate: k,
			ContentTransitions: A,
			Padding: Le,
			BorderThickness: Re,
			CornerRadius: ze,
			BackgroundSizing: Be,
			HorizontalContentAlignment: Ve,
			VerticalContentAlignment: He
		});
		let $ = {
			props: u,
			emit: d,
			instance: b,
			attrs: x,
			slots: S,
			buttonControl: C,
			element: w,
			resolve: T,
			resolveString: E,
			resolveLength: D,
			inheritedResources: O,
			ContentTemplate: k,
			ContentTransitions: A,
			renderTemplate: j,
			backgroundBrush: M,
			resolvedBackground: Te,
			Command: N,
			CommandParameter: P,
			localContent: F,
			sourceContent: I,
			Content: L,
			property: R,
			EnabledProperty: z,
			RequestedTheme: B,
			IsEnabled: V,
			IsTabStop: Ee,
			UseSystemFocusVisuals: De,
			ClickMode: Oe,
			childrenOf: H,
			propertyNodes: U,
			localResources: W,
			sourceFlyout: G,
			localFlyout: K,
			FlyoutForButton: q,
			Flyout: J,
			isFlyoutOpen: ke,
			ContentOutlet: Ae,
			AttachedOutlet: je,
			raiseEvent: Y,
			onButtonClick: Me,
			forwardButtonEvent: X,
			contextRequestedListener: Ne,
			IsPressed: Pe,
			IsPointerOver: Fe,
			exposedContent: Ie,
			api: Z,
			Padding: Le,
			BorderThickness: Re,
			CornerRadius: ze,
			BackgroundSizing: Be,
			HorizontalContentAlignment: Ve,
			VerticalContentAlignment: He,
			AnimatedChevronDownSmallVisualSource: Ue,
			hostAttrs: We,
			invoke: Ge,
			onAccelerator: Q,
			Grid: ne,
			ColumnDefinition: fe,
			ContentPresenter: ce,
			AnimatedIcon: se,
			get FontIconSource() {
				return pe;
			},
			Button: de
		};
		return Object.defineProperty($, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), $;
	}
});
//#endregion
export { b as default };

//# sourceMappingURL=DropDownButton.vue_vue_type_script_setup_true_lang.js.map