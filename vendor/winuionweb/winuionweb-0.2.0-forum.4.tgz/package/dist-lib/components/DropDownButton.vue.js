import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./DropDownButton.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                   */
import { Fragment as n, createBlock as r, createCommentVNode as i, createElementBlock as a, createVNode as o, mergeProps as s, openBlock as c, withCtx as l } from "vue";
//#region src/components/DropDownButton.vue
function u(e, t, u, d, f, p) {
	return c(), a(n, null, [o(d.Button, s({ ref: "buttonControl" }, d.hostAttrs, {
		class: ["win-dropdown-button", [d.attrs.class]],
		style: d.attrs.style,
		IsEnabled: d.IsEnabled,
		IsTabStop: d.IsTabStop,
		ClickMode: d.ClickMode,
		RequestedTheme: d.RequestedTheme,
		Visibility: d.resolveString(d.props.Visibility),
		Background: d.resolvedBackground,
		Foreground: d.resolveString(d.props.Foreground),
		BorderBrush: d.resolveString(d.props.BorderBrush),
		BorderThickness: d.BorderThickness,
		CornerRadius: d.CornerRadius,
		Padding: d.resolveString(d.props.Padding),
		BackgroundSizing: d.BackgroundSizing,
		Margin: d.resolveString(d.props.Margin),
		Width: d.resolveLength(d.props.Width),
		Height: d.resolveLength(d.props.Height),
		MinWidth: d.resolveLength(d.props.MinWidth),
		MinHeight: d.resolveLength(d.props.MinHeight),
		MaxWidth: d.resolveLength(d.props.MaxWidth),
		MaxHeight: d.resolveLength(d.props.MaxHeight),
		HorizontalAlignment: d.resolveString(d.props.HorizontalAlignment),
		VerticalAlignment: d.resolveString(d.props.VerticalAlignment),
		HorizontalContentAlignment: d.HorizontalContentAlignment,
		VerticalContentAlignment: d.VerticalContentAlignment,
		FontFamily: d.resolveString(d.props.FontFamily),
		FontSize: d.resolveLength(d.props.FontSize),
		FontWeight: d.resolveString(d.props.FontWeight),
		UseSystemFocusVisuals: d.UseSystemFocusVisuals,
		FocusVisualMargin: d.resolveLength(d.props.FocusVisualMargin),
		"aria-haspopup": d.Flyout ? "menu" : void 0,
		"aria-expanded": d.Flyout ? d.isFlyoutOpen : void 0,
		Command: d.Command,
		CommandParameter: d.CommandParameter,
		Flyout: d.FlyoutForButton,
		onClick: d.onButtonClick,
		onGotFocus: t[0] ||= (e) => d.forwardButtonEvent("GotFocus"),
		onLostFocus: t[1] ||= (e) => d.forwardButtonEvent("LostFocus"),
		onKeyDown: t[2] ||= (e) => d.forwardButtonEvent("KeyDown"),
		onKeyUp: t[3] ||= (e) => d.forwardButtonEvent("KeyUp"),
		onPointerEntered: t[4] ||= (e) => d.forwardButtonEvent("PointerEntered"),
		onPointerExited: t[5] ||= (e) => d.forwardButtonEvent("PointerExited"),
		onPointerMoved: t[6] ||= (e) => d.forwardButtonEvent("PointerMoved"),
		onPointerPressed: t[7] ||= (e) => d.forwardButtonEvent("PointerPressed"),
		onPointerReleased: t[8] ||= (e) => d.forwardButtonEvent("PointerReleased"),
		onPointerCanceled: t[9] ||= (e) => d.forwardButtonEvent("PointerCanceled"),
		onPointerCaptureLost: t[10] ||= (e) => d.forwardButtonEvent("PointerCaptureLost"),
		onContextRequested: d.contextRequestedListener
	}), {
		default: l(() => [o(d.Grid, { class: "win-dropdown-root-grid" }, {
			default: l(() => [
				o(d.Grid.ColumnDefinitions, null, {
					default: l(() => [o(d.ColumnDefinition, { Width: "*" }), o(d.ColumnDefinition, { Width: "Auto" })]),
					_: 1
				}),
				o(d.ContentPresenter, {
					class: "win-dropdown-content-presenter",
					Content: d.Content,
					ContentTemplate: d.ContentTemplate,
					ContentTransitions: d.ContentTransitions,
					HorizontalContentAlignment: d.HorizontalContentAlignment,
					VerticalContentAlignment: d.VerticalContentAlignment,
					"AutomationProperties.AccessibilityView": "Raw"
				}, {
					default: l(() => [o(d.ContentOutlet)]),
					_: 1
				}, 8, [
					"Content",
					"ContentTemplate",
					"ContentTransitions",
					"HorizontalContentAlignment",
					"VerticalContentAlignment"
				]),
				o(d.AnimatedIcon, {
					class: "win-dropdown-chevron",
					"Grid.Column": "1",
					Margin: "8,0,0,0",
					Width: "12",
					Height: "12",
					"AutomationProperties.AccessibilityView": "Raw"
				}, {
					default: l(() => [o(d.AnimatedChevronDownSmallVisualSource), o(d.AnimatedIcon.FallbackIconSource, null, {
						default: l(() => [o(d.FontIconSource, {
							FontSize: "8",
							FontFamily: "{ThemeResource SymbolThemeFontFamily}",
							Glyph: "",
							IsTextScaleFactorEnabled: "False"
						})]),
						_: 1
					})]),
					_: 1
				})
			]),
			_: 1
		})]),
		_: 1
	}, 16, /* @__PURE__ */ "class.style.IsEnabled.IsTabStop.ClickMode.RequestedTheme.Visibility.Background.Foreground.BorderBrush.BorderThickness.CornerRadius.Padding.BackgroundSizing.Margin.Width.Height.MinWidth.MinHeight.MaxWidth.MaxHeight.HorizontalAlignment.VerticalAlignment.HorizontalContentAlignment.VerticalContentAlignment.FontFamily.FontSize.FontWeight.UseSystemFocusVisuals.FocusVisualMargin.aria-haspopup.aria-expanded.Command.CommandParameter.Flyout.onContextRequested".split(".")), d.propertyNodes.attached.length ? (c(), r(d.AttachedOutlet, { key: 0 })) : i("", !0)], 64);
}
var d = /*#__PURE__*/ e(t, [["render", u], ["__file", "DropDownButton.vue"]]);
//#endregion
export { d as default };

//# sourceMappingURL=DropDownButton.vue.js.map