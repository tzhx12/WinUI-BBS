import { alignment as e, boolValue as t, xamlThickness as n } from "./layout.js";
import { colorString as r, createSolidColorBrush as i, xamlThemeKey as a } from "./brushCore.js";
import { primitiveResourceScope as o } from "./xamlPrimitives.js";
import { useAcrylicBrushStyle as s } from "./AcrylicBrush.js";
import { normalizeXamlNodes as c, resolveXamlHandler as l, resolveXamlValue as u, updateXamlBinding as d, xamlItemContextKey as f, xamlScopeKey as p, xamlTemplateComponent as m } from "./xamlRuntime.js";
import { collectXamlResources as h, useXamlBrushResources as g } from "./xamlBrushResources.js";
import { isBrushProperty as _, useBrushProperty as v } from "./brushProperties.js";
import { vAcrylicBrush as ee } from "./acrylicBrushVisual.js";
import { vThemeShadow as te } from "./themeShadowVisual.js";
import ne from "../_virtual/_plugin-vue_export-helper.js";
import { useI18n as re } from "./i18n/index.js";
import { xamlResourceDictionaryKey as ie } from "./Page.vue_vue_type_script_lang.js";
import { CollectionItemContainerStyle as ae, CollectionItemTemplate as oe, CollectionItems as se, CollectionResources as ce, getCollectionProperty as le, getVNodeChildren as ue } from "./CollectionProperties.js";
import de from "./TextBlock.vue.js";
import { animatedIconVisualSourceComponents as fe } from "./animatedIconVisuals.js";
import pe from "./AnimatedIcon.vue.js";
import me from "./ScrollViewer.vue.js";
import { scrollViewerTemplateBindings as he } from "./scrollViewerTemplateBindings.js";
import ge from "./ContentPresenter.vue.js";
import _e from "./TextBox.vue.js";
import { useAnimatedIconInput as ve } from "./animatedIconInput.js";
import { useFlyoutAnimation as ye } from "./useFlyoutAnimation.js";
import { FontIconSource as be } from "./IconSource.js";
import { ComboBoxDescription as xe, ComboBoxHeader as Se, ComboBoxHeaderTemplate as Ce, getComboBoxProperty as we, isComboBoxProperty as Te } from "./ComboBoxProperties.js";
/* empty css                      */
import "./inlineControlProperties.js";
/* empty css                                             */
import { Fragment as Ee, Teleport as De, computed as y, createBlock as Oe, createCommentVNode as ke, createElementBlock as b, createElementVNode as x, createVNode as S, defineComponent as Ae, getCurrentInstance as je, h as Me, inject as Ne, isVNode as Pe, mergeProps as C, nextTick as w, normalizeClass as Fe, normalizeStyle as Ie, onBeforeUnmount as Le, onMounted as Re, openBlock as T, provide as ze, ref as E, renderList as Be, shallowReactive as Ve, shallowRef as He, toDisplayString as Ue, unref as We, useAttrs as Ge, useSlots as Ke, watch as D, withCtx as O, withDirectives as qe, withModifiers as Je } from "vue";
//#region src/components/ComboBox.vue
var Ye = /*@__PURE__*/ Object.assign({
	ItemTemplate: oe,
	Items: se,
	Resources: ce,
	ItemContainerStyle: ae,
	Header: Se,
	HeaderTemplate: Ce,
	Description: xe
}, {
	name: "ComboBox",
	inheritAttrs: !1
}, {
	__name: "ComboBox",
	props: {
		ItemsSource: {
			type: [Array, String],
			default: void 0
		},
		ItemTemplate: {
			type: [
				String,
				Object,
				Function
			],
			default: void 0
		},
		Header: {
			type: null,
			default: ""
		},
		HeaderTemplate: {
			type: null,
			default: void 0
		},
		Description: {
			type: null,
			default: ""
		},
		ItemContainerStyle: {
			type: null,
			default: void 0
		},
		PlaceholderText: {
			type: [String, Number],
			default: ""
		},
		IsEditable: {
			type: [Boolean, String],
			default: !1
		},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		IsDropDownOpen: {
			type: [Boolean, String],
			default: void 0
		},
		SelectedIndex: {
			type: [Number, String],
			default: void 0
		},
		SelectedItem: {
			type: null,
			default: void 0
		},
		SelectedValue: {
			type: null,
			default: void 0
		},
		SelectedValuePath: {
			type: [String, Number],
			default: ""
		},
		DisplayMemberPath: {
			type: [String, Number],
			default: ""
		},
		Text: {
			type: [String, Number],
			default: void 0
		},
		IsTextSearchEnabled: {
			type: [Boolean, String],
			default: !0
		},
		SelectionChangedTrigger: {
			type: String,
			default: "Committed"
		},
		LightDismissOverlayMode: {
			type: String,
			default: "Auto"
		},
		IsTabStop: {
			type: [Boolean, String],
			default: !0
		},
		RequestedTheme: {
			type: String,
			default: "Default"
		},
		Visibility: {
			type: String,
			default: "Visible"
		},
		Background: {
			type: [String, Object],
			default: ""
		},
		Foreground: {
			type: String,
			default: ""
		},
		BorderBrush: {
			type: [String, Object],
			default: ""
		},
		BorderThickness: {
			type: [String, Number],
			default: 1
		},
		CornerRadius: {
			type: [String, Number],
			default: 4
		},
		Padding: {
			type: [String, Number],
			default: ""
		},
		PlaceholderForeground: {
			type: String,
			default: ""
		},
		FontFamily: {
			type: String,
			default: ""
		},
		FontSize: {
			type: [String, Number],
			default: ""
		},
		FontWeight: {
			type: [String, Number],
			default: ""
		},
		HorizontalContentAlignment: {
			type: String,
			default: "Stretch"
		},
		VerticalContentAlignment: {
			type: String,
			default: "Top"
		},
		Width: {
			type: [String, Number],
			default: ""
		},
		Height: {
			type: [String, Number],
			default: ""
		},
		MinWidth: {
			type: [String, Number],
			default: ""
		},
		MinHeight: {
			type: [String, Number],
			default: ""
		},
		MaxWidth: {
			type: [String, Number],
			default: ""
		},
		MaxHeight: {
			type: [String, Number],
			default: ""
		},
		Margin: {
			type: [String, Number],
			default: ""
		},
		HorizontalAlignment: {
			type: String,
			default: "Left"
		},
		VerticalAlignment: {
			type: String,
			default: "Top"
		},
		MaxDropDownHeight: {
			type: [Number, String],
			default: 504
		}
	},
	emits: [
		"DropDownOpened",
		"DropDownClosed",
		"SelectionChanged",
		"TextSubmitted",
		"Loaded"
	],
	setup(ne, { expose: De, emit: Oe }) {
		let ke = fe.AnimatedChevronDownSmallVisualSource, b = {
			Top: 4,
			Bottom: 4
		}, { t: x } = re(), S = ne, C = je(), Fe = s("{ThemeResource ComboBoxDropDownBackground}", C), Ie = ve(!1, (e) => e === "Disabled" ? "Normal" : e), T = Ge(), Be = y(() => Object.fromEntries(Object.entries(T).filter(([e]) => ![
			"class",
			"style",
			"SelectionChanged",
			"TextSubmitted",
			"DropDownOpened",
			"DropDownClosed",
			"Loaded"
		].includes(e) && !e.startsWith("on")))), Ue = he((e) => T[e], C, {
			VerticalScrollMode: "Auto",
			IsDeferredScrollingEnabled: !1
		}), O = Ke(), qe = o(() => O.default?.() ?? []), Je = y(() => t(qe.value.IsDefaultShadowEnabled ?? !0)), Ye = v("Background", () => S.Background, () => O.default?.() ?? [], C), Xe = Ne(ie, {}), Ze = y(() => {
			let e = {
				Header: [],
				HeaderTemplate: [],
				Description: [],
				resources: [],
				items: [],
				itemTemplate: [],
				itemContainerStyle: []
			}, t = (n) => {
				for (let r of n) {
					if (r.type === Ee && Array.isArray(r.children)) {
						t(r.children);
						continue;
					}
					let n = we(r) || le(r);
					n && n in e && e[n].push(...ue(r));
				}
			};
			return t(O.default?.() ?? []), e;
		}), Qe = y(() => {
			let e = {}, t = (n) => {
				for (let r of n) {
					let n = typeof r.type == "string" ? r.type : r.type?.name;
					r.type === Ee || n === "ResourceDictionary" ? t(ue(r)) : h([r], e);
				}
			};
			return t(Ze.value.resources), e;
		}), $e = new Proxy(Xe, { get: (e, t) => Qe.value[t] ?? e[t] });
		ze(ie, $e);
		let et = g(C), k = (e) => {
			let t = typeof e == "string" ? e.match(/^\{(?:StaticResource|ThemeResource)\s+([^\s}]+)\}/)?.[1] : void 0;
			return t && $e[t] ? $e[t] : u(e, C);
		}, tt = y(() => {
			let e = k(S.ItemTemplate);
			return e && typeof e == "object" && e.type ? ue(e) : Ze.value.itemTemplate;
		}), nt = y(() => tt.value.length > 0 || typeof k(S.ItemTemplate) == "function"), rt = Ae({
			name: "ComboBoxItemTemplate",
			props: {
				item: {
					type: null,
					default: void 0
				},
				index: {
					type: Number,
					default: 0
				}
			},
			setup(e) {
				return ze(f, y(() => e.item)), () => typeof k(S.ItemTemplate) == "function" ? k(S.ItemTemplate)(e.item) : m(tt.value, e.item, C);
			}
		}), it = Ae({
			props: { item: {
				type: null,
				default: void 0
			} },
			setup(e) {
				return () => e.item?.__contentNodes?.length ? Me(Ee, c(e.item.__contentNodes, C)) : Pe(e.item?.Content) ? Me(Ee, c([e.item.Content], C)) : K(e.item);
			}
		}), at = Ae({ setup() {
			return () => U.value === void 0 ? Me(de, {
				Text: mt.value,
				class: "win-combo-placeholder",
				Foreground: "var(--ComboBoxPlaceholderCurrent)"
			}) : nt.value ? Me(rt, {
				item: U.value,
				index: H.value
			}) : Me(it, { item: U.value });
		} }), ot = /* @__PURE__ */ new Map(), st = /* @__PURE__ */ new Map(), ct = /* @__PURE__ */ new Map(), lt = y(() => {
			let e = [], n = /* @__PURE__ */ new Set(), a = /* @__PURE__ */ new Map(), o = (e) => {
				if (e == null) return "";
				if (Array.isArray(e)) return e.map(o).join("");
				if (typeof e == "string" || typeof e == "number") return String(e);
				if (typeof e != "object") return "";
				let t = e.children;
				if (typeof t == "string" || typeof t == "number") return String(t);
				if (t && typeof t == "object" && typeof t.default == "function") try {
					return o(t.default());
				} catch {
					return "";
				}
				return o(t);
			}, s = (c) => {
				if (c) {
					if (Array.isArray(c)) {
						c.forEach(s);
						return;
					}
					if (typeof c == "object") {
						let l = c.type, d = typeof l == "string" ? l : l?.name || l?.__name || "";
						if (le(c) === "items") s(ue(c));
						else if (Te(c) || _(c)) return;
						else if (d === "x:String") {
							let t = c.props?.["x:Uid"], n = t ? x(t) : o(c.children).trim();
							n && (a.set(c.key ?? t ?? e.length, e.length), e.push(n));
						} else if (d === "SolidColorBrush") {
							let t = c.key ?? e.length;
							n.add(t);
							let a = ot.get(t);
							(!a || a.__xamlBrush !== "SolidColorBrush") && (a = i(), ot.set(t, a)), a.Color = r(u(c.props?.Color, C)), a.Opacity = Number(u(c.props?.Opacity ?? 1, C)), e.push(a);
						} else if (l?.__xamlComboBoxItem || d === "ComboBoxItem") {
							let r = c.props?.Content === void 0 ? void 0 : u(c.props.Content, C), i = c.props?.Content === void 0 ? ue(c) : [], a = c.props?.Tag, s = c.key ?? e.length;
							n.add(s);
							let l = ot.get(s);
							l || (l = Ve({
								Content: void 0,
								Tag: void 0,
								IsEnabled: !0,
								__contentNodes: []
							}), ot.set(s, l)), l.Content = r ?? o(c).trim(), l.__contentNodes = i, l.IsEnabled = t(u(c.props?.IsEnabled ?? !0, C)), l.Tag = typeof a == "string" && a.startsWith("{}") ? a.slice(2) : u(a, C), e.push(l);
						} else typeof l == "symbol" && s(c.children);
					}
				}
			};
			s(O.default?.());
			for (let e of ot.keys()) n.has(e) || ot.delete(e);
			return ct = st, st = a, e;
		}), ut = !0, A = y(() => {
			let e = u(S.ItemsSource, C);
			return Array.isArray(e) ? (ut = !1, e) : (ut = !0, lt.value);
		}), dt = y(() => Ze.value.Header[0] ?? u(S.Header, C)), ft = y(() => Ze.value.HeaderTemplate[0] ?? k(S.HeaderTemplate)), pt = y(() => Ze.value.Description[0] ?? u(S.Description, C)), mt = y(() => u(S.PlaceholderText, C)), j = y(() => t(u(S.IsEditable, C))), ht = E(void 0), gt = y(() => t(u(S.IsEnabled, C)));
		D(gt, () => {
			ht.value = void 0;
		});
		let M = y(() => ht.value ?? gt.value), _t = y(() => t(u(S.IsTabStop, C))), vt = y(() => {
			let e = u(S.IsDropDownOpen, C);
			return e === void 0 ? void 0 : t(e);
		}), yt = y(() => {
			let e = u(S.SelectedIndex, C);
			return e === void 0 || e === "" ? void 0 : Number(e);
		}), bt = y(() => u(S.SelectedItem, C)), xt = y(() => u(S.SelectedValue, C)), N = y(() => u(S.Text, C)), St = y(() => u(S.Width, C)), Ct = y(() => u(S.MinWidth, C)), wt = y(() => u(S.MaxWidth, C)), Tt = y(() => Number(u(S.MaxDropDownHeight, C)) || 504), Et = Oe, Dt = E(null), P = E(null), Ot = E(null), kt = Ae({
			name: "ComboBoxEditableText",
			inheritAttrs: !1,
			setup(e, { attrs: n, expose: r }) {
				let i = je(), a = E(null), o = {
					Focus: () => a.value?.Focus(),
					SelectAll: () => a.value?.SelectAll()
				};
				return Object.defineProperty(o, "Text", { get: () => a.value?.Text }), r(o), () => {
					let e = c([Me(_e, {
						...n,
						ref: a
					})], i)[0];
					for (let n of ["IsEnabled", "ShowDeleteButton"]) e.props?.[n] !== void 0 && (e.props[n] = t(u(e.props[n], i)));
					return e;
				};
			}
		}), F = E(null), At = E(null), jt = E(null), I = E([]), L = E(-1), R = E(-1), Mt = y(() => z.value && R.value >= 0 ? R.value : H.value), z = E(!!vt.value), Nt = y(() => z.value ? .5 : 1), B = E(!1), Pt = y(() => z.value || B.value), V = E(!1), Ft = E(!1), It = E(!1), Lt = E({ visibility: "hidden" }), Rt = E("Mouse"), zt = y(() => u(S.LightDismissOverlayMode, C) === "On"), H = E(-1), U = He(void 0), W = E(N.value === void 0 ? "" : String(N.value)), Bt = E(""), Vt = Ne(a, null) ?? Ne("winuiTheme", null), Ht = `win-combo-box-${Math.random().toString(36).slice(2)}`, G = ye(F, {
			Duration: () => B.value ? 167 : 250,
			Easing: "cubic-bezier(0,0,0,1)",
			Origin: "rect",
			StartRect: (e) => {
				let t = P.value?.getBoundingClientRect(), n = t ? t.top + t.height / 2 - e.top : e.height / 2, r = Math.abs(n - e.height / 2), i = B.value ? .15 : .5, a = e.height * (1 - i) / 2, o = e.height * i + Math.max(0, r - a) * 2;
				return {
					left: 0,
					right: e.width,
					top: n - o / 2,
					bottom: n + o / 2
				};
			},
			Direction: () => It.value ? "bottom" : "top",
			StripSize: 36
		}), Ut = y(() => G.isPlaying.value), Wt = [], Gt = () => {
			Wt.forEach((e) => e.cancel()), Wt = [];
		}, Kt = (e) => {
			if (Gt(), !G.isPlaying.value) return;
			e && F.value?.animate && Wt.push(F.value.animate([
				{ opacity: 1 },
				{
					opacity: 1,
					offset: 84 / 167
				},
				{ opacity: 0 }
			], {
				duration: 167,
				easing: "linear",
				fill: "none"
			}));
			let t = !j.value && P.value?.querySelector(".win-combo-content");
			t?.animate && Wt.push(t.animate(e ? [
				{ opacity: 0 },
				{
					opacity: 0,
					offset: 84 / 167
				},
				{ opacity: 1 }
			] : [{ opacity: 1 }, { opacity: .5 }], {
				duration: e ? 167 : 83,
				easing: "linear",
				fill: "none"
			}));
		};
		D(Ut, (e) => {
			!e && B.value && (Gt(), B.value = !1, Ft.value = !1);
		});
		let qt = null, Jt = null, Yt = 0, Xt = "Mouse", Zt = !1, Qt, $t = "", en = !1, tn = (e) => e === "" || e == null ? "" : typeof e == "string" && e.trim() !== "" && !Number.isNaN(Number(e.trim())) ? `${Number(e.trim())}px` : typeof e == "number" ? `${e}px` : e, nn = y(() => {
			let t = {};
			et.sync(Qe.value), St.value !== "" && (t.width = tn(St.value)), Ct.value !== "" && (t.minWidth = tn(Ct.value)), wt.value !== "" && (t.maxWidth = tn(wt.value));
			let r = String(u(S.Margin, C) ?? "").split(",").map((e) => tn(e.trim()));
			S.Margin !== "" && (t.margin = r.length === 4 ? `${r[1]} ${r[2]} ${r[3]} ${r[0]}` : r.length === 2 ? `${r[1]} ${r[0]}` : r[0]);
			for (let e of [
				"Height",
				"MinHeight",
				"MaxHeight"
			]) S[e] !== "" && (t[e[0].toLowerCase() + e.slice(1)] = tn(u(S[e], C)));
			t.alignSelf = e(u(S.VerticalAlignment, C), "vertical"), t.justifySelf = e(u(S.HorizontalAlignment, C), "horizontal"), u(S.HorizontalAlignment, C) === "Stretch" && St.value === "" && (t.width = "100%");
			for (let e of [
				"Background",
				"Foreground",
				"BorderBrush"
			]) S[e] && (t[`--ComboBox${e}`] = u(S[e], C));
			let i = u(S.BorderBrush, C);
			i != null && typeof i != "object" && !/gradient\(/i.test(String(i)) && (t["--ComboBoxBorderSide"] = String(i), t["--ComboBoxBorderTop"] = String(i), t["--ComboBoxBorderBottom"] = String(i)), Ye.value.value && typeof Ye.value.value != "object" && (t["--ComboBoxBackground"] = Ye.value.value), S.PlaceholderForeground && (t["--ComboBoxPlaceHolderForeground"] = u(S.PlaceholderForeground, C)), t["--ComboBoxBorderThemeThickness"] = n(u(S.BorderThickness, C)), S.Padding !== "" && (t["--ComboBoxPadding"] = n(u(S.Padding, C))), t["--ComboBoxCornerRadius"] = n(u(S.CornerRadius, C));
			for (let e of [
				"FontFamily",
				"FontSize",
				"FontWeight"
			]) S[e] !== "" && (t[e[0].toLowerCase() + e.slice(1)] = e === "FontSize" ? tn(u(S[e], C)) : u(S[e], C));
			return u(S.Visibility, C) === "Collapsed" && (t.display = "none"), [T.style, t];
		}), rn = y(() => S.Padding === "" ? "var(--combo-selection-padding)" : u(S.Padding, C)), an = y(() => ({
			margin: n(rn.value),
			justifySelf: e(u(S.HorizontalContentAlignment, C), "horizontal"),
			alignSelf: e(u(S.VerticalContentAlignment, C), "vertical")
		})), on = y(() => {
			let e = String(u(S.RequestedTheme, C)).toLowerCase(), t = e === "default" ? We(Vt) || Bt.value : e;
			return t === "light" || t === "dark" ? `theme-${t}` : "";
		}), sn = (e, t) => t ? t.split(".").reduce((e, t) => e?.[t], e) : e, K = (e) => {
			let t = u(S.DisplayMemberPath, C), n = t ? sn(e, t) : e;
			return n == null ? "" : typeof n == "object" ? n.Content === void 0 ? typeof n.toString == "function" && n.toString !== Object.prototype.toString ? String(n) : "" : typeof n.Content == "string" || typeof n.Content == "number" ? String(n.Content) : "" : String(n);
		}, cn = (e) => e?.IsEnabled !== !1, ln = (e) => {
			let t = Ze.value.itemContainerStyle[0] ?? k(S.ItemContainerStyle), r = {};
			for (let e of Pe(t) ? ue(t) : []) {
				let t = e.props?.Property, i = u(e.props?.Value, C);
				[
					"Width",
					"Height",
					"MinWidth",
					"MinHeight",
					"MaxWidth",
					"MaxHeight",
					"FontSize"
				].includes(t) && (r[t[0].toLowerCase() + t.slice(1)] = tn(i)), t === "Foreground" && (r.color = i), t === "Padding" && (r["--ComboBoxItemPadding"] = n(i));
			}
			return r;
		}, un = (e, t = {}) => {
			t.OriginalSource ??= Qn;
			let n = C?.vnode.props?.[`on${e}`];
			if (e === "Loaded" && n) {
				for (let e of Array.isArray(n) ? n : [n]) e(Qn, t);
				return;
			}
			Et(e, Qn, t), n || l(T[e], C)?.(Qn, t);
		}, dn = (e) => {
			let t = u(S.SelectedValuePath, C);
			return t ? sn(e, t) : e;
		}, fn = (e, t) => e && typeof e == "object" ? e.Key ?? e.Id ?? e.id ?? t : `${String(e)}-${t}`, pn = (e) => A.value.findIndex((t) => Object.is(t, e)), mn = (e) => A.value.findIndex((t) => Object.is(dn(t), e)), hn = y(() => U.value === void 0 ? mt.value || "" : K(U.value)), gn = y(() => W.value || hn.value), _n = (e, t, n = !0) => {
			H.value = e, U.value = t, Zt = j.value && t !== void 0 && e < 0, n && (W.value = t === void 0 ? "" : K(t));
		}, vn = () => [
			yt.value,
			bt.value,
			xt.value
		], yn, q = !1, bn = (e) => !yn || e.some((e, t) => !Object.is(e, yn[t])), xn = () => {
			let e, t, n = vn(), r = yn ? n.findIndex((e, t) => !Object.is(e, yn[t])) : -1, i = r >= 0 ? r : n.findIndex((e) => e !== void 0);
			if (yn = n, q = !1, i === 0) e = yt.value >= 0 && yt.value < A.value.length ? yt.value : -1, t = e >= 0 ? A.value[e] : void 0, q = yt.value >= 0 && e < 0;
			else if (i === 1) e = pn(bt.value), t = bt.value === null ? void 0 : bt.value, q = t !== void 0 && e < 0 && !j.value;
			else if (i === 2) e = mn(xt.value), t = e >= 0 ? A.value[e] : void 0, q = e < 0;
			else return;
			let a = U.value, o = e !== H.value || !Object.is(a, t);
			_n(e, t, N.value === void 0), o && !q && Sn(a, t, e);
		}, Sn = (e, t, n) => {
			q = !1, d(S.SelectedIndex, n, C), d(S.SelectedItem, t, C), d(S.SelectedValue, t === void 0 ? void 0 : dn(t), C), d(S.Text, W.value, C), yn = vn(), un("SelectionChanged", {
				AddedItems: t === void 0 ? [] : [t],
				RemovedItems: e === void 0 ? [] : [e],
				Handled: !1
			});
		}, J = (e) => {
			let t = e >= 0 && e < A.value.length ? e : -1, n = t >= 0 ? A.value[t] : void 0, r = U.value;
			q = !1, !(t === H.value && Object.is(n, r)) && (_n(t, n), Sn(r, n, t));
		}, Cn = (e) => {
			let t = e === null ? void 0 : e, n = pn(t);
			if (t !== void 0 && n < 0 && !j.value) return;
			let r = U.value;
			q = !1, !(n === H.value && Object.is(t, r)) && (_n(n, t), Sn(r, t, n));
		}, wn = (e) => {
			W.value = e == null ? "" : String(e), d(S.Text, W.value, C);
		}, Tn = (e) => J(mn(e)), En = () => {
			let e = Dt.value?.parentElement?.closest(".theme-light, .theme-dark, [data-theme=\"light\"], [data-theme=\"dark\"]");
			return e?.classList.contains("theme-dark") ? "dark" : e?.classList.contains("theme-light") ? "light" : e?.getAttribute("data-theme") || "";
		}, Dn = () => {
			Jt?.disconnect();
			let e = Dt.value?.parentElement?.closest(".theme-light, .theme-dark, [data-theme=\"light\"], [data-theme=\"dark\"]");
			Bt.value = En(), e && (Jt = new MutationObserver(() => {
				let e = En();
				e !== Bt.value && (Bt.value = e, Nn());
			}), Jt.observe(e, {
				attributes: !0,
				attributeFilter: ["class", "data-theme"]
			}));
		}, Y = (e) => {
			let t = I.value[e];
			if (!t) return 36;
			let n = window.getComputedStyle(t);
			return t.getBoundingClientRect().height + Number.parseFloat(n.marginTop || "0") + Number.parseFloat(n.marginBottom || "0");
		}, On = (e, t, n, r, i, a, o) => {
			let s = o, c = 0;
			if ((t < e || e < 0) && (e = Math.floor(t / 2)), t === 0) return {
				popupY: n,
				popupMaxHeight: r,
				offset: c
			};
			let l = Y(e);
			n + r >= a.Height && (n = a.Height - r);
			let u = n + r / 2 - l / 2 - i.Top, d = Math.max(u, 0), f = Math.max(n + r / 2 - s / 2, 0), p = d + l + i.Top + i.Bottom, m = Math.min(p, a.Height), h = Math.min(f + s, a.Height), g = e - 1, _ = e + 1, v = 1, ee = Math.min(7, t), te = Math.min(15, t);
			if (p > a.Height && (d = Math.max(d - p + a.Height, 0)), g >= 0) for (l = Y(g); g >= 0 && d - l >= f && v < ee;) d -= l, v++, g--, g >= 0 && (l = Y(g));
			if (_ < t) for (l = Y(_); _ < t && m + l < h && m - d < s && v < te;) m += l, v++, _++, _ < t && (l = Y(_));
			if (g >= 0 || _ < t) {
				let e = g >= 0, n = e ? g : _;
				for (l = Y(n); m - d + l <= s && (m + l < a.Height || d - l >= 0) && v < te;) e ? g-- : _++, d - l <= 0 ? m += l : d -= l, v++, (g >= 0 || _ < t) && (e = g >= 0, n = e ? g : _, l = Y(n));
			}
			c = g + 1;
			let ne = d;
			return s = m - d, {
				popupY: ne,
				popupMaxHeight: s,
				offset: c
			};
		}, kn = (e, t, n, r, i) => {
			if (e === 0) return {
				popupY: t,
				popupMaxHeight: n,
				offset: 0,
				openedUp: !1
			};
			let a = t + n, o = Math.max(a, 0), s = o + r.Top + r.Bottom, c = 0, l = 0, u = Math.min(15, e);
			for (; c < e && l < u;) s += Y(c), l++, c++;
			let d = o, f = s - o, p = !1;
			return d + f > i.Height && t - f >= 0 && (d = Math.max(t - f, 0), p = !0), {
				popupY: d,
				popupMaxHeight: f,
				offset: 0,
				openedUp: p
			};
		}, An = (e, t, n, r, i, a, o) => {
			let s = o;
			(t < e || e < 0) && (e = Math.floor(t / 2));
			let c = Y(e), l = Math.min((s - r) / 2, n), u = Math.min(s - l - r, Math.max(0, a.Height - n - c)), d = Math.floor(Math.min(7, (t - 1) / 2)), f = Math.floor(Math.min(7, (t - 1) / 2)), p = 0, m = 0, h = e - 1 >= 0 ? e - 1 : t - 1;
			h >= 0 && (m = Y(h));
			let g = Math.max(Math.min(n, a.Height - c), 0);
			for (; c + m <= s && p < d && l - m > 0;) p++, c += m, l -= m, g -= m, h = h - 1 >= 0 ? h - 1 : t - 1, h >= 0 && (m = Y(h));
			let _ = e - p, v = 0;
			for (m = 0, h = e + 1 < t ? e + 1 : 0, h < t && (m = Y(h)); c + m <= s && v < f && u - m > 0;) v++, c += m, u -= m, h = h + 1 < t ? h + 1 : 0, h < t && (m = Y(h));
			for (l >= m / 2 && (c += m / 2, g -= m / 2, _ -= .5), s = Math.min(s, c); _ < 0;) _ += t + 1;
			for (; _ >= t + 1;) _ -= t + 1;
			return {
				popupY: g,
				popupMaxHeight: s,
				offset: _,
				childHeight: i
			};
		}, jn = (e, t, n, r = b) => e <= 0 ? !1 : e > 15 ? !0 : (t = Math.min(t, n.Height), A.value.reduce((e, t, n) => e + Y(n), r.Top + r.Bottom) > t), Mn = async () => {
			if (!z.value || !P.value || !F.value) return;
			G.cancel(), await w();
			let e = P.value.getBoundingClientRect(), t = {
				Width: window.innerWidth,
				Height: window.innerHeight
			};
			if (t.Width === 0 || t.Height === 0 || e.width === 0 || e.height === 0) return;
			let n = Math.min(Tt.value, t.Height), r = Rt.value === "Touch", i = b, a = Math.max(r ? 240 : 80, e.width);
			Ft.value = !1, Lt.value = {
				top: "0px",
				left: "0px",
				minWidth: `${a}px`,
				maxWidth: `${t.Width}px`,
				maxHeight: `${n}px`,
				visibility: "hidden"
			}, await w();
			let o = Math.max(e.width, Math.min(F.value.getBoundingClientRect().width, t.Width)), s = window.getComputedStyle(P.value).direction === "rtl" ? e.right - o : e.left, c = Math.round(Math.max(0, Math.min(s, t.Width - o))), l = jn(A.value.length, n, t, i), u = j.value ? kn(A.value.length, e.top, e.height, i, t) : r && l ? An(H.value, A.value.length, e.top, e.height, F.value.getBoundingClientRect().height, t, n) : On(H.value, A.value.length, e.top, e.height, i, t, n), d = u.popupY, f = Math.max(e.height, Math.min(u.popupMaxHeight, n));
			d + f > t.Height && (d = Math.max(d - (d + f - t.Height), 0));
			let p = Math.round(d);
			if (It.value = u.openedUp ?? p < e.top, Lt.value = {
				top: `${p}px`,
				left: `${c}px`,
				width: `${Math.ceil(o)}px`,
				minWidth: `${a}px`,
				maxWidth: `${t.Width}px`,
				height: `${Math.ceil(f + 2)}px`,
				maxHeight: `${Math.ceil(f + 2)}px`,
				visibility: "visible"
			}, await w(), jt.value) {
				let e = Math.floor(u.offset), t = u.offset - e, n = Array.from({ length: e }, (e, t) => Y(t)).reduce((e, t) => e + t, 0) + (t > 0 ? Y(e) * t : 0);
				At.value?.ChangeView(null, n, null);
			}
			Ft.value = !0, A.value.length > 0 && (G.play(), Kt(!1));
		}, Nn = () => {
			!z.value || Yt || (Yt = window.requestAnimationFrame(() => {
				Yt = 0, Mn();
			}));
		}, Pn = (e) => {
			F.value?.contains(e.target) || Nn();
		}, Fn = async (e) => {
			e === z.value || e && !M.value || (z.value = e, d(S.IsDropDownOpen, e, C), e ? (G.cancel(), Gt(), B.value = !1, Rt.value = Xt, Bt.value = En(), Ft.value = !1, R.value = H.value, or = U.value, un("DropDownOpened"), await w(), await Mn()) : (G.cancel(), Ft.value && F.value ? (B.value = !0, G.playReverse(), Kt(!0), G.isPlaying.value || (B.value = !1, Ft.value = !1)) : Ft.value = !1, R.value = -1, L.value = -1, un("DropDownClosed")));
		}, In = () => Fn(!0), X = () => Fn(!1), Ln = () => Fn(!z.value), Z = () => {
			if (!j.value) {
				P.value?.focus();
				return;
			}
			V.value ? Ot.value?.Focus() : P.value?.querySelector(".win-combo-edit-display")?.focus();
		}, Rn = (e = !1) => {
			Ot.value?.Focus(), e && Ot.value?.SelectAll();
		}, zn = () => {
			M.value && (V.value || (Qt = U.value, $t = W.value), V.value = !0, w(() => Rn(!0)));
		}, Bn = (e = !1) => {
			V.value && (V.value = !1, e && w(Z));
		}, Vn = () => {
			if (z.value) {
				$n();
				return;
			}
			zn(), In();
		}, Hn = (e) => {
			!M.value || !cn(A.value[e]) || (L.value = -1, J(e), V.value = !1, X(), w(Z));
		}, Un = (e) => {
			let t = e.clientX, n = e.clientY;
			for (let e = 0; e < I.value.length; e += 1) {
				let r = I.value[e];
				if (!r) continue;
				let i = r.getBoundingClientRect();
				if (t >= i.left && t <= i.right && n >= i.top && n <= i.bottom) return e;
			}
			return -1;
		}, Wn = (e) => {
			if (e.pointerType === "touch") {
				L.value = -1;
				return;
			}
			L.value = Un(e);
		}, Gn = () => {
			L.value = -1;
		}, Kn = (e) => {
			e.pointerType === "touch" && (L.value = -1);
		}, qn = (e) => {
			if (!z.value || e.pointerType === "touch") {
				e.pointerType === "touch" && (L.value = -1);
				return;
			}
			let t = e.target;
			L.value = F.value?.contains(t) || t instanceof Element && t.closest(".win-combo-flyout-hit-overlay") ? Un(e) : -1;
		}, Jn = (e) => {
			if (e.target instanceof Element && e.target.closest(".win-combo-item")) return;
			let t = Un(e);
			t >= 0 && Hn(t);
		}, Yn = () => {
			if (wn(Ot.value?.Text ?? W.value), z.value && t(u(S.IsTextSearchEnabled, C))) {
				let e = W.value.toLocaleLowerCase(), t = A.value.findIndex((t) => cn(t) && K(t).toLocaleLowerCase().startsWith(e));
				R.value = e ? t : -1, t >= 0 && u(S.SelectionChangedTrigger, C) === "Always" && J(t);
			}
		}, Xn = () => {
			let e = W.value, t = A.value.findIndex((t) => K(t) === e);
			if (t >= 0) return t !== H.value && J(t), Zt = !1, !0;
			if (!e.trim()) return U.value !== void 0 && Cn(void 0), !0;
			if (Zt && K(U.value) === e) return !0;
			let n = {
				Text: e,
				Handled: !1
			};
			en = !0;
			try {
				un("TextSubmitted", n);
			} finally {
				en = !1;
			}
			return n.Handled || Cn(e), !0;
		}, Zn = () => {
			w(() => {
				if (!V.value || en) return;
				let e = document.activeElement;
				P.value?.contains(e) || F.value?.contains(e) || (Xn(), Bn());
			});
		}, Qn = {};
		Object.defineProperties(Qn, {
			Element: { get: () => Dt.value },
			Name: { get: () => T["data-xaml-ref"] ?? T["x:Name"] ?? T.Name ?? "" },
			IsEnabled: {
				get: () => M.value,
				set: (e) => {
					ht.value = t(e), d(S.IsEnabled, t(e), C);
				}
			},
			Text: {
				get: () => W.value,
				set: wn
			},
			SelectedIndex: {
				get: () => H.value,
				set: (e) => J(Number(e))
			},
			SelectedItem: {
				get: () => U.value,
				set: Cn
			},
			SelectedValue: {
				get: () => U.value === void 0 ? void 0 : dn(U.value),
				set: Tn
			},
			IsDropDownOpen: {
				get: () => z.value,
				set: (e) => Fn(t(e))
			},
			Items: { get: () => A.value },
			ItemsSource: { get: () => A.value },
			SelectionBoxItem: { get: () => U.value },
			SelectionBoxItemTemplate: { get: () => k(S.ItemTemplate) },
			Focus: { value: () => (Z(), M.value) }
		});
		let $n = () => {
			Xn(), X(), Bn(!0);
		}, er = (e = !0) => {
			V.value && (Cn(Qt), wn($t)), X(), Bn(e);
		}, tr = (e) => {
			if (A.value.length === 0) return;
			let t = Math.min(A.value.length - 1, Math.max(0, H.value < 0 ? e > 0 ? 0 : A.value.length - 1 : H.value + e));
			for (; t >= 0 && t < A.value.length && !cn(A.value[t]);) t += e;
			t >= 0 && t < A.value.length && J(t);
		}, Q = (e, t = 1) => {
			if (A.value.length === 0) return;
			let n = Math.min(A.value.length - 1, Math.max(0, e));
			for (; n >= 0 && n < A.value.length && !cn(A.value[n]);) n += t;
			n < 0 || n >= A.value.length || (R.value = n, u(S.SelectionChangedTrigger, C) === "Always" && J(n), I.value[n]?.focus(), I.value[n]?.scrollIntoView({ block: "nearest" }));
		}, nr = (e) => {
			!M.value || e.defaultPrevented || cr(e) || (e.key === "ArrowDown" && !e.altKey && !z.value ? (e.preventDefault(), tr(1)) : e.key === "ArrowUp" && !z.value ? (e.preventDefault(), tr(-1)) : e.key === "Home" || e.key === "End" ? (e.preventDefault(), J(e.key === "Home" ? 0 : A.value.length - 1)) : (e.key === "ArrowDown" || e.key === "F4" || e.key === "Enter" || e.key === " ") && (e.preventDefault(), In(), w(() => Q(H.value < 0 ? 0 : H.value))));
		}, rr = (e) => {
			!M.value || e.defaultPrevented || (e.key === "Enter" || e.key === "F2" || e.key === " " ? (e.preventDefault(), zn()) : e.key === "F4" || e.altKey && e.key === "ArrowDown" ? (e.preventDefault(), In(), w(() => Q(H.value < 0 ? 0 : H.value))) : e.key === "ArrowDown" || e.key === "ArrowUp" ? (e.preventDefault(), zn(), In()) : e.key.length === 1 && !e.ctrlKey && !e.altKey && !e.metaKey && (e.preventDefault(), zn(), wn(e.key)));
		}, ir = (e) => {
			if (!(e.defaultPrevented || e.isComposing || !M.value)) if (e.key === "Enter") e.preventDefault(), $n();
			else if (e.key === "Escape") e.preventDefault(), er();
			else if (e.key === "F4" || e.altKey && (e.key === "ArrowDown" || e.key === "ArrowUp")) e.preventDefault(), z.value ? $n() : In();
			else if ((e.key === "ArrowDown" || e.key === "ArrowUp") && !z.value) e.preventDefault(), In();
			else if ((e.key === "ArrowDown" || e.key === "ArrowUp") && z.value) {
				e.preventDefault();
				let t = Math.max(0, Math.min(A.value.length - 1, (R.value >= 0 ? R.value : H.value) + (e.key === "ArrowDown" ? 1 : -1)));
				R.value = t, t >= 0 && cn(A.value[t]) && (wn(K(A.value[t])), u(S.SelectionChangedTrigger, C) === "Always" && J(t), I.value[t]?.scrollIntoView({ block: "nearest" }));
			} else e.key === "Tab" && (Xn(), X(), Bn());
		}, ar = (e) => {
			let t = I.value.indexOf(document.activeElement);
			if (!cr(e)) if (e.altKey && (e.key === "ArrowDown" || e.key === "ArrowUp")) e.preventDefault(), X(), w(Z);
			else if (e.key === "Escape") e.preventDefault(), j.value ? er() : (u(S.SelectionChangedTrigger, C) === "Always" && Cn(or), X()), w(Z);
			else if (e.key === "ArrowDown") e.preventDefault(), Q(t < 0 ? 0 : t + 1);
			else if (e.key === "ArrowUp") e.preventDefault(), Q(t < 0 ? A.value.length - 1 : t - 1, -1);
			else if (e.key === "Home") e.preventDefault(), Q(0);
			else if (e.key === "End") e.preventDefault(), Q(A.value.length - 1, -1);
			else if (e.key === "PageDown" || e.key === "PageUp") {
				e.preventDefault();
				let n = e.key === "PageDown" ? 1 : -1, r = Math.max(1, Math.floor((F.value?.clientHeight ?? 252) / 36));
				Q(Math.max(0, t) + n * r, n);
			} else e.key === "Enter" || e.key === " " ? (e.preventDefault(), t >= 0 && Hn(t)) : e.key === "F4" || e.altKey && (e.key === "ArrowDown" || e.key === "ArrowUp") ? (e.preventDefault(), X(), w(Z)) : e.key === "Tab" ? (R.value >= 0 && J(R.value), Z(), X()) : (e.key === "ArrowLeft" || e.key === "ArrowRight") && e.preventDefault();
		}, or, $ = "", sr = 0, cr = (e) => {
			if (!t(u(S.IsTextSearchEnabled, C)) || e.isComposing || e.ctrlKey || e.altKey || e.metaKey || e.key.length !== 1 || e.key === " " && !$) return !1;
			let n = Date.now();
			$ = n - sr > 1e3 ? e.key : $ + e.key, sr = n;
			let r = A.value.findIndex((e) => cn(e) && K(e).toLocaleLowerCase().startsWith($.toLocaleLowerCase()));
			if (r < 0 && [...$].every((t) => t.toLocaleLowerCase() === e.key.toLocaleLowerCase())) {
				$ = e.key;
				let t = z.value ? R.value : H.value;
				for (let e = 1; e <= A.value.length; e += 1) {
					let n = (Math.max(-1, t) + e) % A.value.length;
					if (cn(A.value[n]) && K(A.value[n]).toLocaleLowerCase().startsWith($.toLocaleLowerCase())) {
						r = n;
						break;
					}
				}
			}
			return r >= 0 && (z.value ? Q(r) : J(r)), e.preventDefault(), !0;
		}, lr = (e) => {
			!M.value || z.value || document.activeElement !== P.value || e.deltaY === 0 || (e.preventDefault(), tr(e.deltaY > 0 ? 1 : -1));
		}, ur = (e, t) => {
			I.value[t] = e;
		}, dr = (e) => {
			Xt = e.pointerType === "touch" ? "Touch" : "Mouse";
		}, fr = (e) => {
			Xt = "Keyboard", V.value && e.target instanceof Element && e.target.closest(".win-textbox") ? ir(e) : e.key === "Escape" && (z.value || V.value) && (e.preventDefault(), j.value ? er() : (u(S.SelectionChangedTrigger, C) === "Always" && Cn(or), X(), w(Z)));
		}, pr = (e) => {
			let t = Dt.value?.contains(e.target), n = F.value?.contains(e.target) || z.value && e.target instanceof Element && e.target.closest(".win-combo-flyout-hit-overlay");
			V.value && !t && !n && !en && (Xn(), Bn()), !(!z.value || t || n) && X();
		};
		D(vn, (e) => {
			bn(e) && xn();
		}, { immediate: !0 }), D(() => A.value.slice(), (e, t) => {
			if ((bn(vn()) || q) && xn(), q) {
				z.value && w(Nn);
				return;
			}
			let n = U.value;
			if (n !== void 0) {
				let r = e.findIndex((e) => Object.is(e, n));
				if (r < 0) {
					let r = t?.findIndex((e) => Object.is(e, n)), i = ut ? [...ct].find(([, e]) => e === r)?.[0] : void 0, a = i === void 0 ? void 0 : st.get(i);
					a !== void 0 && e[a] !== void 0 ? (_n(a, e[a], N.value === void 0), Sn(n, e[a], a)) : Zt || (_n(-1, void 0, N.value === void 0), Sn(n, void 0, -1));
				} else {
					let e = r !== H.value;
					_n(r, n, N.value === void 0), e && d(S.SelectedIndex, r, C);
				}
			}
			z.value && w(Nn);
		}), D(N, (e) => {
			e !== void 0 && (W.value = String(e));
		}), D(vt, (e) => {
			e !== void 0 && Fn(e);
		}), D(M, (e) => {
			e || (Bn(), X());
		}), D(j, (e) => {
			e || Bn();
		}), Re(() => {
			Ie.Attach(Dt.value), qt = new ResizeObserver(Nn), P.value && qt.observe(P.value), Dn(), window.addEventListener("resize", Nn), window.addEventListener("scroll", Pn, !0), document.addEventListener("pointerdown", pr), document.addEventListener("pointermove", qn, !0), w(() => {
				un("Loaded");
			});
		}), D(M, Ie.Refresh, { flush: "post" }), Le(() => {
			qt?.disconnect(), Jt?.disconnect(), G.cancel(), Gt(), window.removeEventListener("resize", Nn), window.removeEventListener("scroll", Pn, !0), document.removeEventListener("pointerdown", pr), document.removeEventListener("pointermove", qn, !0), Yt && window.cancelAnimationFrame(Yt);
		}), ze(p, {
			...Ne(p, {}),
			props: S,
			ComboBoxScrollSettings: Ue,
			SelectionBoxPadding: rn,
			SelectionBoxOpacity: Nt,
			currentText: W,
			resolvedIsEnabled: M,
			resolvedPlaceholderText: mt,
			resolvedHeader: dt,
			resolvedHeaderTemplate: ft,
			resolvedDescription: pt,
			onEditableTextChanged: Yn,
			onEditableLostFocus: Zn
		}), De(Qn);
		let mr = {
			AnimatedChevronDownSmallVisualSource: ke,
			ComboBoxPopupMaxNumberOfItems: 15,
			ComboBoxPopupMaxNumberOfItemsThatCanBeShownOnOneSide: 7,
			ComboBoxDropdownContentMargin: b,
			DefaultComboBoxItemHeight: 36,
			t: x,
			props: S,
			instance: C,
			dropDownBackgroundStyle: Fe,
			AnimatedGlyphInput: Ie,
			attrs: T,
			rootAttrs: Be,
			ComboBoxScrollSettings: Ue,
			slots: O,
			localPrimitiveResources: qe,
			defaultShadowEnabled: Je,
			backgroundBrush: Ye,
			inheritedResources: Xe,
			propertyNodes: Ze,
			resourceNodes: Qe,
			resources: $e,
			brushResources: et,
			templateValue: k,
			itemTemplateNodes: tt,
			hasItemTemplate: nt,
			ItemRenderer: rt,
			InlineItemRenderer: it,
			SelectionBoxRenderer: at,
			inlineItemContainers: ot,
			get inlineStringKeys() {
				return st;
			},
			set inlineStringKeys(e) {
				st = e;
			},
			get previousInlineStringKeys() {
				return ct;
			},
			set previousInlineStringKeys(e) {
				ct = e;
			},
			inlineItems: lt,
			get isUsingInlineItems() {
				return ut;
			},
			set isUsingInlineItems(e) {
				ut = e;
			},
			resolvedItemsSource: A,
			resolvedHeader: dt,
			resolvedHeaderTemplate: ft,
			resolvedDescription: pt,
			resolvedPlaceholderText: mt,
			resolvedIsEditable: j,
			localIsEnabled: ht,
			sourceIsEnabled: gt,
			resolvedIsEnabled: M,
			resolvedIsTabStop: _t,
			resolvedIsDropDownOpen: vt,
			resolvedSelectedIndex: yt,
			resolvedSelectedItem: bt,
			resolvedSelectedValue: xt,
			resolvedText: N,
			resolvedWidth: St,
			resolvedMinWidth: Ct,
			resolvedMaxWidth: wt,
			resolvedMaxDropDownHeight: Tt,
			emit: Et,
			comboRef: Dt,
			backgroundRef: P,
			inputRef: Ot,
			TextBox: kt,
			flyoutRef: F,
			scrollViewerRef: At,
			itemsPresenterRef: jt,
			itemRefs: I,
			hoveredIndex: L,
			focusedIndex: R,
			visualSelectedIndex: Mt,
			isOpen: z,
			SelectionBoxOpacity: Nt,
			isClosing: B,
			popupVisible: Pt,
			isEditing: V,
			flyoutReady: Ft,
			openedUp: It,
			flyoutStyle: Lt,
			inputDeviceTypeUsedToOpen: Rt,
			isOverlayVisible: zt,
			currentSelectedIndex: H,
			currentSelectedItem: U,
			currentText: W,
			anchorTheme: Bt,
			inheritedTheme: Vt,
			listBoxId: Ht,
			flyoutAnimation: G,
			isFlyoutAnimating: Ut,
			get opacityAnimations() {
				return Wt;
			},
			set opacityAnimations(e) {
				Wt = e;
			},
			cancelOpacityAnimations: Gt,
			playOpacityAnimations: Kt,
			get resizeObserver() {
				return qt;
			},
			set resizeObserver(e) {
				qt = e;
			},
			get themeObserver() {
				return Jt;
			},
			set themeObserver(e) {
				Jt = e;
			},
			get positionFrame() {
				return Yt;
			},
			set positionFrame(e) {
				Yt = e;
			},
			get lastInputDeviceType() {
				return Xt;
			},
			set lastInputDeviceType(e) {
				Xt = e;
			},
			get isCustomSelection() {
				return Zt;
			},
			set isCustomSelection(e) {
				Zt = e;
			},
			get editingRestoreItem() {
				return Qt;
			},
			set editingRestoreItem(e) {
				Qt = e;
			},
			get editingRestoreText() {
				return $t;
			},
			set editingRestoreText(e) {
				$t = e;
			},
			get submittingText() {
				return en;
			},
			set submittingText(e) {
				en = e;
			},
			cssLength: tn,
			rootStyle: nn,
			SelectionBoxPadding: rn,
			selectionBoxStyle: an,
			themeClass: on,
			GetPathValue: sn,
			GetItemLabel: K,
			IsItemEnabled: cn,
			itemContainerStyle: ln,
			raiseEvent: un,
			GetItemValue: dn,
			getItemKey: fn,
			FindItemIndex: pn,
			FindValueIndex: mn,
			selectedLabel: hn,
			editableDisplayLabel: gn,
			SetCurrentSelection: _n,
			GetSelectionProperties: vn,
			get lastSelectionProperties() {
				return yn;
			},
			set lastSelectionProperties(e) {
				yn = e;
			},
			get pendingSelectionFromProperties() {
				return q;
			},
			set pendingSelectionFromProperties(e) {
				q = e;
			},
			HaveSelectionPropertiesChanged: bn,
			SyncSelectionFromProperties: xn,
			RaiseSelectionChanged: Sn,
			SetSelectedIndex: J,
			SetSelectedItem: Cn,
			SetText: wn,
			SetSelectedValue: Tn,
			ResolveAnchorTheme: En,
			ObserveAnchorTheme: Dn,
			GetItemLayoutHeight: Y,
			GetNonPannablePopupLayout: On,
			GetEditableComboBoxPopupLayout: kn,
			GetPannablePopupLayout: An,
			UpdateIsPopupPannable: jn,
			positionFlyout: Mn,
			schedulePositionFlyout: Nn,
			onWindowScroll: Pn,
			setOpen: Fn,
			open: In,
			close: X,
			toggle: Ln,
			focusCombo: Z,
			focusEditableText: Rn,
			beginEditing: zn,
			endEditing: Bn,
			toggleEditableDropDown: Vn,
			select: Hn,
			itemIndexAtPoint: Un,
			onFlyoutPointerMove: Wn,
			onFlyoutPointerLeave: Gn,
			onFlyoutPointerDown: Kn,
			onDocumentPointerMove: qn,
			onFlyoutClick: Jn,
			onEditableTextChanged: Yn,
			commitEditableText: Xn,
			onEditableLostFocus: Zn,
			controlSender: Qn,
			SubmitText: $n,
			CancelEditableText: er,
			MoveSelection: tr,
			FocusItem: Q,
			onButtonKeyDown: nr,
			onEditableDisplayKeyDown: rr,
			onEditableKeyDown: ir,
			onFlyoutKeyDown: ar,
			get openingSelectedItem() {
				return or;
			},
			set openingSelectedItem(e) {
				or = e;
			},
			get searchText() {
				return $;
			},
			set searchText(e) {
				$ = e;
			},
			get searchTimestamp() {
				return sr;
			},
			set searchTimestamp(e) {
				sr = e;
			},
			ProcessTextSearch: cr,
			onPointerWheelChanged: lr,
			setItemRef: ur,
			onPointerDown: dr,
			onInputKeyDown: fr,
			onDocumentPointerDown: pr,
			get CollectionItemTemplate() {
				return oe;
			},
			get CollectionItems() {
				return se;
			},
			get CollectionResources() {
				return ce;
			},
			get CollectionItemContainerStyle() {
				return ae;
			},
			get ComboBoxHeader() {
				return Se;
			},
			get ComboBoxHeaderTemplate() {
				return Ce;
			},
			get ComboBoxDescription() {
				return xe;
			},
			computed: y,
			defineComponent: Ae,
			Fragment: Ee,
			getCurrentInstance: je,
			h: Me,
			inject: Ne,
			isVNode: Pe,
			nextTick: w,
			onBeforeUnmount: Le,
			onMounted: Re,
			provide: ze,
			ref: E,
			shallowReactive: Ve,
			shallowRef: He,
			unref: We,
			useAttrs: Ge,
			useSlots: Ke,
			watch: D,
			get useI18n() {
				return re;
			},
			ScrollViewer: me,
			get getCollectionProperty() {
				return le;
			},
			get getVNodeChildren() {
				return ue;
			},
			xamlResourceDictionaryKey: ie,
			get normalizeXamlNodes() {
				return c;
			},
			get resolveXamlHandler() {
				return l;
			},
			get resolveXamlValue() {
				return u;
			},
			get updateXamlBinding() {
				return d;
			},
			get xamlItemContextKey() {
				return f;
			},
			get xamlScopeKey() {
				return p;
			},
			get xamlTemplateComponent() {
				return m;
			},
			get scrollViewerTemplateBindings() {
				return he;
			},
			TextBlock: de,
			TextBoxControl: _e,
			ContentPresenter: ge,
			get boolValue() {
				return t;
			},
			get xamlThickness() {
				return n;
			},
			get alignment() {
				return e;
			},
			get getComboBoxProperty() {
				return we;
			},
			get isComboBoxProperty() {
				return Te;
			},
			get collectXamlResources() {
				return h;
			},
			get useXamlBrushResources() {
				return g;
			},
			get useBrushProperty() {
				return v;
			},
			get isBrushProperty() {
				return _;
			},
			get useFlyoutAnimation() {
				return ye;
			},
			AnimatedIcon: pe,
			get FontIconSource() {
				return be;
			},
			get animatedIconVisualSourceComponents() {
				return fe;
			},
			get useAnimatedIconInput() {
				return ve;
			},
			get colorString() {
				return r;
			},
			get createSolidColorBrush() {
				return i;
			},
			get xamlThemeKey() {
				return a;
			},
			get useAcrylicBrushStyle() {
				return s;
			},
			get vAcrylicBrush() {
				return ee;
			},
			get vThemeShadow() {
				return te;
			},
			get primitiveResourceScope() {
				return o;
			}
		};
		return Object.defineProperty(mr, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), mr;
	}
}), Xe = ["aria-disabled"], Ze = {
	key: 0,
	class: "win-combo-background",
	"aria-hidden": "true"
}, Qe = [
	"aria-expanded",
	"aria-label",
	"disabled",
	"tabindex"
], $e = ["aria-label", "disabled"], et = [
	"aria-expanded",
	"aria-label",
	"disabled",
	"tabindex"
], k = {
	ref: "itemsPresenterRef",
	class: "win-combo-items-presenter"
}, tt = [
	"aria-selected",
	"disabled",
	"tabindex",
	"onClick"
], nt = { class: "win-combo-item-layout" }, rt = {
	key: 0,
	class: "win-combo-item-pill",
	width: "3",
	height: "16",
	viewBox: "0 0 3 16",
	"aria-hidden": "true",
	focusable: "false"
};
function it(e, t, n, r, i, a) {
	return T(), b("div", C({ ref: "comboRef" }, r.rootAttrs, {
		class: ["win-combo-box win-theme-scope", [
			r.attrs.class,
			r.themeClass,
			{
				"is-disabled": !r.resolvedIsEnabled,
				"is-drop-down-open": r.isOpen,
				"is-editable": r.resolvedIsEditable
			}
		]],
		style: r.rootStyle,
		"aria-disabled": !r.resolvedIsEnabled,
		onKeydownCapture: r.onInputKeyDown,
		onPointerdownCapture: r.onPointerDown,
		onPointerenter: t[2] ||= (...e) => r.AnimatedGlyphInput.PointerEntered && r.AnimatedGlyphInput.PointerEntered(...e),
		onPointerleave: t[3] ||= (...e) => r.AnimatedGlyphInput.PointerExited && r.AnimatedGlyphInput.PointerExited(...e),
		onPointerdown: t[4] ||= (...e) => r.AnimatedGlyphInput.PointerPressed && r.AnimatedGlyphInput.PointerPressed(...e),
		onPointerup: t[5] ||= (...e) => r.AnimatedGlyphInput.PointerReleased && r.AnimatedGlyphInput.PointerReleased(...e),
		onPointercancel: t[6] ||= (...e) => r.AnimatedGlyphInput.PointerExited && r.AnimatedGlyphInput.PointerExited(...e),
		onLostpointercapture: t[7] ||= (...e) => r.AnimatedGlyphInput.PointerReleased && r.AnimatedGlyphInput.PointerReleased(...e),
		onKeydown: t[8] ||= (...e) => r.AnimatedGlyphInput.KeyDown && r.AnimatedGlyphInput.KeyDown(...e),
		onKeyup: t[9] ||= (...e) => r.AnimatedGlyphInput.KeyUp && r.AnimatedGlyphInput.KeyUp(...e),
		onFocusout: t[10] ||= (...e) => r.AnimatedGlyphInput.LostFocus && r.AnimatedGlyphInput.LostFocus(...e)
	}), [
		r.resolvedHeader ? (T(), Oe(r.ContentPresenter, {
			key: 0,
			"x:Name": "HeaderContentPresenter",
			class: "win-combo-header",
			Content: "{x:Bind resolvedHeader, Mode=OneWay}",
			ContentTemplate: "{x:Bind resolvedHeaderTemplate, Mode=OneWay}",
			Margin: "{ThemeResource ComboBoxTopHeaderMargin}",
			Foreground: "{ThemeResource ComboBoxHeaderForeground}",
			VerticalAlignment: "Top"
		})) : ke("", !0),
		r.resolvedIsEditable ? (T(), b("div", {
			key: 1,
			ref: "backgroundRef",
			class: Fe(["win-combo-editable", { "is-editing": r.isEditing }])
		}, [
			r.isEditing ? (T(), b("span", Ze)) : ke("", !0),
			r.isEditing ? (T(), Oe(r.TextBox, {
				key: 2,
				ref: "inputRef",
				class: "win-combo-textbox",
				role: "combobox",
				"aria-controls": r.listBoxId,
				"aria-expanded": r.isOpen,
				"aria-label": r.resolvedHeader || r.resolvedPlaceholderText,
				"x:Name": "EditableText",
				IsEnabled: "{x:Bind resolvedIsEnabled, Mode=OneWay}",
				Padding: "{ThemeResource ComboBoxEditableTextPadding}",
				PlaceholderText: "{x:Bind resolvedPlaceholderText, Mode=OneWay}",
				ShowDeleteButton: "False",
				Text: "{x:Bind currentText, Mode=TwoWay}",
				LostFocus: "onEditableLostFocus",
				TextChanged: "onEditableTextChanged"
			}, null, 8, ["aria-expanded", "aria-label"])) : (T(), b("button", {
				key: 1,
				class: "win-combo-btn win-combo-edit-display",
				type: "button",
				role: "combobox",
				"aria-controls": r.listBoxId,
				"aria-expanded": r.isOpen,
				"aria-label": r.resolvedHeader || r.resolvedPlaceholderText,
				disabled: !r.resolvedIsEnabled,
				tabindex: r.resolvedIsTabStop ? void 0 : -1,
				onClick: r.beginEditing,
				onKeydown: r.onEditableDisplayKeyDown
			}, [t[11] ||= x("span", {
				class: "win-combo-background",
				"aria-hidden": "true"
			}, null, -1), x("span", {
				class: Fe(["win-combo-content", { "is-placeholder": !r.currentText && r.currentSelectedItem === void 0 }]),
				style: Ie(r.selectionBoxStyle)
			}, Ue(r.editableDisplayLabel), 7)], 40, Qe)),
			x("button", {
				class: "win-combo-drop-down-button",
				type: "button",
				tabindex: "-1",
				"aria-label": r.t("text.select"),
				disabled: !r.resolvedIsEnabled,
				onClick: r.toggleEditableDropDown,
				onPointerdown: t[0] ||= Je(() => {}, ["prevent"])
			}, null, 40, $e),
			S(r.AnimatedIcon, {
				class: "win-combo-chevron",
				"x:Name": "DropDownGlyph",
				Width: "12",
				Height: "12",
				Margin: "0,0,14,0",
				HorizontalAlignment: "Right",
				VerticalAlignment: "Center",
				Foreground: "{ThemeResource ComboBoxDropDownGlyphForeground}",
				IsHitTestVisible: "False",
				"AutomationProperties.AccessibilityView": "Raw"
			}, {
				default: O(() => [S(r.AnimatedIcon.Source, null, {
					default: O(() => [S(r.AnimatedChevronDownSmallVisualSource)]),
					_: 1
				}), S(r.AnimatedIcon.FallbackIconSource, null, {
					default: O(() => [S(r.FontIconSource, {
						Foreground: "{ThemeResource ComboBoxDropDownGlyphForeground}",
						FontFamily: "{ThemeResource SymbolThemeFontFamily}",
						FontSize: "12",
						Glyph: ""
					})]),
					_: 1
				})]),
				_: 1
			})
		], 2)) : (T(), b("button", {
			key: 2,
			ref: "backgroundRef",
			class: "win-combo-btn",
			type: "button",
			role: "combobox",
			"aria-controls": r.listBoxId,
			"aria-expanded": r.isOpen,
			"aria-label": r.resolvedHeader || r.resolvedPlaceholderText,
			disabled: !r.resolvedIsEnabled,
			tabindex: r.resolvedIsTabStop ? void 0 : -1,
			onClick: r.toggle,
			onKeydown: r.onButtonKeyDown,
			onWheel: r.onPointerWheelChanged
		}, [
			t[12] ||= x("span", {
				class: "win-combo-background",
				"aria-hidden": "true"
			}, null, -1),
			S(r.ContentPresenter, {
				"x:Name": "ContentPresenter",
				class: Fe(["win-combo-content", { "is-placeholder": r.currentSelectedIndex < 0 && r.currentSelectedItem === void 0 }]),
				Margin: "{x:Bind SelectionBoxPadding, Mode=OneWay}",
				Opacity: "{x:Bind SelectionBoxOpacity, Mode=OneWay}",
				HorizontalAlignment: "{x:Bind props.HorizontalContentAlignment, Mode=OneWay}",
				VerticalAlignment: "{x:Bind props.VerticalContentAlignment, Mode=OneWay}"
			}, {
				default: O(() => [S(r.SelectionBoxRenderer)]),
				_: 1
			}, 8, ["class"]),
			t[13] ||= x("span", {
				class: "win-combo-focus-pill",
				"aria-hidden": "true"
			}, null, -1),
			S(r.AnimatedIcon, {
				class: "win-combo-chevron",
				"x:Name": "DropDownGlyph",
				Width: "12",
				Height: "12",
				Margin: "0,0,14,0",
				HorizontalAlignment: "Right",
				VerticalAlignment: "Center",
				Foreground: "{ThemeResource ComboBoxDropDownGlyphForeground}",
				IsHitTestVisible: "False",
				"AutomationProperties.AccessibilityView": "Raw"
			}, {
				default: O(() => [S(r.AnimatedIcon.Source, null, {
					default: O(() => [S(r.AnimatedChevronDownSmallVisualSource)]),
					_: 1
				}), S(r.AnimatedIcon.FallbackIconSource, null, {
					default: O(() => [S(r.FontIconSource, {
						Foreground: "{ThemeResource ComboBoxDropDownGlyphForeground}",
						FontFamily: "{ThemeResource SymbolThemeFontFamily}",
						FontSize: "12",
						Glyph: ""
					})]),
					_: 1
				})]),
				_: 1
			})
		], 40, et)),
		r.resolvedDescription ? (T(), Oe(r.ContentPresenter, {
			key: 3,
			"x:Name": "DescriptionPresenter",
			class: "win-combo-description",
			Content: "{x:Bind resolvedDescription, Mode=OneWay}"
		})) : ke("", !0),
		(T(), Oe(De, { to: "body" }, [
			r.isOpen ? (T(), b("div", {
				key: 0,
				class: Fe(["win-combo-overlay", [r.themeClass, { "is-visible": r.isOverlayVisible }]]),
				onContextmenu: Je(r.close, ["prevent"]),
				onPointerdown: r.close
			}, null, 34)) : ke("", !0),
			r.popupVisible ? qe((T(), b("div", {
				key: 1,
				id: r.listBoxId,
				ref: "flyoutRef",
				class: Fe(["win-combo-flyout win-theme-scope", [r.themeClass, {
					"is-positioned": r.flyoutReady,
					"is-closing": r.isClosing,
					"opens-up": r.openedUp,
					"touch-input": r.inputDeviceTypeUsedToOpen === "Touch",
					"edge-square-top": r.resolvedIsEditable && !r.openedUp,
					"edge-square-bottom": r.resolvedIsEditable && r.openedUp
				}]]),
				style: Ie([r.flyoutStyle, r.dropDownBackgroundStyle]),
				role: "listbox",
				onKeydown: r.onFlyoutKeyDown,
				onPointerdown: Je(r.onFlyoutPointerDown, ["stop"]),
				onPointerleave: r.onFlyoutPointerLeave
			}, [x("div", {
				class: "win-combo-flyout-hit-root",
				onPointermove: r.onFlyoutPointerMove,
				onClick: r.onFlyoutClick
			}, [S(r.ScrollViewer, {
				ref: "scrollViewerRef",
				class: "win-combo-scroll-viewer",
				HorizontalScrollMode: "{x:Bind ComboBoxScrollSettings.HorizontalScrollMode, Mode=OneWay}",
				HorizontalScrollBarVisibility: "{x:Bind ComboBoxScrollSettings.HorizontalScrollBarVisibility, Mode=OneWay}",
				VerticalScrollMode: "{x:Bind ComboBoxScrollSettings.VerticalScrollMode, Mode=OneWay}",
				VerticalScrollBarVisibility: "{x:Bind ComboBoxScrollSettings.VerticalScrollBarVisibility, Mode=OneWay}",
				IsHorizontalRailEnabled: "{x:Bind ComboBoxScrollSettings.IsHorizontalRailEnabled, Mode=OneWay}",
				IsVerticalRailEnabled: "{x:Bind ComboBoxScrollSettings.IsVerticalRailEnabled, Mode=OneWay}",
				IsDeferredScrollingEnabled: "{x:Bind ComboBoxScrollSettings.IsDeferredScrollingEnabled, Mode=OneWay}",
				ZoomMode: "Disabled",
				IsVerticalScrollChainingEnabled: "False",
				IsTabStop: "False"
			}, {
				default: O(() => [x("div", k, [(T(!0), b(Ee, null, Be(r.resolvedItemsSource, (e, n) => (T(), b("button", {
					key: r.getItemKey(e, n),
					ref_for: !0,
					ref: (e) => r.setItemRef(e, n),
					class: Fe(["win-combo-item", {
						selected: r.visualSelectedIndex === n,
						hovered: r.isFlyoutAnimating && r.hoveredIndex === n,
						"is-disabled": !r.IsItemEnabled(e)
					}]),
					type: "button",
					role: "option",
					"aria-selected": r.currentSelectedIndex === n,
					disabled: !r.IsItemEnabled(e),
					style: Ie(r.itemContainerStyle(e)),
					tabindex: r.currentSelectedIndex === n ? 0 : -1,
					onClick: (e) => r.select(n)
				}, [x("span", nt, [r.visualSelectedIndex === n ? (T(), b("svg", rt, [...t[14] ||= [x("rect", {
					width: "3",
					height: "16",
					rx: "1.5",
					fill: "currentColor"
				}, null, -1)]])) : ke("", !0), S(r.ContentPresenter, {
					class: "win-combo-item-content",
					Margin: "{ThemeResource ComboBoxItemThemePadding}",
					HorizontalAlignment: "Stretch",
					VerticalAlignment: "Top"
				}, {
					default: O(() => [r.hasItemTemplate ? (T(), Oe(r.ItemRenderer, {
						key: 0,
						item: e,
						index: n
					}, null, 8, ["item", "index"])) : (T(), Oe(r.InlineItemRenderer, {
						key: 1,
						item: e
					}, null, 8, ["item"]))]),
					_: 2
				}, 1024)])], 14, tt))), 128))], 512)]),
				_: 1
			}, 512)], 32)], 38)), [[
				r.vAcrylicBrush,
				r.dropDownBackgroundStyle,
				void 0,
				{ "host-backdrop": !0 }
			], [r.vThemeShadow, {
				Translation: 32,
				Enabled: r.defaultShadowEnabled
			}]]) : ke("", !0),
			r.isOpen && r.isFlyoutAnimating ? (T(), b("div", {
				key: 2,
				class: "win-combo-flyout-hit-overlay",
				style: Ie(r.flyoutStyle),
				onPointerdown: t[1] ||= Je(() => {}, ["stop"]),
				onPointermove: r.onFlyoutPointerMove,
				onPointerleave: r.onFlyoutPointerLeave,
				onClick: r.onFlyoutClick
			}, null, 36)) : ke("", !0)
		]))
	], 16, Xe);
}
var at = /*#__PURE__*/ ne(Ye, [["render", it], ["__file", "ComboBox.vue"]]);
//#endregion
export { at as default };

//# sourceMappingURL=ComboBox.vue.js.map