import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./TitleBar.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                             */
import { Fragment as n, Teleport as r, createBlock as i, createCommentVNode as a, createElementBlock as o, createElementVNode as s, createVNode as c, mergeProps as l, normalizeClass as u, normalizeStyle as d, openBlock as f, resolveComponent as p, withCtx as m, withKeys as h, withModifiers as g } from "vue";
//#region src/components/TitleBar.vue
var _ = [
	"aria-label",
	"aria-disabled",
	"data-state"
], v = [
	"aria-label",
	"aria-pressed",
	"aria-disabled",
	"data-state"
], y = [
	"aria-label",
	"aria-disabled",
	"data-state"
], b = {
	key: 8,
	"Grid.Column": "14",
	class: "win-titlebar-right-padding",
	"aria-hidden": "true"
}, x = {
	key: 9,
	"Grid.Column": "11",
	class: "win-titlebar-right-padding",
	"aria-hidden": "true"
};
function S(e, t, S, C, w, T) {
	let E = p("animatedvisuals:AnimatedBackVisualSource"), D = p("animatedvisuals:AnimatedGlobalNavigationButtonVisualSource");
	return f(), i(C.Grid, l({
		"x:Name": "PART_LayoutRoot",
		ref: C.registerRoot
	}, C.rootAttrs, {
		class: ["win-titlebar", C.rootClasses],
		style: C.rootStyle,
		"data-titlebar-height-option": C.resolvedCaptionHeightOption,
		"data-titlebar-caption-hit-test": C.nativeCaptionHitTestEnabled ? "NativeSnap" : "Web",
		dir: C.FlowDirection === "RightToLeft" ? "rtl" : "ltr"
	}), {
		default: m(() => [
			c(C.Grid.ColumnDefinitions, null, {
				default: m(() => [
					c(C.ColumnDefinition, {
						"x:Name": "LeftPaddingColumn",
						Width: "{ThemeResource TitleBarLeftPaddingWidth}"
					}),
					c(C.ColumnDefinition, { Width: "Auto" }),
					c(C.ColumnDefinition, { Width: "Auto" }),
					c(C.ColumnDefinition, { Width: "Auto" }),
					c(C.ColumnDefinition, { Width: "{x:Bind HeaderInset, Mode=OneWay}" }),
					c(C.ColumnDefinition, { Width: "Auto" }),
					c(C.ColumnDefinition, { Width: "Auto" }),
					c(C.ColumnDefinition, { Width: "Auto" }),
					c(C.ColumnDefinition, { Width: "*" }),
					c(C.ColumnDefinition, { Width: "Auto" }),
					c(C.ColumnDefinition, { Width: "{ThemeResource TitleBarMinDragRegionWidth}" }),
					C.captionControlsVisible ? (f(), o(n, { key: 1 }, [
						c(C.ColumnDefinition, { Width: "46" }),
						c(C.ColumnDefinition, { Width: "46" }),
						c(C.ColumnDefinition, { Width: "46" }),
						c(C.ColumnDefinition, { Width: "0" })
					], 64)) : (f(), i(C.ColumnDefinition, {
						key: 0,
						"x:Name": "RightPaddingColumn",
						Width: "{ThemeResource TitleBarRightPaddingWidth}"
					}))
				]),
				_: 1
			}),
			t[27] ||= s("div", {
				"Grid.Column": "0",
				class: "win-titlebar-left-padding",
				"aria-hidden": "true"
			}, null, -1),
			C.IsBackButtonVisible ? (f(), i(C.Button, {
				key: 0,
				"x:Name": "PART_BackButton",
				"Grid.Column": "1",
				class: "win-titlebar-back-button",
				Style: "{ThemeResource TitleBarBackButtonStyle}",
				VerticalAlignment: "Stretch",
				HorizontalContentAlignment: "Center",
				VerticalContentAlignment: "Center",
				FontSize: "16",
				IsEnabled: "{x:Bind BackButtonEnabled, Mode=OneWay}",
				"AutomationProperties.Name": "{x:Bind BackLabel, Mode=OneWay}",
				"ToolTipService.ToolTip": "{x:Bind BackLabel, Mode=OneWay}",
				Click: "requestBack"
			}, {
				default: m(() => [c(C.AnimatedIcon, {
					class: "icon",
					Width: "16",
					Height: "16",
					HorizontalAlignment: "Center",
					VerticalAlignment: "Center"
				}, {
					default: m(() => [c(C.AnimatedIcon.Source, null, {
						default: m(() => [c(E)]),
						_: 1
					}), c(C.AnimatedIcon.FallbackIconSource, null, {
						default: m(() => [c(C.FontIconSource, { Glyph: "" })]),
						_: 1
					})]),
					_: 1
				})]),
				_: 1
			})) : a("", !0),
			C.IsPaneToggleButtonVisible ? (f(), i(C.Button, {
				key: 1,
				"x:Name": "PART_PaneToggleButton",
				"Grid.Column": "2",
				class: "win-titlebar-pane-toggle-button",
				Style: "{ThemeResource TitleBarPaneToggleButtonStyle}",
				VerticalAlignment: "Stretch",
				HorizontalContentAlignment: "Center",
				VerticalContentAlignment: "Center",
				FontSize: "16",
				IsEnabled: "{x:Bind IsEnabled, Mode=OneWay}",
				"data-nav-pane-toggle": "",
				"aria-expanded": C.IsPaneOpen,
				"AutomationProperties.Name": "{x:Bind PaneLabel, Mode=OneWay}",
				"ToolTipService.ToolTip": "{x:Bind PaneLabel, Mode=OneWay}",
				Click: "requestPaneToggle"
			}, {
				default: m(() => [c(C.AnimatedIcon, {
					class: "icon",
					Width: "16",
					Height: "16",
					HorizontalAlignment: "Center",
					VerticalAlignment: "Center"
				}, {
					default: m(() => [c(C.AnimatedIcon.Source, null, {
						default: m(() => [c(D)]),
						_: 1
					}), c(C.AnimatedIcon.FallbackIconSource, null, {
						default: m(() => [c(C.FontIconSource, { Glyph: "" })]),
						_: 1
					})]),
					_: 1
				})]),
				_: 1
			}, 8, ["aria-expanded"])) : a("", !0),
			C.hasLeftHeader ? (f(), i(C.ContentPresenter, {
				key: 2,
				"x:Name": "PART_LeftHeaderPresenter",
				"Grid.Column": "3",
				class: "win-titlebar-left-header",
				HorizontalAlignment: "{ThemeResource TitleBarLeftHeaderHorizontalAlignment}",
				VerticalAlignment: "{ThemeResource TitleBarLeftHeaderVerticalAlignment}"
			}, {
				default: m(() => [c(C.LeftHeaderOutlet)]),
				_: 1
			})) : a("", !0),
			t[28] ||= s("div", {
				"Grid.Column": "4",
				class: "win-titlebar-left-header-padding",
				"aria-hidden": "true"
			}, null, -1),
			C.hasIcon ? (f(), i(C.Viewbox, {
				key: 3,
				"x:Name": "PART_Icon",
				"Grid.Column": "5",
				class: "win-titlebar-icon",
				MaxWidth: "{ThemeResource TitleBarIconMaxWidth}",
				MaxHeight: "{ThemeResource TitleBarIconMaxHeight}",
				Margin: "{ThemeResource TitleBarIconMargin}",
				VerticalAlignment: "Center"
			}, {
				default: m(() => [c(C.IconElementOutlet)]),
				_: 1
			})) : a("", !0),
			C.showTitle ? (f(), i(C.TextBlock, {
				key: 4,
				"x:Name": "PART_TitleText",
				"Grid.Column": "6",
				class: "win-titlebar-title",
				Text: "{x:Bind Title, Mode=OneWay}",
				Style: "{StaticResource CaptionTextBlockStyle}",
				Margin: "{ThemeResource TitleBarTitleMargin}",
				MinWidth: "{ThemeResource TitleBarTitleMinWidth}",
				HorizontalAlignment: "Left",
				VerticalAlignment: "Center",
				TextTrimming: "CharacterEllipsis",
				TextWrapping: "NoWrap"
			})) : a("", !0),
			C.showSubtitle ? (f(), i(C.TextBlock, {
				key: 5,
				"x:Name": "PART_SubtitleText",
				"Grid.Column": "7",
				class: "win-titlebar-subtitle",
				Text: "{x:Bind Subtitle, Mode=OneWay}",
				Style: "{StaticResource CaptionTextBlockStyle}",
				Foreground: "{ThemeResource TitleBarSubtitleForegroundBrush}",
				Margin: "{ThemeResource TitleBarSubtitleMargin}",
				MinWidth: "{ThemeResource TitleBarSubtitleMinWidth}",
				HorizontalAlignment: "Left",
				VerticalAlignment: "Center",
				TextTrimming: "CharacterEllipsis",
				TextWrapping: "NoWrap"
			})) : a("", !0),
			C.hasContent ? (f(), i(C.Grid, {
				key: 6,
				"x:Name": "PART_ContentPresenterGrid",
				"Grid.Column": "8",
				ref: C.registerContentArea,
				class: u(["win-titlebar-content", { "is-compact": C.isCompact }])
			}, {
				default: m(() => [c(C.ContentPresenter, {
					"x:Name": "PART_ContentPresenter",
					class: "win-titlebar-content-presenter",
					HorizontalAlignment: "{x:Bind ContentAlignment, Mode=OneWay}",
					VerticalAlignment: "{x:Bind ContentVerticalAlignment, Mode=OneWay}",
					Margin: "{x:Bind ContentMargin, Mode=OneWay}"
				}, {
					default: m(() => [c(C.ContentOutlet)]),
					_: 1
				})]),
				_: 1
			}, 8, ["class"])) : a("", !0),
			C.hasRightHeader ? (f(), i(C.ContentPresenter, {
				key: 7,
				"x:Name": "PART_RightHeaderPresenter",
				"Grid.Column": "9",
				class: "win-titlebar-right-header",
				HorizontalAlignment: "{ThemeResource TitleBarRightHeaderHorizontalAlignment}",
				VerticalAlignment: "{ThemeResource TitleBarRightHeaderVerticalAlignment}",
				Margin: C.hasContent ? C.FlowDirection === "RightToLeft" ? "0,0,16,0" : "16,0,0,0" : 0
			}, {
				default: m(() => [c(C.RightHeaderOutlet)]),
				_: 1
			}, 8, ["Margin"])) : a("", !0),
			t[29] ||= s("div", {
				"Grid.Column": "10",
				class: "win-titlebar-min-drag-region",
				"aria-hidden": "true"
			}, null, -1),
			(f(), i(r, {
				to: "body",
				disabled: !C.captionButtonsPortaled
			}, [C.captionControlsVisible ? (f(), o("div", {
				key: 0,
				class: u(["win-titlebar-caption-host", {
					"is-portal": C.captionButtonsPortaled,
					"is-deactivated": C.isDeactivated
				}]),
				style: d(C.captionButtonHostStyle)
			}, [
				s("div", {
					ref: "minimizeCaptionButton",
					class: "win-titlebar-caption-button win-titlebar-caption-button-minimize",
					"data-titlebar-caption-button": "minimize",
					role: "button",
					tabindex: "-1",
					"aria-label": C.captionLabels.minimize,
					"aria-disabled": C.captionActionInFlight !== null,
					"data-state": C.captionButtonState("minimize"),
					onClick: t[0] ||= g((e) => C.activateCaptionButton("minimize"), ["stop"]),
					onKeydown: [t[1] ||= h(g((e) => C.activateCaptionButton("minimize"), ["prevent"]), ["enter"]), t[2] ||= h(g(() => {}, ["prevent"]), ["space"])],
					onKeyup: t[3] ||= h(g((e) => C.activateCaptionButton("minimize"), ["prevent"]), ["space"]),
					onPointerenter: t[4] ||= (e) => C.setCaptionButtonPointer("minimize", "pointerOver", e),
					onPointerleave: t[5] ||= (e) => C.setCaptionButtonPointer("minimize", "normal", e),
					onPointerdown: t[6] ||= (e) => C.setCaptionButtonPointer("minimize", "pressed", e),
					onPointerup: t[7] ||= (e) => C.setCaptionButtonPointer("minimize", "pointerOver", e),
					onPointercancel: t[8] ||= (e) => C.setCaptionButtonPointer("minimize", "normal", e)
				}, [c(C.FontIcon, {
					class: "win-titlebar-caption-glyph",
					Glyph: "",
					FontFamily: "{ThemeResource SymbolThemeFontFamily}",
					FontSize: "10",
					IsTextScaleFactorEnabled: "False",
					HorizontalAlignment: "Center",
					VerticalAlignment: "Center",
					"aria-hidden": "true"
				})], 40, _),
				s("div", {
					ref: "maximizeCaptionButton",
					class: "win-titlebar-caption-button win-titlebar-caption-button-maximize",
					"data-titlebar-caption-button": "maximize",
					role: "button",
					tabindex: "-1",
					"aria-label": C.captionLabels.maximize,
					"aria-pressed": C.windowIsMaximized,
					"aria-disabled": C.captionActionInFlight !== null,
					"data-state": C.captionButtonState("maximize"),
					onClick: t[9] ||= g((e) => C.activateCaptionButton("maximize"), ["stop"]),
					onKeydown: [t[10] ||= h(g((e) => C.activateCaptionButton("maximize"), ["prevent"]), ["enter"]), t[11] ||= h(g(() => {}, ["prevent"]), ["space"])],
					onKeyup: t[12] ||= h(g((e) => C.activateCaptionButton("maximize"), ["prevent"]), ["space"]),
					onPointerenter: t[13] ||= (e) => C.setCaptionButtonPointer("maximize", "pointerOver", e),
					onPointerleave: t[14] ||= (e) => C.setCaptionButtonPointer("maximize", "normal", e),
					onPointerdown: t[15] ||= (e) => C.setCaptionButtonPointer("maximize", "pressed", e),
					onPointerup: t[16] ||= (e) => C.setCaptionButtonPointer("maximize", "pointerOver", e),
					onPointercancel: t[17] ||= (e) => C.setCaptionButtonPointer("maximize", "normal", e)
				}, [C.windowIsMaximized ? (f(), i(C.FontIcon, {
					key: 1,
					class: "win-titlebar-caption-glyph",
					Glyph: "",
					FontFamily: "{ThemeResource SymbolThemeFontFamily}",
					FontSize: "10",
					IsTextScaleFactorEnabled: "False",
					HorizontalAlignment: "Center",
					VerticalAlignment: "Center",
					"aria-hidden": "true"
				})) : (f(), i(C.FontIcon, {
					key: 0,
					class: "win-titlebar-caption-glyph",
					Glyph: "",
					FontFamily: "{ThemeResource SymbolThemeFontFamily}",
					FontSize: "10",
					IsTextScaleFactorEnabled: "False",
					HorizontalAlignment: "Center",
					VerticalAlignment: "Center",
					"aria-hidden": "true"
				}))], 40, v),
				s("div", {
					ref: "closeCaptionButton",
					class: "win-titlebar-caption-button win-titlebar-caption-button-close",
					"data-titlebar-caption-button": "close",
					role: "button",
					tabindex: "-1",
					"aria-label": C.captionLabels.close,
					"aria-disabled": C.captionActionInFlight !== null,
					"data-state": C.captionButtonState("close"),
					onClick: t[18] ||= g((e) => C.activateCaptionButton("close"), ["stop"]),
					onKeydown: [t[19] ||= h(g((e) => C.activateCaptionButton("close"), ["prevent"]), ["enter"]), t[20] ||= h(g(() => {}, ["prevent"]), ["space"])],
					onKeyup: t[21] ||= h(g((e) => C.activateCaptionButton("close"), ["prevent"]), ["space"]),
					onPointerenter: t[22] ||= (e) => C.setCaptionButtonPointer("close", "pointerOver", e),
					onPointerleave: t[23] ||= (e) => C.setCaptionButtonPointer("close", "normal", e),
					onPointerdown: t[24] ||= (e) => C.setCaptionButtonPointer("close", "pressed", e),
					onPointerup: t[25] ||= (e) => C.setCaptionButtonPointer("close", "pointerOver", e),
					onPointercancel: t[26] ||= (e) => C.setCaptionButtonPointer("close", "normal", e)
				}, [c(C.FontIcon, {
					class: "win-titlebar-caption-glyph",
					Glyph: "",
					FontFamily: "{ThemeResource SymbolThemeFontFamily}",
					FontSize: "10",
					IsTextScaleFactorEnabled: "False",
					HorizontalAlignment: "Center",
					VerticalAlignment: "Center",
					"aria-hidden": "true"
				})], 40, y)
			], 6)) : a("", !0)], 8, ["disabled"])),
			C.captionControlsVisible ? (f(), o("div", b)) : (f(), o("div", x)),
			C.captionControlsVisible ? (f(), i(C.ToolTip, {
				key: 10,
				IsOpen: C.tooltipButton === "minimize",
				PlacementTarget: C.minimizeCaptionButton,
				Placement: "Bottom",
				Content: C.captionLabels.minimize
			}, null, 8, [
				"IsOpen",
				"PlacementTarget",
				"Content"
			])) : a("", !0),
			C.captionControlsVisible ? (f(), i(C.ToolTip, {
				key: 11,
				IsOpen: C.tooltipButton === "maximize",
				PlacementTarget: C.maximizeCaptionButton,
				Placement: "Bottom",
				Content: C.captionLabels.maximize
			}, null, 8, [
				"IsOpen",
				"PlacementTarget",
				"Content"
			])) : a("", !0),
			C.captionControlsVisible ? (f(), i(C.ToolTip, {
				key: 12,
				IsOpen: C.tooltipButton === "close",
				PlacementTarget: C.closeCaptionButton,
				Placement: "Bottom",
				Content: C.captionLabels.close
			}, null, 8, [
				"IsOpen",
				"PlacementTarget",
				"Content"
			])) : a("", !0)
		]),
		_: 1
	}, 16, [
		"class",
		"style",
		"data-titlebar-height-option",
		"data-titlebar-caption-hit-test",
		"dir"
	]);
}
var C = /*#__PURE__*/ e(t, [
	["render", S],
	["__scopeId", "data-v-b48b096d"],
	["__file", "TitleBar.vue"]
]);
//#endregion
export { C as default };

//# sourceMappingURL=TitleBar.vue.js.map