import { alignment as e, boolValue as t, cssLength as n, xamlThickness as r } from "./layout.js";
import { normalizeXamlNodes as i, resolveXamlHandler as ee, resolveXamlValue as te, updateXamlBinding as a, xamlScopeKey as ne } from "./xamlRuntime.js";
import re from "./Grid.vue.js";
import { useUICommand as ie } from "./uiCommandRuntime.js";
import { animatedIconVisualSourceComponents as ae } from "./animatedIconVisuals.js";
import oe from "./AnimatedIcon.vue.js";
import { buttonContentProperty as o, getButtonContentProperty as se, useButtonContent as ce } from "./buttonContentRuntime.js";
import le from "./Button.vue.js";
import ue from "./ColumnDefinition.vue.js";
import { FontIconSource as de } from "./IconSource.js";
import { Comment as fe, Fragment as s, Text as pe, cloneVNode as me, computed as c, defineComponent as l, getCurrentInstance as he, h as u, inject as ge, isVNode as d, onBeforeUnmount as _e, onMounted as ve, provide as f, proxyRefs as ye, ref as p, shallowRef as be, useAttrs as xe, useSlots as Se, watch as m } from "vue";
//#region src/components/SplitButton.vue?vue&type=script&setup=true&lang.ts
var h = l({
	name: "SplitButton.Flyout",
	__splitButtonProperty: "flyout",
	setup() {
		return () => null;
	}
}), g = l({
	name: "SplitButton.Content",
	__splitButtonProperty: "content",
	setup() {
		return () => null;
	}
}), Ce = /*@__PURE__*/ l({
	Flyout: h,
	Content: g,
	ContentTemplate: o("SplitButton", "ContentTemplate"),
	ContentTransitions: o("SplitButton", "ContentTransitions"),
	Resources: o("SplitButton", "Resources"),
	name: "SplitButton",
	inheritAttrs: !1,
	__name: "SplitButton",
	props: {
		Content: {
			type: null,
			default: ""
		},
		Flyout: {
			type: null,
			default: void 0
		},
		ContentTemplate: {
			type: null,
			default: void 0
		},
		ContentTransitions: {
			type: null,
			default: void 0
		},
		Command: {
			type: [Object, String],
			default: void 0
		},
		CommandParameter: { default: void 0 },
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		IsTabStop: {
			type: [Boolean, String],
			default: !0
		},
		Background: {
			type: String,
			default: ""
		},
		Foreground: {
			type: String,
			default: ""
		},
		BorderBrush: {
			type: String,
			default: ""
		},
		BorderThickness: {
			type: [String, Number],
			default: 1
		},
		Width: {
			type: [String, Number],
			default: ""
		},
		Height: {
			type: [String, Number],
			default: ""
		},
		MinWidth: {
			type: [String, Number],
			default: ""
		},
		MinHeight: {
			type: [String, Number],
			default: ""
		},
		MaxWidth: {
			type: [String, Number],
			default: ""
		},
		MaxHeight: {
			type: [String, Number],
			default: ""
		},
		Padding: {
			type: [String, Number],
			default: "11,6,11,7"
		},
		Margin: {
			type: [String, Number],
			default: ""
		},
		HorizontalAlignment: {
			type: String,
			default: "Left"
		},
		VerticalAlignment: {
			type: String,
			default: "Center"
		},
		HorizontalContentAlignment: {
			type: String,
			default: "Center"
		},
		VerticalContentAlignment: {
			type: String,
			default: "Center"
		},
		FontFamily: {
			type: String,
			default: "{ThemeResource ContentControlThemeFontFamily}"
		},
		FontSize: {
			type: [String, Number],
			default: 14
		},
		FontWeight: {
			type: String,
			default: "Normal"
		},
		CornerRadius: {
			type: [String, Number],
			default: 4
		},
		UseSystemFocusVisuals: {
			type: [Boolean, String],
			default: !0
		},
		FocusVisualMargin: {
			type: [String, Number],
			default: -1
		},
		Visibility: {
			type: String,
			default: "Visible"
		},
		RequestedTheme: {
			type: String,
			default: "Default"
		}
	},
	emits: ["Click"],
	setup(o, { expose: Ce, emit: we }) {
		let _ = o, Te = we, v = xe(), y = Se(), b = he();
		f("buttonFlyoutAnchor", null), f("buttonFlyoutController", null);
		let x = (e) => te(e, b), { ContentTemplate: S, ContentTransitions: C, renderTemplate: Ee } = ce(_, () => y.default?.() ?? [], b), w = p(null), De = p(null), Oe = p(null), T = p(null), E = p(!1), D = p(""), O = p(!1), k = p(!1), A = p(!1), j = p(!1), M = p("mouse"), N = ge("toggleSplitButtonState", null), P = c(() => N?.IsChecked.value ?? !1), F = c(() => t(x(_.IsEnabled))), I = p(), L = c({
			get: () => (I.value ?? F.value) && (G.value?.CanExecute?.(K.value) ?? !0),
			set: (e) => {
				I.value = t(e), a(_.IsEnabled, I.value, b);
			}
		}), ke = c(() => t(x(_.IsTabStop))), R = c(() => x(_.Content)), z = be(void 0);
		m(R, () => {
			z.value = void 0;
		});
		let B = c({
			get: () => z.value === void 0 ? R.value : z.value,
			set: (e) => {
				z.value = e, a(_.Content, e, b);
			}
		}), V = c(() => x(_.Flyout)), H = be(void 0);
		m(V, () => {
			H.value = void 0;
		});
		let U = c(() => String(x(_.RequestedTheme))), W = p();
		m(U, () => {
			W.value = void 0;
		});
		let Ae = c({
			get: () => W.value ?? U.value,
			set: (e) => {
				W.value = e, a(_.RequestedTheme, e, b);
			}
		}), G = ie(() => x(_.Command)), K = c(() => x(_.CommandParameter)), je = ae.AnimatedChevronDownSmallVisualSource, q = c(() => {
			let e = [], t = [], n = (r) => {
				for (let i of r) {
					if (i.type === fe || i.type === pe && !String(i.children ?? "").trim()) continue;
					if (i.type === s && Array.isArray(i.children)) {
						n(i.children);
						continue;
					}
					if (se(i)) continue;
					let r = i.type?.__splitButtonProperty;
					if (r) {
						let n = i.children?.default;
						n && (r === "flyout" ? t : e).push(...n());
					} else e.push(i);
				}
			};
			return n(y.default?.() ?? []), {
				main: e,
				flyout: t
			};
		}), Me = c(() => {
			if (H.value === void 0 && q.value.flyout.length) return q.value.flyout;
			let e = H.value === void 0 ? V.value : H.value;
			return d(e) ? [e] : [];
		}), Ne = l({ setup: () => () => {
			let e = Ee(B.value);
			if (e) return e;
			if (z.value === void 0 && q.value.main.length) {
				let e = i(q.value.main, b);
				return e.every((e) => e.type === pe) ? u("span", { class: "win-button-default-text" }, e.map((e) => String(e.children ?? "")).join("")) : u(s, e);
			}
			return typeof B.value == "string" || typeof B.value == "number" ? u("span", { class: "win-button-default-text" }, String(B.value)) : d(B.value) ? u(s, i([B.value], b)) : null;
		} }), Pe = l({ setup: () => () => u(s, i(Me.value, b).map((e) => me(e, {
			ref: (e) => {
				T.value = e;
			},
			onOpened: () => {
				E.value = !0;
			},
			onClosed: () => {
				E.value = !1;
			}
		}, !0))) }), J = c({
			get: () => H.value !== void 0 && !d(H.value) ? H.value : T.value ?? V.value,
			set: (e) => {
				J.value?.Hide?.(), T.value = null, H.value = e, E.value = !1, a(_.Flyout, e, b);
			}
		}), Fe = c(() => x(_.Padding)), Ie = c(() => x(_.CornerRadius)), Le = c(() => x(_.FontFamily)), Re = c(() => x(_.FontSize)), ze = c(() => x(_.FontWeight)), Be = c(() => x(_.HorizontalContentAlignment)), Ve = c(() => x(_.VerticalContentAlignment)), Y = (e) => `var(--SplitButton${e})`, He = c(() => !!D.value || M.value === "touch" && (A.value || j.value)), X = c(() => E.value || He.value ? "Pressed" : ""), Ue = c(() => L.value ? !P.value && !X.value && !O.value && !A.value && _.Background ? x(_.Background) : Y(`Background${P.value ? "Checked" : ""}${X.value || (A.value ? "Pressed" : O.value && M.value !== "touch" ? "PointerOver" : "")}`) : "transparent"), We = c(() => L.value ? !P.value && !X.value && !k.value && !j.value && _.Background ? x(_.Background) : Y(`Background${P.value ? "Checked" : ""}${X.value || (j.value ? "Pressed" : k.value && M.value !== "touch" ? "PointerOver" : "")}`) : "transparent"), Ge = c(() => L.value ? !P.value && !X.value && !O.value && !A.value && _.Foreground ? x(_.Foreground) : Y(`Foreground${P.value ? "Checked" : ""}${X.value || (A.value ? "Pressed" : O.value && M.value !== "touch" ? "PointerOver" : "")}`) : Y("ForegroundDisabled")), Ke = c(() => L.value ? P.value ? Y(`ForegroundChecked${X.value || (j.value ? "Pressed" : k.value ? "PointerOver" : "")}`) : Y(X.value || j.value ? "ForegroundSecondaryPressed" : k.value ? "ForegroundPointerOver" : "ForegroundSecondary") : Y("ForegroundDisabled")), qe = c(() => L.value ? !P.value && !X.value && !A.value && _.BorderBrush ? x(_.BorderBrush) : Y(`BorderBrush${P.value ? "Checked" : ""}${X.value || (!P.value && A.value ? "Pressed" : "")}`) : Y("BorderBrushDisabled")), Je = c(() => L.value ? !P.value && !X.value && !j.value && _.BorderBrush ? x(_.BorderBrush) : Y(`BorderBrush${P.value ? "Checked" : ""}${X.value || (!P.value && j.value ? "Pressed" : "")}`) : Y("BorderBrushDisabled")), Ye = c(() => Y(P.value ? "BorderBrushCheckedDivider" : "BorderBrushDivider")), Xe = c(() => {
			let e = Object.fromEntries(Object.entries(v).filter(([e]) => ![
				"class",
				"style",
				"Click",
				"onClick"
			].includes(e))), t = e["AutomationProperties.Name"];
			return delete e["AutomationProperties.Name"], t && (e["aria-label"] = String(x(t))), e;
		}), Ze = c(() => {
			let t = {
				margin: r(x(_.Margin)),
				justifySelf: e(x(_.HorizontalAlignment), "horizontal"),
				alignSelf: e(x(_.VerticalAlignment), "vertical"),
				outlineOffset: n(x(_.FocusVisualMargin))
			};
			t["--SplitButtonPrimaryBorderBrush"] = qe.value, t["--SplitButtonSecondaryBorderBrush"] = Je.value;
			for (let e of [
				"Width",
				"Height",
				"MinWidth",
				"MinHeight",
				"MaxWidth",
				"MaxHeight"
			]) x(_[e]) !== "" && (t[e[0].toLowerCase() + e.slice(1)] = n(x(_[e])));
			return x(_.Visibility) === "Collapsed" && (t.display = "none"), x(_.Visibility) === "Hidden" && (t.visibility = "hidden"), [v.style, t];
		}), Z = ye({
			IsEnabled: L,
			RequestedTheme: Ae,
			ContentTemplate: S,
			ContentTransitions: C,
			Name: c(() => v["data-xaml-ref"] ?? v["x:Name"] ?? v.Name ?? ""),
			Content: c({
				get: () => z.value === void 0 ? q.value.main[0] ?? B.value : z.value,
				set: (e) => {
					B.value = e;
				}
			}),
			Flyout: J,
			Command: G,
			CommandParameter: K,
			Element: w,
			IsFlyoutOpen: E,
			Focus: () => (w.value?.focus(), L.value)
		});
		Ce(Z);
		function Qe(e) {
			if (!L.value) return;
			N?.Invoke(e);
			let t = {
				OriginalSource: Z,
				OriginalEvent: e
			};
			Te("Click", Z, t), ee(v.Click, b)?.(Z, t), (G.value?.CanExecute?.(K.value) ?? !0) && G.value?.Execute(K.value);
		}
		function $e() {
			L.value && J.value?.ShowAt && J.value.ShowAt(w.value, { Placement: "BottomEdgeAlignedLeft" });
		}
		function et(e, t) {
			w.value?.focus({ preventScroll: !0 }), Qe(t?.OriginalEvent);
		}
		function tt() {
			w.value?.focus({ preventScroll: !0 }), $e();
		}
		function Q(e) {
			M.value = e?.OriginalEvent?.pointerType ?? "mouse";
		}
		function nt(e, t) {
			Q(t), O.value = !0;
		}
		function rt(e, t) {
			Q(t), O.value = !1, A.value = !1;
		}
		function it(e, t) {
			Q(t), A.value = !0;
		}
		function at(e, t) {
			Q(t), A.value = !1;
		}
		function ot(e) {
			A.value = e.IsPressed, O.value = e.IsPointerOver;
		}
		function st(e, t) {
			Q(t), k.value = !0;
		}
		function ct(e, t) {
			Q(t), k.value = !1, j.value = !1;
		}
		function lt(e, t) {
			Q(t), j.value = !0;
		}
		function ut(e, t) {
			Q(t), j.value = !1;
		}
		function dt(e) {
			j.value = e.IsPressed, k.value = e.IsPointerOver;
		}
		function $() {
			D.value = "", A.value = !1, j.value = !1;
		}
		function ft(e) {
			!L.value || e.target !== w.value || ((e.key === " " || e.key === "Enter") && (e.preventDefault(), e.repeat || (D.value = e.key)), (e.key === "F4" || e.key === "ArrowDown" && e.altKey) && e.preventDefault());
		}
		function pt(e) {
			if (!(!L.value || e.target !== w.value)) if (e.key === " " || e.key === "Enter") {
				e.preventDefault();
				let t = D.value === e.key;
				$(), t && Qe(e);
			} else (e.key === "F4" || e.key === "ArrowDown" && e.altKey) && (e.preventDefault(), $e());
		}
		m(F, () => {
			I.value = void 0;
		}), m(L, (e) => {
			e || ($(), J.value?.Hide?.());
		}), ve(() => window.addEventListener("blur", $)), _e(() => {
			window.removeEventListener("blur", $), J.value?.Hide?.();
		}), f(ne, {
			...ge(ne, {}),
			IsEnabled: L,
			Content: B,
			ContentTemplate: S,
			ContentTransitions: C,
			CornerRadius: Ie,
			Padding: Fe,
			FontFamily: Le,
			FontSize: Re,
			FontWeight: ze,
			HorizontalContentAlignment: Be,
			VerticalContentAlignment: Ve,
			PrimaryBackground: Ue,
			SecondaryBackground: We,
			PrimaryForeground: Ge,
			SecondaryForeground: Ke,
			PrimaryBorderBrush: qe,
			SecondaryBorderBrush: Je,
			DividerBackground: Ye,
			OnPrimaryClick: et,
			OnSecondaryClick: tt,
			OnPrimaryEntered: nt,
			OnPrimaryExited: rt,
			OnPrimaryPressed: it,
			OnPrimaryReleased: at,
			OnPrimaryMoved: ot,
			OnSecondaryEntered: st,
			OnSecondaryExited: ct,
			OnSecondaryPressed: lt,
			OnSecondaryReleased: ut,
			OnSecondaryMoved: dt
		});
		let mt = {
			SplitButtonFlyout: h,
			SplitButtonContent: g,
			props: _,
			emit: Te,
			attrs: v,
			slots: y,
			instance: b,
			resolve: x,
			ContentTemplate: S,
			ContentTransitions: C,
			renderTemplate: Ee,
			root: w,
			primaryButton: De,
			secondaryButton: Oe,
			attachedFlyout: T,
			isOpen: E,
			keyPressed: D,
			primaryOver: O,
			secondaryOver: k,
			primaryPressed: A,
			secondaryPressed: j,
			pointerType: M,
			internalChecked: N,
			checked: P,
			sourceEnabled: F,
			localEnabled: I,
			IsEnabled: L,
			IsTabStop: ke,
			sourceContent: R,
			localContent: z,
			Content: B,
			sourceFlyout: V,
			localFlyout: H,
			sourceRequestedTheme: U,
			localRequestedTheme: W,
			RequestedTheme: Ae,
			Command: G,
			CommandParameter: K,
			AnimatedChevronDownSmallVisualSource: je,
			propertyNodes: q,
			flyoutNodes: Me,
			MainOutlet: Ne,
			FlyoutOutlet: Pe,
			Flyout: J,
			Padding: Fe,
			CornerRadius: Ie,
			FontFamily: Le,
			FontSize: Re,
			FontWeight: ze,
			HorizontalContentAlignment: Be,
			VerticalContentAlignment: Ve,
			resource: Y,
			touchPressed: He,
			commonSuffix: X,
			PrimaryBackground: Ue,
			SecondaryBackground: We,
			PrimaryForeground: Ge,
			SecondaryForeground: Ke,
			PrimaryBorderBrush: qe,
			SecondaryBorderBrush: Je,
			DividerBackground: Ye,
			hostAttrs: Xe,
			hostStyle: Ze,
			api: Z,
			invoke: Qe,
			openFlyout: $e,
			onPrimaryClick: et,
			onSecondaryClick: tt,
			pointer: Q,
			onPrimaryEntered: nt,
			onPrimaryExited: rt,
			onPrimaryPressed: it,
			onPrimaryReleased: at,
			onPrimaryMoved: ot,
			onSecondaryEntered: st,
			onSecondaryExited: ct,
			onSecondaryPressed: lt,
			onSecondaryReleased: ut,
			onSecondaryMoved: dt,
			clearKey: $,
			onKeyDown: ft,
			onKeyUp: pt,
			Grid: re,
			ColumnDefinition: ue,
			Button: le,
			AnimatedIcon: oe,
			get FontIconSource() {
				return de;
			},
			get boolValue() {
				return t;
			}
		};
		return Object.defineProperty(mt, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), mt;
	}
});
//#endregion
export { g as SplitButtonContent, h as SplitButtonFlyout, Ce as default };

//# sourceMappingURL=SplitButton.vue_vue_type_script_setup_true_lang.js.map