import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./SplitButton.vue_vue_type_script_setup_true_lang.js";
/* empty css                                                */
import { createBlock as n, createCommentVNode as r, createElementBlock as i, createVNode as a, mergeProps as o, openBlock as s, withCtx as c } from "vue";
//#region src/components/SplitButton.vue
var l = [
	"tabindex",
	"aria-disabled",
	"aria-expanded"
];
function u(e, t, u, d, f, p) {
	return s(), i("div", o({ ref: "root" }, d.hostAttrs, {
		class: ["win-split-button", [d.attrs.class, {
			"is-open": d.isOpen,
			"is-disabled": !d.IsEnabled,
			"keyboard-pressed": d.keyPressed,
			"system-focus": d.boolValue(d.resolve(d.props.UseSystemFocusVisuals)),
			"win-theme-scope": d.RequestedTheme === "Light" || d.RequestedTheme === "Dark",
			"theme-light": d.RequestedTheme === "Light",
			"theme-dark": d.RequestedTheme === "Dark"
		}]],
		style: d.hostStyle,
		role: "button",
		tabindex: d.IsEnabled && d.IsTabStop ? 0 : -1,
		"aria-disabled": !d.IsEnabled || void 0,
		"aria-expanded": d.isOpen,
		onKeydown: d.onKeyDown,
		onKeyup: d.onKeyUp,
		onBlur: d.clearKey
	}), [a(d.Grid, {
		class: "win-split-root-grid",
		Background: "Transparent",
		CornerRadius: "{x:Bind CornerRadius}"
	}, {
		default: c(() => [
			a(d.Grid.ColumnDefinitions, null, {
				default: c(() => [
					a(d.ColumnDefinition, {
						Width: "*",
						MinWidth: "35"
					}),
					a(d.ColumnDefinition, { Width: "1" }),
					a(d.ColumnDefinition, { Width: "35" })
				]),
				_: 1
			}),
			a(d.Grid, {
				class: "win-split-primary-background",
				"Grid.ColumnSpan": "2",
				Background: "{x:Bind PrimaryBackground}"
			}),
			a(d.Grid, {
				class: "win-split-divider",
				"Grid.Column": "1",
				Background: "{x:Bind DividerBackground}"
			}),
			a(d.Grid, {
				class: "win-split-secondary-background",
				"Grid.Column": "2",
				Background: "{x:Bind SecondaryBackground}"
			}),
			a(d.Button, {
				ref: "primaryButton",
				class: "win-split-main-button",
				"Grid.Column": "0",
				IsEnabled: "{x:Bind IsEnabled}",
				IsTabStop: "False",
				Background: "Transparent",
				BorderBrush: "Transparent",
				BorderThickness: "0",
				Foreground: "{x:Bind PrimaryForeground}",
				HorizontalAlignment: "Stretch",
				VerticalAlignment: "Stretch",
				HorizontalContentAlignment: "{x:Bind HorizontalContentAlignment}",
				VerticalContentAlignment: "{x:Bind VerticalContentAlignment}",
				Padding: "{x:Bind Padding}",
				FontFamily: "{x:Bind FontFamily}",
				FontSize: "{x:Bind FontSize}",
				FontWeight: "{x:Bind FontWeight}",
				Content: "{x:Bind Content}",
				ContentTemplate: "{x:Bind ContentTemplate}",
				ContentTransitions: "{x:Bind ContentTransitions}",
				Click: "OnPrimaryClick",
				PointerEntered: "OnPrimaryEntered",
				PointerExited: "OnPrimaryExited",
				PointerMoved: "OnPrimaryMoved",
				PointerPressed: "OnPrimaryPressed",
				PointerReleased: "OnPrimaryReleased",
				PointerCanceled: "OnPrimaryReleased",
				PointerCaptureLost: "OnPrimaryReleased"
			}, {
				default: c(() => [a(d.MainOutlet)]),
				_: 1
			}, 512),
			a(d.Button, {
				ref: "secondaryButton",
				class: "win-split-secondary-button",
				"Grid.Column": "2",
				IsEnabled: "{x:Bind IsEnabled}",
				IsTabStop: "False",
				Background: "Transparent",
				BorderBrush: "Transparent",
				BorderThickness: "0",
				Foreground: "{x:Bind SecondaryForeground}",
				HorizontalAlignment: "Stretch",
				VerticalAlignment: "Stretch",
				HorizontalContentAlignment: "Stretch",
				VerticalContentAlignment: "Stretch",
				Padding: "0,0,12,0",
				Click: "OnSecondaryClick",
				PointerEntered: "OnSecondaryEntered",
				PointerExited: "OnSecondaryExited",
				PointerMoved: "OnSecondaryMoved",
				PointerPressed: "OnSecondaryPressed",
				PointerReleased: "OnSecondaryReleased",
				PointerCanceled: "OnSecondaryReleased",
				PointerCaptureLost: "OnSecondaryReleased"
			}, {
				default: c(() => [a(d.Button.Content, null, {
					default: c(() => [a(d.AnimatedIcon, {
						Height: "12",
						Width: "12",
						VerticalAlignment: "Center",
						HorizontalAlignment: "Right",
						"AutomationProperties.AccessibilityView": "Raw"
					}, {
						default: c(() => [a(d.AnimatedChevronDownSmallVisualSource), a(d.AnimatedIcon.FallbackIconSource, null, {
							default: c(() => [a(d.FontIconSource, {
								FontFamily: "{ThemeResource SymbolThemeFontFamily}",
								FontSize: "8",
								Glyph: "",
								IsTextScaleFactorEnabled: "False"
							})]),
							_: 1
						})]),
						_: 1
					})]),
					_: 1
				})]),
				_: 1
			}, 512),
			a(d.Grid, {
				class: "win-split-primary-border",
				"Grid.Column": "0",
				BorderBrush: "{x:Bind PrimaryBorderBrush}",
				BorderThickness: "1,1,0,1",
				CornerRadius: "4,0,0,4"
			}),
			a(d.Grid, {
				class: "win-split-secondary-border",
				"Grid.Column": "2",
				BorderBrush: "{x:Bind SecondaryBorderBrush}",
				BorderThickness: "0,1,1,1",
				CornerRadius: "0,4,4,0"
			})
		]),
		_: 1
	}), d.flyoutNodes.length ? (s(), n(d.FlyoutOutlet, { key: 0 })) : r("", !0)], 16, l);
}
var d = /*#__PURE__*/ e(t, [["render", u], ["__file", "SplitButton.vue"]]);
//#endregion
export { d as default };

//# sourceMappingURL=SplitButton.vue.js.map