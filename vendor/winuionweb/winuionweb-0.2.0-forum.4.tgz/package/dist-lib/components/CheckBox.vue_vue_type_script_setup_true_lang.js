import { resolveXamlHandler as e, resolveXamlValue as t, updateXamlBinding as n, xamlScopeKey as r } from "./xamlRuntime.js";
import { animatedIconVisualSourceComponents as i } from "./animatedIconVisuals.js";
import a from "./AnimatedIcon.vue.js";
import { useAnimatedIconInput as o } from "./animatedIconInput.js";
import { FontIconSource as s } from "./IconSource.js";
import { computed as c, defineComponent as l, getCurrentInstance as u, inject as d, provide as f, ref as p, useAttrs as m, watch as h } from "vue";
//#region src/components/CheckBox.vue?vue&type=script&setup=true&lang.ts
var g = /*@__PURE__*/ l({
	__name: "CheckBox",
	props: {
		Content: {
			type: [String, Number],
			default: ""
		},
		IsChecked: {
			type: [
				Boolean,
				String,
				null
			],
			default: void 0
		},
		IsThreeState: {
			type: [Boolean, String],
			default: void 0
		},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		IsTabStop: {
			type: [Boolean, String],
			default: !0
		},
		Margin: {
			type: String,
			default: ""
		}
	},
	emits: [
		"Click",
		"update:IsChecked",
		"Checked",
		"Unchecked",
		"Indeterminate"
	],
	setup(l, { expose: g, emit: _ }) {
		let v = i.AnimatedAcceptVisualSource, y = l, b = u(), x = m(), S = c(() => {
			let { class: e, style: t, Click: n, onClick: r, onPointerdown: i, ...a } = x;
			return a;
		}), C = c(() => t(y.Content, b)), w = c(() => t(y.IsChecked, b)), T = c(() => t(y.IsThreeState, b)), E = c(() => t(y.IsEnabled, b) !== !1), D = _, O = p(!1), k = p(void 0), A = c(() => T.value === !0), j = c(() => t(y.IsTabStop, b) !== !1), M = c(() => !E.value), N = c(() => k.value === void 0 ? O.value : k.value);
		h(w, (e) => {
			e === void 0 ? k.value = void 0 : k.value = e === null ? null : e === !0;
		}, { immediate: !0 });
		let P = c(() => N.value === !0), F = c(() => A.value && N.value === null), I = c(() => F.value ? "mixed" : P.value), L = c(() => ({
			"is-checked": P.value,
			"is-unchecked": !P.value && !F.value,
			"is-indeterminate": F.value,
			"is-disabled": M.value
		})), R = p(null), z = o(!1, (e) => `${e === "Disabled" ? "Normal" : e}${F.value ? "Indeterminate" : P.value ? "On" : "Off"}`);
		h(R, (e) => z.Attach(e), { flush: "post" }), h([
			P,
			F,
			M
		], () => z.Refresh(), { flush: "post" }), f(r, {
			...d(r, {}),
			CheckGlyphMargin: c(() => F.value ? "0" : "0,1,0,-1")
		});
		let B = (e) => e === "" || e == null ? "" : typeof e == "string" && e.trim() !== "" && !Number.isNaN(Number(e.trim())) ? `${Number(e.trim())}px` : typeof e == "number" ? `${e}px` : e, V = (e) => {
			if (!e) return "";
			let t = String(e).split(",").map((e) => B(Number.isNaN(Number(e.trim())) ? e.trim() : Number(e.trim())));
			return t.length === 1 ? t[0] : t.length === 2 ? `${t[1]} ${t[0]}` : t.length === 4 ? `${t[1]} ${t[2]} ${t[3]} ${t[0]}` : e;
		}, H = c(() => y.Margin ? { margin: V(y.Margin) } : {}), U = (t, r) => {
			if (t === N.value) return;
			k.value = t, O.value = t === !0, D("update:IsChecked", t), n(y.IsChecked, t, b);
			let i = {
				OriginalSource: W,
				OriginalEvent: r,
				Handled: !1
			}, a = t === !0 ? "Checked" : t === null ? "Indeterminate" : "Unchecked", o = b?.vnode.props?.[`on${a}`];
			if (o) for (let e of Array.isArray(o) ? o : [o]) typeof e == "function" && e(W, i);
			else D(a, W, i), e(x[a], b)?.(W, i);
		}, W = {
			get IsChecked() {
				return N.value;
			},
			set IsChecked(e) {
				U(e);
			},
			get IsEnabled() {
				return !M.value;
			},
			get Content() {
				return C.value;
			},
			get Element() {
				return R.value;
			}
		};
		g(W);
		let G = (t) => {
			if (M.value || t instanceof KeyboardEvent && t.repeat) return;
			A.value ? N.value === !1 ? U(!0, t) : N.value === !0 ? U(null, t) : U(!1, t) : U(!P.value, t);
			let n = {
				OriginalEvent: t,
				Handled: !1
			};
			D("Click", W, n), b?.vnode.props?.onClick || e(x.Click, b)?.(W, n);
		}, K = !1, q = (e) => {
			z.KeyDown(e), !(e.key !== " " && e.key !== "Spacebar") && (e.preventDefault(), !e.repeat && !M.value && (K = !0));
		}, J = (e) => {
			if (z.KeyUp(e), e.key !== " " && e.key !== "Spacebar") return;
			e.preventDefault();
			let t = K && !M.value;
			K = !1, t && G(e);
		}, Y = (e) => {
			K = !1, z.LostFocus(e);
		};
		h(M, (e) => {
			e && (K = !1);
		});
		let X = {
			AnimatedAcceptVisualSource: v,
			props: y,
			instance: b,
			attrs: x,
			forwardedAttrs: S,
			resolvedContent: C,
			resolvedIsChecked: w,
			resolvedIsThreeState: T,
			resolvedIsEnabled: E,
			emit: D,
			localChecked: O,
			boundChecked: k,
			isThreeState: A,
			isTabStop: j,
			isDisabled: M,
			currentValue: N,
			isChecked: P,
			isIndeterminate: F,
			ariaChecked: I,
			stateClasses: L,
			checkboxElement: R,
			iconInput: z,
			cssLength: B,
			xamlThickness: V,
			checkboxStyle: H,
			emitState: U,
			publicApi: W,
			toggle: G,
			get spacePressed() {
				return K;
			},
			set spacePressed(e) {
				K = e;
			},
			onKeyDown: q,
			onKeyUp: J,
			onLostFocus: Y,
			AnimatedIcon: a,
			get FontIconSource() {
				return s;
			}
		};
		return Object.defineProperty(X, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), X;
	}
});
//#endregion
export { g as default };

//# sourceMappingURL=CheckBox.vue_vue_type_script_setup_true_lang.js.map