import e from "../_virtual/_plugin-vue_export-helper.js";
import t from "./CheckBox.vue_vue_type_script_setup_true_lang.js";
/* empty css                                             */
import { createElementBlock as n, createElementVNode as r, createTextVNode as i, createVNode as a, mergeProps as o, openBlock as s, renderSlot as c, toDisplayString as l, withCtx as u } from "vue";
//#region src/components/CheckBox.vue
var d = [
	"tabindex",
	"aria-checked",
	"aria-disabled"
], f = {
	class: "checkbox-box",
	"aria-hidden": "true"
}, p = { class: "checkbox-content" };
function m(e, t, m, h, g, _) {
	return s(), n("div", o({
		ref: "checkboxElement",
		class: ["win-checkbox", h.stateClasses],
		style: h.checkboxStyle,
		tabindex: h.isTabStop ? h.isDisabled ? -1 : 0 : -1,
		role: "checkbox",
		"aria-checked": h.ariaChecked,
		"aria-disabled": h.isDisabled
	}, h.forwardedAttrs, {
		onClick: h.toggle,
		onPointerenter: t[0] ||= (...e) => h.iconInput.PointerEntered && h.iconInput.PointerEntered(...e),
		onPointerleave: t[1] ||= (...e) => h.iconInput.PointerExited && h.iconInput.PointerExited(...e),
		onPointerdown: t[2] ||= (...e) => h.iconInput.PointerPressed && h.iconInput.PointerPressed(...e),
		onPointerup: t[3] ||= (...e) => h.iconInput.PointerReleased && h.iconInput.PointerReleased(...e),
		onPointercancel: t[4] ||= (...e) => h.iconInput.PointerExited && h.iconInput.PointerExited(...e),
		onLostpointercapture: t[5] ||= (...e) => h.iconInput.PointerExited && h.iconInput.PointerExited(...e),
		onKeydown: h.onKeyDown,
		onKeyup: h.onKeyUp,
		onFocusout: h.onLostFocus
	}), [r("span", f, [a(h.AnimatedIcon, {
		class: "checkbox-glyph",
		Width: "18",
		Height: "18",
		HorizontalAlignment: "Center",
		VerticalAlignment: "Center",
		Margin: "{x:Bind CheckGlyphMargin, Mode=OneWay}"
	}, {
		default: u(() => [a(h.AnimatedIcon.Source, null, {
			default: u(() => [a(h.AnimatedAcceptVisualSource)]),
			_: 1
		}), a(h.AnimatedIcon.FallbackIconSource, null, {
			default: u(() => [a(h.FontIconSource, {
				Glyph: "",
				FontSize: "12"
			})]),
			_: 1
		})]),
		_: 1
	})]), r("span", p, [c(e.$slots, "default", {}, () => [i(l(h.resolvedContent), 1)])])], 16, d);
}
var h = /*#__PURE__*/ e(t, [["render", m], ["__file", "CheckBox.vue"]]);
//#endregion
export { h as default };

//# sourceMappingURL=CheckBox.vue.js.map