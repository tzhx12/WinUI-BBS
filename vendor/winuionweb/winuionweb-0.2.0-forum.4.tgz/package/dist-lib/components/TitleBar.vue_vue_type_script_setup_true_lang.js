import { primitiveResourceScope as e, xamlPrimitiveResourceKey as t } from "./xamlPrimitives.js";
import { uiSettings as n } from "./uiSettings.js";
import { normalizeXamlNodes as r, resolveXamlHandler as i, resolveXamlValue as a, updateXamlBinding as o, xamlScopeKey as ee } from "./xamlRuntime.js";
import te from "./Grid.vue.js";
import ne from "./Viewbox.vue.js";
import { useI18n as re } from "./i18n/index.js";
import ie from "./TextBlock.vue.js";
import ae from "./FontIcon.vue.js";
import { animatedIconVisualSourceComponents as oe } from "./animatedIconVisuals.js";
import se from "./AnimatedIcon.vue.js";
import ce from "./ContentPresenter.vue.js";
import le from "./Button.vue.js";
import ue from "./ColumnDefinition.vue.js";
import { FontIconSource as de } from "./IconSource.js";
import fe from "./ToolTip.vue.js";
import pe from "./IconSourceElement.vue.js";
import { titleBarBrushAliases as me, titleBarHighContrastBrushAliases as he, titleBarResources as ge } from "./titleBarResources.js";
import { IsDragRegionProperty as _e, findTitleBarInteractableElements as ve, getIsDragRegion as ye, setIsDragRegion as s } from "./TitleBarDragRegion.js";
import { connectTitleBarWindowHost as be, createFrameworkTitleBarWindowHost as xe, getTitleBarHostPadding as Se, titleBarHostAdapterKey as Ce } from "./titleBarHostAdapter.js";
import { TitleBarContent as we, TitleBarIconSource as Te, TitleBarLeftHeader as Ee, TitleBarResources as De, TitleBarRightHeader as Oe } from "./TitleBarProperties.js";
import { Comment as ke, Fragment as Ae, Text as je, cloneVNode as Me, computed as c, defineComponent as Ne, getCurrentInstance as Pe, h as Fe, inject as Ie, isVNode as Le, nextTick as l, onBeforeUnmount as Re, onMounted as ze, provide as Be, proxyRefs as Ve, ref as u, shallowRef as He, useAttrs as Ue, useSlots as We, watch as d } from "vue";
var Ge = /*@__PURE__*/ Ne({
	components: {
		"animatedvisuals:AnimatedBackVisualSource": oe.AnimatedBackVisualSource,
		"animatedvisuals:AnimatedGlobalNavigationButtonVisualSource": oe.AnimatedGlobalNavigationButtonVisualSource
	},
	IconSource: Te,
	LeftHeader: Ee,
	Content: we,
	RightHeader: Oe,
	Resources: De,
	GetIsDragRegion: ye,
	SetIsDragRegion: s,
	IsDragRegionProperty: _e,
	inheritAttrs: !1,
	__name: "TitleBar",
	props: {
		Title: {
			type: String,
			default: ""
		},
		Subtitle: {
			type: String,
			default: ""
		},
		IconSource: {
			type: [String, Object],
			default: null
		},
		IsBackButtonVisible: {
			type: [Boolean, String],
			default: !1
		},
		IsBackButtonEnabled: {
			type: [Boolean, String],
			default: !0
		},
		IsPaneToggleButtonVisible: {
			type: [Boolean, String],
			default: !1
		},
		IsPaneOpen: {
			type: [Boolean, String],
			default: !0
		},
		IsCaptionButtonsVisible: {
			type: [Boolean, String],
			default: !1
		},
		CaptionButtonsFramework: {
			type: String,
			default: ""
		},
		LeftHeader: {
			type: null,
			default: null
		},
		Content: {
			type: null,
			default: null
		},
		RightHeader: {
			type: null,
			default: null
		},
		IsEnabled: {
			type: [Boolean, String],
			default: !0
		},
		FlowDirection: {
			type: String,
			default: "LeftToRight"
		},
		Visibility: {
			type: String,
			default: "Visible"
		},
		AutoRefreshDragRegions: {
			type: [Boolean, String],
			default: !1
		},
		PreferredHeightOption: {
			type: String,
			default: "Standard"
		},
		Background: {
			type: String,
			default: ""
		},
		Foreground: {
			type: String,
			default: ""
		},
		Width: {
			type: [String, Number],
			default: ""
		},
		Height: {
			type: [String, Number],
			default: ""
		},
		MinWidth: {
			type: [String, Number],
			default: ""
		},
		MinHeight: {
			type: [String, Number],
			default: ""
		},
		MaxWidth: {
			type: [String, Number],
			default: ""
		},
		MaxHeight: {
			type: [String, Number],
			default: ""
		},
		Margin: {
			type: [String, Number],
			default: ""
		},
		HorizontalAlignment: {
			type: String,
			default: ""
		},
		VerticalAlignment: {
			type: String,
			default: ""
		}
	},
	emits: [
		"BackRequested",
		"PaneToggleRequested",
		"LayoutUpdated",
		"CaptionButtonRequested",
		"MinimizeRequested",
		"MaximizeRequested",
		"CloseRequested"
	],
	setup(oe, { expose: _e, emit: ye }) {
		let { t: s } = re(), we = We(), Te = Ie(Ce, null), Ee = u(!1), De = c(() => Ee.value || n.IsHighContrast), Oe = c(() => De.value ? he : me), Ge = {
			SystemControlForegroundBaseHighBrush: "CanvasText",
			SystemControlHighlightAltBaseHighBrush: "HighlightText",
			SystemControlDisabledBaseMediumLowBrush: "GrayText",
			SystemControlBackgroundBaseLowBrush: "Canvas",
			SystemControlHighlightListLowBrush: "Highlight",
			SystemControlHighlightListMediumBrush: "Highlight"
		}, Ke = oe, f = ye, p = Pe(), m = Ue(), h = He({}), g = new Proxy(Ke, { get: (e, t) => a(t in h.value ? h.value[t] : Reflect.get(e, t), p) }), qe = c(() => Object.fromEntries(Object.entries(m).filter(([e]) => ![
			"BackRequested",
			"PaneToggleRequested",
			"LayoutUpdated",
			"CaptionButtonRequested",
			"MinimizeRequested",
			"MaximizeRequested",
			"CloseRequested"
		].includes(e)))), Je = c(() => Xe(we.default?.() ?? [])), Ye = (e) => Array.isArray(e.children) ? e.children : e.children?.default?.() ?? [], Xe = (e) => e.flatMap((e) => e.type === Ae ? Xe(Ye(e)) : e.type === ke || e.type === je && !String(e.children ?? "").trim() ? [] : [e]), Ze = (e) => e.type?.__titleBarProperty, _ = (e) => Je.value.filter((t) => Ze(t) === e).flatMap(Ye), Qe = () => Je.value.filter((e) => !Ze(e)), $e = Ie(t, null), et = e(() => Je.value.filter((e) => Ze(e) === "Resources"), $e), tt = c(() => ({
			...ge,
			...et.value
		}));
		Be(t, tt);
		let v = (e) => {
			if (tt.value[e] !== void 0) return tt.value[e];
			let t = Oe.value[e] ?? e, n = a(`{ThemeResource ${t}}`, p);
			return De.value && n === `var(--${t})` ? Ge[t] ?? n : n;
		}, nt = c(() => g.IconSource), rt = c(() => g.FlowDirection), it = c(() => g.IsEnabled !== !1), at = (e) => e in h.value ? g[e] !== null : _(e).length > 0 || g[e] !== null, ot = c(() => at("IconSource")), st = c(() => at("LeftHeader")), ct = c(() => at("RightHeader")), lt = Ne({ setup: () => () => Fe(pe, {
			ref: Nt,
			IconSource: g.IconSource
		}, { default: () => g.IconSource || "IconSource" in h.value ? [] : r(_("IconSource"), p) }) }), ut = Ne({
			props: { element: {
				type: Object,
				required: !0
			} },
			setup(e) {
				let t = u(null), n, r = null, i = null, a = () => {
					n && n.parentNode === t.value && (r ? r.insertBefore(n, i?.parentNode === r ? i : null) : n.remove()), n = void 0, r = i = null;
				}, o = () => {
					let o = e.element;
					!t.value || o === n || (a(), n = o, r = o.parentNode, i = o.nextSibling, t.value.appendChild(o));
				};
				return ze(o), d(() => e.element, o, { flush: "post" }), Re(a), () => Fe("span", {
					ref: t,
					style: { display: "contents" }
				});
			}
		}), dt = (e) => Ne({ setup: () => () => {
			let t = e in h.value ? [] : e === "Content" ? _("Content").length ? _("Content") : Qe() : _(e);
			if (t.length) return Fe(Ae, r(t.map((e) => Me(e)), p));
			let n = g[e], i = n, a = i?.nodeType === 1 ? i : i?.Element ?? i?.$el;
			return a?.nodeType === 1 ? Fe(ut, { element: a }) : Le(n) ? Fe(Ae, r([n], p)) : typeof n == "string" || typeof n == "number" ? String(n) : null;
		} }), ft = dt("LeftHeader"), pt = dt("RightHeader"), mt = dt("Content"), ht = c(() => !ot.value && !st.value ? 0 : v(vt.value === bt.value ? "TitleBarLeftHeaderPaddingWidth" : "TitleBarHeaderNegativeInsetPaddingWidth")), gt = c(() => g.Title), _t = c(() => g.Subtitle), vt = c(() => g.IsBackButtonVisible === !0), yt = c(() => g.IsBackButtonEnabled === !0), bt = c(() => g.IsPaneToggleButtonVisible === !0), y = c(() => g.IsCaptionButtonsVisible === !0 || typeof g.IsCaptionButtonsVisible == "string" && g.IsCaptionButtonsVisible.toLowerCase() === "true"), xt = c(() => {
			if (!y.value) return null;
			let e = g.CaptionButtonsFramework;
			return e === "Tauri" || e === "Electron" ? e : null;
		}), St = c(() => g.IsPaneOpen !== !1), Ct = c(() => it.value && yt.value), wt = c(() => s("text.back")), Tt = c(() => s(St.value ? "text.close-navigation" : "text.open-navigation")), Et = c(() => v("TitleBarContentHorizontalAlignment")), Dt = c(() => S.value ? "Stretch" : v("TitleBarContentVerticalAlignment")), Ot = c(() => S.value ? v("TitleBarCompactContentMargin") : 0), kt = () => {
			!it.value || !yt.value || !vt.value || (f("BackRequested", $, null), p?.vnode.props?.onBackRequested || i(m.BackRequested, p)?.($, null));
		}, At = () => {
			!it.value || !bt.value || (f("PaneToggleRequested", $, null), p?.vnode.props?.onPaneToggleRequested || i(m.PaneToggleRequested, p)?.($, null));
		};
		Be(ee, {
			...Ie(ee, {}),
			Title: gt,
			Subtitle: _t,
			IconSource: nt,
			HeaderInset: ht,
			IsEnabled: it,
			IsPaneOpen: St,
			BackButtonEnabled: Ct,
			BackLabel: wt,
			PaneLabel: Tt,
			ContentAlignment: Et,
			ContentVerticalAlignment: Dt,
			ContentMargin: Ot,
			requestBack: kt,
			requestPaneToggle: At
		});
		let jt = (e) => {
			let t = (e) => {
				if (e && typeof e == "object" && e.nodeType === 1) return e;
				if (!e || typeof e != "object") return null;
				let n = e;
				return t(n.Element) ?? t(n.$el);
			};
			return t(e);
		}, b = u(null), Mt = (e) => {
			b.value = jt(e);
		}, Nt = u(null), x = u(null), Pt = (e) => {
			x.value = jt(e);
		}, Ft = u(!1), S = u(!1), C = u(!1), w = u(null), T = y, It = u(!1), Lt = u(!1), E = u({
			Button: null,
			State: "normal"
		}), Rt = u({
			Button: null,
			State: "normal"
		}), zt = u(null), Bt = u(null), Vt = u(null), Ht = u(null), Ut = u(null), Wt = u(!1), Gt = He({}), Kt = c(() => E.value.State === "normal" ? Rt.value : E.value), qt = c(() => Kt.value.State === "pointerOver" ? Kt.value.Button : null), Jt = c(() => ({
			minimize: s("text.minimize"),
			maximize: Lt.value ? s("text.restore") : s("text.maximize"),
			close: s("text.close")
		})), Yt = () => {
			let e = b.value;
			if (!Wt.value || !e || !R) return;
			let t = e.getBoundingClientRect(), n = {
				left: `${t.right - 138}px`,
				top: `${t.top}px`,
				height: `${t.height}px`
			}, r = R.getComputedStyle(e);
			for (let e of [
				"--TitleBarCaptionButtonForeground",
				"--TitleBarCaptionButtonPressedForeground",
				"--TitleBarCaptionButtonInactiveForeground",
				"--SubtleFillColorSecondaryBrush",
				"--SubtleFillColorTertiaryBrush",
				"--subtle-secondary",
				"--subtle-tertiary"
			]) {
				let t = r.getPropertyValue(e).trim();
				t && (n[e] = t);
			}
			Gt.value = n;
		}, Xt = u(0), Zt = "", D = "", O = null, k = null, A = null, j = null, Qt, $t = [], M = null, N = 0, P = 0, F = -1, I = -1, L = -1, R = null, z = null, B = null, en, V, H, U, tn, W, nn = 0, G = 0, K, q, rn = () => {
			Ee.value = !!q?.matches;
		}, J = !1, an = c(() => "Content" in h.value ? g.Content !== null : _("Content").length > 0 || Qe().length > 0 || g.Content !== null), on = c(() => an.value || st.value || ct.value), sn = c(() => {
			let e = g.Height;
			if (typeof e == "number" && Number.isFinite(e)) return e;
			if (typeof e == "string") {
				let t = e.match(/^\s*(-?(?:\d+(?:\.\d*)?|\.\d+))(?:px)?\s*$/i);
				if (t) return Number(t[1]);
			}
			return null;
		}), cn = c(() => sn.value === 32 ? "Standard" : sn.value === 46 || g.PreferredHeightOption === "Tall" ? "Tall" : "Standard"), ln = c(() => g.Title !== ""), un = c(() => g.Subtitle !== ""), dn = c(() => g.IsBackButtonVisible !== g.IsPaneToggleButtonVisible), fn = c(() => ({
			"is-expanded-height": on.value,
			"is-compact-height": !on.value,
			"is-compact": S.value,
			"is-deactivated": Ft.value,
			"is-narrow": C.value,
			"has-caption-controls": T.value,
			"is-negative-inset-spacing": dn.value
		})), Y = (e) => e === "" || e == null ? "" : typeof e == "string" && e.trim() !== "" && !Number.isNaN(Number(e.trim())) ? `${Number(e.trim())}px` : typeof e == "number" ? `${e}px` : String(e), pn = (e) => {
			if (e === "" || e == null) return "";
			let t = String(e).split(",").map((e) => Y(e.trim()));
			return t.length === 1 ? t[0] ?? "" : t.length === 2 ? `${t[1]} ${t[0]}` : t.length === 4 ? `${t[1]} ${t[2]} ${t[3]} ${t[0]}` : String(e);
		}, mn = (e) => ({
			Left: "start",
			Center: "center",
			Right: "end",
			Stretch: "stretch"
		})[e] ?? "center", hn = (e) => ({
			Top: "start",
			Center: "center",
			Bottom: "end",
			Stretch: "stretch"
		})[e] ?? "center", gn = c(() => {
			let e = {};
			for (let t of Object.keys(Oe.value)) e[`--${t}`] = v(t);
			e["--TitleBarCaptionButtonForeground"] = String(v("TitleBarBackButtonForeground")), e["--TitleBarCaptionButtonPressedForeground"] = String(v("TitleBarBackButtonForegroundPressed")), e["--TitleBarCaptionButtonInactiveForeground"] = String(v("TitleBarDeactivatedForegroundBrush"));
			for (let t of [
				"TitleBarLeftPaddingWidth",
				"TitleBarRightPaddingWidth",
				"TitleBarMinDragRegionWidth",
				"TitleBarBackButtonWidth",
				"TitleBarPaneToggleButtonWidth"
			]) et.value[t] !== void 0 && (e[`--${t}`] = Y(et.value[t]));
			if (w.value) {
				let { LeftInset: t, RightInset: n } = w.value, r = g.FlowDirection === "RightToLeft";
				e["--TitleBarLeftPaddingWidth"] = Y(r ? n : t), e["--TitleBarRightPaddingWidth"] = Y(r ? t : n), T.value || (e.clipPath = `inset(0 ${n}px 0 ${t}px)`);
			}
			e["--TitleBarLeftHeaderPaddingWidth"] = Y(ht.value);
			for (let t of [
				"TitleBarIconMaxWidth",
				"TitleBarIconMaxHeight",
				"TitleBarTitleMinWidth",
				"TitleBarSubtitleMinWidth"
			]) e[`--${t}`] = Y(v(t));
			for (let t of [
				"TitleBarIconMargin",
				"TitleBarTitleMargin",
				"TitleBarSubtitleMargin",
				"TitleBarCompactContentMargin"
			]) e[`--${t}`] = pn(v(t));
			return e["--TitleBarDeactivatedOpacity"] = String(v("TitleBarDeactivatedOpacity")), e.height = Y(g.Height !== "" && g.Height !== void 0 && g.Height !== null ? g.Height : v(cn.value === "Tall" ? "TitleBarExpandedHeight" : "TitleBarCompactHeight")), e.gridTemplateColumns = T.value ? "var(--TitleBarLeftPaddingWidth, 2px) auto auto auto var(--TitleBarLeftHeaderPaddingWidth, 14px) auto auto auto minmax(0, 1fr) auto var(--TitleBarMinDragRegionWidth, 48px) 46px 46px 46px 0px" : "var(--TitleBarLeftPaddingWidth, 2px) auto auto auto var(--TitleBarLeftHeaderPaddingWidth, 14px) auto auto auto minmax(0, 1fr) auto var(--TitleBarMinDragRegionWidth, 48px) var(--TitleBarRightPaddingWidth, 0px)", e.gridTemplateRows = "minmax(0, 1fr)", T.value && (e["--TitleBarRightPaddingWidth"] = "0px"), g.FlowDirection === "RightToLeft" && !T.value && (e.direction = "rtl"), g.Visibility === "Collapsed" && (e.display = "none"), g.Width !== "" && (e.width = Y(g.Width)), g.MinWidth !== "" && (e.minWidth = Y(g.MinWidth)), g.MinHeight !== "" && (e.minHeight = Y(g.MinHeight)), g.MaxWidth !== "" && (e.maxWidth = Y(g.MaxWidth)), g.MaxHeight !== "" && (e.maxHeight = Y(g.MaxHeight)), g.Margin !== "" && (e.margin = pn(g.Margin)), g.HorizontalAlignment !== "" && (e.justifySelf = mn(g.HorizontalAlignment)), g.VerticalAlignment !== "" && (e.alignSelf = hn(g.VerticalAlignment)), g.Background !== "" && (e.background = g.Background), g.Foreground !== "" && (e.color = g.Foreground, e["--TitleBarForegroundBrush"] = g.Foreground), e;
		}), _n = () => {
			!z || g.Title === "" || z.GetTitle() !== g.Title && (D = g.Title, z.SetTitle(g.Title));
		}, vn = () => {
			z && D && z.GetTitle() === D && z.SetTitle(Zt), D = "";
		}, yn = () => {
			let e = b.value, t = x.value;
			if (!e || !t) return;
			let n = t.querySelector(".win-titlebar-content-presenter"), r = e.getBoundingClientRect().width, i = S.value, a = C.value;
			if (C.value = r < 480, r <= 0) return;
			let o = t.clientWidth, ee = n?.scrollWidth ?? t.scrollWidth;
			if (!(r !== F || Math.abs(o - I) > .5 || Math.abs(ee - L) > .5)) return i !== S.value || a !== C.value;
			let te = F < 0 || Math.abs(r - F) > .5;
			return F = r, I = o, L = ee, !P && o > 0 && ee > o + 1 ? (P = r, S.value = !0) : S.value && te && r >= P && (P = 0, S.value = !1), i !== S.value || a !== C.value;
		}, X = () => {
			J || N || (N = (R ?? window).requestAnimationFrame(() => {
				if (N = 0, J) return;
				let e = yn();
				Yt(), Q(), e && Cn();
			}));
		}, bn = () => {
			let e = b.value;
			if (!e || J) return;
			Yt();
			let t = e.getBoundingClientRect(), n = z?.GetTitleBarInsets?.() ?? null, r = Se({
				X: t.x,
				Y: t.y,
				Width: t.width,
				Height: t.height
			}, R?.innerWidth ?? 0, n);
			w.value?.LeftInset === r?.LeftInset && w.value?.RightInset === r?.RightInset || (w.value = r, P = 0, F = -1, I = -1, L = -1, S.value = !1, l(X));
		}, xn = () => {
			j &&= (j.disconnect(), null);
		}, Sn = () => {
			xn();
			let e = x.value;
			e && (j = new (R?.MutationObserver ?? MutationObserver)((e) => {
				g.AutoRefreshDragRegions && e.some((e) => e.type === "childList") && Z();
			}), j.observe(e, {
				childList: !0,
				subtree: !0,
				characterData: !0
			}));
		}, Z = () => {
			let e = b.value;
			if (!e) return;
			let t = ve(e);
			$t = t;
			let n = new Set(t);
			for (let t of e.querySelectorAll("[data-titlebar-passthrough]")) n.has(t) || t.removeAttribute("data-titlebar-passthrough");
			for (let e of t) e.hasAttribute("data-titlebar-passthrough") || e.setAttribute("data-titlebar-passthrough", "");
			Q(), Xt.value += 1;
		}, Q = () => {
			if (!z?.SetDragRegions) return;
			let e = b.value;
			if (!e) return;
			let t = e.getBoundingClientRect(), n = (e) => {
				let n = e.getBoundingClientRect(), r = Math.max(t.left + (w.value?.LeftInset ?? 0), n.left), i = Math.max(t.top, n.top), a = T.value ? 0 : w.value?.RightInset ?? 0;
				return {
					X: r,
					Y: i,
					Width: Math.max(0, Math.min(t.right - a, n.right) - r),
					Height: Math.max(0, Math.min(t.bottom, n.bottom) - i)
				};
			}, r = e.querySelector(".win-titlebar-icon");
			A && M !== r && (M && A.unobserve(M), r && A.observe(r), M = r);
			let i = T.value ? {
				...Bt.value ? { minimize: n(Bt.value) } : {},
				...Vt.value ? { maximize: n(Vt.value) } : {},
				...Ht.value ? { close: n(Ht.value) } : {}
			} : void 0;
			z?.SetDragRegions?.({
				Caption: n(e),
				Passthrough: $t.filter((e) => e.isConnected).map(n).filter((e) => e.Width > 0 && e.Height > 0),
				Icon: r ? n(r) : null,
				CaptionButtons: i
			});
		}, Cn = () => {
			J || (f("LayoutUpdated", $, null), p?.vnode.props?.onLayoutUpdated || i(m.LayoutUpdated, p)?.($, null));
		}, wn = () => {
			Ft.value = !1, Q();
		}, Tn = () => {
			Ft.value = !0, Q();
		}, En = (e) => Kt.value.Button === e ? Kt.value.State : "normal", Dn = (e, t, n) => {
			if (n?.pointerType === "touch") {
				t === "pressed" ? E.value = {
					Button: e,
					State: "pressed"
				} : E.value.Button === e && (E.value = {
					Button: null,
					State: "normal"
				});
				return;
			}
			t === "normal" ? E.value.Button === e && (E.value = {
				Button: null,
				State: "normal"
			}) : E.value = {
				Button: e,
				State: t
			};
		}, On = async () => {
			if (B?.IsMaximized) try {
				Lt.value = await B.IsMaximized();
			} catch (e) {
				R?.console.error("Unable to read window maximize state:", e);
			}
		}, kn = () => {
			let e = ++G;
			V?.(), V = void 0, H?.(), H = void 0, U?.(), U = void 0;
			let t = B, n = xt.value, r = y.value && n && R ? xe(R, n, z) : null;
			if (B = r, Rt.value = {
				Button: null,
				State: "normal"
			}, It.value = !1, t?.SetCaptionButtonHitTestMode && t !== r && Promise.resolve(t.SetCaptionButtonHitTestMode("Web")).catch((e) => R?.console.error("Unable to clear title bar Snap Layout hit testing:", e)), r && (On(), r.SubscribeStateChanged && Promise.resolve(r.SubscribeStateChanged(() => {
				On();
			})).then((t) => {
				J || e !== G ? t() : V = t;
			}).catch((e) => R?.console.error("Unable to watch caption button state:", e)), r.SubscribeCaptionButtonState && Promise.resolve(r.SubscribeCaptionButtonState((t) => {
				J || e !== G || (E.value = {
					Button: null,
					State: "normal"
				}, Rt.value = t);
			})).then((t) => {
				J || e !== G ? t() : H = t;
			}).catch((e) => R?.console.error("Unable to watch native caption pointer state:", e)), r.SubscribeCaptionButtonAction && Promise.resolve(r.SubscribeCaptionButtonAction((t) => {
				!J && e === G && Mn(t);
			})).then((t) => {
				J || e !== G ? t() : U = t;
			}).catch((e) => R?.console.error("Unable to watch native caption actions:", e)), r.SetCaptionButtonHitTestMode)) {
				let t = !!r.SubscribeCaptionButtonAction;
				Promise.resolve(r.SetCaptionButtonHitTestMode(t ? "NativeSnap" : "Web")).then(() => {
					!J && e === G && (It.value = t);
				}).catch((e) => R?.console.error("Unable to enable title bar Snap Layout hit testing:", e));
			}
		}, An = Promise.resolve(), jn = () => {
			let e = z;
			if (!e?.SetPreferredHeightOption) return;
			let t = cn.value, n = ++nn;
			An = An.catch(() => void 0).then(async () => {
				J || n !== nn || await e.SetPreferredHeightOption?.(t);
			}).catch((e) => R?.console.error("Unable to set title bar height:", e));
		}, Mn = async (e) => {
			if (!(!T.value || zt.value)) {
				zt.value = e, Ut.value = null;
				try {
					e === "minimize" ? B?.Minimize ? await B.Minimize() : (f("MinimizeRequested", $, null), p?.vnode.props?.onMinimizeRequested || i(m.MinimizeRequested, p)?.($, null)) : e === "maximize" ? (B?.ToggleMaximize ? await B.ToggleMaximize() : (f("MaximizeRequested", $, null), p?.vnode.props?.onMaximizeRequested || i(m.MaximizeRequested, p)?.($, null)), await On()) : B?.Close ? await B.Close() : (f("CloseRequested", $, null), p?.vnode.props?.onCloseRequested || i(m.CloseRequested, p)?.($, null)), B || (f("CaptionButtonRequested", e, $, null), p?.vnode.props?.onCaptionButtonRequested || i(m.CaptionButtonRequested, p)?.(e, $, null));
				} catch (t) {
					R?.console.error(`Unable to ${e} the window:`, t);
				} finally {
					zt.value = null;
				}
			}
		};
		d(qt, (e) => {
			W !== void 0 && R?.clearTimeout(W), W = void 0, Ut.value = null, e && (W = (R ?? window).setTimeout(() => {
				Ut.value = qt.value === e ? e : null, W = void 0;
			}, 600));
		}), ze(async () => {
			b.value && (R = b.value.ownerDocument.defaultView ?? window, q = R.matchMedia?.("(forced-colors: active)"), rn(), q?.addEventListener("change", rn), z = be(b.value, Te), Wt.value = !!(z && T.value), Yt(), jn(), kn(), bn(), tn = z?.SubscribeTitleBarInsets?.(bn), z?.GetTitleBarInsets && !tn && (K = bn, R.addEventListener("resize", K)), Ft.value = !(z?.IsInputActive?.() ?? b.value.ownerDocument.hasFocus()), Zt = z?.GetTitle() ?? "", _n(), en = z?.SubscribeActivation?.((e) => {
				e ? wn() : Tn();
			}), en || (O = wn, k = Tn, R.addEventListener("focus", O), R.addEventListener("blur", k)), b.value.addEventListener("winui-titlebar-drag-region-changed", Z), Qt = new R.MutationObserver(Z), Qt.observe(b.value, {
				attributes: !0,
				subtree: !0,
				attributeFilter: ["titlebar.isdragregion"]
			}), await l(), !J && (yn(), Z(), Cn(), x.value && Sn(), R?.ResizeObserver && (A = new R.ResizeObserver(X), b.value && A.observe(b.value), Q())));
		}), d([y, xt], () => {
			!R || !z || (kn(), l(Z));
		}, { flush: "post" }), Re(() => {
			J = !0, W !== void 0 && R?.clearTimeout(W), O && R?.removeEventListener("focus", O), k && R?.removeEventListener("blur", k), A && A.disconnect(), en?.(), V?.(), H?.(), U?.(), tn?.(), K && R?.removeEventListener("resize", K), q?.removeEventListener("change", rn), Qt?.disconnect(), b.value?.removeEventListener("winui-titlebar-drag-region-changed", Z), z?.ClearDragRegions?.(), G += 1, T.value && B?.SetCaptionButtonHitTestMode && Promise.resolve(B.SetCaptionButtonHitTestMode("Web")).catch((e) => R?.console.error("Unable to clear title bar Snap Layout hit testing:", e)), It.value = !1, nn += 1, R?.cancelAnimationFrame(N), xn(), vn();
		}), d(() => g.Title, (e, t) => {
			t !== "" && e === "" ? vn() : _n();
		}), d(() => g.AutoRefreshDragRegions, (e) => {
			x.value && Sn(), e && Z();
		}), d(an, (e) => {
			e ? (F = -1, I = -1, L = -1, l(() => {
				yn(), Sn();
			})) : (xn(), P = 0, F = -1, I = -1, L = -1, S.value = !1);
		}), d(S, () => {
			l(Z);
		}, { flush: "post" }), d([
			gt,
			_t,
			vt,
			yt,
			bt,
			st,
			ct,
			ot
		], () => {
			l(() => {
				X(), Z();
			});
		}, { flush: "post" }), d(() => g.FlowDirection, () => {
			l(X);
		}), d(cn, () => {
			jn(), l(X);
		});
		let Nn = (e) => c({
			get: () => e in h.value || g[e] !== null ? g[e] : e === "IconSource" ? Nt.value?.IconSource ?? null : _(e)[0] ?? g[e],
			set: (t) => {
				h.value = {
					...h.value,
					[e]: t
				}, o(Ke[e], t, p);
			}
		});
		for (let e of Object.keys(Ke)) d(() => a(Ke[e], p), () => {
			if (e in h.value) {
				let t = { ...h.value };
				delete t[e], h.value = t;
			}
		});
		let $ = Ve({
			Element: b,
			isCompact: S,
			isNarrow: C,
			...Object.fromEntries([
				"Title",
				"Subtitle",
				"IconSource",
				"LeftHeader",
				"Content",
				"RightHeader",
				"IsBackButtonVisible",
				"IsBackButtonEnabled",
				"IsPaneToggleButtonVisible",
				"IsPaneOpen",
				"IsCaptionButtonsVisible",
				"CaptionButtonsFramework",
				"AutoRefreshDragRegions",
				"PreferredHeightOption",
				"FlowDirection"
			].map((e) => [e, Nn(e)])),
			ResolvedHeightOption: cn,
			TemplateSettings: c(() => ({ IconElement: ot.value ? Nt.value : null })),
			RecomputeDragRegions: Z
		});
		_e($);
		let Pn = {
			t: s,
			slots: we,
			hostAdapter: Te,
			forcedHighContrast: Ee,
			highContrast: De,
			brushAliases: Oe,
			highContrastColors: Ge,
			xamlProps: Ke,
			emit: f,
			instance: p,
			attrs: m,
			overrides: h,
			props: g,
			rootAttrs: qe,
			slotNodes: Je,
			children: Ye,
			flatten: Xe,
			property: Ze,
			propertyNodes: _,
			defaultContent: Qe,
			inheritedResources: $e,
			localResources: et,
			resources: tt,
			resource: v,
			IconSource: nt,
			FlowDirection: rt,
			IsEnabled: it,
			hasProperty: at,
			hasIcon: ot,
			hasLeftHeader: st,
			hasRightHeader: ct,
			IconElementOutlet: lt,
			ElementOutlet: ut,
			outlet: dt,
			LeftHeaderOutlet: ft,
			RightHeaderOutlet: pt,
			ContentOutlet: mt,
			HeaderInset: ht,
			Title: gt,
			Subtitle: _t,
			IsBackButtonVisible: vt,
			IsBackButtonEnabled: yt,
			IsPaneToggleButtonVisible: bt,
			IsCaptionButtonsVisible: y,
			configuredCaptionButtonsFramework: xt,
			IsPaneOpen: St,
			BackButtonEnabled: Ct,
			BackLabel: wt,
			PaneLabel: Tt,
			ContentAlignment: Et,
			ContentVerticalAlignment: Dt,
			ContentMargin: Ot,
			requestBack: kt,
			requestPaneToggle: At,
			elementFromRef: jt,
			rootRef: b,
			registerRoot: Mt,
			iconElementRef: Nt,
			contentAreaRef: x,
			registerContentArea: Pt,
			isDeactivated: Ft,
			isCompact: S,
			isNarrow: C,
			captionPadding: w,
			captionControlsVisible: T,
			nativeCaptionHitTestEnabled: It,
			windowIsMaximized: Lt,
			captionPointerState: E,
			nativeCaptionPointerState: Rt,
			captionActionInFlight: zt,
			minimizeCaptionButton: Bt,
			maximizeCaptionButton: Vt,
			closeCaptionButton: Ht,
			tooltipButton: Ut,
			captionButtonsPortaled: Wt,
			captionButtonHostStyle: Gt,
			effectiveCaptionPointerState: Kt,
			hoveredCaptionButton: qt,
			captionLabels: Jt,
			updateCaptionButtonHost: Yt,
			dragRegionRevision: Xt,
			NARROW_TITLEBAR_WIDTH: 480,
			get defaultDocumentTitle() {
				return Zt;
			},
			set defaultDocumentTitle(e) {
				Zt = e;
			},
			get lastAppliedTitle() {
				return D;
			},
			set lastAppliedTitle(e) {
				D = e;
			},
			get focusHandler() {
				return O;
			},
			set focusHandler(e) {
				O = e;
			},
			get blurHandler() {
				return k;
			},
			set blurHandler(e) {
				k = e;
			},
			get resizeObserver() {
				return A;
			},
			set resizeObserver(e) {
				A = e;
			},
			get contentObserver() {
				return j;
			},
			set contentObserver(e) {
				j = e;
			},
			get attachedPropertyObserver() {
				return Qt;
			},
			set attachedPropertyObserver(e) {
				Qt = e;
			},
			get interactableElements() {
				return $t;
			},
			set interactableElements(e) {
				$t = e;
			},
			get observedIcon() {
				return M;
			},
			set observedIcon(e) {
				M = e;
			},
			get compactMeasureFrame() {
				return N;
			},
			set compactMeasureFrame(e) {
				N = e;
			},
			get compactModeThresholdWidth() {
				return P;
			},
			set compactModeThresholdWidth(e) {
				P = e;
			},
			get lastMeasuredWidth() {
				return F;
			},
			set lastMeasuredWidth(e) {
				F = e;
			},
			get lastMeasuredContentAvailableWidth() {
				return I;
			},
			set lastMeasuredContentAvailableWidth(e) {
				I = e;
			},
			get lastMeasuredContentDesiredWidth() {
				return L;
			},
			set lastMeasuredContentDesiredWidth(e) {
				L = e;
			},
			get ownerWindow() {
				return R;
			},
			set ownerWindow(e) {
				R = e;
			},
			get windowHost() {
				return z;
			},
			set windowHost(e) {
				z = e;
			},
			get captionActionHost() {
				return B;
			},
			set captionActionHost(e) {
				B = e;
			},
			get unsubscribeActivation() {
				return en;
			},
			set unsubscribeActivation(e) {
				en = e;
			},
			get unsubscribeWindowState() {
				return V;
			},
			set unsubscribeWindowState(e) {
				V = e;
			},
			get unsubscribeCaptionState() {
				return H;
			},
			set unsubscribeCaptionState(e) {
				H = e;
			},
			get unsubscribeCaptionAction() {
				return U;
			},
			set unsubscribeCaptionAction(e) {
				U = e;
			},
			get unsubscribeInsets() {
				return tn;
			},
			set unsubscribeInsets(e) {
				tn = e;
			},
			get tooltipTimer() {
				return W;
			},
			set tooltipTimer(e) {
				W = e;
			},
			get preferredHeightRevision() {
				return nn;
			},
			set preferredHeightRevision(e) {
				nn = e;
			},
			get captionHostRevision() {
				return G;
			},
			set captionHostRevision(e) {
				G = e;
			},
			get insetResizeHandler() {
				return K;
			},
			set insetResizeHandler(e) {
				K = e;
			},
			get contrastQuery() {
				return q;
			},
			set contrastQuery(e) {
				q = e;
			},
			contrastChanged: rn,
			get disposed() {
				return J;
			},
			set disposed(e) {
				J = e;
			},
			hasContent: an,
			hasExpandedHeight: on,
			explicitHeight: sn,
			resolvedCaptionHeightOption: cn,
			showTitle: ln,
			showSubtitle: un,
			isNegativeInsetSpacing: dn,
			rootClasses: fn,
			cssLength: Y,
			xamlThickness: pn,
			alignment: mn,
			verticalAlignment: hn,
			rootStyle: gn,
			updateWindowTitle: _n,
			resetWindowTitle: vn,
			updateCompactMode: yn,
			scheduleCompactModeUpdate: X,
			updatePadding: bn,
			stopContentObserver: xn,
			startContentObserver: Sn,
			recomputeDragRegions: Z,
			updateDragRegions: Q,
			notifyLayoutUpdated: Cn,
			onFocus: wn,
			onBlur: Tn,
			captionButtonState: En,
			setCaptionButtonPointer: Dn,
			refreshWindowMaximized: On,
			syncCaptionActionHost: kn,
			get preferredHeightTask() {
				return An;
			},
			set preferredHeightTask(e) {
				An = e;
			},
			syncPreferredHeightOption: jn,
			activateCaptionButton: Mn,
			dependencyProperty: Nn,
			publicApi: $,
			Grid: te,
			Button: le,
			ColumnDefinition: ue,
			ContentPresenter: ce,
			Viewbox: ne,
			TextBlock: ie,
			ToolTip: fe,
			AnimatedIcon: se,
			FontIcon: ae,
			get FontIconSource() {
				return de;
			}
		};
		return Object.defineProperty(Pn, "__isScriptSetup", {
			enumerable: !1,
			value: !0
		}), Pn;
	}
});
//#endregion
export { Ge as default };

//# sourceMappingURL=TitleBar.vue_vue_type_script_setup_true_lang.js.map